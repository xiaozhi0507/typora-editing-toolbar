---
name: scientific-python-plotting
description: Create, refine, or reproduce publication-oriented scientific figures in Python with Matplotlib or Seaborn, including multi-panel layouts, statistical annotations, SHAP plots, consistent styling, and editable PDF or SVG export. Use for 科研绘图、论文配图、科研绘图代码优化 and figure revisions; not for business dashboards, illustration generation, or statistical modeling without a figure deliverable.
---

# 科研 Python 绘图

生成科学含义正确、参数可持续修改、可复现且便于论文排版的图及 Python 源码。沿用用户“顶部参数区＋中文分区注释＋明确颜色映射＋组合图＋PDF/PNG”的工作习惯。当前任务要求和期刊规范优先于本技能默认值。

## 工作入口

- **修改已有图**：先读脚本、配置、数据结构和已有输出，只改与请求有关的参数及实现。已有 `CONFIG_FIG`、`BOXPLOT_*` 等结构可继续使用，不为统一命名重写整个项目。
- **新建科研图**：先明确科学问题、数据粒度、变量单位、分组/面板顺序、统计量含义、输出尺寸。能从文件确认的先自行确认；只对影响科学结论的缺失信息提问，其余说明合理默认后继续。
- **参考图复现**：读取用户图片，拆解布局、字体、颜色、坐标与标注；用真实数据重建，缺少数据时只能输出明确标记的演示或模板。

按需读取，不一次加载所有资料：

| 当前问题 | 读取内容 |
|---|---|
| 参数结构、字体、尺寸、导出或验收要求 | [绘图规范](references/plotting-standard.md)，定位对应小节 |
| Illustrator 中选错轴框、选中整幅数据范围，或要求方便单独编辑图形 | [Illustrator 编辑与裁剪](references/illustrator-editing.md)，区分可见轴框、剪切路径与分组 |
| 箱线/小提琴、回归边际图、SHAP、热图/Mantel、极坐标、气象图、UMAP | [图型注意事项](references/chart-patterns.md)，只读该图型 |
| 用户要求延续本机代码库的具体风格 | [本地习惯与证据](references/local-conventions.md)；仅在源路径可用时读取相关源码 |
| 从零创建普通图的代码骨架 | 将 [plot_template.py](assets/plot_template.py) 复制到任务输出目录，再按任务裁剪或扩展；它是散点＋箱线图示例，不是所有图的固定布局 |

## 核心执行规则

1. **参数只有一个有效来源。** 新脚本在顶部集中 `GLOBAL_SETTINGS`；已有脚本沿用原配置。颜色、字体、边距、图例、inset、标注、输出和随机种子等本次可调参数都从配置读取。每次修改同步源文件中的配置及使用处，避免配置写了却被函数内常量覆盖。
2. **保留修改的作用域。** 用户只改某子图就只更新该子图覆盖项；公共默认不变。用 `deepcopy` 或可靠的深合并，避免修改一个面板污染其它面板。跨会话持久性来自已保存脚本/配置，不能承诺 AI 自动永久记住。
3. **先核对数据，再绘图。** 检查输入路径、工作表/列名、主键与样本对齐、数值和缺失、分类顺序、重复记录；记录实际采用的筛选/聚合。没有真实输入就报出缺失或提供显式 demo，不能自动造数填补。
4. **计算与展示分开。** 优先使用已有经确认的结果表或模型输出。样式修改不重训模型、不换检验、不更换评估集。显著性、置信区间、误差线、指标、阈值均须有可追溯来源；缺失结果不补造。
5. **维持用户的视觉语言。** 英文/数字优先 Times New Roman，中文使用实际存在且支持字形的字体回退，数学式默认 STIX。按类别名称固定颜色；可比面板共用范围/归一化。字号按最终版面尺寸检查，勿机械套用大画布或“顶刊配色”。
6. **显式管理 Figure/Axes。** 优先 `fig, ax` 与绘图函数返回 Figure/Axes；普通多面板先用 constrained layout，精细复刻可用 GridSpec 和手动边距。每张图选一种主布局策略，不在末尾无条件追加 `tight_layout()`。
7. **导出与核验。** 默认 PNG＋PDF，白底；确需透明才开启。设置 `pdf.fonttype=42`，SVG 保留文本时设 `svg.fonttype='none'`。这不能保证 Illustrator 中完美编辑，也不创建原生 AI 图层。海量点可局部栅格化并说明；文字与轴尽量保持矢量。
8. **轴框和数据分别编辑。** 普通科研图默认兼顾 Illustrator 后期修改：可见轴框使用独立的 spine/路径，避免与柱形共用自建剪切分组；双轴图同一条可见边框只由一个 Axes 绘制。需要改善选择体验时，仅对确认不依赖裁剪且导出外观不变的 Artist 去掉冗余裁剪，禁止全图统一 `clip_on=False` 或删除全部蒙版。具体处理与示例见 [Illustrator 编辑与裁剪](references/illustrator-editing.md)。

## 完成标准

- 运行本次新写/改动的代码；用真实输入核对样本数、排序、单位和标注来源。依赖或数据阻塞时明确区分已运行与仅静态检查。
- 打开实际生成的 PNG 检查缺字、遮挡、图例、色条、子图编号、密集区域和最终尺寸下的可读性；不能只凭代码无报错判定图已合格。
- 有 PDF/SVG 时检查页面/画布尺寸、文本是否保留和预期矢量元素；涉及后期编辑时再检查轴框独立、双轴重复边框、数据裁剪范围及越界元素。没有在 Illustrator 实际选择并移动指定边框、确认数据保持不动，就不声称已通过 AI 编辑测试。
- 对用户指定修改检查作用域：改动生效，其他面板和统计结果符合预期。简单样式修改做运行与目视检查即可，不额外搭建测试框架。
- 交付可运行 `.py`、实际生成的图、必要依赖/运行命令；有数据处理或统计步骤时附关键口径/结果。多轮或批量任务建议保存有效配置 JSON。遵守用户“只要代码”等明确交付范围。
- 用中文简要说明改动、输出位置和验证范围；不把演示输出、静态检查或文字可提取说成真实科研结果或 AI 端验证。
