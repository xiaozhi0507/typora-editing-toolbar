"""科研绘图起点：复制到项目目录后修改，不直接在技能目录保存研究结果。

依赖：numpy pandas matplotlib；读取 .xlsx 另需 openpyxl。
演示：python plot_template.py --demo --output-dir ./figures
数据：python plot_template.py --input ./data.csv --output-dir ./figures
输入列由 GLOBAL_SETTINGS['data'] 映射。真实数据与 --demo 互斥。
仅实现线性/对数 y 轴的纵向散点＋箱线图，不计算显著性或模型指标。
"""

from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import platform
import warnings

import matplotlib as mpl
from matplotlib import font_manager
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


BASE_DIR = Path(__file__).resolve().parent

# ==================== 1. 全局可调参数 ====================
GLOBAL_SETTINGS = {
    "data": {"input_path": None, "sheet_name": 0, "x": "x", "y": "y",
             "group": "group", "group_order": None, "missing": "error"},
    "figure": {"size_inches": [7.2, 3.5], "layout": "constrained"},
    "font": {"latin": "Times New Roman", "fallback": ["Liberation Serif", "DejaVu Serif"],
             "cjk": ["SimSun", "Microsoft YaHei", "Noto Serif CJK SC"],
             "size_pt": 10, "mathtext": "stix", "unicode_minus": True},
    "axes": {"label_size_pt": 11, "tick_size_pt": 9, "linewidth_pt": 0.8,
             "tick_direction": "in", "tick_length_pt": 3, "tick_pad_pt": 3,
             "y_scale": "linear", "y_limits": None,
             "x_label": "Predictor (unit)", "y_label": "Response (unit)"},
    "colors": {"Control": "#0072B2", "Treatment": "#D55E00"},
    "palette": ["#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00", "#56B4E9"],
    "scatter": {"size_pt2": 22, "alpha": 0.75, "rasterized": False},
    "boxplot": {"width": 0.5, "showfliers": True, "alpha": 0.65,
                "linewidth_pt": 1.0, "median_color": "black", "whis": 1.5,
                "y_margin": 0.22, "group_label_rotation_deg": 0},
    "annotation": {"median_offset_pt": 5, "number_format": ".2f", "fontsize_pt": 9,
                   "panel_xy_axes": [0.02, 0.98]},
    "legend": {"fontsize_pt": 9, "loc": "best", "frameon": False},
    "panels": {},  # 局部 axes/annotation/colors/legend/scatter/boxplot；如 {'a': {'scatter': {'size_pt2': 32}}}
    "export": {"output_dir": "figures", "stem": "scientific_figure",
               "formats": ["pdf", "png"], "dpi": 300, "transparent": False,
               "bbox_inches": None, "pad_inches": 0.05, "overwrite": False},
    "random_seed": 42,
}


def resolve_path(value):
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (BASE_DIR / path).resolve()


def merged(base, override):
    """深合并；不修改原配置，不使局部设置泄漏至其他子图。"""
    result = deepcopy(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = merged(result[key], value)
        else:
            result[key] = deepcopy(value)
    return result


# ==================== 2. 数据读取与校验 ====================
def load_data(cfg, *, demo=False):
    settings = cfg["data"]
    if demo:
        if settings["input_path"]:
            raise ValueError("--demo 不能与真实输入路径同时使用。")
        rng = np.random.default_rng(cfg["random_seed"])
        x = np.tile(np.linspace(1, 10, 24), 2)
        frame = pd.DataFrame({"x": x, "y": 2 + 0.5 * x + rng.normal(0, 0.6, x.size),
                              "group": np.repeat(["Control", "Treatment"], 24)})
        frame.loc[frame["group"] == "Treatment", "y"] += 1
        source = {"mode": "demo", "description": "Synthetic data; no scientific inference"}
    else:
        if not settings["input_path"]:
            raise ValueError("请提供 --input 或修改 data.input_path；演示须显式指定 --demo。")
        path = resolve_path(settings["input_path"])
        if not path.is_file():
            raise FileNotFoundError(f"输入文件不存在：{path}")
        if path.suffix.lower() == ".csv":
            frame = pd.read_csv(path)
        elif path.suffix.lower() == ".xlsx":
            frame = pd.read_excel(path, sheet_name=settings["sheet_name"])
        else:
            raise ValueError("此模板读取 .csv 或 .xlsx；其他格式请明确实现读取逻辑。")
        columns = [settings["x"], settings["y"]]
        if settings["group"] is not None:
            columns.append(settings["group"])
        if len(columns) != len(set(columns)):
            raise ValueError("x、y、group 必须映射到不同列。")
        missing = set(columns) - set(frame.columns)
        if missing:
            raise ValueError(f"缺少必要列：{sorted(missing)}；现有列：{list(frame.columns)}")
        frame = frame[columns].copy()
        frame.columns = ["x", "y", "group"] if len(columns) == 3 else ["x", "y"]
        if "group" not in frame:
            frame["group"] = "All"
        source = {"mode": "input", "path": str(path), "sheet_name": settings["sheet_name"],
                  "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
    n_input = len(frame)
    if n_input == 0:
        raise ValueError("输入没有数据行。")
    for column in ("x", "y"):
        original = frame[column]
        numeric = pd.to_numeric(original, errors="coerce")
        invalid = original.notna() & numeric.isna()
        if invalid.any():
            raise ValueError(f"{column} 列有 {int(invalid.sum())} 个非数值，不能静默丢弃。")
        frame[column] = numeric
    frame["group"] = frame["group"].astype("string").str.strip()
    bad = (~np.isfinite(frame[["x", "y"]].to_numpy(dtype=float)).all(axis=1)
           | frame["group"].isna().to_numpy() | frame["group"].eq("").fillna(False).to_numpy())
    policy = settings["missing"]
    if policy not in {"error", "drop"}:
        raise ValueError("data.missing 必须是 error 或 drop。")
    if bad.any():
        if policy == "error":
            raise ValueError(f"发现 {int(bad.sum())} 行缺失/非有限数据；明确处理口径后重试。")
        warnings.warn(f"按显式 missing='drop' 删除 {int(bad.sum())} 行。", stacklevel=2)
        frame = frame.loc[~bad].copy()
    if frame.empty:
        raise ValueError("筛选后没有可绘制的数据。")
    groups = settings["group_order"]
    groups = sorted(frame["group"].unique().tolist()) if groups is None else list(groups)
    if len(groups) != len(set(groups)) or set(groups) != set(frame["group"].unique()):
        raise ValueError("group_order 必须逐一包含所有有效组，不能重复或隐藏额外组。")
    settings["group_order"] = groups
    available_colors = [color for color in cfg["palette"] if color not in cfg["colors"].values()]
    for group in groups:
        if group not in cfg["colors"]:
            if not available_colors:
                raise ValueError("分类多于初始色板；请明确设置 colors，避免重复色造成歧义。")
            cfg["colors"][group] = available_colors.pop(0)
    source.update(n_input=n_input, n_used=len(frame), n_dropped=n_input-len(frame),
                  n_by_group={group: int((frame["group"] == group).sum()) for group in groups})
    return frame, source


# ==================== 3. 字体与样式 ====================
def make_rc(cfg):
    font = cfg["font"]
    installed = {entry.name for entry in font_manager.fontManager.ttflist}
    latin = next((name for name in [font["latin"], *font["fallback"]] if name in installed), "DejaVu Serif")
    if latin != font["latin"]:
        warnings.warn(f"未找到 {font['latin']}；实际使用 {latin}。", stacklevel=2)
    cjk = next((name for name in font["cjk"] if name in installed), None)
    families = [latin] + ([cjk] if cjk else [])
    return {
        "font.family": families, "font.size": font["size_pt"],
        "mathtext.fontset": font["mathtext"], "axes.unicode_minus": font["unicode_minus"],
        "text.usetex": False, "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none",
    }


def style_axis(ax, cfg):
    settings = cfg["axes"]
    ax.set_yscale(settings["y_scale"])
    if settings["y_limits"] is not None:
        ax.set_ylim(settings["y_limits"])
    ax.set_ylabel(settings["y_label"], fontsize=settings["label_size_pt"])
    ax.tick_params(direction=settings["tick_direction"], length=settings["tick_length_pt"],
                   pad=settings["tick_pad_pt"], labelsize=settings["tick_size_pt"],
                   width=settings["linewidth_pt"])
    for spine in ax.spines.values():
        spine.set_linewidth(settings["linewidth_pt"])


# ==================== 4. 组合图（按任务替换本节） ====================
def build_figure(frame, cfg, *, demo=False):
    left_cfg = merged(cfg, cfg["panels"].get("a", {}))
    right_cfg = merged(cfg, cfg["panels"].get("b", {}))
    for panel in (left_cfg, right_cfg):
        if panel["axes"]["y_scale"] not in {"linear", "log"}:
            raise ValueError("此模板仅实现 linear/log y 轴。")
        if panel["axes"]["y_scale"] == "log" and (frame["y"] <= 0).any():
            raise ValueError("对数 y 轴不能绘制非正值；请明确变换方式。")
    fig, axes = plt.subplots(1, 2, figsize=cfg["figure"]["size_inches"], layout=cfg["figure"]["layout"])
    groups = cfg["data"]["group_order"]
    for group in groups:
        subset = frame.loc[frame["group"] == group]
        axes[0].scatter(subset["x"], subset["y"], label=group, color=left_cfg["colors"][group],
                        s=left_cfg["scatter"]["size_pt2"], alpha=left_cfg["scatter"]["alpha"],
                        rasterized=left_cfg["scatter"]["rasterized"], zorder=3)
    axes[0].set_xlabel(left_cfg["axes"]["x_label"], fontsize=left_cfg["axes"]["label_size_pt"])
    axes[0].legend(fontsize=left_cfg["legend"]["fontsize_pt"], loc=left_cfg["legend"]["loc"],
                   frameon=left_cfg["legend"]["frameon"])
    box = right_cfg["boxplot"]
    values = [frame.loc[frame["group"] == group, "y"].to_numpy() for group in groups]
    positions = np.arange(1, len(groups) + 1)
    artists = axes[1].boxplot(values, positions=positions, widths=box["width"], patch_artist=True,
                             whis=box["whis"], showfliers=box["showfliers"], showcaps=True,
                             medianprops={"color": box["median_color"], "linewidth": box["linewidth_pt"]},
                             boxprops={"linewidth": box["linewidth_pt"]},
                             whiskerprops={"linewidth": box["linewidth_pt"]},
                             capprops={"linewidth": box["linewidth_pt"]})
    for patch, group in zip(artists["boxes"], groups):
        patch.set_facecolor(right_cfg["colors"][group])
        patch.set_alpha(box["alpha"])
    axes[1].set_xticks(positions, [f"{g}\n(n={len(v)})" for g, v in zip(groups, values)],
                      rotation=box["group_label_rotation_deg"])
    axes[1].margins(y=box["y_margin"])
    annotation = right_cfg["annotation"]
    for x, cap, sample in zip(positions, artists["caps"][1::2], values):
        anchor = float(cap.get_ydata()[0])
        if box["showfliers"]:
            anchor = max(anchor, float(np.max(sample)))
        text = f"M={np.median(sample):{annotation['number_format']}}"
        axes[1].annotate(text, (x, anchor), xytext=(0, annotation["median_offset_pt"]),
                         textcoords="offset points", ha="center", va="bottom",
                         fontsize=annotation["fontsize_pt"], zorder=10)
    for index, (ax, panel) in enumerate(zip(axes, (left_cfg, right_cfg))):
        style_axis(ax, panel)
        ax.text(*panel["annotation"]["panel_xy_axes"], f"({chr(97+index)})", transform=ax.transAxes,
                ha="left", va="top", fontweight="bold", zorder=10)
    # 同一响应变量默认共用范围；用户显式设置不同面板范围/尺度时保留其选择。
    if (left_cfg["axes"]["y_scale"] == right_cfg["axes"]["y_scale"]
            and left_cfg["axes"]["y_limits"] is None and right_cfg["axes"]["y_limits"] is None):
        limits = [ax.get_ylim() for ax in axes]
        common = min(pair[0] for pair in limits), max(pair[1] for pair in limits)
        for ax in axes:
            ax.set_ylim(common)
    if demo:
        fig.suptitle("DEMO — synthetic data", fontsize=cfg["font"]["size_pt"])
    return fig, axes


# ==================== 5. 导出与有效配置记录 ====================
# 若交付需在 Illustrator 单独修改轴框，参照 references/illustrator-editing.md：
# 保持 spine 与数据路径独立，检查重叠边框；不要在此统一关闭全部 Artist 的裁剪。
# 本模板的散点、离群点等仍保留必要裁剪；命名 SVG 元素不等于创建原生 AI 图层。
def export_figure(fig, cfg, source, rc):
    settings = cfg["export"]
    output = resolve_path(settings["output_dir"])
    stem = settings["stem"] + ("_demo" if source["mode"] == "demo" else "")
    if not stem or Path(stem).name != stem:
        raise ValueError("export.stem 应为不含目录的文件名主干。")
    formats = settings["formats"]
    if not formats or not set(formats) <= {"pdf", "png", "svg", "tiff"}:
        raise ValueError("formats 应为 pdf/png/svg/tiff 中的一项或多项。")
    paths = [output / f"{stem}.{suffix}" for suffix in dict.fromkeys(formats)]
    settings_path = output / f"{stem}.settings.json"
    existing = [str(p) for p in [*paths, settings_path] if p.exists()]
    if existing and not settings["overwrite"]:
        raise FileExistsError(f"输出已存在；确认后传 --overwrite，或修改文件名：{existing}")
    output.mkdir(parents=True, exist_ok=True)
    fig.canvas.draw()
    for path in paths:
        fig.savefig(path, dpi=settings["dpi"], bbox_inches=settings["bbox_inches"],
                    pad_inches=settings["pad_inches"], transparent=settings["transparent"],
                    facecolor="none" if settings["transparent"] else "white")
    record = {"settings": cfg, "source": source, "font_families_used": rc["font.family"],
              "versions": {"python": platform.python_version(), "matplotlib": mpl.__version__,
                           "numpy": np.__version__, "pandas": pd.__version__},
              "outputs": [str(p) for p in paths]}
    settings_path.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    return [*paths, settings_path]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group()
    source.add_argument("--input", help="CSV/XLSX 输入路径；相对路径以脚本目录为基准")
    source.add_argument("--demo", action="store_true", help="显式使用模拟数据，图和文件名带 demo 标记")
    parser.add_argument("--output-dir", help="输出目录；相对路径以脚本目录为基准")
    parser.add_argument("--overwrite", action="store_true", help="覆盖本次同名输出")
    args = parser.parse_args()
    cfg = deepcopy(GLOBAL_SETTINGS)
    if args.input:
        cfg["data"]["input_path"] = args.input
    if args.output_dir:
        cfg["export"]["output_dir"] = args.output_dir
    if args.overwrite:
        cfg["export"]["overwrite"] = True
    frame, report = load_data(cfg, demo=args.demo)
    rc = make_rc(cfg)
    with mpl.rc_context(rc):
        fig, _ = build_figure(frame, cfg, demo=args.demo)
        try:
            for path in export_figure(fig, cfg, report, rc):
                print(path)
        finally:
            plt.close(fig)


if __name__ == "__main__":
    main()
