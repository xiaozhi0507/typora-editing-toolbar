# AI 绘图代码指令规范 (AI Plotting Instruction Set)

> 用途：指导 AI 创建、修改、复现科研 Python 绘图代码。基于个人代码库整理；更新日期：2026-10-10。
> 配套技能名：`scientific-python-plotting`。本文件是完整规范，技能入口为同名文件夹中的 `SKILL.md`。

## 1. 目标与优先级

优先保证 **科学含义正确 → 数据与代码可复现 → 参数便于修改 → 最终版面清晰 → 后期编辑方便**。

执行优先级：本次用户明确要求 > 已有项目约定/期刊要求 > 本规范默认。本文中的画布、字号、颜色和 DPI 是起点，不是普适投稿标准。用户只要求改颜色或布局时，保留原数据、统计方法、模型结果与图型。

## 2. 先理解任务，再进入绘图

- 确认输入文件、工作表/列名、每行含义、变量单位、样本或处理主键、类别顺序，以及图需要表达的比较或关系。
- 分清原始重复观测与汇总统计表；均值＋SD 不能直接还原成真实箱线图或小提琴图。
- 明确误差线为 SD、SE、CI 还是用户提供区间；明确比较组、独立/配对/重复测量设计及检验来源。不能把这些作为纯视觉默认。
- 优先读取现有脚本、数据结构和参考图。能自行发现的信息不反复询问；影响结论的缺失信息才需要澄清。
- 没有真实数据时，可生成标明 `Demo / synthetic data` 的演示，但不得把模拟值、p 值、拟合指标混入正式结果。

## 3. 集中参数与持续修改

### 3.1 单一参数来源

新脚本在 import 和路径基准后定义 `GLOBAL_SETTINGS`。推荐按功能分组；小脚本无需空配置层级。已有 `CONFIG_FIG`、`CONFIG_X`、`CONFIG_Y_*`、`COLOR_SCHEMES`、大写常量结构可以保留。

```python
GLOBAL_SETTINGS = {
    "data": {"input_path": "data.xlsx", "sheet_name": "Sheet1"},
    "figure": {"size_inches": (7.0, 4.5), "layout": "constrained"},
    "font": {"latin": "Times New Roman", "mathtext": "stix", "size_pt": 10},
    "axes": {"label_size_pt": 11, "tick_size_pt": 9, "linewidth_pt": 0.8},
    "colors": {"Control": "#0072B2", "Treatment": "#D55E00"},
    "line": {"width_pt": 1.5, "alpha": 1.0},
    "scatter": {"size_pt2": 20, "alpha": 0.75},
    "legend": {"fontsize_pt": 9, "loc": "best", "frameon": False},
    "panels": {},  # 确有局部差异才添加覆盖项
    "export": {"formats": ["pdf", "png"], "dpi": 300,
               "transparent": False, "bbox_inches": None},
    "random_seed": 42,
}
```

参数注释应写清 **含义、单位、作用对象和必要的取值范围**：

| 类型 | 正确单位/坐标 |
|---|---|
| figsize | 英寸；若输入毫米，除以 25.4 |
| 字号、线宽、tick length/pad、labelpad、outward spine offset | pt，不写成 px |
| `scatter(s=...)` | pt²，不能与 `plot(markersize=...)` 的 pt 混为一谈 |
| `ax.transAxes` / `fig.transFigure` | 归一化轴/画布坐标 |
| `annotate(..., textcoords='offset points')` | 相对锚点的 pt 偏移 |
| 数据坐标、日期跨度、极坐标角度 | 明确变量单位；角度说明度或弧度 |

### 3.2 对话修改的落地规则

1. 修改参数值，并保证实际绘图调用读取该值；删除或协调冲突的硬编码。
2. “只改 b 图”写入 b 图的局部覆盖项；“全部统一”才修改公共设置。
3. 嵌套配置使用深复制/深合并；不要修改共享字典导致其它面板随之变化。不要将可变字典直接作为函数默认实参。
4. 参数持久性依靠保存到 `.py` 或项目配置文件。长期/批量任务可额外导出有效配置 JSON；不承诺跨会话自动记忆。
5. 再次运行受影响的图，说明实际改动项。未指定的既有偏好继续沿用。

## 4. 代码与路径习惯

- 保留中文章节注释，但不必给每条 Python 语句做翻译式注释；重点解释科学口径、坐标变换和难改参数。
- 按规模拆分：读取与校验、必要的统计/预处理、样式、绘图、导出、`main()`。简图可合并相邻步骤，不堆砌空函数。
- 用面向对象接口 `fig, ax`；绘图函数接收数据和设置并返回 Figure/Axes。导出用 `fig.savefig()`，批量任务结束用 `plt.close(fig)`。
- 以 `Path(__file__).resolve().parent` 或明确项目根目录解析相对路径；笔记本单独显式指定基准。不得复制旧脚本中的其他用户桌面路径。
- 输入路径与输出目录分开；创建目录前确认目标。不要将名为 `data.xlsx` 的路径当输出文件夹。
- 先检查本地包版本。只列出实际用到的依赖；不为普通图强制安装 SHAP、XGBoost、UMAP、LaTeX 或 SciencePlots。
- 无界面批处理可在导入 pyplot 前选择 Agg；交互环境不强行切换后端。不要全局屏蔽所有 warning，缺字、无效数值和布局失败需要暴露。

## 5. 数据正确性与复现

- 对关键列做显式映射并检查映射后的重名；数值转换失败与 NaN/Inf 分开记录。默认不能静默丢弃坏行。
- 先检查主键是否唯一再 pivot/merge；不得用 `aggfunc='first'` 掩盖重复。真实重复观测应按明确口径聚合，报告 n 与离散程度。
- 配对数据、标签、特征、预测、SHAP 值按样本 ID 对齐；仅行数一致不代表顺序一致。无 ID 时说明位置对齐假设并检查可用证据。
- 分组/月份/处理顺序显式固定；颜色与类别名绑定，不能因缺一个类别而整体换色。
- 缺失值、零分母、空组、常量列、极少样本要有可解释结果或错误；不要为了“能出图”自动填零或造数据。
- 所有随机步骤使用明确 seed：抽样、抖动、bootstrap、拆分和模型算法。固定 seed 不能保证不同库版本、线程或硬件下逐像素一致。
- 保存必要的输入来源、筛选/聚合口径、有效样本量、参数和环境版本。已有模型结果只做绘图时，不额外重训。

## 6. 字体、公式与排版

- **英文与数字**：默认 Times New Roman；实际缺失时回退到可用的 Liberation Serif 或 DejaVu Serif，并说明实际字体。
- **中文**：检测系统可用的中文字体，如 SimSun、Microsoft YaHei、Noto Serif CJK SC。Times New Roman 本身不覆盖中文，单独设置它不等于支持中英混排。
- **公式**：默认 `mathtext.fontset='stix'`，变量/下标/单位按学科约定设置。普通图不默认开启 `text.usetex=True`，避免引入额外运行依赖。
- **负号**：支持时保留 Unicode 负号；只有确认存在显示问题才将 `axes.unicode_minus=False` 作为兼容设置。
- **尺寸**：先按实际使用宽度设置画布；例如单栏 85 mm、双栏 180 mm 只能作为临时起点，最终以目标期刊为准。不要把 `(8, 5)` 或 `(6, 4)` 当作必须遵守的黄金比例。
- **字号**：在最终输出尺寸检查，而不是只看放大的 notebook 预览；刻度/图例约 8–10 pt、标签约 10–12 pt 可作为初始值，按内容密度调整。

## 7. 配色与视觉编码

- 延续用户已确认的处理颜色与色板方案 ID。同一类别跨面板、年份、图例保持一致。
- 新的离散分类可用明确的 Okabe–Ito 风格色值或 Seaborn colorblind 色板，增加线型/点形辅助区分；仍需检查背景对比和灰度输出。
- 连续量优先顺序色图，如 viridis/cividis；有实际中点的正负量用以中点归一化的发散色图；周期量才使用循环色图。
- 不能把 Set1、Muted 或“Nature/Science 风格”一概称为色盲安全或期刊认可标准。SciencePlots 是可选风格包，不是科研图的必要条件。
- 同一数值在可比较面板应具有相同颜色含义。共享 `Normalize`、`vmin/vmax`、色图与色条刻度；不同单位可以用不同色条并标清。
- 透明度按信息密度决定：散点可从 0.7–0.8 起步，置信带通常更淡，文字/关键线条不机械跟随全局 alpha。
- 3D 饼图、径向柱图、渐变填充只能在适合任务或用户要求时使用，不将装饰效果设为科学图的默认。

## 8. 多面板、坐标与标注

### 布局选择

- 普通多面板优先 `plt.subplots(..., layout='constrained')`；不规则面板可用 `subplot_mosaic` 或 GridSpec。
- 已精调的多轴、极坐标、网络图或参考图复刻，可用 GridSpec＋`subplots_adjust`/显式 Axes 位置；把比例和边距放到配置。
- 每图选一种主要布局策略。`tight_layout()` 会关闭 constrained layout，不要先开启后再无条件调用。
- `bbox_inches='tight'` 是导出裁边，不是布局修复；它可能改变最终物理尺寸。有严格尺寸要求时保留 `bbox_inches=None`，在画布内解决溢出。

### 位置与空间

- 子图编号、统计文字一般使用 Axes 坐标；数据标签使用数据坐标；图级图例说明使用 Figure 坐标。
- 对缩放/对数轴，标注优先用 point 偏移；普通线性轴可以使用轴跨度比例，不用数据最大值乘比例代替。
- `ax.margins()` 不保证给所有文字、误差线或手工固定坐标范围留足空间。根据实际元素预留边界并渲染检查。
- 图例合并去重但保留语义顺序；明确图例属于哪个轴。`twinx` 的 zorder 跨 Axes 也受轴绘制顺序影响，不能只调单个元素。

### 箱线图与 inset

- 标注的 **数值** 从真实数据或明确传入的统计结果计算；标注的 **位置** 可以从 `bplot['caps']`/`whiskers` 获取。cap 不是中位数。
- 不写死只有两个箱子：对 `bplot['caps'][1::2]` 与实际 `positions`、中位数逐一对应；横向箱线图需交换坐标逻辑。
- 显示离群点时，标注需同时考虑可见离群点，避免文字落在点中。隐藏离群点只改变显示，不能把它说成删除或清洗异常值。
- inset 单独配置 `bounds`、宽度、字号、刻度、旋转、标签 pad/offset、颜色和 zorder；说明 bounds 相对哪个 Axes/Figure。

## 9. 科学统计与图型约束

- **显著性**：检验名必须与执行的方法一致；Tukey HSD 与 Bonferroni 校正的成对 t 检验不同。明确多重比较控制、原始/校正 p 值及显著性阈值。
- **显著性字母**：依据完整比较矩阵生成并核对全部组对；显著差异组不得共享字母，非显著组应至少共享一个字母。不能凭均值高低分配字母，也不把“未显著”解释成证明相等。
- **误差线/阴影**：说明 SD、SE、CI、预测区间或平滑不确定性；有汇总表时原样采用已确认口径。仅有均值与 SD 而无 n/设计时不补做未获支持的检验。
- **回归**：区分预测–实测的 1:1 参考线与拟合线；R²、RMSE、MAE 使用相同有效样本及明确评估集，单位随目标变量。边际分布必须对应实际横/纵变量。
- **SHAP**：明确特征顺序、样本/类别、模型输出尺度；全局重要性通常是 mean(abs(SHAP))。零交点不自动等于拐点/因果阈值；无交点就报告未发现，不能用中位数替代。
- **热图与 Mantel**：核对矩阵维度、对角线、对称性、缺失掩码和变量顺序；真实 Mantel 结果需距离矩阵、距离方法及置换信息，不能把随机边或普通 Pearson r 伪称 Mantel 检验。
- **极坐标/百分比**：明确半径还是面积编码；内圈只是布局偏移时刻度应还原真实值。百分比确认分母、缺失项和合计，不能任意凑到 100%。
- **UMAP/GAM**：同一嵌入用于不同着色时复用坐标；UMAP-1/2 不是 PCA 主成分，颜色看似混乱不能单独证明解耦。GAM 的响应面说明固定变量/平均方式和观测支持范围。

## 10. PDF、SVG 与 Illustrator 工作流

推荐导出配置：

```python
rc = {
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
    "text.usetex": False,
}
# 将创建 Figure、绘图和保存都放在同一个 rc_context 内。
```

- PDF 优先嵌入 TrueType；不要将 Type 3 列为与 TrueType 等效的 Illustrator 编辑保证。
- SVG 设置 `'none'` 保留文本节点，显示仍取决于接收端字体；数学文本可能拆成多个片段。字体嵌入/文本可提取不等于在 AI 中排版完全不变。
- `zorder` 只控制绘制顺序，**不创建 Illustrator 原生图层**。普通路径可编辑性、文字编辑性、AI 图层结构应分别描述；不能靠把后缀改为 `.ai` 交付原生文件。
- 线条、轴、文字和普通图形尽量保留矢量。海量散点/密集网格可仅对相应 Artist 使用 `rasterized=True`；报告这部分不再能逐点编辑。
- 用图像拼接得到的 PDF 仍然是位图内容。最终组合图应尽量在同一 Figure/GridSpec 中重绘，不将 PNG 拼版误称为矢量图。
- DPI 影响 PNG/TIFF 以及矢量文件中栅格化部分，不使纯矢量线条“更高清”。PNG 默认 300 DPI；特殊投稿要求按具体规范设置。
- 默认 PDF＋PNG 同名输出，背景白色。透明输出须同时协调 `transparent` 与 `facecolor`，避免显式白色 facecolor 抵消期望的透明画布。
- SVG/TIFF/EPS 按需增加。EPS 对透明效果有限制，不把复杂 alpha 图无检查地转为 EPS。

### Illustrator 中的轴框与数据独立编辑

- 可见黑色坐标轴边框与数据系列分别保留为矢量路径；不要把坐标轴边框当作数据剪切路径，也不要人为将两者放进同一个剪切组。选中范围等于整个 Axes 时，先区分数据组、剪切蒙版、背景矩形和真正的 spine，不能只凭选框颜色判断。
- `twinx/twiny` 同一可见边框只保留一个绘制来源，隐藏重复的 spine；保留该轴的刻度、标签和数据变换。上层透明 Axes 不重复画背景或描边。调整 Artist 的 zorder 不等于改变不同 Axes 的绘制顺序，也不建立 AI 图层。
- 必须保留数据剪切组且边框被它覆盖时，可在最终布局后将可见矩形框线复制为 Figure 层的独立路径并隐藏原 spine，使框线在所有数据 Axes 后绘制；保留数据裁剪。只适用于已核对变换/样式的静态导出，不把整幅 Axes 提到最前或额外叠画第二套边框。
- 对已检查完整几何与描边均不依赖裁剪的普通柱形/路径，可以单独 `set_clip_on(False)` 减少冗余的整轴剪切矩形；必须比较修改前后的实际导出。跨边界折线、散点边缘、误差线、置信带、热图/图像、极坐标等保留必要裁剪。禁止遍历全图关闭裁剪，禁止为编辑方便改变数值、截断数据或擅自扩大坐标范围。
- 后期编辑需求明确时，保留标准 PDF＋PNG，按需增加含语义 `gid` 的 SVG 或单独 `_edit` 文件。SVG 名称方便结构定位，但不能承诺 PDF 或 Illustrator 导入后保留原生图层；不要承诺所有格式都完全没有剪切组。
- 参数集中在现有配置区；更改范围、数据或布局后重新检查裁剪条件。完整说明与条件化代码在配套技能的 `references/illustrator-editing.md`。

## 11. 验收与交付

| 验收层面 | 至少检查什么 | 可作出的结论 |
|---|---|---|
| 数据/科学 | 主键、样本数、单位、缺失处理、计算口径与标注来源 | 结果与所用数据/方法一致 |
| 运行 | 实际命令、环境、导出文件、关键 warning | 代码在记录环境下成功运行 |
| 视觉 | 最终尺寸下的标签、遮挡、图例/色条、面板一致性、图外文本 | 已检查所查看图的实际布局 |
| 文件结构 | 页面尺寸、文本、字体资源、矢量/栅格元素 | 已核对导出文件结构 |
| Illustrator | 实际选中并移动指定黑色边框，确认柱形、误差线和标签不随动，再撤销；区分路径/组/蒙版 | 仅此时可以说已验证 AI 编辑；仅结构检查须如实说明 |

运行与视觉检查都不可用时，明确写“未运行/未目视检查”，不要声称全部验证。对简单样式改动只做相关验证；不为了形式添加与风险无关的测试。

通常交付：可运行 `.py`、实际导出的图、必要依赖和运行命令；需要复现处理/统计时提供关键结果表或记录；多轮/批量绘图可附有效配置 JSON。只要代码时不擅自扩大交付范围。

## 12. 可直接使用的请求

> 使用 `$scientific-python-plotting`，读取这份 Excel，保持我的 Times New Roman 和处理配色习惯，制作三面板均值±SD 图。把所有可调参数放到顶部，输出 PDF＋PNG，并检查最终尺寸下的标签。

> 使用 `$scientific-python-plotting` 修改现有脚本：只把 b 图的中位数标注上移 6 pt、inset 缩小 10%；保持其他面板和统计结果，更新相应配置并重新导出。

> 使用 `$scientific-python-plotting` 复现参考图布局。缺少的统计结果标记待补，不伪造显著性；列出需要的数据列。

## 13. 技术依据

以下为 2026-10-07 核对的官方文档；API 使用以实际安装版本为准。

- [Matplotlib 字体、PDF/SVG 与字体回退](https://matplotlib.org/stable/users/explain/text/fonts.html)
- [Constrained layout 与 tight_layout 的关系](https://matplotlib.org/stable/users/explain/axes/constrainedlayout_guide.html)
- [savefig：格式、DPI、透明度与裁边](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.savefig.html)
- [局部栅格化及其分辨率](https://matplotlib.org/stable/gallery/misc/rasterization_demo.html)
- [Artist 裁剪开关及越界风险](https://matplotlib.org/stable/api/_as_gen/matplotlib.artist.Artist.set_clip_on.html)
- [Adobe Illustrator 剪切蒙版说明](https://helpx.adobe.com/illustrator/desktop/manage-objects/edit-objects/about-clipping-masks.html)
- [箱线图统计量、方向及返回元素](https://matplotlib.org/stable/api/_as_gen/matplotlib.axes.Axes.boxplot.html)
- [SciPy Tukey HSD](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.tukey_hsd.html)
