# 本机代码习惯与来源

来源根目录：`E:\学习\科研\科研绘图\绘图代码`。2026-10-07 盘点 24 个 Python 文件，共 6970 行；结构扫描覆盖全部脚本，针对配置、布局、统计及导出精读代表实现。该路径不可用时，以下归纳仍可使用，不依赖此路径才能出图。原脚本仅作为风格参考，未在本次技能制作中修改或整批运行。

## 保留的习惯

| 代码位置（相对根目录） | 观察到的做法 | 技能采用方式 |
|---|---|---|
| `图2/Circular_Barplot/circular_barplot_publication.py`，约第 22 行 | GLOBAL_SETTINGS、中文参数注释、嵌套 scale_axis、显示开关、subplot 边距 | 顶部参数单一来源；位置与开关可调；不沿用特定任务的隐藏标签默认 |
| `气象数据图/plot_weather_and_crop_growth2.py`，第 17–191 行附近 | CONFIG_FIG/X/Y/PLOT/DATA 分块，各轴可独立微调 | 允许沿用成熟的多个 CONFIG_*，补正 pt 与 px 的单位描述 |
| `20260203_RF重要性分析条形图及关键特征的组间差异对比箱线图/shap_boxplot_barplot.py` | COLOR_SCHEMES＋SCHEME_ID、箱线图与 inset 专属参数、嵌套 GridSpec、caps 定位 | 保留分类色板和独立 inset；数值/定位分开，多组时不固定两个 caps |
| `图2/Faceted_Combo_Chart/Faceted_Combo_Chart.py`，第 57–120 行附近 | 中文/英文列名归一化、必需列与组合缺失检查、显著性标签偏移 | 数据校验先行；增加重名/重复主键检查，避免 first 聚合隐藏问题 |
| `图2/Grouped_Bar_Chart/Grouped_Bar_Chart.py`、`图2/Stacked_Bar_Chart/Stacked_Bar_Chart.py` | 处理顺序、月份映射、家族色、均值/SD 与显著性结果读取 | 分类顺序和统计结果与图形样式分离 |
| `回归拟合图+边际直方图+残差图组合图/回归拟合图+边际直方图+残差图组合图.py` | 嵌套 GridSpec、边际分布、残差面板、多个评价指标 | 复用组合布局；逐一校验横纵变量、边际数据和指标所用样本 |
| `高颜值Mantel检验网络图+相关性热图/mantel_heatmap.py` | 节点/连线/标签/图例独立参数和 zorder | 保留可控布局；明确统计来源和视觉映射 |
| `水氮解耦图/code/plot_feature_distribution.py` | UMAP seed、2×3 面板、同一嵌入不同着色、Excel/NPZ 真值核对、PNG/PDF | 保留复用嵌入和交叉核对；共享色条范围、显式处理数据冲突 |
| `GAM模型非线性交互效应等高线热力图/gam_heatmap_visualization.py` | 单子图函数返回 contour 对象、固定色阶、边缘轴标签 | 复用函数和色条；标明统计目标及观测支持范围 |

## 不提升为通用规范的旧写法

- `Tukey's HSD 检验的小提琴图/violin_plot_code.py` 中的 `perform_significance_test` 实际调用 `stats.ttest_ind` 并做 Bonferroni 阈值调整；文件夹名不能证明执行了 Tukey HSD。技能要求检验名称与方法一致。
- `绘制XGB+SHAP特征重要性排序+依赖组合图/shap_analysis.py` 的 `find_knee_point` 在无实数零交点时返回中位数。技能改为显式无结果，并区分零交点与拐点。
- 回归组合图中，顶部 KDE 使用 `y_true` 而顶部直方图使用 `y_pred`；这种对应关系要按主图 x 变量复核，不能只复制布局。
- 多个脚本硬编码其它用户的 `Desktop` 路径；新脚本使用明确的项目/脚本基准和可配置路径。
- 部分脚本全局忽略 warning、无条件隐藏离群点、使用大型默认画布、自动造示例数据；这些都是具体示例选择，不是普遍要求。
- 原规范中 Type 3/42 的编辑承诺、以 zorder 方便 AI 分层的描述、强制 tight_layout 均需收窄；所有文本强制 Times New Roman 也不能保证中文覆盖。
- 一些已有 PNG/PDF 是参考输出；本次未验证所有旧数据或旧图的科学正确性。代码习惯提炼与整库审计是不同范围。
