# Illustrator 中单独编辑轴框

适用：用户要在 Adobe Illustrator 中修改 PDF/SVG 的坐标轴边框，却选中了柱形系列、一个覆盖整幅子图的矩形或剪切组；或明确要求方便后期编辑。目标是让可见轴框与数据可分别选择，保持原图的数据、尺度和显示结果。

## 先分清选中的对象

- 黑色可见边框通常来自 `ax.spines`；Axes 背景 patch、数据的矩形剪切路径、系列 group 的选择范围都可能与它重合。
- 选框颜色是编辑器的选择提示，不能据此认定对象是“红色边框”。一个系列 group 的包围框也可能很大；不能只凭截图断定一定有剪切蒙版。
- 能读原脚本和矢量文件就检查对象树/裁剪关系。只有截图时说明是可能原因，不假称已经定位或修复原图。

## 绘图结构

1. 用独立 spine/线条表示可见轴框，不让它兼作数据蒙版，也不额外叠加一个相同尺寸的空心矩形。背景需要时保留，避免重复描边。
2. `twinx/twiny` 检查重复 spine。普通双 y 轴图可由左轴负责左/上/下边框，右轴仅负责右边框；错位多轴按实际位置处理，不能机械隐藏有意义的轴。保留刻度、标签、数值范围及数据变换。
3. 不将“移动绘图边框”直接实现为移动整个 Axes；那会一起移动数据和刻度。先辨明是改边框样式/位置，还是调整整块绘图区。
4. SVG 可给边框、柱形、误差线等设唯一、稳定的 `gid`。它帮助检查 SVG 节点；不保证 Illustrator 导入后的命名或图层，PDF 也不因此获得同样的组名。

普通双 y 轴的局部示例（沿用原配置的线宽/颜色，不重建整图）：

```python
# ax_left、ax_right 已由原脚本创建；每条可见边框保留一个来源。
ax_left.spines["right"].set_visible(False)
for side in ("left", "top", "bottom"):
    ax_right.spines[side].set_visible(False)
ax_right.patch.set_visible(False)

for axis_name, ax in (("left", ax_left), ("right", ax_right)):
    for side, spine in ax.spines.items():
        if spine.get_visible():
            spine.set_gid(f"panel-a-frame-{axis_name}-{side}")
for series_name, container in (("early", bars_left), ("late", bars_right)):
    for index, bar in enumerate(container.patches):
        bar.set_gid(f"panel-a-bars-{series_name}-{index}")
```

## 减少冗余裁剪，保留必要裁剪

- 只对**逐个检查后不依赖裁剪**的 Artist 去掉裁剪。检查最终布局下的完整路径和描边范围，而不仅是柱高或散点中心；误差线、点的尺寸、旋转/坐标变换、阴影和 path effects 需另查。
- 柱底正好落在零轴、柱边接触坐标边界时，关闭裁剪可能露出半个描边；不能仅以“数据在 xlim/ylim 内”作为通过条件。若无法证明导出显示一致，保留裁剪，让可见边框位于剪切组之外，并说明如何在对象树中选择。
- 确认不影响显示的普通矩形柱可逐个关闭裁剪，避免每个数据系列携带不必要的整轴剪切范围。调用必须发生在已确定数据、范围及布局之后，并在后续修改时重新判断。

```python
# verified_interior_bars 是本次逐个核验后的对象清单，不是 fig.findobj() 的全部结果。
for bar in verified_interior_bars:
    bar.set_clip_on(False)
```

- 不对跨边界折线、误差线、置信带、图像/热图、极坐标等统一关裁剪；不得对全图遍历执行 `set_clip_on(False)`、删除所有 `clip-path` 或在 Illustrator 一次释放所有蒙版。
- 不为消除蒙版而修改观测值、删去范围外数据、改变零基线或扩大既定坐标范围。确需改变视觉表现的编辑副本应单独命名并说明差异，不能冒充原版结果。

## 导出与核验

### 必须保留数据裁剪时，优先让框线最后绘制

双轴图中，右轴的数据组可能在左轴 spine 之后输出。仅提高左轴 spine 的 `zorder` 不能跨 Axes 解决覆盖。若需要更方便选框，可在完成布局后把**可见的矩形轴框**复制为 Figure 层的独立路径，隐藏原 spine，让新框线在所有数据 Axes 之后绘制；数据的必要裁剪仍然保留。不能只叠加第二套框线。

下面是普通直角坐标图的可选导出步骤；`frame_zorder` 放入原配置，取值高于所有 Axes，仍需检查图例/标注是否与框重叠。有动态缩放、非矩形投影、自定义 spine/path effects 时，不直接套用。更改布局/范围后应重新生成。

```python
from matplotlib.patches import PathPatch

fig.canvas.draw()  # 先确定最终 spine 路径和布局
for ax in (ax_left, ax_right):
    for side, spine in ax.spines.items():
        if not spine.get_visible():
            continue
        frame = PathPatch(
            spine.get_path().deepcopy(), transform=spine.get_transform(),
            fill=False, edgecolor=spine.get_edgecolor(), alpha=spine.get_alpha(),
            linewidth=spine.get_linewidth(), linestyle=spine.get_linestyle(),
            capstyle=spine.get_capstyle(), joinstyle=spine.get_joinstyle(),
            clip_on=False, zorder=frame_zorder,
        )
        frame.set_gid(spine.get_gid())
        fig.add_artist(frame)
        spine.set_visible(False)
```

此处只关闭**边框路径**自身的裁剪，不触碰柱形数据的裁剪。Figure 层绘制顺序改善矢量对象的独立定位，但 Illustrator 的导入分组/点击选择仍须实际验证。

### 验收

- 默认保留 PDF＋PNG。用户明确需要对象定位/分组时，可增加带语义 `gid` 的 SVG；必要时另存 `_edit` 文件，保留标准图。保持文字与轴为矢量，不把整图栅格化来“解决”对象选择问题。
- 比较前后 PNG 和矢量文件的实际渲染，重点看柱底、最左/右柱、误差线端点、面板边缘和双轴接缝。数值、坐标范围、刻度与统计标签保持不变。
- 结构检查至少区分：可见边框路径、数据路径、剪切范围、重复边框，以及 SVG 中目标对象的祖先是否有 `clip-path`。PDF 仍可能有组或页面级裁剪；“没有整轴数据裁剪”不等于“没有任何剪切组”。
- 若可使用 Illustrator，实际选中一条黑色轴框，移动少量，确认柱形、误差线和标签不随动，再撤销。操作时区分选择工具与直接选择工具，必要时在图层面板展开数据组/剪切组定位目标路径；不要把释放全部蒙版作为首选。
- 只有代码/矢量结构/渲染验证时，明确写“未在 Illustrator 中实测选择与移动”。用户现有图没有提供原文件时，本次 skill 更新不会自动修复旧 PDF。

依据：2026-10-10 核对 [Matplotlib 裁剪开关](https://matplotlib.org/stable/api/_as_gen/matplotlib.artist.Artist.set_clip_on.html)、[Artist gid](https://matplotlib.org/stable/api/_as_gen/matplotlib.artist.Artist.set_gid.html) 与 [Adobe 剪切蒙版说明](https://helpx.adobe.com/illustrator/desktop/manage-objects/edit-objects/about-clipping-masks.html)；具体导出结构仍以本机 Matplotlib 和接收软件实测为准。
