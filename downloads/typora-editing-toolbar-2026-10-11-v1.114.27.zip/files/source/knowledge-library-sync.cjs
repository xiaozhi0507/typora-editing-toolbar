'use strict';
const DriveCleanup=require('./knowledge-drive-cleanup.cjs');
const restoreArchive=require('./knowledge-drive-restore.cjs');
// One owner per library/window. Transfers outlive the settings dialog.
class KnowledgeLibrarySync {
 constructor(backup,drive,{flush=async()=>{},changed=async()=>{},onState=()=>{},debounce=1800,poll=4000,settle=500}={}){
  this.backup=backup;this.drive=drive;this.flush=flush;this.changed=changed;this.onState=onState;this.debounce=debounce;this.poll=poll;this.settle=settle;this.state={busy:false,text:'就绪',stage:'idle'};this.tracked=new Map();this.enabled=false;this.closed=false;this.blocked=false;this.retryAt=0;
 }
 emit(update){Object.assign(this.state,update);this.onState({...this.state,enabled:this.enabled});}
 async start(){
  const b=this.backup;await b.mkdir(b.destination);let saved;
  try{saved=await b.json(b.path.join(b.root,'sync-settings.json'));}catch(e){if(e.code!=='ENOENT')throw e;}
  this.enabled=saved?.enabled!==false;this.closed=false;
  try{this.watcher=b.store.fs.watch(b.store.root,{recursive:true},(_,file)=>{if(!file||!/(?:\.lock(?:\.recover)?|\.partial|\.previous|\.tmp-[\w-]+)$/.test(String(file)))this.queue();});this.watcher.on('error',()=>{this.watcher?.close();this.watcher=null;});}catch{}
  await this.track([]);this.poller=setInterval(()=>void this.checkFiles(),this.poll);this.poller.unref?.();
  if(this.enabled&&this.drive.account())this.queue(2500);this.emit({text:this.enabled?'实时同步已开启':'实时同步已暂停'});return this;
 }
 async setEnabled(value){this.blocked=false;this.retryAt=0;this.enabled=!!value;await this.backup.atomic(this.backup.path.join(this.backup.root,'sync-settings.json'),JSON.stringify({enabled:this.enabled}));clearTimeout(this.timer);this.timer=null;this.pending=false;if(this.enabled)this.queue();this.emit({retryAt:null,text:this.enabled?'实时同步已开启':'实时同步已暂停'});}
 async signature(file){try{const s=await this.backup.io.stat(file);return s.size+':'+s.mtimeMs;}catch(e){return e.code==='ENOENT'?'missing':String(e.code);}}
 async track(files){this.tracked=new Map(await Promise.all([this.backup.store.file,...files].map(async f=>[f,await this.signature(f)])));}
 async checkFiles(){if(this.checking||this.closed||!this.enabled)return;this.checking=true;try{for(const [file,old]of this.tracked){const current=await this.signature(file);if(current!==old){this.tracked.set(file,current);this.queue();}}}finally{this.checking=false;}}
 queue(delay=this.debounce){if(!this.enabled||this.closed||this.blocked)return;try{if(!this.drive.account())return;}catch{return;}this.pending=true;clearTimeout(this.timer);this.timer=setTimeout(()=>{this.timer=null;if(!this.state.busy)void this.upload({automatic:true}).catch(()=>{});},Math.max(delay,this.retryAt-Date.now()));this.timer.unref?.();}
 async pause(ms,signal){return new Promise((resolve,reject)=>{
  const abort=()=>{clearTimeout(timer);reject(Object.assign(Error('已取消同步'),{name:'AbortError'}));};
  const timer=setTimeout(()=>{signal.removeEventListener('abort',abort);resolve();},ms);
  if(signal.aborted)abort();else signal.addEventListener('abort',abort,{once:true});
 });}
 async job(fn,{rescan=false,preservePending=false,autoRetry=false}={}){
  if(this.closed)throw Error('同步已关闭');if(this.state.busy)throw Error('已有同步任务正在运行');clearTimeout(this.timer);this.timer=null;if(!preservePending)this.pending=false;this.controller=new AbortController();const signal=this.controller.signal;
  const stale=e=>rescan&&['BACKUP_SOURCE_CHANGED','BACKUP_PLAN_STALE'].includes(e.code);
  this.emit({busy:true,error:'',retryAt:null,text:'正在准备…',stage:'scanning'});
  try{
   for(let attempt=0;;attempt++){
    try{const result=await fn({signal,onProgress:(text,stage)=>this.emit({text,stage:stage||this.state.stage})});this.failures=0;return result;}
    catch(e){if(!stale(e)||attempt>=2)throw e;this.emit({error:'',text:'检测到新变化，正在自动重新扫描…',stage:'waiting'});await this.pause(this.settle,signal);}
   }
  }catch(e){
   if(stale(e)){this.emit({error:'',summaryState:'waiting',text:this.enabled?'知识库仍在更新，稍后自动继续':'知识库仍在更新，请稍后扫描',stage:'waiting'});if(this.enabled)this.queue(Math.max(2000,this.debounce));return {deferred:true};}
   this.emit({summaryState:this.state.summaryState==='scanning'?'stale':this.state.summaryState,error:e.name==='AbortError'?'':e.message,text:e.name==='AbortError'?'已暂停本次任务':e.message,stage:e.name==='AbortError'?'idle':'error'});
   if(autoRetry&&e.name!=='AbortError'){
    const retryable=e.retryable===true||['PLUGIN_NETWORK_TIMEOUT','ECONNRESET','ETIMEDOUT','ENOTFOUND','EAI_AGAIN','ECONNREFUSED'].includes(e.code);
    if(retryable&&this.enabled){const delay=Math.max(Number(e.retryAfterMs)||0,Math.min(300000,30000*2**Math.min(this.failures++||0,4)));this.retryAt=Date.now()+delay;this.emit({retryAt:this.retryAt});this.queue(delay);}
    else {this.blocked=true;this.pending=false;clearTimeout(this.timer);this.timer=null;this.emit({retryAt:null});}
   }throw e;
  }finally{this.controller=null;this.emit({busy:false});if(this.pending&&!this.timer&&!this.closed)this.queue();}
 }
 async plan(options){
  this.emit({summaryState:'scanning',pendingFiles:undefined});
  const plan=await this.backup.plan({...options,onSummary:(summary,ready)=>this.emit({summary:ready?summary:{...this.state.summary,...summary},summaryState:ready?'ready':'scanning',...(ready?{summaryAt:Date.now()}:{})})});
  await this.track([...plan.collected.files.values()].map(f=>f.file));return plan;
 }
 async upload({automatic=false}={}){if(this.state.busy)throw Error('已有同步任务正在运行');this.blocked=false;this.retryAt=0;return this.job(async options=>{
  await this.flush();const b=this.backup,plan=await this.plan(options);
  // A recreated or cleared library must not replace cloud history in the background.
  // Keep watching so the first new item resumes sync without changing the user's setting.
  if(automatic&&plan.collected.library.items.length===0){
   this.emit({summary:plan.summary,summaryState:'ready',pendingFiles:undefined,text:'知识库为空，已跳过自动同步',stage:'idle'});
   return {skipped:true,reason:'empty-library'};
  }
  const remote=await this.drive.scan(b,plan,options);this.emit({pendingFiles:remote.count});
  const result=await this.drive.run(b,plan,remote,options);
  this.emit({last:result,summary:plan.summary,summaryState:'ready',pendingFiles:0,text:'已同步 · '+result.cloudFiles+' 个文件',stage:'done'});
  if(b.store.hash((await b.store.read()).data)!==b.store.hash(plan.collected.initial))this.queue();
  return result;
 },{rescan:true,autoRetry:true});}
 async manualUpload(confirm,{cleanupOnly=false}={}){
  if(typeof confirm!=='function')throw Error('清理需要确认预览');
  this.blocked=false;this.retryAt=0;
  // This path has no automatic retry. A failed or stale confirmation never
  // becomes permission for a background task to delete cloud data.
  return this.job(async options=>{
   const b=this.backup,cleaner=new DriveCleanup(this.drive,b);await cleaner.recover();
   await this.flush();const plan=await this.plan(options),preview=await cleaner.inspect(plan,options);
   let choice='sync';
   if(preview.documents.length){this.emit({text:'等待选择是否清理云端备份',stage:'confirming'});choice=await confirm(preview,options.signal);}
   else if(cleanupOnly){this.emit({text:'没有需要清理的云端文献',stage:'done'});return {skipped:true,reason:'nothing-to-clean'};}
   b.check(options.signal);if(choice!=='sync'&&choice!=='cleanup'){this.emit({text:'已取消，未修改云端备份',stage:'idle'});return {cancelled:true};}
   this.drive.check(options.signal,preview.key);await b.assertCurrent(plan,options.signal);
   const remote=await this.drive.scan(b,plan,options),result=await this.drive.run(b,plan,remote,options);
   let cleanup;if(choice==='cleanup')cleanup=await cleaner.run(plan,preview,result,options);
   this.emit({last:result,summary:plan.summary,summaryState:'ready',pendingFiles:0,catalog:null,cleanup,text:cleanup?'已同步并清理 '+cleanup.documents+' 篇文献 · '+cleanup.files+' 个附件移入云端回收站':'已同步 · '+result.cloudFiles+' 个文件',stage:'done'});
   return {...result,cleanup};
  });
 }
 async scan({localOnly=false}={}){return this.job(async options=>{
  await this.flush();const plan=await this.plan(options);
  if(localOnly){this.emit({text:'本机变化统计已更新',stage:'idle'});return {plan};}
  const remote=await this.drive.scan(this.backup,plan,options);this.emit({summary:plan.summary,pendingFiles:remote.count,text:'待上传 '+remote.count+' 个文件',stage:'idle'});return {plan,remote};
 },{rescan:true,preservePending:localOnly});}
 async catalog({all=false}={}){return this.job(async options=>{const catalog=await (all?this.drive.catalogAll(this.backup,options):this.drive.catalog(this.backup,options));this.emit({catalog,text:'云端文件已更新 · '+catalog.rows.length+' 个',stage:'idle'});return catalog;});}
 async pull({all=false,packageId=''}={}){if(all)return this.job(async options=>{
  await this.flush();const catalog=await this.drive.catalogAll(this.backup,options),result=await restoreArchive(this.drive,this.backup,catalog,{...options,packageId});
  await this.changed();
  // Refresh local counters after a committed download. A scan failure must not
  // turn an already completed restore into a reported transfer failure.
  try{await this.plan(options);}catch{this.emit({summary:{items:(await this.backup.store.read()).data.items.length},summaryState:'stale',summaryAt:0});}
  this.emit({catalog,pull:result,text:'已下载 '+result.files+' 个文件 · 新增 '+result.items+' 篇文献'+(result.conflicts?' · 本地修改已保留':''),stage:'done'});return result;
 });return this.job(async options=>{
  await this.flush();const b=this.backup,{signal,onProgress}=options,catalog=await this.drive.catalog(b,options);this.drive.check(signal,catalog.key);
  const release=await b.lock('cloud.lock');try{
   const snapshot=catalog.snapshot;let sources=[];
   try{sources=await b.json(b.path.join(b.root,'sources-'+snapshot.packageId+'.json'));}catch(e){if(e.code!=='ENOENT')throw e;}
   let collection;try{collection=await b.archive.collect(options);}catch(e){if(!sources.length)throw e;collection={files:new Map()};}
   const current=new Map([...collection.files.values()].map(f=>[f.entry,f]));
   // Paths are taken only from local records, never from an absolute cloud path.
   const previous=await b.latest(),base=new Map((previous?.files||[]).map(f=>[f.path,f.sha256]));
   const mappings=new Map(sources.map(f=>[f.path,f]));const allowed=new Set([...current.values()].map(f=>b.path.resolve(f.file).toLowerCase()));
   const data=(await b.store.read()).data;for(const item of data.items)for(const ref of item.files)if(ref.linkType!=='url')allowed.add(b.path.resolve(b.store.resolveFile(ref)).toLowerCase());
   const results=[];let count=0;
   // Stage and verify every cloud byte before touching any current document.
   for(const row of catalog.rows){b.check(signal);const target=b.object(row.sha256);let valid=false;
    if(await b.exists(target))valid=(await b.fingerprint(target,{signal})).sha256===row.sha256;
    if(!valid)await this.drive.download(b,catalog.key,row.remote,target,options);
    const hash=await b.fingerprint(target,{signal});if(hash.sha256!==row.sha256||hash.bytes!==row.bytes)throw Error('下载文件与备份清单不符');
    onProgress('正在校验下载 '+(++count)+' / '+catalog.rows.length,'downloading');
   }
   for(const row of catalog.rows){this.drive.check(signal,catalog.key);const local=current.get(row.path),saved=mappings.get(row.path);let target=saved&&(b.managed.inside(b.store.root,saved.file)||allowed.has(b.path.resolve(saved.file).toLowerCase()))?saved.file:local?.file;
    if(target&&!allowed.has(b.path.resolve(target).toLowerCase())&&!b.managed.inside(b.store.root,target))target=null;
    const imported=!target;if(!target)target=b.path.join(b.store.root,'storage','drive-downloads',snapshot.packageId,...row.path.split('/'));
    let before=await b.exists(target),old=before?await b.fingerprint(target,{signal}):null;const source=b.object(row.sha256);let conflict=false;
    if(old?.sha256===row.sha256){results.push({path:row.path,target,unchanged:true,imported});continue;}
    if(old&&old.sha256!==(saved?.sha256||base.get(row.path))){const ext=b.path.extname(target);target=target.slice(0,target.length-ext.length)+'.cloud-conflict-'+row.sha256.slice(0,10)+ext;conflict=true;old=null;
     if(await b.exists(target)){if((await b.fingerprint(target,{signal})).sha256===row.sha256){results.push({path:row.path,target,unchanged:true,conflict,imported});continue;}target=target.slice(0,target.length-ext.length)+'-'+b.crypto.randomUUID().slice(0,8)+ext;}
    }
    await b.mkdir(b.path.dirname(target));await b.managed.regular(b.path.dirname(target));
    // Keep a byte-exact rollback copy, then recheck immediately before replacement.
    if(old){const rollback=b.path.join(b.root,'before-pull',b.crypto.randomUUID());await b.mkdir(b.path.dirname(rollback));await b.io.copyFile(target,rollback);if((await b.fingerprint(target,{signal})).sha256!==old.sha256)throw Error('下载期间本机文件发生变化，请重试');}
    const temp=target+'.'+b.crypto.randomUUID()+'.partial';try{await b.io.copyFile(source,temp,b.store.fs.constants.COPYFILE_EXCL);if((await b.fingerprint(temp,{signal})).sha256!==row.sha256)throw Error('本机写入校验失败');
     if(old){if((await b.fingerprint(target,{signal})).sha256!==old.sha256)throw Error('本机文件发生变化，请重试');await b.io.rename(temp,target);}else{await b.io.copyFile(temp,target,b.store.fs.constants.COPYFILE_EXCL);}
    }finally{await b.io.unlink(temp).catch(()=>{});}
    results.push({path:row.path,target,conflict,imported});
   }
   const added=results.filter(r=>r.imported||r.conflict);{const original=(await b.store.read()).data,next=JSON.parse(JSON.stringify(original));
    for(const item of snapshot.library.items){const existing=next.items.find(i=>i.id===item.id);const files=item.files.filter(f=>f.linkType!=='url').map(f=>(existing?added:results).find(r=>r.path===f.path)).filter(Boolean);if(!files.length)continue;
     const refs=files.map(f=>b.store.fileRef(f.target));
     if(existing){for(const ref of refs)if(!existing.files.some(f=>f.path===ref.path))existing.files.push(ref);}
     else next.items.push({...item,collections:[],related:[],files:refs,title:item.title+'（云端下载）'});
    }if(b.store.hash(original)!==b.store.hash(next))await b.store.commit(original,next);
   }
   await this.changed();this.emit({catalog,text:'已下载更新 '+results.filter(r=>!r.unchanged).length+' 个文件'+(results.some(r=>r.conflict)?' · 冲突文件已另存':'') ,stage:'done',pull:results});return results;
  }finally{await release();}
 });}
 cancel(){const retrying=!!this.state.retryAt;this.retryAt=0;this.state.retryAt=null;this.pending=false;clearTimeout(this.timer);this.timer=null;this.controller?.abort();if(retrying)this.emit({retryAt:null});}
 close(){this.closed=true;this.cancel();this.watcher?.close();clearInterval(this.poller);}
}
module.exports=KnowledgeLibrarySync;
