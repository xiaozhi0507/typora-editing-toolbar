'use strict';
// Manual-only, previewed cleanup. Every surviving historical snapshot is kept.
// Unowned legacy attachments are retained whenever their snapshot still has items.
const API='https://www.googleapis.com/drive/v3/';
const HASH=/^[a-f0-9]{64}$/;
const stale=()=>Error('本机或云端备份已变化，请重新点击“立即同步”检查清理清单');
class DriveCleanup {
 constructor(drive,backup){this.d=drive;this.b=backup;}
 journal(){return this.b.path.join(this.b.root,'cloud-cleanup.json');}
 async pending(){try{return await this.b.json(this.journal());}catch(e){if(e.code==='ENOENT')return null;throw e;}}
 stamp(meta){return JSON.stringify([meta.id,meta.name,meta.size,meta.md5Checksum,meta.sha256Checksum,[...(meta.parents||[])].sort(),!!meta.trashed]);}
 contained(meta,parent){return meta.parents?.length===1&&meta.parents[0]===parent&&meta.mimeType!=='application/vnd.google-apps.folder';}
 async inventory(key,signal){
  const d=this.d,ns='kb-'+this.b.libraryId;d.check(signal,key);
  const roots=await d.list(key,"mimeType = 'application/vnd.google-apps.folder' and appProperties has { key='typoraBackup' and value='"+ns+"' }",signal);
  if(roots.length>1)throw Error('云端存在重复备份目录，无法安全清理');
  if(!roots.length)return {root:null,records:[],snapshots:[]};
  const root=roots[0],folders=await d.list(key,"'"+d.id(root.id)+"' in parents and mimeType = 'application/vnd.google-apps.folder'",signal);
  const named=tag=>folders.filter(f=>f.appProperties?.typoraBackup===ns+'-'+tag),objects=named('objects'),history=named('snapshots');
  if(objects.length!==1||history.length!==1)throw Error('云端备份目录不完整或重复，无法安全清理');
  const records=await d.list(key,"'"+d.id(objects[0].id)+"' in parents",signal),snapshots=await d.list(key,"'"+d.id(history[0].id)+"' in parents",signal);
  if(snapshots.some(m=>!/^snapshot-[a-f0-9]{64}\.json$/.test(m.name)||!this.contained(m,history[0].id)))throw Error('历史备份目录含未知文件，请先检查，未执行清理');
  if(snapshots.length>500||snapshots.reduce((n,m)=>n+Number(m.size),0)>128*1024**2)throw Error('历史清单过多，暂不能安全清理');
  const pointer=root.appProperties?.typoraLatest;
  if(pointer&&(!HASH.test(pointer)||!snapshots.some(m=>m.name==='snapshot-'+pointer+'.json')))throw Error('云端最新备份索引不完整，无法安全清理');
  return {root,objects:objects[0].id,history:history[0].id,records,snapshots};
 }
 async inspect(plan,{signal,onProgress=()=>{}}={}){
  const d=this.d,b=this.b,key=d.account()?.key;if(!key)throw Error('请先授权 Google Drive 备份');
  await b.assertCurrent(plan,signal);const remote=await this.inventory(key,signal),keep=new Set();
  // Recycle-bin items remain in this list. Imported copies also protect source IDs.
  for(const item of plan.collected.library.items){keep.add(item.id);if(item.archiveImport?.sourceId)keep.add(item.archiveImport.sourceId);}
  const removed=new Map(),entries=[],protectedHashes=new Set(plan.files.map(f=>f.sha256)),removedHashes=new Set(),legacyHashes=new Set();
  for(const [index,meta]of remote.snapshots.entries()){
   if(Number(meta.size)>b.archive.limits.json)throw Error('历史清单过大，无法安全清理');
   onProgress('正在检查历史备份 '+(index+1)+' / '+remote.snapshots.length,'scanning');
   const cache=b.path.join(b.root,'cleanup-preview',d.id(meta.id)+'-'+meta.name);let valid=false;
   if(await b.exists(cache))valid=d.matches(meta,await b.fingerprint(cache,{signal}));
   if(!valid)await d.download(b,key,meta,cache,{signal});
   const snapshot=b.validate(await b.json(cache));if(meta.name!=='snapshot-'+snapshot.packageId+'.json')throw Error('历史清单名称与内容不符');
   for(const f of snapshot.files)if(!remote.records.some(m=>m.name===f.sha256&&Number(m.size)===f.bytes&&(m.sha256Checksum?m.sha256Checksum===f.sha256:!!m.md5Checksum)))throw Error('历史备份缺少附件或校验不符，未执行清理');
   const missing=snapshot.library.items.filter(i=>!keep.has(i.id));for(const item of missing)removed.set(item.id,{id:item.id,title:item.title||'未命名文献'});
   const library=JSON.parse(JSON.stringify(snapshot.library));library.items=library.items.filter(i=>keep.has(i.id));const ids=new Set(library.items.map(i=>i.id));
   for(const item of library.items){item.related=(item.related||[]).filter(id=>ids.has(id));if(item.relatedOut)item.relatedOut=item.relatedOut.filter(id=>ids.has(id));}
   const files=[];
   for(const f of snapshot.files){
    if(f.owners?.some(id=>!ids.has(id)))removedHashes.add(f.sha256);
    const owners=f.owners?.filter(id=>ids.has(id)),retain=f.owners?owners.length>0:ids.size>0;
    if(retain){files.push(f.owners?{...f,owners}:f);protectedHashes.add(f.sha256);if(!f.owners&&missing.length)legacyHashes.add(f.sha256);}
    else if(missing.length)removedHashes.add(f.sha256);
   }
   let replacement=null;
   if(missing.length&&ids.size){replacement={...snapshot,library,files,packageId:b.archive.packageId(library,files)};b.validate(replacement);}
   entries.push({meta:{...meta},snapshot,affected:missing.length>0,replacement});
  }
  const trash=remote.records.filter(m=>removedHashes.has(m.name)&&!protectedHashes.has(m.name));
  for(const meta of trash){
   const refs=entries.flatMap(e=>e.snapshot.files.filter(f=>f.sha256===meta.name));
   if(!this.contained(meta,remote.objects)||!HASH.test(meta.name)||!refs.length||refs.some(f=>Number(meta.size)!==f.bytes)||meta.sha256Checksum&&meta.sha256Checksum!==meta.name||!meta.sha256Checksum&&!meta.md5Checksum)throw Error('待清理附件位置或校验值异常，未执行清理');
  }
  await b.assertCurrent(plan,signal);d.check(signal,key);
  return {key,remote,entries,trash,documents:[...removed.values()],summary:{documents:removed.size,files:trash.length,bytes:trash.reduce((n,m)=>n+Number(m.size),0),snapshots:entries.filter(e=>e.affected).length,shared:[...removedHashes].filter(h=>protectedHashes.has(h)).length,legacy:legacyHashes.size,localEmpty:plan.collected.library.items.length===0}};
 }
 async restore(journal){
  const d=this.d,b=this.b;d.check(null,journal.key);
  if(journal.version!==1||journal.libraryId!==b.libraryId||!Array.isArray(journal.attempted))throw Error('清理恢复记录无效，请保留该记录');
  // Do not honor the cancelled transfer's signal: undo is a separate recovery step.
  const failed=[];
  for(const meta of [...journal.attempted].reverse())try{
   const current=await d.metadata(journal.key,meta.id);if(!current?.id||!this.contained(current,meta.parents[0])||current.name!==meta.name||current.md5Checksum!==meta.md5Checksum||current.sha256Checksum!==meta.sha256Checksum)throw Error('云端文件已改变');
   if(current.trashed){await d.request(journal.key,API+'files/'+d.id(meta.id)+'?fields=id,trashed',{method:'PATCH',json:{trashed:false}});if((await d.metadata(journal.key,meta.id))?.trashed)throw Error('恢复未完成');}
  }catch{failed.push(meta.id);}
  if(failed.length)throw Error('部分文件尚未恢复，请保持原备份账户，再次点击“立即同步”恢复上次清理');
  await b.io.unlink(this.journal());return {recovered:journal.attempted.length};
 }
 async recover(){const pending=await this.pending();if(!pending)return null;const release=await this.b.lock('cloud.lock');try{return await this.restore(pending);}finally{await release();}}
 async run(plan,approved,result,{signal,onProgress=()=>{}}={}){
  if(!approved.documents.length)return {documents:0,files:0};
  const b=this.b,d=this.d,key=approved.key;d.check(signal,key);const release=await b.lock('cloud.lock');let journal;
  try{
   if(await this.pending())throw Error('上次清理尚未恢复，请再次点击“立即同步”');
   await b.assertCurrent(plan,signal);let remote=await this.inventory(key,signal);
   if(remote.root?.id!==approved.remote.root?.id||result.cloudRoot!==remote.root?.id||remote.root.appProperties?.typoraLatest!==plan.packageId||remote.objects!==approved.remote.objects||remote.history!==approved.remote.history)throw stale();
   const old=new Map(approved.remote.snapshots.map(m=>[m.id,this.stamp(m)]));
   if(remote.snapshots.some(m=>old.has(m.id)?old.get(m.id)!==this.stamp(m):m.name!=='snapshot-'+plan.packageId+'.json')||[...old.keys()].some(id=>!remote.snapshots.some(m=>m.id===id)))throw stale();
   const allowed=new Map(remote.snapshots.map(m=>[m.id,this.stamp(m)])),sessions=await d.stateFile(b.libraryId,key),affected=approved.entries.filter(e=>e.affected);
   const retained=new Map(plan.files.map(f=>[f.sha256,f]));for(const e of approved.entries)for(const f of (e.affected?e.replacement?.files||[]:e.snapshot.files))retained.set(f.sha256,f);
   // Publish complete replacement histories before removing any old history.
   for(const entry of affected){if(!entry.replacement)continue;const s=entry.replacement,name='snapshot-'+s.packageId+'.json',file=b.path.join(b.root,'cleanup-prepared',name);
    await b.atomic(file,JSON.stringify(s));const fingerprint=await b.fingerprint(file,{signal});let meta=remote.snapshots.find(m=>m.name===name&&d.matches(m,fingerprint));
    if(!meta)meta=await d.upload(key,file,{name,parents:[remote.history]},fingerprint,sessions,{signal});allowed.set(meta.id,this.stamp(meta));
   }
   const trashed=new Set();
   const guard=async()=>{
    await b.assertCurrent(plan,signal);d.check(signal,key);const now=await this.inventory(key,signal);
    if(now.root?.id!==remote.root.id||now.objects!==remote.objects||now.history!==remote.history||now.root.appProperties?.typoraLatest!==plan.packageId)throw stale();
    const expected=[...allowed].filter(([id])=>!trashed.has(id));if(now.snapshots.length!==expected.length||now.snapshots.some(m=>allowed.get(m.id)!==this.stamp(m)||trashed.has(m.id)))throw stale();
    for(const f of retained.values())if(!now.records.some(m=>m.name===f.sha256&&Number(m.size)===f.bytes&&(m.sha256Checksum?m.sha256Checksum===f.sha256:!!m.md5Checksum)))throw Error('保留文献的云端附件发生变化，已停止清理');
   };
   await guard();
   journal={version:1,libraryId:b.libraryId,key,root:remote.root.id,createdAt:new Date().toISOString(),attempted:[]};await b.atomic(this.journal(),JSON.stringify(journal));
   const targets=[...affected.map(e=>e.meta),...approved.trash];
   for(let index=0;index<targets.length;index++){
    if(index%10===0||index===affected.length)await guard();const meta=targets[index];await b.assertCurrent(plan,signal);d.check(signal,key);
    const current=await d.metadata(key,meta.id,signal);if(!current?.id||this.stamp(current)!==this.stamp(meta))throw stale();
    // Persist intent first: even a lost successful PATCH response is recoverable.
    journal.attempted.push(meta);await b.atomic(this.journal(),JSON.stringify(journal));
    await d.request(key,API+'files/'+d.id(meta.id)+'?fields=id,trashed',{signal,method:'PATCH',json:{trashed:true}});
    if(!(await d.metadata(key,meta.id,signal))?.trashed)throw Error('云端文件未进入回收站');trashed.add(meta.id);
    onProgress('正在移入云端回收站 '+(index+1)+' / '+targets.length,'cleaning');
   }
   await guard();await b.io.unlink(this.journal());journal=null;
   return {...approved.summary,completedAt:new Date().toISOString()};
  }catch(e){if(journal)try{await this.restore(journal);}catch(recovery){throw Error(e.message+'；'+recovery.message);}throw e;
  }finally{await release();}
 }
}
module.exports=DriveCleanup;
