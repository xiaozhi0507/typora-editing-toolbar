'use strict';
const MarkdownIt=require('markdown-it');
// Resource discovery only: never render, execute HTML, or fetch URLs.
const parser=new MarkdownIt('commonmark',{html:true});
parser.validateLink=()=>true; // Keep file:/drive-letter links so the caller can reject them.
function mathEnd(text,start,open,close){
  let at=start+open.length;
  if(open==='$'&&(/\s/.test(text[at]||'')||text[at]==='$'))return -1;
  while((at=text.indexOf(close,at))!==-1){
    let slashes=0;for(let i=at-1;i>=0&&text[i]==='\\';i--)slashes++;
    if(!(slashes%2)&&(close!=='$'||(!/\s/.test(text[at-1]||'')&&text[at+1]!=='$'))){
      if(open==='$'&&/\n\s*\n/.test(text.slice(start,at)))return -1;
      return at+close.length;
    }
    at+=close.length;
  }
  return -1;
}
function delimiters(text,start){
  if(text.startsWith('$$',start))return ['$$','$$'];
  if(text[start]==='$')return ['$','$'];
  if(text.startsWith('\\(',start))return ['\\(','\\)'];
  if(text.startsWith('\\[',start))return ['\\[','\\]'];
  return null;
}
parser.inline.ruler.before('escape','resource_math',(state,silent)=>{
  const pair=delimiters(state.src,state.pos);if(!pair)return false;
  const end=mathEnd(state.src,state.pos,...pair);if(end<0||end>state.posMax)return false;
  if(!silent){const token=state.push('resource_math','',0);token.content=state.src.slice(state.pos,end);}
  state.pos=end;return true;
});
parser.block.ruler.before('fence','resource_math_block',(state,start,end,silent)=>{
  const at=state.bMarks[start]+state.tShift[start],pair=delimiters(state.src,at);
  if(!pair||pair[0]==='$'||pair[0]==='\\('||state.sCount[start]-state.blkIndent>=4)return false;
  const finish=mathEnd(state.src,at,...pair);if(finish<0||finish>state.eMarks[end-1])return false;
  let line=start;while(line<end&&state.eMarks[line]<finish)line++;
  if(state.src.slice(finish,state.eMarks[line]).trim())return false;
  if(silent)return true;
  const token=state.push('resource_math_block','',0);token.block=true;token.map=[start,line+1];
  state.line=line+1;return true;
},{alt:['paragraph','reference','blockquote','list']});
// Typora footnotes are prose, not CommonMark link-reference destinations.
// Keep their bodies so real images/links in a footnote are still discovered.
parser.block.ruler.before('reference','resource_footnote',(state,start,end,silent)=>{
  if(state.sCount[start]-state.blkIndent>=4)return false;
  const at=state.bMarks[start]+state.tShift[start];
  const marker=/^\[\^[^\]\s]+\]:[ \t]*/.exec(state.src.slice(at,state.eMarks[start]));
  if(!marker)return false;
  if(silent)return true;
  let next=start+1,body=state.src.slice(at+marker[0].length,state.eMarks[start])+'\n';
  while(next<end){
    if(state.isEmpty(next)){body+='\n';next++;continue;}
    if(state.sCount[next]<state.blkIndent+4)break;
    body+=state.getLines(next,next+1,state.blkIndent+4,true);next++;
  }
  const token=state.push('resource_footnote','',0);token.block=true;token.content=body;token.map=[start,next];
  state.line=next;return true;
},{alt:['paragraph','reference']});
module.exports=function links(markdown){
  const result=[],env={};
  const walk=tokens=>{for(const t of tokens){
    if(t.type==='link_open')result.push(t.attrGet('href'));
    if(t.type==='image')result.push(t.attrGet('src'));
    if(t.type==='resource_footnote')walk(parser.parse(t.content,env));
    if(t.type==='html_block'||t.type==='html_inline'){
      for(const m of t.content.matchAll(/<(?:img|source|video|audio)\b[^>]*?\bsrc\s*=\s*['"]([^'"]+)['"]/gi))result.push(m[1].replace(/&amp;/g,'&'));
    }
    if(t.children)walk(t.children);
  }};
  walk(parser.parse(String(markdown),env));
  // Preserve the existing behavior of including reference definitions, even unused ones.
  for(const ref of Object.values(env.references||{}))result.push(ref.href);
  return [...new Set(result.filter(Boolean))];
};
