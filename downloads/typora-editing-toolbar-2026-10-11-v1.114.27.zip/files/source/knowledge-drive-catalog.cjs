'use strict';
const Cleanup=require('./knowledge-drive-cleanup.cjs');
// List every completed backup, including documents absent from the latest one.
module.exports=async function catalogAll(d,b,{signal,onProgress=()=>{}}={}){
 const key=d.account()?.key;if(!key)throw Error('请先授权 Google Drive 备份');
 const cleaner=new Cleanup(d,b);if(await cleaner.pending())throw Error('上次清理尚未恢复，请在同步概览点击“立即同步”恢复');
 onProgress('正在读取全部云端备份…','downloading');const remote=await cleaner.inventory(key,signal);
 if(!remote.root)return {key,rows:[],snapshots:[],url:'',root:null};
 const snapshots=[],rows=new Map(),pointer=remote.root.appProperties?.typoraLatest;
 const metas=[...remote.snapshots].sort((a,c)=>Number(c.name==='snapshot-'+pointer+'.json')-Number(a.name==='snapshot-'+pointer+'.json')||String(c.createdTime||'').localeCompare(String(a.createdTime||''))||a.id.localeCompare(c.id));
 const packages=new Set();
 for(const [index,meta]of metas.entries()){
  d.check(signal,key);if(Number(meta.size)>b.archive.limits.json)throw Error('云端清单过大');
  onProgress('正在读取备份 '+(index+1)+' / '+metas.length,'downloading');
  const file=b.path.join(b.root,'downloads',d.id(meta.id)+'-'+meta.name);
  if(!await b.exists(file)||!d.matches(meta,await b.fingerprint(file,{signal})))await d.download(b,key,meta,file,{signal});
  const snapshot=b.validate(await b.json(file));if(meta.name!=='snapshot-'+snapshot.packageId+'.json')throw Error('云端备份清单名称不符');
  if(packages.has(snapshot.packageId))continue;packages.add(snapshot.packageId);
  const info={...snapshot,latest:snapshot.packageId===pointer};snapshots.push(info);
  const items=new Map(snapshot.library.items.map(i=>[i.id,i]));
  for(const f of snapshot.files){
   const object=remote.records.find(m=>m.name===f.sha256&&Number(m.size)===f.bytes&&(m.sha256Checksum?m.sha256Checksum===f.sha256:!!m.md5Checksum));
   if(!object)throw Error('云端备份不完整，缺少文件：'+f.path);
   const id=f.path+'\n'+f.sha256,copy={packageId:snapshot.packageId,path:f.path};
   let row=rows.get(id);if(!row){row={...f,key:id,remote:object,copies:[],titles:[],createdAt:snapshot.createdAt};rows.set(id,row);}
   row.copies.push(copy);
   const owners=f.owners?f.owners.map(id=>items.get(id)):snapshot.library.items.filter(i=>i.files.some(ref=>ref.linkType!=='url'&&ref.path===f.path));
   for(const item of owners)if(item?.title&&!row.titles.includes(item.title))row.titles.push(item.title);
  }
 }
 d.check(signal,key);return {key,root:remote.root.id,url:'https://drive.google.com/drive/folders/'+remote.root.id,snapshots,rows:[...rows.values()]};
};
