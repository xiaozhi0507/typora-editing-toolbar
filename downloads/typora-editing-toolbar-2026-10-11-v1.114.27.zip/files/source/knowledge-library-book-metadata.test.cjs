const test=require('node:test'),assert=require('node:assert/strict');
const Metadata=require('./knowledge-library-book-metadata.cjs'),ISBN=require('./knowledge-library-isbn.cjs');
const parse=(text,name='前置资料.md')=>Metadata.parse([{name,path:'00 前置资料/'+name,text}],ISBN.normalize);
test('inline OCR CIP heading, publication and ISBN identify the book rather than production credits',()=>{
 const r=parse('版权所有，侵权必究。图书在版编目 *(CIP)* 数据机器学习/周志华著. --北京：清华大学出版社，2016ISBN 978-7-302-42328-7I. 机…中国版本图书馆CIP数据核字（2015）第287090号\n\n责任编辑：薛慧\n封面设计：何凤霞\n网址：http://www.tup.com.cn\n版次：2016年1月第1版');
 assert.equal(r.fields.title,'机器学习');assert.equal(r.fields.author,'周志华');assert.equal(r.fields.isbn,'9787302423287');assert.equal(r.fields.publisher,'清华大学出版社');assert.equal(r.fields.date,'2016');assert.equal(r.fields.year,'2016');assert.equal(r.fields.edition,'2016年1月第1版');assert.equal(r.isbnCandidates[0].score,110);assert.equal(r.evidence.title,'00 前置资料/前置资料.md');
});
test('multiline CIP preserves translated authors, translator, edition and original ISBN ranking',()=>{
 const r=parse('图书在版编目（CIP）数据\n\n示例教材：原书第2版 / (美)甲 (Alice Example)，(美)乙 (Bob Example) 著；王明译. -- 北京：示例出版社，2020.6\nISBN 978-7-302-42328-7\n中国版本图书馆CIP数据核字（2020）第123号\nEnglish language edition ISBN 978-0-262-03384-8','版权.md');
 assert.equal(r.fields.title,'示例教材（原书第2版）');assert.equal(r.fields.author,'Alice Example；Bob Example');assert.equal(r.fields.translator,'王明');assert.equal(r.fields.date,'2020-06');assert.equal(r.fields.isbn,'9787302423287');
});
test('single-line Chinese author followed by full stop and OCR dash are supported',()=>{
 const r=parse('图书在版编目（CIP）数据\n统计学习方法/李航著.一2版.一北京：清华大学出版社，2019（2019.6重印） ISBN 978-7-302-51727-6\n中国版本图书馆CIP数据核字（2018）第267477号');
 assert.equal(r.fields.title,'统计学习方法');assert.equal(r.fields.author,'李航');assert.equal(r.fields.place,'北京');assert.equal(r.fields.publisher,'清华大学出版社');assert.equal(r.fields.date,'2019');assert.equal(r.fields.isbn,'9787302517276');
});
test('empty or malformed CIP does not consume production credits or URLs as a book title',()=>{
 for(const text of ['图书在版编目（CIP）数据\n\n责任编辑：张三\n封面设计：李四\n网址：http://example.com','图书在版编目（CIP）数据\nhttp://example.com\n责任编辑：张三','中国版本图书馆CIP数据核字（2015）第287090号\n责任编辑：张三'])assert.equal(parse(text).fields.title,undefined);
});
test('normal title pages and explicit metadata retain precedence',()=>{
 const r=parse('# 书名页\n书名：明确书名\n作者：明确作者\n出版社：明确出版社\n出版日期：2022-01\nISBN 978-7-302-42328-7\n图书在版编目（CIP）数据\n另一书名/其他作者著. -- 北京：其他出版社，2020','书名页.md');
 assert.equal(r.fields.title,'明确书名');assert.equal(r.fields.author,'明确作者');assert.equal(r.fields.date,'2022-01');assert.equal(r.fields.isbn,'9787302423287');
});
test('ISBN check digits and reference-only ISBNs remain rejected',()=>{
 assert.equal(parse('图书在版编目（CIP）数据机器学习/周志华著. --北京：清华大学出版社，2016ISBN 978-7-302-42328-8').fields.isbn,undefined);
 assert.equal(parse('参考文献中引用 ISBN 978-7-302-42328-7','参考文献.md').fields.isbn,undefined);
 assert.equal(parse('Authorized translation of the English language edition ISBN 978-0-262-03384-8','版权.md').fields.isbn,undefined);
});
