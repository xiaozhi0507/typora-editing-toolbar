'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os');
const Store=require('./knowledge-library-store.cjs'),Managed=require('./knowledge-library-managed.cjs'),Book=require('./knowledge-library-book.cjs'),Archive=require('./knowledge-library-archive.cjs'),Backup=require('./knowledge-library-backup.cjs'),Zip=require('fflate');
async function fixture(t){
 const root=await fs.mkdtemp(path.join(os.tmpdir(),'kb-book-links-'));t.after(()=>fs.rm(root,{recursive:true,force:true}));
 const source=path.join(root,'书籍'),store=new Store(path.join(root,'library'));await store.open();
 await fs.mkdir(source+'/00 前置资料',{recursive:true});await fs.mkdir(source+'/代码/子目录',{recursive:true});
 await fs.writeFile(source+'/目录.md','# 示例教材\n[正文](正文.md)\n[代码](代码/)');
 await fs.writeFile(source+'/00 前置资料/版权.md','书名：示例教材\n作者：示例作者');
 await fs.writeFile(source+'/正文.md','# 正文\n说明[^note]\n\n[^note]: 这句话不是文件。\n\n[全书](目录.md)\n[代码](代码)');
 await fs.writeFile(source+'/代码/README.md','[整个目录](./)\n[上级](../)\n[子目录](子目录/)');
 await fs.writeFile(source+'/代码/子目录/例子.ipynb',JSON.stringify({nbformat:4,cells:[]}));
 const book=new Book(store),managed=new Managed(store);return {root,source,store,book,managed};
}
test('books with folder links and footnotes import completely without changing original files',async t=>{
 const x=await fixture(t),detected=await x.book.inspect(x.source);assert.ok(detected);
 const r=await x.book.importFolder(x.source),item=r.data.items[0];assert.equal(r.files,5);assert.equal(r.chapters,4);assert.equal(item.title,'示例教材');
 const owned=path.join(x.managed.storage,item.book.storageKey),manifest=JSON.parse(await fs.readFile(owned+'/.managed.json','utf8'));
 for(const file of manifest.files)assert.deepEqual(await fs.readFile(path.join(owned,file.path)),await fs.readFile(file.source));
 const again=await x.book.importFolder(x.source);assert.equal(again.reused,true);assert.equal(again.data.items.length,1);
});
test('folder back-links and repeated links are deduplicated for ordinary managed Markdown too',async t=>{
 const x=await fixture(t),plan=await x.managed.plan(x.store.fileRef(x.source+'/目录.md'));
 assert.equal(plan.files.length,5);assert.equal(new Set(plan.files.map(f=>f.file)).size,5);
});
test('book folder links outside the selected root are still rejected',async t=>{
 const x=await fixture(t);await fs.mkdir(x.root+'/outside');await fs.writeFile(x.source+'/正文.md','[outside](../outside/)');
 await assert.rejects(x.book.importFolder(x.source),/所选文件夹之外/);assert.equal((await x.store.read()).data.items.length,0);
});
test('missing real links in footnotes still stop the import with no partial item',async t=>{
 const x=await fixture(t);await fs.writeFile(x.source+'/正文.md','正文[^x]\n\n[^x]: 看图 ![missing](missing.png)');
 await assert.rejects(x.book.importFolder(x.source),/ENOENT/);assert.equal((await x.store.read()).data.items.length,0);
});
test('folder links never traverse junctions and cancellation stays atomic',async t=>{
 const x=await fixture(t);await fs.symlink(x.store.root,x.source+'/代码/junction','junction');
 await assert.rejects(x.book.importFolder(x.source),/链接/);assert.equal((await x.store.read()).data.items.length,0);
 const controller=new AbortController();controller.abort();await assert.rejects(x.book.importFolder(x.source,{signal:controller.signal}),{name:'AbortError'});
});
test('imported folder links and footnote resources survive backup and ZIP restore',async t=>{
 const x=await fixture(t);await x.book.importFolder(x.source);const destination=x.root+'/backups';await fs.mkdir(destination);
 const backup=new Backup(x.store,{Managed,Archive,Zip,destination}),plan=await backup.plan();assert.equal(plan.files.length,5);await backup.run(plan);
 const archive=new Archive(x.store,{Managed,Zip}),out=await archive.export(x.root),target=new Store(x.root+'/restored');await target.open();
 const restored=await new Archive(target,{Managed,Zip}).import(out.path);assert.equal(restored.data.items[0].title,'示例教材');
 const entry=restored.data.items[0].files.find(f=>f.id===restored.data.items[0].defaultFile),roundtrip=await new Managed(target).plan(entry);
 assert.equal(roundtrip.files.length,5);assert.ok(roundtrip.files.some(f=>f.file.endsWith('例子.ipynb')));
});
