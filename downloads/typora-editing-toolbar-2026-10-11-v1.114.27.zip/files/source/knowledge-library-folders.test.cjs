'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os');
const Store=require('./knowledge-library-store.cjs'),Managed=require('./knowledge-library-managed.cjs'),Archive=require('./knowledge-library-archive.cjs'),Backup=require('./knowledge-library-backup.cjs'),Purge=require('./knowledge-library-purge.cjs'),Zip=require('fflate'),restore=require('./knowledge-drive-restore.cjs');
async function fixture(t){
 const root=await fs.mkdtemp(path.join(os.tmpdir(),'kb-folders-'));t.after(()=>fs.rm(root,{recursive:true,force:true}));
 const store=new Store(path.join(root,'library')),base=(await store.open()).data,source=path.join(root,'代码');await fs.mkdir(source+'/nested/empty',{recursive:true});
 await fs.writeFile(source+'/README.md','# code\n[not bundled](../missing.md)\n![missing](missing.png)');await fs.writeFile(source+'/.gitignore','*.pyc\n');await fs.writeFile(source+'/nested/例子.py','print("sample")\n');await fs.writeFile(source+'/nested/实验.ipynb',JSON.stringify({nbformat:4,nbformat_minor:5,metadata:{},cells:[]}));await fs.writeFile(source+'/nested/data.bin',Buffer.from([0,255,8]));
 await store.commit(base,{...base,items:[{id:'book',type:'book',title:'机器学习',status:'reading',files:[],tags:['tag'],collections:[],related:[],rating:4}]});
 const managed=new Managed(store),folders=managed.folders();return {root,store,source,managed,folders,archive:s=>new Archive(s,{Managed,Zip})};
}
test('folder import preserves names, nested bytes and originals without parsing README links',async t=>{
 const x=await fixture(t),result=await x.folders.attach('book',x.source),ref=result.ref,{root}=await x.folders.descriptor(ref);
 assert.equal(ref.name,'代码');assert.equal(ref.attachmentType,'folder');assert.equal(result.data.items[0].status,'reading');assert.equal(result.data.items[0].rating,4);
 for(const name of ['README.md','.gitignore','nested/例子.py','nested/实验.ipynb','nested/data.bin'])assert.deepEqual(await fs.readFile(path.join(root,name)),await fs.readFile(path.join(x.source,name)));
 assert.ok((await fs.stat(root+'/nested/empty')).isDirectory());assert.equal((await x.folders.list(ref)).length,3);
 const again=await x.folders.attach('book',x.source);assert.equal(again.reused,true);assert.equal(again.data.items[0].files.length,1);assert.equal((await fs.readdir(x.managed.storage)).length,1);
 await fs.writeFile(root+'/nested/new.py','new');assert.ok((await x.managed.plan(ref)).files.some(f=>f.relative==='nested/new.py'));
});
test('cancel, copy failure and concurrent item mutation leave no orphan folder',async t=>{
 for(const mode of ['cancel','copy','concurrent']){
  const x=await fixture(t),controller=new AbortController();if(mode==='copy')x.managed.io={...x.store.io,copyFile:async()=>{throw Error('copy failed');}};
  const service=x.managed.folders();await assert.rejects(service.attach('book',x.source,{signal:controller.signal,onProgress:async(text,phase)=>{if(phase==='copying'&&mode==='cancel')controller.abort();if(phase==='saving'&&mode==='concurrent'){const commit=x.store.commit.bind(x.store);x.store.commit=async(base,next,verify)=>{x.store.commit=commit;const live=(await x.store.read()).data;await commit(live,{...live,items:live.items.map(i=>({...i,title:'用户修改'}))});return commit(base,next,verify);};}}}));
  assert.deepEqual(await fs.readdir(x.managed.storage),[]);assert.equal((await x.store.read()).data.items[0].files.length,0);
 }
});
test('folder traversal, linked files and attaching library itself are rejected',async t=>{
 const x=await fixture(t),{ref}=await x.folders.attach('book',x.source);
 for(const relative of ['../library.json','/outside','C:/outside','nested/../../README.md','nested\\例子.py'])await assert.rejects(x.folders.child(ref,relative));
 await assert.rejects(x.folders.prepare(x.store.root),/知识库之外/);
 const linked=x.source+'/linked';await fs.symlink(x.store.root,linked,'junction');await assert.rejects(x.folders.prepare(x.source),/链接/);
});
test('ZIP export/import carries folder tree, empty folders and file types',async t=>{
 const x=await fixture(t);await x.folders.attach('book',x.source);const out=await x.archive(x.store).export(x.root),target=new Store(x.root+'/restored');await target.open();
 const result=await x.archive(target).import(out.path),ref=result.data.items[0].files[0],folders=new Managed(target).folders(),{root}=await folders.descriptor(ref);
 assert.equal(ref.attachmentType,'folder');assert.equal(ref.name,'代码');assert.ok((await fs.stat(root+'/nested/empty')).isDirectory());
 assert.deepEqual(await fs.readFile(root+'/nested/data.bin'),Buffer.from([0,255,8]));assert.equal((await folders.list(ref,'nested')).length,4);
 assert.equal((await x.archive(target).import(out.path)).added,0);
});
test('empty folder attachments roundtrip as folders',async t=>{
 const x=await fixture(t),empty=x.root+'/empty';await fs.mkdir(empty);await x.folders.attach('book',empty);const target=new Store(x.root+'/restored');await target.open();const out=await x.archive(x.store).export(x.root),result=await x.archive(target).import(out.path);assert.deepEqual(await new Managed(target).folders().list(result.data.items[0].files[0]),[]);
});
test('binary ZIP payloads and arbitrary PK signatures survive portable export',async t=>{
 const x=await fixture(t),bytes=Zip.zipSync({'[Content_Types].xml':new TextEncoder().encode('<xml/>'),'xl/workbook.xml':new TextEncoder().encode('<workbook/>')},{level:0});
 await fs.writeFile(x.source+'/data.xlsx',bytes);await fs.writeFile(x.source+'/signatures.bin',Buffer.from('PK\x03\x04PK\x07\x08PK\x01\x02'));await x.folders.attach('book',x.source);const out=await x.archive(x.store).export(x.root),target=new Store(x.root+'/binary-restored');await target.open();const result=await x.archive(target).import(out.path),{root}=await new Managed(target).folders().descriptor(result.data.items[0].files[0]);assert.deepEqual(await fs.readFile(root+'/data.xlsx'),Buffer.from(bytes));assert.deepEqual(await fs.readFile(root+'/signatures.bin'),await fs.readFile(x.source+'/signatures.bin'));
});
test('backup and cloud restore preserve complete folder metadata and detect code edits',async t=>{
 const x=await fixture(t),{ref}=await x.folders.attach('book',x.source),destination=x.root+'/backups';await fs.mkdir(destination);
 const make=store=>new Backup(store,{Managed,Archive,Zip,destination}),b=make(x.store),plan=await b.plan();assert.equal(plan.files.length,6);await b.run(plan);const snapshot=await b.latest();
 const target=new Store(x.root+'/downloaded');await target.open();const dest=make(target),catalog={key:'test-account',snapshots:[snapshot],rows:snapshot.files.map(f=>({...f,remote:f}))};
 const d={check:signal=>{if(signal?.aborted)throw Error('cancel');},download:async(b,key,remote,file)=>{await b.mkdir(path.dirname(file));await fs.copyFile(x.root+'/backups/Typora知识库备份/'+bSourceId+'/objects/'+remote.sha256,file);}};const bSourceId=b.libraryId;
 await restore(d,dest,catalog);const restored=(await target.read()).data.items[0].files[0],folders=new Managed(target).folders();assert.equal(restored.attachmentType,'folder');assert.equal(restored.name,'代码');assert.equal(restored.sourcePath,undefined);
 const local=await folders.child(restored,'nested/例子.py');assert.equal(await fs.readFile(local.target,'utf8'),'print("sample")\n');assert.ok((await fs.stat(path.join(path.dirname(target.resolveFile(restored)),'nested/empty'))).isDirectory());
 await fs.writeFile(local.target,'local edit');await restore(d,dest,catalog);assert.equal(await fs.readFile(local.target,'utf8'),'local edit');
 const managedRoot=(await x.folders.descriptor(ref)).root;await fs.writeFile(managedRoot+'/nested/例子.py','changed');assert.equal((await b.plan()).summary.modified,1);
});
test('purge protects folder contents shared by another paper',async t=>{
 const x=await fixture(t),{ref}=await x.folders.attach('book',x.source),base=(await x.store.read()).data,shared={...base.items[0],id:'other',files:[ref],defaultFile:ref.id};
 const live={...base,items:[{...base.items[0],deleted:true},shared]},next={...live,items:[shared]},purge=new Purge(x.store,{Managed});const plan=await purge.plan(live,next,new Set(['book']));assert.deepEqual(plan.paths,[]);assert.equal(plan.shared,1);
});
