class EditingToolbarAI {
  static welcomeQuotes = [
    ["纸上得来终觉浅，绝知此事要躬行。","冬夜读书示子聿","陆游"],
    ["古人学问无遗力，少壮工夫老始成。","冬夜读书示子聿","陆游"],
    ["问渠那得清如许？为有源头活水来。","观书有感·其一","朱熹"],
    ["半亩方塘一鉴开，天光云影共徘徊。","观书有感·其一","朱熹"],
    ["欲穷千里目，更上一层楼。","登鹳雀楼","王之涣"],
    ["不识庐山真面目，只缘身在此山中。","题西林壁","苏轼"],
    ["山重水复疑无路，柳暗花明又一村。","游山西村","陆游"],
    ["长风破浪会有时，直挂云帆济沧海。","行路难·其一","李白"],
    ["会当凌绝顶，一览众山小。","望岳","杜甫"],
    ["千磨万击还坚劲，任尔东西南北风。","竹石","郑燮"],
    ["不积跬步，无以至千里；不积小流，无以成江海。","荀子·劝学","荀子"],
    ["锲而不舍，金石可镂。","荀子·劝学","荀子"],
    ["学而不思则罔，思而不学则殆。","论语·为政","孔子"],
    ["温故而知新，可以为师矣。","论语·为政","孔子"],
    ["知之者不如好之者，好之者不如乐之者。","论语·雍也","孔子"],
    ["博学之，审问之，慎思之，明辨之，笃行之。","礼记·中庸",""],
    ["举头望明月，低头思故乡。","静夜思","李白"],
    ["飞流直下三千尺，疑是银河落九天。","望庐山瀑布","李白"],
    ["两岸猿声啼不住，轻舟已过万重山。","早发白帝城","李白"],
    ["桃花潭水深千尺，不及汪伦送我情。","赠汪伦","李白"],
    ["孤帆远影碧空尽，唯见长江天际流。","黄鹤楼送孟浩然之广陵","李白"],
    ["我寄愁心与明月，随君直到夜郎西。","闻王昌龄左迁龙标遥有此寄","李白"],
    ["两岸青山相对出，孤帆一片日边来。","望天门山","李白"],
    ["浮云游子意，落日故人情。","送友人","李白"],
    ["相看两不厌，只有敬亭山。","独坐敬亭山","李白"],
    ["此夜曲中闻折柳，何人不起故园情。","春夜洛城闻笛","李白"],
    ["天生我材必有用，千金散尽还复来。","将进酒","李白"],
    ["举杯邀明月，对影成三人。","月下独酌·其一","李白"],
    ["国破山河在，城春草木深。","春望","杜甫"],
    ["随风潜入夜，润物细无声。","春夜喜雨","杜甫"],
    ["两个黄鹂鸣翠柳，一行白鹭上青天。","绝句四首·其三","杜甫"],
    ["迟日江山丽，春风花草香。","绝句二首·其一","杜甫"],
    ["留连戏蝶时时舞，自在娇莺恰恰啼。","江畔独步寻花·其六","杜甫"],
    ["白日放歌须纵酒，青春作伴好还乡。","闻官军收河南河北","杜甫"],
    ["此曲只应天上有，人间能得几回闻。","赠花卿","杜甫"],
    ["正是江南好风景，落花时节又逢君。","江南逢李龟年","杜甫"],
    ["萧萧梧叶送寒声，江上秋风动客情。","夜书所见","叶绍翁"],
    ["独在异乡为异客，每逢佳节倍思亲。","九月九日忆山东兄弟","王维"],
    ["明月松间照，清泉石上流。","山居秋暝","王维"],
    ["行到水穷处，坐看云起时。","终南别业","王维"],
    ["劝君更尽一杯酒，西出阳关无故人。","送元二使安西","王维"],
    ["愿君多采撷，此物最相思。","相思","王维"],
    ["返景入深林，复照青苔上。","鹿柴","王维"],
    ["深林人不知，明月来相照。","竹里馆","王维"],
    ["大漠孤烟直，长河落日圆。","使至塞上","王维"],
    ["夜来风雨声，花落知多少。","春晓","孟浩然"],
    ["野旷天低树，江清月近人。","宿建德江","孟浩然"],
    ["绿树村边合，青山郭外斜。","过故人庄","孟浩然"],
    ["气蒸云梦泽，波撼岳阳城。","望洞庭湖赠张丞相","孟浩然"],
    ["不知细叶谁裁出，二月春风似剪刀。","咏柳","贺知章"],
    ["少小离家老大回，乡音无改鬓毛衰。","回乡偶书·其一","贺知章"],
    ["羌笛何须怨杨柳，春风不度玉门关。","凉州词·其一","王之涣"],
    ["葡萄美酒夜光杯，欲饮琵琶马上催。","凉州词·其一","王翰"],
    ["但使龙城飞将在，不教胡马度阴山。","出塞·其一","王昌龄"],
    ["黄沙百战穿金甲，不破楼兰终不还。","从军行·其四","王昌龄"],
    ["洛阳亲友如相问，一片冰心在玉壶。","芙蓉楼送辛渐","王昌龄"],
    ["莫愁前路无知己，天下谁人不识君。","别董大·其一","高适"],
    ["忽如一夜春风来，千树万树梨花开。","白雪歌送武判官归京","岑参"],
    ["马上相逢无纸笔，凭君传语报平安。","逢入京使","岑参"],
    ["姑苏城外寒山寺，夜半钟声到客船。","枫桥夜泊","张继"],
    ["春潮带雨晚来急，野渡无人舟自横。","滁州西涧","韦应物"],
    ["谁言寸草心，报得三春晖。","游子吟","孟郊"],
    ["天街小雨润如酥，草色遥看近却无。","早春呈水部张十八员外·其一","韩愈"],
    ["孤舟蓑笠翁，独钓寒江雪。","江雪","柳宗元"],
    ["春风得意马蹄疾，一日看尽长安花。","登科后","孟郊"],
    ["千淘万漉虽辛苦，吹尽狂沙始到金。","浪淘沙·其八","刘禹锡"],
    ["沉舟侧畔千帆过，病树前头万木春。","酬乐天扬州初逢席上见赠","刘禹锡"],
    ["自古逢秋悲寂寥，我言秋日胜春朝。","秋词·其一","刘禹锡"],
    ["湖光秋月两相和，潭面无风镜未磨。","望洞庭","刘禹锡"],
    ["旧时王谢堂前燕，飞入寻常百姓家。","乌衣巷","刘禹锡"],
    ["野火烧不尽，春风吹又生。","赋得古原草送别","白居易"],
    ["乱花渐欲迷人眼，浅草才能没马蹄。","钱塘湖春行","白居易"],
    ["日出江花红胜火，春来江水绿如蓝。","忆江南·其一","白居易"],
    ["可怜九月初三夜，露似真珠月似弓。","暮江吟","白居易"],
    ["晚来天欲雪，能饮一杯无？","问刘十九","白居易"],
    ["人间四月芳菲尽，山寺桃花始盛开。","大林寺桃花","白居易"],
    ["停车坐爱枫林晚，霜叶红于二月花。","山行","杜牧"],
    ["千里莺啼绿映红，水村山郭酒旗风。","江南春","杜牧"],
    ["借问酒家何处有？牧童遥指杏花村。","清明","杜牧"],
    ["烟笼寒水月笼沙，夜泊秦淮近酒家。","泊秦淮","杜牧"],
    ["银烛秋光冷画屏，轻罗小扇扑流萤。","秋夕","杜牧"],
    ["何当共剪西窗烛，却话巴山夜雨时。","夜雨寄北","李商隐"],
    ["夕阳无限好，只是近黄昏。","乐游原","李商隐"],
    ["沧海月明珠有泪，蓝田日暖玉生烟。","锦瑟","李商隐"],
    ["春蚕到死丝方尽，蜡炬成灰泪始干。","无题·相见时难别亦难","李商隐"],
    ["嫦娥应悔偷灵药，碧海青天夜夜心。","嫦娥","李商隐"],
    ["海上生明月，天涯共此时。","望月怀远","张九龄"],
    ["海内存知己，天涯若比邻。","送杜少府之任蜀州","王勃"],
    ["白毛浮绿水，红掌拨清波。","咏鹅","骆宾王"],
    ["念天地之悠悠，独怆然而涕下。","登幽州台歌","陈子昂"],
    ["春江潮水连海平，海上明月共潮生。","春江花月夜","张若虚"],
    ["春色满园关不住，一枝红杏出墙来。","游园不值","叶绍翁"],
    ["接天莲叶无穷碧，映日荷花别样红。","晓出净慈寺送林子方","杨万里"],
    ["小荷才露尖尖角，早有蜻蜓立上头。","小池","杨万里"],
    ["欲把西湖比西子，淡妆浓抹总相宜。","饮湖上初晴后雨·其二","苏轼"],
    ["竹外桃花三两枝，春江水暖鸭先知。","惠崇春江晚景·其一","苏轼"],
    ["但愿人长久，千里共婵娟。","水调歌头·明月几时有","苏轼"],
    ["零落成泥碾作尘，只有香如故。","卜算子·咏梅","陆游"],
    ["众里寻他千百度，蓦然回首，那人却在，灯火阑珊处。","青玉案·元夕","辛弃疾"],
    ["稻花香里说丰年，听取蛙声一片。","西江月·夜行黄沙道中","辛弃疾"],
    ...ETAIWelcomeExtraQuotes,
  ];
  refreshWelcomeQuote(resetIdle = true) {
    if (resetIdle) this.welcomeMotion?.cancel();
    const text = this.empty?.querySelector?.('.et-ai-welcome-quote');
    const source = this.empty?.querySelector?.('.et-ai-welcome-source');
    if (!text || !source) return;
    const historyKey = 'et-ai-welcome-quote-v1';
    let previous = this.welcomeQuote;
    if (!previous) { try { const saved = localStorage.getItem(historyKey); if (saved !== null) previous = EditingToolbarAI.welcomeQuotes[Number(saved)]; } catch {} }
    const quotes = EditingToolbarAI.welcomeQuotes.filter(quote => quote !== previous);
    this.welcomeQuote = quotes[Math.floor(Math.random() * quotes.length)];
    try { localStorage.setItem(historyKey, String(EditingToolbarAI.welcomeQuotes.indexOf(this.welcomeQuote))); } catch {}
    const [words, work, author] = this.welcomeQuote;
    text.textContent = words;
    source.textContent = '--《' + work + '》' + (author ? ' · ' + author : '');
    if (resetIdle) this.welcomeMotion?.arm();
  }
  constructor(toolbar) {
    this.toolbar = toolbar; this.client = new ETAIClient(reqnode); this.configKey = 'et-ai-assistant-v1';
    this.config = this.load(); this.keys = new Map(); this.turns = []; this.layoutMode = this.config.layout || 'dock';
    this.webChat = new EditingToolbarAIWebChat(this);
    this.promptsManager = new EditingToolbarPromptManager(this);
    this.settingsUI = new EditingToolbarAISettings(this);this.chatgptUI=new EditingToolbarAIChatGPT(this);
    this.pythonUI=new EditingToolbarAIPythonSettings(this);
    this.composerUI = new EditingToolbarAIComposer(this);this.skillsUI=new EditingToolbarAISkills(this);this.pluginsUI=new EditingToolbarAIPlugins(this);
    this.editUI = new EditingToolbarAIDocumentEdit(this);this.webUI=new EditingToolbarAIWeb(this);this.shellUI=new EditingToolbarAIShell(this);this.referencesUI=new EditingToolbarAIReferences(this);this.codeUI=new EditingToolbarAICodeEdit(this);
    this.paperTranslation=new EditingToolbarAIPaperTranslation(this);
    this.attachments = new EditingToolbarAIAttachments(this);
    this.imagesUI = new EditingToolbarAIImages(this);
    this.conversations = new EditingToolbarAIConversations(this);this.queue=new EditingToolbarAIMessageQueue(this);
    this.selectionUI = new EditingToolbarAISelection(this);this.contextUI=new EditingToolbarAIContext(this);
    window.addEventListener('storage',e=>{if(e.key===this.configKey+':last-model'&&this.model&&!this.busy)this.composerUI.refreshModels();});
    document.addEventListener('keydown', e => { if (e.ctrlKey && e.altKey && e.code === 'KeyG') { e.preventDefault(); e.stopPropagation(); this.toggle(); } }, true);
    window.addEventListener('resize', () => { this.motion?.finish(true); this.layout(); });
    window.addEventListener('unload', () => { this.controller?.abort(); for(const turn of this.turns)EditingToolbarAITiming.finish(turn); clearInterval(this.documentTimer); });
  }
  load() {
    try { const saved = JSON.parse(localStorage.getItem(this.configKey)); if (Array.isArray(saved?.profiles)) return saved; } catch {}
    return { version: 1, profiles: [], active: '', width: 420, layout: 'dock' };
  }
  rememberedModel() {
    // Only an explicit choice/send writes this key. Background settings and older
    // windows must not replace the last chosen model with their stale config.
    try { const saved=JSON.parse(localStorage.getItem(this.configKey+':last-model'));const p=this.modelProfiles().find(p=>p.id===saved?.id&&p.model===saved.model);
      if(p){this.config.active=p.id;if(saved.effort!=null&&p.authType!=='chatgpt-web')p.reasoningEffort=ETAIClient.effortValue({...p,reasoningEffort:saved.effort});return p;}
    } catch {}
  }
  rememberModel(p) { if(p)localStorage.setItem(this.configKey+':last-model',JSON.stringify({id:p.id,model:p.model,...(p.authType==='chatgpt-web'?{}:{effort:ETAIClient.effortValue(p)})})); }
  persist() { this.rememberedModel();localStorage.setItem(this.configKey, JSON.stringify(this.config)); }
  profile() { return this.rememberedModel() || this.modelProfiles().find(p => p.id === this.config.active) || this.config.profiles[0]; }
  modelProfiles(){return [...this.config.profiles.filter(p=>p.authType!=='chatgpt'||!/^gpt[- ]?5\.5(?:$|[- ])/i.test(p.model)),...(this.webChat?[this.webChat.profile]:[])];}
  selectModel(choice){
    const p=this.modelProfiles().find(p=>p.id===choice.id&&p.model===choice.model);if(!p||this.busy)return;
    if(p.authType!=='chatgpt-web'&&this.attachments?.selected.some(f=>f.kind==='webfile')){this.notice('请先移除 GPT 网页附件，再切换助手模型',true);return;}
    if((p.authType==='chatgpt-web')!==(this.profile()?.authType==='chatgpt-web')&&this.turns.length&&!this.newConversation())return;
    if(this.attachments)this.attachments.catalog=null;
    if(p.authType==='chatgpt-web'&&this.editUI)this.editUI.enabled=false;
    this.config.active=p.id;this.rememberModel(p);this.persist();return p;
  }
  file() { return String(window.File?.bundle?.filePath || 'untitled:' + File.bundle?.untitledId); }
  source() { if (File.isFileLoading?.()) throw Error('文档正在加载，请稍后重试'); return String(File.editor.sourceView?.inSourceMode ? File.editor.sourceView.cm.getValue() : File.editor.getMarkdown()); }
  node(tag, cls, text) { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; }
  notice(text, error = false, reportedInTurn = false) {
    for(const status of [this.status,this.preferencesStatus]) if(status) {status.textContent=text;status.title=text;status.dataset.error=String(error);if(status===this.status)status.hidden=true;}
    if(error&&!reportedInTurn&&!this.preferences?.open)this.toolbar._showToolbarNotice(text);
  }
  toggle() { if (this.panel && !this.panel.hidden) this.close(); else this.open(); }
  openFromSelection(){try{const item=this.selectionUI.bodyItem();if(!item)return this.open();if(this.busy)throw Error('请等待当前回答完成后再添加引用');this.open();this.composerUI.draft.quotes.add(item);getSelection()?.removeAllRanges();this.prompt.focus();}catch(e){this.toolbar._showToolbarNotice(e.message);}}
  rememberSelection() {
    if (this.panel?.contains(document.activeElement) || this.preferences?.contains(document.activeElement)) return;
    const selection = getSelection();
    if (this.toolbar._selectionInEditor(selection)) this.toolbar._saveSelection(selection);
  }
  open() {
    this.rememberSelection();
    if (!this.toolbar.annotations?.frame) { this.toolbar._showToolbarNotice('AI 助手正在初始化，请稍后重试'); return; }
    if (!this.panel) this.mount();
    else if (this.panel.hidden) this.refreshWelcomeQuote();

    this.panel.hidden = false; this.toolbar.hide();
    if (!this.context) this.capture();
    this.layout(); this.syncProfiles(); this.checkDocument();this.chatgptUI.ensurePickerModels();
    this.prompt.focus();
    if (!this.profile()) this.notice('点击右上角设置，添加模型配置');
    this.webChat?.resumePending();
  }
  close() { if (!this.panel) return;this.richComposer?.close();this.referencesUI?.close();this.referencesUI?.previewDialog?.close();this.referencesUI?.applicationDialog?.close(); this.queue?.suspend('助手已关闭，排队已暂停'); this.editUI?.closePreview(); this.editUI?.dialog?.close();this.composerUI.draft.media?.cancel(); this.motion?.finish(true); this.attachments.cancelIO(); this.composerUI.closeMenu(); if(!this.webChat?.running)this.controller?.abort(); this.skillsUI?.dialog?.close();this.pluginsUI?.close();this.settingsUI.closeWindow(false); this.conversations.closePopup();this.contextUI?.close(); this.composerUI.draft.quotes.close(); this.selectionUI.hide(); this.conversations.flush(); this.panel.hidden = true; document.body.classList.remove('et-ai-docked'); this.toolbar._applyTopPlacement(); }
  capture(follow=true) {
    if(follow&&this.context&&this.context.file!==this.file())return this.followDocument();
    try {
      const editor = this.toolbar._getEditor(), current = getSelection();
      if (!this.panel?.contains(document.activeElement) && this.toolbar._selectionInEditor(current)) this.toolbar._saveSelection(current);
      const candidate = this.toolbar.savedRange?.cloneRange(), valid = candidate && this.toolbar._selectionInEditor(candidate);
      const markdown = this.source(), file = this.file(), range = valid ? candidate : null;
      const sourceMode = !!editor.sourceView?.inSourceMode;
      const selected = sourceMode ? editor.sourceView.cm.getSelection() : range && !range.collapsed ? this.toolbar._getSelectionText(range) : '';
      this.context = { file, markdown, selected, range: sourceMode ? null : range, label: File.bundle?.filePath ? reqnode('path').basename(file) : '未命名文档' };
      // Keep the explicitly selected scope; a new conversation starts without attached text.
      this.promptsManager.captureContext(this.context, range);
      this.updateContext();return true;
    } catch (error) { this.notice(error.message, true);return false; }
  }
  // A request owns its captured source. Changes after dispatch prepare the next turn.
  composerLocked() {return !!this.queue?.preparing||!!(this.busy&&!this.requestSource?.ready);}
  scopeLocked() {return !!this.attachments.pending||this.composerLocked();}
  updateContext() {
    if (!this.context) return;
    const scope = this.scope.value, reference = this.promptsManager.reference(), text = reference.text;
    this.contextLabel.textContent = reference.name + (scope === 'none' ? '' : ' · ' + (reference.detail || this.context.label) + (reference.image ? ' · ' + reference.image.width + ' × ' + reference.image.height : ' · ' + text.length.toLocaleString() + ' 字符'));
    if(scope==='image')this.contextLabel.textContent='图片 · '+this.context.label+' · 已选 '+(!this.composerUI.hasSourceDraft()&&this.attachments.frozen?.images?.length!=null?this.attachments.frozen.images.length:this.attachments.selected.filter(f=>f.kind==='image').length)+' 张';
    this.contextLabel.title = this.contextLabel.textContent;
    this.contextPreview.replaceChildren();
    if (reference.image) { const img = this.node('img'); img.src = reference.image.data; img.alt = reference.image.name; this.contextPreview.append(img); }
    else this.contextPreview.textContent = text || (scope === 'none' ? '只发送你的提问和本次对话。' : '尚未读取到资料，请选择对应内容或点击“读取当前”。');
    this.contextPreview.hidden = true;
    this.scope.disabled = this.scopeLocked();
    this.panel.querySelector('[data-ai="capture"]').disabled = this.scopeLocked();
    this.promptsManager.lockContext(); this.composerUI.syncContext();
  }
  mount() {
    const p = this.node('section'); p.id = 'et-ai-panel'; p.hidden = true; p.setAttribute('aria-label', 'AI 阅读助手');
    p.innerHTML = `${['n','s','e','w','ne','nw','se','sw'].map(edge=>`<div class="et-ai-resize" data-edge="${edge}" role="separator" aria-label="调整面板大小 ${edge}" tabindex="${edge==='se'?0:-1}"></div>`).join('')}
      <div class="et-ai-header"><div class="et-ai-brand"><span class="et-ai-logo">${EditingToolbarAISettings.icon}</span><strong>AI 阅读助手</strong></div><div class="et-ai-header-actions"><button data-ai="new" title="新对话" aria-label="新对话">＋</button><button data-ai="settings" title="设置" aria-label="AI 助手设置"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M4 7h5m5 0h6M4 17h10m5 0h1"/><circle cx="11.5" cy="7" r="2.5"/><circle cx="16.5" cy="17" r="2.5"/></svg></button><button data-ai="layout" title="切换浮窗 / 侧栏" aria-label="切换浮窗 / 侧栏">↗</button><button data-ai="close" title="关闭" aria-label="关闭 AI 助手">×</button></div></div>
      <div class="et-ai-chat">
        <div class="et-ai-messages" aria-label="对话记录"><div class="et-ai-empty"><div class="et-ai-welcome-mark" aria-hidden="true">${EditingToolbarAISettings.icon}</div><h3>从一个问题开始</h3><div class="et-ai-welcome-citation"><p class="et-ai-welcome-quote"></p><p class="et-ai-welcome-source"></p></div></div></div>
        <div class="et-ai-composer">
          <div class="et-ai-context"><div class="et-ai-context-label"></div><div class="et-ai-context-controls"><select class="et-ai-scope" aria-label="资料范围"><option value="selection">选中文字</option><option value="document">当前文档</option><option value="none" selected>自由提问</option><option value="abstract">摘要</option><option value="section">当前章节</option><option value="sections">多个章节</option><option value="note">笔记</option><option value="image">图片</option></select><button data-ai="capture">读取当前</button><button data-ai="preview">查看资料</button></div><pre class="et-ai-context-preview" hidden></pre></div>
          <textarea class="et-ai-prompt" rows="1" placeholder="问点什么…" aria-label="输入问题"></textarea>
          <div class="et-ai-compose-actions"><button type="button" data-ai="add-context" title="添加资料" aria-label="添加资料" aria-haspopup="dialog" aria-controls="et-ai-attachment-menu" aria-expanded="false"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg></button><button type="button" class="et-ai-model" aria-label="当前模型配置" aria-haspopup="menu" aria-expanded="false" aria-controls="et-ai-model-menu"></button><button data-ai="stop" title="停止生成" aria-label="停止生成" hidden><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="7" y="7" width="10" height="10" rx="1.5"/></svg></button><button data-ai="send" title="发送" aria-label="发送">${EditingToolbarAIComposer.arrow}</button></div>
        </div>
        <div class="et-ai-status" role="status" aria-live="polite" hidden></div>
      </div>
`;
    document.body.append(p); this.panel = p;
    const q = selector => p.querySelector(selector);
    this.chat=q('.et-ai-chat'); this.prompt=q('.et-ai-prompt'); this.scope=q('.et-ai-scope'); this.model=q('.et-ai-model');
    this.richComposer=ETRichComposer.mount(this,this.prompt);this.openComposerLink=href=>reqnode('electron').shell.openExternal(href).catch(error=>this.notice(error.message,true));
    this.messages=q('.et-ai-messages'); this.empty=q('.et-ai-empty'); this.status=q('.et-ai-status'); this.contextLabel=q('.et-ai-context-label'); this.contextPreview=q('.et-ai-context-preview');
    this.welcomeMotion = new EditingToolbarAIWelcome(this);
    this.refreshWelcomeQuote();
    this.settingsUI.mountWindow();
    this.bindSurface(p); this.bindSurface(this.preferences);
    EditingToolbarAIComposer.bindPromptKeys(this.prompt,()=>this.send());
    this.scope.onchange=()=>this.composerUI.changeScope(this.scope.value);

    this.form.elements.profile.onchange=()=>this.fillProfile(this.form.elements.profile.value);
    this.form.onsubmit=e=>{e.preventDefault();this.saveProfile().catch(error=>this.notice(error.message,true));};
    this.settingsUI.mount(); this.chatgptUI.mount();this.promptsManager.mount(); this.composerUI.mount(); this.editUI.mount();this.attachments.mount();this.webUI.mount();this.shellUI.mount(); this.composerUI.draft.mount();this.codeUI.mount(); this.conversations.mount();this.skillsUI.mount();this.pluginsUI.mount();
    this.pythonUI.mount();this.queue.mount();this.contextUI.mount();this.navigation=new EditingToolbarAIChatNavigation(this);
    // Main panel motion is owned by panelWorkspace; settings retain their own motion.
    this.documentTimer=setInterval(()=>this.checkDocument(),700);
  }
  bindSurface(root) {
    root.addEventListener('pointerdown',()=>this.rememberSelection(),true);
    for(const type of ['mousedown','mouseup','keydown','keyup','keypress','beforeinput','input','paste','copy','cut','drop']) root.addEventListener(type,e=>{this.toolbar.hide();e.stopPropagation();});
    root.addEventListener('click',e=>{e.stopPropagation();const button=e.target.closest('button');if(!button||button.disabled)return;const action=button.dataset.ai;if(action)this.act(action).catch(error=>this.notice(error.message,true));});
  }
  async act(action) {
    if (action === 'close') this.close();
    if (action === 'close-settings') this.settingsUI.closeWindow();
    if (action === 'layout') return;
    if (action === 'settings') this.settings(true);
    if (action === 'chatgpt') this.settings(true,'chatgpt');
    if (action === 'prompts') this.promptsManager.open(false);
    if (action === 'back') this.settings(false);
    if (action === 'providers') this.settingsUI.menu.hidden ? this.settingsUI.openMenu() : this.settingsUI.closeMenu();
    if (action === 'edit-system') this.settingsUI.edit('system');
    if (action === 'edit-extra') this.settingsUI.edit('extra');
    if (action === 'capture') this.composerUI.changeScope(this.scope.value);
    if (action === 'preview') {this.contextPreview.hidden = !this.contextPreview.hidden;this.composerUI.positionMenu();}
    if (action === 'new' && !this.busy) {const target=this.webChat?.active()&&this.webChat.projects.target();if(target)void this.webChat.projects.select({...target,chat:null}).catch(e=>this.notice(e.message,true));else this.newConversation();}
    if (action === 'send') await this.send();
    if (action === 'stop') {this.queue?.pause('当前回复已停止，排队已暂停');this.controller?.abort();}
    if (action === 'clear-key') { this.clearKey = true; this.form.elements.key.value = ''; this.settingsUI.syncKey();this.form.elements.key.focus();this.notice('保存配置后清除密钥'); }
    if (action === 'test') await this.test();
    if (action === 'delete-profile') {
      if (!this.editingId) return;
      const button = this.form.querySelector('[data-ai="delete-profile"]');
      if (button.dataset.confirm !== this.editingId) { button.dataset.confirm = this.editingId; button.textContent = '确认删除配置'; return; }
      this.config.profiles = this.config.profiles.filter(p => p.id !== this.editingId); this.keys.delete(this.editingId); if(this.config.active===this.editingId)this.config.active = this.config.profiles[0]?.id || ''; this.persist(); this.syncProfiles(); this.fillProfile(this.config.active || 'new'); this.notice('配置已删除');
    }
  }
  syncProfiles() {
    const fill = (select, creating) => { select.replaceChildren(); if (creating) select.append(new Option('＋ 新建配置', 'new')); for (const p of this.config.profiles.filter(p=>!creating||p.authType!=='chatgpt')) select.append(new Option(p.name + (creating ? '' : ' · ' + p.model), p.id)); if (!creating && !this.config.profiles.length) select.append(new Option('先配置模型', '')); };
    this.composerUI.refreshModels();this.composerUI.sync();
    fill(this.form.elements.profile, true); this.form.elements.profile.value = this.editingId || 'new';
  }
  settings(show, tab='settings') {
    if (this.busy || this.settingsBusy) return;
    if(!show) {this.settingsUI.closeWindow();this.prompt.focus();return;}
    this.composerUI.closeMenu(); this.settingsUI.openWindow(); this.setView(tab);
    if(tab==='settings'&&!this.settingsInitialized){this.syncProfiles();this.fillProfile(this.config.profiles.find(p=>p.id===this.editingId)?.id||(this.profile()?.authType==='chatgpt'?'new':this.profile()?.id||'new'));this.settingsInitialized=true;}
  }
  setView(name) {
    this.settingsUI.closeMenu();this.settingsUI.hideHelp();
    this.settingsPanel.hidden=name!=='settings';this.promptsManager.panel.hidden=name!=='prompts';this.chatgptUI.panel.hidden=name!=='chatgpt';this.skillsUI.panel.hidden=name!=='skills';this.pluginsUI.panel.hidden=name!=='plugins';this.preferencesStatus.hidden=name==='chatgpt'||name==='skills'||name==='plugins';if(name==='chatgpt')this.chatgptUI.open();
    this.pythonUI.panel.hidden=name!=='python';if(name==='python'){this.preferencesStatus.hidden=true;this.pythonUI.open().catch(e=>this.pythonUI.notice(e.message,true));}
    for(const button of this.nav.children){const active=button.dataset.ai===name;button.setAttribute('aria-selected',String(active));button.tabIndex=active?0:-1;}
  }
  fillProfile(id) {
    const p = this.config.profiles.find(p => p.id === id) || { name: '', url: '', model: '', temperature: .7, maxTokens: 4096 };
    this.editingId = p.id || ''; this.clearKey = false; this.form.reset(); this.form.elements.profile.value = p.id || 'new';
    for (const key of ['name', 'url', 'model', 'system', 'extra', 'temperature', 'maxTokens']) this.form.elements[key].value = p[key] ?? '';
    for (const key of ['temperatureEnabled', 'maxTokensEnabled']) this.form.elements[key].checked = !!p[key];
    this.form.elements.protocol.value = p.protocol || 'openai-chat';
    this.form.elements.fullUrl.checked = p.fullUrl ?? true;
    if(p.id && p.fullUrl == null && p.url) this.form.elements.url.value = ETAIClient.endpoint(p.url,p.protocol);
    this.form.elements.remember.checked = !!p.secret;
    this.form.elements.provider.value = p.provider || 'custom';
    this.form.elements.model.title = ETAIPrompts.providers.find(x => x.id === (p.provider || 'custom'))?.hint || '填写模型 ID';
    this.form.elements.key.title = p.secret || this.keys.has(p.id) ? '已配置；留空保持原密钥' : '填写 API Key，本机模型可留空';
    this.settingsUI.sync();
    const del = this.form.querySelector('[data-ai="delete-profile"]'); del.disabled = !p.id; del.textContent = '删除配置'; delete del.dataset.confirm;
  }
  formProfile() {
    const f = this.form.elements, p = { id: this.editingId || 'ai-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7) };
    const previous=this.config.profiles.find(x=>x.id===this.editingId);
    if(previous?.model===f.model.value.trim()&&previous.protocol===f.protocol.value&&previous.reasoningEffort!=null)p.reasoningEffort=previous.reasoningEffort;
    p.provider = f.provider.value;
    p.protocol = f.protocol.value; p.fullUrl = f.fullUrl.checked;
    for (const key of ['name', 'url', 'model', 'system', 'extra', 'temperature', 'maxTokens']) p[key] = f[key].value.trim();
    for (const key of ['temperatureEnabled', 'maxTokensEnabled']) p[key] = f[key].checked;
    if (!p.name) p.name = p.model || '模型配置';
    ETAIClient.endpoint(p.url,p.protocol,p.fullUrl); ETAIClient.body(p, [{ role: 'user', content: '连接测试' }]); return p;
  }
  request(profile,key,messages,options={}){const perform=callbacks=>profile.authType==='chatgpt'?this.chatgptUI.request(profile,messages,callbacks):this.client.request(profile,key,messages,callbacks);return options.execution?ETAIExecution.request(options.execution,perform,options):perform(options);}
  async keyFor(profile) {
    if(profile.authType==='chatgpt')return '';
    if (this.keys.has(profile.id)) return this.keys.get(profile.id);
    if (profile.secret) { const key = await this.client.protect(profile.secret, true); this.keys.set(profile.id, key); return key; }
    return '';
  }
  async formKey() {
    const typed = this.form.elements.key.value.trim(), previous = this.config.profiles.find(p => p.id === this.editingId);
    if (typed || this.clearKey || !previous) return typed;
    if (new URL(previous.url).origin !== new URL(this.form.elements.url.value).origin) throw Error('服务地址已更换，请重新填写对应服务商的 API Key');
    return this.keyFor(previous);
  }
  newConversation(discard=false,{scope='none',draft=null,command=null,silent=false}={}) {
    this.editUI?.closePreview();
    if(File.isFileLoading?.())return false;
    if(!discard&&!this.conversations.beforeNew())return false;
    this.webChat?.translation.clear();this.codeUI?.clear();
    this.queue?.clear();
    for(const turn of this.turns){this.resetCopyFeedback(turn);EditingToolbarAITiming.finish(turn);}
    this.composerUI.restoreSource();this.composerUI.sourceChanged=false;this.composerUI.draft.clear();this.turns = []; this.messages.querySelectorAll('.et-ai-turn').forEach(n => n.remove()); this.empty.hidden = false; this.refreshWelcomeQuote(); this.scope.value=scope;this.composerUI.command=command;this.attachments.reset();this.composerUI.closeMenu();
    this.contextUI?.reset();this.navigation?.reset();const captured=this.capture(false);this.composerUI.draft.restore(draft);this.composerUI.refresh();this.composerUI.sync();if(!silent&&captured)this.notice('已新建对话');return captured;
  }
  followDocument() {
    if(File.isFileLoading?.())return false;
    if(!this.context)return this.capture(false);
    if(this.context.file===this.file())return true;
    if(this.busy){if(this.webChat?.running)return false;this.queue?.suspend('文档已切换，排队已暂停');this.controller?.abort();return false;}
    // Save the previous document before replacing its frozen reference/history.
    // Carry the question and chosen scope, but not old file-bound sources.
    const {text,folded}=this.composerUI.draft.snapshot();
    const changed=this.newConversation(false,{scope:this.scope.value,draft:{text,folded},command:this.composerUI.command,silent:true});
    if(changed)this.status.hidden=true;
    return changed&&this.context?.file===this.file();
  }
  assertRequestDocument(context,controller) {
    const captured=this.requestSource?.controller===controller?this.requestSource.context:this.context;
    if(File.isFileLoading?.()||context!==captured||context.file!==this.file()){
      controller.abort();throw Object.assign(Error('已停止生成'),{name:'AbortError',documentChanged:true});
    }
    if(controller.signal.aborted)throw Object.assign(Error('已停止生成'),{name:'AbortError'});
  }
  lockSettings(lock) {
    this.settingsBusy = lock; for (const el of this.form.elements) el.disabled = lock;
    for(const b of this.nav.children) b.disabled = lock;
    if (!lock) this.form.querySelector('[data-ai="delete-profile"]').disabled = !this.editingId;
    this.settingsUI.sync();
  }
  async saveProfile() {
    if (this.settingsBusy) return;
    const p = this.formProfile(), remember = this.form.elements.remember.checked;
    this.lockSettings(true);
    try {
      const key = await this.formKey(); if (remember && key) p.secret = await this.client.protect(key);
      const next = this.config.profiles.filter(x => x.id !== p.id); next.push(p);
      const config = { ...this.config, active: p.id, profiles: next };
      this.rememberModel(p);localStorage.setItem(this.configKey, JSON.stringify(config)); this.config = config; this.keys.set(p.id, key);
      this.syncProfiles(); this.fillProfile(p.id); this.notice('模型配置已保存' + (key && !remember ? ' · 密钥仅本次窗口有效' : ''));
    } finally { this.lockSettings(false); }
  }
  async test() {
    if (this.settingsBusy) return;
    const p = this.formProfile(); this.lockSettings(true); this.controller = new AbortController(); this.notice('正在测试连接…');
    try { const key = await this.formKey(); await this.client.request(p, key, [{ role: 'user', content: '请只回复 OK。' }], { signal: this.controller.signal }); this.notice('连接成功，可以保存配置并开始对话'); }
    catch (error) { this.notice(error.message, error.name !== 'AbortError'); }
    finally { this.lockSettings(false); this.controller = null; }
  }
  busyState(value) {
    if(value&&!this.busy){const effects=['orbit','comet','aurora','pulse'].filter(effect=>effect!==this.lastWorkingEffect);this.lastWorkingEffect=effects[Math.floor(Math.random()*effects.length)];this.panel.dataset.workingEffect=this.lastWorkingEffect;}
    else if(!value)delete this.panel.dataset.workingEffect;
    this.busy = value;this.panel.dataset.generating=String(!!value);this.contextUI?.sync(); this.model.disabled = value;
    for (const action of ['new','settings','send']) for(const button of this.panel.querySelectorAll('[data-ai="'+action+'"]')) button.disabled=value;
    this.panel.querySelector('[data-ai="stop"]').hidden = !value;
    this.panel.querySelector('[data-ai="send"]').hidden = value&&!this.queue;
    if(value)this.composerUI.closeMenu();this.composerUI.sync();this.updateContext(); this.checkDocument();
    this.navigation?.schedule();
  }
  validateSource(retry,editMode,base) {
    const scope=this.scope.value;
    if (!retry && (this.composerUI.hasSourceDraft() || !this.attachments.frozen) && scope !== 'none' && !(editMode&&scope==='document') && !base.text.trim() && !base.image && !this.composerUI.draft.media?.items.length && !(scope!=='image'&&this.composerUI.draft.quotes.items.length) && !this.attachments.selected.some(f=>f.kind===(scope==='image'?'image':'text'))) return this.notice(({selection:'请先选择正文文字，再点击“读取当前”',abstract:'未找到摘要，请补充摘要标题或改用其他资料范围',section:'请选择一个章节',sections:'请勾选需要阅读的章节',note:'请选择一篇有内容的笔记',image:'请先选择图片',document:'当前文档没有内容'})[scope], true),false;
    return true;
  }
  async prepareInput(base,retry,p,signal,activity=null){
      if(p.codeFiles?.length)return this.codeUI.prepareInput(p,signal);
      const staged=!retry&&this.composerUI.hasSourceDraft();
      const reference=(retry&&(retry.requestContext||this.attachments.frozen))||await this.attachments.prepare(base,signal,p,activity);
      const quotes=retry?[]:this.composerUI.draft.quotes.snapshot(),images=retry?[]:this.composerUI.draft.media?.snapshot()||[];
      let requestContext=retry?.requestContext;
      if(!retry&&(staged||quotes.length||images.length)){
        requestContext=staged?Object.fromEntries(['text','label','name','detail','images'].map(key=>[key,reference[key]])):{text:'',label:'所选文本'};
        if(images.length){requestContext.images=[...(requestContext.images||[]),...images];requestContext.label=quotes.length?'所选文字与图片':'本轮图片';}
        if(quotes.length){requestContext.text=[requestContext.text,this.composerUI.draft.quotes.reference()].filter(Boolean).join('\n\n');requestContext.quotes=quotes;}
      }
      if(!retry&&(p.webSearch||p.project))requestContext={...(requestContext||reference),webSearch:p.webSearch,...(p.project?{projectId:p.project.id}:{})};
    return {staged,reference,requestContext};
  }
  async send(retry=null,queued=null) {
    if(this.codeUI?.targets?.length&&this.profile()?.authType==='chatgpt-web')return this.notice('代码编辑请切换到助手模型',true);
    if(retry?.webChat||this.profile()?.authType==='chatgpt-web')return this.webChat.send(retry);
    if(retry?.command?.id==='builtin-paper-translation')return this.paperTranslation.start(retry);
    if(!retry&&!queued&&this.contextUI&&this.contextUI.slashMatch()){this.contextUI.syncSlash();return this.contextUI.fromSlash();}
    if(!retry&&!queued&&this.queue&&(this.busy||this.queue.items.length||this.queue.preparing))return this.queue.enqueue();
    const queueEpoch=this.queue?.epoch;
    if (this.busy || this.settingsBusy || this.codeUI?.attaching || this.attachments.pending || this.composerUI.draft.media?.pending) return;
    if(File.isFileLoading?.())return this.notice('文档正在加载，请稍后重试');
    if(!this.followDocument()||(retry&&!this.turns.includes(retry)))return;
    const request=queued?.request||(retry?{question:retry.question,displayQuestion:retry.displayQuestion,command:retry.command,skills:retry.requestContext?.skillSelection}:this.composerUI.request());
    const {question,displayQuestion,command}=request;if(!question)return this.prompt.focus();
    const submittedAt=retry?retry.time:queued?.time||new Date().toISOString();
    const profile = queued?this.config.profiles.find(p=>['id','model','url','protocol','fullUrl'].every(k=>p[k]===queued.profile[k])):this.profile(); if(queued&&!profile)return this.notice('排队消息的模型配置已变化，请重新配置或删除该消息',true); if (!profile) { this.settings(true); return; }
    const editMode=queued?queued.editMode:retry?!!retry.editMode:!!this.editUI?.enabled,p={...profile,...(queued?{reasoningEffort:queued.profile.reasoningEffort}:{}),documentEdit:editMode,webSearch:queued?queued.webSearch:retry?!!retry.requestContext?.webSearch:!!this.webUI?.enabled,project:queued?this.webUI?.project()?.items.find(p=>p.id===queued.project?.id&&p.root===queued.project.root&&p.trusted):(editMode||this.shellUI?.enabled)?this.webUI?.defaultProject():null};
    p.codeFiles=queued?.input.requestContext?.codeFiles||retry?.requestContext?.codeFiles||this.codeUI?.snapshot()||[];if(p.codeFiles.length){p.project=this.codeUI.project(p.codeFiles);p.webSearch=false;if(!p.project)return this.notice('代码项目已不可用，请重新关联文件',true);}
    p.shellGrant=p.codeFiles.length?null:queued?queued.shellGrant:this.shellUI?.capture(p.project,p);p.shellEnabled=!!p.shellGrant;
    if(p.shellEnabled&&p.shellGrant!==this.shellUI?.capture(p.project,p))return this.notice('排队消息的 Shell 权限已失效，请重新开启并重新发送该消息',true);
    if(queued?.project&&!p.project)return this.notice('排队消息的项目已不可用，请检查项目后继续',true);
    const scope = this.scope.value, base = this.promptsManager.reference();
    if(!queued&&!p.codeFiles.length&&!this.validateSource(retry,editMode,base))return;
    const controller = this.controller = new AbortController(), context=this.context;let turn;
    this.requestSource={context,controller,ready:false};
    this.busyState(true);
    try {
      if(!retry&&!queued&&this.attachments.selected.some(f=>f.webpage)&&(!this.attachments.frozen||this.composerUI.hasSourceDraft())){turn={question,displayQuestion,command,answer:'',status:'running',file:context.file,source:context.markdown,selected:context.selected,model:p.model,time:submittedAt,editMode};EditingToolbarAITiming.begin(turn);this.turns.push(turn);this.mountTurn(turn);}
      await this.skillsUI?.configure(p,request.skills);await this.pluginsUI?.configure(p);
      const {staged,reference,requestContext}=queued?.input||await this.prepareInput(base,retry,p,controller.signal,turn?{turn,update:()=>{turn.executionUI?.update();this.conversations.schedule();}}:null);
      this.assertRequestDocument(context,controller);
      const history=retry||turn?this.turns.slice(0,-1):this.turns,build=turns=>ETAIClient.messages(p,editMode||p.codeFiles.length?reference:this.attachments.frozen||reference,turns,question,requestContext);
      const key=await this.keyFor(p);this.assertRequestDocument(context,controller);
      const messages=this.contextUI?await this.contextUI.beforeSend(p,key,history,build,controller,context):build(history);ETAIClient.body(p,messages);ETAIClient.endpoint(p.url,p.protocol,p.fullUrl);
      this.assertRequestDocument(context,controller);
      this.rememberModel(p);
      const turnValues = { ...(queued?.input.reference.sourceExecution?{execution:queued.input.reference.sourceExecution}:{}),question, displayQuestion, command, requestContext:request.skills?{...requestContext,skillSelection:request.skills}:requestContext, editMode, answer: '', status: 'running', file: context.file, source: context.markdown, selected: context.selected, range: context.range?.cloneRange(), model: p.model, reference: reference.label, time: submittedAt };
      if(turn)Object.assign(turn,turnValues);else {turn=turnValues;EditingToolbarAITiming.begin(turn);}
      if(!staged&&!this.attachments.frozen)this.attachments.freeze(reference);
      if(retry){this.turns.pop();retry.article.remove();}
      if(!this.turns.includes(turn)){this.turns.push(turn);this.mountTurn(turn);}if(queued)this.queue.started(queued);else if(!retry)this.composerUI.consumed();
      this.conversations.flush();this.notice('正在生成 · ' + p.model);
      this.assertRequestDocument(context,controller);
      this.requestSource.ready=true;this.updateContext();this.composerUI.sync();
      const changed=()=>{this.scheduleRender(turn);if(!turn.savedFirstChunk){turn.savedFirstChunk=true;this.conversations.flush();}else this.conversations.schedule();};
      const options={signal:controller.signal,execution:turn,onExecution:changed,sanitize:this.shellUI?.sanitizer(key),shellKey:key};
      const result = (editMode||p.codeFiles.length||p.webSearch||p.shellEnabled||p.skillsEnabled||p.pluginsEnabled?.length)?await this.editUI.run(p,key,messages,options,turn):await this.request(p,key,messages,options);
      this.assertRequestDocument(context,controller);
      if(!editMode&&!p.webSearch&&!p.shellEnabled&&!p.skillsEnabled&&!p.pluginsEnabled?.length)this.contextUI?.recordUsage(p,messages,result,turn);
      turn.answer = result.text;turn.status = 'done';if(this.contextUI)this.contextUI.lastUsage=result.usage?.inputTokens!=null?result.usage:null; turn.detail = result.finishReason === 'length' ? '达到模型输出上限，可继续提问' : '完成';
      this.notice(turn.detail);
    } catch (error) {
      if(turn){turn.status = error.name === 'AbortError' ? 'stopped' : 'error';turn.detail=error.message;}
      if(!error.documentChanged)this.notice(error.message,error.name!=='AbortError',!!turn);
    } finally { this.controller = null;this.requestSource=null;if(turn){ETAIExecution.finish(turn);EditingToolbarAITiming.finish(turn);this.renderTurn(turn);this.conversations.flush();}this.busyState(false);if(turn&&this.turns.includes(turn))this.renderTurn(turn);this.queue?.completed(turn,queueEpoch); }
  }
  mountTurn(turn) {
    turn.id ||= reqnode('crypto').randomUUID();this.empty.hidden = true; const article = this.node('article', 'et-ai-turn');
    const question = this.node('div', 'et-ai-question', turn.displayQuestion??turn.question), meta = this.node('small', 'et-ai-answer-meta', turn.model), answer = this.node('div', 'et-ai-answer'), actions = this.node('div', 'et-ai-answer-actions');
    ETRichComposer.renderMessage(question,turn.displayQuestion??turn.question,url=>this.openComposerLink(url));
    EditingToolbarAIQuotes.renderSent(this,article,turn);
    this.composerUI.draft.media.renderSent(article,turn,this.turns[0]===turn?this.attachments.frozen:null);
    article.append(question, this.conversations.questionFooter(turn), meta, answer, actions); this.messages.append(article); Object.assign(turn, { article, meta, answerNode: answer, actions });
    turn.executionUI=new EditingToolbarAIExecution(this,turn,answer);turn.reasoningUI=new EditingToolbarAIReasoning(this,turn,answer);
    for (const [action, label, icon] of [['copy','复制回答','copy'],['note','存为笔记','note'],['favorite','收藏回答','star'],['retry','重试','retry']]) { if(turn.webChat&&action==='retry')continue;const b=this.conversations.button(label,icon,()=>this.answerAction(turn,action));b.dataset.answerAction=action;actions.append(b); }
    this.webChat?.decorate(turn);EditingToolbarAITiming.watch(turn);this.navigation?.observe(turn);this.renderTurn(turn);if(this.navigation)this.navigation.latest();else this.messages.scrollTop = this.messages.scrollHeight;
  }
  scheduleRender(turn) { if (turn.renderTimer) return; turn.renderTimer = setTimeout(() => { turn.renderTimer = null; this.renderTurn(turn); }, 120); }
  renderTurn(turn) {
    if (!turn.article.isConnected) return; clearTimeout(turn.renderTimer); turn.renderTimer = null;
    EditingToolbarAITiming.update(turn);
    const manager = this.toolbar.annotations,emptyAnswer=turn.status==='running'?(turn.webChat?'正在等待网页回答…':'正在思考…'):this.codeUI?.emptyAnswer(turn)?this.codeUI.emptyAnswer(turn):this.editUI?.change(turn)?'文档已修改，可查看变更或撤销。':turn.requestContext?.createdFiles?.length?'文件已创建，可点击下方查看。':turn.webChat?.submitted?'暂未收到完整回答，可继续接收。':turn.webChat?'（未返回回答，请重新发送）':ETAIExecution.emptyAnswer(turn);
    turn.executionUI?.update();turn.reasoningUI?.update();turn.answerNode.hidden=!!turn.execution?.length&&!turn.answer&&turn.status==='running';
    const previewText=turn.answer||emptyAnswer,previewSignature=JSON.stringify([previewText,turn.status,turn.requestContext?.createdFiles,turn.requestContext?.fileReferences]);
    if(!turn.answerNode.hidden&&turn.previewSignature!==previewSignature){turn.previewSignature=previewSignature;const serial=turn.renderSerial=(turn.renderSerial||0)+1;
    try { manager._ensureRenderer().renderPreview(turn.answerNode, previewText, { ...this.referencesUI.options(turn),...(turn.webChat?this.webChat.previewOptions(turn):{}),minHeadingLevel:turn.webChat?2:1,isCurrent: () => turn.renderSerial === serial && turn.article.isConnected, renderMath: (tex, display) => manager._renderMath(tex, display), openLink: url => { if (/^https?:\/\//i.test(url)) reqnode('electron').shell.openExternal(url); } }); }
    catch { turn.answerNode.textContent = previewText; }}
    if(turn.webChat){
      if(!turn.webErrorNode){turn.webErrorNode=this.node('p','et-ai-web-chat-error');turn.webErrorNode.setAttribute('role','status');turn.answerNode.after(turn.webErrorNode);}
      turn.webErrorNode.hidden=turn.status!=='error'||!turn.detail;turn.webErrorNode.textContent=turn.status==='error'?turn.detail:'';
      this.webChat.renderRecovery(turn);
    }
    this.syncTurnActions(turn);
    this.editUI?.render(turn);this.webUI?.render(turn);this.codeUI?.render(turn);
    this.navigation?.schedule();
  }
  syncTurnActions(turn) {
    if(turn.webRecovery)turn.webRecovery.disabled=!!this.busy;
  turn.actions.hidden = turn.status === 'running';
    for (const b of turn.actions.children) {
      const action = b.dataset.answerAction;
      b.hidden = action === 'retry' ? !!turn.webChat?.submitted || !['error', 'stopped'].includes(turn.status) || this.turns.at(-1) !== turn || !!this.editUI?.change(turn) || !!turn.requestContext?.createdFiles?.length || !!turn.requestContext?.codeEdits?.length || !!turn.execution?.some(e=>['run_shell_command','run_skill_script','run_python_file'].includes(e.name)&&e.startedAt) : false;
      b.disabled = turn.status === 'running' || (action === 'retry' ? this.busy : b.dataset.webChatOpen ? false : !turn.answer) || action === 'note' && (turn.file !== this.file() || !!File.isFileLoading?.());
    }
    this.conversations.library.update(turn.actions,turn);
  }
  checkDocument() {
    if (!this.panel || this.panel.hidden) return;
    if(!this.conversations.saveError)this.followDocument();
    this.conversations.refreshQuestionTimes?.();this.contextUI?.schedule();
    this.editUI?.sync();this.webUI?.sync();
    for (const t of this.turns) this.syncTurnActions(t);
  }
  async answerAction(turn, action) {
    if (turn.status === 'running' || (action !== 'retry' && !turn.answer)) return;
    if (action === 'copy') {
      this.resetCopyFeedback(turn);
      reqnode('electron').clipboard.writeText(turn.answer);
      const button=turn.actions?.querySelector('[data-answer-action=copy]');
      if(button){button.innerHTML=this.conversations.icon('check');button.title='已复制';button.setAttribute('aria-label','已复制');button.dataset.copied='true';turn.copyTimer=setTimeout(()=>this.resetCopyFeedback(turn),2000);}
      this.notice('已复制 Markdown');return;
    }
    if (action === 'favorite') return this.conversations.library.toggle(turn);
    if (action === 'retry') { if (this.busy || this.turns.at(-1) !== turn || !['error','stopped'].includes(turn.status) || this.editUI?.change(turn) || turn.requestContext?.createdFiles?.length || turn.execution?.some(e=>e.name==='run_shell_command'&&e.startedAt)) return; return this.send(turn); }
    if (turn.file !== this.file() || File.isFileLoading?.()) throw Error('请回到提问时的文档后再保存');
    if (action === 'note') {
      const m = this.toolbar.documentNotes; m._switchDocument(); if (!m.ctx || m.ctx.readonly) throw Error('当前文档的笔记暂时无法写入');
      m._flushEditor(); if (!m._save()) throw Error('原笔记尚未保存，请先处理笔记保存提示');
      const n = m._blankNote('AI · ' + (turn.displayQuestion??turn.question).replace(/\s+/g, ' ').slice(0, 45));
      n.markdown = ETAIClient.insertableMarkdown('**提问**：' + (turn.displayQuestion??turn.question) + '\n\n> 来源：' + turn.reference + ' · 模型：' + turn.model + '\n\n' + turn.answer + (turn.status === 'done' ? '' : '\n\n> 此回答未完整生成。'));
      m.ctx.notes.push(n); m.ctx.virgin = false; const ui = m._ui(); ui.opened.push(n.id); ui.active = n.id; m.ctx.selected = n.id; m._touch();
      if (!m._save()) throw Error('笔记保留为草稿，但未完成保存，请查看笔记面板');
      m._saveUI(); m.open(); m._renderList(); m._showSelected(); m.tabs.reveal(n.id); this.toolbar._showToolbarNotice('AI 回答已保存为当前文档的笔记'); return;
    }
  }
  resetCopyFeedback(turn) {
    clearTimeout(turn.copyTimer);turn.copyTimer=null;
    const button=turn.actions?.querySelector('[data-answer-action=copy]');if(!button||!button.dataset.copied)return;
    button.innerHTML=this.conversations.icon('copy');button.title='复制回答';button.setAttribute('aria-label','复制回答');delete button.dataset.copied;
  }
  maxDockWidth() {
    const sidebar=window.File?.editor?.library?.isSidebarShown()?document.getElementById('typora-sidebar')?.getBoundingClientRect().width||0:0;
    return Math.max(320,innerWidth-sidebar-220);
  }
  layout() {
    if(this.toolbar.panelWorkspace?.layoutOwner(this))return;
    if(!this.panel||this.panel.hidden)return;
    this.composerUI.closeMenu();this.settingsUI.closeMenu();this.settingsUI.hideHelp();
    const floating=this.layoutMode==='float'||innerWidth<760, wasDocked=document.body.classList.contains('et-ai-docked');
    const mode=floating?'float':'dock';if(this.panel.dataset.layout!==mode)this.panel.dataset.layout=mode;
    document.body.classList.toggle('et-ai-docked',!floating);
    const width=Math.min(Math.max(320,Number(this.config.width)||420),floating?Math.max(180,innerWidth-16):this.maxDockWidth());
    const height=Math.min(Math.max(300,Number(this.config.height)||660),Math.max(180,innerHeight-16));
    const set=(key,value)=>{if(this.panel.style[key]!==value)this.panel.style[key]=value;};set('width',width+'px');
    if(floating){const pos=this.position||this.config.position;set('height',height+'px');set('left',Math.max(8,Math.min(pos?.x??innerWidth-width-24,innerWidth-width-8))+'px');set('top',Math.max(8,Math.min(pos?.y??80,innerHeight-height-8))+'px');}
    else {set('left','');set('top','');set('height','');document.documentElement.style.setProperty('--et-ai-width',width+'px');}
    const label=floating?'⇥':'↗',toggle=this.panel.querySelector('[data-ai="layout"]');if(toggle.textContent!==label)toggle.textContent=label;
    if(wasDocked!==!floating||!floating)this.toolbar._applyTopPlacement();
  }
}
