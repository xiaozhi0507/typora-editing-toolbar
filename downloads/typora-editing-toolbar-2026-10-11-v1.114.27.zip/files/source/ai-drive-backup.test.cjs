'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const Plugins=require('./ai-plugins.cjs'),Drive=require('./ai-drive-backup.cjs'),Store=require('./knowledge-library-store.cjs'),Managed=require('./knowledge-library-managed.cjs'),Archive=require('./knowledge-library-archive.cjs'),Backup=require('./knowledge-library-backup.cjs'),Zip=require('fflate');
async function fixture(t,{DriveClass=Drive}={}){
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'drive-backup-'));t.after(()=>fs.rm(dir,{recursive:true,force:true}));let refresh=0;
 const p=new Plugins(require,dir+'/plugins',{protect:async(v,d)=>d?Buffer.from(v,'base64').toString():Buffer.from(v).toString('base64'),transport:async(url)=>url.includes('/token')?(refresh++,{access_token:'fresh-token',expires_in:3600}):{user:{emailAddress:'backup@example.test',permissionId:'provider'}}});
 await p.update((s,c)=>{c.googleConfig={client_id:'client.apps.googleusercontent.com',client_secret:'test-secret'};c.googleBackup={key:'account-key',client_id:c.googleConfig.client_id,access_token:'test-token',refresh_token:'refresh-secret',expiresAt:Date.now()+3600000};s.plugins['google-drive']={enabled:true,configured:true,connectionMode:'codex',codexAccounts:[{key:'codex-test',account:'codex@example.test'}],backupAccount:{key:'account-key',account:'backup@example.test'}};});
 const store=new Store(dir+'/library'),base=(await store.open()).data;await fs.writeFile(store.root+'/a.md','# document');await fs.mkdir(dir+'/cache');
 await store.commit(base,{...base,items:[{id:'item',type:'paper',title:'Test',status:'unread',files:[store.fileRef(store.root+'/a.md')],tags:[],collections:[],related:[]}]});
 const backup=new Backup(store,{Managed,Archive,Zip,destination:dir+'/cache'}),files=new Map(),sessions=new Map(),calls=[];let serial=0,hook;
 const digest=(b,type)=>crypto.createHash(type).update(b).digest('hex');
 const transport=async(url,options={})=>{
  const u=new URL(url),o=options,json=o.body?.length&&o.headers?.['Content-Type']?.startsWith('application/json')?JSON.parse(o.body):null;calls.push({path:u.pathname,method:o.method||'GET',range:o.headers?.['Content-Range'],json,count:Number(u.searchParams.get('count')),uploadType:u.searchParams.get('uploadType')});
  if(hook){const result=await hook(u,o,json);if(result)return result;}
  const done=(status,data,headers={})=>({status,data,headers});
  if(u.pathname.endsWith('/generateIds'))return done(200,{ids:Array.from({length:Number(u.searchParams.get('count'))||1},()=> 'id'+(++serial))});
  if(u.pathname==='/drive/v3/files'&&o.method==='POST'){if(files.has(json.id))return done(409,{});const file={...json,trashed:false};files.set(file.id,file);return done(200,{id:file.id});}
  if(u.pathname==='/drive/v3/files'){
   const q=u.searchParams.get('q')||'',parent=/'([^']+)' in parents/.exec(q)?.[1],tag=/value='([^']+)'/.exec(q)?.[1];
   return done(200,{files:[...files.values()].filter(f=>!f.trashed&&(!parent||f.parents?.includes(parent))&&(!tag||f.appProperties?.typoraBackup===tag)&&(!q.includes("mimeType = 'application/vnd.google-apps.folder'")||f.mimeType==='application/vnd.google-apps.folder')&&(!q.includes("name = 'README.txt'")||f.name==='README.txt'))});
  }
  if(u.pathname.startsWith('/drive/v3/files/')){
   const id=u.pathname.split('/').pop(),file=files.get(id);if(!file)return done(404,{error:{code:404}});
   if(o.method==='PATCH'){Object.assign(file,json);return done(200,{id});}
   if(u.searchParams.get('alt')==='media'){const bytes=[...sessions.values()].find(s=>s.metadata.id===id).bytes,m=/bytes=(\d+)-(\d+)/.exec(o.headers.Range);return done(206,bytes.subarray(+m[1],+m[2]+1),{'content-range':'bytes '+m[1]+'-'+m[2]+'/'+bytes.length});}
   return done(200,file);
  }
  if(u.pathname==='/upload/drive/v3/files'&&u.searchParams.get('uploadType')==='multipart'){
   const boundary=o.headers['Content-Type'].split('boundary=')[1],divider=Buffer.from('\r\n--'+boundary+'\r\n'),end=Buffer.from('\r\n--'+boundary+'--\r\n');
   const first=o.body.indexOf(Buffer.from('\r\n\r\n'))+4,split=o.body.indexOf(divider),metadata=JSON.parse(o.body.subarray(first,split).toString());
   if(files.has(metadata.id))return done(409,{});
   const payload=o.body.indexOf(Buffer.from('\r\n\r\n'),split+divider.length)+4,bytes=o.body.subarray(payload,o.body.length-end.length);
   assert.deepEqual(o.body.subarray(o.body.length-end.length),end);
   const f={...metadata,mimeType:'application/octet-stream',size:String(bytes.length),md5Checksum:digest(bytes,'md5'),sha256Checksum:digest(bytes,'sha256'),createdTime:new Date(Date.now()+serial).toISOString(),trashed:false};
   files.set(f.id,f);sessions.set('multipart:'+f.id,{metadata,total:bytes.length,bytes:Buffer.from(bytes)});return done(200,f);
  }
  if(u.pathname==='/upload/drive/v3/files'&&o.method==='POST'){const location='https://www.googleapis.com/upload/drive/v3/resume/'+(++serial);sessions.set(location,{metadata:json,total:Number(o.headers['X-Upload-Content-Length']),bytes:Buffer.alloc(0)});return done(200,null,{location});}
  if(sessions.has(url)){
   const s=sessions.get(url),range=o.headers['Content-Range'];if(range.startsWith('bytes */')&&s.total>0){if(files.has(s.metadata.id))return done(200,files.get(s.metadata.id));return done(308,null,s.bytes.length?{range:'bytes=0-'+(s.bytes.length-1)}:{});}
   if(o.body?.length){const start=Number(/^bytes (\d+)-/.exec(range)[1]);if(start!==s.bytes.length)return done(400,{});s.bytes=Buffer.concat([s.bytes,o.body]);}
   if(s.bytes.length===s.total){const f={...s.metadata,mimeType:'application/octet-stream',size:String(s.total),md5Checksum:digest(s.bytes,'md5'),sha256Checksum:digest(s.bytes,'sha256'),createdTime:new Date(Date.now()+serial).toISOString(),trashed:false};files.set(f.id,f);return done(200,f);}
   return done(308,null,{range:'bytes=0-'+(s.bytes.length-1)});
  }
  throw Error('Unexpected mocked URL '+u.pathname);
 };
 const drive=new DriveClass(p,{request:transport,sleep:async()=>{}}),run=async()=>{const plan=await backup.plan(),remote=await drive.scan(backup,plan);return drive.run(backup,plan,remote);};
 return {dir,p,store,backup,drive,files,sessions,calls,run,transport,hook:value=>hook=value,refresh:()=>refresh};
}
test('direct backup uploads and verifies exact raw bytes; second run uploads no blobs, snapshot or README',async t=>{
 const x=await fixture(t),before=JSON.stringify(x.p.state().plugins['google-drive'].codexAccounts),first=await x.run();assert.equal(first.uploaded,1);assert.equal(first.cloudFiles,1);assert.match(first.url,/drive.google.com\/drive\/folders\/id/);
 const uploads=x.calls.filter(c=>c.path==='/upload/drive/v3/files').length;const again=await x.run();assert.equal(again.uploaded,0);assert.equal(x.calls.filter(c=>c.path==='/upload/drive/v3/files').length,uploads);assert.equal(JSON.stringify(x.p.state().plugins['google-drive'].codexAccounts),before);assert.equal(x.p.connectionMode('google-drive'),'codex');
 assert.ok([...x.sessions.values()].some(s=>s.bytes.toString()==='# document'));assert.equal((await x.backup.json(path.join(x.backup.root,'cloud-account-key.json'))).packageId,first.packageId);
});
test('changed files upload incrementally while old cloud snapshots and blobs remain',async t=>{
 const x=await fixture(t);await x.run();const oldIds=[...x.files.keys()];await fs.writeFile(x.store.root+'/a.md','# changed');const r=await x.run();assert.equal(r.uploaded,1);assert.ok(oldIds.every(id=>x.files.has(id)));assert.equal([...x.files.values()].filter(f=>f.name.startsWith('snapshot-')).length,2);
});
test('cloud deletions are found during next scan even if local backup is unchanged',async t=>{
 const x=await fixture(t);await x.run();const blob=[...x.files.values()].find(f=>/^[a-f0-9]{64}$/.test(f.name));x.files.delete(blob.id);assert.equal((await x.run()).uploaded,1);
});
test('failed upload never publishes snapshot or claims cloud success',async t=>{
 const x=await fixture(t);x.hook(async u=>u.pathname==='/upload/drive/v3/files'?{status:403,data:{error:{errors:[{reason:'insufficientPermissions'}]}},headers:{}}:null);
 await assert.rejects(x.run(),/拒绝写入/);assert.equal([...x.files.values()].filter(f=>f.name.startsWith('snapshot-')).length,0);assert.equal(await x.backup.exists(path.join(x.backup.root,'cloud-account-key.json')),null);assert.equal(await x.backup.exists(x.backup.root+'/cloud.lock'),null);
});
test('chunk cancellation resumes server-acknowledged offset after restart; session URLs are encrypted',async t=>{
 const x=await fixture(t);await fs.writeFile(x.store.root+'/payload.bin',Buffer.alloc(5*1024**2,67));const base=(await x.store.read()).data;await x.store.commit(base,{...base,items:[{...base.items[0],files:[x.store.fileRef(x.store.root+'/payload.bin')]}]});
 const plan=await x.backup.plan(),remote=await x.drive.scan(x.backup,plan),c=new AbortController();await assert.rejects(x.drive.run(x.backup,plan,remote,{signal:c.signal,onProgress:text=>{if(text.includes('80%'))c.abort();}}),{name:'AbortError'});
 const sessionName=(await fs.readdir(x.p.dir)).find(n=>n.startsWith('backup-sessions-'));assert.ok(sessionName);assert.ok(!(await fs.readFile(path.join(x.p.dir,sessionName),'utf8')).includes('googleapis.com'));
 const result=await x.run();assert.equal(result.uploaded,1);assert.ok(x.calls.some(call=>call.range==='bytes */5242880'));assert.ok(x.calls.some(call=>call.range==='bytes 4194304-5242879/5242880'));
});
test('cloud checksum mismatches are not accepted as successful backups',async t=>{
 const x=await fixture(t);x.hook(async(u)=>{if(u.pathname.startsWith('/drive/v3/files/')){const f=x.files.get(u.pathname.split('/').pop());if(f?.size)return {status:200,headers:{},data:{...f,md5Checksum:'bad',sha256Checksum:'bad'}};}});await assert.rejects(x.run(),/校验/);assert.equal([...x.files.values()].filter(f=>f.name.startsWith('snapshot-')).length,0);
});
test('account switching during requests stops before publishing another account snapshot',async t=>{
 const x=await fixture(t);let once=true;x.hook(async()=>{if(once){once=false;await x.p.update(s=>{s.plugins['google-drive'].backupAccount.key='other';});}});await assert.rejects(x.run(),/账户已变更/);assert.equal(x.files.size,0);
});
test('401 refreshes the backup token without changing Codex or independent read credentials',async t=>{
 const x=await fixture(t);let once=true;x.hook(async()=>{if(once){once=false;return {status:401,headers:{},data:{}};}});await x.run();assert.equal(x.refresh(),1);assert.equal(x.p.connectionMode('google-drive'),'codex');assert.equal((await x.p.secrets()).googleBackup.refresh_token,'refresh-secret');
});
test('strict upload origin guard refuses token-bearing redirects and lookalike hosts',async t=>{
 const x=await fixture(t);for(const url of ['http://www.googleapis.com/drive/v3/files','https://www.googleapis.com.evil.test/drive/v3/files','https://user@www.googleapis.com/drive/v3/files','https://www.googleapis.com/other','https://www.googleapis.com:8443/drive/v3/files'])assert.throws(()=>x.drive.url(url),/官方/);
});
test('zero-byte files are uploaded intact and can use MD5 readback when SHA256 is absent',async t=>{
 const x=await fixture(t);await fs.writeFile(x.store.root+'/a.md','');const result=await x.run();assert.equal(result.uploaded,1);assert.ok([...x.files.values()].some(f=>f.size==='0'));const f={bytes:0,md5:crypto.createHash('md5').digest('hex'),sha256:'test'};assert.equal(x.drive.matches({size:'0',md5Checksum:f.md5},f),true);
});
test('disconnect and changed OAuth configuration clear only backup/direct credentials, preserving Codex',async t=>{
 const x=await fixture(t);await x.drive.disconnect();assert.equal(x.drive.account(),null);assert.equal(x.p.connectionMode('google-drive'),'codex');await x.p.configureGoogle({installed:{client_id:'new.apps.googleusercontent.com'}});assert.equal(x.p.state().plugins['google-drive'].enabled,true);assert.equal(x.p.state().plugins['google-drive'].codexAccounts.length,1);assert.equal((await x.p.secrets()).googleBackup,undefined);
});

test('backup consent uses narrow scope and PKCE; saves verified identity without changing Codex',async t=>{
 const x=await fixture(t),stages=[];let auth,exchange;
 x.p.transport=async(url,o)=>{if(url.includes('/token')){exchange=o.form;return {access_token:'backup-access',refresh_token:'backup-refresh',expires_in:3600,scope:'https://www.googleapis.com/auth/drive.file'};}return {user:{emailAddress:'second@example.test',permissionId:'new-provider'}};};
 const account=await x.drive.connect(async url=>{auth=new URL(url);const cb=auth.searchParams.get('redirect_uri')+'?state='+auth.searchParams.get('state')+'&code=mock-code';await new Promise((resolve,reject)=>require('node:http').get(cb,r=>{r.resume();r.on('end',resolve);}).on('error',reject));},{onProgress:s=>stages.push(s)});
 assert.equal(auth.searchParams.get('scope'),'https://www.googleapis.com/auth/drive.file');assert.equal(auth.searchParams.get('access_type'),'offline');assert.equal(auth.searchParams.get('code_challenge'),crypto.createHash('sha256').update(exchange.code_verifier).digest('base64url'));
 assert.equal(account.account,'second@example.test');assert.equal(x.p.connectionMode('google-drive'),'codex');assert.ok(stages.includes('saving'));assert.ok(!JSON.stringify(x.p.state()).includes('backup-refresh'));
 assert.equal((await x.p.secrets()).googleBackup.refresh_token,'backup-refresh');
});

test('cancelled consent preserves prior backup identity and refuses late token persistence',async t=>{
 const x=await fixture(t),before=JSON.stringify(x.drive.account()),c=new AbortController();await assert.rejects(x.drive.connect(()=>c.abort(),{signal:c.signal}),{name:'AbortError'});assert.equal(JSON.stringify(x.drive.account()),before);
});

test('lost chunk response queries accepted range instead of resending the same chunk',async t=>{
 const x=await fixture(t);await fs.writeFile(x.store.root+'/a.md',Buffer.alloc(5*1024**2,65));let dropped=false;
 x.hook(async(u,o)=>{if(!dropped&&u.pathname.includes('/resume/')&&o.body?.length===4*1024**2){const s=x.sessions.get(u.href);s.bytes=Buffer.from(o.body);dropped=true;throw Object.assign(Error('lost response'),{retryable:true});}});
 assert.equal((await x.run()).uploaded,1);assert.equal(x.calls.filter(c=>c.range==='bytes 0-4194303/5242880').length,1);assert.ok(x.calls.some(c=>c.range==='bytes 4194304-5242879/5242880'));
});

const Sync=require('./knowledge-library-sync.cjs');
test('all-backup catalog includes old files after empty latest and keeps distinct versions',async t=>{
 const x=await fixture(t);await x.run();await fs.writeFile(x.store.root+'/a.md','# version two');await x.run();await removeItem(x);await x.run();
 const all=await x.drive.catalogAll(x.backup);assert.equal(all.snapshots.length,3);assert.equal(all.rows.length,2);assert.equal(all.snapshots[0].library.items.length,0);assert.equal(all.snapshots[0].latest,true);assert.equal(all.rows[0].titles[0],'Test');assert.equal((await x.drive.catalog(x.backup)).rows.length,0);
});
test('all-backup catalog deduplicates unchanged bytes and gracefully lists never-backed-up libraries',async t=>{
 const x=await fixture(t);assert.equal((await x.drive.catalogAll(x.backup)).rows.length,0);await x.run();let base=(await x.store.read()).data;await x.store.commit(base,{...base,items:[{...base.items[0],title:'Updated title'}]});await x.run();
 const all=await x.drive.catalogAll(x.backup);assert.equal(all.rows.length,1);assert.equal(all.rows[0].copies.length,2);assert.deepEqual(all.rows[0].titles,['Updated title','Test']);
});
test('all-backup pull restores historical papers, metadata-only items, collections and relative images',async t=>{
 const x=await fixture(t);await fs.mkdir(x.store.root+'/img');await fs.writeFile(x.store.root+'/img/p.png','image bytes');await fs.writeFile(x.store.root+'/a.md','# doc\n![p](img/p.png)');
 const base=(await x.store.read()).data;await x.store.commit(base,{...base,collections:[{id:'collection',name:'Research'}],items:[{...base.items[0],collections:['collection'],related:['meta'],relatedOut:['meta']},{id:'meta',type:'paper',title:'No attachment',status:'unread',files:[],tags:[],collections:['collection'],related:['item']}]});await x.run();
 const current=(await x.store.read()).data;await x.store.commit(current,{...current,collections:[],items:[]});await x.run();const start=x.calls.length;
 const s=new Sync(x.backup,x.drive),result=await s.pull({all:true});assert.equal(result.items,2);assert.equal(result.files,2);const restored=(await x.store.read()).data;
 assert.equal(restored.items.length,2);assert.equal(s.state.summary.items,2);assert.equal(restored.collections[0].name,'Research');assert.deepEqual(restored.items.find(i=>i.id==='item').related,['meta']);
 const file=x.store.resolveFile(restored.items.find(i=>i.id==='item').files[0]);assert.match(await fs.readFile(file,'utf8'),/img\/p.png/);assert.equal(await fs.readFile(path.join(path.dirname(file),'img/p.png'),'utf8'),'image bytes');
 assert.equal(x.calls.slice(start).filter(c=>c.method!=='GET').length,0);const second=await s.pull({all:true});assert.equal(second.files,0);assert.equal(second.items,0);assert.equal((await x.store.read()).data.items.length,2);
});
test('all-backup pull preserves edited resource trees and reuses the verified conflict copy',async t=>{
 const x=await fixture(t);await fs.writeFile(x.store.root+'/p.png','cloud image');await fs.writeFile(x.store.root+'/a.md','![p](p.png)');await x.run();await removeItem(x);const s=new Sync(x.backup,x.drive);await s.pull({all:true});
 let item=(await x.store.read()).data.items[0],original=x.store.resolveFile(item.files[0]),image=path.join(path.dirname(original),'p.png');await fs.writeFile(original,'Local changes\n![p](p.png)');await fs.writeFile(image,'local image');
 const r=await s.pull({all:true});assert(r.conflicts>0);item=(await x.store.read()).data.items[0];assert.equal(item.files.length,2);assert.match(await fs.readFile(original,'utf8'),/Local changes/);assert.equal(await fs.readFile(image,'utf8'),'local image');
 const cloud=x.store.resolveFile(item.files.find(f=>f.id===item.defaultFile));assert.equal(await fs.readFile(cloud,'utf8'),'![p](p.png)');assert.equal(await fs.readFile(path.join(path.dirname(cloud),'p.png'),'utf8'),'cloud image');
 await s.pull({all:true});await s.pull({all:true});assert.equal((await x.store.read()).data.items[0].files.length,2);assert.match(await fs.readFile(original,'utf8'),/Local changes/);
});
test('all-backup pull keeps both file versions on disk and uses the newest available document',async t=>{
 const x=await fixture(t);await x.run();const old=(await x.drive.catalog(x.backup)).snapshot;await fs.writeFile(x.store.root+'/a.md','# newest');await x.run();await removeItem(x);await x.run();
 const s=new Sync(x.backup,x.drive);await s.pull({all:true});const item=(await x.store.read()).data.items[0];assert.equal(await fs.readFile(x.store.resolveFile(item.files[0]),'utf8'),'# newest');
 const oldFile=path.join(x.store.root,'storage','drive-downloads',old.packageId,...old.files[0].path.split('/'));assert.equal(await fs.readFile(oldFile,'utf8'),'# document');
});
test('selecting one historical version downloads only that version and missing selection fails closed',async t=>{
 const x=await fixture(t);await x.run();const old=(await x.drive.catalog(x.backup)).snapshot;await fs.writeFile(x.store.root+'/a.md','# newest');await x.run();await removeItem(x);
 const s=new Sync(x.backup,x.drive),r=await s.pull({all:true,packageId:old.packageId});assert.equal(r.files,1);const item=(await x.store.read()).data.items[0];assert.equal(await fs.readFile(x.store.resolveFile(item.files[0]),'utf8'),'# document');await assert.rejects(s.pull({all:true,packageId:'0'.repeat(64)}),/所选备份已变化/);
});
test('download interruption or concurrent local edits never commits restored library records',async t=>{
 const x=await fixture(t);await x.run();await removeItem(x);const before=(await x.store.read()).data,s=new Sync(x.backup,x.drive);
 const write=x.backup.io.copyFile;let changed=false;x.backup.io.copyFile=async(...args)=>{const r=await write(...args);if(!changed&&String(args[1]).includes('drive-downloads')){changed=true;const b=(await x.store.read()).data;await x.store.commit(b,{...b,items:[{id:'new-local',type:'note',title:'New local edit',status:'unread',files:[],tags:[],collections:[],related:[]}]});}return r;};
 try{await assert.rejects(s.pull({all:true}),/知识库已变化/);assert.deepEqual((await x.store.read()).data.items.map(i=>i.id),['new-local']);}finally{x.backup.io.copyFile=write;}
});
test('all-backup pull cancellation after staging never publishes restored records',async t=>{
 const x=await fixture(t);await x.run();await removeItem(x);let s;
 s=new Sync(x.backup,x.drive,{onState:state=>{if(state.stage==='saving')s.cancel();}});
 await assert.rejects(s.pull({all:true}),{name:'AbortError'});assert.equal((await x.store.read()).data.items.length,0);assert.equal(await fs.readFile(x.store.root+'/a.md','utf8'),'# document');assert.equal(s.state.busy,false);
});
test('all-backup pull verifies remote bytes before publishing local references',async t=>{
 const x=await fixture(t);await x.run();await removeItem(x);const catalog=await x.drive.catalogAll(x.backup);await fs.unlink(x.backup.object(catalog.rows[0].sha256));
 x.hook(async u=>u.searchParams.get('alt')==='media'&&!x.files.get(u.pathname.split('/').pop()).name.endsWith('.json')?{status:200,headers:{},data:Buffer.from('corruption')}:null);
 await assert.rejects(new Sync(x.backup,x.drive).pull({all:true}));assert.equal((await x.store.read()).data.items.length,0);assert.equal(await fs.readFile(x.store.root+'/a.md','utf8'),'# document');
});
test('cloud avatar refresh uses the backup account identity, caches, and rejects switched identities',async t=>{
 const x=await fixture(t);let reads=0;x.hook(async u=>{if(u.pathname==='/drive/v3/about'){reads++;return {status:200,headers:{},data:{user:{emailAddress:'backup@example.test',permissionId:'provider',photoLink:'https://lh3.googleusercontent.com/test',displayName:'Reader'}}};}});
 const account=await x.drive.profile();assert.equal(account.avatar,'https://lh3.googleusercontent.com/test');await x.drive.profile();assert.equal(reads,1);
 await x.p.update(s=>{s.plugins['google-drive'].backupAccount.profileCheckedAt=0;});x.hook(async u=>u.pathname==='/drive/v3/about'?{status:200,headers:{},data:{user:{emailAddress:'different@example.test'}}}:null);await assert.rejects(x.drive.profile(),/不匹配/);
});
const Cleanup=require('./knowledge-drive-cleanup.cjs');
async function removeItem(x){const base=(await x.store.read()).data;await x.store.commit(base,{...base,items:base.items.filter(i=>i.id!=='item')});}
const trashCalls=x=>x.calls.filter(c=>c.method==='PATCH'&&c.json?.trashed===true);
test('manual cleanup detects removed documents in older history; automatic uploads never trash',async t=>{
 const x=await fixture(t);await x.run();await removeItem(x);const s=new Sync(x.backup,x.drive);
 assert.equal((await s.upload({automatic:true})).reason,'empty-library');assert.equal(trashCalls(x).length,0);
 await s.upload(); // A newer empty snapshot must not hide the old document.
 const result=await s.manualUpload(async p=>{assert.equal(p.summary.documents,1);assert.equal(p.summary.files,1);return 'cleanup';});
 assert.equal(result.cleanup.documents,1);assert.equal(result.cleanup.files,1);assert.equal(trashCalls(x).length,2);
 assert.equal((await x.drive.catalog(x.backup)).rows.length,0);assert.equal(await new Cleanup(x.drive,x.backup).pending(),null);
});
test('cancel and sync-only never clean; count equality does not suppress ID comparison',async t=>{
 const x=await fixture(t);await x.run();const base=(await x.store.read()).data;await x.store.commit(base,{...base,items:[{...base.items[0],id:'replacement',title:'Other'}]});
 const s=new Sync(x.backup,x.drive),before=x.calls.length;
 assert.equal((await s.manualUpload(async p=>{assert.equal(p.documents[0].id,'item');return 'cancel';})).cancelled,true);
 assert.equal(x.calls.slice(before).filter(c=>c.method!=='GET').length,0);
 await s.manualUpload(async()=> 'sync');assert.equal(trashCalls(x).length,0);
 await s.manualUpload(async()=> 'cleanup');assert.equal(trashCalls(x).length,1); // Shared content hash retained.
 assert.equal((await x.drive.catalog(x.backup)).snapshot.library.items[0].id,'replacement');
});
test('local recycle-bin items and imported source IDs protect cloud documents',async t=>{
 const x=await fixture(t);await x.run();let base=(await x.store.read()).data;await x.store.commit(base,{...base,items:[{...base.items[0],deleted:Date.now()}]});
 let p=await new Cleanup(x.drive,x.backup).inspect(await x.backup.plan());assert.equal(p.documents.length,0);
 base=(await x.store.read()).data;await x.store.commit(base,{...base,items:[{...base.items[0],id:'copy',archiveImport:{sourceId:'item',packageId:'legacy'}}]});
 p=await new Cleanup(x.drive,x.backup).inspect(await x.backup.plan());assert.equal(p.documents.length,0);
});
test('shared closure ownership preserves retained documents and every historical attachment version',async t=>{
 const x=await fixture(t);await fs.writeFile(x.store.root+'/shared.png','image');await fs.writeFile(x.store.root+'/a.md','# first\n![shared](shared.png)');await fs.writeFile(x.store.root+'/b.md','# second\n![shared](shared.png)');
 let base=(await x.store.read()).data;await x.store.commit(base,{...base,items:[base.items[0],{...base.items[0],id:'second',title:'Second',files:[x.store.fileRef(x.store.root+'/b.md')],related:['item'],relatedOut:['item']}]});
 const initial=await x.backup.plan(),image=initial.files.find(f=>f.path.endsWith('shared.png'));assert.deepEqual(image.owners,['item','second']);await x.run();
 await fs.writeFile(x.store.root+'/b.md','# newer second\n![shared](shared.png)');await x.run();
 base=(await x.store.read()).data;await x.store.commit(base,{...base,items:base.items.filter(i=>i.id!=='item').map(i=>({...i,related:[],relatedOut:[]}))});
 const s=new Sync(x.backup,x.drive),r=await s.manualUpload(async p=>{assert.equal(p.summary.shared,1);assert.equal(p.summary.files,1);return 'cleanup';});assert.equal(r.cleanup.documents,1);
 const checker=new Cleanup(x.drive,x.backup),after=await checker.inspect(await x.backup.plan());assert.equal(after.documents.length,0);assert(after.entries.length>=2);
 for(const e of after.entries){assert.deepEqual(e.snapshot.library.items.map(i=>i.id),['second']);assert.equal(e.snapshot.library.items[0].related.length,0);assert(e.snapshot.files.some(f=>f.sha256===image.sha256));}
 assert.equal([...x.files.values()].find(m=>m.name===image.sha256).trashed,false);
});
test('legacy snapshots keep unknown attachments while retaining another document',async t=>{
 const x=await fixture(t);let base=(await x.store.read()).data;await x.store.commit(base,{...base,items:[base.items[0],{...base.items[0],id:'second',title:'Metadata-only',files:[]}]});
 const plan=await x.backup.plan();plan.files=plan.files.map(({owners,...f})=>f);plan.packageId=x.backup.archive.packageId(plan.collected.library,plan.files);await x.drive.run(x.backup,plan,await x.drive.scan(x.backup,plan));
 await removeItem(x);const r=await new Sync(x.backup,x.drive).manualUpload(async p=>{assert.equal(p.summary.files,0);assert.equal(p.summary.legacy,1);return 'cleanup';});assert.equal(r.cleanup.files,0);
 assert.equal(trashCalls(x).length,1);const remaining=await new Cleanup(x.drive,x.backup).inspect(await x.backup.plan());assert.equal(remaining.documents.length,0);assert(remaining.entries.some(e=>e.snapshot.files.length===1));
});
test('source changes during confirmation stop before upload or cleanup',async t=>{
 const x=await fixture(t);await x.run();await removeItem(x);const before=x.calls.length;
 await assert.rejects(new Sync(x.backup,x.drive).manualUpload(async()=>{const b=(await x.store.read()).data;await x.store.commit(b,{...b,items:[{id:'new',type:'note',title:'New',status:'unread',files:[],tags:[],collections:[],related:[]}]});return 'cleanup';}),/变化|更新/);
 assert.equal(x.calls.slice(before).filter(c=>c.method!=='GET').length,0);
});
test('cloud history changed after preview prevents all trash operations',async t=>{
 const x=await fixture(t);await x.run();await removeItem(x);
 await assert.rejects(new Sync(x.backup,x.drive).manualUpload(async()=>{const meta=[...x.files.values()].find(m=>m.name.startsWith('snapshot-'));x.files.set('foreign',{...meta,id:'foreign'});return 'cleanup';}),/变化/);assert.equal(trashCalls(x).length,0);
});
test('failure during trash rolls back old manifests and blobs, including lost responses',async t=>{
 const x=await fixture(t);await x.run();await removeItem(x);let failures=0;
 x.hook(async(u,o,json)=>{if(json?.trashed===true&&++failures===2){x.files.get(u.pathname.split('/').pop()).trashed=true;throw Error('lost successful response');}});
 await assert.rejects(new Sync(x.backup,x.drive).manualUpload(async()=> 'cleanup'),/lost successful response/);
 assert([...x.files.values()].every(m=>!m.trashed));assert.equal(await new Cleanup(x.drive,x.backup).pending(),null);
});
test('unfinished rollback blocks automatic upload and next manual action recovers first',async t=>{
 const x=await fixture(t);await x.run();await removeItem(x);let count=0;
 x.hook(async(u,o,j)=>{if(j?.trashed===true&&++count===2)throw Error('interrupted');if(j?.trashed===false)throw Error('offline');});
 await assert.rejects(new Sync(x.backup,x.drive).manualUpload(async()=> 'cleanup'),/尚未恢复/);
 assert(await new Cleanup(x.drive,x.backup).pending());await assert.rejects(x.run(),/上次清理尚未恢复/);
 x.hook(null);await new Sync(x.backup,x.drive).manualUpload(async()=> 'cancel');assert([...x.files.values()].every(m=>!m.trashed));assert.equal(await new Cleanup(x.drive,x.backup).pending(),null);
});
test('cancel during deletion restores objects; cleanup is never scheduled as automatic retry',async t=>{
 const x=await fixture(t);await x.run();await removeItem(x);const s=new Sync(x.backup,x.drive);s.enabled=true;let cancelled=false;
 x.hook(async(u,o,j)=>{if(j?.trashed===true&&!cancelled){cancelled=true;s.cancel();}});
 await assert.rejects(s.manualUpload(async()=> 'cleanup'),{name:'AbortError'});assert([...x.files.values()].every(m=>!m.trashed));assert(!s.timer);assert.equal(await new Cleanup(x.drive,x.backup).pending(),null);s.close();
});
test('unexpected history files and attachment parents fail closed without cloud writes',async t=>{
 const x=await fixture(t);await x.run();await removeItem(x);const blob=[...x.files.values()].find(m=>HASH_TEST(m.name));blob.parents.push('another-library');
 await assert.rejects(new Sync(x.backup,x.drive).manualUpload(async()=> 'cleanup'),/位置或校验/);assert.equal(trashCalls(x).length,0);
 blob.parents.pop();const meta=[...x.files.values()].find(m=>m.name.startsWith('snapshot-'));x.files.set('unknown',{...meta,id:'unknown',name:'unknown.json'});
 await assert.rejects(new Sync(x.backup,x.drive).manualUpload(async()=> 'cleanup'),/未知文件/);assert.equal(trashCalls(x).length,0);
});
function HASH_TEST(s){return /^[a-f0-9]{64}$/.test(s);}
test('changing accounts during preview refuses upload as well as cleanup',async t=>{
 const x=await fixture(t);await x.run();await removeItem(x);const before=x.calls.length;
 await assert.rejects(new Sync(x.backup,x.drive).manualUpload(async()=>{await x.p.update(s=>{s.plugins['google-drive'].backupAccount.key='different';});return 'cleanup';}),/账户已变更/);assert.equal(x.calls.slice(before).filter(c=>c.method!=='GET').length,0);
});
test('missing historical blobs and invalid ownership refuse cleanup',async t=>{
 const x=await fixture(t);await x.run();const plan=await x.backup.plan(),snapshot=await x.backup.latest();snapshot.files[0].owners=['nonexistent'];snapshot.packageId=x.backup.archive.packageId(snapshot.library,snapshot.files);assert.throws(()=>x.backup.validate(snapshot),/归属/);
 await removeItem(x);const blob=[...x.files.values()].find(m=>HASH_TEST(m.name));x.files.delete(blob.id);await assert.rejects(new Cleanup(x.drive,x.backup).inspect(await x.backup.plan()),/缺少附件/);assert.equal(trashCalls(x).length,0);
});
test('legacy history with no retained items can be cleaned without touching unrelated objects',async t=>{
 const x=await fixture(t),plan=await x.backup.plan();plan.files=plan.files.map(({owners,...f})=>f);plan.packageId=x.backup.archive.packageId(plan.collected.library,plan.files);await x.drive.run(x.backup,plan,await x.drive.scan(x.backup,plan));
 const blob=[...x.files.values()].find(m=>HASH_TEST(m.name));x.files.set('unrelated',{...blob,id:'unrelated',name:'0'.repeat(64)});await removeItem(x);await new Sync(x.backup,x.drive).manualUpload(async p=>{assert.equal(p.summary.files,1);return 'cleanup';});assert.equal(x.files.get('unrelated').trashed,false);
});
test('a concurrent history publication during deletion triggers rollback',async t=>{
 const x=await fixture(t);await x.run();await removeItem(x);let once=true;x.hook(async(u,o,j)=>{if(j?.trashed===true&&once){once=false;const meta=[...x.files.values()].find(m=>m.name.startsWith('snapshot-'));x.files.set('concurrent',{...meta,id:'concurrent'});}});
 await assert.rejects(new Sync(x.backup,x.drive).manualUpload(async()=> 'cleanup'),/变化/);assert([...x.files.values()].every(m=>!m.trashed));assert.equal(await new Cleanup(x.drive,x.backup).pending(),null);
});
test('account switch during cleanup retains recovery journal and never restores into a different account',async t=>{
 const x=await fixture(t);await x.run();await removeItem(x);let once=true;x.hook(async(u,o,j)=>{if(j?.trashed===true&&once){once=false;await x.p.update(s=>{s.plugins['google-drive'].backupAccount.key='different';});}});
 await assert.rejects(new Sync(x.backup,x.drive).manualUpload(async()=> 'cleanup'),/账户已变更/);assert(await new Cleanup(x.drive,x.backup).pending());const attempts=x.calls.length;await assert.rejects(new Cleanup(x.drive,x.backup).recover(),/账户已变更/);assert.equal(x.calls.length,attempts);
 x.hook(null);await x.p.update(s=>{s.plugins['google-drive'].backupAccount.key='account-key';});await new Cleanup(x.drive,x.backup).recover();assert([...x.files.values()].every(m=>!m.trashed));
});
async function synchronizer(t,x,options={}){const sync=new Sync(x.backup,x.drive,options);t.after(()=>sync.close());return sync;}
const until=async(fn)=>{const end=Date.now()+5000;while(!fn()){if(Date.now()>end)throw Error('condition timeout');await new Promise(r=>setTimeout(r,20));}};

test('empty library startup skips automatic sync without cloud calls or a local snapshot',async t=>{
 const x=await fixture(t),base=(await x.store.read()).data;await x.store.commit(base,{...base,items:[]});
 const sync=await synchronizer(t,x,{debounce:20,poll:30});await sync.start();
 await until(()=>sync.state.text==='知识库为空，已跳过自动同步'&&!sync.state.busy);
 assert.equal(x.calls.length,0);assert.equal(await x.backup.latest(),null);assert.equal(sync.state.summary.items,0);
 assert.equal(sync.state.last,undefined);assert.equal(sync.enabled,true);assert.equal(sync.blocked,false);assert.equal(sync.state.error,'');
});

test('clearing a library preserves cloud latest and new items resume automatic sync',async t=>{
 const x=await fixture(t),first=await x.run(),base=(await x.store.read()).data;
 await x.store.commit(base,{...base,items:[]});const priorCalls=x.calls.length,priorFiles=JSON.stringify([...x.files.values()]);
 const sync=await synchronizer(t,x,{debounce:20,poll:30});await sync.start();sync.state.last=first;sync.queue(0);
 await until(()=>sync.state.text==='知识库为空，已跳过自动同步'&&!sync.state.busy);
 assert.equal(x.calls.length,priorCalls);assert.equal(JSON.stringify([...x.files.values()]),priorFiles);
 assert.equal((await x.backup.latest()).packageId,first.packageId);assert.equal(sync.state.last.packageId,first.packageId);
 await fs.writeFile(x.store.root+'/a.md','# added again');const empty=(await x.store.read()).data;await x.store.commit(empty,{...empty,items:base.items});
 await until(()=>sync.state.last.packageId!==first.packageId&&!sync.state.busy);
 sync.close();await until(()=>!sync.state.busy);
 assert.equal((await x.drive.catalog(x.backup)).rows.length,1);assert.equal(sync.enabled,true);
});

test('manual sync still supports an explicitly requested empty snapshot',async t=>{
 const x=await fixture(t),base=(await x.store.read()).data;await x.store.commit(base,{...base,items:[]});
 const sync=await synchronizer(t,x),result=await sync.upload();assert.equal(result.cloudFiles,0);
 assert.equal((await x.drive.catalog(x.backup)).snapshot.library.items.length,0);assert.equal(sync.state.stage,'done');
});

test('metadata-only library items still sync automatically with zero attachments',async t=>{
 const x=await fixture(t),base=(await x.store.read()).data;await x.store.commit(base,{...base,items:[{...base.items[0],files:[]}]});
 const sync=await synchronizer(t,x),result=await sync.upload({automatic:true});assert.equal(result.cloudFiles,0);
 assert.equal((await x.drive.catalog(x.backup)).snapshot.library.items.length,1);
});

test('automatic stale-plan retry skips a library cleared before publication',async t=>{
 const x=await fixture(t),first=await x.run(),check=x.backup.assertCurrent.bind(x.backup);let changed=false;
 x.backup.assertCurrent=async(plan,signal)=>{if(!changed){changed=true;const base=(await x.store.read()).data;await x.store.commit(base,{...base,items:[]});}return check(plan,signal);};
 const sync=await synchronizer(t,x,{settle:1}),calls=x.calls.length,result=await sync.upload({automatic:true});
 assert.equal(result.reason,'empty-library');assert.equal(x.calls.slice(calls).filter(c=>c.method!=='GET').length,0);
 assert.equal((await x.drive.catalog(x.backup)).snapshot.packageId,first.packageId);assert.equal((await x.backup.latest()).packageId,first.packageId);
});
test('cloud catalog downloads the newest validated snapshot and exact binary bytes',async t=>{
 const x=await fixture(t);await x.run();await fs.writeFile(x.store.root+'/a.md',Buffer.alloc(2*1024**2+13,187));await x.run();const c=await x.drive.catalog(x.backup);assert.equal(c.rows[0].bytes,2*1024**2+13);
 const out=x.dir+'/download.bin';await x.drive.download(x.backup,c.key,c.rows[0].remote,out);assert.deepEqual(await fs.readFile(out),await fs.readFile(x.store.root+'/a.md'));assert.equal((await x.drive.catalog(x.backup)).snapshot.packageId,c.snapshot.packageId);
});
test('pull restores a missing registered file and keeps metadata IDs and bytes',async t=>{
 const x=await fixture(t);await x.run();await fs.unlink(x.store.root+'/a.md');const sync=await synchronizer(t,x);const r=await sync.pull();assert.equal(r.length,1);assert.equal(await fs.readFile(x.store.root+'/a.md','utf8'),'# document');assert.equal((await x.store.read()).data.items[0].id,'item');
});
test('pull preserves local edits as original and adds a cloud conflict attachment',async t=>{
 const x=await fixture(t);await x.run();await fs.writeFile(x.store.root+'/a.md','# local edits');const sync=await synchronizer(t,x),r=await sync.pull();assert.equal(r[0].conflict,true);assert.equal(await fs.readFile(x.store.root+'/a.md','utf8'),'# local edits');assert.equal(await fs.readFile(r[0].target,'utf8'),'# document');assert.equal((await x.store.read()).data.items[0].files.length,2);
});
test('pull rejects changed cloud bytes before changing local files',async t=>{
 const x=await fixture(t);await x.run();const c=await x.drive.catalog(x.backup);await fs.unlink(x.backup.object(c.rows[0].sha256));x.hook(async(u,o)=>u.searchParams.get('alt')==='media'&&!x.files.get(u.pathname.split('/').pop()).name.endsWith('.json')?{status:200,headers:{},data:Buffer.from('corruption')}:null);
 const sync=await synchronizer(t,x);await assert.rejects(sync.pull(),/校验/);assert.equal(await fs.readFile(x.store.root+'/a.md','utf8'),'# document');
});
test('realtime saved-file changes debounce, survive a closed dialog, and pause persistently',async t=>{
 const x=await fixture(t);const sync=await synchronizer(t,x,{debounce:30,poll:40});await sync.start();clearTimeout(sync.timer);sync.timer=null;sync.pending=false;await sync.upload();const first=sync.state.last.packageId;
 await fs.writeFile(x.store.root+'/a.md','# edit one');await fs.writeFile(x.store.root+'/a.md','# edit two');await until(()=>sync.state.last.packageId!==first&&!sync.state.busy);assert.equal(sync.state.last.uploaded,1);
 await sync.setEnabled(false);const prior=sync.state.last.packageId;await fs.writeFile(x.store.root+'/a.md','# paused');await new Promise(r=>setTimeout(r,150));assert.equal(sync.state.last.packageId,prior);sync.close();const next=await synchronizer(t,x);await next.start();assert.equal(next.enabled,false);
});
test('a change arriving during upload queues another pass and never runs concurrently',async t=>{
 const x=await fixture(t);const sync=await synchronizer(t,x,{debounce:10,poll:20});await sync.start();clearTimeout(sync.timer);sync.timer=null;sync.pending=false;let changed=false;
 x.hook(async(u)=>{if(!changed&&u.pathname==='/upload/drive/v3/files'){changed=true;await fs.writeFile(x.store.root+'/a.md','# saved during upload');sync.queue();await new Promise(r=>setTimeout(r,35));}});
 await sync.upload();await until(()=>sync.state.last&&sync.state.last.packageId!==undefined&&[...x.files.values()].filter(f=>f.name.startsWith('snapshot-')).length===2&&!sync.state.busy);
 const c=await x.drive.catalog(x.backup);assert.equal(c.rows[0].sha256,crypto.createHash('sha256').update('# saved during upload').digest('hex'));
});
test('external linked file changes are detected by stat fallback',async t=>{
 const x=await fixture(t);const file=x.dir+'/external.md';await fs.writeFile(file,'external');const data=(await x.store.read()).data;await x.store.commit(data,{...data,items:[{...data.items[0],files:[x.store.fileRef(file)]}]});
 const sync=await synchronizer(t,x,{debounce:20,poll:30});await sync.start();clearTimeout(sync.timer);sync.timer=null;sync.pending=false;await sync.upload();const old=sync.state.last.packageId;await fs.writeFile(file,'changed external');await until(()=>sync.state.last.packageId!==old&&!sync.state.busy);assert.equal(sync.state.last.uploaded,1);
});
test('cancelled sync retains pending bytes but does not report done or auto-retry',async t=>{
 const x=await fixture(t);const sync=await synchronizer(t,x);x.hook(async()=>{sync.cancel();return null;});await assert.rejects(sync.upload(),{name:'AbortError'});assert.equal(sync.state.busy,false);assert.equal(sync.state.last,undefined);assert.equal(sync.pending,false);
});
test('catalog follows the committed pointer when content returns to an older snapshot',async t=>{
 const x=await fixture(t);const first=await x.run();await fs.writeFile(x.store.root+'/a.md','second');await x.run();await fs.writeFile(x.store.root+'/a.md','# document');const reverted=await x.run();assert.equal(reverted.packageId,first.packageId);assert.equal((await x.drive.catalog(x.backup)).snapshot.packageId,first.packageId);
});
test('newer cloud content replaces an unchanged local baseline and keeps a rollback copy',async t=>{
 const x=await fixture(t);await x.run();const pointer=await fs.readFile(x.backup.root+'/latest.json');await fs.writeFile(x.store.root+'/a.md','# cloud change');const remote=await x.run();await fs.writeFile(x.store.root+'/a.md','# document');await fs.writeFile(x.backup.root+'/latest.json',pointer);await fs.unlink(x.backup.root+'/sources-'+remote.packageId+'.json');const sync=await synchronizer(t,x);const rows=await sync.pull();assert.equal(rows[0].conflict,false);assert.equal(await fs.readFile(x.store.root+'/a.md','utf8'),'# cloud change');const saved=await fs.readdir(x.backup.root+'/before-pull');assert.equal(await fs.readFile(x.backup.root+'/before-pull/'+saved[0],'utf8'),'# document');
});
test('missing source map imports cloud attachments into managed library storage',async t=>{
 const x=await fixture(t);await x.run();const original=(await x.store.read()).data;await x.store.commit(original,{...original,items:[]});const cloud=await x.drive.catalog(x.backup);await fs.unlink(x.backup.root+'/sources-'+cloud.snapshot.packageId+'.json');const sync=await synchronizer(t,x);await sync.pull();const restored=(await x.store.read()).data.items;assert.equal(restored.length,1);assert.equal(await fs.readFile(x.store.resolveFile(restored[0].files[0]),'utf8'),'# document');assert.match(x.store.resolveFile(restored[0].files[0]),/drive-downloads/);
});
test('pull reattaches removed library items even when their original source mapping remains',async t=>{
 const x=await fixture(t);await x.run();const old=(await x.store.read()).data;await x.store.commit(old,{...old,items:[]});const sync=await synchronizer(t,x);await sync.pull();assert.equal((await x.store.read()).data.items.length,1);
});
test('repeated cloud pull reuses conflict copies and never duplicates restored items',async t=>{
 const x=await fixture(t);await x.run();await fs.writeFile(x.store.root+'/a.md','local');const sync=await synchronizer(t,x);await sync.pull();await sync.pull();assert.equal((await x.store.read()).data.items[0].files.length,2);const old=(await x.store.read()).data;await x.store.commit(old,{...old,items:[]});await sync.pull();await sync.pull();assert.equal((await x.store.read()).data.items.length,1);
});

async function manyFiles(x,count){
 const data=(await x.store.read()).data,refs=[];
 for(let i=0;i<count;i++){const file=x.store.root+'/图片-'+i+'.bin';await fs.writeFile(file,Buffer.from([0,255,13,10,i,128,1]));refs.push(x.store.fileRef(file));}
 await x.store.commit(data,{...data,items:[{...data.items[0],files:refs}]});
}
test('small binary files use four bounded workers, bulk IDs, and verified completion counts',async t=>{
 const x=await fixture(t);await manyFiles(x,12);let active=0,peak=0,decrypts=0;const protect=x.p.protect;
 x.p.protect=async(v,d)=>{if(d)decrypts++;return protect(v,d);};
 x.hook(async(u)=>{if(u.searchParams.get('uploadType')==='multipart'){active++;peak=Math.max(peak,active);await new Promise(r=>setTimeout(r,10));active--;}});
 const plan=await x.backup.plan(),remote=await x.drive.scan(x.backup,plan),progress=[];
 const r=await x.drive.run(x.backup,plan,remote,{onProgress:text=>progress.push(text)});
 assert.equal(r.uploaded,12);assert.equal(peak,4);assert.equal(active,0);assert.ok(decrypts<=2);
 assert.equal(x.calls.filter(c=>c.count===12).length,1);assert.equal(x.calls.filter(c=>c.uploadType==='resumable').length,0);
 assert.ok(progress.some(text=>text.includes('12 / 12')));assert.ok(progress.some(text=>text.includes('4 个并行')));
 const c=await x.drive.catalog(x.backup);assert.equal(c.rows.length,12);
 for(const row of c.rows){const bytes=[...x.sessions.values()].find(s=>s.metadata.id===row.remote.id).bytes;assert.equal(bytes[1],255);assert.equal(bytes.length,7);}
});
test('failed parallel upload aborts and joins siblings before releasing the lock; retry reuses reserved IDs',async t=>{
 const x=await fixture(t);await manyFiles(x,9);let started=0,active=0,aborted=0;
 x.hook(async(u,o)=>{
  if(u.searchParams.get('uploadType')!=='multipart')return;
  const number=++started;active++;
  try{
   if(number===1){await new Promise(r=>setTimeout(r,25));return {status:403,headers:{},data:{}};}
   await new Promise((resolve,reject)=>{const stop=()=>{aborted++;reject(Object.assign(Error('cancel'),{name:'AbortError'}));};if(o.signal.aborted)stop();else o.signal.addEventListener('abort',stop,{once:true});});
  }finally{active--;}
 });
 await assert.rejects(x.run(),/拒绝写入/);assert.equal(started,4);assert.equal(active,0);assert.equal(aborted,3);assert.equal(await x.backup.exists(x.backup.root+'/cloud.lock'),null);
 assert.ok(![...x.files.values()].some(f=>f.name.startsWith('snapshot-')));
 x.hook(null);const r=await x.run();assert.equal(r.uploaded,9);assert.equal(x.calls.filter(c=>c.count===9).length,1);
});
test('lost multipart success response retries the same ID and reads back one intact object',async t=>{
 const x=await fixture(t),transport=x.drive.transport;let lost=false;
 x.drive.transport=async(url,o)=>{const r=await transport(url,o);if(!lost&&new URL(url).searchParams.get('uploadType')==='multipart'){lost=true;throw Object.assign(Error('lost response'),{retryable:true});}return r;};
 const r=await x.run();assert.equal(r.uploaded,1);assert.equal([...x.files.values()].filter(f=>/^[a-f0-9]{64}$/.test(f.name)).length,1);
 assert.equal(x.calls.filter(c=>c.uploadType==='multipart').length,4);
});
test('parallel checkpoint writes are encrypted, serialized and coalesced without losing state',async t=>{
 const x=await fixture(t),session=await x.drive.stateFile(x.backup.libraryId,'account-key'),protect=x.p.protect;let active=0,peak=0,writes=0;
 x.p.protect=async(v,d)=>{if(d)return protect(v,d);active++;peak=Math.max(peak,active);writes++;await new Promise(r=>setTimeout(r,5));try{return await protect(v,d);}finally{active--;}};
 const pending=[];for(let i=0;i<30;i++){session.state['job'+i]={id:'id'+i,sha256:String(i),url:'https://www.googleapis.com/upload/drive/v3/resume/'+i};pending.push(session.save());}
 await Promise.all(pending);const raw=await fs.readFile(path.join(x.p.dir,session.name),'utf8');
 assert.equal(peak,1);assert.ok(writes<5);assert.ok(!raw.includes('googleapis.com'));assert.deepEqual(JSON.parse(await protect(raw,true)),session.state);
});
test('concurrent 401s share one token refresh and reconnect invalidates the short memory cache',async t=>{
 const x=await fixture(t);let decrypts=0;const secrets=x.p.secrets.bind(x.p);
 x.p.secrets=async()=>{decrypts++;await new Promise(r=>setTimeout(r,5));return secrets();};
 x.hook(async(u,o)=>{if(o.headers.Authorization==='Bearer test-token')return {status:401,headers:{},data:{}};});
 await Promise.all(Array.from({length:8},()=>x.drive.list('account-key',"'unused' in parents")));
 assert.equal(x.refresh(),1);assert.ok(decrypts<=3);
 await x.p.update((s,c)=>{s.plugins['google-drive'].backupAccount.connectedAt='new-generation';c.googleBackup.access_token='reconnected-token';});
 assert.equal(await x.drive.token('account-key'),'reconnected-token');
 x.drive.tokenCache.until=0;assert.equal(await x.drive.token('account-key'),'reconnected-token');
 await x.drive.disconnect();await assert.rejects(x.drive.token('account-key'),/账户已变更/);
});
test('rate-limited multipart uploads back off and preserve exact bytes',async t=>{
 const x=await fixture(t);let attempts=0,sleeps=0,clock=0;x.drive.now=()=>clock;x.drive.sleep=async ms=>{sleeps++;clock+=ms;};
 x.hook(async(u)=>u.searchParams.get('uploadType')==='multipart'&&attempts++===0?{status:429,headers:{},data:{}}:null);
 assert.equal((await x.run()).uploaded,1);assert.equal(sleeps,1);assert.ok([...x.sessions.values()].some(s=>s.bytes.toString()==='# document'));
});

test('a real edit during hashing automatically rescans and publishes the new metadata without error banners',async t=>{
 const x=await fixture(t),events=[],sync=await synchronizer(t,x,{settle:1,onState:s=>events.push(s)}),fingerprint=x.backup.fingerprint.bind(x.backup);let changed=false;
 x.backup.fingerprint=async(file,o)=>{const hash=await fingerprint(file,o);if(!changed&&path.resolve(file)===path.resolve(x.store.root,'a.md')){changed=true;const data=(await x.store.read()).data,next=structuredClone(data);next.items[0].title='Edited during scan';await x.store.commit(data,next);}return hash;};
 const r=await sync.upload();assert.equal(r.uploaded,1);assert.equal((await x.drive.catalog(x.backup)).snapshot.library.items[0].title,'Edited during scan');
 assert.ok(events.some(s=>s.stage==='waiting'));assert.ok(events.every(s=>!s.error));assert.equal(sync.state.summary.items,1);
});
test('statistics become ready before any cloud call and survive a cloud failure',async t=>{
 const x=await fixture(t),sync=await synchronizer(t,x);let observed=false;
 x.hook(async()=>{assert.equal(sync.state.summaryState,'ready');assert.equal(sync.state.summary.added,1);assert.equal(sync.state.summary.items,1);observed=true;return {status:403,headers:{},data:{}};});
 await assert.rejects(sync.upload(),/拒绝写入/);assert.ok(observed);assert.equal(sync.state.summaryState,'ready');assert.equal(sync.state.summary.added,1);assert.ok(sync.state.summaryAt);assert.equal(sync.state.last,undefined);
});
test('continuous edits defer with a quiet pending state after bounded retries',async t=>{
 const x=await fixture(t),events=[],sync=await synchronizer(t,x,{settle:1,onState:s=>events.push(s)});sync.enabled=true;let calls=0;
 x.backup.plan=async()=>{calls++;throw Object.assign(Error('changed'),{code:'BACKUP_SOURCE_CHANGED'});};
 const result=await sync.upload();assert.equal(result.deferred,true);assert.equal(calls,3);assert.equal(sync.state.busy,false);assert.equal(sync.state.stage,'waiting');assert.equal(sync.state.error,'');assert.ok(sync.timer);assert.ok(events.every(s=>s.stage!=='error'));
});
test('cancelling while waiting for a rescan stops retries and the queued task',async t=>{
 const x=await fixture(t);let sync,calls=0;sync=await synchronizer(t,x,{settle:100,onState:s=>{if(s.stage==='waiting')sync.cancel();}});sync.enabled=true;
 x.backup.plan=async()=>{calls++;throw Object.assign(Error('changed'),{code:'BACKUP_SOURCE_CHANGED'});};
 await assert.rejects(sync.upload(),{name:'AbortError'});assert.equal(calls,1);assert.equal(sync.pending,false);assert.equal(sync.timer,null);assert.equal(sync.state.error,'');
});
test('opening a local preview calculates statistics without cloud access and preserves an existing auto-upload',async t=>{
 const x=await fixture(t),sync=await synchronizer(t,x);sync.enabled=true;sync.pending=true;
 x.hook(async()=>{throw Error('local preview must not call cloud');});const result=await sync.scan({localOnly:true});
 assert.equal(result.plan.summary.added,1);assert.equal(sync.state.summaryState,'ready');assert.ok(sync.state.summaryAt);assert.equal(x.calls.length,0);assert.ok(sync.timer);
});

test('330 reserved upload IDs survive an actual Windows-encrypted checkpoint and reload',{skip:process.platform!=='win32'},async t=>{
 const x=await fixture(t),Client=require('./ai-client.cjs'),client=new Client(require);x.p.protect=client.protect.bind(client);x.drive.token=async()=> 'synthetic-token';
 const checkpoint=await x.drive.stateFile(x.backup.libraryId,'account-key'),jobs=Array.from({length:330},(_,i)=>({job:'objects:'+String(i).padStart(64,'a'),sha256:String(i).padStart(64,'b')}));
 await x.drive.reserve('account-key',jobs,checkpoint);
 const saved=await fs.readFile(path.join(x.p.dir,checkpoint.name),'utf8');assert.ok(saved.length>32768);assert.ok(!saved.includes('objects:'));
 const restored=await x.drive.stateFile(x.backup.libraryId,'account-key');assert.deepEqual(restored.state,checkpoint.state);assert.equal(Object.keys(restored.state).length,330);
});

test('Drive throttling pauses all later workers until Retry-After elapses',async t=>{
 const x=await fixture(t);let clock=0,calls=0;const sleeps=[],times=[];
 x.drive.now=()=>clock;x.drive.sleep=(ms,signal)=>new Promise((resolve,reject)=>{sleeps.push({ms,resolve});signal?.addEventListener('abort',()=>reject(Object.assign(Error('cancel'),{name:'AbortError'})),{once:true});});
 x.drive.transport=async()=>{times.push(clock);return ++calls===1?{status:429,headers:{'retry-after':'12'},data:{}}:{status:200,headers:{},data:{}};};
 const first=x.drive.request('account-key','https://www.googleapis.com/drive/v3/files');await until(()=>sleeps.length===1);
 const second=x.drive.request('account-key','https://www.googleapis.com/drive/v3/files');await until(()=>sleeps.length===2);
 assert.equal(calls,1);assert.deepEqual(sleeps.map(s=>s.ms),[12000,12000]);clock=12000;sleeps.forEach(s=>s.resolve());await Promise.all([first,second]);assert.deepEqual(times,[0,12000,12000]);
 assert.equal(x.drive.backoff({'retry-after':new Date(clock+8000).toUTCString()},0),8000);
 assert.equal(x.drive.backoff({'retry-after':'nonsense'},2),2000);
});
test('shared rate limit wait is cancellable and never submits a cancelled worker',async t=>{
 const x=await fixture(t),controller=new AbortController();let clock=1000,requests=0;
 x.drive.now=()=>clock;x.drive.retryUntil=11000;
 let ready;const sleeping=new Promise(r=>ready=r);
 x.drive.sleep=(ms,signal)=>new Promise((resolve,reject)=>{ready();signal.addEventListener('abort',()=>reject(Object.assign(Error('stop'),{name:'AbortError'})),{once:true});});
 x.drive.transport=async()=>{requests++;throw Error('unexpected network');};
 const pending=x.drive.request('account-key','https://www.googleapis.com/drive/v3/files',{signal:controller.signal});await sleeping;controller.abort();await assert.rejects(pending,{name:'AbortError'});assert.equal(requests,0);
});
test('permanent upload errors do not reschedule on watcher events; explicit retry recovers',async t=>{
 const x=await fixture(t),sync=await synchronizer(t,x);sync.enabled=true;x.hook(async()=>({status:403,data:{},headers:{}}));
 await assert.rejects(sync.upload(),/拒绝写入/);assert.equal(sync.blocked,true);assert.equal(sync.timer,null);sync.queue(1);assert.equal(sync.timer,null);assert.equal(sync.state.retryAt,null);
 x.hook(null);await sync.upload();assert.equal(sync.blocked,false);assert.equal(sync.state.stage,'done');
});
test('transient failures expose retry time and new edits do not bypass the backoff',async t=>{
 const x=await fixture(t),sync=await synchronizer(t,x);sync.enabled=true;const scan=x.drive.scan.bind(x.drive);
 x.drive.scan=async()=>{throw Object.assign(Error('network interrupted'),{retryable:true,retryAfterMs:45000});};
 await assert.rejects(sync.upload(),/interrupted/);assert(sync.state.retryAt>=Date.now()+44000);const planned=sync.state.retryAt;sync.queue(1);assert.equal(sync.state.retryAt,planned);assert(sync.timer._idleTimeout>43000);
 await sync.setEnabled(false);assert.equal(sync.state.retryAt,null);assert.equal(sync.pending,false);assert.equal(sync.timer,null);sync.cancel();x.drive.scan=scan;
});
test('failed manual cloud listing never starts an unrelated automatic upload',async t=>{
 const x=await fixture(t),sync=await synchronizer(t,x);sync.enabled=true;
 x.drive.catalog=async()=>{throw Object.assign(Error('offline'),{retryable:true});};
 await assert.rejects(sync.catalog(),/offline/);assert.equal(sync.timer,null);assert.equal(sync.pending,false);
});
