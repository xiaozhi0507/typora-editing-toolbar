class KnowledgeLibraryBackupUI {
 constructor(host){this.host=host;window.addEventListener('unload',()=>this.engine?.close(),{once:true});}
 get busy(){return !!this.engine?.state.busy;}
 async prepare(store=this.host.store){
  if(this.preparing)return this.preparing;
  return this.preparing=(async()=>{
   if(this.engine?.backup.store.root===store.root)return this.engine;
   if(this.busy)throw Error('请先完成或暂停同步');this.engine?.close();
   const h=this.host,p=h.toolbar.connections;await p.init();
   const cache=reqnode('path').join(File.option.userDataPath,'editing-toolbar','knowledge-backup-cache');
   const backup=new ETKnowledgeBackup(store,{Managed:ETKnowledgeManaged,Archive:ETKnowledgeArchive,Zip:ETKnowledgeZip,destination:cache});
   this.engine=new ETKnowledgeSync(backup,p.store.backup(),{flush:async()=>{
    if(reqnode('path').resolve(h.rootPath).toLowerCase()!==store.root.toLowerCase())throw Error('知识库已切换');if(h.store?.root===store.root&&h.ui&&!await h.ui.flush())throw Error('知识库尚未保存');h.flushBackupNotes();
   },changed:async()=>{if(h.store?.root===store.root)await h.ui?.refresh();h.graphChanged();},onState:s=>this.render(s)});
   await this.engine.start();return this.engine;
  })().finally(()=>this.preparing=null);
 }
 async boot(){try{const store=new ETKnowledgeStorage(this.host.rootPath,reqnode);if(!await store.io.stat(store.file).catch(()=>null))return;await store.read();await this.prepare(store);}catch(e){this.host.notice('云端同步：'+e.message);}}
 render(s){
  const p=this.host.toolbar.connections;if(!p)return;
  if(!this.indicator){const b=this.indicator=p.node('button','et-drive-sync-indicator');b.type='button';b.innerHTML='<span class="et-drive-sync-ring" aria-hidden="true"></span><span></span>';b.onclick=()=>this.host.openDriveBackup().catch(e=>this.host.notice(e.message));document.body.append(b);}
  this.indicator.hidden=!!this.dialog?.open||!s.busy&&s.stage!=='error';this.indicator.classList.toggle('is-busy',s.busy);this.indicator.lastChild.textContent=s.error||s.text;this.indicator.title='Google Drive · '+(s.error||s.text);this.indicator.setAttribute('aria-label',this.indicator.title);this.update?.(s);
 }
 confirmCleanup(preview,signal){
  const p=this.host.toolbar.connections,{d}=p.form('清理云端备份','et-drive-cleanup'),node=(tag,cls,text)=>p.node(tag,cls,text);
  const body=node('div','et-drive-cleanup-body'),lead=node('p','',preview.summary.localEmpty?'当前知识库为空，是否将以下文献的云端备份移入回收站？':'是否将以下已彻底删除文献的云端备份移入回收站？'),list=node('ul','et-drive-cleanup-list');
  for(const item of preview.documents)list.append(node('li','',item.title));body.append(lead,list);const actions=node('div','et-drive-cleanup-actions');d.append(body,actions);
  return new Promise(resolve=>{
   let done=false;const parent=this.dialog,finish=choice=>{if(done)return;done=true;signal?.removeEventListener('abort',abort);parent?.removeEventListener('close',abort);resolve(choice);if(d.open)d.close();},abort=()=>finish('cancel');
   const cancel=p.button('取消',abort);actions.append(cancel,p.button('仅同步',()=>finish('sync')),p.button('同步并清理',()=>finish('cleanup')));
   d.addEventListener('close',abort,{once:true});parent?.addEventListener('close',abort,{once:true});signal?.addEventListener('abort',abort,{once:true});
   if(signal?.aborted){finish('cancel');d.remove();return;}d.showModal();cancel.focus();
  });
 }
 async show(){
  if(this.dialog?.open){this.dialog.focus();return;}
  const engine=await this.prepare(),h=this.host,p=h.toolbar.connections,service=engine.drive,backup=engine.backup,{d}=p.form('Google Drive 备份','et-drive-backup');this.dialog=d;
  const node=(tag,cls,text)=>p.node(tag,cls,text),controls=[];let isCloud=false,listing=0,refreshPending=false,seenCatalog=null,seenSummary,page=0,avatarKey='';
  const run=fn=>Promise.resolve().then(fn).catch(e=>{if(d.open)engine.emit({error:e.name==='AbortError'?'':e.message,text:e.message,stage:e.name==='AbortError'?'idle':'error'});});
  const button=(label,fn)=>{const b=p.button(label,()=>run(fn));controls.push(b);return b;};
  const header=d.querySelector('.et-plugin-form-head'),heading=header.querySelector('h3'),logo=node('span','et-drive-logo');logo.setAttribute('aria-hidden','true');logo.innerHTML='<svg viewBox="0 0 24 24"><path fill="#2684fc" d="M8 15h16l-4 7H4z"/><path fill="#00ac47" d="M8 1h8L4 22l-4-7z"/><path fill="#ffba00" d="m16 1 8 14h-8L8 1z"/></svg>';heading?.prepend(logo);
  header.dataset.preferencesMove='';header.tabIndex=0;header.setAttribute('aria-label','移动 Google Drive 备份窗口');
  const open=button('查看云端',()=>{const url=engine.state.catalog?.url||engine.state.last?.url;if(url)return reqnode('electron').shell.openExternal(url);});open.classList.add('et-drive-open-cloud');heading?.after(open);
  const tabs=node('div','et-drive-tabs'),body=node('div','et-drive-backup-body'),overview=node('section','et-drive-overview'),cloud=node('section','et-drive-cloud');
  const overviewTab=p.button('同步概览',()=>selectTab(false)),cloudTab=p.button('云端文件',()=>selectTab(true));
  tabs.setAttribute('role','tablist');tabs.setAttribute('aria-label','备份页面');tabs.append(overviewTab,cloudTab);
  for(const [panel,tab,id]of [[overview,overviewTab,'overview'],[cloud,cloudTab,'cloud']]){panel.id='et-drive-'+id;tab.id=panel.id+'-tab';tab.setAttribute('role','tab');tab.setAttribute('aria-controls',panel.id);panel.setAttribute('role','tabpanel');panel.setAttribute('aria-labelledby',tab.id);}
  const source=node('div','et-drive-backup-source');source.append(node('span','','当前知识库'),node('strong','',reqnode('path').basename(backup.store.root)));
  const account=node('div','et-drive-backup-account'),avatar=node('span','et-drive-account-avatar'),accountName=node('strong');avatar.setAttribute('aria-hidden','true');
  const loadProfile=async()=>{try{await service.profile();if(d.open)this.render({...engine.state});}catch{/* A missing photo never blocks backup. */}};
  const login=button('授权备份',()=>engine.job(async options=>{await service.connect(url=>reqnode('electron').shell.openExternal(url),{...options,onProgress:stage=>options.onProgress(({waiting:'等待浏览器授权…',exchanging:'正在验证授权…',verifying:'正在验证账户…',saving:'正在保存授权…'})[stage]||'正在打开浏览器…','authorizing')});engine.emit({catalog:null,last:null,text:'授权成功',stage:'idle'});engine.queue();await config();void loadProfile();}));account.append(avatar,accountName,login);
  const realtime=node('label','et-drive-sync-toggle'),toggle=node('input');toggle.type='checkbox';toggle.setAttribute('role','switch');toggle.setAttribute('aria-label','实时同步');realtime.append(node('span','','实时同步'),toggle);toggle.onchange=()=>run(()=>engine.setEnabled(toggle.checked));
  const preview=node('div','et-drive-backup-preview'),stats=node('div','et-drive-backup-stats');preview.append(stats);
  const setup=node('details','et-drive-backup-setup');setup.open=true;setup.append(node('summary','','账户设置'));
  const configure=button('导入 OAuth 配置',()=>engine.job(async()=>{
   const picked=await JSBridge.invoke('dialog.showOpenDialog',{title:'选择 Google 桌面应用 OAuth JSON',properties:['openFile'],filters:[{name:'OAuth JSON',extensions:['json']}]});if(!picked?.filePaths?.[0])return;
   const fs=reqnode('fs').promises,file=picked.filePaths[0];if((await fs.stat(file)).size>64000)throw Error('配置文件过大');await p.store.configureGoogle(await fs.readFile(file,'utf8'));engine.emit({catalog:null,last:null,text:'配置已保存，请授权备份',stage:'idle'});await config();
  }));
  const settings=button('Google 授权设置',()=>reqnode('electron').shell.openExternal('https://console.cloud.google.com/auth/audience'));
  const disconnect=button('断开授权',()=>engine.job(async()=>{await service.disconnect();engine.emit({catalog:null,last:null,text:'已断开备份授权',stage:'idle'});await config();}));setup.append(configure,settings,disconnect);overview.append(source,account,realtime,preview,setup);
  const search=node('input','et-drive-cloud-search');search.placeholder='查找云端文件';search.setAttribute('aria-label','查找云端文件');
  const filter=node('select','et-drive-cloud-filter');filter.setAttribute('aria-label','文件类型');for(const [value,label]of [['all','全部文件'],['document','文档'],['image','图片'],['other','其他附件']]){const option=node('option','',label);option.value=value;filter.append(option);}
  const tools=node('div','et-drive-cloud-tools'),files=node('div','et-drive-cloud-files'),pager=node('div','et-drive-cloud-pager'),pageInfo=node('span'),size=40;
  const searchField=node('div','et-drive-search-field'),searchIcon=node('span','et-drive-search-icon');searchIcon.setAttribute('aria-hidden','true');searchIcon.innerHTML='<svg viewBox="0 0 24 24"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/></svg>';searchField.append(searchIcon,search);
  const selectField=(input,cls)=>{const wrap=node('div','et-drive-select-field '+cls),arrow=node('span');arrow.setAttribute('aria-hidden','true');arrow.innerHTML='<svg viewBox="0 0 24 24"><path d="m7 10 5 5 5-5"/></svg>';wrap.append(input,arrow);return wrap;};
  const previous=p.button('上一页',()=>{page--;drawFiles();}),next=p.button('下一页',()=>{page++;drawFiles();});pager.append(pageInfo,previous,next);searchField.append(selectField(filter,'et-drive-type-field'));tools.append(searchField);cloud.append(tools,files,pager);
  const footer=node('div','et-drive-backup-actions'),status=node('div','et-drive-footer-status');status.setAttribute('role','status');status.setAttribute('aria-live','polite');
  const scan=button('扫描变化',()=>engine.scan()),upload=button('立即同步',()=>isCloud?engine.pull({all:true}):engine.manualUpload((preview,signal)=>this.confirmCleanup(preview,signal)));upload.classList.add('et-drive-backup-primary');
  const cancel=p.button('暂停',()=>engine.cancel());footer.append(status,scan,upload,cancel);body.append(overview,cloud);d.append(tabs,body,footer);
  const refresh=async()=>{if(!isCloud||!d.open||!service.account())return;if(engine.state.busy){refreshPending=true;return;}refreshPending=false;listing++;try{await engine.catalog({all:true});}catch(e){if(d.open&&e.name!=='AbortError')engine.emit({error:e.message,text:e.message,stage:'error'});}finally{listing--;}};
  const selectTab=value=>{isCloud=value;d.dataset.view=value?'cloud':'overview';overview.hidden=value;cloud.hidden=!value;scan.hidden=value;for(const [tab,selected]of [[overviewTab,!value],[cloudTab,value]]){tab.setAttribute('aria-selected',String(selected));tab.tabIndex=selected?0:-1;}body.scrollTop=0;upload.title=value?'云端 → 本地':'本地 → 云端';upload.setAttribute('aria-description',upload.title);if(value)void refresh();else refreshPending=false;this.update?.(engine.state);};
  tabs.onkeydown=e=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();const target=e.key==='Home'?overviewTab:e.key==='End'?cloudTab:e.target===overviewTab?cloudTab:overviewTab;target.click();target.focus();}};
  const kind=path=>/\.(md|txt|pdf|docx?|epub|html?|rtf)$/i.test(path)?'document':/\.(png|jpe?g|gif|svg|webp|bmp|tiff?)$/i.test(path)?'image':'other';
  const drawFiles=()=>{
   const catalog=engine.state.catalog,rows=catalog?.snapshots?catalog.rows:null;files.replaceChildren();if(!rows){pager.hidden=true;cloudTab.textContent='云端文件';return;}
   const query=search.value.trim().toLowerCase(),filtered=rows.filter(f=>(filter.value==='all'||kind(f.path)===filter.value)&&[f.path,...f.titles].some(v=>v.toLowerCase().includes(query)));
   cloudTab.textContent='云端文件 · '+rows.length;const pages=Math.max(1,Math.ceil(filtered.length/size));page=Math.max(0,Math.min(page,pages-1));
   for(const f of filtered.slice(page*size,(page+1)*size)){const row=node('div','et-drive-cloud-file'),icon=node('span','et-drive-file-icon',kind(f.path)==='image'?'▧':kind(f.path)==='document'?'≡':'◇'),copy=node('div','et-drive-file-copy');icon.setAttribute('aria-hidden','true');copy.title=f.path;copy.append(node('strong','',f.path.split('/').pop()),node('small','',[f.titles.join('、')||f.path.split('/').slice(2,-1).join('/'),new Date(f.createdAt).toLocaleString()].filter(Boolean).join(' · ')));row.append(icon,copy,node('span','et-drive-file-size',f.bytes<1024?f.bytes+' B':f.bytes<1024**2?(f.bytes/1024).toFixed(1)+' KB':(f.bytes/1024**2).toFixed(1)+' MB'));files.append(row);}
   if(!filtered.length)files.append(node('p','et-drive-empty',rows.length?'没有匹配文件':'云端备份中没有附件文件'));pageInfo.textContent=filtered.length?'共 '+filtered.length+' 个 · '+(page*size+1)+'–'+Math.min(filtered.length,(page+1)*size):'0 个文件';pager.hidden=false;previous.disabled=page===0;next.disabled=page>=pages-1;
  };
  search.oninput=filter.onchange=()=>{page=0;drawFiles();};
  this.update=s=>{
   if(!d.open)return;const acc=service.account();accountName.textContent=acc?.account||'尚未授权备份';login.textContent=acc?'更换账户':'授权备份';disconnect.hidden=!acc;
   const match=[...(p.store.state().plugins['google-drive']?.accounts||[]),...(p.store.state().plugins['google-drive']?.codexAccounts||[])].find(a=>a.account?.toLowerCase()===acc?.account?.toLowerCase());const photo=acc?.avatar||match?.avatar||'',signature=JSON.stringify([acc?.key,photo]);
   if(signature!==avatarKey){avatarKey=signature;avatar.replaceChildren();avatar.textContent=acc?.displayName?.slice(0,1)||acc?.account?.slice(0,1).toUpperCase()||'G';try{const url=new URL(photo);if(url.protocol==='https:'&&!url.username&&!url.password&&!url.port&&/(^|\.)(googleusercontent|ggpht)\.com$/.test(url.hostname)){const img=node('img');img.alt='';img.draggable=false;img.referrerPolicy='no-referrer';img.onload=()=>{if(avatar.contains(img))for(const child of [...avatar.childNodes])if(child!==img)child.remove();};img.onerror=()=>img.remove();img.src=url.href;avatar.append(img);}}catch{}}
   for(const b of controls)b.disabled=s.busy;for(const b of [scan,upload])b.disabled=s.busy||!acc;toggle.disabled=s.busy;toggle.checked=engine.enabled;cancel.hidden=!s.busy;
   open.hidden=!(s.catalog?.url||s.last?.url);status.textContent=s.error||s.text||(isCloud?'云端 → 本地':'本地 → 云端');status.title=status.textContent;status.dataset.tone=s.error?'error':s.busy?'busy':s.stage==='done'?'done':'idle';
   const summary=JSON.stringify(s.summary||{});if(summary!==seenSummary){seenSummary=summary;stats.replaceChildren();for(const [label,value]of [['条目',s.summary?.items??'…'],['新增文件',s.summary?.added??'…'],['修改文件',s.summary?.modified??'…'],['未变文件',s.summary?.unchanged??'…']]){const cell=node('div');cell.append(node('strong','',String(value)),node('span','',label));stats.append(cell);}}
   if(seenCatalog!==s.catalog){seenCatalog=s.catalog;page=0;drawFiles();}
   d.setAttribute('aria-busy',String(s.busy));if(!s.busy&&refreshPending&&isCloud){refreshPending=false;queueMicrotask(()=>void refresh());}
  };
  const config=async()=>{configure.textContent=(await p.store.secrets()).googleConfig?'更换 OAuth 配置':'导入 OAuth 配置';this.render({...engine.state});};
  let disposeMovement;
  // A queued close event from an old instance must not detach a reopened window.
  d.addEventListener('close',()=>{disposeMovement?.();refreshPending=false;if(listing)engine.cancel();if(this.dialog===d){this.update=null;this.dialog=null;this.render(engine.state);}});
  selectTab(false);d.showModal();disposeMovement=attachMovablePreferences(d,()=>{},{kind:'drive-backup',minWidth:360,minHeight:320});await config();
  if(service.account()&&!engine.state.last)try{engine.state.last=await backup.json(reqnode('path').join(backup.root,'cloud-'+service.account().key.slice(0,24)+'.json'));}catch{}
  this.render({...engine.state});upload.focus();void loadProfile();if(!engine.state.busy&&!engine.state.summaryAt)void engine.scan({localOnly:true}).catch(()=>{});
 }
}

