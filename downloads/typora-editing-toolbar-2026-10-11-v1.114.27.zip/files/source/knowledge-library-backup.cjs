'use strict';
// Immutable, content-addressed backups. A snapshot is published only after every
// referenced byte has been copied and verified. Cloud transport is independent.
class KnowledgeLibraryBackup {
  constructor(store,{Managed,Archive,Zip,destination}) {
    this.store=store;this.io=store.io;this.path=store.path;this.crypto=store.crypto;
    this.managed=new Managed(store);this.archive=new Archive(store,{Managed,Zip});
    this.destination=this.path.resolve(destination);
    this.libraryId=this.digest(this.path.resolve(store.root).toLowerCase()).slice(0,24);
    this.root=this.path.join(this.destination,'Typora知识库备份',this.libraryId);
  }
  digest(value){return this.crypto.createHash('sha256').update(value).digest('hex');}
  check(signal){if(signal?.aborted)throw Object.assign(Error('已取消备份'),{name:'AbortError'});}
  object(hash,root=this.root){if(!/^[a-f0-9]{64}$/.test(hash))throw Error('备份校验值无效');return this.path.join(root,'objects',hash);}
  async exists(file){try{return await this.managed.regular(file);}catch(e){if(e.code==='ENOENT')return null;throw e;}}
  async json(file){const stat=await this.managed.regular(file);if(!stat.isFile()||stat.size>this.archive.limits.json)throw Error('备份清单格式或大小无效');return JSON.parse(await this.io.readFile(file,'utf8'));}
  async fingerprint(file,{signal,expected,output}={}){
    this.check(signal);const before=await this.managed.regular(file);
    if(!before.isFile()||expected&&(before.size!==expected.bytes||before.mtimeMs!==expected.mtime))throw this.sourceChanged('备份期间文件已变化，请重新扫描：'+this.path.basename(file));
    const hash=this.crypto.createHash('sha256'),md5=this.crypto.createHash('md5'),input=await this.io.open(file,'r');let size=0;
    try{
      const buffer=new Uint8Array(128*1024);
      for(;;){this.check(signal);const {bytesRead}=await input.read(buffer,0,buffer.length,null);if(!bytesRead)break;
        size+=bytesRead;if(size>before.size)throw this.sourceChanged('备份期间文件已变化');const chunk=buffer.subarray(0,bytesRead);hash.update(chunk);md5.update(chunk);if(output)await output.writeFile(chunk);
      }
      const after=await input.stat();if(size!==before.size||after.size!==before.size||after.mtimeMs!==before.mtimeMs)throw this.sourceChanged('备份期间文件已变化，请重新扫描：'+this.path.basename(file));
    }finally{await input.close();}
    return {bytes:size,sha256:hash.digest('hex'),md5:md5.digest('hex'),mtime:before.mtimeMs};
  }
  validate(snapshot,{anyLibrary=false}={}){
    if(snapshot?.format!=='typora-knowledge-backup'||snapshot.version!==1||!(/^[a-f0-9]{24}$/).test(snapshot.libraryId)||!anyLibrary&&snapshot.libraryId!==this.libraryId||!Array.isArray(snapshot.files)||snapshot.files.length>this.archive.limits.files)throw Error('备份清单不属于当前知识库，或格式无效');
    this.store.validate(snapshot.library);const seen=new Set(),items=new Set(snapshot.library.items.map(i=>i.id));let total=0;
    for(const f of snapshot.files){this.archive.safe(f.path);const key=f.path.toLowerCase();
      if(!f.path.startsWith('data/')||seen.has(key)||!Number.isSafeInteger(f.bytes)||f.bytes<0)throw Error('备份文件清单无效');
      if(f.owners!==undefined&&(!Array.isArray(f.owners)||!f.owners.length||new Set(f.owners).size!==f.owners.length||f.owners.some(id=>!items.has(id))))throw Error('备份附件归属无效');
      this.object(f.sha256);seen.add(key);total+=f.bytes;
    }
    if(total>this.archive.limits.bytes||snapshot.packageId!==this.archive.packageId(snapshot.library,snapshot.files))throw Error('备份清单校验失败');
    const byPath=new Map(snapshot.files.map(f=>[f.path.toLowerCase(),f]));
    for(const item of snapshot.library.items)for(const ref of item.files)if(ref.linkType!=='url'){
      const file=byPath.get(ref.path.toLowerCase());if(!ref.relative||!file||file.owners&&!file.owners.includes(item.id))throw Error('备份缺少条目附件或归属不符');
    }
    return snapshot;
  }
  async latest(){
    const pointer=this.path.join(this.root,'latest.json');if(!await this.exists(pointer))return null;
    const p=await this.json(pointer);if(p.version!==1||!/^snapshot-[a-f0-9]{64}\.json$/.test(p.snapshot))throw Error('最新备份索引损坏，原备份已保留');
    return this.validate(await this.json(this.path.join(this.root,'snapshots',p.snapshot)));
  }
  sourceChanged(message){return Object.assign(Error(message),{code:'BACKUP_SOURCE_CHANGED'});}
  sameSource(a,b){
    // Metrics caches and reading history can update while hashing attachments.
    // Capture their start-of-scan values, then sync newer metadata next time.
    // Titles, fields, membership and file references still invalidate the plan.
    const content=data=>{const {revision,updatedAt,...rest}=data;return {...rest,items:data.items.map(item=>{const {metrics,last,lastFile,notes,...saved}=item;return saved;})};};
    return this.store.hash(content(a))===this.store.hash(content(b));
  }
  async plan({signal,onProgress=()=>{},onSummary=()=>{}}={}){
    this.check(signal);onSummary({items:(await this.store.read()).data.items.length},false);
    await this.managed.regular(this.destination);
    if(this.managed.inside(this.store.root,this.root)||this.managed.inside(this.root,this.store.root))throw Error('备份位置不能放在当前知识库内，也不能包含当前知识库');
    const collected=await this.archive.collect({signal,onProgress}),files=[];
    for(const f of [...collected.files.values()].sort((a,b)=>a.entry.localeCompare(b.entry))){
      if(this.managed.inside(this.root,f.file))throw Error('知识库条目引用了备份目录，请选择其他备份位置');
      onProgress('正在校验：'+this.path.basename(f.file),'scanning');const hash=await this.fingerprint(f.file,{signal,expected:f});
      f.sha256=hash.sha256;f.md5=hash.md5;files.push({path:f.entry,bytes:f.bytes,sha256:hash.sha256,owners:[...f.owners].sort()});
    }
    const previous=await this.latest(),old=new Map((previous?.files||[]).map(f=>[f.path,f])),current=new Set(files.map(f=>f.path)),missing=new Set(),verified=new Set();
    for(const f of files){this.check(signal);if(verified.has(f.sha256))continue;verified.add(f.sha256);const target=this.object(f.sha256);
      if(!await this.exists(target))missing.add(f.sha256);
      else {onProgress('正在检查已有备份…','scanning');const actual=await this.fingerprint(target,{signal});if(actual.sha256!==f.sha256||actual.bytes!==f.bytes)missing.add(f.sha256);}
    }
    if(!this.sameSource((await this.store.read()).data,collected.initial))throw this.sourceChanged('扫描期间知识库内容已更新');
    const packageId=this.archive.packageId(collected.library,files);
    const unique=new Map(files.map(f=>[f.sha256,f]));
    const plan={collected,files,missing,previousId:previous?.packageId||null,packageId,root:this.root,
      summary:{items:collected.library.items.length,files:files.length,bytes:collected.total,
        added:files.filter(f=>!old.has(f.path)).length,modified:files.filter(f=>old.has(f.path)&&old.get(f.path).sha256!==f.sha256).length,
        removed:(previous?.files||[]).filter(f=>!current.has(f.path)).length,unchanged:files.filter(f=>old.get(f.path)?.sha256===f.sha256).length,
        copyFiles:missing.size,copyBytes:[...missing].reduce((n,h)=>n+unique.get(h).bytes,0),metadataChanged:previous?.packageId!==packageId}};
    onSummary(plan.summary,true);return plan;
  }
  async mkdir(folder){await this.io.mkdir(folder,{recursive:true});await this.managed.regular(folder);}
  async atomic(file,contents){
    await this.mkdir(this.path.dirname(file));const tmp=file+'.'+this.crypto.randomUUID()+'.partial';let handle;
    try{handle=await this.io.open(tmp,'wx');await handle.writeFile(contents);await handle.sync();await handle.close();handle=null;await this.io.rename(tmp,file);}
    finally{if(handle)await handle.close().catch(()=>{});await this.io.unlink(tmp).catch(()=>{});}
  }
  async lock(name='backup.lock'){
    if(!['backup.lock','cloud.lock'].includes(name))throw Error('备份锁名称无效');
    await this.mkdir(this.root);const file=this.path.join(this.root,name);let handle;
    const busy=()=>Error('此备份目录已有任务正在运行；请确认其他窗口已结束备份');
    try{handle=await this.io.open(file,'wx');}catch(e){
      if(e.code!=='EEXIST')throw e;
      // Serialize stale-lock recovery. Never steal from an active or unknown PID.
      let guard;const guardFile=file+'.recover';
      try{guard=await this.io.open(guardFile,'wx');}catch{throw busy();}
      try{
        let previous;try{previous=await this.json(file);}catch{throw busy();}
        if(!Number.isInteger(previous.pid)||previous.pid<=0)throw busy();
        let dead=false;try{this.store.process.kill(previous.pid,0);}catch(error){dead=error.code==='ESRCH';}
        if(!dead)throw busy();await this.io.unlink(file);
        try{handle=await this.io.open(file,'wx');}catch(error){if(error.code==='EEXIST')throw busy();throw error;}
      }finally{await guard.close();await this.io.unlink(guardFile);}
    }
    try{await handle.writeFile(JSON.stringify({pid:this.store.process.pid,started:new Date().toISOString()}));}
    catch(e){await handle.close();await this.io.unlink(file);throw e;}
    return async()=>{await handle.close();await this.io.unlink(file);};
  }
  async assertCurrent(plan,signal){
    this.check(signal);if(plan.root!==this.root)throw Error('备份计划不属于当前目录');if(!this.sameSource((await this.store.read()).data,plan.collected.initial))throw this.sourceChanged('知识库内容已更新');
    for(const f of plan.collected.files.values()){this.check(signal);const stat=await this.managed.regular(f.file);if(stat.size!==f.bytes||stat.mtimeMs!==f.mtime)throw this.sourceChanged('扫描后文件已变化，请重新扫描：'+this.path.basename(f.file));}
  }
  async run(plan,{signal,onProgress=()=>{}}={}){
    await this.assertCurrent(plan,signal);const release=await this.lock();let copied=0;
    try{
      if((await this.latest())?.packageId!==(plan.previousId||undefined))throw Object.assign(Error('备份记录已在其他窗口更新'),{code:'BACKUP_PLAN_STALE'});
      const readme=this.path.join(this.root,'README.txt'),help='Typora 知识库实时备份\n\nobjects 保存原始文件字节，snapshots 保存条目和 SHA-256 清单。\n请通过 Typora 的“知识库 → 我的文库 → Google Drive 备份 → 云端文件”刷新列表和下载更新。旧快照继续保留；不要直接修改 objects 或 snapshots。\n';
      if(await this.io.readFile(readme,'utf8').catch(e=>{if(e.code==='ENOENT')return '';throw e;})!==help)await this.atomic(readme,help);
      if(!plan.summary.metadataChanged&&!plan.missing.size)return {...plan.summary,copied:0,root:this.root,unchanged:true};
      const done=new Set();
      for(const f of plan.collected.files.values()){
        this.check(signal);if(!plan.missing.has(f.sha256)||done.has(f.sha256))continue;
        const target=this.object(f.sha256);await this.mkdir(this.path.dirname(target));const tmp=target+'.'+this.crypto.randomUUID()+'.partial';let handle;
        try{
          onProgress('正在备份 '+(copied+1)+' / '+plan.missing.size+'：'+this.path.basename(f.file),'copying');
          handle=await this.io.open(tmp,'wx');const written=await this.fingerprint(f.file,{signal,expected:f,output:handle});await handle.sync();await handle.close();handle=null;
          if(written.sha256!==f.sha256)throw this.sourceChanged('文件内容已变化，请重新扫描：'+this.path.basename(f.file));
          const verified=await this.fingerprint(tmp,{signal});if(verified.sha256!==f.sha256||verified.bytes!==f.bytes)throw Error('备份写入校验失败');
          this.check(signal);await this.io.rename(tmp,target);done.add(f.sha256);copied++;
        }finally{if(handle)await handle.close().catch(()=>{});await this.io.unlink(tmp).catch(()=>{});}
      }
      await this.assertCurrent(plan,signal);
      for(const f of new Map(plan.files.map(f=>[f.sha256,f])).values()){
        const verified=await this.fingerprint(this.object(f.sha256),{signal});if(verified.sha256!==f.sha256||verified.bytes!==f.bytes)throw Error('备份文件已变化，请重新扫描');
      }
      const snapshot={format:'typora-knowledge-backup',version:1,libraryId:this.libraryId,packageId:plan.packageId,createdAt:new Date().toISOString(),library:plan.collected.library,files:plan.files};
      const text=JSON.stringify(snapshot);if(new TextEncoder().encode(text).length>this.archive.limits.json)throw Error('备份清单超过 16 MB');
      const name='snapshot-'+plan.packageId+'.json';onProgress('正在保存备份记录…','saving');this.check(signal);
      // Keep the first timestamp for an identical immutable snapshot.
      const snapshotPath=this.path.join(this.root,'snapshots',name);
      if(!await this.exists(snapshotPath))await this.atomic(snapshotPath,text);
      else if(this.validate(await this.json(snapshotPath)).packageId!==plan.packageId)throw Error('已有备份清单校验失败');
      await this.atomic(this.path.join(this.root,'latest.json'),JSON.stringify({version:1,snapshot:name}));
      return {...plan.summary,copied,root:this.root,snapshot:this.path.join(this.root,'snapshots',name),createdAt:snapshot.createdAt};
    }finally{await release();}
  }
  async exportSnapshot(file,folder,{signal,onProgress=()=>{}}={}){
    if(this.path.basename(this.path.dirname(file))!=='snapshots')throw Error('请从备份目录的 snapshots 文件夹选择备份清单');
    const snapshot=this.validate(await this.json(file),{anyLibrary:true}),files=new Map(),root=this.path.dirname(this.path.dirname(file));let total=0;
    for(const f of snapshot.files){this.check(signal);onProgress('正在验证恢复文件：'+this.path.basename(f.path),'scanning');const source=this.object(f.sha256,root),actual=await this.fingerprint(source,{signal});
      if(actual.sha256!==f.sha256||actual.bytes!==f.bytes)throw Error('恢复校验失败，文件损坏：'+f.path);
      files.set(f.path,{file:source,entry:f.path,bytes:f.bytes,mtime:actual.mtime,sha256:f.sha256});total+=f.bytes;
    }
    return this.archive.pack({library:snapshot.library,files,total},folder,{signal,onProgress});
  }
}
module.exports=KnowledgeLibraryBackup;
