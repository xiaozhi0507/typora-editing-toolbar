'use strict';
const authorize=require('./ai-plugin-oauth.cjs');
const Cleanup=require('./knowledge-drive-cleanup.cjs');
const catalogAll=require('./knowledge-drive-catalog.cjs');
const SCOPE='https://www.googleapis.com/auth/drive.file';
const API='https://www.googleapis.com/drive/v3/';
const FIELDS='id,name,mimeType,size,md5Checksum,sha256Checksum,parents,trashed,appProperties,createdTime';
const SMALL_UPLOAD=4*1024**2,UPLOAD_WORKERS=4;
const cancelled=()=>Object.assign(Error('已取消备份'),{name:'AbortError'});
class DriveBackup {
  constructor(plugins,{request,sleep,now=()=>Date.now()}={}){this.now=now;this.retryUntil=0;this.plugins=plugins;this.req=plugins.req;this.fs=plugins.fs;this.path=plugins.path;this.crypto=plugins.crypto;this.Buffer=plugins.Buffer;this.transport=request||this.http.bind(this);this.sleep=sleep||((ms,signal)=>new Promise((resolve,reject)=>{const abort=()=>{clearTimeout(timer);reject(cancelled());};const timer=setTimeout(()=>{signal?.removeEventListener('abort',abort);resolve();},ms);if(signal?.aborted)abort();else signal?.addEventListener('abort',abort,{once:true});}));}
  account(){return this.plugins.state().plugins['google-drive']?.backupAccount||null;}
  async profile({signal}={}){
    const account=this.account();if(!account)return null;
    if(account.profileCheckedAt>Date.now()-86400000)return account;
    const user=(await this.request(account.key,API+'about?fields=user(emailAddress,permissionId,photoLink,displayName)',{signal})).data?.user;
    if(!user?.emailAddress||user.emailAddress.toLowerCase()!==account.account.toLowerCase()||account.providerId&&user.permissionId!==account.providerId)throw Error('备份账户资料不匹配');
    await this.plugins.update(s=>{this.check(signal,account.key);const a=s.plugins['google-drive']?.backupAccount;if(a?.key!==account.key)throw Error('备份账户已变更');Object.assign(a,{avatar:user.photoLink||'',displayName:user.displayName||'',profileCheckedAt:Date.now()});});return this.account();
  }
  async catalogAll(backup,options){return catalogAll(this,backup,options);}
  check(signal,key){if(signal?.aborted)throw cancelled();if(key&&this.account()?.key!==key)throw Error('备份账户已变更，请重新扫描');}
  async connect(open,{signal,onProgress,timeout=180000}={}){
    const p=this.plugins,config=(await p.secrets()).googleConfig;if(!config)throw Error('请先导入 Google 桌面应用 OAuth 配置');
    return authorize(this.req,open,{authorizeURL:'https://accounts.google.com/o/oauth2/v2/auth',params:{client_id:config.client_id,scope:SCOPE,access_type:'offline',prompt:'consent select_account'},signal,onProgress,timeout},async({signal,progress,...form})=>{
      const tokens=await p.loginStep(progress,'exchanging',()=>p.transport('https://oauth2.googleapis.com/token',{signal,form:{...config,...form,grant_type:'authorization_code'}}));
      if(!tokens.access_token||!tokens.refresh_token||tokens.scope&&!tokens.scope.split(' ').includes(SCOPE))throw Error('未取得备份文件授权，请重新登录并同意访问');
      const user=(await p.loginStep(progress,'verifying',()=>p.transport(API+'about?fields=user(emailAddress,permissionId,photoLink,displayName)',{signal,token:tokens.access_token}))).user;
      if(!user?.emailAddress||!user.permissionId)throw Error('无法验证 Google 备份账户');
      const account={key:this.crypto.createHash('sha256').update(config.client_id+'\n'+user.permissionId).digest('hex'),account:user.emailAddress,providerId:user.permissionId,avatar:user.photoLink||'',displayName:user.displayName||'',profileCheckedAt:Date.now(),connectedAt:new Date().toISOString()};
      await p.loginStep(progress,'saving',()=>p.update((s,c)=>{this.check(signal);if(c.googleConfig?.client_id!==config.client_id)throw Error('OAuth 配置已更换，请重新登录');
        c.googleBackup={...tokens,client_id:config.client_id,key:account.key,expiresAt:Date.now()+(Number(tokens.expires_in)||0)*1000};s.plugins['google-drive']={...s.plugins['google-drive'],backupAccount:account};
      }));return account;
    });
  }
  async disconnect(){this.tokenCache=null;await this.plugins.update((s,c)=>{delete c.googleBackup;if(s.plugins['google-drive'])delete s.plugins['google-drive'].backupAccount;});}
  credentialGeneration(key){return key+':'+(this.account()?.connectedAt||'');}
  async token(key,signal,force=false,rejectedToken){
    this.check(signal,key);const generation=this.credentialGeneration(key),cached=this.tokenCache;
    if(cached?.generation===generation&&cached.until>Date.now()&&(!force||rejectedToken&&cached.access_token!==rejectedToken))return cached.access_token;
    const pending=this.tokenPending;
    if(pending?.generation===generation){
      await pending.promise;this.check(signal,key);
      return this.token(key,signal,force,rejectedToken);
    }
    const job={generation};this.tokenPending=job;
    job.promise=(async()=>{
      const value=await this.loadToken(key,signal,force);
      this.check(signal,key);if(this.credentialGeneration(key)!==generation)throw Error('备份授权已变更，请重新登录');
      this.tokenCache={generation,access_token:value.access_token,until:Math.min(Date.now()+30000,value.expiresAt-60000)};
      return value.access_token;
    })();
    try{return await job.promise;}finally{if(this.tokenPending===job)this.tokenPending=null;}
  }
  async loadToken(key,signal,force){
    const p=this.plugins,c=await p.secrets(),value=c.googleBackup;
    if(!value?.refresh_token||value.key!==key||value.client_id!==c.googleConfig?.client_id)throw Error('请先授权 Google Drive 备份');
    if(!force&&value.expiresAt>Date.now()+60000)return value;
    return p.locked(async()=>{
      this.check(signal,key);const fresh=await p.secrets(),saved=fresh.googleBackup,config=fresh.googleConfig;
      if(saved?.key!==key||!config||saved.client_id!==config.client_id)throw Error('备份授权已变更，请重新登录');
      if(saved.access_token!==value.access_token&&saved.expiresAt>Date.now()+60000)return saved;
      const tokens=await p.transport('https://oauth2.googleapis.com/token',{signal,form:{...config,refresh_token:saved.refresh_token,grant_type:'refresh_token'}});
      this.check(signal,key);if(!tokens.access_token)throw Error('备份授权已过期，请重新授权；测试状态的应用需要改为正式发布');
      fresh.googleBackup={...saved,...tokens,expiresAt:Date.now()+(Number(tokens.expires_in)||0)*1000};await p.write('accounts.dpapi',await p.protect(JSON.stringify(fresh)));return fresh.googleBackup;
    });
  }
  url(value){const u=new URL(value);if(u.origin!=='https://www.googleapis.com'||u.username||u.password||u.hash||!/^\/(?:upload\/)?drive\/v3\//.test(u.pathname))throw Error('拒绝非 Google Drive 官方上传地址');return u;}
  http(value,{method='GET',headers={},body,signal,timeout=60000,raw=false}={}){
    const u=this.url(value);return new Promise((resolve,reject)=>{
      let request,agent,done=false;const controller=new AbortController();
      const finish=(error,result)=>{if(done)return;done=true;if(error?.retryable)this.plugins.network.invalidate();clearTimeout(timer);signal?.removeEventListener('abort',abort);controller.abort();request?.destroy();agent?.destroy();error?reject(error):resolve(result);};
      const abort=()=>finish(cancelled()),timer=setTimeout(()=>finish(Object.assign(Error('Google Drive 请求超时，可重试继续备份'),{retryable:true})),timeout);
      if(signal?.aborted)return abort();signal?.addEventListener('abort',abort,{once:true});
      (async()=>{agent=await this.plugins.network.agent(u.href,controller.signal);if(done){agent.destroy();return;}
        request=this.req('https').request(u,{method,agent,headers:{Accept:'application/json','User-Agent':'Typora-Editing-Toolbar',...headers,...(body?{'Content-Length':body.length}:method==='PUT'?{'Content-Length':0}:{})}},res=>{
          let size=0,chunks=[];res.on('data',chunk=>{size+=chunk.length;if(size>4*1024**2)finish(Error('Google Drive 响应过大'));else chunks.push(chunk);});
          res.on('error',()=>finish(Object.assign(Error('Google Drive 连接中断，可重试继续备份'),{retryable:true})));
          res.on('end',()=>{let data;try{const bytes=this.Buffer.concat(chunks);data=raw&&res.statusCode<300?bytes:bytes.length?JSON.parse(bytes.toString('utf8')):null;}catch{return finish(Error('Google Drive 返回无效响应'));}finish(null,{status:res.statusCode,headers:res.headers,data});});
        });request.on('error',()=>finish(Object.assign(Error('无法访问 Google Drive，请检查系统代理或网络'),{retryable:true})));request.end(body);
      })().catch(e=>finish(e));
    });
  }
  backoff(headers,attempt){
    const value=headers?.['retry-after']??headers?.['Retry-After'];let delay;
    if(value!==undefined&&String(value).trim()!=='')delay=/^\d+(?:\.\d+)?$/.test(String(value).trim())?Number(value)*1000:Date.parse(value)-this.now();
    return Number.isFinite(delay)&&delay>=0?Math.min(86400000,Math.max(delay,500)):500*2**attempt;
  }
  async waitForRetry(signal){while(this.retryUntil>this.now()){if(signal?.aborted)throw cancelled();await this.sleep(Math.min(60000,this.retryUntil-this.now()),signal);}if(signal?.aborted)throw cancelled();}
  async request(key,url,{signal,method='GET',json,body,headers={},allow=[],retry=true,raw=false}={}){
    this.url(url);let force=false,rejectedToken;
    for(let attempt=0;attempt<4;attempt++){
      this.check(signal,key);await this.waitForRetry(signal);const token=await this.token(key,signal,force,rejectedToken);force=false;let result;
      try{await this.waitForRetry(signal);result=await this.transport(url,{signal,method,raw,body:json===undefined?body:this.Buffer.from(JSON.stringify(json)),headers:{...headers,...(json===undefined?{}:{'Content-Type':'application/json; charset=utf-8'}),Authorization:'Bearer '+token}});}
      catch(e){if(e.name==='AbortError'||!retry||!e.retryable||attempt===3)throw e;await this.sleep(500*2**attempt,signal);continue;}
      this.check(signal,key);const {status,data}=result;
      if(status>=200&&status<300||allow.includes(status))return result;
      if(status===401&&attempt<3){force=true;rejectedToken=token;continue;}
      const reason=data?.error?.errors?.[0]?.reason,transient=status===429||status>=500||status===403&&['rateLimitExceeded','userRateLimitExceeded'].includes(reason);
      if(transient){this.retryUntil=Math.max(this.retryUntil,this.now()+this.backoff(result.headers,attempt));if(retry&&attempt<3)continue;}
      throw Object.assign(Error(status===401?'备份授权已过期，请重新授权':status===403?'Google Drive 拒绝写入，请检查备份权限、应用发布状态或存储配额':status===404?'云端备份文件已移除或无法访问，请重新扫描':transient?'Google Drive 暂时繁忙，请稍后重试':'Google Drive 上传失败（HTTP '+status+'）'),{status,retryable:transient,retryAfterMs:transient?Math.max(0,this.retryUntil-this.now()):0});
    }
  }
  async list(key,q,signal){let pageToken,files=[];do{const r=await this.request(key,API+'files?'+new URLSearchParams({q:'trashed = false and ('+q+')',pageSize:'1000',fields:'nextPageToken,files('+FIELDS+')',...(pageToken?{pageToken}:{})}),{signal});files.push(...(r.data?.files||[]));if(files.length>25000)throw Error('云端备份文件数量超限');pageToken=r.data?.nextPageToken;}while(pageToken);return files;}
  id(value){if(typeof value!=='string'||!/^[-\w]{1,200}$/.test(value))throw Error('Google Drive 文件 ID 无效');return value;}
  async metadata(key,id,signal){return (await this.request(key,API+'files/'+this.id(id)+'?'+new URLSearchParams({fields:FIELDS}),{signal,allow:[404]})).data;}
  async folder(key,name,parent,tag,signal){
    const rows=await this.list(key,"mimeType = 'application/vnd.google-apps.folder' and appProperties has { key='typoraBackup' and value='"+tag+"' }"+(parent?" and '"+this.id(parent)+"' in parents":''),signal);
    if(rows.length>1)throw Error('发现重复备份文件夹，请保留一个后重试');if(rows.length)return rows[0].id;
    const generated=await this.request(key,API+'files/generateIds?count=1&space=drive&type=files',{signal}),id=this.id(generated.data?.ids?.[0]);
    await this.request(key,API+'files?fields=id',{signal,method:'POST',allow:[409],json:{id,name,mimeType:'application/vnd.google-apps.folder',appProperties:{typoraBackup:tag},...(parent?{parents:[parent]}:{})}});
    const verified=await this.metadata(key,id,signal);if(verified?.id!==id||verified.trashed||verified.mimeType!=='application/vnd.google-apps.folder'||parent&&!verified.parents?.includes(parent)||verified.appProperties?.typoraBackup!==tag)throw Error('云端备份目录创建校验失败');return id;
  }
  matches(meta,file){return !!meta&&!meta.trashed&&Number(meta.size)===file.bytes&&(meta.sha256Checksum?meta.sha256Checksum===file.sha256:!!file.md5&&meta.md5Checksum===file.md5);}
  async stateFile(libraryId,key){
    const name='backup-sessions-'+libraryId+'-'+key.slice(0,24)+'.dpapi';let state={};
    try{state=JSON.parse(await this.plugins.protect(await this.fs.promises.readFile(this.path.join(this.plugins.dir,name),'utf8'),true));}catch(e){if(e.code!=='ENOENT')throw Error('上传续传记录无法读取，请保留原文件并重新配置备份');}
    const session={state,name,freshIds:new Set()};let revision=0,saved=0,writing=null;
    // Multiple workers share one encrypted checkpoint. Serialize writes and
    // coalesce updates while encryption is running, never replace a newer state.
    session.save=()=>{
      revision++;
      if(!writing)writing=(async()=>{try{while(saved<revision){const version=revision,snapshot=JSON.stringify(session.state);await this.plugins.write(name,await this.plugins.protect(snapshot));saved=version;}}finally{writing=null;}})();
      return writing;
    };return session;
  }
  async reserve(key,jobs,sessions,signal){
    const missing=jobs.filter(j=>sessions.state[j.job]?.sha256!==j.sha256);
    for(let offset=0;offset<missing.length;offset+=100){
      const batch=missing.slice(offset,offset+100),r=await this.request(key,API+'files/generateIds?count='+batch.length+'&space=drive&type=files',{signal});
      const ids=r.data?.ids;if(!Array.isArray(ids)||ids.length!==batch.length||new Set(ids).size!==ids.length)throw Error('Google Drive 未返回完整上传标识');
      const valid=ids.map(id=>this.id(id));
      batch.forEach((j,i)=>{sessions.state[j.job]={id:valid[i],sha256:j.sha256};sessions.freshIds.add(valid[i]);});
      await sessions.save();
    }
  }
  async multipart(key,local,metadata,expected,entry,signal){
    const input=await this.fs.promises.open(local,'r');let bytes;
    try{
      const stat=await input.stat();if(!stat.isFile()||stat.size!==expected.bytes)throw Error('上传缓存已变化，请重新扫描');
      bytes=this.Buffer.alloc(expected.bytes);let offset=0;
      while(offset<bytes.length){this.check(signal,key);const r=await input.read(bytes,offset,bytes.length-offset,offset);if(!r.bytesRead)throw Error('上传缓存文件不完整');offset+=r.bytesRead;}
      const after=await input.stat();if(after.size!==stat.size||after.mtimeMs!==stat.mtimeMs||this.crypto.createHash('sha256').update(bytes).digest('hex')!==expected.sha256)throw Error('上传期间缓存文件已变化');
    }finally{await input.close();}
    const boundary='typora-'+this.crypto.randomUUID(),body=this.Buffer.concat([
      this.Buffer.from('--'+boundary+'\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n'+JSON.stringify({...metadata,id:entry.id})+'\r\n--'+boundary+'\r\nContent-Type: application/octet-stream\r\n\r\n'),
      bytes,this.Buffer.from('\r\n--'+boundary+'--\r\n')
    ]);
    // Reuse the persisted ID on retries: a lost successful response yields 409,
    // then read back and verify the existing bytes instead of creating duplicates.
    await this.request(key,'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields='+FIELDS,{signal,method:'POST',body,headers:{'Content-Type':'multipart/related; boundary='+boundary},allow:[409]});
    const meta=await this.metadata(key,entry.id,signal);if(!this.matches(meta,expected))throw Error('云端文件大小或校验值不符，本次备份尚未完成');return meta;
  }
  async uploadPending(backup,remote,objects,sessions,{signal,onProgress}){
    await this.reserve(remote.key,remote.pending.map(f=>({job:objects+':'+f.sha256,sha256:f.sha256})),sessions,signal);
    const controller=new AbortController(),abort=()=>controller.abort();let next=0,completed=0,active=0,failure;
    if(signal?.aborted)abort();else signal?.addEventListener('abort',abort,{once:true});
    const progress=(f,detail='')=>onProgress('正在上传 '+completed+' / '+remote.count+' · '+active+' 个并行'+detail+'：'+this.path.basename(f.file),'uploading');
    const worker=async()=>{
      try{
        while(!controller.signal.aborted&&next<remote.pending.length){
          const f=remote.pending[next++];active++;
          try{progress(f);await this.upload(remote.key,backup.object(f.sha256),{name:f.sha256,parents:[objects]},f,sessions,{signal:controller.signal,onProgress:(done,total)=>progress(f,' · '+Math.floor(done/Math.max(1,total)*100)+'%')});completed++;}
          finally{active--;}
          progress(f);
        }
      }catch(e){if(!failure)failure=e;controller.abort();}
    };
    try{
      await Promise.all(Array.from({length:Math.min(UPLOAD_WORKERS,remote.pending.length)},worker));
      if(failure)throw failure;this.check(signal,remote.key);return completed;
    }finally{signal?.removeEventListener('abort',abort);}
  }
  async upload(key,local,metadata,expected,sessions,{signal,onProgress=()=>{}}={}){
    const job=metadata.parents[0]+':'+metadata.name;let entry=sessions.state[job];
    if(!entry||entry.sha256!==expected.sha256){await this.reserve(key,[{job,sha256:expected.sha256}],sessions,signal);entry=sessions.state[job];}
    let meta=sessions.freshIds.delete(entry.id)?null:await this.metadata(key,entry.id,signal);if(this.matches(meta,expected)){delete sessions.state[job];await sessions.save();return meta;}
    if(meta?.id){delete sessions.state[job];await this.reserve(key,[{job,sha256:expected.sha256}],sessions,signal);entry=sessions.state[job];sessions.freshIds.delete(entry.id);}
    if(!entry.url&&expected.bytes<=SMALL_UPLOAD){meta=await this.multipart(key,local,metadata,expected,entry,signal);delete sessions.state[job];await sessions.save();onProgress(expected.bytes,expected.bytes);return meta;}
    const begin=async()=>{const r=await this.request(key,'https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&fields='+FIELDS,{signal,method:'POST',json:{...metadata,id:entry.id},headers:{'X-Upload-Content-Type':'application/octet-stream','X-Upload-Content-Length':String(expected.bytes)}});entry.url=this.url(r.headers.location).href;await sessions.save();};
    let offset=0;
    if(entry.url){const status=await this.request(key,entry.url,{signal,method:'PUT',headers:{'Content-Range':'bytes */'+expected.bytes},allow:[308,404,410]});
      if(status.status===200||status.status===201){meta=await this.metadata(key,entry.id,signal);if(!this.matches(meta,expected))throw Error('云端文件校验失败');delete sessions.state[job];await sessions.save();return meta;}
      if(status.status===308)offset=this.offset(status,expected.bytes);else delete entry.url;
    }
    if(!entry.url)await begin();
    let recoveries=0;const input=await this.fs.promises.open(local,'r');try{
      const stat=await input.stat();if(!stat.isFile()||stat.size!==expected.bytes)throw Error('上传缓存已变化，请重新扫描');
      do{
        this.check(signal,key);const length=Math.min(4*1024**2,expected.bytes-offset),buffer=this.Buffer.alloc(length);if(length){const r=await input.read(buffer,0,length,offset);if(r.bytesRead!==length)throw Error('上传缓存文件不完整');}
        let result;try{result=await this.request(key,entry.url,{signal,method:'PUT',body:buffer,retry:false,headers:{'Content-Type':'application/octet-stream','Content-Range':length?'bytes '+offset+'-'+(offset+length-1)+'/'+expected.bytes:'bytes */0'},allow:[308]});}
        catch(e){
          if(e.name==='AbortError')throw e;const recovered=await this.metadata(key,entry.id,signal);if(this.matches(recovered,expected))break;
          if(!e.retryable||recoveries++>=3)throw e;
          await this.sleep(500*2**(recoveries-1),signal);
          const status=await this.request(key,entry.url,{signal,method:'PUT',headers:{'Content-Range':'bytes */'+expected.bytes},allow:[308,404,410]});
          if(status.status===200||status.status===201)break;
          if(status.status===308)offset=this.offset(status,expected.bytes);else{delete entry.url;offset=0;await begin();}
          continue;
        }
        if(result.status!==308)break;const next=this.offset(result,expected.bytes);if(next<=offset)throw Error('Google Drive 未确认上传进度，请重试续传');offset=next;onProgress(offset,expected.bytes);
      }while(offset<expected.bytes);
      const after=await input.stat();if(after.size!==stat.size||after.mtimeMs!==stat.mtimeMs)throw Error('上传期间缓存文件已变化');
    }finally{await input.close();}
    meta=await this.metadata(key,entry.id,signal);if(!this.matches(meta,expected))throw Error('云端文件大小或校验值不符，本次备份尚未完成');delete sessions.state[job];await sessions.save();return meta;
  }
  offset(response,total){const range=String(response.headers?.range||'');if(!range)return 0;const m=/^bytes=0-(\d+)$/.exec(range);if(!m||!Number.isSafeInteger(+m[1])||+m[1]+1>total)throw Error('Google Drive 续传位置无效');return +m[1]+1;}
  async scan(backup,plan,{signal,onProgress=()=>{}}={}){
    const account=this.account();if(!account)throw Error('请先授权 Google Drive 备份');const key=account.key;this.check(signal,key);onProgress('正在检查云端备份…','scanning');
    const namespace='kb-'+backup.libraryId,roots=await this.list(key,"mimeType = 'application/vnd.google-apps.folder' and appProperties has { key='typoraBackup' and value='"+namespace+"' }",signal);if(roots.length>1)throw Error('云端存在重复备份目录');
    const root=roots[0]?.id;let objects,records=[],snapshots=[];
    if(root){const folders=await this.list(key,"'"+this.id(root)+"' in parents and mimeType = 'application/vnd.google-apps.folder'",signal);objects=folders.find(f=>f.appProperties?.typoraBackup===namespace+'-objects')?.id;const history=folders.find(f=>f.appProperties?.typoraBackup===namespace+'-snapshots')?.id;
      if(objects)records=await this.list(key,"'"+this.id(objects)+"' in parents",signal);if(history)snapshots=await this.list(key,"'"+this.id(history)+"' in parents",signal);
    }
    const unique=[...new Map([...plan.collected.files.values()].map(f=>[f.sha256,f])).values()],pending=unique.filter(f=>!records.some(m=>m.name===f.sha256&&this.matches(m,f)));
    return {key,namespace,root,objects,pending,files:unique,recordIds:records,hasSnapshot:snapshots.some(s=>s.name==='snapshot-'+plan.packageId+'.json'),count:pending.length,bytes:pending.reduce((n,f)=>n+f.bytes,0)};
  }
  async run(backup,plan,remote,{signal,onProgress=()=>{}}={}){
    this.check(signal,remote.key);await backup.assertCurrent(plan,signal);const release=await backup.lock('cloud.lock');try{
    if(await new Cleanup(this,backup).pending())throw Error('上次清理尚未恢复，请手动点击“立即同步”恢复');
    const local=await backup.run(plan,{signal,onProgress}),key=remote.key;
    // Recheck after local capture so an old preview cannot skip removed cloud files.
    remote=await this.scan(backup,plan,{signal,onProgress});if(remote.key!==key)throw Error('备份账户已变更');
    const root=await this.folder(key,'Typora 知识库备份 · '+this.path.basename(backup.store.root),null,remote.namespace,signal),objects=await this.folder(key,'objects',root,remote.namespace+'-objects',signal),history=await this.folder(key,'snapshots',root,remote.namespace+'-snapshots',signal);
    const sessions=await this.stateFile(backup.libraryId,key),uploaded=await this.uploadPending(backup,remote,objects,sessions,{signal,onProgress});
    // Verify every referenced file, including reused blobs, before publishing.
    const records=await this.list(key,"'"+objects+"' in parents",signal);for(const f of remote.files)if(!records.some(m=>m.name===f.sha256&&this.matches(m,f)))throw Error('云端文件不完整，本次备份未发布，请重试');
    const snapshot=this.path.join(backup.root,'snapshots','snapshot-'+plan.packageId+'.json'),fingerprint=await backup.fingerprint(snapshot,{signal});
    const histories=await this.list(key,"'"+history+"' in parents",signal);let published=histories.find(m=>m.name===this.path.basename(snapshot)&&this.matches(m,fingerprint));
    onProgress('正在核对云端备份清单…','saving');if(!published)published=await this.upload(key,snapshot,{name:this.path.basename(snapshot),parents:[history]},fingerprint,sessions,{signal});
    const readme=this.path.join(backup.root,'README.txt'),info=await backup.fingerprint(readme,{signal}),rootFiles=await this.list(key,"'"+root+"' in parents and name = 'README.txt'",signal);
    if(!rootFiles.some(m=>this.matches(m,info)))await this.upload(key,readme,{name:'README.txt',parents:[root]},info,sessions,{signal});
    // A reverted document may reuse an older immutable snapshot. Publish the
    // current pointer explicitly instead of inferring it from creation time.
    await this.request(key,API+'files/'+this.id(root)+'?fields=id',{signal,method:'PATCH',json:{appProperties:{typoraBackup:remote.namespace,typoraLatest:plan.packageId}}});
    const result={...local,uploaded,cloudFiles:remote.files.length,account:this.account().account,cloudRoot:root,url:'https://drive.google.com/drive/folders/'+root,completedAt:new Date().toISOString(),packageId:plan.packageId};
    await backup.atomic(this.path.join(backup.root,'sources-'+plan.packageId+'.json'),JSON.stringify([...plan.collected.files.values()].map(f=>({path:f.entry,file:f.file,sha256:f.sha256}))));
    await backup.atomic(this.path.join(backup.root,'cloud-'+key.slice(0,24)+'.json'),JSON.stringify(result));return result;
    }finally{await release();}
  }
  async download(backup,key,meta,target,{signal,onProgress=()=>{}}={}){
    const size=Number(meta.size);if(!Number.isSafeInteger(size)||size<0||size>backup.archive.limits.bytes)throw Error('云端文件大小超限');
    const tmp=target+'.'+this.crypto.randomUUID()+'.partial';await backup.mkdir(this.path.dirname(target));let handle;
    try{handle=await this.fs.promises.open(tmp,'wx');
      for(let offset=0;offset<size;){this.check(signal,key);const end=Math.min(size-1,offset+1024**2-1);
        const r=await this.request(key,API+'files/'+this.id(meta.id)+'?alt=media',{signal,raw:true,headers:{Range:'bytes='+offset+'-'+end}});
        if(!this.Buffer.isBuffer(r.data)||r.data.length!==end-offset+1||r.status===200&&size>1024**2||r.status===206&&r.headers['content-range']!=='bytes '+offset+'-'+end+'/'+size)throw Error('云端下载范围校验失败');
        await handle.writeFile(r.data);offset=end+1;onProgress('正在下载 · '+Math.floor(offset/Math.max(size,1)*100)+'%','downloading');
      }
      await handle.sync();await handle.close();handle=null;const hash=await backup.fingerprint(tmp,{signal});
      if(!this.matches(meta,hash))throw Error('云端下载校验失败，未修改本机文件');this.check(signal,key);await this.fs.promises.rename(tmp,target);return hash;
    }finally{if(handle)await handle.close().catch(()=>{});await this.fs.promises.unlink(tmp).catch(()=>{});}
  }
  async catalog(backup,{signal,onProgress=()=>{}}={}){
    const key=this.account()?.key;if(!key)throw Error('请先授权 Google Drive 备份');onProgress('正在读取云端文件…','downloading');
    const ns='kb-'+backup.libraryId,roots=await this.list(key,"mimeType = 'application/vnd.google-apps.folder' and appProperties has { key='typoraBackup' and value='"+ns+"' }",signal);
    if(roots.length!==1)throw Error(roots.length?'云端存在重复备份目录':'云端尚无当前知识库的备份');
    const folders=await this.list(key,"'"+this.id(roots[0].id)+"' in parents and mimeType = 'application/vnd.google-apps.folder'",signal);
    const history=folders.find(f=>f.appProperties?.typoraBackup===ns+'-snapshots'),objects=folders.find(f=>f.appProperties?.typoraBackup===ns+'-objects');if(!history||!objects)throw Error('云端备份尚未完成');
    const snapshots=(await this.list(key,"'"+this.id(history.id)+"' in parents",signal)).filter(f=>/^snapshot-[a-f0-9]{64}\.json$/.test(f.name)).sort((a,b)=>String(b.createdTime||'').localeCompare(String(a.createdTime||'')));
    if(!snapshots.length)throw Error('云端尚无已完成的备份');const pointer=roots[0].appProperties?.typoraLatest;
    const latest=pointer?snapshots.find(f=>f.name==='snapshot-'+pointer+'.json'):snapshots[0];if(!latest)throw Error('云端最新备份索引不完整');if(Number(latest.size)>backup.archive.limits.json)throw Error('云端清单过大');
    const file=this.path.join(backup.root,'downloads',latest.name);await this.download(backup,key,latest,file,{signal});const snapshot=backup.validate(await backup.json(file));
    if(latest.name!=='snapshot-'+snapshot.packageId+'.json')throw Error('云端备份清单名称不符');
    const records=await this.list(key,"'"+this.id(objects.id)+"' in parents",signal),rows=snapshot.files.map(f=>({...f,remote:records.find(m=>m.name===f.sha256&&Number(m.size)===f.bytes&&(m.sha256Checksum?m.sha256Checksum===f.sha256:!!m.md5Checksum))}));
    if(rows.some(f=>!f.remote))throw Error('云端备份不完整，暂不能下载更新');return {key,snapshot,rows};
  }
}
module.exports=DriveBackup;
