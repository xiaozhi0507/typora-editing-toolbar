'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),path=require('node:path');
const Managed=require('./knowledge-library-managed.cjs');
test('TeX bracket products are not files, including inline, display and alternate delimiters',()=>{
  const formula=String.raw`[\rho_{700}](\frac{\rho_{700}}{\rho_{670}})`;
  for(const text of ['$'+formula+'$', '$$\n'+formula+'\n\n+1\n$$', '\\('+formula+'\\)', '\\[\n'+formula+'\n\\]']){
    assert.deepEqual(Managed.links('Before '+(text.startsWith('$$')?'\n\n':'')+text+'\n\n![actual](images/plot.png)'),['images/plot.png'],text);
  }
});
test('literal code, escaped syntax and incomplete link-like prose are ignored',()=>{
  assert.deepEqual(Managed.links('`[sample](C:/example.md)`\n\n~~~md\n[x](D:/example.md)\n~~~\n\n    [sample](C:/example.md)\n\nonly ](missing.md)\n\n\\[sample](missing.md)'),[]);
});
test('real resources survive math and include nested names, reference links, HTML media and dollar names',()=>{
  const text=String.raw`$[x](\frac{a}{b})$ [chapter](chapter(2).md) ![pic](<images/a b.png>) [ref][two]

[two]: chapters/二.md
[unused]: appendix.md

<img src="images/a.png?x=1&amp;y=2">

[dollar](assets/$price$.md)`;
  const links=Managed.links(text).map(x=>decodeURIComponent(x));
  for(const link of ['chapter(2).md','images/a b.png','chapters/二.md','appendix.md','images/a.png?x=1&y=2','assets/$price$.md'])assert(links.includes(link),link);
  assert.equal(links.length,6);
});
test('real absolute links remain blocked including percent encoded Windows paths',()=>{
  const managed=new Managed({path:path.win32,root:'C:\\library'});
  for(const text of ['[x](C:/notes/x.md)','![x](file:///C:/x.png)','[x](C%3A%2Fnotes%2Fx.md)','[x](%5Croot%5Cx.md)']){
    const links=Managed.links(text);assert.equal(links.length,1);assert.throws(()=>managed.localLink(links[0],'C:\\library'),/绝对本地链接/);
  }
});
test('Typora footnote text is not a resource path, even when definitions are unused',()=>{
  assert.deepEqual(Managed.links('正文[^ch3-note1]。\n\n[^ch3-note1]: 译者注：国内有些教材也将它翻译成概率分布律。\n\n[^unused]: 另一个纯文本说明。\n\n[chapter](next.md)'),['next.md']);
});
test('real footnote resources survive multiline blocks, references and code fences',()=>{
  const text='正文[^n]。\n\n[^n]: 参见 [章节](chapter.md) 和 ![图](images/a.png)。\n\n    后续段落 [资料][resource]\n\n    ```md\n    [example](missing.md)\n    ```\n\n    ![附图](images/b.png)\n\n[resource]: appendix.md\n\n[normal](next.md)';
  assert.deepEqual(new Set(Managed.links(text)),new Set(['chapter.md','images/a.png','appendix.md','images/b.png','next.md']));
});
test('quoted and list footnotes keep resources while code and escaped definitions stay literal',()=>{
  assert.deepEqual(Managed.links('> [^q]: 纯文字。![图](q.png)\n\n- 项目\n\n  [^l]: 纯文字。 [文件](l.md)\n\n```md\n[^code]: [x](missing.md)\n```\n\n\\[^literal]: 不是路径'),['q.png','l.md']);
});
