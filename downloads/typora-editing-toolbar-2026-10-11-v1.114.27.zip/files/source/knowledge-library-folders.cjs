'use strict';
// A descriptor references a complete sibling tree through the existing
// checksummed archive/backup pipeline. Code is copied, never executed.
class KnowledgeLibraryFolders {
  constructor(managed){this.managed=managed;this.store=managed.store;this.io=managed.io;this.path=managed.path;}
  check(signal){if(signal?.aborted)throw Object.assign(Error('已取消导入'),{name:'AbortError'});}
  relative(value){
    if(typeof value!=='string'||!value||value.length>2048||/[\\:\x00-\x1f]/.test(value)||value.split('/').some(p=>!p||p==='.'||p==='..'||/[. ]$/.test(p)))throw Error('文件夹附件包含无效路径');
    return value;
  }
  async scan(root,{signal,onProgress=()=>{}}={}){
    const files=[],directories=[];let bytes=0,entries=0;
    const walk=async(dir,depth)=>{
      this.check(signal);if(depth>128||++entries>20000)throw Error('文件夹层级或文件数量过多');
      if(!(await this.managed.regular(dir)).isDirectory())throw Error('请选择普通文件夹');
      directories.push(this.path.relative(root,dir).replaceAll('\\','/'));
      for(const entry of await this.io.readdir(dir,{withFileTypes:true})){
        this.check(signal);const file=this.path.join(dir,entry.name),relative=this.path.relative(root,file).replaceAll('\\','/');this.relative(relative);
        const stat=await this.managed.regular(file);
        if(stat.isDirectory())await walk(file,depth+1);
        else {
          if(!stat.isFile())throw Error('文件夹中存在非普通文件：'+file);
          bytes+=stat.size;if(bytes>1024**3||files.length>=10000)throw Error('单个文件夹附件超过 1 GB 或一万个文件，请拆分后添加');
          files.push({file,relative,bytes:stat.size,mtime:stat.mtimeMs});onProgress('正在扫描：'+relative,'scanning');
        }
      }
    };
    await walk(root,0);return {source:root,base:root,files,directories,bytes};
  }
  async descriptor(ref){
    if(ref.attachmentType!=='folder')throw Error('不是文件夹附件');
    const file=this.store.resolveFile(ref),stat=await this.managed.regular(file);
    if(!stat.isFile()||stat.size>4*1024**2)throw Error('文件夹附件索引无效');
    const data=JSON.parse(await this.io.readFile(file,'utf8'));
    if(data.format!=='typora-folder-attachment'||data.version!==1||!Array.isArray(data.directories)||data.directories.length>20000)throw Error('文件夹附件索引无效');
    for(const dir of data.directories)if(dir)this.relative(dir);
    const root=this.path.dirname(file);await this.managed.regular(root);return {root,file,data};
  }
  async plan(ref,options={}){const {root}=await this.descriptor(ref);return this.scan(root,options);}
  async digest(file,signal){
    const handle=await this.io.open(file,'r'),hash=this.store.crypto.createHash('sha256');
    try{const chunk=new Uint8Array(128*1024);for(;;){this.check(signal);const {bytesRead}=await handle.read(chunk,0,chunk.length,null);if(!bytesRead)break;hash.update(chunk.subarray(0,bytesRead));}return hash.digest('hex');}finally{await handle.close();}
  }
  async prepare(source,options={}){
    source=this.path.resolve(source);this.check(options.signal);
    if(this.managed.inside(source,this.store.root)||this.managed.inside(this.store.root,source))throw Error('请选择知识库之外的原始附件文件夹');
    const plan=await this.scan(source,options),key=this.store.crypto.randomBytes(4).toString('hex').toUpperCase(),bundle=this.path.join(this.managed.storage,key),root=this.path.join(bundle,this.path.basename(source));
    await this.io.mkdir(this.managed.storage,{recursive:true});await this.managed.regular(this.managed.storage);await this.io.mkdir(bundle);
    try{
      for(const dir of plan.directories){this.check(options.signal);await this.io.mkdir(this.path.join(root,dir),{recursive:true});}
      const manifest=[];
      for(const f of plan.files){
        this.check(options.signal);options.onProgress?.('正在复制：'+f.relative,'copying');
        const target=this.path.join(root,f.relative),before=await this.managed.regular(f.file);
        if(before.size!==f.bytes||before.mtimeMs!==f.mtime)throw Error('导入期间文件已修改，请重试：'+f.file);
        await this.io.copyFile(f.file,target,this.store.fs.constants.COPYFILE_EXCL);
        const a=await this.digest(f.file,options.signal),b=await this.digest(target,options.signal),after=await this.managed.regular(f.file);
        if(a!==b||after.size!==f.bytes||after.mtimeMs!==f.mtime)throw Error('文件复制校验失败，请重试：'+f.file);
        manifest.push({path:this.path.relative(bundle,target).replaceAll('\\','/'),source:f.file,bytes:f.bytes,sha256:b});
      }
      this.check(options.signal);
      const final=await this.scan(source,{signal:options.signal});
      if(JSON.stringify(final.directories)!==JSON.stringify(plan.directories)||JSON.stringify(final.files)!==JSON.stringify(plan.files))throw Error('导入期间文件夹已变化，请重试');
      const marker=this.path.join(root,'.et-folder-'+this.store.crypto.randomUUID()+'.json');
      await this.io.writeFile(marker,JSON.stringify({format:'typora-folder-attachment',version:1,directories:plan.directories}),{flag:'wx'});
      await this.io.writeFile(this.path.join(bundle,'.managed.json'),JSON.stringify({version:1,source,created:new Date().toISOString(),files:manifest}),{flag:'wx'});
      return {...this.store.fileRef(marker,'文件夹'),name:this.path.basename(source),attachmentType:'folder',managed:true,storageKey:key,sourcePath:source};
    }catch(e){await this.managed.removeFolder(bundle).catch(()=>{});throw e;}
  }
  async attach(id,source,options={}){
    const base=(await this.store.read()).data,item=base.items.find(i=>i.id===id);if(!item||item.deleted)throw Error('条目已删除或不存在');
    const existing=item.files.find(f=>f.attachmentType==='folder'&&f.sourcePath&&this.path.resolve(f.sourcePath).toLowerCase()===this.path.resolve(source).toLowerCase());
    if(existing)return {data:base,id,reused:true};
    const ref=await this.prepare(source,options);
    try{
      const next=JSON.parse(JSON.stringify(base)),target=next.items.find(i=>i.id===id);target.files.push(ref);target.defaultFile ||= ref.id;
      this.check(options.signal);options.onProgress?.('正在保存附件…','saving');
      const data=await this.store.commit(base,next,live=>{this.check(options.signal);if(JSON.stringify(live.items.find(i=>i.id===id))!==JSON.stringify(item))throw Error('条目已在其他窗口修改，请重新添加');});
      return {data,id,ref,reused:false};
    }catch(e){await this.managed.rollback([ref]);throw e;}
  }
  async child(ref,relative='',directory=false){
    const {root,file}=await this.descriptor(ref);if(relative)this.relative(relative);
    const target=this.path.resolve(root,relative);if(!this.managed.inside(root,target)||target===file)throw Error('附件路径无效');
    const stat=await this.managed.regular(target);if(directory?!stat.isDirectory():!stat.isFile())throw Error('找不到附件内容');
    return {root,target,file};
  }
  async list(ref,relative=''){
    const {target,file}=await this.child(ref,relative,true),result=[];
    for(const entry of await this.io.readdir(target,{withFileTypes:true})){
      const child=this.path.join(target,entry.name);if(child===file)continue;
      const stat=await this.managed.regular(child);if(!stat.isFile()&&!stat.isDirectory())continue;
      result.push({name:entry.name,path:(relative?relative+'/':'')+entry.name,directory:stat.isDirectory(),kind:this.path.extname(child).slice(1).toUpperCase()||'文件'});
    }
    return result.sort((a,b)=>Number(b.directory)-Number(a.directory)||a.name.localeCompare(b.name,'zh-CN',{numeric:true}));
  }
  async restore(ref){
    const {root,data}=await this.descriptor(ref);
    for(const dir of data.directories){if(!dir)continue;let target=root;for(const part of dir.split('/')){target=this.path.join(target,part);await this.io.mkdir(target).catch(e=>{if(e.code!=='EEXIST')throw e;});if(!(await this.managed.regular(target)).isDirectory())throw Error('附件目录与文件冲突');}}
  }
}
module.exports=KnowledgeLibraryFolders;
