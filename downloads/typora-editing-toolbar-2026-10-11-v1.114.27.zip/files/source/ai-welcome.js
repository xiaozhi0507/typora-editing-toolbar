// The welcome page owns one idle timer. Draft text is deliberately not an eligibility condition.
class EditingToolbarAIWelcome {
  constructor(ai) {
    this.ai = ai;
    this.text = ai.empty.querySelector('.et-ai-welcome-quote');
    this.source = ai.empty.querySelector('.et-ai-welcome-source');
    this.animations = [];
    this.generation = 0;
    this.listeners = [];
    this.reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    const listen = (target, type, callback, options) => {
      target.addEventListener(type, callback, options);
      this.listeners.push(() => target.removeEventListener(type, callback, options));
    };
    const activity = () => this.reset();
    for (const type of ['pointermove', 'pointerdown', 'keydown', 'input', 'wheel', 'selectionchange', 'compositionstart'])
      listen(document, type, activity, {capture: true, passive: true});
    // Typora's embedded editors blur the parent window without hiding it.
    // A visible welcome page must keep rotating, including beside another app.
    listen(window, 'resize', activity);
    listen(document, 'visibilitychange', activity);
    listen(this.reducedMotion, 'change', activity);
    listen(window, 'unload', () => this.dispose());
    this.lastVisible = this.visible();
    const visibility = () => {
      const visible = this.visible();
      if (visible === this.lastVisible) return;
      this.lastVisible = visible;
      this.reset();
    };
    this.observer = new MutationObserver(visibility);
    for (const node of [ai.panel, ai.empty]) this.observer.observe(node, {attributes: true, attributeFilter: ['hidden']});
    // A compact dock hides the quote with CSS; expanding it should start idle again.
    this.resizeObserver = new ResizeObserver(visibility);
    this.resizeObserver.observe(ai.panel);
  }
  visible() {
    return !this.disposed && !document.hidden && this.ai.panel.isConnected &&
      !this.ai.panel.hidden && !this.ai.empty.hidden && !this.ai.turns.length && !this.ai.busy &&
      this.text.getClientRects().length > 0;
  }
  eligible() {
    if (!this.visible()) return false;
    const selection = document.getSelection();
    if (selection && !selection.isCollapsed && this.ai.empty.contains(selection.anchorNode)) return false;
    // Menus and modal dialogs should stay still while the user makes a choice.
    return ![...document.querySelectorAll('dialog[open], [role="menu"]:not([aria-hidden="true"]):not(#typora-sidebar), #et-ai-panel [aria-expanded="true"]')]
      .some(node => node.getClientRects().length > 0 && getComputedStyle(node).visibility !== 'hidden');
  }
  arm() {
    clearTimeout(this.timer);
    this.timer = null;
    if (this.visible()) this.timer = setTimeout(() => {
      this.timer = null;
      if (this.eligible()) void this.rotate();
      else this.arm();
    }, 12000);
  }
  reset() { this.lastVisible = this.visible(); this.cancel(); this.arm(); }
  clearVisuals() {
    for (const animation of this.animations) animation.cancel();
    this.animations = [];
    const original = this.text.querySelector('.et-ai-welcome-original');
    if (original) this.text.textContent = original.textContent;
    this.ai.empty.removeAttribute('data-quote-motion');
  }
  cancel() {
    clearTimeout(this.timer); this.timer = null;
    this.generation++;
    this.clearVisuals();
  }
  async animate(incoming) {
    // Position visual glyphs over the original line layout: punctuation and wrapping never jump.
    const original = document.createElement('span');
    original.className = 'et-ai-welcome-original';
    original.textContent = this.text.textContent;
    this.text.replaceChildren(original);
    const overlay = document.createElement('span');
    overlay.className = 'et-ai-welcome-particles';
    overlay.setAttribute('aria-hidden', 'true');
    const bounds = this.text.getBoundingClientRect(), textNode = original.firstChild;
    let offset = 0;
    const glyphs = [];
    for (const char of original.textContent) {
      const range = document.createRange();
      range.setStart(textNode, offset); offset += char.length; range.setEnd(textNode, offset);
      const rect = range.getBoundingClientRect();
      if (/\s/u.test(char)) continue;
      const glyph = document.createElement('span');
      glyph.textContent = char;
      Object.assign(glyph.style, {left: (rect.left - bounds.left) + 'px', top: (rect.top - bounds.top) + 'px', width: rect.width + 'px', height: rect.height + 'px', lineHeight: rect.height + 'px'});
      overlay.append(glyph); glyphs.push(glyph);
    }
    this.text.append(overlay);
    original.style.opacity = '0';
    this.ai.empty.dataset.quoteMotion = incoming ? 'assembling' : 'dissolving';
    for (const [i, glyph] of glyphs.entries()) {
      const spread = {opacity: 0, filter: 'blur(3px)', transform: `translate(${Math.sin(i * 2.4) * 22}px, ${-12 - (i % 5) * 5}px) rotate(${Math.sin(i * 1.7) * 12}deg) scale(.85)`};
      const resting = {opacity: 1, filter: 'blur(0px)', transform: 'translate(0, 0) rotate(0deg) scale(1)'};
      this.animations.push(glyph.animate(incoming ? [spread, resting] : [resting, spread], {
        duration: incoming ? 650 : 520, delay: (i * 37 % 180), fill: 'both', easing: incoming ? 'cubic-bezier(.16,1,.3,1)' : 'cubic-bezier(.4,0,.8,.2)'
      }));
    }
    this.animations.push(this.source.animate(incoming ? [{opacity: 0}, {opacity: 1}] : [{opacity: 1}, {opacity: 0}], {duration: 450, fill: 'both'}));
    await Promise.all(this.animations.map(animation => animation.finished.catch(() => {})));
  }
  async rotate() {
    if (!this.eligible()) return this.arm();
    this.cancel();
    const generation = this.generation;
    try {
      if (!this.reducedMotion.matches && typeof this.text.animate === 'function') {
        await this.animate(false);
        if (generation !== this.generation || !this.eligible()) return;
        this.clearVisuals();
        this.ai.refreshWelcomeQuote(false);
        await this.animate(true);
      } else this.ai.refreshWelcomeQuote(false);
    } finally {
      if (generation === this.generation) { this.clearVisuals(); this.arm(); }
    }
  }
  dispose() {
    this.disposed = true;
    this.cancel(); this.observer.disconnect(); this.resizeObserver.disconnect();
    for (const remove of this.listeners.splice(0)) remove();
  }
}
