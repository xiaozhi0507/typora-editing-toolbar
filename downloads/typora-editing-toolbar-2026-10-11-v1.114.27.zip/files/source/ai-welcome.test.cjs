'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {JSDOM}=require('jsdom');
const read=name=>fs.readFileSync(path.join(__dirname,name),'utf8');
const AI=new Function(read('ai-welcome-quotes.js')+read('ai-assistant.js')+';return EditingToolbarAI;')();
function setup(t){
  const dom=new JSDOM('<section id="et-ai-panel"><div class="et-ai-empty"><p class="et-ai-welcome-quote"></p><p class="et-ai-welcome-source"></p></div><textarea></textarea></section>',{pretendToBeVisual:true,url:'https://fixture.invalid'});
  const w=dom.window,d=w.document;d.hasFocus=()=>true;w.matchMedia=()=>Object.assign(new w.EventTarget(),{matches:true});
  t.mock.timers.enable({apis:['setTimeout']});
  class ResizeObserver {constructor(callback){this.callback=callback;}observe(){}disconnect(){this.disconnected=true;}}
  const context={window:w,document:d,MutationObserver:w.MutationObserver,ResizeObserver,getComputedStyle:w.getComputedStyle.bind(w),setTimeout,clearTimeout,localStorage:w.localStorage,EditingToolbarAI:AI};
  const Controller=vm.runInNewContext(read('ai-welcome.js')+';EditingToolbarAIWelcome;',context);
  const ai={panel:d.querySelector('section'),empty:d.querySelector('.et-ai-empty'),turns:[],busy:false,prompt:d.querySelector('textarea'),refreshWelcomeQuote:AI.prototype.refreshWelcomeQuote};
  // refreshWelcomeQuote closes over its build scope; use the same source method with the fixture globals.
  ai.refreshWelcomeQuote=vm.runInNewContext('('+AI.prototype.refreshWelcomeQuote.toString().replace('refreshWelcomeQuote','function')+')',context);
  ai.empty.querySelector('p').getClientRects=()=>[{}];
  ai.welcomeMotion=new Controller(ai);ai.refreshWelcomeQuote();
  t.after(()=>{ai.welcomeMotion.dispose();dom.window.close();});
  return {ai,w,d,c:ai.welcomeMotion,tick:ms=>t.mock.timers.tick(ms)};
}
test('the original 100 and the additional 100 remain unique and carry a Chinese work title',()=>{
  assert.equal(AI.welcomeQuotes.length,200);assert.equal(new Set(AI.welcomeQuotes.map(q=>q[0])).size,200);
  for(const q of AI.welcomeQuotes){assert.equal(q.length,3);assert.match(q[0],/[\u3400-\u9fff]/);assert.ok(q[1].length);}
});
test('no countdown or early switch: exactly 12 idle seconds changes the quote without an immediate repeat',t=>{
  const f=setup(t),before=f.ai.welcomeQuote;f.tick(11999);assert.equal(f.ai.welcomeQuote,before);
  f.tick(1);assert.notEqual(f.ai.welcomeQuote,before);assert.equal(f.c.animations.length,0);
  assert.equal(f.ai.empty.querySelectorAll('p').length,2);
});
test('unsent text, focus and cursor survive rotation, and input restarts the full idle interval',t=>{
  const f=setup(t);f.ai.prompt.value='请解释这个推导，还没有发送';f.ai.prompt.focus();f.ai.prompt.setSelectionRange(4,4);
  f.tick(11000);f.ai.prompt.dispatchEvent(new f.w.Event('input',{bubbles:true}));const before=f.ai.welcomeQuote;
  f.tick(11999);assert.equal(f.ai.welcomeQuote,before);f.tick(1);assert.notEqual(f.ai.welcomeQuote,before);
  assert.equal(f.ai.prompt.value,'请解释这个推导，还没有发送');assert.equal(f.ai.prompt.selectionStart,4);assert.equal(f.d.activeElement,f.ai.prompt);
});
test('continuous pointer, keyboard and scrolling activity postpone rotation',t=>{
  const f=setup(t),before=f.ai.welcomeQuote;
  for(const type of ['pointermove','keydown','wheel','compositionstart']){f.tick(11000);f.d.dispatchEvent(new f.w.Event(type));assert.equal(f.ai.welcomeQuote,before);}
  f.tick(12000);assert.notEqual(f.ai.welcomeQuote,before);
});
test('after the first message and while hidden, idle cannot change the welcome quote',async t=>{
  const f=setup(t),before=f.ai.welcomeQuote;f.ai.turns.push({});f.ai.empty.hidden=true;await Promise.resolve();f.tick(20000);assert.equal(f.ai.welcomeQuote,before);assert.equal(f.c.timer,null);
  f.ai.turns=[];f.ai.empty.hidden=false;f.ai.panel.hidden=true;await Promise.resolve();f.tick(20000);assert.equal(f.ai.welcomeQuote,before);
  f.ai.panel.hidden=false;await Promise.resolve();f.tick(12000);assert.notEqual(f.ai.welcomeQuote,before);
});
test('a visible welcome keeps its deadline when an embedded editor or another window takes focus',t=>{
  const f=setup(t),before=f.ai.welcomeQuote;f.tick(11000);f.d.hasFocus=()=>false;f.w.dispatchEvent(new f.w.Event('blur'));
  f.tick(999);assert.equal(f.ai.welcomeQuote,before);f.tick(1);assert.notEqual(f.ai.welcomeQuote,before);
});

test('document visibility pauses rotation and showing it resumes a fresh twelve seconds',t=>{
  const f=setup(t),before=f.ai.welcomeQuote;f.tick(11000);Object.defineProperty(f.d,'hidden',{value:true,configurable:true});f.d.dispatchEvent(new f.w.Event('visibilitychange'));
  f.tick(20000);assert.equal(f.ai.welcomeQuote,before);assert.equal(f.c.timer,null);
  Object.defineProperty(f.d,'hidden',{value:false,configurable:true});f.d.dispatchEvent(new f.w.Event('visibilitychange'));
  f.tick(11999);assert.equal(f.ai.welcomeQuote,before);f.tick(1);assert.notEqual(f.ai.welcomeQuote,before);
});

test('redundant hidden assignments do not restart the idle deadline',async t=>{
  const f=setup(t),before=f.ai.welcomeQuote;f.tick(11000);f.ai.panel.hidden=false;f.ai.empty.hidden=false;await Promise.resolve();
  f.tick(1000);assert.notEqual(f.ai.welcomeQuote,before);
});

test('expanding a CSS-hidden quote resumes idle without needing another pointer event',t=>{
  const f=setup(t),before=f.ai.welcomeQuote;f.c.text.getClientRects=()=>[];f.c.resizeObserver.callback();
  f.tick(20000);assert.equal(f.ai.welcomeQuote,before);assert.equal(f.c.timer,null);
  f.c.text.getClientRects=()=>[{}];f.c.resizeObserver.callback();f.tick(11999);assert.equal(f.ai.welcomeQuote,before);f.tick(1);assert.notEqual(f.ai.welcomeQuote,before);
  f.c.dispose();assert.ok(f.c.resizeObserver.disconnected);
});
test('selected poetry and an open menu are not replaced while being read',t=>{
  const f=setup(t),before=f.ai.welcomeQuote;const range=f.d.createRange();range.selectNodeContents(f.c.text);f.d.getSelection().addRange(range);
  f.tick(12000);assert.equal(f.ai.welcomeQuote,before);f.d.getSelection().removeAllRanges();
  const menu=f.d.createElement('div');menu.setAttribute('role','menu');menu.getClientRects=()=>[{}];f.d.body.append(menu);f.c.reset();f.tick(12000);assert.equal(f.ai.welcomeQuote,before);
  menu.remove();f.d.dispatchEvent(new f.w.Event('pointerdown'));f.tick(12000);assert.notEqual(f.ai.welcomeQuote,before);
});
test('closing the controller releases listeners and timers, even after repeated activity',t=>{
  const f=setup(t),before=f.ai.welcomeQuote;f.c.dispose();f.w.dispatchEvent(new f.w.Event('focus'));f.d.dispatchEvent(new f.w.Event('input'));f.tick(30000);
  assert.equal(f.ai.welcomeQuote,before);assert.equal(f.c.timer,null);assert.equal(f.c.listeners.length,0);
});
test('the permanent Typora sidebar and selection in the document do not block welcome rotation',t=>{
  const f=setup(t),before=f.ai.welcomeQuote;
  const sidebar=f.d.createElement('div');sidebar.id='typora-sidebar';sidebar.setAttribute('role','menu');sidebar.getClientRects=()=>[{}];sidebar.textContent='文档目录';f.d.body.append(sidebar);
  const range=f.d.createRange();range.selectNodeContents(sidebar);f.d.getSelection().addRange(range);f.tick(1);f.c.reset();f.tick(12000);assert.notEqual(f.ai.welcomeQuote,before);
});
