# Changelog

## 0.5.12 — 2026-10-10

- Move local Typora connections from port 23119 to 23120, alongside toolbar v1.113.3, to avoid Zotero's connector port. Both ends must be updated.
- Check `/v1/health` without credentials before requests; require the Typora service/protocol response, reject redirects and never fall back to the old port.
- Replace raw JSON parser errors with actionable Chinese connection messages. Preserve explicit approval, token authorization, cancellation, binary uploads and ZIP-only operation.
- Add network regressions for wrong-service/non-JSON responses, offline connections, authorization errors, binary transfer, cancellation and timeout.

