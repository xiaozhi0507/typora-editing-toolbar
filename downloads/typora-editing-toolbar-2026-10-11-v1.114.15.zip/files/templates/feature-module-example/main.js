module.exports = {
  activate(api) {
    api.registerCommand({
      id: 'hello',
      name: '显示模块测试消息',
      callback: () => api.notice('模块接口已就绪')
    });
  }
};
