"""Private JSON-lines bridge. Jupyter channels live outside Typora's renderer."""
import json
import os
import sys
import threading
import queue
import time
import traceback

write_lock = threading.Lock()
kernel = None
client = None
stopping = threading.Event()
requests = {}
MAX_TEXT = 200_000

def emit(message):
    with write_lock:
        sys.stdout.write(json.dumps(message, ensure_ascii=True) + "\n")
        sys.stdout.flush()

def reply(request, result=None, error=None):
    emit({"type": "reply", "id": request.get("id"), "result": result, "error": error})

def bounded(content):
    # Bound traffic before it reaches the UI. Preserve small MIME bundles verbatim.
    content = dict(content)
    if isinstance(content.get("text"), str) and len(content["text"]) > MAX_TEXT:
        content["text"] = content["text"][:MAX_TEXT] + "\n[输出过长，已截断]"
    if "data" in content:
        content["data"] = {k: v for k, v in content["data"].items()
                           if len(json.dumps(v)) <= 12_000_000}
    return content

def pump(channel):
    getter = client.get_iopub_msg if channel == "iopub" else client.get_shell_msg
    while not stopping.is_set():
        try:
            message = getter(timeout=0.1)
            parent = message.get("parent_header", {}).get("msg_id")
            emit({"type": "event", "channel": channel, "parent": parent,
                  "event": message["msg_type"], "content": bounded(message.get("content", {}))})
        except queue.Empty:
            pass
        except Exception as error:
            if not stopping.is_set():
                emit({"type": "diagnostic", "error": str(error)})
            break

def monitor():
    while not stopping.wait(1):
        if kernel and not kernel.is_alive():
            emit({"type": "fatal", "error": "Python 内核意外退出，请重启内核。"})
            break

def start(request):
    global kernel, client
    from jupyter_client import KernelManager
    kernel = KernelManager(kernel_name="python3")
    # Launch the exact selected interpreter, even if the registered python3 spec is elsewhere.
    kernel.kernel_spec.argv = [sys.executable, "-m", "ipykernel_launcher", "-f", "{connection_file}"]
    env = dict(os.environ)
    env.update(request.get("env", {}))
    kernel.start_kernel(cwd=request["cwd"], env=env, stdout=sys.stderr, stderr=sys.stderr)
    client = kernel.client()
    client.start_channels()
    client.wait_for_ready(timeout=25)
    for channel in ("iopub", "shell"):
        threading.Thread(target=pump, args=(channel,), daemon=True).start()
    threading.Thread(target=monitor, daemon=True).start()
    reply(request, {"python": sys.executable, "version": sys.version.split()[0]})

try:
    for line in sys.stdin:
        try:
            request = json.loads(line)
            op = request.get("op")
            if op == "start":
                start(request)
            elif op == "execute":
                # stdin is explicit: input() fails visibly instead of freezing the entire run queue.
                mid = client.execute(request["code"], store_history=True, allow_stdin=False,
                                     stop_on_error=True)
                reply(request, {"message_id": mid})
            elif op == "interrupt":
                kernel.interrupt_kernel()
                reply(request, True)
            elif op == "shutdown":
                reply(request, True)
                break
            else:
                raise ValueError("Unknown notebook operation")
        except Exception as error:
            reply(request if "request" in locals() else {}, error=str(error))
finally:
    stopping.set()
    if client:
        client.stop_channels()
    if kernel:
        kernel.shutdown_kernel(now=True)
