const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
function fixture(){
 const events=[],saved=[],box={reqnode:require,AbortController,EditingToolbarAIWebProjects:class{target(){return null;} bind(){}},EditingToolbarAIWebTranslation:class{bind(){} decorate(){}},EditingToolbarWebChatBrowser:class{constructor(){this.capabilities={modes:[{label:'Medium'}]};}show(){events.push('show');}},EditingToolbarAITiming:{begin(){},finish(){}},ETAIExecution:{put(){},finish(){}}};
 vm.createContext(box);vm.runInContext(fs.readFileSync(require.resolve('./ai-web-chat.js'),'utf8')+';globalThis.Web=EditingToolbarAIWebChat',box);
 const image={name:'figure.png',data:'data:image/png;base64,YQ=='};
 const ai={config:{webChat:{mode:'Medium',version:'Latest'}},scope:{value:'document'},context:{file:'paper.md'},file:()=> 'paper.md',source:()=> '# Original',turns:[],followDocument:()=>true,profile:()=>({authType:'chatgpt-web'}),promptsManager:{reference:()=>({text:'Original'})},attachments:{selected:[]},notice:m=>events.push(m),busyState(b){this.busy=b;},scheduleRender(){},renderTurn(){},mountTurn(t){t.article={remove(){}};events.push('mounted');},conversations:{flush(){saved.push(JSON.parse(JSON.stringify(ai.turns)));},schedule(){}}};
 const draft={text:'What is in this image?',images:[image]};ai.composerUI={draft:{media:{snapshot:()=>draft.images.map(i=>({...i}))},quotes:{reference:()=>'',snapshot:()=>[]}},request:()=>({question:draft.text,displayQuestion:draft.text}),consumed(){draft.text='';draft.images=[];events.push('cleared');}};
 const web=new box.Web(ai);web.refreshUI=()=>{};ai.webChat=web;return {web,ai,draft,events,saved};
}
test('website input uses the user question without a fixed prefix or question heading',async()=>{
 const {web,ai}=fixture();ai.scope.value='none';ai.promptsManager.reference=()=>({text:''});const input=await web.input({question:'Exactly this question.'},new AbortController().signal);assert.equal(input.text,'Exactly this question.');assert.equal(input.files.length,1);
});
test('web send clears the captured draft before waiting for the website and retains mixed attachments',async()=>{
 const {web,ai,draft,events,saved}=fixture();web.browser.request=async opts=>{
  assert.equal(draft.text,'');assert.equal(draft.images.length,0);assert.deepEqual(events.slice(0,2),['mounted','cleared']);assert.equal(opts.files.length,2);assert.equal(ai.turns[0].webChat.input.text,'What is in this image?');
  draft.text='Next draft';opts.onBinding({submitted:true});assert.equal(draft.text,'Next draft');return {text:'Answer',url:'https://chatgpt.com/c/test'};
 };await web.send();assert.equal(ai.turns[0].status,'done');assert.equal(saved[0][0].webChat.input.files.length,2);assert.equal(events.filter(x=>x==='cleared').length,1);
});
test('failed unsubmitted message retries persisted bytes instead of current draft or document',async()=>{
 const {web,ai,draft}=fixture();web.browser.request=async()=>{throw Error('upload failed');};await web.send();const failed=ai.turns[0];assert.equal(failed.status,'error');assert.equal(draft.text,'');
 ai.source=()=> '# Changed';draft.text='Keep new draft';draft.images=[{name:'new.png',data:'data:image/png;base64,Yg=='}];web.input=async()=>{throw Error('must not recapture');};
 web.browser.request=async opts=>{assert.equal(Buffer.from(opts.files[0].base64,'base64').toString(),'# Original');assert.equal(opts.files[1].name,'figure.png');return {text:'Retried',url:'https://chatgpt.com/c/test'};};
 await web.send(failed);assert.equal(ai.turns.length,1);assert.equal(ai.turns[0].answer,'Retried');assert.equal(draft.text,'Keep new draft');assert.equal(draft.images[0].name,'new.png');
});
test('uncertain website submission is never retried or allowed to consume a new draft',async()=>{
 const {web,ai,draft,events}=fixture();web.browser.request=async opts=>{opts.onBinding({submitted:true});throw Object.assign(Error('ack lost'),{webSubmitted:true});};await web.send();draft.text='Keep me';await web.send(ai.turns[0]);assert.equal(draft.text,'Keep me');assert.equal(ai.turns.length,1);assert.ok(events.includes('show'));
});


test('recovering a submitted turn updates it in place and preserves a new draft and attachments',async()=>{
 const {web,ai,draft,events}=fixture();web.browser.request=async opts=>{opts.onBinding({submitted:true,url:'https://chatgpt.com/c/test',userCount:0,answerCount:0});throw Object.assign(Error('message match failed'),{webSubmitted:true});};await web.send();const turn=ai.turns[0];draft.text='Keep next question';draft.images=[{name:'new.png'}];let resumes=0;web.browser.request=async()=>assert.fail('must not resend');web.browser.resumeReply=async(binding,callbacks)=>{resumes++;assert.equal(binding.input.files[1].name,'figure.png');callbacks.onText('Recovered');callbacks.onBinding({userId:'bound'});return {text:'Recovered',url:binding.url};};
 await web.resume(turn);assert.equal(resumes,1);assert.equal(ai.turns.length,1);assert.equal(ai.turns[0],turn);assert.equal(turn.status,'done');assert.equal(turn.answer,'Recovered');assert.equal(draft.text,'Keep next question');assert.equal(draft.images[0].name,'new.png');assert.equal(events.filter(x=>x==='cleared').length,1);
});

test('automatic recovery is once per restored error and does not restart a user-stopped reception',async()=>{
 const {web,ai}=fixture();const turn={id:'saved',status:'error',webChat:{submitted:true,url:'https://chatgpt.com/c/test',input:{text:'Q'}}};ai.turns=[turn];let count=0;web.resume=async()=>count++;web.resumePending();web.resumePending();assert.equal(count,1);ai.turns=[{...turn,id:'stopped',status:'stopped',detail:'已停止本地接收'}];web.resumePending();assert.equal(count,1);ai.turns[0].detail='上次生成被中断，可重试';web.resumePending();assert.equal(count,2);
});
