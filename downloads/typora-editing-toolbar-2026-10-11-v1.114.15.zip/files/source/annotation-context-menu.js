import {TextSelection,NodeSelection} from 'prosemirror-state';
import {Slice} from 'prosemirror-model';
import {closeHistory} from 'prosemirror-history';
import {CellSelection} from 'prosemirror-tables';
import {tableMenuItems,inNoteTable,isNoteTableFrozen} from './annotation-tables.js';

export function createNoteContextMenu(view,schema,options,io,controls){
 const menu=document.createElement('div');menu.className='note-context-menu';menu.hidden=true;menu.setAttribute('role','menu');menu.setAttribute('aria-label',(options.label||'注释')+'右键菜单');document.body.append(menu);
 let saved=null,point=null,path=[],previousSelection=null,alive=true;
 const def=id=>id==='table-align-menu'?{title:'对齐',actions:['align-left','align-center','align-right']}:options.definition?.(id)||{title:id};
 const hide=()=>{menu.hidden=true;saved=null;path=[];};
 const valid=()=>alive&&saved&&view.state.doc===saved.doc;
 const restore=()=>{if(!valid()){hide();return false;}view.dispatch(view.state.tr.setSelection(saved.selection));return true;};
 const place=()=>{const r=menu.getBoundingClientRect();menu.style.left=Math.max(6,Math.min(point.x,innerWidth-r.width-6))+'px';menu.style.top=Math.max(6,Math.min(point.y,innerHeight-r.height-6))+'px';};
 const item=(label,id,fn,disabled=false,sub=false)=>{const b=document.createElement('button');b.type='button';b.setAttribute('role','menuitem');b.tabIndex=-1;b.dataset.contextAction=id;b.disabled=disabled;const text=document.createElement('span');text.textContent=label;b.append(text);if(sub){const arrow=document.createElement('span');arrow.textContent='›';arrow.className='note-context-arrow';b.append(arrow);b.setAttribute('aria-haspopup','menu');}b.onclick=fn;menu.append(b);return b;};
 const separator=()=>{const hr=document.createElement('hr');hr.setAttribute('role','separator');menu.append(hr);};
 function clipboard(kind){
  if(!restore())return;if(kind!=='copy'&&!view.editable)return hide();
  try{
   if(kind==='copy'||kind==='cut'){
    if(view.state.selection.empty)return hide();
    const {dom,text}=view.serializeForClipboard(view.state.selection.content());options.writeClipboard({text,html:dom.innerHTML});
    if(kind==='cut')view.dispatch(closeHistory(view.state.tr).deleteSelection().scrollIntoView());
   }else{
    const data=options.readClipboard();
    if(data.image){view.dispatch(closeHistory(view.state.tr));options.onNativeImage();}
    else if(data.text){const doc=io.parse(data.text);view.dispatch(closeHistory(view.state.tr).replaceSelection(Slice.maxOpen(doc.content)).scrollIntoView());}
    else if(data.html){view.dispatch(closeHistory(view.state.tr));view.pasteHTML(data.html);}
   }
   hide();view.focus();
  }catch(error){hide();options.notice?.('剪贴板操作未完成，请重试。');view.focus();}
 }
 function choose(id){
  if(!restore()||!view.editable)return hide();const origin={left:point.x,right:point.x,top:point.y,bottom:point.y,width:0,height:0};hide();controls.activate(id,origin);
 }
 function group(id){path.push(id);render();}
 function render(){
  menu.replaceChildren();menu.scrollTop=0;
  if(!path.length){
   const empty=!saved||saved.selection.empty;
   item('剪切','cut',()=>clipboard('cut'),!view.editable||empty);
   item('复制','copy',()=>clipboard('copy'),empty);
   item('粘贴','paste',()=>clipboard('paste'),!view.editable);
   if(options.onCollect)item('暂存素材','collect-material',()=>{if(!restore())return;hide();options.collectSelection?.();},empty);
   separator();
   for(const [id,label] of [['paragraph-menu','段落'],['math-menu','数学'],['insert-menu','插入']])item(label,id,()=>group(id),!view.editable,true);
   if(inNoteTable(view.state)){separator();item('对齐','table-align-menu',()=>group('table-align-menu'),!view.editable,true);const frozen=isNoteTableFrozen(view.state),freeze=item(frozen?'取消冻结首行':'冻结首行','table-freeze-header',()=>choose('table-freeze-header'),!view.editable);freeze.setAttribute('role','menuitemcheckbox');freeze.setAttribute('aria-checked',String(frozen));for(const [id,label] of tableMenuItems)item(label,id,()=>choose(id),!view.editable);}
  }else{
   const id=path.at(-1),d=def(id);item('‹ '+(id==='paragraph-menu'?'段落':d.title),'back',()=>{path.pop();render();});separator();
   const definitions=d.menuItems||d.actions?.map(id=>id==='|'?{type:'divider'}:{id,label:def(id).title})||[];
   const entries=id==='paragraph-menu'?[...['paragraph','h1','h2','h3','h4','h5','h6'].map(id=>({id,label:id==='paragraph'?'正文':def(id).title})),{type:'divider'},...definitions]:definitions;
   for(const entry of entries){if(entry.type==='divider'){separator();continue;}if(entry.type==='header'){const h=document.createElement('div');h.className='note-context-label';h.textContent=entry.label;menu.append(h);continue;}const d=def(entry.id),sub=!!(d.actions||d.menuItems);item(entry.label||entry.title||d.title,entry.id,()=>sub?group(entry.id):choose(entry.id),!view.editable,sub);}
  }
  place();
 }
 function open(event,keyboard=false){
  if(event.target.closest('input,textarea,video')){previousSelection=null;return;}
  event.preventDefault();event.stopPropagation();controls.beforeOpen();
  const previous=!keyboard&&previousSelection?.doc===view.state.doc?previousSelection:null;let selection=previous?.selection||view.state.selection;previousSelection=null;
  if(!keyboard){
   const domSelection=document.getSelection(),rects=previous?.rects||(domSelection?.rangeCount?[...domSelection.getRangeAt(0).getClientRects()]:[]);
   if(selection instanceof CellSelection)selection.forEachCell((n,pos)=>{const el=view.nodeDOM(pos);if(el)rects.push(el.getBoundingClientRect());});
   const inSelection=!selection.empty&&rects.some(r=>event.clientX>=r.left&&event.clientX<=r.right&&event.clientY>=r.top&&event.clientY<=r.bottom);
   if(!inSelection){const hit=view.posAtCoords({left:event.clientX,top:event.clientY});if(hit){const node=hit.inside>=0?view.state.doc.nodeAt(hit.inside):null;selection=node?.isAtom&&NodeSelection.isSelectable(node)?NodeSelection.create(view.state.doc,hit.inside):TextSelection.near(view.state.doc.resolve(hit.pos));}}
  }
  view.dispatch(view.state.tr.setSelection(selection));saved={doc:view.state.doc,selection:view.state.selection};
  const caret=keyboard?view.coordsAtPos(selection.from):null;point={x:caret?.left??event.clientX,y:caret?.bottom??event.clientY};path=[];menu.hidden=false;render();
  if(keyboard)menu.querySelector('button:not(:disabled)')?.focus({preventScroll:true});
 }
 const down=e=>{if(e.button===2){const s=document.getSelection();previousSelection={doc:view.state.doc,selection:view.state.selection,rects:s?.rangeCount?[...s.getRangeAt(0).getClientRects()]:[]};}};
 const context=e=>open(e);
 const outside=e=>{if(!menu.contains(e.target))hide();};
 const keys=e=>{
  if(menu.hidden){if(view.dom.contains(e.target)&&(e.key==='ContextMenu'||(e.shiftKey&&e.key==='F10')))open(e,true);return;}
  if(!['Escape','ArrowDown','ArrowUp','ArrowLeft','ArrowRight','Home','End','Enter',' ','Tab'].includes(e.key))return;
  e.preventDefault();e.stopPropagation();
  if(e.key==='Escape'||e.key==='Tab'){hide();view.focus();return;}
  if(e.key==='ArrowLeft'){if(path.length){path.pop();render();menu.querySelector('button:not(:disabled)')?.focus();}return;}
  const buttons=[...menu.querySelectorAll('button:not(:disabled)')],i=buttons.indexOf(document.activeElement);
  if(e.key==='Enter'||e.key===' '||e.key==='ArrowRight'){if(i>=0)buttons[i].click();return;}
  const index=e.key==='Home'?0:e.key==='End'?buttons.length-1:i<0?(e.key==='ArrowUp'?buttons.length-1:0):(i+(e.key==='ArrowUp'?-1:1)+buttons.length)%buttons.length;buttons[index]?.focus();
 };
 menu.addEventListener('mousedown',e=>e.preventDefault());menu.addEventListener('contextmenu',e=>e.preventDefault());
 view.dom.addEventListener('mousedown',down,true);view.dom.addEventListener('contextmenu',context);
 document.addEventListener('mousedown',outside);document.addEventListener('keydown',keys,true);window.addEventListener('blur',hide);window.addEventListener('resize',hide);window.addEventListener('scroll',hide);
 return{get visible(){return !menu.hidden;},hide,destroy(){alive=false;hide();menu.remove();view.dom.removeEventListener('mousedown',down,true);view.dom.removeEventListener('contextmenu',context);document.removeEventListener('mousedown',outside);document.removeEventListener('keydown',keys,true);window.removeEventListener('blur',hide);window.removeEventListener('resize',hide);window.removeEventListener('scroll',hide);}};
}
