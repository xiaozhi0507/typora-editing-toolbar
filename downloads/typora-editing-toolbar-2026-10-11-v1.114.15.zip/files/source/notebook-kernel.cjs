'use strict';
class NotebookKernel {
 constructor(requireNode,options={}){this.require=requireNode;this.options=options;this.pending=new Map();this.runs=new Map();this.early=new Map();this.state='off';this.serial=0;}
 notify(state){this.state=state;this.options.onState?.(state);}
 async start(){
  if(this.starting)return this.starting;if(this.proc)return;
  this.starting=(async()=>{this.notify('starting');const cp=this.require('child_process');this.proc=cp.spawn(this.options.python,['-u',this.options.bridge],{windowsHide:true,cwd:this.options.cwd,env:{...this.require('process').env,...this.options.env,PYTHONIOENCODING:'utf-8'},stdio:['pipe','pipe','pipe']});
   let buffer='';this.diagnostics='';const owned=this.proc;this.proc.stdout.setEncoding('utf8');this.proc.stdout.on('data',s=>{buffer+=s;if(buffer.length>32*1024*1024){this.fail(Error('内核输出超过限制'));return;}let at;while((at=buffer.indexOf('\n'))>=0){const line=buffer.slice(0,at);buffer=buffer.slice(at+1);try{this.message(JSON.parse(line));}catch(e){this.options.onDiagnostic?.(e.message);}}});this.proc.stderr.setEncoding('utf8');this.proc.stderr.on('data',s=>{this.diagnostics=(this.diagnostics+s).slice(-8000);});this.proc.on('error',e=>this.fail(e));this.proc.on('exit',code=>{if(this.proc!==owned)return;this.proc=null;this.fail(Error('Notebook 内核已退出'+(code?'（'+code+'）':'')+(this.diagnostics?'：'+this.diagnostics.slice(-1200):'')));});
   try{const info=await this.call('start',{cwd:this.options.cwd,env:this.options.env},35000);this.notify('idle');return info;}catch(e){await this.shutdown();throw Error('启动 Notebook 失败：'+e.message+'。所选环境需要 ipykernel 和 jupyter_client。');}
  })().finally(()=>{this.starting=null;});return this.starting;
 }
 call(op,args={},timeout=10000){return new Promise((resolve,reject)=>{if(!this.proc?.stdin?.writable)return reject(Error('内核未连接'));const id=++this.serial,timer=setTimeout(()=>{this.pending.delete(id);reject(Error(op+' 操作超时'));},timeout);this.pending.set(id,{resolve,reject,timer});this.proc.stdin.write(JSON.stringify({id,op,...args})+'\n',e=>{if(e){clearTimeout(timer);this.pending.delete(id);reject(e);}});});}
 message(m){
  if(m.type==='fatal'){this.fail(Error(m.error));this.proc?.stdin.end();return;}
  if(m.type==='reply'){const p=this.pending.get(m.id);if(p){clearTimeout(p.timer);this.pending.delete(m.id);m.error?p.reject(Error(m.error)):p.resolve(m.result);}return;}
  if(m.type!=='event')return;
  const run=this.runs.get(m.parent);if(!run){if(this.executing){const rows=this.early.get(m.parent)||[];if(rows.length<1000)rows.push(m);this.early.set(m.parent,rows);}return;}
  this.event(run,m);
 }
 event(run,m){
  const c=m.content;
  if(m.event==='status'&&c.execution_state==='idle')run.idle=true;
  if(m.event==='execute_reply'){run.reply=c;}
  this.options.onEvent?.(run.cellId,m.event,c);
  if(run.reply&&run.idle&&!run.done){run.done=true;this.executing=false;this.notify('idle');run.resolve(run.reply);/* Retain routing for background display updates until restart. */if(this.runs.size>500)this.runs.delete(this.runs.keys().next().value);}
 }
 async execute(cellId,code){
  await this.start();if(this.executing)throw Error('内核忙碌，请等待当前单元格结束');this.executing=true;this.notify('busy');
  try{const result=await this.call('execute',{code});return await new Promise((resolve,reject)=>{const run={cellId,resolve,reject};this.runs.set(result.message_id,run);const rows=this.early.get(result.message_id)||[];this.early.clear();for(const m of rows)this.event(run,m);});}catch(e){this.executing=false;this.notify('idle');throw e;}
 }
 interrupt(){return this.call('interrupt');}
 fail(e){for(const p of this.pending.values()){clearTimeout(p.timer);p.reject(e);}this.pending.clear();for(const r of this.runs.values())if(!r.done)r.reject(e);this.runs.clear();this.early.clear();this.executing=false;this.notify('off');}
 async shutdown(){const p=this.proc;if(!p)return;try{await this.call('shutdown',{},2000);}catch{}p.stdin.end();await new Promise(resolve=>{const timer=setTimeout(()=>{if(this.require('process').platform==='win32')this.require('child_process').execFile('taskkill',['/PID',String(p.pid),'/T','/F'],{windowsHide:true},()=>resolve());else{p.kill('SIGKILL');resolve();}},5000);p.once('exit',()=>{clearTimeout(timer);resolve();});});this.proc=null;this.fail(Error('内核已关闭'));}
}
module.exports={NotebookKernel};
