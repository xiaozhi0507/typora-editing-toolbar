const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const {JSDOM}=require('jsdom');
function setup(t){const d=new JSDOM('<body></body>',{url:'https://local.test',runScripts:'outside-only'});t.after(()=>d.window.close());const w=d.window;w.reqnode=require;w.__editingToolbarNoAutoInit=true;return {w,context:d.getInternalVMContext(),load(file,name){return vm.runInContext(fs.readFileSync(path.join(__dirname,file),'utf8')+'\n'+name,d.getInternalVMContext());}};}
test('recent colors are separate, deduplicated, bounded, and survive a new toolbar instance',t=>{
 const f=setup(t),Toolbar=f.load('base/editing-toolbar.js','EditingToolbarPlugin'),a=new Toolbar();
 for(let i=0;i<13;i++)a._rememberColor('font-color','#'+i.toString(16).padStart(6,'0'));
 a._rememberColor('bg-color','#ffccaa');a._rememberColor('font-color','#00000a');a._rememberColor('font-color','bad');
 const b=new Toolbar();assert.equal(b._colorHistory('font-color').length,10);assert.equal(b._colorHistory('font-color')[0],'#00000A');assert.equal(b._colorHistory('bg-color')[0],'#FFCCAA');assert.equal(new Set(b._colorHistory('font-color')).size,10);
 f.w.localStorage.setItem('editing-toolbar-color-history-v1','bad json');assert.equal(b._colorHistory('font-color').length,0);
});
test('size settings migrate legacy presets, clamp values, and compact without enlarging small buttons',t=>{
 const f=setup(t),Toolbar=f.load('base/editing-toolbar.js','EditingToolbarPlugin'),a=new Toolbar(),bar=f.w.document.createElement('div');
 for(const [size,pixels] of Object.entries({small:28,normal:32,large:38}))assert.equal(a._normalizeToolbarSettings({version:1,size}).buttonSize,pixels);
 a.uiSettings=a._normalizeToolbarSettings({...a._defaultToolbarSettings(),buttonSize:40,topMode:'floating',topCollapsed:true,responsive:false});
 assert.equal(a.uiSettings.topMode,'floating');assert.equal(a.uiSettings.topCollapsed,false);assert.equal(a.uiSettings.responsive,true);
 f.w.localStorage.setItem('editing-toolbar-layout-v1',JSON.stringify(a.uiSettings));assert.equal(new Toolbar()._loadToolbarSettings().buttonSize,40);
 Object.defineProperty(f.w.document.documentElement,'clientWidth',{value:1200,configurable:true});a._applyToolbarButtonSize(bar,true);assert.equal(bar.style.getPropertyValue('--et-button-size'),'40px');
 Object.defineProperty(f.w.document.documentElement,'clientWidth',{value:800,configurable:true});a._applyToolbarButtonSize(bar,true);assert.equal(bar.style.getPropertyValue('--et-button-size'),'28px');
 a.uiSettings.buttonSize=24;a._applyToolbarButtonSize(bar,true);assert.equal(bar.style.getPropertyValue('--et-button-size'),'24px');
 assert.equal(a._toolbarButtonSize({buttonSize:100}),44);assert.equal(a._toolbarButtonSize({buttonSize:-1}),24);
});
test('recent translucent background colors preserve alpha after reload and reject unsafe values',t=>{
 const f=setup(t),Toolbar=f.load('base/editing-toolbar.js','EditingToolbarPlugin'),a=new Toolbar();
 a._rememberColor('bg-color','rgba(218,208,216,0.45)');a._rememberColor('bg-color','rgba(218, 208, 216, 0.45)');
 for(const bad of ['url(https://example.test)','rgba(999,0,0,0.5)','rgba(0,0,0,2)','red'])a._rememberColor('bg-color',bad);
 const b=new Toolbar();assert.equal(b._colorHistory('bg-color').length,1);assert.equal(b._colorHistory('bg-color')[0],'rgba(218, 208, 216, 0.45)');assert.equal(b._colorHistory('font-color').length,0);
});
test('history swatch preserves the selection path and updates every open palette without cross-kind colors',t=>{
 const f=setup(t),Toolbar=f.load('base/editing-toolbar.js','EditingToolbarPlugin'),a=new Toolbar(),calls=[];
 a._saveSelection=()=>calls.push('selection');a._applySelectionStyle=(k,v)=>calls.push([k,v]);a._closeActivePopover=()=>calls.push('close');
 for(const kind of ['font-color','bg-color']){const root=f.w.document.createElement('section');root.className='et-color-history';root.dataset.colorKind=kind;f.w.document.body.append(root);a._renderColorHistory(root,kind);}
 a._rememberColor('font-color','#295bba');a._rememberColor('bg-color','#fff176');
 const swatch=f.w.document.querySelector('[data-color-kind="font-color"] button');swatch.dispatchEvent(new f.w.MouseEvent('mousedown',{bubbles:true,cancelable:true}));swatch.click();
 assert.deepEqual(calls,['selection',['color','#295BBA'],'close']);assert.equal(f.w.document.querySelector('[data-color-kind="bg-color"] button').title,'#FFF176');
});
test('screen picker can be removed while manual color and hex selection remain available',t=>{
 const f=setup(t),source=fs.readFileSync(path.join(__dirname,'palette-picker.js'),'utf8').replace('export function','function');
 const attach=vm.runInContext(source+'\nattachPalettePicker',f.context),host=f.w.document.createElement('div'),row=f.w.document.createElement('div'),input=f.w.document.createElement('input'),apply=f.w.document.createElement('button');row.append(input,apply);host.append(row);f.w.document.body.append(host);
 attach({host,row,input,apply,screenPicker:false,capture(){},valid:()=>true,eyeDropper:()=>{throw Error('should not open');},message(){}});
 assert.equal(row.querySelector('.et-palette-eye'),null);const color=row.querySelector('[type=color]');color.value='#123456';color.dispatchEvent(new f.w.Event('input'));assert.equal(input.value,'#123456');
});
test('manual refresh coalesces repeated clicks, preserves controls and flashes only after success',async t=>{
 const f=setup(t),Skills=f.load('ai-skills.js','EditingToolbarAISkills'),ui=new Skills({}),owner={reload:f.w.document.createElement('button'),list:f.w.document.createElement('div')};f.w.document.body.append(owner.reload,owner.list);
 let resolve,calls=0;const run=()=>{calls++;return new Promise(r=>resolve=r);};const one=ui.refreshFeedback(owner,run),two=ui.refreshFeedback(owner,run);await new Promise(r=>setImmediate(r));assert.equal(calls,1);assert(owner.reload.disabled);assert(owner.reload.classList.contains('is-refreshing'));resolve(42);await Promise.all([one,two]);assert(!owner.reload.disabled);assert(!owner.reload.hasAttribute('aria-busy'));assert(owner.list.classList.contains('et-refresh-flash'));
 owner.list.classList.remove('et-refresh-flash');await assert.rejects(ui.refreshFeedback(owner,()=>Promise.reject(Error('offline'))),/offline/);assert(!owner.reload.disabled);assert(!owner.list.classList.contains('et-refresh-flash'));
});
test('document tab drop adds an attachment without sending or granting project edit access',async t=>{
 const f=setup(t),Media=f.load('ai-input-media.js','EditingToolbarAIInputMedia'),calls=[],ai={busy:false,toolbar:{documentTabs:{supported:p=>/\.md$/i.test(p)}},notice:m=>calls.push(m),attachments:{pending:false,locked:()=>false,add:async rows=>calls.push(rows)},composerUI:{}};
 const media=new Media(ai,()=>{}),file=path.resolve('fixture.md'),dt={types:['application/x-et-document-tab'],getData:()=>file};media.surface=f.w.document.createElement('div');
 assert(media.acceptsDrop({dataTransfer:dt,target:f.w.document.body}));await media.receive(dt);assert.equal(calls[0][0].path,file);assert.equal(calls[0][0].location,'标签页');
 assert(!media.acceptsDrop({dataTransfer:{types:[...dt.types,'application/x-et-project-files']},target:f.w.document.body}));
 ai.attachments.locked=()=>true;await media.receive(dt);assert.match(calls[1],/锁定/);ai.attachments.locked=()=>false;await media.receive({...dt,getData:()=>''});assert.match(calls[2],/已保存/);
});
test('split capture does not steal a tab dropped onto the AI panel',t=>{
 const f=setup(t),Split=f.load('document-split.js','EditingToolbarDocumentSplit'),s=Object.create(Split.prototype),panel=f.w.document.createElement('section');panel.id='et-ai-panel';const child=f.w.document.createElement('div');panel.append(child);f.w.document.body.append(panel);s.enabled=true;s.dragFile='document.md';let removed=0;s.preview={remove:()=>removed++};const e={target:child,preventDefault(){throw Error('split must not consume');},stopImmediatePropagation(){throw Error('split must not consume');}};s.dragOver(e);assert.equal(removed,1);assert.equal(s.preview,null);s.drop(e);assert.equal(s.dragFile,null);
});
test('loose code tabs expose a reference payload and automatic pin order remains immutable',t=>{
 const f=setup(t),Tabs=f.load('document-tabs.js','EditingToolbarDocumentTabs'),tabs=Object.create(Tabs.prototype),row=f.w.document.createElement('div');row.dataset.path=path.resolve('main.py');const button=f.w.document.createElement('button');button.className='et-dt-open';row.append(button);f.w.document.body.append(row);tabs.toolbar={codeEditor:{supported:p=>/\.(py|ipynb)$/i.test(p)}};tabs.supported=p=>/\.md$/i.test(p);tabs.list=f.w.document.body;tabs.bindReferenceDrag(row);
 const data=new Map(),start={target:button,preventDefault(){this.defaultPrevented=true;},stopPropagation(){},dataTransfer:{setData:(k,v)=>data.set(k,v)}};row.ondragstart(start);assert.equal(data.get('application/x-et-code-file'),row.dataset.path);assert(row.draggable);
 row.dataset.path=path.resolve('pinned.md');let moved=0;tabs.bindSort(row,{kind:'pinned',group:'pinned',key:'a',enabled:false,move:()=>moved++});data.clear();row.ondragstart(start);assert.equal(data.get('application/x-et-document-tab'),row.dataset.path);assert(!data.has('application/x-et-sidebar-order'));assert.equal(tabs.sortDrag,null);tabs.sortDrag={kind:'pinned',group:'pinned',key:'b'};row.ondrop({preventDefault(){throw Error('must not reorder');}});assert.equal(moved,0);
});

function settingsFixture(t){const f=setup(t),Toolbar=f.load('base/editing-toolbar.js','EditingToolbarPlugin'),a=new Toolbar();f.w.attachMovablePreferences=()=>()=>{};f.w.HTMLElement.prototype.scrollIntoView=()=>{};for(const name of ['_saveSelection','_closeActivePopover','hide','_returnToEditor','_applyToolbarLayout'])a[name]=()=>{};a.uiSettings=a._defaultToolbarSettings();a._openToolbarSettings();const row=(key,id)=>f.w.document.querySelector(`[data-list="${key}"] [data-row="${id}"]`),ids=(key,scope)=>Array.from(f.w.document.querySelectorAll(`[data-list="${key}"] [data-scope="${scope}"]`),n=>n.dataset.row);return {...f,a,row,ids,save:()=>f.w.document.querySelector('[data-save]').click()};}
test('toolbar groups reopen collapsed and group selection never removes or expands the row',t=>{
 const f=settingsFixture(t),group=()=>f.row('top','heading-menu');assert.equal(f.w.document.querySelectorAll('.et-settings-child').length,0);const roots=f.ids('top','root');group().querySelector('input').click();assert.deepEqual(f.ids('top','root'),roots);assert.equal(group().querySelector('input').checked,false);assert.equal(group().querySelector('[aria-expanded]').getAttribute('aria-expanded'),'false');group().querySelector('.et-settings-expand').click();assert.equal(f.ids('top','menu:heading-menu').length,6);assert([...f.w.document.querySelectorAll('[data-scope="menu:heading-menu"] input')].every(n=>!n.checked));f.save();assert(!f.a.uiSettings.top.includes('heading-menu'));f.a._openToolbarSettings();assert(group());assert.equal(group().querySelector('[aria-expanded]').getAttribute('aria-expanded'),'false');group().querySelector('input').click();assert.equal(f.w.document.querySelectorAll('.et-settings-child').length,0);f.save();assert(f.a.uiSettings.top.includes('heading-menu'));
});
test('unchecked child and floating rows retain position, while saved layout excludes them',t=>{
 const f=settingsFixture(t);f.row('top','heading-menu').querySelector('.et-settings-expand').click();const children=f.ids('top','menu:heading-menu'),floating=f.ids('floating','flat');f.row('top','h2').querySelector('input').click();assert.deepEqual(f.ids('top','menu:heading-menu'),children);assert(f.row('top','heading-menu').querySelector('input').indeterminate);f.row('floating','redo').querySelector('input').click();assert.deepEqual(f.ids('floating','flat'),floating);assert.equal(f.row('floating','redo').querySelector('input').checked,false);f.row('floating','redo').querySelector('input').click();assert.deepEqual(f.ids('floating','flat'),floating);f.save();assert(!f.a.uiSettings.layouts.compact.menus['heading-menu'].includes('h2'));assert.deepEqual([...f.a.uiSettings.floating],floating);
});
test('rechecking restores order after keyboard sorting and cancel does not persist changes',t=>{
 const f=settingsFixture(t),before=JSON.stringify(f.a.uiSettings);f.row('floating','redo').querySelector('.et-drag-handle').dispatchEvent(new f.w.KeyboardEvent('keydown',{key:'ArrowDown',bubbles:true}));const reordered=f.ids('floating','flat');assert.equal(reordered[2],'redo');f.row('floating','redo').querySelector('input').click();f.row('floating','redo').querySelector('input').click();assert.deepEqual(f.ids('floating','flat'),reordered);f.w.document.querySelector('[data-close]').click();assert.equal(JSON.stringify(f.a.uiSettings),before);assert.equal(f.w.localStorage.getItem('editing-toolbar-layout-v1'),null);
});
test('dragging into and out of More keeps row caches and saved membership in sync',t=>{
 const f=settingsFixture(t);const drag=(from,to)=>{const data={setData(){}};for(const [node,type] of [[from.querySelector('.et-drag-handle'),'dragstart'],[to,'drop']]){const e=new f.w.Event(type,{bubbles:true,cancelable:true});Object.defineProperties(e,{dataTransfer:{value:data},clientY:{value:0}});node.dispatchEvent(e);}};
 const original=[...f.a.uiSettings.layouts.compact.menus['more-menu']];drag(f.row('top','undo'),f.row('top','more-menu'));assert.equal(f.row('top','undo').dataset.scope,'menu:more-menu');assert(f.ids('top','menu:more-menu').includes(original[0]));drag(f.row('top','undo'),f.row('top','redo'));assert.equal(f.row('top','undo').dataset.scope,'root');assert(!f.ids('top','menu:more-menu').includes('undo'));f.save();assert(f.a.uiSettings.layouts.compact.order.includes('undo'));assert.deepEqual([...f.a.uiSettings.layouts.compact.menus['more-menu']],original);
});
test('answer effect is chosen once per request, avoids adjacent repeats and clears on completion',t=>{
 const f=setup(t),AI=f.load('ai-assistant.js','EditingToolbarAI'),a=Object.create(AI.prototype);a.panel=f.w.document.createElement('section');a.panel.innerHTML='<button data-ai="stop"></button><button data-ai="send"></button>';a.model={};a.composerUI={closeMenu(){},sync(){}};a.updateContext=a.checkDocument=()=>{};let randomCalls=0;f.w.Math.random=()=>{randomCalls++;return .5};const seen=[];for(let i=0;i<6;i++){a.busyState(true);const chosen=a.panel.dataset.workingEffect;seen.push(chosen);a.busyState(true);assert.equal(a.panel.dataset.workingEffect,chosen);a.busyState(false);assert.equal(a.panel.dataset.generating,'false');assert(!('workingEffect' in a.panel.dataset));}assert.equal(randomCalls,6);assert(seen.every((s,i)=>!i||s!==seen[i-1]));assert(seen.every(s=>['orbit','comet','aurora','pulse'].includes(s)));
});
