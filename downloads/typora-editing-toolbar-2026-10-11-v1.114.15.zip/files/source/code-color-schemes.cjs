'use strict';
const colorKeys=['background','foreground','cursor','comment','keyword','string','number','function'];
const presets=[['auto','跟随软件'],['dark','参考深色'],['light','清爽浅色'],['classic','经典配色']];
function colors(input){
 input=input&&typeof input==='object'?input:{};
 const out={mode:presets.some(([id])=>id===input.mode)?input.mode:'auto'};
 for(const key of colorKeys)if(typeof input[key]==='string'&&/^#[\da-f]{6}$/i.test(input[key]))out[key]=input[key].toLowerCase();
 return out;
}
function merge(current,palette){const out={...current};for(const key of colorKeys)delete out[key];return {...out,...colors(palette)};}
function same(a,b){return JSON.stringify(colors(a))===JSON.stringify(colors(b));}
function normalize(input){
 input=input&&typeof input==='object'?input:{};
 const schemes=[],ids=new Set(),names=new Set();
 for(const entry of Array.isArray(input.schemes)?input.schemes:[]){
  if(schemes.length>=30)break;
  if(!entry||typeof entry.id!=='string'||!/^scheme-[\w-]{1,80}$/.test(entry.id)||typeof entry.name!=='string')continue;
  const name=entry.name.replace(/[\x00-\x1f\x7f]/g,'').trim().slice(0,40),key=name.toLowerCase();
  if(!name||ids.has(entry.id)||names.has(key))continue;
  ids.add(entry.id);names.add(key);schemes.push({id:entry.id,name,colors:colors(entry.colors)});
 }
 const valid=presets.some(([id])=>'builtin:'+id===input.defaultId)||ids.has(input.defaultId);
 return {version:1,schemes,defaultId:valid?input.defaultId:''};
}
function resolve(db,id){const builtin=presets.find(([mode])=>'builtin:'+mode===id);return builtin?{mode:builtin[0]}:db.schemes.find(x=>x.id===id)?.colors||null;}
function label(db,id){return presets.find(([mode])=>'builtin:'+mode===id)?.[1]||db.schemes.find(x=>x.id===id)?.name||'沿用上次配色';}
class ColorSchemes{
 constructor(storage){this.storage=storage;this.key='et-code-color-schemes-v1';this.read();}
 read(){try{this.data=normalize(JSON.parse(this.storage.getItem(this.key)));}catch{this.data=normalize();}return this.data;}
 commit(next){next=normalize(next);this.storage.setItem(this.key,JSON.stringify(next));this.data=next;return next;}
 create(name,palette){
  this.read();name=String(name||'').trim();
  if(!name||name.length>40||/[\x00-\x1f\x7f]/.test(name))throw Error('请输入 1–40 个字符的方案名称');
  if(this.data.schemes.some(x=>x.name.toLowerCase()===name.toLowerCase()))throw Error('已存在同名方案，请使用其他名称');
  if(this.data.schemes.length>=30)throw Error('最多保存 30 个方案，请先删除不再使用的方案');
  const id='scheme-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10);
  this.commit({...this.data,schemes:[...this.data.schemes,{id,name,colors:colors(palette)}]});return id;
 }
 update(id,palette){this.read();if(!this.data.schemes.some(x=>x.id===id))throw Error('方案已不存在');this.commit({...this.data,schemes:this.data.schemes.map(x=>x.id===id?{...x,colors:colors(palette)}:x)});}
 remove(id){this.read();if(!this.data.schemes.some(x=>x.id===id))throw Error('方案已不存在');this.commit({...this.data,schemes:this.data.schemes.filter(x=>x.id!==id),defaultId:this.data.defaultId===id?'builtin:auto':this.data.defaultId});}
 setDefault(id){this.read();if(!resolve(this.data,id))throw Error('请先保存当前配色为方案');this.commit({...this.data,defaultId:id});}
 startup(current){this.read();const palette=resolve(this.data,this.data.defaultId);return palette?merge(current,palette):current;}
}
module.exports={ColorSchemes,colorKeys,presets,colors,merge,same,normalize,resolve,label};
