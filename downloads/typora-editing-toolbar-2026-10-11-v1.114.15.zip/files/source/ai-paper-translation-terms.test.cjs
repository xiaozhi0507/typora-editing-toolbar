const test=require('node:test'),assert=require('node:assert/strict');
const PT=require('./ai-paper-translation.cjs');
const packet=(id,text)=>JSON.stringify({translations:[{id,text}]});
test('natural Chinese compression is accepted without a character or language ratio',async()=>{
 for(const [english,chinese] of [['sprinkler irrigation','喷灌'],['evapotranspiration','蒸散'],['It was not necessary to carry out any additional irrigation.','无需补灌。'],['The measurements were not statistically significantly different from one another.','差异不显著。'],['The cultivar used was Citrus reticulata Blanco.','Citrus reticulata Blanco']]){
  const units=PT.plan(english).units;let calls=0;
  const result=await PT.translateChunk(units,async pending=>{calls++;return PT.accept(pending,packet('L1',chinese));});
  assert.equal(result.get('L1'),chinese);assert.equal(calls,1);
 }
});
test('a complete experimental sentence allows Chinese word order around age and plant height',()=>{
 const units=PT.plan('A potted citrus tree (5-year-old) was used for the experiment, with a plant height of 156 cm.').units;
 const result=PT.accept(units,packet('L1','试验采用一株盆栽柑橘树（⟦ET0⟧年生），株高⟦ET1⟧ cm。'));
 assert.equal(result.get('L1'),'试验采用一株盆栽柑橘树（5年生），株高156 cm。');
 const input=PT.input(units).segments[0];assert.equal(input.text,units[0].text);assert(!('parts' in input));assert.deepEqual(input.locked.map(t=>t.value),['5','156']);
});
test('headings and table terms preserve structure without minimum text length',()=>{
 for(const [source,text,expected] of [['# Evapotranspiration','⟦ET0⟧蒸散','# 蒸散'],['| sprinkler irrigation |','⟦ET0⟧喷灌⟦ET1⟧','|喷灌|'],['**sprinkler irrigation**','⟦ET0⟧喷灌⟦ET1⟧','**喷灌**']])assert.equal(PT.accept(PT.plan(source).units,packet('L1',text)).get('L1'),expected);
});
test('new markup, blank paragraphs and missing numeric markers still fail',()=>{
 const units=PT.plan('A potted tree was 5 years old.').units;
 for(const text of ['', '⟦ET0⟧', '中文 <img src=x> ⟦ET0⟧','一株盆栽树。'])assert.throws(()=>PT.accept(units,packet('L1',text)),e=>e.code==='PAPER_TRANSLATION_VALIDATION');
});
