'use strict';
// Explicitly attached files are the only code-edit targets. The disk and live
// model are checked again after review, before either can be changed.
class AICodeFiles {
 constructor(req,store,manager,editor){Object.assign(this,{req,store,manager,editor});this.path=req('path');}
 key(file){return this.path.resolve(file).toLowerCase();}
 owner(file){return this.manager.items.filter(p=>{const r=this.path.relative(p.root,file);return r&&r!=='..'&&!r.startsWith('..'+this.path.sep)&&!this.path.isAbsolute(r);}).sort((a,b)=>b.root.length-a.root.length)[0];}
 async validate(target){
  this.manager.read?.();const p=this.owner(target.file);if(!p?.trusted||p.id!==target.projectId||p.root!==target.projectRoot)throw Error('代码所属项目已更改，请重新拖入文件');
  await this.manager.core.existingFile(p,target.file);return p;
 }
 async read(target){
  await this.validate(target);const disk=this.store.read(target.file),record=this.editor.records.get(this.key(disk.file));
  if(record&&!this.store.unchanged(record))throw Error('代码在外部发生了修改，请先重新载入或保存草稿副本');
  const text=record?record.model.getValue():disk.text;if(text.length>100000)throw Error('代码文件超过 10 万字符，请缩小文件');
  return {target:{...target,file:disk.file},disk,text,record};
 }
 async check(snapshot){
  await this.validate(snapshot.target);if(!this.store.unchanged(snapshot.disk))throw Error('等待期间文件已变化，本次修改未应用，请重新读取');
  const current=this.editor.records.get(this.key(snapshot.target.file));if((current?current.model.getValue():snapshot.disk.text)!==snapshot.text)throw Error('代码已有后续修改，本次修改未应用，请重新读取');return current;
 }
 async commit(snapshot,next){
  const record=await this.check(snapshot);const saved=this.store.save(snapshot.disk,next);
  if(record){record.model.pushStackElement();record.model.pushEditOperations([],[{range:record.model.getFullModelRange(),text:next}],()=>null);record.model.pushStackElement();Object.assign(record,saved);record.wasDirty=false;record.problem='';this.editor.persistDrafts();this.editor.renderTabs();this.editor.status();this.editor.sidebar();}
  const change={file:saved.file,projectId:snapshot.target.projectId,projectRoot:snapshot.target.projectRoot,before:snapshot.text,beforeDisk:snapshot.disk.text,after:next,afterHash:this.req('crypto').createHash('sha256').update(saved.base).digest('hex'),time:new Date().toISOString(),hadDraft:snapshot.text!==snapshot.disk.text};
  // Continue from our own successful write; check() still rejects later disk/model changes.
  Object.assign(snapshot,{disk:saved,text:next,record});return change;
 }
 async undo(change){
  const snapshot=await this.read(change);if(snapshot.text!==change.after||this.req('crypto').createHash('sha256').update(snapshot.disk.base).digest('hex')!==change.afterHash)throw Error('文件已有后续修改，不能直接撤销这次变更');
  const record=await this.check(snapshot),saved=this.store.save(snapshot.disk,change.beforeDisk??change.before);
  if(record){record.model.pushStackElement();record.model.pushEditOperations([],[{range:record.model.getFullModelRange(),text:change.before}],()=>null);record.model.pushStackElement();Object.assign(record,saved);record.wasDirty=record.model.getValue()!==record.text;this.editor.persistDrafts();this.editor.renderTabs();this.editor.status();this.editor.sidebar();}
  change.undone=true;return true;
 }
}
module.exports=AICodeFiles;
