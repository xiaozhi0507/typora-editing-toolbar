const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const { JSDOM } = require('jsdom');

function setup() {
  const dom = new JSDOM('<body><section style="background:#faf9f7;color:#333"><div></div></section><button></button></body>');
  const { window } = dom, { document } = window, frames = new Map();
  let serial = 0, fits = 0, saves = 0, saved;
  const Terminal = vm.runInNewContext(fs.readFileSync(__dirname + '/terminal-panel.js', 'utf8') + ';EditingToolbarTerminal', {
    window, document, getComputedStyle: window.getComputedStyle.bind(window),
    requestAnimationFrame(fn) { frames.set(++serial, fn); return serial; },
    cancelAnimationFrame(id) { frames.delete(id); }
  });
  const t = Object.create(Terminal.prototype), writes = {}, options = new Proxy({
    fontFamily: 'Cascadia Mono, Consolas, Microsoft YaHei, monospace', fontSize: 12, cursorStyle: 'bar', minimumContrastRatio: 4.5,
    theme: { background: '#faf9f7', foreground: '#333333', cursor: '#333333' }
  }, { set(o,k,v) { writes[k] = (writes[k] || 0) + 1; o[k] = v; return true; } });
  const active = { term: { options } };
  Object.assign(t, { panel: document.querySelector('section'), appearanceMenu: document.querySelector('section>div'), appearanceButton: document.querySelector('button'),
    frame: { contentDocument: document }, menu: {}, context: {}, sessions: [active], active,
    appearance: { fontSize: 12, uiFontSize: 11.5, cursorStyle: 'bar' },
    fit() { fits++; }, persist() { saves++; saved = JSON.parse(JSON.stringify(this.appearance)); }
  });
  t.syncTheme(); for (const k of Object.keys(writes)) delete writes[k];
  t.appearanceMenu.hidden = true; t.showAppearance();
  const input = (label, value, kind = 'input') => { const el = document.querySelector('[aria-label="' + label + '"]'); el.value = value; el.dispatchEvent(new window.Event(kind)); return el; };
  const click = label => document.querySelector('[aria-label="' + label + '"]').click();
  const flush = () => { const pending = [...frames.values()]; frames.clear(); pending.forEach(fn => fn()); };
  return { t, window, document, input, click, flush, frames, writes, counts: () => ({ fits, saves }), saved: () => saved, close: () => dom.window.close() };
}

test('hex editor accepts 3/6 digits and optional hash; invalid or partial values never change the terminal', () => {
  const h = setup();
  for (const [value,expected] of [['abc','#aabbcc'],['#AbC','#aabbcc'],[' A1B2c3 ','#a1b2c3'],['#000000','#000000']]) assert.equal(h.t.colorHex(value), expected);
  for (const value of ['', '#12', '#12345', '#abcd', '#12gg34', 'red', '#12345678']) assert.equal(h.t.colorHex(value), null);
  h.input('背景颜色十六进制','#123'); assert.equal(h.t.appearance.background, undefined);
  h.input('背景颜色十六进制','#123','change'); h.flush(); assert.equal(h.t.appearance.background,'#112233');
  const el = h.input('背景颜色十六进制','oops','change');
  assert.equal(el.getAttribute('aria-invalid'),'true'); assert.equal(h.t.appearance.background,'#112233');
  el.dispatchEvent(new h.window.KeyboardEvent('keydown',{key:'Escape',bubbles:true}));
  assert.equal(el.value,'#112233'); assert.equal(el.hasAttribute('aria-invalid'),false);
  assert.equal(h.document.querySelector('input[type=color]'),null); h.close();
});

test('100 color edits coalesce to one theme update and persistence without measuring terminal dimensions', () => {
  const h = setup();
  for (let i=0;i<100;i++) h.input('背景颜色十六进制','#'+(0x203040+i*193).toString(16));
  assert.equal(h.frames.size,1); assert.deepEqual(h.counts(),{fits:0,saves:0});
  h.flush(); assert.deepEqual(h.counts(),{fits:0,saves:1});
  assert.equal(h.writes.theme,1); assert.equal(h.writes.fontSize,undefined); assert.equal(h.writes.fontFamily,undefined);
  assert.equal(h.saved().background,'#207ae3'); h.close();
});

test('font edits apply the last half-point value with one fit, while cursor changes never refit', () => {
  const h = setup();
  h.input('终端字号','13'); h.input('终端字号','13.5'); h.input('界面字号','12.5'); h.flush();
  assert.equal(h.t.active.term.options.fontSize,13.5); assert.equal(h.writes.fontSize,1);
  assert.deepEqual(h.counts(),{fits:1,saves:1});
  h.click('方块光标'); h.flush(); assert.equal(h.t.active.term.options.cursorStyle,'block');
  assert.deepEqual(h.counts(),{fits:1,saves:2}); assert.equal(h.writes.theme,undefined); h.close();
});

test('presets and swatches share the hex values; reset keeps the session and restores font settings', () => {
  const h = setup(), session = h.t.active;
  h.click('深色配色'); h.flush(); assert.equal(h.saved().background,'#242422');
  assert.equal(h.document.querySelector('#et-term-hex-background').value,'#242422');
  h.click('字体颜色色板'); assert.equal(h.document.querySelector('[aria-label="字体颜色常用颜色"]').hidden,false);
  h.click('字体颜色 #80A7DB'); h.flush(); assert.equal(h.saved().foreground,'#80a7db');
  h.input('终端字号','18'); h.flush();
  h.document.querySelector('#et-term-style-tab-type').click();
  h.document.querySelector('.et-term-style-reset').click();
  assert.equal(h.t.active,session); assert.equal(h.t.appearanceTab,'type');
  assert.equal(h.t.appearance.background,undefined); assert.equal(h.t.appearance.fontSize,12);
  assert.equal(h.document.querySelector('[aria-label="终端字号"]').value,'12');
  assert.equal(h.t.active.term.options.fontFamily,'Cascadia Mono, Consolas, Microsoft YaHei, monospace'); h.close();
});

test('repeated theme sync and external theme notifications do not rewrite options or save user preferences', () => {
  const h = setup();
  for (let i=0;i<20;i++) h.t.syncTheme(); assert.deepEqual(h.writes,{});
  for (let i=0;i<20;i++) h.t.queueAppearance(false,false); h.flush();
  assert.deepEqual(h.counts(),{fits:0,saves:0}); assert.deepEqual(h.writes,{}); h.close();
});
