// Account/Drive services outlive the optional AI panel and retain their original storage.
class EditingToolbarConnections {
 constructor(toolbar){this.toolbar=toolbar;}
 async init(){if(!this.store)this.store=new ETConnectionStore(reqnode,reqnode('path').join(File.option.userDataPath,'editing-toolbar','plugins'),{protect:(value,decrypt)=>ETLocalProtection(reqnode,value,decrypt)});return this.store;}
 node(tag,cls='',text){const n=document.createElement(tag);n.className=cls;if(text!=null)n.textContent=text;return n;}
 button(label,fn){const b=this.node('button','',label);b.type='button';b.onclick=()=>Promise.resolve().then(fn).catch(e=>this.toolbar._showToolbarNotice(e.message));return b;}
 form(label,cls=''){const d=this.node('dialog','et-skill-form et-plugin-form '+cls),head=this.node('div','et-plugin-form-head'),error=this.node('p','et-skills-status et-plugin-error');error.setAttribute('role','status');error.hidden=true;head.append(this.node('h3','',label),this.button('×',()=>d.close()));d.append(head);document.body.append(d);d.addEventListener('close',()=>d.remove(),{once:true});d.addEventListener('keydown',e=>e.stopPropagation());return {d,error};}
}
