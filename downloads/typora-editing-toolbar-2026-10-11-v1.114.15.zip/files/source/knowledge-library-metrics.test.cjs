'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),path=require('node:path');
const Metrics=require('./knowledge-library-metrics.cjs'),CNKI=require('./knowledge-library-cnki.cjs');
const connected={...Metrics.defaults,hasSemanticKey:true};
const BookMetrics=require('./knowledge-library-book-metrics.cjs'),ISBN=require('./knowledge-library-isbn.cjs');
function fixture(request){
 let now=1700000000000;const disk=new Map(),calls=[],waits=[],isbns=[];
 const store={root:'book-metrics-fixture',path,readOptional:async p=>disk.get(p)||null,locked:async f=>f(),atomic:async(p,v)=>disk.set(p,v)};
 const service=new Metrics(store,{now:()=>now,delay:async ms=>{waits.push(ms);now+=ms;},lookupISBN:async isbn=>{isbns.push(isbn);return {fields:{...book,isbn},source:'Test ISBN catalogue'};},settings:()=>({...Metrics.defaults,secretKey:'TEST_ONLY',semanticKey:'TEST_ONLY_SEMANTIC'}),request:async(u,o)=>{calls.push(u);return request(u,o,service);}});
 return {service,calls,waits,disk,isbns,advance:ms=>now+=ms,now:()=>now};
}
const book={id:'book',type:'book',title:'Example optics book',author:'Example Author',date:'2020',doi:'10.5555/example-book',isbn:'9780133507690'};
const s2Book={paperId:'a'.repeat(40),title:book.title,year:2020,authors:[{name:book.author}],publicationTypes:['Book'],citationCount:219,influentialCitationCount:8};
function isbnReply(url){
 if(url.includes('/search?')){const params=new URL(url).searchParams;assert.equal(params.get('query'),book.title);assert.equal(params.get('publicationTypes'),'Book');assert.equal(params.get('year'),'2020');return {total:1,data:[s2Book]};}
 if(url.includes('/'+s2Book.paperId+'/citations?'))return doiReply(url);
 throw Error('Books must not query DOI, Crossref or invented ISBN endpoints: '+url);
}
function doiReply(url){
 if(url.includes('api.crossref.org'))return {message:{DOI:book.doi,'is-referenced-by-count':40}};
 if(url.includes('/citations?'))return {data:[{citingPaper:{paperId:'a'},intents:['background']},{citingPaper:{paperId:'a'},intents:['background','methodology']},{citingPaper:{paperId:'b'},intents:['resultcomparison']}]};
 if(url.includes('api.semanticscholar.org'))return {externalIds:{DOI:book.doi},citationCount:219,influentialCitationCount:8};
 throw Error('Unexpected source '+url);
}
const viewRecord=(item,record)=>Metrics.view({...item,metrics:{citations:record.citations}},connected);
function cnkiDoc(row){
 const node=value=>({textContent:value});
 const tr={querySelector(sel){return ({'td.name a.fz14,td.name a':{...node(row.title),getAttribute:()=>row.url},'td.author':node(row.author),'td.date':node(row.date),'td.source':node('出版社'),'td.quote':node(row.cited),'td.download':node(row.downloads)})[sel]||null;}};
 return {title:'检索结果',body:node('检索结果'),querySelector:sel=>sel==='table.result-table-list'?{querySelectorAll:()=>[tr]}:null};
}
test('ISBN books reuse citation fields, cache, open rounds and pacing without querying their DOI',async()=>{
 const f=fixture(isbnReply),equivalent={...book,id:'isbn10',isbn:'ISBN-10: 0-13-350769-6'};
 const first=await f.service.readItems([book,equivalent],{force:true,round:'open-1'});
 assert.equal(first.records.length,2);assert.deepEqual(first.warnings,[]);assert.equal(f.calls.length,2);assert.deepEqual(f.isbns,[book.isbn]);
 assert.equal(first.records[0].citations.identity,'isbn:'+book.isbn);
 const view=viewRecord(book,first.records[0]);assert.equal(view.count,219);
 assert.deepEqual(Object.fromEntries(Object.entries(view.citationValues).map(([k,v])=>[k,v.value])),{'Total(DOI)':219,'Highly Influential':8,Background:1,Methods:1,Results:1});
 assert(f.waits.includes(5000),'Semantic Scholar pages retain service pacing');
 assert(view.citationBadges.every(b=>b.tip.includes('ISBN '+book.isbn)));
 await f.service.readItems([book],{force:true,round:'open-1'});assert.equal(f.calls.length,2,'same open event reuses round');
 await f.service.readItems([book]);assert.equal(f.calls.length,2,'fresh cache reused');
 await f.service.readItems([book],{force:true,round:'manual-2'});assert.equal(f.calls.length,4,'manual action starts a new round');
});
test('Chinese books use CNKI exact matching and display real zero independently from missing fields',async()=>{
 const item={id:'cnki-book',type:'book',title:'线性代数及其应用',author:'示例作者',date:'2020'},row={title:item.title,author:item.author,date:'2020',url:'https://kns.cnki.net/kcms/detail?filename=BOOK001',cited:'0',downloads:'12'};
 const f=fixture((u,o)=>{assert.equal(u,CNKI.endpoint);assert.equal(o.method,'POST');assert(new URLSearchParams(o.body).get('QueryJson').includes(item.title));return 'response';});f.service.parseHTML=()=>cnkiDoc(row);
 const result=await f.service.readItems([item]);assert.equal(result.warnings.length,1);assert.match(result.warnings[0],/有效 ISBN/);assert.equal(f.calls.length,1);
 const view=viewRecord(item,result.records[0]);assert.equal(view.count,0);assert.equal(view.citationValues['Download'].value,12);assert(!view.citationValues['Total(DOI)']);
 assert.equal(Metrics.view({...item,date:'2021',metrics:{citations:result.records[0].citations}},connected).citationBadges.length,0,'changed identity cannot use old book counts');
});
test('failed book updates keep old metrics and use the existing service cooldown',async()=>{
 let fail=false;const f=fixture((u,o,s)=>{if(fail&&u.includes('api.semanticscholar.org'))throw s.responseError('api.semanticscholar.org','Semantic Scholar',429,'30');return isbnReply(u);});
 const initial=await f.service.readItems([book],{force:true});fail=true;f.advance(1000);
 const failed=await f.service.readItems([book],{force:true});assert.equal(viewRecord(book,failed.records[0]).count,219);assert.equal(viewRecord(book,failed.records[0]).citationValues.Methods.value,1);assert(failed.warnings.some(x=>x.includes('429')));
 const deadline=f.service.serviceFailures.get('api.semanticscholar.org'),n=f.calls.filter(u=>u.includes('api.semanticscholar.org')).length;
 await f.service.readItems([book],{force:true});assert.equal(f.calls.filter(u=>u.includes('api.semanticscholar.org')).length,n);assert.equal(f.service.serviceFailures.get('api.semanticscholar.org'),deadline);
 assert.equal(viewRecord(book,initial.records[0]).count,219);
});
test('book journal values remain hidden while paper ranks and citation sorting are preserved',()=>{
 const stale={publication:{query:'',ranks:{sciif:'15',sci:'Q1'}}},b={...book,journalTag:'SCI Q1',citationCount:12,metrics:stale};
 const view=Metrics.view(b,connected);assert.deepEqual(view.badges,[]);assert.equal(view.impact,null);assert.equal(view.legacyJournal,'');assert.equal(view.count,12);
 const paper={...b,type:'paper',publicationTitle:'Journal',metrics:{publication:{query:'Journal',ranks:{sciif:'15',sci:'Q1'}}}};assert.equal(Metrics.view(paper,connected).impact,15);
 assert(Metrics.compareCitations({...book,citationCount:2},{...book,citationCount:20},connected)<0);
 assert.equal(Metrics.compareJournal(b,{...book,metrics:{publication:{query:'',ranks:{sciif:'99'}}}},Metrics.defaults),0);
});
test('unsupported or deleted items never query providers; unidentified books do not invent zero',async()=>{
 const f=fixture(()=>{throw Error('must not request');});const result=await f.service.readItems([{...book,deleted:true},{...book,type:'webpage'},{...book,type:'note'},{...book,isbn:'',url:''}]);assert.equal(f.calls.length,0);assert.equal(f.isbns.length,0);assert.equal(result.records.length,1);assert.equal(viewRecord({...book,isbn:''},result.records[0]).count,null);assert.match(result.warnings[0],/ISBN/);
});
test('ambiguous or wrong-year CNKI books and a mismatched DOI are rejected',async()=>{
 const item={type:'book',title:'概率论',author:'示例作者',date:'2020'},row={title:'概率论',author:'示例作者',date:'2019',url:'https://kns.cnki.net/kcms/detail?filename=B1',id:'B1',cited:11};
 assert.throws(()=>CNKI.match(item,[row]),/未找到/);assert.throws(()=>CNKI.match(item,[{...row,date:'2020'},{...row,id:'B2',date:'2020'}]),/多个同名/);
 const f=fixture(u=>u.includes('crossref')?{message:{DOI:'10.5555/other','is-referenced-by-count':999}}:{externalIds:{DOI:'10.5555/other'},citationCount:999});
 const paper={...book,type:'paper'};const result=await f.service.readItems([paper]);assert.equal(result.records[0].citations,undefined);assert.equal(result.warnings.length,2);assert.equal(viewRecord(paper,result.records[0]).count,null);
});
test('partial book citations preserve old individual fields without treating absent statistics as zero',()=>{
 const old={fields:{'Total(CNKI)':{value:11,source:'中国知网',updatedAt:100},Download:{value:23,source:'中国知网',updatedAt:100}}};
 const merged=Metrics.mergeRecord(old,{fields:{'Total(CNKI)':{value:12,source:'中国知网',updatedAt:200}},updatedAt:200});assert.equal(merged.fields['Total(CNKI)'].value,12);assert.equal(merged.fields.Download.value,23);assert.deepEqual(merged.retainedFields,['Download']);
});

test('papers keep DOI providers and share the DOI cache independently of ISBN books',async()=>{
 const f=fixture(doiReply),paper={...book,type:'paper'};
 const result=await f.service.readItems([paper,{...paper,id:'second'}],{force:true,round:'open'});
 assert.equal(f.calls.length,3);assert.equal(f.isbns.length,0);assert.equal(viewRecord(paper,result.records[0]).count,219);assert.deepEqual(result.warnings,[]);
});

test('ISBN catalogue must return the exact checksum-valid edition and usable metadata before S2 search',async()=>{
 assert.equal(BookMetrics.isbn('ISBN-10: 0-13-350769-6'),book.isbn);
 assert.equal(BookMetrics.isbn('9780133507695'),'');
 const f=fixture(()=>{throw Error('must not call S2');});
 f.service.lookupISBN=async()=>({fields:{...book,isbn:'9787111803416'}});
 const wrong=await f.service.readItems([book]);assert.equal(f.calls.length,0);assert.match(wrong.warnings[0],/书号不匹配/);
 const c={...book,isbn:book.isbn};
 for(const fields of [{...c,title:''},{...c,author:''},{...c,date:''}])assert.throws(()=>BookMetrics.catalogue({fields},book.isbn),/缺少/);
});

test('matching rejects wrong editions, authors, reviews, chapters, duplicates and incomplete searches',()=>{
 const meta=BookMetrics.catalogue({fields:book},book.isbn),pick=data=>BookMetrics.select(meta,{total:data.length,data});
 assert.equal(pick([{...s2Book,authors:[{name:'E. Author'}]}]).paperId,s2Book.paperId);
 assert.equal(pick([{...s2Book,authors:[{name:'Author, Example'}]}]).paperId,s2Book.paperId);
 for(const change of [{year:2019},{title:book.title+' Second Edition'},{authors:[{name:'Other Author'}]},{publicationTypes:['Review']},{publicationTypes:['BookSection']},{publicationTypes:['Book','BookSection']},{authors:[]},{paperId:'bad-id'}])assert.throws(()=>pick([{...s2Book,...change}]),/未找到/);
 assert.throws(()=>pick([s2Book,{...s2Book,paperId:'b'.repeat(40)}]),/多个/);
 assert.throws(()=>pick([s2Book,{...s2Book,citationCount:999}]),/冲突/);
 assert.throws(()=>BookMetrics.select(meta,{total:2,data:[s2Book],next:1}),/不完整/);
 assert.throws(()=>BookMetrics.select(meta,{total:2,data:[s2Book]}),/不完整/);
 assert.throws(()=>BookMetrics.select(meta,{data:[s2Book]}),/响应无效/);
});

test('ISBN change invalidates old citation identity while equivalent ISBN-10/13 preserves it',async()=>{
 const f=fixture(isbnReply),result=await f.service.readItems([book]);const stored={...book,metrics:{citations:result.records[0].citations}};
 assert.equal(Metrics.view({...stored,isbn:'0133507696'},connected).count,219);
 assert.equal(Metrics.view({...stored,isbn:'9787111803416'},connected).count,null);
 assert.equal(Metrics.view({...stored,isbn:''},connected).count,null);
 assert.equal(Metrics.view({...stored,doi:'10.5555/other'},connected).count,219,'DOI does not identify books');
 assert.equal(Metrics.view({...stored,metrics:{citations:{identity:'doi:'+book.doi,doi:book.doi,count:777}}},connected).count,null,'old DOI stats cannot masquerade as ISBN stats');
});

test('empty S2 result and explicit zero remain distinct; partial intent failures retain old fields',async()=>{
 const noResult=fixture(()=>({total:0,data:[]}));const missing=await noResult.service.readItems([book]);assert.equal(missing.records[0].citations,undefined);assert.match(missing.warnings[0],/未找到/);
 let partial=false;const f=fixture(url=>{
   if(url.includes('/search?'))return {total:1,data:[{...s2Book,citationCount:0,influentialCitationCount:0}]};
   if(partial)throw Error('fixture interrupted intents');return {data:[]};
 });
 const zero=await f.service.readItems([book]);assert.equal(viewRecord(book,zero.records[0]).count,0);assert.equal(viewRecord(book,zero.records[0]).citationValues.Methods.value,0);
 partial=true;const retry=await f.service.readItems([book],{force:true});assert.equal(viewRecord(book,retry.records[0]).citationValues.Methods.value,0);assert.match(retry.warnings[0],/interrupted/);
});

test('stopping during ISBN resolution prevents subsequent S2 requests',async()=>{
 const f=fixture(()=>{throw Error('must not call');});f.service.lookupISBN=async()=>{f.service.stopped=true;return {fields:book};};
 const result=await f.service.readItems([book]);assert.equal(f.calls.length,0);assert.match(result.warnings[0],/停止/);
});

test('API key reaches ISBN-based S2 search and citations, catalogue transport never receives it',async()=>{
 const f=fixture(()=>{throw Error('override removed');});delete f.service.requestOverride;
 const key='SYNTHETIC_ONLY_KEY',headers=[];f.service.settings=()=>({...Metrics.defaults,semanticKey:key});
 f.service.browserFetch=async(url,options)=>{headers.push(options.headers);return new Response(JSON.stringify(isbnReply(url)),{status:200});};
 const catalogueCalls=[];const isbnClient=new ISBN({interval:0,request:async(url,body)=>{
   catalogueCalls.push({url,body});const isbn=book.isbn;
   return JSON.stringify({['ISBN:'+isbn]:{title:book.title,authors:[{name:book.author}],publish_date:'2020',identifiers:{isbn_13:[isbn]}}});
 }});
 f.service.lookupISBN=value=>isbnClient.lookup(value);
 const result=await f.service.readItems([book]);assert.equal(viewRecord(book,result.records[0]).count,219);
 assert.equal(catalogueCalls.length,1);assert(!JSON.stringify(catalogueCalls).includes(key));assert.equal(headers.length,2);assert(headers.every(h=>h['x-api-key']===key));
});

test('changed S2 record never inherits statistics from the previously matched book',()=>{
 const old={book:{paperId:'a'.repeat(40)},fields:{'Total(DOI)':{value:20,source:'Semantic Scholar'},Methods:{value:8,source:'Semantic Scholar'},'Total(CNKI)':{value:11,source:'中国知网'}}};
 const merged=Metrics.mergeRecord(old,{book:{paperId:'b'.repeat(40)},fields:{'Total(DOI)':{value:4,source:'Semantic Scholar'}}});
 assert.equal(merged.fields['Total(DOI)'].value,4);assert.equal(merged.fields.Methods,undefined);assert.equal(merged.fields['Total(CNKI)'].value,11);
});

test('fresh or disconnected profiles hide imported and cached citations without destroying them',()=>{
 const item={...book,citationCount:253,metrics:{citations:{identity:'isbn:'+book.isbn,fields:{'Total(DOI)':{value:219,source:'Semantic Scholar'},'Total(CNKI)':{value:12,source:'中国知网'}}}}};
 const before=JSON.stringify(item);
 for(const settings of [{},{hasSemanticKey:false},{semanticKey:'  ',hasSemanticKey:true}]){
  for(const row of [item,{...book,citationCount:253}]){const view=Metrics.view(row,settings);assert.equal(view.count,null);assert.deepEqual(view.citationBadges,[]);assert.deepEqual(view.citationValues,{});assert.equal(view.citationTip,'');}
 }
 assert.equal(Metrics.view(item,connected).count,219);assert.equal(Metrics.view({...book,citationCount:253},connected).count,253);
 assert.equal(JSON.stringify(item),before);assert.equal(Metrics.compareCitations(item,{...book,citationCount:1},{}),0);
});

test('no citation key means no anonymous requests, ISBN lookups or cache use, even on manual refresh',async()=>{
 const f=fixture(()=>{throw Error('unexpected request');});f.service.settings=()=>({...Metrics.defaults});
 const rows=[book,{...book,type:'paper'},{...book,type:'thesis',title:'中文论文',author:'示例作者',url:'https://kns.cnki.net/kcms/detail?filename=TEST'}];
 await f.service.ready;f.service.cache['s2:isbn:'+book.isbn]={count:999,updatedAt:f.now()};
 const automatic=await f.service.readItems(rows),manual=await f.service.readItems(rows,{force:true});
 assert.deepEqual(automatic,{records:[],warnings:[]});assert.deepEqual(manual.records,[]);assert(manual.warnings.some(x=>x.includes('API Key')));assert.equal(f.calls.length,0);assert.equal(f.isbns.length,0);
});

test('easyScholar setup does not enable citation lookups',async()=>{
 const f=fixture(url=>{assert(url.startsWith('https://www.easyscholar.cc/'));return {data:{officialRank:{all:{sciif:'5'}}}};});
 f.service.settings=()=>({...Metrics.defaults,secretKey:'TEST_ONLY'});
 const result=await f.service.readItems([{...book,type:'paper',publicationTitle:'Test Journal'}]);
 assert.equal(f.calls.length,1);assert.equal(result.records[0].publication.ranks.sciif,'5');assert.equal(result.records[0].citations,undefined);
});

test('clearing the key while a request is queued prevents its network call',async()=>{
 const f=fixture(()=>{throw Error('unexpected request');});let key='TEST_ONLY_SEMANTIC';f.service.settings=()=>({semanticKey:key});
 f.service.delay=async()=>{key='';};
 await assert.rejects(f.service.request('https://api.crossref.org/works/10.5555/example'),/API Key/);assert.equal(f.calls.length,0);
});
