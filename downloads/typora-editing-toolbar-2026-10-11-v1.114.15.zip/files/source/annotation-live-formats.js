import {imageLayout,imageLayoutStyle,imageRotation} from './annotation-image-layout.js';
// Only our small, inert formatting vocabulary is read from HTML-like Markdown.
export const escapeAttr=value=>String(value||'').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
const decodeAttr=value=>value.replace(/&quot;/g,'"').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&');
export function cleanStyle(attrs={}){
 const color=value=>{const rgb=/^rgb\(\s*(\d{1,3}),\s*(\d{1,3}),\s*(\d{1,3})\s*\)$/.exec(value||'');if(rgb&&rgb.slice(1).every(n=>+n<=255))value='#'+rgb.slice(1).map(n=>(+n).toString(16).padStart(2,'0')).join('');if(/^#[\da-f]{6}$/i.test(value||''))return value.toUpperCase();const m=/^rgba\(\s*(\d{1,3}),\s*(\d{1,3}),\s*(\d{1,3}),\s*(0(?:\.\d+)?|1(?:\.0+)?)\s*\)$/.exec(value||'');return m&&m.slice(1,4).every(n=>+n<=255)?'rgba('+m.slice(1,4).map(Number).join(', ')+', '+Number(m[4])+')':null;};
 const size=Number(attrs.size);return {size:Number.isFinite(size)&&size>=.6&&size<=3&&size!==1?Math.round(size*100)/100:null,
 color:color(attrs.color),background:color(attrs.background)};
}
export const styleCSS=attrs=>{const a=cleanStyle(attrs);return (a.size?'font-size:'+a.size+'em;':'')+(a.color?'color:'+a.color+';':'')+(a.background?'background-color:'+a.background+';':'');};
function parseStyle(value){const attrs={};for(const item of value.split(';')){const [prop,val]=item.split(':').map(x=>x.trim());if(prop==='font-size'&&/^\d*\.?\d+em$/.test(val))attrs.size=parseFloat(val);if(prop==='color')attrs.color=val;if(prop==='background-color')attrs.background=val;}return cleanStyle(attrs);}
export const formatMarks={
 underline:{parseDOM:[{tag:'u'}],toDOM:()=>['u',0]},
 highlight:{parseDOM:[{tag:'mark'}],toDOM:()=>['mark',0]},
 superscript:{excludes:'subscript',parseDOM:[{tag:'sup'}],toDOM:()=>['sup',0]},
 subscript:{excludes:'superscript',parseDOM:[{tag:'sub'}],toDOM:()=>['sub',0]},
 text_style:{attrs:{size:{default:null},color:{default:null},background:{default:null}},parseDOM:[{tag:'span[style]',getAttrs:el=>parseStyle(el.getAttribute('style'))}],toDOM:m=>['span',{style:styleCSS(m.attrs)},0]}
};
const types={u:'underline',mark:'highlight',sup:'superscript',sub:'subscript',span:'text_style'};
export function installFormatRules(md){
 md.inline.ruler.before('escape','note_safe_formats',(state,silent)=>{
  const source=state.src.slice(state.pos);
  const img=/^<img src="(assets\/[a-f0-9]{32}\.png)" alt="([^"]*)"(?: width="(\d{1,5})")?(?: data-note-wrap="(inline|square|tight|through|top-bottom|front|behind)" data-note-side="(left|center|right)")?(?: data-note-rotation="(-?\d{1,4}(?:\.\d)?)")?(?: style="[^"]*")?\s*\/?>/.exec(source);
  if(img){const width=img[3]?+img[3]:null;if(width!==null&&(width<32||width>12000))return false;if(!silent){const t=state.push('note_image','img',0);t.meta={src:img[1],alt:decodeAttr(img[2]),title:null,width,...imageLayout({wrap:img[4],side:img[5]}),rotation:imageRotation(img[6])};}state.pos+=img[0].length;return true;}
  const open=/^<(u|mark|sup|sub)>/.exec(source)||/^<(span) style="([^"]*)">/.exec(source);if(!open)return false;
  const tag=open[1],re=new RegExp('<'+tag+'(?:\\s[^>]*)?>|</'+tag+'>','g');re.lastIndex=open[0].length;
  let depth=1,match,end=-1;while((match=re.exec(source))){if(match[0].startsWith('</'))depth--;else depth++;if(!depth){end=match.index;break;}}if(end<0)return false;
  if(!silent){const t=state.push('note_'+tag+'_open',tag,1);t.meta=tag==='span'?parseStyle(decodeAttr(open[2])):null;
   const nested=[];state.md.inline.parse(source.slice(open[0].length,end),state.md,state.env,nested);state.tokens.push(...nested);state.push('note_'+tag+'_close',tag,-1);}
  state.pos+=re.lastIndex;return true;
 });
}
export const formatTokens=Object.fromEntries(Object.entries(types).map(([tag,type])=>['note_'+tag,{mark:type,...(tag==='span'?{getAttrs:t=>t.meta}:{})}]));
formatTokens.note_image={node:'image',getAttrs:t=>t.meta};
export const formatMarkSerializers=Object.fromEntries(Object.entries(types).map(([tag,type])=>[type,{open:tag==='span'?(_s,m)=>'<span style="'+styleCSS(m.attrs)+'">':'<'+tag+'>',close:'</'+tag+'>',mixable:true,expelEnclosingWhitespace:true}]));
export function serializeNoteImage(s,n,fallback){
 const a=n.attrs,{wrap,side}=imageLayout(a),rotation=imageRotation(a.rotation);
 if(!/^assets\/[a-f0-9]{32}\.png$/.test(a.src)||(!a.width&&wrap==='inline'&&!rotation))return fallback(s,n);
 const style=imageLayoutStyle({...a,wrap,side})+(rotation?'transform:rotate('+rotation+'deg);transform-origin:center;':'');
 s.write('<img src="'+a.src+'" alt="'+escapeAttr(a.alt)+'"'+(a.width?' width="'+Math.round(a.width)+'"':'')+(wrap==='inline'?'':' data-note-wrap="'+wrap+'" data-note-side="'+side+'"')+(rotation?' data-note-rotation="'+rotation+'"':'')+(style?' style="'+style+'"':'')+'>');
}
