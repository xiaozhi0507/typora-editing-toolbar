'use strict';

// Parse delimiters before CommonMark's escape rule consumes \( and \[.
// Keeping this at token level leaves code spans, fences and link URLs alone.
function escaped(source, pos) {
    let slashes = 0;
    while (pos > 0 && source[--pos] === '\\') slashes++;
    return slashes % 2 === 1;
}

function closing(source, delimiter, from, limit = source.length) {
    for (let at = source.indexOf(delimiter, from); at >= 0 && at < limit; at = source.indexOf(delimiter, at + delimiter.length)) {
        if (escaped(source, at)) continue;
        if (delimiter === '$' && (source[at - 1] === '$' || source[at + 1] === '$')) continue;
        return at + delimiter.length <= limit ? at : -1;
    }
    return -1;
}

function installMathRules(markdown) {
    markdown.inline.ruler.before('escape', 'note_math', (state, silent) => {
        const pos = state.pos, source = state.src, pair = source.slice(pos, pos + 2);
        let open, close, display = false;
        if (pair === '\\(') { open = pair; close = '\\)'; }
        else if (pair === '\\[') { open = pair; close = '\\]'; display = true; }
        else if (pair === '$$') { open = close = pair; display = true; }
        else if (source[pos] === '$' && !/\s/.test(source[pos + 1] || '') && source[pos + 1]) open = close = '$';
        else return false;
        const end = closing(source, close, pos + open.length, state.posMax);
        if (end < 0) {
            // An unfinished streamed backslash formula must remain verbatim.
            // Dollars may be ordinary currency, so let CommonMark handle those.
            if (open[0] !== '\\') return false;
            if (!silent) state.pending += source.slice(pos, state.posMax);
            state.pos = state.posMax;
            return true;
        }
        const tex = source.slice(pos + open.length, end);
        if (open === '$' && (!tex || /\s$/.test(tex) || tex.includes('\n') || /\d/.test(source[end + 1] || ''))) return false;
        if (!silent) {
            const token = state.push('note_math', 'math', 0);
            token.content = tex.trim();
            token.meta = {display};
        }
        state.pos = end + close.length;
        return true;
    });

    markdown.block.ruler.before('fence', 'note_math_block', (state, start, end, silent) => {
        if (state.sCount[start] - state.blkIndent >= 4) return false;
        const first = state.src.slice(state.bMarks[start] + state.tShift[start], state.eMarks[start]);
        const open = first.slice(0, 2), close = open === '\\[' ? '\\]' : '$$';
        if (open !== '\\[' && open !== '$$') return false;
        const parts = [];
        for (let line = start; line < end; line++) {
            if (line > start && !state.isEmpty(line) && state.sCount[line] < state.blkIndent) break;
            const value = line === start ? first.slice(2) : state.getLines(line, line + 1, state.blkIndent, false);
            const at = closing(value, close, 0);
            if (at >= 0) {
                // Content after a closing delimiter belongs to the paragraph.
                if (value.slice(at + 2).trim()) return false;
                if (silent) return true;
                parts.push(value.slice(0, at));
                const token = state.push('note_math_block', 'math', 0);
                token.content = parts.join('\n').trim();
                token.map = [start, line + 1];
                state.line = line + 1;
                return true;
            }
            parts.push(value);
        }
        return false;
    }, {alt: ['paragraph', 'reference', 'blockquote', 'list']});
}

module.exports = {installMathRules};
