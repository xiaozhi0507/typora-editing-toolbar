// ============================================================================
// Typora Editing Toolbar
// 直接注入版：顶部全量工具栏 + 选区精简浮动工具栏
// ============================================================================

class EditingToolbarPlugin {
    constructor() {
        this.toolbar = null;
        this.topHost = null;
        this.topToolbar = null;
        this.linkDialog = null;
        this.linkDialogUrlInput = null;
        this.linkDialogTitleInput = null;
        this.linkDialogResolver = null;
        this.dialogSelectionRange = null;
        this.dialogSelectionText = "";
        this.activePopover = null;
        this.floatingToolbarEnabled = this._loadFloatingToolbarEnabled();
        this.lastPopoverInteractionAt = 0;
        this.hideTimeout = null;
        this.isVisible = false;
        this.savedRange = null;
        this.savedRangy = null;
        this.savedCursor = null;
        this.lastSelectionText = "";
        this.imageResizeHandle = null;
        this.activeImage = null;
        this.imageResizeState = null;
        this.config = {
            TOP_TOOLBAR_BUTTONS: [
                "undo", "redo", "common-menu", "heading-menu", "paragraph-menu", "math-menu", "insert-menu", "more-menu", "toolbar-settings"
            ],
            FLOATING_TOOLBAR_BUTTONS: [
                "undo", "redo", "common-menu", "heading-menu", "paragraph-menu", "math-menu", "insert-menu", "more-menu"
            ],
            FONT_COLOR_SECTIONS: [
                {
                    label: "Theme Colors",
                    shape: "square",
                    columns: 10,
                    theme: true,
                    colors: [
                        "#FFFFFF", "#000000", "#EEECE1", "#1F497D", "#4F81BD", "#C0504D", "#9BBB59", "#8064A2", "#4BACC6", "#F79646",
                        "#F2F2F2", "#7F7F7F", "#DDD9C3", "#C6D9F1", "#DBE5F1", "#F2DCDB", "#EBF1DD", "#E5E0EC", "#DBEEF3", "#FDE9D9",
                        "#D8D8D8", "#595959", "#C4BD97", "#8DB3E2", "#B8CCE4", "#E5B9B7", "#D7E3BC", "#CCC1D9", "#B7DDE8", "#FBD5B5",
                        "#BFBFBF", "#3F3F3F", "#938953", "#548DD4", "#95B3D7", "#D99694", "#C3D69B", "#B2A2C7", "#92CDDC", "#FAC08F",
                        "#A5A5A5", "#262626", "#494429", "#17365D", "#366092", "#953734", "#76923C", "#5F497A", "#31859B", "#E36C09",
                        "#7F7F7F", "#0C0C0C", "#1D1B10", "#0F243E", "#244061", "#632423", "#4F6128", "#3F3151", "#205867", "#974806"
                    ]
                },
                {
                    label: "Standard Colors",
                    shape: "square",
                    columns: 10,
                    colors: [
                        "#C00000", "#FF0000", "#FFC000", "#FFFF00", "#92D050",
                        "#00B050", "#00B0F0", "#0070C0", "#002060", "#7030A0"
                    ]
                }
            ],
            BG_COLOR_SECTIONS: [
                {
                    label: "Translucent Colors",
                    shape: "circle",
                    columns: 5,
                    colors: [
                        "rgba(218, 208, 216, 0.45)", "rgba(228, 220, 223, 0.45)", "rgba(238, 208, 201, 0.45)", "rgba(246, 214, 196, 0.45)", "rgba(250, 234, 187, 0.45)",
                        "rgba(190, 219, 218, 0.45)", "rgba(194, 222, 214, 0.45)", "rgba(188, 214, 238, 0.45)", "rgba(201, 203, 238, 0.45)", "rgba(224, 191, 236, 0.45)"
                    ]
                },
                {
                    label: "Highlighter Colors",
                    shape: "circle",
                    columns: 5,
                    colors: [
                        "#FFF176", "#D9F99D", "#86EFAC", "#99F6E4", "#F0ABFC",
                        "#C4B5FD", "#60A5FA", "#FF5C5C", "#E0B400", "#8D5BD9"
                    ]
                }
            ],
            EMOJI_SECTIONS: [
                {
                    label: "标记与状态",
                    columns: 5,
                    items: [
                        { emoji: "✅", label: "完成" }, { emoji: "❌", label: "错误" }, { emoji: "⭐", label: "重要" }, { emoji: "⚠️", label: "警告" }, { emoji: "❗", label: "强调" },
                        { emoji: "❓", label: "疑问" }, { emoji: "🔴", label: "紧急" }, { emoji: "🟡", label: "中等" }, { emoji: "🟢", label: "正常" }, { emoji: "🔵", label: "信息" },
                        { emoji: "📌", label: "置顶" }, { emoji: "🏷️", label: "标签" }, { emoji: "🚀", label: "上线" }, { emoji: "🚧", label: "进行中" }, { emoji: "💡", label: "灵感" },
                        { emoji: "🎯", label: "目标" }
                    ]
                },
                {
                    label: "分类与结构",
                    columns: 5,
                    items: [
                        { emoji: "📁", label: "文件夹" }, { emoji: "📂", label: "打开" }, { emoji: "📄", label: "文档" }, { emoji: "📝", label: "笔记" }, { emoji: "📖", label: "阅读" },
                        { emoji: "📚", label: "资料" }, { emoji: "🗂️", label: "归档" }, { emoji: "🗃️", label: "资料库" }, { emoji: "📊", label: "数据" }, { emoji: "📈", label: "上升" },
                        { emoji: "📉", label: "下降" }, { emoji: "🗓️", label: "日程" }
                    ]
                },
                {
                    label: "技术与开发",
                    columns: 5,
                    items: [
                        { emoji: "💻", label: "代码" }, { emoji: "🖥️", label: "桌面" }, { emoji: "📱", label: "移动" }, { emoji: "🌐", label: "Web" }, { emoji: "⚙️", label: "设置" },
                        { emoji: "🔧", label: "修复" }, { emoji: "🐛", label: "Bug" }, { emoji: "🔒", label: "安全" }, { emoji: "🔑", label: "密钥" }, { emoji: "🗄️", label: "数据库" },
                        { emoji: "📡", label: "接口" }, { emoji: "🧪", label: "测试" }, { emoji: "🔗", label: "链接" }, { emoji: "📦", label: "部署" }, { emoji: "🛠️", label: "工具" },
                        { emoji: "🤖", label: "AI" }
                    ]
                },
                {
                    label: "时间与协作",
                    columns: 5,
                    items: [
                        { emoji: "⏰", label: "提醒" }, { emoji: "⏳", label: "等待" }, { emoji: "📅", label: "计划" }, { emoji: "🕐", label: "时间" }, { emoji: "⏩", label: "加速" },
                        { emoji: "⏸️", label: "暂停" }, { emoji: "🔄", label: "刷新" }, { emoji: "⏪", label: "回顾" }, { emoji: "👤", label: "个人" }, { emoji: "👥", label: "团队" },
                        { emoji: "💬", label: "讨论" }, { emoji: "📧", label: "邮件" }, { emoji: "📞", label: "会议" }, { emoji: "🤝", label: "合作" }, { emoji: "📢", label: "公告" },
                        { emoji: "💭", label: "思考" }
                    ]
                },
                {
                    label: "学习与装饰",
                    columns: 5,
                    items: [
                        { emoji: "🧠", label: "知识" }, { emoji: "📐", label: "公式" }, { emoji: "🔍", label: "研究" }, { emoji: "📎", label: "附件" }, { emoji: "💎", label: "精华" },
                        { emoji: "🏆", label: "实践" }, { emoji: "📑", label: "总结" }, { emoji: "🔖", label: "书签" }, { emoji: "✏️", label: "编辑" }, { emoji: "🗑️", label: "删除" },
                        { emoji: "✍️", label: "写作" }, { emoji: "🎓", label: "课程" }, { emoji: "🎉", label: "庆祝" }, { emoji: "🔥", label: "热门" }, { emoji: "✨", label: "亮点" },
                        { emoji: "💪", label: "努力" }, { emoji: "👍", label: "赞同" }, { emoji: "👎", label: "反对" }, { emoji: "❤️", label: "喜欢" }, { emoji: "💥", label: "突破" },
                        { emoji: "🌟", label: "推荐" }, { emoji: "🎁", label: "彩蛋" }
                    ]
                }
            ],
            OFFSET_Y: 12
        };
    }

    init() {
        this.uiSettings = this._loadToolbarSettings();
        this._injectCSS();
        this._removeStaleNodes();
        this._createTopToolbar();
        this._createFloatingToolbar();
        this._createLinkDialog();
        this._createImageResizeHandle();
        this._bindToolbarKeyboard();
        this._bindAlertTitleGuard();
        this._bindAlignedParagraphEditing();
        this._bindEvents();
        this._updateToolbarState();
        this._updateFloatingToolbarToggleButtons();
    }

    _injectCSS() {
        if (document.getElementById("editing-toolbar-style")) return;
        const link = document.createElement("link");
        link.id = "editing-toolbar-style";
        link.rel = "stylesheet";
        link.href = this._getAssetDir() + "/editing-toolbar.css";
        document.head.appendChild(link);
    }

    _getAssetDir() {
        if (document.currentScript?.src?.includes("editing-toolbar")) {
            return document.currentScript.src.replace(/\/[^/]+$/, "");
        }
        const scripts = document.querySelectorAll("script[src]");
        for (const script of scripts) {
            if (script.src.includes("editing-toolbar")) {
                return script.src.replace(/\/[^/]+$/, "");
            }
        }
        return ".";
    }

    _toolbarControlIds() {
        return ["undo","redo","heading-menu","paragraph-menu","math-menu","common-menu","insert-menu","more-menu","toolbar-settings"];
    }

    _menuActionIds(id) {
        return (BUTTON_DEFINITIONS[id]?.actions || []).filter(action => action !== "|" && BUTTON_DEFINITIONS[action]);
    }

    _toolbarActionIds() {
        return [...new Set(this._toolbarControlIds().flatMap(id => this._menuActionIds(id).length ? this._menuActionIds(id) : [id]))];
    }

    _allowedToolbarMenuActions(id) {
        return id === "more-menu" ? this._toolbarActionIds().filter(action => action !== "toolbar-settings") : this._menuActionIds(id);
    }

    _flatToolbarButtons(ids) {
        const allowed = new Set(this._toolbarActionIds());
        return [...new Set((Array.isArray(ids) ? ids : []).flatMap(id => this._menuActionIds(id).length ? this._menuActionIds(id) : [id]).filter(id => allowed.has(id)))];
    }

    _groupToolbarButtons(ids) {
        const controls = new Set(this._toolbarControlIds()), owners = new Map();
        for (const id of controls) for (const action of this._menuActionIds(id)) owners.set(action, id);
        return [...new Set((Array.isArray(ids) ? ids : []).map(id => owners.get(id) || id).filter(id => controls.has(id)))];
    }

    _defaultToolbarSettings() {
        const order = this._toolbarControlIds();
        const compact = {order, menus:Object.fromEntries(order.filter(id => this._menuActionIds(id).length).map(id => [id,this._menuActionIds(id)]))};
        const classic = {buttons:this._flatToolbarButtons([
            "undo","redo","font-size-increase","font-size-decrease","bold","italic","strikethrough","underline","highlight","clear-format",
            "heading-menu","blockquote","ordered-list","unordered-list","task-list","align-left","align-center","align-right","align-justify","indent","outdent",
            "code","codeblock","inline-math","inline-math-ascii","math-block","warning-block","superscript","subscript","hr","table",
            "link","link-reference","footnote","image","video","emoji","font-color","bg-color","fullscreen","floating-toolbar-toggle","toolbar-settings"
        ])};
        return {version:1,layoutRevision:3,topLayout:"compact",layouts:{compact,classic},top:[...order],
            floating:["undo","redo","font-size-increase","font-size-decrease","bold","italic","strikethrough","underline","highlight","blockquote","warning-block","code","inline-math","inline-math-ascii","codeblock","math-block","superscript","subscript","clear-format","font-color","bg-color"],
            size:"normal",buttonSize:32,fontColors:[],bgColors:[],topMode:"docked",topCollapsed:false,topPosition:{x:24,y:100},responsive:true};
    }

    _normalizeToolbarSettings(input) {
        const defaults = this._defaultToolbarSettings();
        if (!input || input.version !== 1) return defaults;
        const controls = this._toolbarControlIds(), groups = controls.filter(id => this._menuActionIds(id).length);
        const unique = (ids, allowed) => [...new Set(ids.filter(id => allowed.includes(id)))];
        const compact = {order:[],menus:{}};
        let classic, floating, topLayout = "compact";
        if (input.layoutRevision === 3) {
            const source = input.layouts?.compact || defaults.layouts.compact;
            compact.order = Array.isArray(source.order) ? unique(source.order,controls) : [...controls];
            for (const id of groups) compact.menus[id] = Array.isArray(source.menus?.[id]) ? unique(source.menus[id],this._allowedToolbarMenuActions(id)) : this._menuActionIds(id);
            classic = {buttons:Array.isArray(input.layouts?.classic?.buttons) ? this._flatToolbarButtons(input.layouts.classic.buttons) : [...defaults.layouts.classic.buttons]};
            floating = Array.isArray(input.floating) ? this._flatToolbarButtons(input.floating) : [...defaults.floating];
            topLayout = input.topLayout === "classic" ? "classic" : "compact";
        } else {
            const previous = Array.isArray(input.top) ? input.top : controls;
            compact.order = this._groupToolbarButtons(previous);
            const flat = this._flatToolbarButtons(previous);
            for (const id of groups) compact.menus[id] = input.layoutRevision === 2
                ? (previous.includes(id) ? this._menuActionIds(id) : [])
                : (previous.includes(id) ? this._menuActionIds(id) : flat.filter(action => this._menuActionIds(id).includes(action)));
            if (input.layoutRevision !== 2) {
                // Old More also exposed hidden actions. Keep them accessible in
                // the compact profile; preserve explicit old buttons in Classic.
                for (const id of groups) if (!compact.menus[id].length) compact.menus[id] = this._menuActionIds(id);
            }
            classic = {buttons:input.layoutRevision !== 2 && Array.isArray(input.top) ? this._flatToolbarButtons(input.top) : [...defaults.layouts.classic.buttons]};
            floating = Array.isArray(input.floating) ? this._flatToolbarButtons(input.floating) : [...defaults.floating];
        }
        // Retain empty groups in the stored order so checking a child restores
        // its menu at the previous position, without introducing empty menus.
        for (const id of groups) if (!compact.order.includes(id)) compact.order.push(id);
        if (!compact.order.includes("toolbar-settings")) compact.order.push("toolbar-settings");
        if (!classic.buttons.includes("toolbar-settings")) classic.buttons.push("toolbar-settings");
        if (input.layoutRevision !== 3) {
            compact.order = compact.order.filter(id => id !== "math-menu" && id !== "more-menu" && id !== "toolbar-settings");
            compact.order.splice(compact.order.indexOf("paragraph-menu") + 1,0,"math-menu");
            compact.order.push("more-menu","toolbar-settings");
        }
        const relocated = new Set(compact.menus['more-menu'] || []);
        compact.order = compact.order.filter(id => !relocated.has(id));
        for(const id of groups)if(id!=='more-menu')compact.menus[id]=compact.menus[id].filter(action=>!relocated.has(action));
        const top = topLayout === "classic" ? [...classic.buttons] : compact.order.filter(id => !groups.includes(id) || compact.menus[id].length);
        const colors = key => Array.isArray(input[key]) ? [...new Set(input[key].filter(color => typeof color === "string" && /^#[0-9a-f]{6}$/i.test(color)).map(color => color.toUpperCase()))].slice(0,16) : [];
        return {version:1,layoutRevision:3,topLayout,layouts:{compact,classic},top,floating,
            size:["small","normal","large"].includes(input.size) ? input.size : "normal",
            buttonSize:this._toolbarButtonSize(input),fontColors:colors("fontColors"),bgColors:colors("bgColors"),
            topMode:input.topMode === "floating" ? "floating" : "docked",topCollapsed:false,responsive:true,
            topPosition:{x:Number.isFinite(input.topPosition?.x) ? Math.max(0,Math.min(100000,input.topPosition.x)) : 24,y:Number.isFinite(input.topPosition?.y) ? Math.max(0,Math.min(100000,input.topPosition.y)) : 100}};
    }

    _toolbarButtonSize(settings=this.uiSettings) {
        const value=settings?.buttonSize;
        return typeof value==="number"&&Number.isFinite(value) ? Math.max(24,Math.min(44,Math.round(value))) : ({small:28,normal:32,large:38}[settings?.size]||32);
    }

    _applyToolbarButtonSize(bar,top=false) {
        if(!bar)return;
        const configured=this._toolbarButtonSize(),size=top&&document.documentElement.clientWidth<900?Math.min(28,configured):configured;
        bar.style.setProperty("--et-button-size",size+"px");
        bar.style.setProperty("--et-icon-size",Math.round(size*.5)+"px");
        bar.style.setProperty("--et-label-size",Math.max(11,Math.round(size*.375))+"px");
    }

    _toolbarCategories() {
        return [
            {id:"text",label:"常用",controls:["common-menu"],buttons:this._menuActionIds("common-menu")},
            {id:"paragraph",label:"标题与段落",controls:["heading-menu","paragraph-menu"],buttons:[...this._menuActionIds("heading-menu"),...this._menuActionIds("paragraph-menu")]},
            {id:"math",label:"数学",controls:["math-menu"],buttons:this._menuActionIds("math-menu")},
            {id:"insert",label:"插入",controls:["insert-menu"],buttons:this._menuActionIds("insert-menu")},
            {id:"interface",label:"编辑与界面",controls:["undo","redo","more-menu","toolbar-settings"],buttons:["undo","redo",...this._menuActionIds("more-menu"),"toolbar-settings"]}
        ];
    }


    _loadToolbarSettings() {
        try { return this._normalizeToolbarSettings(JSON.parse(localStorage.getItem("editing-toolbar-layout-v1"))); }
        catch (_) { return this._defaultToolbarSettings(); }
    }

    _applyToolbarLayout() {
        this._closeActivePopover();
        this.hide();
        this.uiSettings = this._normalizeToolbarSettings(this.uiSettings);
        this._renderButtons(this.topToolbar, this.uiSettings.top, "top");
        this._renderButtons(this.toolbar, this.uiSettings.floating, "floating");
        [this.topToolbar, this.toolbar].forEach((bar) => this._applyToolbarButtonSize(bar,bar===this.topToolbar));
        this._applyTopPlacement();
        this._updateToolbarState();
    }

    _setupToolbarAccess(bar, location) {
        bar.setAttribute("role", "toolbar");
        bar.setAttribute("aria-label", location === "top" ? "笔记编辑工具栏" : "选区编辑工具栏");
        const buttons = Array.from(bar.querySelectorAll(".et-btn"));
        buttons.forEach((button, index) => { button.tabIndex = index === 0 ? 0 : -1; });
        this._applyToolbarButtonSize(bar,location === "top");
    }

    _createGroupControl(id, definition, location) {
        const wrapper = document.createElement("div");
        wrapper.className = "et-popover-anchor";
        const panel = document.createElement("div");
        panel.className = "et-menu-panel et-actions-panel";
        panel.hidden = true;
        const button = this._createButton(id, definition, location, () => {
            this._saveSelection();
            this._renderActionMenu(panel, definition.actions, location, definition.title);
            this._togglePopover(panel, location);
        });
        if (definition.label) { button.classList.add("et-btn-labeled"); button.insertAdjacentHTML("beforeend", `<span>${definition.label}</span><svg class="et-chevron" viewBox="0 0 16 16" aria-hidden="true" fill="none"><path d="m4.5 6.25 3.5 3.5 3.5-3.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>`); }
        wrapper.append(button, panel);
        this._preparePopover(panel);
        return wrapper;
    }

    _renderActionMenu(panel, actions, location, title, back = null) {
        panel.replaceChildren();
        panel.etGoBack = back;
        panel.etLocation = location;
        panel.setAttribute("role", "menu");
        panel.setAttribute("aria-label", title);
        if (back) {
            const button = document.createElement("button");
            button.type = "button"; button.className = "et-menu-item et-menu-back"; button.textContent = "‹ 返回";
            button.addEventListener("click", () => {back(); this._positionPopover(panel, location); this._focusFirstControl(panel);});
            panel.appendChild(button);
        }
        actions.forEach((id) => {
            if (id === "|") { const line = document.createElement("div"); line.className = "et-menu-divider"; panel.appendChild(line); return; }
            const def = BUTTON_DEFINITIONS[id];
            if (!def) return;
            const button = document.createElement("button");
            button.type = "button"; button.className = "et-menu-item et-action-item"; button.dataset.action = id;
            button.setAttribute("role", "menuitem"); button.tabIndex = -1;
            button.innerHTML = `${def.icon}<span>${this._escapeHtml(def.title)}</span>`;
            button.title = def.title; button.dataset.baseTitle = def.title;
            if (id === "floating-toolbar-toggle") this._updateFloatingToolbarToggleButton(button);
            const nested = def.actions || def.menuItems || def.colorPicker || def.emojiPicker;
            if (nested) { button.insertAdjacentHTML("beforeend", '<span class="et-menu-arrow">›</span>'); button.setAttribute("aria-haspopup", "true"); }
            button.addEventListener("mousedown", (event) => {this._saveSelection(); event.preventDefault();});
            button.addEventListener("click", (event) => {
                event.preventDefault(); event.stopPropagation();
                const goBack = () => this._renderActionMenu(panel, actions, location, title, back);
                if (def.actions) this._renderActionMenu(panel, def.actions, location, def.title, goBack);
                else if (nested) {
                    const content = def.colorPicker ? this._buildColorPicker(id) : def.emojiPicker ? this._buildEmojiPicker() : this._buildMenuPanel(def.menuItems);
                    this._renderActionMenu(panel, [], location, def.title, goBack);
                    panel.classList.add("et-actions-detail");
                    if(def.colorPicker)panel.dataset.colorKind=id;
                    while (content.firstChild) panel.appendChild(content.firstChild);
                } else { this._executeAction(id); return; }
                this._positionPopover(panel, location);
                if (event.detail === 0) this._focusFirstControl(panel);
            });
            panel.appendChild(button);
        });
        panel.classList.remove("et-actions-detail");
        delete panel.dataset.colorKind;
        this._updateToolbarState();
    }

    _focusFirstControl(container) {
        Array.from(container.querySelectorAll("button:not(:disabled),input,select"))
            .find((button) => button.getClientRects().length)?.focus({preventScroll:true});
    }

    _returnToEditor() {
        this._closeActivePopover(); this.hide();
        this._getEditor()?.writingArea?.focus({preventScroll:true});
        this._restoreSelection(this._getEditor());
    }

    _showToolbarNotice(message) {
        if (!this.keyboardNotice) {
            const notice = document.createElement("div");
            notice.className = "et-keyboard-notice";
            notice.setAttribute("role", "status");
            notice.setAttribute("aria-live", "polite");
            document.body.appendChild(notice);
            this.keyboardNotice = notice;
        }
        clearTimeout(this.keyboardNoticeTimer);
        this.keyboardNotice.textContent = message;
        this.keyboardNotice.hidden = false;
        this.keyboardNoticeTimer = setTimeout(() => { this.keyboardNotice.hidden = true; }, 4500);
    }

    _bindToolbarKeyboard() {
        // Arrow-key navigation stays local to toolbar controls; no global entry shortcuts.
        window.addEventListener("keydown", (event) => {
            if (event.ctrlKey || event.altKey || event.metaKey || event.key === "Escape") return;
            if (this.settingsDialog && !this.settingsDialog.hidden) return;
            if (!this._isInsideToolbar(event.target)) return;
            if (event.target.closest?.(".et-top-chrome")) return;
            event.stopImmediatePropagation();
            const panel = this.activePopover?.contains(event.target) ? this.activePopover : null;
            const bar = this.topToolbar.contains(event.target) ? this.topToolbar : this.toolbar;
            if (!panel && event.key === "ArrowDown" && event.target.getAttribute("aria-haspopup")) {
                event.preventDefault(); event.target.click(); if (this.activePopover) this._focusFirstControl(this.activePopover); return;
            }
            if (event.key === "Tab") {this._closeActivePopover(); return;}
            const keys = panel ? ["ArrowDown","ArrowUp","ArrowLeft","ArrowRight","Home","End"] : ["ArrowLeft","ArrowRight","Home","End"];
            if (!keys.includes(event.key)) return;
            event.preventDefault();
            const buttons = Array.from((panel || bar).querySelectorAll(panel ? "button:not(:disabled)" : ".et-btn:not(:disabled)"))
                .filter((button) => button.getClientRects().length && (panel || !button.closest(".et-menu-panel,.et-color-picker,.et-emoji-picker")));
            if (!buttons.length) return;
            let delta = event.key === "ArrowLeft" || event.key === "ArrowUp" ? -1 : 1;
            const grid = event.target.closest(".et-color-grid,.et-emoji-grid");
            if (grid && ["ArrowUp","ArrowDown"].includes(event.key)) delta *= getComputedStyle(grid).gridTemplateColumns.split(" ").length;
            let index = (buttons.indexOf(event.target) + delta + buttons.length) % buttons.length;
            if (event.key === "Home") index=0;
            if (event.key === "End") index=buttons.length-1;
            if (!panel) buttons.forEach((button,i)=>button.tabIndex=i===index?0:-1);
            buttons[index].focus({preventScroll:!panel});
        }, true);
        document.addEventListener("input", () => {clearTimeout(this.stateTimer);this.stateTimer=setTimeout(()=>this._updateToolbarState(),100);});
        window.addEventListener("storage", (event) => {
            if (event.key === "editing-toolbar-layout-v1" && (!this.settingsDialog || this.settingsDialog.hidden)) {
                this.uiSettings=this._loadToolbarSettings();this._applyToolbarLayout();
            }
        });
    }

    _updateToolbarState() {
        if (!this.topToolbar || !this.toolbar) return;
        const range = this._resolveRange(window.getSelection()) || this.savedRange;
        const valid = this._selectionInEditor(range);
        const blocked = !valid || (range?.commonAncestorContainer.nodeType === 1 ? range.commonAncestorContainer : range?.commonAncestorContainer.parentElement)?.closest(".md-fences,.md-math-block,.md-htmlblock") || this._getEditor()?.sourceView?.inSourceMode
            || window.File?.isLocked || window.File?.bundle?.isLocked;
        const selectors = {bold:"strong,b,[md-inline='strong']",italic:"em,i,[md-inline='em']",underline:"u,[md-inline='underline']",
            strikethrough:"s,del,[md-inline='del']",highlight:"mark,[md-inline='highlight']",code:"code,[md-inline='code']",
            "inline-math":"[md-inline='inline_math']",superscript:"sup,[md-inline='superscript']",subscript:"sub,[md-inline='subscript']"};
        const samples = [];
        if (valid && range.collapsed) samples.push(range.startContainer.nodeType===1 ? range.startContainer : range.startContainer.parentElement);
        else if (valid) {
            const root=range.commonAncestorContainer;
            const walker=document.createTreeWalker(root,4);
            const inspect=(node)=>{
                const element=node.parentElement;
                if (!node.textContent.trim() || element.closest(".md-meta,.md-content,mjx-container,script,.md-math-after-sym")) return;
                const r=document.createRange();r.selectNodeContents(node);
                if (range.compareBoundaryPoints(1,r)>0 && range.compareBoundaryPoints(3,r)<0) samples.push(element);
            };
            if(root.nodeType===3) inspect(root); else while(walker.nextNode()) inspect(walker.currentNode);
        }
        const blocks=valid?this._getAlignmentBlocks(range):[];
        const stateOf=(values)=>values.length ? values.every(Boolean) ? "true" : values.some(Boolean) ? "mixed" : "false" : "false";
        const states={};
        Object.entries(selectors).forEach(([id,selector])=>states[id]=stateOf(samples.map(e=>Boolean(e.closest(selector)))));
        ["left","center","right"].forEach(align=>states["align-"+align]=stateOf(blocks.map(e=>{
            const value=this._getBlockAlignment(e);return (value==="start"?"left":value==="end"?"right":value)===align;
        })));
        for(let level=1;level<=6;level++) states["h"+level]=stateOf(blocks.map(e=>e.tagName==="H"+level));
        ["ordered-list","unordered-list","task-list","blockquote"].forEach(id=>{
            const selector={"ordered-list":"ol","unordered-list":"ul:not(.task-list)","task-list":".task-list-item","blockquote":"blockquote"}[id];
            states[id]=stateOf(blocks.map(e=>Boolean(e.closest(selector))));
        });
        const formatIds = new Set([...Object.keys(states),"font-color","bg-color","font-size-increase","font-size-decrease","clear-format","indent","outdent"]);
        [this.topToolbar,this.toolbar].forEach(bar=>bar.querySelectorAll("button[data-action]").forEach(button=>{
            const id=button.dataset.action;
            if (id==="floating-toolbar-toggle") return;
            const base=button.dataset.baseTitle || BUTTON_DEFINITIONS[id]?.title || button.title;
            button.dataset.baseTitle=base;
            if(formatIds.has(id)) {button.disabled=Boolean(blocked);button.title=blocked?base+"（请在正文中选择内容）":base;}
            if(states[id]!==undefined) {
                const state=blocked?"false":states[id];
                if(button.getAttribute("role")?.startsWith("menuitem")) {button.setAttribute("role","menuitemcheckbox");button.setAttribute("aria-checked",state);button.removeAttribute("aria-pressed");}
                else button.setAttribute("aria-pressed",state);
                button.classList.toggle("et-btn-active",state==="true");button.classList.toggle("et-btn-mixed",state==="mixed");
                if(state==="mixed") button.title=base+"（混合格式）";
            }
            button.setAttribute("aria-label",button.title);
        }));
        [this.topToolbar,this.toolbar].forEach(bar=>{
            const buttons=Array.from(bar.querySelectorAll(".et-btn"));
            const current=buttons.find(button=>button.tabIndex===0 && !button.disabled);
            if(!current) {buttons.forEach(button=>button.tabIndex=-1);const first=buttons.find(button=>!button.disabled);if(first) first.tabIndex=0;}
        });
        for(const [id,property] of [["font-color","color"],["bg-color","backgroundColor"]]) {
            const colors=[...new Set(samples.map(e=>{
                if(property==="color") return getComputedStyle(e).color;
                for(let node=e;node && node.id!=="write";node=node.parentElement) {const color=getComputedStyle(node).backgroundColor;if(color!=="rgba(0, 0, 0, 0)" && color!=="transparent") return color;}
                return "transparent";
            }))];
            [this.topToolbar,this.toolbar].forEach(bar=>bar.querySelectorAll(`button[data-action="${id}"]`).forEach(button=>{
                button.classList.toggle("et-color-mixed",colors.length>1);
                button.style.setProperty("--et-current-color",colors.length===1?colors[0]:"transparent");
                if(colors.length>1) {button.title=BUTTON_DEFINITIONS[id].title+"（混合颜色）";button.setAttribute("aria-label",button.title);}
            }));
        }
    }



    _openToolbarSettings() {
        if (this.settingsDialog) {this._focusFirstControl(this.settingsDialog);return;}
        this._saveSelection();this._closeActivePopover();this.hide();
        let draft = this._normalizeToolbarSettings(this.uiSettings);
        const views = {top:"enabled",floating:"enabled"}, categories = this._toolbarCategories();
        const expanded = new Set(), displayOrders = {top:new Map(),floating:new Map()};
        const backdrop = document.createElement("div");backdrop.className = "et-settings-backdrop";
        const dialog = document.createElement("div");dialog.className = "et-settings-dialog";
        dialog.setAttribute("role","dialog");dialog.setAttribute("aria-modal","true");dialog.setAttribute("aria-labelledby","et-settings-title");
        backdrop.appendChild(dialog);this.settingsDialog = backdrop;
        let disposeMovement;
        const close = () => {disposeMovement?.();backdrop.remove();this.settingsDialog=null;this._returnToEditor();};
        const save = () => {
            const error = dialog.querySelector(".et-settings-error");
            const settings=this._normalizeToolbarSettings(draft);
            try {localStorage.setItem("editing-toolbar-layout-v1",JSON.stringify(settings));}
            catch (_) {error.textContent="设置未能保存，请检查 Typora 用户配置目录是否可写。";return;}
            this.uiSettings=settings;this._applyToolbarLayout();close();
        };
        const grouped = key => key==="top" && draft.topLayout==="compact";
        const getOrder = (key,scope="flat") => key==="floating" ? draft.floating : scope==="root" ? draft.layouts.compact.order
            : scope.startsWith("menu:") ? draft.layouts.compact.menus[scope.slice(5)] : draft.layouts.classic.buttons;
        const setOrder = (key,scope,order) => {
            if(key==="floating") draft.floating=order;
            else if(scope==="root") draft.layouts.compact.order=order;
            else if(scope.startsWith("menu:")) draft.layouts.compact.menus[scope.slice(5)]=order;
            else draft.layouts.classic.buttons=order;
        };
        // Keep the settings rows stable while checkboxes change the saved selection.
        const rowOrder = (key,scope,ids) => {
            const known=displayOrders[key].get(scope)||[],next=[...new Set([...known,...ids])];
            displayOrders[key].set(scope,next);return next;
        };
        const renderList = (key,focusId,focusPart="handle") => {
            const section=dialog.querySelector(`[data-section="${key}"]`),list=section.querySelector(".et-settings-list");
            const scroll=list.scrollTop;list.replaceChildren();
            const isGrouped=grouped(key),enabledView=views[key]==="enabled";
            const category=categories.find(item=>item.id===views[key]);
            const count=isGrouped ? draft.layouts.compact.order.reduce((sum,id)=>sum+(this._menuActionIds(id).length?draft.layouts.compact.menus[id].length:1),0) : getOrder(key).length;
            section.querySelector("h3").textContent=key==="floating"?"小窗工具栏":`顶部工具栏（${isGrouped?"精简":"经典"}）`;
            section.querySelector(".et-settings-count").textContent=`已启用 ${count} 项`;
            let dragging=null;
            const appendRow=(id,scope,{group=false,child=false}={})=>{
                const order=getOrder(key,scope),all=group?[...new Set([...this._menuActionIds(id),...(draft.layouts.compact.menus[id]||[])])]:[];
                const selected=group?draft.layouts.compact.menus[id]:null;
                const checked=group?selected.length>0:order.includes(id),locked=key==="top"&&id==="toolbar-settings";
                const title=BUTTON_DEFINITIONS[id].title;
                const row=document.createElement("div");row.className="et-settings-row"+(group?" et-settings-group":"")+(child?" et-settings-child":"");row.dataset.row=id;row.dataset.scope=scope;
                const visibleOrder=()=>getOrder(key,scope);
                const sortable=(checked||group)&&(enabledView || isGrouped&&scope.startsWith("menu:"))||isGrouped&&id==='more-menu';
                const shift=(delta,part)=>{
                    const visible=visibleOrder(),index=visible.indexOf(id),other=visible[index+delta];if(!other)return;
                    const next=[...getOrder(key,scope)],a=next.indexOf(id),b=next.indexOf(other);[next[a],next[b]]=[next[b],next[a]];
                    const rows=rowOrder(key,scope,next),x=rows.indexOf(id),y=rows.indexOf(other);[rows[x],rows[y]]=[rows[y],rows[x]];
                    setOrder(key,scope,next);renderList(key,id,part);
                };
                const destination=()=>{
                    if(!dragging||dragging.id===id||dragging.id==='toolbar-settings')return null;
                    if(isGrouped&&group&&this._allowedToolbarMenuActions(id).includes(dragging.id))return 'menu:'+id;
                    if(dragging.scope===scope)return scope;
                    if(isGrouped&&scope==='menu:more-menu'&&this._allowedToolbarMenuActions('more-menu').includes(dragging.id))return scope;
                    if(isGrouped&&scope==='root'&&dragging.scope==='menu:more-menu'&&this._toolbarControlIds().includes(dragging.id))return 'root';
                    return null;
                };
                if(sortable||enabledView){
                    const handle=document.createElement("button");handle.type="button";handle.className="et-drag-handle";handle.textContent="⠿";handle.title="拖动排序，或聚焦后按上下键";handle.setAttribute("aria-label","排序"+title);handle.draggable=true;
                    handle.disabled=!sortable;handle.draggable=sortable;
                    handle.addEventListener("keydown",event=>{if(event.key==="ArrowUp"||event.key==="ArrowDown"){event.preventDefault();event.stopPropagation();shift(event.key==="ArrowUp"?-1:1,"handle");}});
                    handle.addEventListener("dragstart",event=>{event.stopPropagation();dragging={id,scope};event.dataTransfer.setData("text/plain",id);event.dataTransfer.effectAllowed="move";row.classList.add("et-dragging");});
                    handle.addEventListener("dragend",()=>{dragging=null;row.classList.remove("et-dragging");list.querySelectorAll(".et-drop-before,.et-drop-after,.et-drop-inside").forEach(el=>el.classList.remove("et-drop-before","et-drop-after","et-drop-inside"));});
                    row.addEventListener("dragover",event=>{
                        const target=destination();if(!target)return;
                        event.preventDefault();event.stopPropagation();event.dataTransfer.dropEffect="move";
                        list.querySelectorAll(".et-drop-before,.et-drop-after,.et-drop-inside").forEach(el=>el.classList.remove("et-drop-before","et-drop-after","et-drop-inside"));
                        row.classList.add(target==='menu:'+id?'et-drop-inside':event.clientY>row.getBoundingClientRect().top+row.offsetHeight/2?"et-drop-after":"et-drop-before");
                        const bounds=list.getBoundingClientRect();if(event.clientY<bounds.top+8)list.scrollTop-=12;if(event.clientY>bounds.bottom-8)list.scrollTop+=12;
                    });
                    row.addEventListener("drop",event=>{
                        event.preventDefault();event.stopPropagation();const target=destination();if(!target)return;
                        const moved=dragging.id;setOrder(key,dragging.scope,getOrder(key,dragging.scope).filter(item=>item!==moved));
                        displayOrders[key].set(dragging.scope,rowOrder(key,dragging.scope,[]).filter(item=>item!==moved));
                        const next=getOrder(key,target).filter(item=>item!==moved),after=event.clientY>row.getBoundingClientRect().top+row.offsetHeight/2;
                        if(target==='menu:'+id){next.push(moved);expanded.add(id);}else next.splice(Math.max(0,next.indexOf(id)+(after?1:0)),0,moved);
                        const rows=rowOrder(key,target,getOrder(key,target)).filter(item=>item!==moved);
                        if(target==='menu:'+id)rows.push(moved);else rows.splice(Math.max(0,rows.indexOf(id)+(after?1:0)),0,moved);
                        displayOrders[key].set(target,rows);
                        setOrder(key,target,rows.filter(item=>next.includes(item)));dragging=null;renderList(key,moved);
                    });
                    row.appendChild(handle);
                }
                let expand;
                if(group){
                    expand=document.createElement("button");expand.type="button";expand.className="et-settings-expand";expand.innerHTML='<svg viewBox="0 0 16 16" aria-hidden="true"><path d="m6 3 5 5-5 5"/></svg>';expand.setAttribute("aria-expanded",String(expanded.has(id)));expand.setAttribute("aria-label",(expanded.has(id)?"收起":"展开")+title);
                    expand.addEventListener("click",()=>{if(expanded.has(id))expanded.delete(id);else expanded.add(id);renderList(key,id,"expand");});
                }
                const label=document.createElement("label"),input=document.createElement("input");input.type="checkbox";input.checked=checked;input.disabled=locked;input.indeterminate=group&&selected.length>0&&selected.length<all.length;
                label.append(input,document.createTextNode(title+(locked?"（保留入口）":"")));row.appendChild(label);
                if(expand)row.appendChild(expand);
                input.addEventListener("change",()=>{
                    if(group){const children=rowOrder(key,'menu:'+id,[...selected,...all]);draft.layouts.compact.menus[id]=input.checked?[...children]:[];}
                    else {const selectedIds=new Set(getOrder(key,scope));if(input.checked)selectedIds.add(id);else selectedIds.delete(id);setOrder(key,scope,rowOrder(key,scope,[...order,id]).filter(item=>selectedIds.has(item)));}
                    renderList(key,id,"input");
                });
                if(group){const count=document.createElement("span");count.className="et-settings-group-count";count.textContent=`${selected.length}/${all.length}`;row.appendChild(count);}
                list.appendChild(row);
                if(group&&expanded.has(id)){
                    const children=rowOrder(key,'menu:'+id,[...selected,...all.filter(action=>!selected.includes(action))]);
                    for(const action of children)appendRow(action,"menu:"+id,{child:true});
                }
            };
            if(isGrouped){
                const ids=enabledView?rowOrder(key,'root',draft.layouts.compact.order):this._toolbarControlIds().filter(id=>!category||category.controls.includes(id));
                ids.forEach(id=>appendRow(id,"root",{group:this._menuActionIds(id).length>0}));
            }else{
                const ids=enabledView?rowOrder(key,'flat',getOrder(key)):this._toolbarActionIds().filter(id=>!category||category.buttons.includes(id));
                ids.forEach(id=>appendRow(id,"flat"));
            }
            if(!list.childElementCount){const empty=document.createElement("p");empty.className="et-settings-empty";empty.textContent="暂无已启用功能，请切换分类勾选。";list.appendChild(empty);}
            list.scrollTop=scroll;
            if(focusId){
                const row=list.querySelector(`[data-row="${focusId}"]`),selector=focusPart==="input"?"input:not(:disabled)":focusPart==="expand"?".et-settings-expand":".et-drag-handle";
                const target=row?.querySelector(selector);target?.focus({preventScroll:true});row?.scrollIntoView({block:"nearest"});
            }
        };
        dialog.innerHTML=`<header class="et-preferences-header" data-preferences-move><span class="et-preferences-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M4 7h16M4 17h16"/><rect x="7" y="4" width="4" height="6" rx="1"/><rect x="14" y="14" width="4" height="6" rx="1"/></svg></span><div><h2 id="et-settings-title">工具栏设置</h2></div><button type="button" class="et-preferences-close" data-close aria-label="取消并关闭工具栏设置">×</button></header><div class="et-settings-body">
            <div class="et-settings-presets"><button type="button" data-preset="compact">精简布局</button><button type="button" data-preset="classic">经典布局</button>
            <label class="et-settings-size">按钮大小 <span class="et-size-track"><input type="range" min="24" max="44" step="1" aria-label="按钮大小"></span><output data-button-size></output></label></div>
            <div class="et-settings-columns"></div>
            </div><div class="et-settings-footer"><p class="et-settings-error" role="alert"></p><button type="button" data-close>取消</button><button type="button" data-save>保存设置</button></div>`;
        const updateMode=()=>dialog.querySelectorAll("[data-preset]").forEach(button=>button.setAttribute("aria-pressed",String(button.dataset.preset===draft.topLayout)));
        dialog.querySelectorAll("[data-preset]").forEach(button=>button.addEventListener("click",()=>{draft.topLayout=button.dataset.preset;updateMode();renderList("top");}));updateMode();
        const sizeSlider=dialog.querySelector('[aria-label="按钮大小"]'),sizeOutput=dialog.querySelector('[data-button-size]');
        const updateSize=()=>{draft.buttonSize=Number(sizeSlider.value);sizeOutput.value=String(draft.buttonSize);sizeSlider.setAttribute("aria-valuetext",draft.buttonSize+" 像素");};
        sizeSlider.value=this._toolbarButtonSize(draft);updateSize();
        sizeSlider.addEventListener("input",updateSize);
        for(const key of ["top","floating"]){
            const section=document.createElement("section");section.dataset.section=key;
            section.innerHTML=`<div class="et-settings-section-title"><h3></h3><span class="et-settings-count"></span></div>
                <select data-category="${key}" aria-label="${key==="top"?"顶部":"小窗"}工具栏分类"><option value="enabled">集中排序</option><option value="all">全部功能</option>${categories.map(category=>`<option value="${category.id}">${category.label}</option>`).join("")}</select>
                <div class="et-settings-list" data-list="${key}"></div>`;
            section.querySelector("select").addEventListener("change",event=>{views[key]=event.target.value;renderList(key);});dialog.querySelector(".et-settings-columns").appendChild(section);renderList(key);
        }
        dialog.querySelectorAll("[data-close]").forEach(button=>button.addEventListener("click",close));dialog.querySelector("[data-save]").addEventListener("click",save);
        ["mousedown","click"].forEach(type=>dialog.addEventListener(type,event=>event.stopPropagation()));
        backdrop.addEventListener("mousedown",event=>{event.stopPropagation();if(event.target===backdrop)save();});
        backdrop.addEventListener("keydown",event=>{
            event.stopPropagation();if(event.key==="Escape"){event.preventDefault();close();return;}if(event.key==="Tab"){
                const controls=Array.from(dialog.querySelectorAll("button:not(:disabled),input:not(:disabled),select")),first=controls[0],last=controls[controls.length-1];
                if(event.shiftKey&&event.target===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&event.target===last){event.preventDefault();first.focus();}
            }
        });
        document.body.appendChild(backdrop);disposeMovement=attachMovablePreferences(dialog);dialog.querySelector('[data-preset][aria-pressed="true"]').focus();
    }


    _persistTopPlacement() {
        try {localStorage.setItem("editing-toolbar-layout-v1", JSON.stringify(this.uiSettings));}
        catch (_) {this._showToolbarNotice("工具栏位置暂未保存，下次打开将使用原位置。");}
    }

    _createTopChrome() {
        const chrome = document.createElement("div"); chrome.className = "et-top-chrome";
        const control = (id, text, title, action) => {
            const button = document.createElement("button"); button.type = "button"; button.dataset.topControl = id;
            button.textContent = text; button.title = title; button.setAttribute("aria-label",title);
            button.addEventListener("mousedown", event => {this._saveSelection(); event.preventDefault(); event.stopPropagation();});
            button.addEventListener("click", event => {event.stopPropagation(); action?.();});
            chrome.appendChild(button); return button;
        };
        const handle = control("drag","⠿","拖动顶部工具栏");
        control("collapse","−","收起顶部工具栏", () => {
            this.uiSettings.topCollapsed = !this.uiSettings.topCollapsed; this._closeActivePopover(); this._applyTopPlacement(); this._persistTopPlacement();
        });
        control("dock","↥","停靠到顶部", () => {
            this.uiSettings.topMode = this.uiSettings.topMode === "floating" ? "docked" : "floating";
            this._closeActivePopover(); this._applyTopPlacement(); this._persistTopPlacement();
        });
        control("settings","⚙","工具栏设置", () => this._openToolbarSettings());
        this.topHost.prepend(chrome); this.topChrome = chrome;
        handle.addEventListener("pointerdown", event => {
            if (event.button !== 0) return;
            event.preventDefault(); event.stopPropagation(); this._saveSelection();
            const start = this.topHost.getBoundingClientRect(), x = event.clientX, y = event.clientY;
            let moved = false;
            const move = event => {
                if (!moved && Math.hypot(event.clientX-x,event.clientY-y) < 4) return;
                if (!moved) {moved = true; this.uiSettings.topMode = "floating"; this._closeActivePopover(); this.hide();}
                this.uiSettings.topPosition = {x:start.left+event.clientX-x,y:start.top+event.clientY-y};
                this._applyTopPlacement();
            };
            const finish = () => {
                window.removeEventListener("pointermove",move,true); window.removeEventListener("pointerup",finish,true); window.removeEventListener("blur",finish);
                if (moved) this._persistTopPlacement();
            };
            window.addEventListener("pointermove",move,true); window.addEventListener("pointerup",finish,true); window.addEventListener("blur",finish);
        });
        window.addEventListener("resize", () => this._applyTopPlacement());
        this._applyTopPlacement();
    }

    _applyTopPlacement() {
        if (!this.topHost || !this.topChrome) return;
        const floating = this.uiSettings.topMode === "floating", collapsed = this.uiSettings.topCollapsed;
        this.topHost.dataset.placement = floating ? "floating" : "docked";
        this.topHost.dataset.collapsed = String(Boolean(collapsed));
        this._applyToolbarButtonSize(this.topToolbar,true);
        const toggle = this.topChrome.querySelector('[data-top-control="collapse"]');
        toggle.textContent = collapsed ? "工具栏 ＋" : "−";
        toggle.title = collapsed ? "展开顶部工具栏" : "收起顶部工具栏";
        toggle.setAttribute("aria-label", toggle.title); toggle.setAttribute("aria-expanded", String(!collapsed));
        const dock = this.topChrome.querySelector('[data-top-control="dock"]');
        dock.textContent = floating ? "↥" : "⤢"; dock.title = floating ? "停靠到顶部" : "浮动顶部工具栏"; dock.setAttribute("aria-label",dock.title);
        if (floating) {
            const bounds = this.topHost.getBoundingClientRect(), position = this.uiSettings.topPosition;
            const x = Math.max(8,Math.min(position.x,document.documentElement.clientWidth-bounds.width-8));
            const y = Math.max(8,Math.min(position.y,document.documentElement.clientHeight-bounds.height-8));
            this.topHost.style.left = x + "px"; this.topHost.style.top = y + "px";
            // Retain the requested position across temporary viewport shrinking.
        } else {this.topHost.style.left = ""; this.topHost.style.top = "";}
    }

    _alertHeaderFor(node) {
        const element = node?.nodeType === 1 ? node : node?.parentElement;
        const paragraph = element?.closest('p[cid]');
        return paragraph?.parentElement?.classList.contains("md-alert") && paragraph === paragraph.parentElement.firstElementChild && paragraph.querySelector('.md-alert-text') ? paragraph : null;
    }

    _focusAlertBody(header) {
        const editor = this._getEditor();
        if (!editor || window.File?.isLocked || this.readingMode?.protected || editor.sourceView?.inSourceMode) return false;
        let body = header.nextElementSibling;
        if (!body) {
            // A file may contain only the marker. Add an editable body with native undo.
            const quote = editor.getNode(header.parentElement.getAttribute("cid")), Model = quote?.constructor;
            if (!quote || !editor.undo?.buildReplaceUndo) return false;
            editor.undo.endSnap(true); editor.store();
            const before = editor.undo.buildReplaceUndo(quote), child = new Model({type:"paragraph",text:""});
            quote.appendChild(child); editor.findElemById(quote.cid).replaceWith(quote.toHTML());
            editor.undo.register({undo:[before],redo:[editor.undo.buildReplaceUndo(quote)]});
            editor.quickRefresh(); body = editor.findElemById(child.cid)[0];
        }
        const target = body?.matches('p,h1,h2,h3,h4,h5,h6,pre') ? body : body?.querySelector('p,h1,h2,h3,h4,h5,h6,pre') || body;
        if (!target) return false;
        const cid = target.getAttribute("cid");
        // Moving only the DOM range leaves Typora.focusCid on the marker and can
        // lose body input on save. Move through its selection API, then refocus.
        editor.selection.jumpIntoElemBegin(editor.findElemById(cid));
        editor.refocus(cid);
        this._saveSelection();
        return true;
    }

    _removeEmptyAlert(range) {
        const editor = this._getEditor();
        if (!editor || this.readingMode?.protected || window.File?.isLocked || window.File?.inBusyMode || editor.isIME || editor.sourceView?.inSourceMode) return false;
        const element = range.startContainer.nodeType === 1 ? range.startContainer : range.startContainer.parentElement;
        const alert = element?.closest('.md-alert[cid]'), header = alert?.firstElementChild;
        if (!header || this._alertHeaderFor(header) !== header) return false;
        const blank = text => !String(text || '').replace(/[\s\u200b\ufeff]/g, '');
        // Check every body block, including off-screen siblings. Media, lists,
        // tables and other structure must never be treated as an empty alert.
        if (![...alert.children].slice(1).every(p => p.tagName === 'P' && blank(p.textContent) && [...p.querySelectorAll('*')].every(n => ['BR','SPAN'].includes(n.tagName)))) return false;
        if (!editor.undo?.buildReplaceUndo || !editor.undo?.exeCommand) return false;
        editor.undo.endSnap(true); editor.store();
        const node = editor.getNode(alert.getAttribute('cid')), json = node?.storeToJson();
        const children = json?.children;
        if (json?.content?.type !== 'blockquote' || !json.content.alert || !children?.length) return false;
        if (children.some(p => p.content.type !== 'paragraph' || p.children?.length)) return false;
        if (!/^\s*\[!(NOTE|TIP|IMPORTANT|WARNING|CAUTION)\]\s*$/i.test(children[0].content.text || '') || !children.slice(1).every(p => blank(p.content.text))) return false;
        const cursor = editor.selection.buildUndo(), before = editor.undo.buildReplaceUndo(node);
        const after = {type:'replace',id:node.cid,json:{...json,content:{type:'paragraph',text:''},children:[]}};
        const command = {undo:cursor ? [cursor,before] : [before],redo:[after]};
        editor.brush.pause(true);
        try {
            editor.undo.exeCommand(after);
            editor.selection.jumpIntoElemBegin(editor.findElemById(node.cid));
            editor.refocus(node.cid);
            const nextCursor = editor.selection.buildUndo(); if (nextCursor) command.redo.push(nextCursor);
            editor.undo.register(command);
        } catch (error) {
            editor.undo.exeCommand(before); if (cursor) editor.undo.exeCommand(cursor);
            console.warn('[EditingToolbar] Empty alert removal rolled back:', error);
            return false;
        } finally {editor.brush.resume();}
        editor.quickRefresh(); this._saveSelection();
        return true;
    }

    _bindAlertTitleGuard() {
        if (this.alertTitleGuardBound) return; this.alertTitleGuardBound = true;
        // Typora also schedules a refocus from mouseup/click. Intercept the full
        // header click sequence so a delayed callback cannot restore marker focus.
        for (const type of ["mousedown","mouseup","click","dblclick"]) window.addEventListener(type, event => {
            if (event.button !== 0 || event.shiftKey) return;
            const header = this._alertHeaderFor(event.target);
            if (header) {event.preventDefault(); event.stopImmediatePropagation(); if (type === "mousedown") this._focusAlertBody(header);}
        },true);
        const protect = event => {
            if (this.settingsDialog || this.readingMode?.protected || window.File?.isLocked || event.isComposing || this._getEditor()?.isIME || this._getEditor()?.sourceView?.inSourceMode || !document.getElementById("write")?.contains(event.target)) return;
            const selection = window.getSelection(); if (!selection?.isCollapsed || !selection.rangeCount) return;
            const range = selection.getRangeAt(0), header = this._alertHeaderFor(range.startContainer);
            const editing = event.type === "beforeinput" || (!event.ctrlKey && !event.metaKey && !event.altKey && (event.key.length === 1 || ["Enter","Backspace","Delete"].includes(event.key)));
            if (!editing) return;
            const deleting = ['Backspace','Delete'].includes(event.key) || ['deleteContentBackward','deleteContentForward'].includes(event.inputType);
            if (deleting && !event.ctrlKey && !event.metaKey && !event.altKey && this._removeEmptyAlert(range)) {
                event.preventDefault(); event.stopImmediatePropagation(); return;
            }
            if (header) {
                this._focusAlertBody(header);
                if (event.key === "Backspace" || event.key === "Delete" || event.inputType?.startsWith("delete")) {event.preventDefault(); event.stopImmediatePropagation();}
                return;
            }
            // Backspace at the first body character must not merge into [!TYPE].
            if (event.key !== "Backspace" && event.inputType !== "deleteContentBackward") return;
            const element = range.startContainer.nodeType === 1 ? range.startContainer : range.startContainer.parentElement;
            const paragraph = element?.closest("p");
            if (!paragraph || !this._alertHeaderFor(paragraph.previousElementSibling)) return;
            const before = document.createRange(); before.selectNodeContents(paragraph); before.setEnd(range.startContainer,range.startOffset);
            if (!before.toString().replace(/\u200b/g,"")) {event.preventDefault(); event.stopImmediatePropagation();}
        };
        window.addEventListener("keydown",protect,true);
        window.addEventListener("beforeinput",protect,true);
    }


    _loadFloatingToolbarEnabled() {
        try {
            return window.localStorage?.getItem("editing-toolbar-floating-enabled") !== "0";
        } catch (error) {
            return true;
        }
    }

    _persistFloatingToolbarEnabled() {
        try {
            window.localStorage?.setItem("editing-toolbar-floating-enabled", this.floatingToolbarEnabled ? "1" : "0");
        } catch (error) {
            // ignore persistence failures
        }
    }

    _removeStaleNodes() {
        document.getElementById("editing-toolbar")?.remove();
        document.getElementById("editing-toolbar-top-host")?.remove();
        document.getElementById("editing-toolbar-link-dialog")?.remove();
        document.getElementById("editing-toolbar-image-resize-handle")?.remove();
    }

    _createTopToolbar() {
        const writeEl = document.getElementById("write");
        if (!writeEl?.parentElement) return;

        this.topHost = document.createElement("div");
        this.topHost.id = "editing-toolbar-top-host";

        this.topToolbar = document.createElement("div");
        this.topToolbar.id = "editing-toolbar-top";
        this.topToolbar.className = "editing-toolbar editing-toolbar-top";

        this._renderButtons(this.topToolbar, this.uiSettings.top, "top");
        this.topHost.appendChild(this.topToolbar);
        writeEl.parentElement.insertBefore(this.topHost, writeEl);
        this._protectToolbarPointer(this.topToolbar);
        this._createTopChrome();
    }

    _createFloatingToolbar() {
        this.toolbar = document.createElement("div");
        this.toolbar.id = "editing-toolbar";
        this.toolbar.className = "editing-toolbar editing-toolbar-floating";
        this.toolbar.hidden = true;

        this._renderButtons(this.toolbar, this.uiSettings.floating, "floating");
        document.body.appendChild(this.toolbar);
        this._protectToolbarPointer(this.toolbar);
    }

    _createLinkDialog() {
        const backdrop = document.createElement("div");
        backdrop.id = "editing-toolbar-link-dialog";
        backdrop.className = "et-link-dialog-backdrop";
        backdrop.hidden = true;

        const dialog = document.createElement("div");
        dialog.className = "et-link-dialog";
        dialog.addEventListener("mousedown", (event) => {
            event.stopPropagation();
        });
        dialog.addEventListener("click", (event) => {
            event.stopPropagation();
        });

        const title = document.createElement("div");
        title.className = "et-link-dialog-title";
        title.textContent = "插入链接";
        dialog.appendChild(title);

        const urlLabel = document.createElement("label");
        urlLabel.className = "et-link-dialog-label";
        urlLabel.textContent = "链接地址";
        dialog.appendChild(urlLabel);

        const urlInput = document.createElement("input");
        urlInput.type = "text";
        urlInput.className = "et-link-dialog-input";
        urlInput.placeholder = "https://";
        dialog.appendChild(urlInput);

        const textLabel = document.createElement("label");
        textLabel.className = "et-link-dialog-label";
        textLabel.textContent = "显示文本";
        dialog.appendChild(textLabel);

        const textInput = document.createElement("input");
        textInput.type = "text";
        textInput.className = "et-link-dialog-input";
        textInput.placeholder = "链接文本";
        dialog.appendChild(textInput);

        const actions = document.createElement("div");
        actions.className = "et-link-dialog-actions";

        const cancelButton = document.createElement("button");
        cancelButton.type = "button";
        cancelButton.className = "et-link-dialog-btn et-link-dialog-btn-secondary";
        cancelButton.textContent = "取消";
        cancelButton.addEventListener("click", () => {
            this._closeLinkDialog(null);
        });

        const confirmButton = document.createElement("button");
        confirmButton.type = "button";
        confirmButton.className = "et-link-dialog-btn et-link-dialog-btn-primary";
        confirmButton.textContent = "插入";
        confirmButton.addEventListener("click", () => {
            const url = String(urlInput.value || "").trim();
            const linkTitle = String(textInput.value || "").trim();
            if (!url) {
                urlInput.focus();
                return;
            }
            this._closeLinkDialog({
                url,
                title: linkTitle || url
            });
        });

        actions.appendChild(cancelButton);
        actions.appendChild(confirmButton);
        dialog.appendChild(actions);

        backdrop.appendChild(dialog);
        backdrop.addEventListener("click", () => {
            this._closeLinkDialog(null);
        });

        urlInput.addEventListener("keydown", (event) => {
            if (event.key === "Enter") {
                event.preventDefault();
                confirmButton.click();
            }
        });

        textInput.addEventListener("keydown", (event) => {
            if (event.key === "Enter") {
                event.preventDefault();
                confirmButton.click();
            }
        });

        this.linkDialog = backdrop;
        this.linkDialogUrlInput = urlInput;
        this.linkDialogTitleInput = textInput;
        document.body.appendChild(backdrop);
    }

    _createImageResizeHandle() {
        const handle = document.createElement("div");
        handle.id = "editing-toolbar-image-resize-handle";
        handle.className = "et-image-resize-handle";
        handle.hidden = true;
        handle.title = "拖拽调整媒体尺寸";
        handle.addEventListener("mousedown", (event) => {
            this._startImageResize(event);
        });

        this.imageResizeHandle = handle;
        document.body.appendChild(handle);
    }

    _renderButtons(container, buttonIds, location) {
        container.innerHTML = "";
        [...new Set(buttonIds)].forEach((buttonId) => {
            if (buttonId === "|") {
                const divider = document.createElement("span");
                divider.className = "et-divider";
                container.appendChild(divider);
                return;
            }
            const definition = BUTTON_DEFINITIONS[buttonId];
            if (!definition) return;
            if (definition.actions) {
                const actions = location === "top" && this.uiSettings.topLayout === "compact" ? this.uiSettings.layouts.compact.menus[buttonId] : definition.actions;
                if (actions?.length) container.appendChild(this._createGroupControl(buttonId, {...definition,actions}, location));
            } else if (definition.colorPicker) {
                container.appendChild(this._createColorControl(buttonId, definition, location));
            } else if (definition.emojiPicker) {
                container.appendChild(this._createEmojiControl(buttonId, definition, location));
            } else if (definition.menuItems) {
                container.appendChild(this._createMenuControl(buttonId, definition, location));
            } else {
                container.appendChild(this._createButton(buttonId, definition, location));
            }
        });
        this._setupToolbarAccess(container, location);
    }

    _protectToolbarPointer(element) {
        element.addEventListener("mousedown", (event) => {
            event.preventDefault();
            event.stopPropagation();
        });
        element.addEventListener("click", (event) => {
            event.stopPropagation();
        });
    }

    _createButton(id, definition, location, onClick = null) {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "et-btn";
        if (location !== "floating") {
            button.classList.add("et-btn-top");
        }
        button.title = definition.title || "";
        button.dataset.baseTitle = button.title;
        button.setAttribute("aria-label", button.title);
        if (definition.actions || definition.menuItems || definition.colorPicker || definition.emojiPicker) {
            button.setAttribute("aria-haspopup", "true"); button.setAttribute("aria-expanded", "false");
        }
        button.innerHTML = definition.icon;
        button.dataset.action = id;
        if (definition.stateful) {
            button.dataset.stateful = "1";
        }
        button.addEventListener("mousedown", (event) => {
            this._saveSelection();
            event.preventDefault();
            event.stopPropagation();
        });
        button.addEventListener("click", (event) => {
            event.preventDefault();
            event.stopPropagation();
            if (typeof onClick === "function") {
                onClick(event);
                if (event.detail === 0 && this.activePopover) this._focusFirstControl(this.activePopover);
                return;
            }
            this._executeAction(id);
        });
        if (id === "floating-toolbar-toggle") {
            this._updateFloatingToolbarToggleButton(button);
        }
        return button;
    }

    _createColorControl(id, definition, location) {
        const wrapper = document.createElement("div");
        wrapper.className = "et-popover-anchor";

        const button = this._createButton(id, definition, location, () => {
            this._saveSelection();
            this._togglePopover(picker, location);
        });
        button.classList.add("et-btn-color");
        wrapper.appendChild(button);

        const picker = this._buildColorPicker(id);
        wrapper.appendChild(picker);

        return wrapper;
    }

    _createEmojiControl(id, definition, location) {
        const wrapper = document.createElement("div");
        wrapper.className = "et-popover-anchor";

        const picker = this._buildEmojiPicker();
        const button = this._createButton(id, definition, location, () => {
            this._saveSelection();
            this._togglePopover(picker, location);
        });

        wrapper.appendChild(button);
        wrapper.appendChild(picker);
        return wrapper;
    }

    _createMenuControl(id, definition, location) {
        const wrapper = document.createElement("div");
        wrapper.className = "et-popover-anchor";

        const panel = this._buildMenuPanel(definition.menuItems || [], definition.panelClass || "");
        const button = this._createButton(id, definition, location, () => {
            this._saveSelection();
            this._togglePopover(panel, location);
        });

        wrapper.appendChild(button);
        wrapper.appendChild(panel);
        return wrapper;
    }

    _historyColor(color) {
        if(typeof color!=='string')return '';
        if(/^#[0-9a-f]{6}$/i.test(color))return color.toUpperCase();
        const rgba=color.match(/^rgba\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(0(?:\.\d+)?|1(?:\.0+)?)\s*\)$/i);
        return rgba&&rgba.slice(1,4).every(n=>Number(n)<=255)?`rgba(${+rgba[1]}, ${+rgba[2]}, ${+rgba[3]}, ${+rgba[4]})`:'';
    }
    _colorHistory(kind) {
        try {const data=JSON.parse(localStorage.getItem('editing-toolbar-color-history-v1')||'{}');return [...new Set((Array.isArray(data[kind])?data[kind]:[]).map(c=>this._historyColor(c)).filter(Boolean))].slice(0,10);}catch{return [];}
    }
    _rememberColor(kind,color) {
        color=this._historyColor(color);if(!color)return;
        const data={'font-color':this._colorHistory('font-color'),'bg-color':this._colorHistory('bg-color')};data[kind]=[color,...data[kind].filter(c=>c!==color)].slice(0,10);
        try{localStorage.setItem('editing-toolbar-color-history-v1',JSON.stringify(data));}catch{return;}
        for(const root of document.querySelectorAll('.et-color-history'))this._renderColorHistory(root,root.dataset.colorKind);
    }
    _renderColorHistory(root,kind) {
        root.replaceChildren();const title=document.createElement('div');title.className='et-color-section-title';title.textContent='Recent Colors';root.append(title);
        const colors=this._colorHistory(kind);root.hidden=!colors.length;if(!colors.length)return;
        const grid=document.createElement('div');grid.className='et-color-grid et-color-grid-square';grid.style.setProperty('--et-color-columns','10');
        for(const color of colors){const b=document.createElement('button');b.type='button';b.className='et-color-swatch et-color-swatch-square';b.title=color;b.setAttribute('aria-label','Recent color '+color);b.style.background=color;b.onmousedown=e=>{this._saveSelection();e.preventDefault();e.stopPropagation();};b.onclick=e=>{e.preventDefault();e.stopPropagation();kind==='font-color'?this._applyFontColor(color):this._applyBgColor(color);this._closeActivePopover();};grid.append(b);}root.append(grid);
    }
    _buildColorPicker(kind) {
        const picker = document.createElement("div");
        picker.className = "et-color-picker";
        picker.dataset.colorKind=kind;
        picker.hidden = true;

        const sections = [...(kind === "font-color" ? this.config.FONT_COLOR_SECTIONS : this.config.BG_COLOR_SECTIONS)];


        sections.forEach((section) => {
            const sectionEl = document.createElement("section");
            sectionEl.className = "et-color-section"+(section.theme?" et-color-theme":"");

            const title = document.createElement("div");
            title.className = "et-color-section-title";
            title.textContent = section.label;
            sectionEl.appendChild(title);

            const grid = document.createElement("div");
            grid.className = `et-color-grid et-color-grid-${section.shape}`;
            grid.style.setProperty("--et-color-columns", String(section.columns || 5));

            section.colors.forEach((color) => {
                const swatch = document.createElement("button");
                swatch.type = "button";
                swatch.className = `et-color-swatch et-color-swatch-${section.shape}`;
                swatch.title = color;
                swatch.setAttribute("aria-label",color);
                swatch.style.background = color;
                swatch.addEventListener("mousedown", (event) => {
                    this._saveSelection();
                    event.preventDefault();
                    event.stopPropagation();
                });
                swatch.addEventListener("click", (event) => {
                    event.preventDefault();
                    event.stopPropagation();
                    if (kind === "font-color") {
                        this._applyFontColor(color);
                    } else {
                        this._applyBgColor(color);
                    }
                    this._closeActivePopover();
                });
                grid.appendChild(swatch);
            });

            sectionEl.appendChild(grid);
            picker.appendChild(sectionEl);
        });

        const history=document.createElement("section");history.className="et-color-section et-color-history";history.dataset.colorKind=kind;this._renderColorHistory(history,kind);picker.append(history);
        return this._preparePopover(picker);
    }

    _buildEmojiPicker() {
        const picker = document.createElement("div");
        picker.className = "et-emoji-picker";
        picker.hidden = true;

        this.config.EMOJI_SECTIONS.forEach((section) => {
            const sectionEl = document.createElement("section");
            sectionEl.className = "et-emoji-section";

            const title = document.createElement("div");
            title.className = "et-color-section-title";
            title.textContent = section.label;
            sectionEl.appendChild(title);

            const grid = document.createElement("div");
            grid.className = "et-emoji-grid";
            grid.style.setProperty("--et-emoji-columns", String(section.columns || 5));

            section.items.forEach((item) => {
                const button = document.createElement("button");
                button.type = "button";
                button.className = "et-emoji-item";
                button.title = `${item.emoji} ${item.label}`;
                button.innerHTML = `
                    <span class="et-emoji-item-emoji">${item.emoji}</span>
                    <span class="et-emoji-item-label">${item.label}</span>
                `;
                button.addEventListener("mousedown", (event) => {
                    this._saveSelection();
                    event.preventDefault();
                    event.stopPropagation();
                });
                button.addEventListener("click", (event) => {
                    event.preventDefault();
                    event.stopPropagation();
                    this._insertEmoji(item.emoji);
                    this._closeActivePopover();
                });
                grid.appendChild(button);
            });

            sectionEl.appendChild(grid);
            picker.appendChild(sectionEl);
        });

        return this._preparePopover(picker);
    }

    _buildMenuPanel(menuItems, panelClass = "") {
        const panel = document.createElement("div");
        panel.className = "et-menu-panel";
        if (panelClass) {
            panel.classList.add(panelClass);
        }
        panel.hidden = true;

        menuItems.forEach((item) => {
            if (!item) return;
            if (item.type === "header") {
                const title = document.createElement("div");
                title.className = "et-menu-section-title";
                title.textContent = item.label || "";
                panel.appendChild(title);
                return;
            }
            if (item.type === "divider") {
                const divider = document.createElement("div");
                divider.className = "et-menu-divider";
                panel.appendChild(divider);
                return;
            }

            const button = document.createElement("button");
            button.type = "button";
            button.className = "et-menu-item";
            if (item.description) {
                button.classList.add("et-menu-item-rich");
                button.innerHTML = `
                    <span class="et-menu-item-label">${this._escapeHtml(item.label || "")}</span>
                    <span class="et-menu-item-desc">${this._escapeHtml(item.description)}</span>
                `;
            } else {
                button.textContent = item.label;
            }
            button.title = item.title || item.label;
            button.addEventListener("mousedown", (event) => {
                this._saveSelection();
                event.preventDefault();
                event.stopPropagation();
            });
            button.addEventListener("click", (event) => {
                event.preventDefault();
                event.stopPropagation();
                this._executeAction(item.action || item.id);
                this._closeActivePopover();
            });
            panel.appendChild(button);
        });

        return this._preparePopover(panel);
    }

    _preparePopover(panel) {
        if (!panel || panel.dataset.etPopoverPrepared === "1") {
            return panel;
        }

        panel.dataset.etPopoverPrepared = "1";
        panel.id = `et-popover-${this.popoverSerial = (this.popoverSerial || 0) + 1}`;
        panel.querySelectorAll("button").forEach(button=>{button.tabIndex=-1;button.setAttribute("aria-label",button.title || button.textContent);});
        const markInteraction = () => {
            this._markPopoverInteraction();
        };

        panel.addEventListener("mousedown", markInteraction, true);
        panel.addEventListener("click", markInteraction, true);
        panel.addEventListener("wheel", markInteraction, { passive: true });
        panel.addEventListener("scroll", markInteraction, { passive: true });
        panel.addEventListener("mouseenter", markInteraction);

        return panel;
    }

    _positionPopover(panel, location) {
        if (panel.hidden || !panel.parentElement) return;
        const padding = 8;
        const gap = 10;
        const width = document.documentElement.clientWidth;
        const height = document.documentElement.clientHeight;
        const anchor = panel.parentElement.getBoundingClientRect();
        Object.assign(panel.style, { marginLeft: "0px", marginTop: "0px", maxHeight: "", maxWidth: `${Math.max(0, width - padding * 2)}px` });
        if (panel.classList.contains("et-menu-panel")) {
            const preferred = panel.classList.contains("et-template-panel") || panel.classList.contains("et-actions-detail") ? 320 : 220;
            panel.style.width = `${Math.min(preferred,Math.max(0,width-padding*2))}px`;
        }
        const availableAbove = Math.max(0, anchor.top - gap - padding);
        const availableBelow = Math.max(0, height - anchor.bottom - gap - padding);
        const needed = panel.getBoundingClientRect().height;
        let above = location !== "top";
        if ((above ? availableAbove : availableBelow) < needed) {
            above = availableAbove > availableBelow;
        }
        panel.classList.toggle("et-popover-above", above);
        panel.classList.toggle("et-popover-below", !above);
        panel.style.maxHeight = `${Math.min(needed, above ? availableAbove : availableBelow)}px`;
        const rect = panel.getBoundingClientRect();
        const left = Math.max(padding, Math.min(rect.left, width - padding - rect.width));
        panel.style.marginLeft = `${left - rect.left}px`;
    }

    _togglePopover(panel, location) {
        if (this.activePopover === panel) {
            this._closeActivePopover();
            return;
        }
        this._closeActivePopover();
        panel.hidden = false;
        panel.classList.remove("et-popover-above", "et-popover-below");
        panel.classList.add(location === "top" ? "et-popover-below" : "et-popover-above");
        this.activePopover = panel;
        const trigger=panel.parentElement.querySelector(":scope > .et-btn");
        trigger?.setAttribute("aria-expanded","true");trigger?.setAttribute("aria-controls",panel.id);
        this._updateToolbarState();
        if (location === "top") this.hide();
        this._positionPopover(panel, location);
        // Re-measure after the floating toolbar finishes entering the layout.
        requestAnimationFrame(() => {
            if (this.activePopover === panel) this._positionPopover(panel, location);
        });
        this._markPopoverInteraction();
    }

    _closeActivePopover() {
        if (!this.activePopover) return;
        this.activePopover.parentElement.querySelector(":scope > .et-btn")?.setAttribute("aria-expanded","false");
        this.activePopover.hidden = true;
        this.activePopover.classList.remove("et-popover-above", "et-popover-below");
        this.activePopover = null;
    }

    _bindEvents() {
        document.addEventListener("selectionchange", () => {
            clearTimeout(this.hideTimeout);
            this.hideTimeout = setTimeout(() => {
                this._updateToolbarState();
                if (this.settingsDialog || this._isInsideToolbar(document.activeElement)) return;
                this._saveSelection();
                this._onSelectionChange();
            }, 80);
        });

        document.addEventListener("mouseup", (event) => {
            if (this.imageResizeState) {
                this._finishImageResize();
                return;
            }
            if (this._isInsideToolbar(event.target)) return;
            clearTimeout(this.hideTimeout);
            this.hideTimeout = setTimeout(() => {
                this._saveSelection();
                this._onSelectionChange();
            }, 40);
        });

        document.addEventListener("mousedown", (event) => {
            if (this._isInsideImageResizeHandle(event.target)) return;
            if (this._isInsideToolbar(event.target) || this._isInsideActivePopoverEvent(event)) {
                this._markPopoverInteraction();
                return;
            }
            this._closeActivePopover();
            const image = this._getEditorImageFromTarget(event.target);
            if (!image) {
                this._hideImageResizeHandle();
            }
            setTimeout(() => {
                const selection = window.getSelection();
                if (!selection || selection.isCollapsed || !selection.toString().trim()) {
                    this.hide();
                }
            }, 60);
        });

        document.addEventListener("click", (event) => {
            if (this._isInsideToolbar(event.target) || this._isInsideImageResizeHandle(event.target) || this._isInsideActivePopoverEvent(event)) {
                this._markPopoverInteraction();
                return;
            }
            const image = this._getEditorImageFromTarget(event.target);
            if (image) {
                this._showImageResizeHandle(image);
            } else if (!this.imageResizeState) {
                this._hideImageResizeHandle();
            }
        });

        document.addEventListener("mousemove", (event) => {
            if (!this.imageResizeState) return;
            this._updateImageResize(event);
        });

        document.addEventListener("keydown", (event) => {
            if (event.key === "Escape") return;
            if (!event.ctrlKey && !event.altKey && !event.metaKey) {
                this._closeActivePopover();
            }
        });

        document.addEventListener("scroll", (event) => {
            const scrollTarget = event.target;
            if (this.activePopover && scrollTarget && typeof scrollTarget.nodeType === "number" && this.activePopover.contains(scrollTarget)) {
                this._markPopoverInteraction();
                return;
            }
            if (this.activePopover && this._hasRecentPopoverInteraction()) {
                return;
            }
            if (this.isVisible) {
                this.hide();
            }
            this._closeActivePopover();
            this._positionImageResizeHandle();
        }, true);

        window.addEventListener("resize", () => {
            this._closeActivePopover();
            if (this.isVisible) {
                this.hide();
            }
            this._positionImageResizeHandle();
        });
    }

    _isInsideToolbar(target) {
        return Boolean(
            (this.toolbar && this.toolbar.contains(target)) ||
            (this.topHost && this.topHost.contains(target))
        );
    }

    _markPopoverInteraction() {
        this.lastPopoverInteractionAt = Date.now();
    }

    _hasRecentPopoverInteraction(withinMs = 220) {
        return Boolean(this.lastPopoverInteractionAt && (Date.now() - this.lastPopoverInteractionAt) <= withinMs);
    }

    _isPointInsideElementRect(element, clientX, clientY) {
        if (!(element instanceof Element)) return false;
        if (!Number.isFinite(clientX) || !Number.isFinite(clientY)) return false;
        const rect = element.getBoundingClientRect();
        return clientX >= rect.left && clientX <= rect.right && clientY >= rect.top && clientY <= rect.bottom;
    }

    _isInsideActivePopoverEvent(event) {
        if (!this.activePopover) return false;

        const target = event?.target;
        if (target && typeof target.nodeType === "number" && this.activePopover.contains(target)) {
            return true;
        }

        return this._isPointInsideElementRect(this.activePopover, event?.clientX, event?.clientY);
    }

    _isInsideImageResizeHandle(target) {
        return Boolean(this.imageResizeHandle && this.imageResizeHandle.contains(target));
    }

    _getEditorImageFromTarget(target) {
        if (!(target instanceof Element)) return null;
        const media = target.closest("#write img, #write video");
        return this._isResizableMediaElement(media) ? media : null;
    }

    _isResizableMediaElement(element) {
        return element instanceof HTMLImageElement || element instanceof HTMLVideoElement;
    }

    _getImageBlock(image) {
        if (!this._isResizableMediaElement(image)) return null;
        return image.closest("p, div, figure, li, blockquote");
    }

    _captureImageAlignment(image) {
        if (!this._isResizableMediaElement(image)) return null;

        const block = this._getImageBlock(image);
        const blockStyle = block ? getComputedStyle(block) : null;

        return {
            signature: {
                tagName: image.tagName.toLowerCase(),
                src: this._getMediaSource(image),
                alt: image instanceof HTMLImageElement ? (image.getAttribute("alt") || "") : "",
                poster: image instanceof HTMLVideoElement ? (image.getAttribute("poster") || "") : ""
            },
            blockInlineTextAlign: block?.style?.textAlign || "",
            blockComputedTextAlign: blockStyle?.textAlign || "",
            imageInlineDisplay: image.style.display || "",
            imageInlineMarginLeft: image.style.marginLeft || "",
            imageInlineMarginRight: image.style.marginRight || "",
            imageInlineFloat: image.style.float || ""
        };
    }

    _findImageBySignature(signature) {
        if (!signature) return null;
        const images = Array.from(document.querySelectorAll("#write img, #write video"));
        return images.find((image) => {
            if (!this._isResizableMediaElement(image)) return false;
            if ((signature.tagName || "") !== image.tagName.toLowerCase()) return false;
            const src = this._getMediaSource(image);
            const alt = image instanceof HTMLImageElement ? (image.getAttribute("alt") || "") : "";
            const poster = image instanceof HTMLVideoElement ? (image.getAttribute("poster") || "") : "";
            return (signature.src && src === signature.src)
                || (signature.alt && alt === signature.alt)
                || (signature.poster && poster === signature.poster);
        }) || null;
    }

    _restoreImageAlignment(image, alignmentState) {
        if (!alignmentState) return;

        const targetImage = image?.isConnected ? image : this._findImageBySignature(alignmentState.signature);
        if (!this._isResizableMediaElement(targetImage)) return;

        const block = this._getImageBlock(targetImage);
        if (block) {
            if (alignmentState.blockInlineTextAlign) {
                block.style.textAlign = alignmentState.blockInlineTextAlign;
            } else if (/center|right|justify/i.test(alignmentState.blockComputedTextAlign || "")) {
                block.style.textAlign = alignmentState.blockComputedTextAlign;
            } else {
                block.style.removeProperty("text-align");
            }
        }

        if (alignmentState.imageInlineDisplay) {
            targetImage.style.display = alignmentState.imageInlineDisplay;
        } else {
            targetImage.style.removeProperty("display");
        }

        if (alignmentState.imageInlineMarginLeft) {
            targetImage.style.marginLeft = alignmentState.imageInlineMarginLeft;
        } else {
            targetImage.style.removeProperty("margin-left");
        }

        if (alignmentState.imageInlineMarginRight) {
            targetImage.style.marginRight = alignmentState.imageInlineMarginRight;
        } else {
            targetImage.style.removeProperty("margin-right");
        }

        if (alignmentState.imageInlineFloat) {
            targetImage.style.float = alignmentState.imageInlineFloat;
        } else {
            targetImage.style.removeProperty("float");
        }
    }

    _showImageResizeHandle(image) {
        if (!this._isResizableMediaElement(image)) return;
        this.activeImage = image;
        if (this.imageResizeHandle) {
            this.imageResizeHandle.hidden = false;
        }
        this._positionImageResizeHandle();
    }

    _hideImageResizeHandle() {
        if (this.imageResizeState) return;
        this.activeImage = null;
        if (this.imageResizeHandle) {
            this.imageResizeHandle.hidden = true;
        }
    }

    _positionImageResizeHandle() {
        if (!this.imageResizeHandle) {
            return;
        }

        const anchor = this.imageResizeState?.overlay || this.activeImage;
        if (!anchor || !anchor.isConnected) {
            this._hideImageResizeHandle();
            return;
        }

        const rect = anchor.getBoundingClientRect();
        if (rect.width < 24 || rect.height < 24 || rect.bottom < 0 || rect.right < 0 || rect.left > window.innerWidth || rect.top > window.innerHeight) {
            this.imageResizeHandle.hidden = true;
            return;
        }

        this.imageResizeHandle.hidden = false;
        this.imageResizeHandle.style.left = `${rect.right - 7}px`;
        this.imageResizeHandle.style.top = `${rect.bottom - 7}px`;
    }

    _startImageResize(event) {
        if (!this.activeImage) return;
        event.preventDefault();
        event.stopPropagation();

        const rect = this.activeImage.getBoundingClientRect();
        const naturalWidth = this._getMediaNaturalWidth(this.activeImage, rect);
        const naturalHeight = this._getMediaNaturalHeight(this.activeImage, rect);
        const aspectRatio = naturalWidth > 0 && naturalHeight > 0
            ? naturalWidth / naturalHeight
            : (rect.height > 0 ? rect.width / rect.height : 1);
        this.imageResizeState = {
            image: this.activeImage,
            startX: event.clientX,
            startWidth: rect.width,
            startHeight: rect.height,
            previewWidth: rect.width,
            previewHeight: rect.height,
            naturalWidth,
            naturalHeight,
            aspectRatio,
            alignmentState: this._captureImageAlignment(this.activeImage),
            originalVisibility: this.activeImage.style.visibility || "",
            overlay: this._createImageResizeOverlay(this.activeImage, rect)
        };

        this.activeImage.style.visibility = "hidden";
        document.body.classList.add("et-image-resizing");
    }

    _updateImageResize(event) {
        if (!this.imageResizeState?.image?.isConnected) {
            this._cancelImageResize();
            return;
        }

        event.preventDefault();
        const state = this.imageResizeState;
        const deltaX = event.clientX - state.startX;
        const maxWidth = Math.max(state.naturalWidth * 2, window.innerWidth * 1.5, state.startWidth);
        const nextWidth = Math.min(maxWidth, Math.max(48, state.startWidth + deltaX));
        const nextHeight = state.aspectRatio > 0 ? nextWidth / state.aspectRatio : state.startHeight;
        state.previewWidth = nextWidth;
        state.previewHeight = nextHeight;

        if (state.overlay?.isConnected) {
            state.overlay.style.width = `${Math.round(nextWidth)}px`;
            state.overlay.style.height = `${Math.round(nextHeight)}px`;
            state.overlay.style.maxWidth = "none";
        }
        this._positionImageResizeHandle();
    }

    _finishImageResize() {
        if (!this.imageResizeState) return;

        const state = this.imageResizeState;
        this.imageResizeState = null;
        document.body.classList.remove("et-image-resizing");

        if (state.image?.isConnected) {
            state.image.style.visibility = state.originalVisibility;
        }

        const committed = this._commitImageResize(state.image, state.previewWidth, state.naturalWidth);
        if (!committed) {
            state.image.style.width = `${Math.round(state.previewWidth)}px`;
            state.image.style.height = "auto";
            state.image.style.maxWidth = "none";
        }

        this._teardownImageResizeOverlay(state);
        this._restoreImageAlignment(state.image, state.alignmentState);

        this._showImageResizeHandle(state.image);
    }

    _cancelImageResize() {
        if (!this.imageResizeState) return;

        const state = this.imageResizeState;
        this.imageResizeState = null;
        document.body.classList.remove("et-image-resizing");

        if (state.image?.isConnected) {
            state.image.style.visibility = state.originalVisibility;
        }

        this._teardownImageResizeOverlay(state);
        this._showImageResizeHandle(state.image);
    }

    _createImageResizeOverlay(image, rect) {
        if (!this._isResizableMediaElement(image)) return null;

        const overlay = image.cloneNode(true);
        overlay.className = [image.className, "et-image-resize-overlay"].filter(Boolean).join(" ");
        overlay.draggable = false;
        overlay.removeAttribute("id");

        if (overlay instanceof HTMLVideoElement) {
            overlay.muted = true;
            overlay.loop = false;
            overlay.autoplay = false;
            overlay.controls = false;
            overlay.preload = "metadata";
            try {
                overlay.pause();
                overlay.currentTime = 0;
            } catch (error) {
                // ignore preview sync issues
            }
        }

        const computedStyle = getComputedStyle(image);
        overlay.style.position = "fixed";
        overlay.style.left = `${rect.left}px`;
        overlay.style.top = `${rect.top}px`;
        overlay.style.width = `${rect.width}px`;
        overlay.style.height = `${rect.height}px`;
        overlay.style.maxWidth = "none";
        overlay.style.maxHeight = "none";
        overlay.style.margin = "0";
        overlay.style.transform = "none";
        overlay.style.transformOrigin = "top left";
        overlay.style.zoom = "1";
        overlay.style.display = "block";
        overlay.style.objectFit = computedStyle.objectFit;
        overlay.style.objectPosition = computedStyle.objectPosition;
        overlay.style.borderRadius = computedStyle.borderRadius;
        overlay.style.background = computedStyle.backgroundColor;
        overlay.style.pointerEvents = "none";
        document.body.appendChild(overlay);
        return overlay;
    }

    _teardownImageResizeOverlay(state) {
        if (state?.overlay?.isConnected) {
            state.overlay.remove();
        }
    }

    _commitImageResize(image, width, naturalWidth) {
        if (image instanceof HTMLVideoElement) {
            return this._commitVideoResize(image, width);
        }

        const percent = Math.max(5, Math.min(2000, Math.round((width / (naturalWidth || width)) * 100)));
        const imgEdit = window.File?.editor?.imgEdit;

        if (!imgEdit?.zoomAction || !image?.isConnected) {
            return false;
        }

        try {
            this._focusImageForResize(image);
            try {
                imgEdit.zoomAction(image, `${percent}%`);
            } catch (error) {
                imgEdit.zoomAction(null, `${percent}%`);
            }
            return true;
        } catch (error) {
            console.warn("[EditingToolbar] Failed to commit image resize:", error);
            return false;
        }
    }

    _focusImageForResize(image) {
        if (!this._isResizableMediaElement(image)) return;
        const rect = image.getBoundingClientRect();
        const options = {
            bubbles: true,
            cancelable: true,
            clientX: rect.left + Math.min(rect.width, 12),
            clientY: rect.top + Math.min(rect.height, 12)
        };

        image.dispatchEvent(new MouseEvent("mousedown", options));
        image.dispatchEvent(new MouseEvent("mouseup", options));
        image.dispatchEvent(new MouseEvent("click", options));
    }

    _getMediaSource(media) {
        if (!this._isResizableMediaElement(media)) return "";
        return media.currentSrc
            || media.getAttribute("src")
            || media.querySelector?.("source")?.getAttribute("src")
            || "";
    }

    _getMediaNaturalWidth(media, rect) {
        if (media instanceof HTMLImageElement) {
            return media.naturalWidth || rect.width;
        }
        if (media instanceof HTMLVideoElement) {
            return media.videoWidth || rect.width;
        }
        return rect.width;
    }

    _getMediaNaturalHeight(media, rect) {
        if (media instanceof HTMLImageElement) {
            return media.naturalHeight || rect.height;
        }
        if (media instanceof HTMLVideoElement) {
            return media.videoHeight || rect.height;
        }
        return rect.height;
    }

    _commitVideoResize(video, width) {
        if (!(video instanceof HTMLVideoElement) || !video.isConnected) {
            return false;
        }

        try {
            const rounded = Math.max(96, Math.round(width));
            video.style.width = `${rounded}px`;
            video.style.height = "auto";
            video.style.maxWidth = "none";
            video.setAttribute("width", String(rounded));
            video.removeAttribute("height");
            this._notifyMediaMutation(video);
            return true;
        } catch (error) {
            console.warn("[EditingToolbar] Failed to resize video:", error);
            return false;
        }
    }

    _notifyMediaMutation(media) {
        const writeEl = document.getElementById("write");
        const block = media?.closest?.("p, div, figure, li, blockquote");
        const targets = [media, block, writeEl].filter(Boolean);
        targets.forEach((target) => {
            try {
                target.dispatchEvent(new Event("input", { bubbles: true }));
                target.dispatchEvent(new Event("change", { bubbles: true }));
            } catch (error) {
                // ignore event dispatch failures
            }
        });
    }

    _resolveRange(selectionOrRange = window.getSelection()) {
        if (!selectionOrRange) return null;
        if (typeof selectionOrRange.getRangeAt === "function" && selectionOrRange.rangeCount > 0) {
            return selectionOrRange.getRangeAt(0);
        }
        if (typeof selectionOrRange.cloneRange === "function") {
            return selectionOrRange;
        }
        return null;
    }

    _saveSelection(selection = null) {
        const editor = this._getEditor();
        const domSelection = selection || window.getSelection();
        const domRange = this._resolveRange(domSelection);
        const editorRange = editor?.selection?.getRangy?.() || null;
        const hasDomText = Boolean(String(domSelection?.toString?.() || "").trim());
        const activeRange = hasDomText && this._selectionInEditor(domRange)
            ? domRange
            : (this._selectionInEditor(editorRange) ? editorRange : domRange);
        if (!activeRange) return;
        if (!this._selectionInEditor(activeRange)) return;
        try {
            this.savedRangy = activeRange.cloneRange();
            this.savedRange = activeRange.cloneRange();
            this.lastSelectionText = this._getSelectionText(activeRange);
            const cursor = editor?.selection?.buildUndo?.(activeRange);
            if (cursor) {
                this.savedCursor = cursor;
                editor.selection.selectionBeforeBlur = cursor;
                editor.lastCursor = cursor;
            }
        } catch (error) {
            console.warn("[EditingToolbar] Failed to save selection:", error);
        }
    }

    _selectionInEditor(selection) {
        const writeEl = document.getElementById("write");
        const range = this._resolveRange(selection);
        if (!writeEl || !range) return false;
        // Typora replaces window.Node with its document model. Do not use
        // DOM node constants here: a multi-paragraph range has #write as its
        // common ancestor and was incorrectly treated as outside the editor.
        return writeEl.contains(range.startContainer) && writeEl.contains(range.endContainer);
    }

    _getSelectionText(selection = window.getSelection(), fallbackRange = this.savedRangy || this.savedRange) {
        const extractTextFromRange = (range) => {
            if (!range) return "";
            try {
                const fragment = range.cloneContents();
                const container = document.createElement("div");
                container.appendChild(fragment);
                return String(container.innerText || container.textContent || "");
            } catch (error) {
                return "";
            }
        };

        const directText = String(selection?.toString?.() || "");
        if (directText) {
            return directText;
        }

        const activeRange = this._resolveRange(selection);
        if (activeRange) {
            const rangeText = extractTextFromRange(activeRange);
            if (rangeText) {
                return rangeText;
            }
        }

        return extractTextFromRange(fallbackRange);
    }

    _selectionInCodeFence(selection) {
        if (!selection || selection.rangeCount === 0) return false;
        const range = selection.getRangeAt(0);
        const node = range.commonAncestorContainer;
        const element = node.nodeType === 1 ? node : node.parentElement;
        return Boolean(element?.closest(".md-fences"));
    }

    _onSelectionChange() {
        this._updateToolbarState();
        if (this.settingsDialog || this._isInsideToolbar(document.activeElement)) return;
        if (!this.floatingToolbarEnabled) {
            this.hide();
            return;
        }

        const selection = window.getSelection();
        if (!this._selectionInEditor(selection) || this._selectionInCodeFence(selection)) {
            this.hide();
            return;
        }

        const text = selection?.toString().trim();
        if (!text) {
            this.hide();
            return;
        }

        this.show(selection);
    }

    show(selection) {
        if (!this.toolbar?.querySelector(".et-btn")) return;
        if (this.settingsDialog || (this.activePopover && this.topToolbar?.contains(this.activePopover))) return;
        if (!this.floatingToolbarEnabled || !this.toolbar || !selection?.rangeCount) {this.hide();return;}
        const rect=this._getSelectionRect(selection);
        if (!rect.width && !rect.height) {this.hide();return;}
        this.toolbar.hidden=false;
        requestAnimationFrame(()=>{
            if (this.settingsDialog || (this.activePopover && this.topToolbar?.contains(this.activePopover))) {this.hide();return;}
            const bar=this.toolbar.getBoundingClientRect(),width=innerWidth,height=innerHeight;
            const topBounds=this.topHost?.getBoundingClientRect();
            const topLimit=this.uiSettings.topMode === "floating" ? 10 : Math.max(10,(topBounds?.bottom || 0)+8);
            const left=Math.max(10,Math.min(rect.left+rect.width/2-bar.width/2,width-bar.width-10));
            const headings=Array.from(document.querySelectorAll("#write h1,#write h2,#write h3,#write h4,#write h5,#write h6"),e=>e.getBoundingClientRect());
            const positions=[rect.bottom+this.config.OFFSET_Y,rect.top-bar.height-this.config.OFFSET_Y];
            const top=positions.find(y=>y>=topLimit && y+bar.height<=height-10 && !(this.uiSettings.topMode === "floating" && topBounds && topBounds.bottom>y && topBounds.top<y+bar.height && topBounds.right>left && topBounds.left<left+bar.width) && !headings.some(h=>h.height && h.bottom>y && h.top<y+bar.height && h.right>left && h.left<left+bar.width));
            if (top===undefined) {this.hide();return;}
            this.toolbar.style.left=left+"px";this.toolbar.style.top=top+"px";
            this.toolbar.classList.add("et-visible");this.isVisible=true;
        });
    }

    _getSelectionRect(selection) {
        if (!selection?.rangeCount) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0,
                width: 0,
                height: 0
            };
        }

        const range = selection.getRangeAt(0);
        const rect = range.getBoundingClientRect();
        if (rect.width || rect.height) {
            return rect;
        }

        const clientRects = Array.from(range.getClientRects?.() || []);
        if (!clientRects.length) {
            return rect;
        }

        const left = Math.min(...clientRects.map((item) => item.left));
        const top = Math.min(...clientRects.map((item) => item.top));
        const right = Math.max(...clientRects.map((item) => item.right));
        const bottom = Math.max(...clientRects.map((item) => item.bottom));

        return {
            left,
            top,
            right,
            bottom,
            width: Math.max(0, right - left),
            height: Math.max(0, bottom - top)
        };
    }

    hide() {
        if (!this.toolbar) return;
        this.toolbar.classList.remove("et-visible");
        this.toolbar.hidden = true;
        this.isVisible = false;
    }

    _toggleFloatingToolbarEnabled() {
        this.floatingToolbarEnabled = !this.floatingToolbarEnabled;
        this._persistFloatingToolbarEnabled();
        if (!this.floatingToolbarEnabled) {
            this.hide();
        }
        this._updateFloatingToolbarToggleButtons();
    }

    _updateFloatingToolbarToggleButtons() {
        document.querySelectorAll('button[data-action="floating-toolbar-toggle"]').forEach((button) => {
            this._updateFloatingToolbarToggleButton(button);
        });
    }

    _updateFloatingToolbarToggleButton(button) {
        if (!(button instanceof HTMLElement)) return;

        const enabled = this.floatingToolbarEnabled !== false;
        button.classList.toggle("et-btn-active", enabled);
        button.classList.toggle("et-btn-inactive", !enabled);
        button.setAttribute("aria-pressed", enabled ? "true" : "false");
        button.title = enabled ? "关闭小窗" : "打开小窗";
        button.dataset.baseTitle = button.title;
        const icon = enabled ? ICONS.floatingToolbarOn : ICONS.floatingToolbarOff;
        button.innerHTML = icon + (button.classList.contains("et-action-item") ? `<span>${button.title}</span>` : "");
        if (button.classList.contains("et-action-item")) {
            button.setAttribute("role", "menuitemcheckbox");
            button.setAttribute("aria-checked", enabled ? "true" : "false");
            button.removeAttribute("aria-pressed");
        }
        button.setAttribute("aria-label", button.title);
    }

    _executeAction(action) {
        this._closeActivePopover();
        if (action === "toolbar-settings") return this._openToolbarSettings();
        requestAnimationFrame(() => this._updateToolbarState());

        const actions = {
            "undo": () => this._undo(),
            "redo": () => this._redo(),
            "bold": () => this._toggleInlineStyle("strong"),
            "italic": () => this._toggleInlineStyle("em"),
            "strikethrough": () => this._toggleInlineStyle("del"),
            "underline": () => this._toggleInlineStyle("underline"),
            "highlight": () => this._toggleInlineStyle("highlight"),
            "font-size-decrease": () => this._adjustFontSize("decrease"),
            "font-size-increase": () => this._adjustFontSize("increase"),
            "code": () => this._toggleInlineCode(),
            "superscript": () => this._toggleInlineStyle("superscript"),
            "subscript": () => this._toggleInlineStyle("subscript"),
            "h1": () => this._changeHeading(1),
            "h2": () => this._changeHeading(2),
            "h3": () => this._changeHeading(3),
            "h4": () => this._changeHeading(4),
            "h5": () => this._changeHeading(5),
            "h6": () => this._changeHeading(6),
            "blockquote": () => this._toggleQuote(),
            "ordered-list": () => this._changeListStyle("ol"),
            "unordered-list": () => this._changeListStyle("ul"),
            "task-list": () => this._changeListStyle("tasklist"),
            "indent": () => this._changeIndent(true),
            "outdent": () => this._changeIndent(false),
            "align-left": () => this._setAlignment("left"),
            "align-center": () => this._setAlignment("center"),
            "align-right": () => this._setAlignment("right"),
            "align-justify": () => this._setAlignment("justify"),
            "codeblock": () => this._insertCodeBlock(),
            "inline-math": () => this._toggleInlineMath(),
            "inline-math-ascii": () => this._convertSelectionAsciiToMath(),
            "math-block": () => this._toggleMathBlock(),
            "warning-note": () => this._insertWarningBlock("note"),
            "warning-tip": () => this._insertWarningBlock("tip"),
            "warning-important": () => this._insertWarningBlock("important"),
            "warning-warning": () => this._insertWarningBlock("warning"),
            "warning-caution": () => this._insertWarningBlock("caution"),
            "hr": () => this._insertHorizontalRule(),
            "table": () => this._insertTable(),
            "link": () => this._insertLink(),
            "link-reference": () => this._insertLinkReference(),
            "footnote": () => this._insertFootnote(),
            "image": () => this._insertImage(),
            "video": () => this._insertVideo(),
            "clear-format": () => this._clearFormat(),
            "fullscreen": () => this._toggleFullscreen(),
            "floating-toolbar-toggle": () => this._toggleFloatingToolbarEnabled()
        };

        const handler = actions[action];
        if (!handler && typeof action === "string" && action.startsWith("template-")) {
            this._insertTemplate(action);
            return;
        }
        if (handler) {
            handler();
        }
    }

    _getEditor() {
        if (typeof File !== "undefined" && File.editor) {
            return File.editor;
        }
        return window.editor || null;
    }

    _restoreSelection(editor) {
        const baseRange = this.savedRangy || this.savedRange;
        if (!baseRange) return false;
        try {
            // Rangy wraps the browser Range; Selection.addRange requires the native one.
            const nativeRange = baseRange.nativeRange || baseRange;
            if (!this._selectionInEditor(nativeRange)) return false;
            const range = nativeRange.cloneRange();
            if (editor?.selection?.setRange) {
                try {
                    editor.selection.setRange(range.cloneRange(), true);
                } catch (error) {
                    editor.selection.setRange(range.cloneRange());
                }
            }

            const selection = window.getSelection();
            if (!selection) return false;
            selection.removeAllRanges();
            selection.addRange(range);
            return true;
        } catch (error) {
            try {
                const selection = window.getSelection();
                if (!selection) return false;
                selection.removeAllRanges();
                selection.addRange((baseRange.nativeRange || baseRange).cloneRange());
                return true;
            } catch (innerError) {
                console.warn("[EditingToolbar] Failed to restore selection:", innerError);
                return false;
            }
        }
    }

    _withEditorSelection(callback) {
        const editor = this._getEditor();
        const baseRange = this.savedRangy || this.savedRange;
        const collapsedCaret = Boolean(baseRange?.collapsed);
        let restored = false;
        if (collapsedCaret) {
            restored = this._focusEditorAtSavedCursor(editor);
            if (!restored && baseRange) {
                restored = this._restoreSelection(editor);
            }
        } else if (baseRange) {
            restored = this._restoreSelection(editor);
        }
        if (!restored) {
            restored = this._focusEditorAtSavedCursor(editor);
        }

        return callback(editor, window.getSelection(), restored);
    }

    _focusEditorAtSavedCursor(editor) {
        try {
            if (this.savedCursor && editor?.selection) {
                editor.selection.selectionBeforeBlur = this.savedCursor;
                editor.lastCursor = this.savedCursor;
            }

            editor?.focusAndRestorePos?.();
            editor?.refocus?.();

            const selection = window.getSelection();
            if (!this._selectionInEditor(selection)) {
                return false;
            }

            this._saveSelection(selection);
            return true;
        } catch (error) {
            console.warn("[EditingToolbar] Failed to focus editor at saved cursor:", error);
            return false;
        }
    }

    _undo() {
        const editor = this._getEditor();
        if (editor?.undo?.undo) {
            editor.undo.undo();
            return;
        }
        document.execCommand("undo");
    }

    _redo() {
        const editor = this._getEditor();
        if (editor?.undo?.redo) {
            editor.undo.redo();
            return;
        }
        document.execCommand("redo");
    }

    _toggleInlineStyle(style) {
        this._withEditorSelection((editor, selection) => {
            if (style === "underline" && !this._selectionHasText(selection)) {
                if (this._insertTextAtCaret("<u></u>", 4)) {
                    return;
                }
            }
            if (editor?.stylize?.toggleStyle) {
                editor.stylize.toggleStyle(style);
                return;
            }
            document.execCommand(style, false, null);
        });
    }

    _toggleInlineCode() {
        this._withEditorSelection((editor, selection) => {
            if (this._formatSelectedInline(editor, selection, "code")) return;
            if (this._selectionHasText(selection)) {
                const rawText = String(this._getSelectionText(selection) || this.lastSelectionText || "");
                const content = rawText.trim();
                if (!content) {
                    return;
                }

                const range = this._resolveRange(selection) || this.savedRange || this.savedRangy;
                const prevChar = this._getBoundaryAdjacentChar(range, "backward");
                const nextChar = this._getBoundaryAdjacentChar(range, "forward");
                const leadingSpace = /^\s/.test(rawText) ? "" : (this._shouldPadInlineMathLeft(prevChar) ? " " : "");
                const trailingSpace = /\s$/.test(rawText) ? "" : (this._shouldPadInlineMathRight(nextChar) ? " " : "");
                const codeSpan = this._buildInlineCodeSpan(content);
                this._replaceSelectionWithLiteralText(editor, `${leadingSpace}${codeSpan}${trailingSpace}`);
                return;
            }

            this._insertTextAtCaret("``", 1);
        });
    }

    _buildInlineCodeSpan(text) {
        const content = String(text || "").replace(/\r\n?/g, " ").replace(/\n/g, " ").trim();
        if (!content) {
            return "` `";
        }

        const tickMatches = content.match(/`+/g) || [];
        const maxTickLength = tickMatches.reduce((max, ticks) => Math.max(max, ticks.length), 0);
        const delimiter = "`".repeat(Math.max(1, maxTickLength + 1));
        const needsPadding = content.startsWith("`") || content.endsWith("`");
        const inner = needsPadding ? ` ${content} ` : content;
        return `${delimiter}${inner}${delimiter}`;
    }

    _getBoundaryAdjacentChar(range, direction = "backward") {
        const writeEl = document.getElementById("write");
        if (!range || !writeEl) return "";

        try {
            const probe = document.createRange();
            probe.selectNodeContents(writeEl);

            if (direction === "forward") {
                probe.setStart(range.endContainer, range.endOffset);
                const text = probe.toString();
                return text ? text.charAt(0) : "";
            }

            probe.setEnd(range.startContainer, range.startOffset);
            const text = probe.toString();
            return text ? text.slice(-1) : "";
        } catch (error) {
            console.warn("[EditingToolbar] Failed to inspect inline code boundaries:", error);
            return "";
        }
    }

    _formattingSelection(editor, selection) {
        const range = this._resolveRange(selection);
        if (!range || !this._selectionInEditor(range) || !editor?.undo?.buildReplaceUndo
            || !editor.MarkParser?.renderHtmlWithBlockMeta || editor.sourceView?.inSourceMode
            || editor.isIME || window.File?.isLocked || window.File?.bundle?.isLocked) return null;
        editor.store();
        const blocks = this._getAlignmentBlocks(range).filter(block => !block.querySelector('[md-inline="alert_text"]'));
        return {range, blocks};
    }

    _formattingOverlap(node, range) {
        const hit = document.createRange(); hit.selectNodeContents(node);
        if (range.compareBoundaryPoints(1, hit) <= 0 || range.compareBoundaryPoints(3, hit) >= 0) return null;
        if (range.compareBoundaryPoints(0, hit) > 0) hit.setStart(range.startContainer, range.startOffset);
        if (range.compareBoundaryPoints(2, hit) < 0) hit.setEnd(range.endContainer, range.endOffset);
        return hit.collapsed ? null : hit;
    }

    _formattingInlineSource(block, range, kind) {
        const raw = node => node.nodeType === 1 && typeof node.rawText === "function" ? node.rawText(true) : node.textContent || "";
        const source = raw(block), segments = [];
        const append = (start, end) => {
            const last = segments.at(-1);
            if (last?.end === start) last.end = end;
            else segments.push({start, end});
        };
        const visit = (node, offset) => {
            const hit = this._formattingOverlap(node, range);
            if (!hit) return;
            if (node.nodeType === 3) {
                append(offset + (hit.startContainer === node ? hit.startOffset : 0),
                    offset + (hit.endContainer === node ? hit.endOffset : node.textContent.length));
                return;
            }
            if (node.nodeType !== 1 || node.matches(".md-meta,.md-content,mjx-container,script,.md-math-after-sym")) return;
            const inline = node.getAttribute("md-inline");
            if (inline && !["plain","strong","em","del","underline","highlight","html_inline","softbreak","linebreak","escape","html_entity"].includes(inline)) return;
            if (["escape","html_entity"].includes(inline)) {append(offset, offset + raw(node).length); return;}
            if (inline === "html_inline") {
                const before = node.querySelector(":scope > .md-before"), after = node.querySelector(":scope > .md-after");
                const content = Array.from(node.children).find(child => !child.matches(".md-meta,.md-content"));
                if (!before || !after || !content || !/^(SPAN|B|STRONG|I|EM|U|S|MARK)$/.test(content.tagName)
                    || raw(node) !== before.textContent + raw(content) + after.textContent) return;
                visit(content, offset + before.textContent.length); return;
            }
            const children = Array.from(node.childNodes);
            if (children.map(raw).join("") !== raw(node)) return;
            for (const child of children) {visit(child, offset); offset += raw(child).length;}
        };
        visit(block, 0);
        const edits = [];
        for (const segment of segments) {
            const content = source.slice(segment.start, segment.end);
            // Inline syntax never crosses a soft line break or paragraph boundary.
            for (const match of content.matchAll(/[^\r\n]+/g)) {
                const value = match[0], leading = value.match(/^\s*/)[0], trailing = value.match(/\s*$/)[0];
                const inner = value.slice(leading.length, value.length - trailing.length);
                if (!inner) continue;
                const start = segment.start + match.index + leading.length, end = start + inner.length;
                const formatted = kind === "code" ? this._buildInlineCodeSpan(inner) : "$" + inner.replace(/(^|[^\\])\$/g, "$1\\$") + "$";
                edits.push({start, end, text:formatted});
            }
        }
        return this._applyAsciiMathEdits(source, edits);
    }

    _commitFormattingChanges(editor, changes) {
        if (!changes.length) return;
        editor.undo.endSnap(true);
        const cursor = editor.selection.buildUndo(), command = {undo:cursor ? [cursor] : [], redo:[]};
        changes.forEach(({node}) => command.undo.push(editor.undo.buildReplaceUndo(node)));
        editor.brush.pause(true);
        try {
            for (const {node, result, attrs} of changes) {
                if (attrs) Object.entries(attrs).forEach(([key, value]) => node.set(key, value));
                if (result) node.set("text", result.text);
                editor.findElemById(node.cid).replaceWith(editor.MarkParser.renderHtmlWithBlockMeta(node, editor.brush));
                command.redo.push(editor.undo.buildReplaceUndo(node));
                editor.brush.addToQueue(node.cid, true);
            }
            if (cursor) {
                const restored = {...cursor};
                const first = changes.find(c => c.node.cid === (cursor.startId || cursor.id));
                const last = changes.find(c => c.node.cid === (cursor.endId || cursor.id));
                if (first?.result) restored.start = first.result.mapOffset(cursor.start);
                if (last?.result) restored.end = last.result.mapOffset(cursor.end);
                editor.undo.exeCommand(restored); command.redo.push(restored);
            }
        } catch (error) {
            command.undo.slice().reverse().forEach(undo => editor.undo.exeCommand(undo));
            throw error;
        } finally {editor.brush.resume();}
        editor.undo.register(command); editor.refresh(); this._saveSelection(); this._updateToolbarState();
    }

    _formatSelectedInline(editor, selection, kind) {
        const state = this._formattingSelection(editor, selection);
        if (!state || state.range.collapsed) return false;
        if (kind === "math" && window.File?.option?.enableInlineMath === false) {
            this._showToolbarNotice("请先在 Typora 偏好设置中启用行内公式。"); return true;
        }
        const ancestor = state.range.commonAncestorContainer;
        const element = ancestor.nodeType === 1 ? ancestor : ancestor.parentElement;
        if (kind === "math" && element?.closest('[md-inline="inline_math"]') && editor.stylize?.toggleStyle) {
            editor.stylize.toggleStyle("inline_math"); return true;
        }
        try {
            const changes = [];
            for (const block of state.blocks) {
                const sourceBlock = block.matches("td,th") ? block.querySelector(".td-span[cid]") : block;
                const node = sourceBlock && editor.getNode(sourceBlock.getAttribute("cid"));
                if (!node || typeof node.get("text") !== "string" || typeof sourceBlock.rawText !== "function") continue;
                if (sourceBlock.rawText(true) !== node.get("text")) throw new Error("Editor source is not synchronized");
                const result = this._formattingInlineSource(sourceBlock, state.range, kind);
                if (result.count) changes.push({node, result});
            }
            this._commitFormattingChanges(editor, changes);
        } catch (error) {
            console.warn("[EditingToolbar] Inline formatting skipped:", error);
            this._showToolbarNotice("格式转换未完成，请重新选择后重试。");
        }
        return true;
    }

    _formatSelectedHeadings(editor, selection, level) {
        const state = this._formattingSelection(editor, selection);
        if (!state) return false;
        if (!state.blocks.length) return true;
        try {
            const changes = [];
            for (const block of state.blocks.filter(block => block.matches("p,h1,h2,h3,h4,h5,h6"))) {
                const node = editor.getNode(block.getAttribute("cid"));
                if (!node || !["paragraph","heading"].includes(node.get("type"))) continue;
                if (block.rawText(true) !== node.get("text")) throw new Error("Editor source is not synchronized");
                const result = this._headingBlockSource(block);
                if (result.count || node.get("type") !== "heading" || node.get("depth") !== level)
                    changes.push({node, result, attrs:{type:"heading", depth:level, pattern:undefined}});
            }
            this._commitFormattingChanges(editor, changes);
        } catch (error) {
            console.warn("[EditingToolbar] Heading formatting skipped:", error);
            this._showToolbarNotice("标题转换未完成，请重新选择后重试。");
        }
        return true;
    }

    _headingBlockSource(block) {
        const raw = node => node.nodeType === 1 && typeof node.rawText === "function" ? node.rawText(true) : node.textContent || "";
        const source = raw(block), edits = [];
        const visit = (node, offset) => {
            if (node.nodeType !== 1 || node.matches('.md-meta,.md-content,[md-inline="code"],[md-inline="inline_math"],mjx-container')) return;
            // ATX headings cannot contain raw newlines on disk. A soft break
            // remains a visible break in the same heading after reopening.
            if (node.matches('[md-inline="softbreak"],[md-inline="linebreak"]')) {
                edits.push({start:offset, end:offset + raw(node).length, text:"<br>"}); return;
            }
            const children = Array.from(node.childNodes);
            if (children.map(raw).join("") !== raw(node)) return;
            for (const child of children) {visit(child, offset); offset += raw(child).length;}
        };
        visit(block, 0);
        return this._applyAsciiMathEdits(source, edits);
    }

    _formattingPlainText(block, range) {
        const read = node => {
            const hit = this._formattingOverlap(node, range);
            if (!hit) return "";
            if (node.nodeType === 3) return hit.toString();
            if (node.nodeType !== 1 || node.matches(".md-meta,.md-content,mjx-container,.md-math-after-sym,.md-emoji-control-ch")) return "";
            if (node.getAttribute("md-inline") === "inline_math") {
                if (typeof node.rawText === "function") {
                    const source = node.rawText(true);
                    if (source.startsWith("$") && source.endsWith("$")) return source.slice(1, -1);
                }
                const source = node.querySelector('script[type="math/tex"],.md-tex');
                return source?.textContent || node.getAttribute("data-math") || "";
            }
            if (node.tagName === "BR" || node.getAttribute("md-inline") === "br") return "\n";
            if (node.matches("img,.md-image,video,audio")) throw new Error("Selection contains media");
            return Array.from(node.childNodes, read).join("");
        };
        return read(block);
    }

    _formatSelectedCodeBlock(editor, selection, type) {
        const state = this._formattingSelection(editor, selection);
        if (!state || state.range.collapsed) return false;
        const blocks = state.blocks;
        if (!blocks.length) return true;
        // A block conversion may replace a continuous run of textual paragraphs,
        // never a table, alert marker, or an intervening embedded editor.
        const parent = blocks[0].parentElement;
        if (blocks.length !== this._getAlignmentBlocks(state.range).length
            || !blocks.every(block => block.matches("p,h1,h2,h3,h4,h5,h6") && block.parentElement === parent)
            || blocks.some((block, index) => index && blocks[index-1].nextElementSibling !== block)) {
            this._showToolbarNotice("请在同一正文或引用中选择连续段落，再转换为代码块或公式块。"); return true;
        }
        let text;
        try {text = blocks.map(block => this._formattingPlainText(block, state.range)).join("\n\n");}
        catch (error) {this._showToolbarNotice("选区包含图片等内容，请只选择要转换的文字。"); return true;}
        if (!text.trim()) return true;
        if (type === "math_block") {
            const lines = text.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
            if (!/\\begin\{/.test(text)) text = lines.length > 1 ? "\\begin{gathered}\n" + lines.join(" \\\\\n") + "\n\\end{gathered}" : lines[0];
        }
        const alignments = [blocks[0], blocks.at(-1)].map((block, index) => {
            const boundary = index ? state.range.endContainer : state.range.startContainer;
            if (!block.contains(boundary)) return null;
            const remainder = document.createRange(); remainder.selectNodeContents(block);
            if (index) remainder.setStart(boundary, state.range.endOffset);
            else remainder.setEnd(boundary, state.range.startOffset);
            let hasRemainder = true;
            try {hasRemainder = Boolean(this._formattingPlainText(block, remainder).trim());} catch (_) { /* Unselected media remains in its paragraph. */ }
            if (!hasRemainder) return null;
            return Array.from(block.querySelectorAll('[md-inline="html_inline"]')).some(element => this._alignmentTag(element)) ? this._getBlockLayout(block) : null;
        });
        editor.undo.endSnap(true);
        const commands = [], register = editor.undo.register;
        editor.undo.register = command => {if (command) commands.push(command);};
        try {
            // These spans are layout metadata, not code/LaTeX. Removing them
            // through mapped model edits also fixes the selection's end offset.
            this._saveSelection(selection);
            const cleanChanges = [];
            for (const block of blocks) {
                const sourceNode = editor.getNode(block.getAttribute("cid"));
                if (!sourceNode || block.rawText(true) !== sourceNode.get("text")) throw new Error("Editor source is not synchronized");
                const result = this._alignedBlockSource(block, null);
                if (result.text !== sourceNode.get("text")) cleanChanges.push({node:sourceNode, result});
            }
            this._commitFormattingChanges(editor, cleanChanges); this._restoreSelection(editor);
            const node = editor.stylize.insertBlock(type);
            if (!node || node.get("type") !== type) throw new Error("Block insertion failed");
            const command = {undo:[editor.undo.buildReplaceUndo(node)], redo:[]};
            const cm = type === "fences" ? editor.fences : editor.mathBlock;
            cm.beforeDeleteFences(node);
            node.set("text", text);
            editor.findElemById(node.cid).replaceWith(editor.MarkParser.renderHtmlWithBlockMeta(node, editor.brush));
            command.redo.push(editor.undo.buildReplaceUndo(node));
            const cursor = {type:"cursor", id:node.cid, start:0, end:0};
            editor.undo.exeCommand(cursor); command.redo.push(cursor); commands.push(command);
            // When the selection begins/ends inside a paragraph, its remaining
            // prefix/suffix keeps the original paragraph alignment.
            const remainders = [node.get("before"), node.get("after")], restoreAlignment = [];
            remainders.forEach((remainder, index) => {
                if (!remainder || !alignments[index] || !["paragraph","heading"].includes(remainder.get("type"))) return;
                const element = editor.findElemById(remainder.cid)?.[0];
                if (element && remainder.get("text")?.trim()) restoreAlignment.push({node:remainder, result:this._alignedBlockSource(element, alignments[index].alignment, alignments[index].indent)});
            });
            this._commitFormattingChanges(editor, restoreAlignment);
        } catch (error) {
            commands.slice().reverse().forEach(command => command.undo.slice().reverse().forEach(undo => editor.undo.exeCommand(undo)));
            console.warn("[EditingToolbar] Block formatting rolled back:", error);
            this._showToolbarNotice("块转换未完成，已恢复原文。"); return true;
        } finally {editor.undo.register = register;}
        if (commands.length) register.call(editor.undo, {undo:commands.flatMap(command => command.undo || []), redo:commands.flatMap(command => command.redo || [])});
        editor.refresh(); this._saveSelection(); this._updateToolbarState();
        return true;
    }

    _changeHeading(level) {
        this._withEditorSelection((editor, selection) => {
            if (this._formatSelectedHeadings(editor, selection, level)) return;
            if (editor?.stylize?.changeBlock) {
                editor.stylize.changeBlock(`header${level}`);
            }
        });
    }

    _toggleQuote() {
        this._withEditorSelection((editor) => {
            if (editor?.stylize?.toggleIndent) {
                editor.stylize.toggleIndent("blockquote");
                return;
            }
            if (editor?.stylize?.changeBlock) {
                editor.stylize.changeBlock("blockquote");
            }
        });
    }

    _changeBlock(style) {
        this._withEditorSelection((editor) => {
            if (editor?.stylize?.changeBlock) {
                editor.stylize.changeBlock(style);
            }
        });
    }

    _changeListStyle(style) {
        this._withEditorSelection((editor) => {
            if (editor?.stylize?.toggleIndent) {
                try {
                    editor.stylize.toggleIndent(style);
                    return;
                } catch (error) {
                    console.warn(`[EditingToolbar] Native list ${style} failed:`, error);
                }
            }

            const selection = window.getSelection();
            const rawText = String(this._getSelectionText(selection) || this.lastSelectionText || "");
            const normalized = rawText.replace(/\r\n?/g, "\n");

            if (!normalized.trim()) {
                this._replaceSelectionWithText(editor, style === "ol" ? "1. " : "- ");
                return;
            }

            let order = 1;
            const formatted = normalized
                .split("\n")
                .map((line) => {
                    if (!line.trim()) {
                        return "";
                    }

                    const leading = (line.match(/^\s*/) || [""])[0];
                    const content = line
                        .slice(leading.length)
                        .replace(/^(?:[-+*]\s+|\d+\.\s+)/, "");

                    if (style === "ol") {
                        return `${leading}${order++}. ${content}`;
                    }
                    return `${leading}- ${content}`;
                })
                .join("\n");

            this._replaceSelectionWithText(editor, formatted);
        });
    }

    _changeIndent(increase) {
        this._withEditorSelection((editor, selection) => {
            const state = this._formattingSelection(editor, selection);
            if (!state || !state.blocks.length) return;
            const lists = state.blocks.map(block => block.closest("li"));
            if (lists.every(Boolean)) {
                // List indentation means changing nesting, not adding visual
                // padding to the item text. Never fall back to DOM-only edits.
                const command = editor.UserOp?.[increase ? "moreIndent" : "lessIndent"];
                if (typeof command !== "function") return;
                const before = editor.getMarkdown();
                try {
                    command.call(editor.UserOp, editor); editor.store(); this._saveSelection();
                    if (editor.getMarkdown() === before) this._showToolbarNotice(increase ? "这些列表项无法继续增加层级，请选择有前一项的列表项。" : "这些列表项已没有可减少的层级。");
                } catch (error) {console.warn("[EditingToolbar] List indentation skipped:", error);this._showToolbarNotice("列表缩进未完成，请重新选择同一列表中的项目。");}
                return;
            }
            if (lists.some(Boolean) || state.blocks.some(block => !block.matches("p,h1,h2,h3,h4,h5,h6"))) {
                this._showToolbarNotice("请分开选择正文段落、列表或表格，再调整缩进。");return;
            }
            const changes = [];
            try {
                for (const block of state.blocks) {
                    const node = editor.getNode(block.getAttribute("cid"));
                    if (!node || typeof node.get("text") !== "string" || block.rawText(true) !== node.get("text")) throw new Error("Editor source is not synchronized");
                    const layout = this._getBlockLayout(block);
                    const indent = Math.max(0, Math.min(12, layout.indent + (increase ? 1 : -1)));
                    if (indent === layout.indent) continue;
                    const result = this._alignedBlockSource(block, layout.alignment, indent);
                    if (result.text !== node.get("text")) changes.push({node,result});
                }
                this._commitFormattingChanges(editor, changes);
                if (!changes.length && increase) this._showToolbarNotice("段落已达到最大缩进级别。");
            } catch (error) {console.warn("[EditingToolbar] Paragraph indentation skipped:",error);this._showToolbarNotice("段落缩进未完成，请重新选择后重试。");}
        });
    }

    _getBlockLayout(block) {
        const root = block.matches("td,th") ? block.querySelector(".td-span") : block;
        const layout = {alignment:null,indent:0};
        let node = root, foundIndent = false;
        for (let depth=0; node && depth<16; depth++) {
            const children = Array.from(node.childNodes).filter(child => child.nodeType===1 ? !child.matches(".md-meta,.md-content") : Boolean(child.textContent.trim()));
            if (children.length!==1 || children[0].nodeType!==1) break;
            const info = this._alignmentTag(children[0]);
            if (info) {
                if (!layout.alignment && ["left","center","right","justify"].includes(info.tag.style.textAlign)) layout.alignment=info.tag.style.textAlign;
                if (!foundIndent && info.indent) {layout.indent=info.indent;foundIndent=true;}
                node=info.content;
            } else node=children[0];
        }
        return layout;
    }


    _insertCodeBlock() {
        this._withEditorSelection((editor, selection) => {
            if (this._formatSelectedCodeBlock(editor, selection, "fences")) return;
            if (editor?.stylize?.insertBlock) {
                editor.stylize.insertBlock("fences");
                return;
            }
            this._pasteText("\n```\n\n```\n");
        });
    }

    _toggleInlineMath() {
        this._withEditorSelection((editor, selection) => {
            if (this._formatSelectedInline(editor, selection, "math")) return;
            if (editor?.stylize?.toggleStyle) {
                editor.stylize.toggleStyle("inline_math");
                return;
            }

            if (this._selectionHasText(selection)) {
                const text = String(this._getSelectionText(selection) || "");
                this._replaceSelectionWithText(editor, `$${text}$`);
                return;
            }

            this._insertTextAtCaret("$$", 1);
        });
    }

    _convertSelectionAsciiToMath() {
        this._withEditorSelection((editor, selection) => {
            if (!editor?.undo?.buildReplaceUndo || !editor.MarkParser?.renderHtmlWithBlockMeta
                || editor.sourceView?.inSourceMode || editor.isIME || window.File?.isLocked || window.File?.bundle?.isLocked) return;
            const range = this._resolveRange(selection);
            if (!range || range.collapsed || !this._selectionInEditor(range)) {
                this._showToolbarNotice("请先选择要转换的文字，可以跨多个段落。"); return;
            }
            if (window.File?.option?.enableInlineMath === false) {
                this._showToolbarNotice("请先在 Typora 偏好设置中启用行内公式，再转换字母数字。"); return;
            }
            // Commit pending typing before comparing the rendered source with the model.
            editor.store();
            const changes = [];
            try {
                for (const block of this._getAlignmentBlocks(range)) {
                    if (block.querySelector('[md-inline="alert_text"]')) continue;
                    const sourceBlock = block.matches("td,th") ? block.querySelector(".td-span[cid]") : block;
                    const node = sourceBlock && editor.getNode(sourceBlock.getAttribute("cid"));
                    if (!node || typeof node.get("text") !== "string" || typeof sourceBlock.rawText !== "function") continue;
                    const source = node.get("text");
                    if (sourceBlock.rawText(true) !== source) throw new Error("Editor source is not synchronized");
                    const result = this._asciiMathBlockSource(sourceBlock, range);
                    if (result.count) changes.push({node,result});
                }
            } catch (error) {
                console.warn("[EditingToolbar] Math conversion skipped:", error);
                this._showToolbarNotice("段落仍在更新，请重新选择后转换。"); return;
            }
            if (!changes.length) {
                this._showToolbarNotice("选区中没有可转换的普通字母数字；已有公式、代码和链接会保留。"); return;
            }
            editor.undo.endSnap(true);
            const cursor = editor.selection.buildUndo();
            const command = {undo:cursor ? [cursor] : [],redo:[]};
            for (const {node} of changes) command.undo.push(editor.undo.buildReplaceUndo(node));
            editor.brush.pause(true);
            try {
                for (const {node,result} of changes) {
                    node.set("text",result.text);
                    editor.findElemById(node.cid).replaceWith(editor.MarkParser.renderHtmlWithBlockMeta(node,editor.brush));
                    command.redo.push(editor.undo.buildReplaceUndo(node));
                    editor.brush.addToQueue(node.cid,true);
                }
                if (cursor) {
                    const restored = {...cursor};
                    const first = changes.find(change => change.node.cid === (cursor.startId || cursor.id));
                    const last = changes.find(change => change.node.cid === (cursor.endId || cursor.id));
                    if (first) restored.start = first.result.mapOffset(cursor.start);
                    if (last) restored.end = last.result.mapOffset(cursor.end);
                    editor.undo.exeCommand(restored); command.redo.push(restored);
                }
            } catch (error) {
                command.undo.slice().reverse().forEach(undo => editor.undo.exeCommand(undo));
                console.error("[EditingToolbar] Math conversion rolled back:",error);
                this._showToolbarNotice("转换未完成，已恢复原文。"); return;
            } finally {editor.brush.resume();}
            editor.undo.register(command); editor.refresh(); this._saveSelection(); this._updateToolbarState();
            this._showToolbarNotice(`已转换 ${changes.length} 个段落中的 ${changes.reduce((sum,change) => sum+change.result.count,0)} 处字母数字，可一次撤销。`);
        });
    }

    _asciiMathTextEdits(text, from = 0, to = text.length) {
        // Leave opaque destinations intact even when they occur as plain text.
        const protectedRanges = [];
        const opaque = /(?:https?:\/\/|www\.)[^\s<>\u3400-\u9fff，。；！？]+|[A-Za-z]:[\\/][^\s<>\u3400-\u9fff，。；！？]+|[A-Za-z0-9_.+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}|\b[A-Za-z0-9_.-]+\.(?:png|jpe?g|gif|svg|webp|pdf|md|csv|xlsx?|docx?|pptx?|py|js|json|exe)\b|\$[^$\n]+\$/gi;
        let match;
        while ((match = opaque.exec(text))) protectedRanges.push({start:match.index,end:match.index+match[0].length});
        const pattern = /[A-Za-z0-9]+(?:[._:+\-\/][A-Za-z0-9]+)*/g;
        const edits = []; let protectedIndex = 0;
        while ((match = pattern.exec(text))) {
            const tokenStart = match.index, tokenEnd = tokenStart + match[0].length;
            while (protectedIndex < protectedRanges.length && protectedRanges[protectedIndex].end <= tokenStart) protectedIndex++;
            if (protectedRanges[protectedIndex]?.start < tokenEnd) continue;
            const start = Math.max(from,tokenStart), end = Math.min(to,tokenEnd);
            if (start >= end || !/[A-Za-z0-9]/.test(text.slice(start,end))) continue;
            // Padding is outside $...$, never inside a Markdown delimiter.
            const left = start > 0 && !/\s/.test(text[start-1]) ? " " : "";
            const right = end < text.length && !/\s/.test(text[end]) ? " " : "";
            edits.push({start,end,text:left+"$"+text.slice(start,end)+"$"+right});
        }
        return edits;
    }

    _asciiMathBlockSource(block, range) {
        const raw = node => node.nodeType === 1 && typeof node.rawText === "function" ? node.rawText(true) : node.textContent || "";
        const source = raw(block), edits = [];
        const overlap = node => {
            const bounds = document.createRange(); bounds.selectNodeContents(node);
            if (range.compareBoundaryPoints(1,bounds) <= 0 || range.compareBoundaryPoints(3,bounds) >= 0) return null;
            if (range.compareBoundaryPoints(0,bounds) > 0) bounds.setStart(range.startContainer,range.startOffset);
            if (range.compareBoundaryPoints(2,bounds) < 0) bounds.setEnd(range.endContainer,range.endOffset);
            return bounds.collapsed ? null : bounds;
        };
        const visit = (node,offset) => {
            if (!overlap(node)) return;
            if (node.nodeType === 3) {
                const hit = overlap(node), text = node.textContent || "";
                const start = hit.startContainer === node ? hit.startOffset : 0;
                const end = hit.endContainer === node ? hit.endOffset : text.length;
                for (const edit of this._asciiMathTextEdits(text,start,end)) edits.push({...edit,start:offset+edit.start,end:offset+edit.end});
                return;
            }
            if (node.nodeType !== 1 || node.matches(".md-meta,.md-content,mjx-container,script,.md-math-after-sym,.md-emoji-control-ch")) return;
            const inline = node.getAttribute("md-inline");
            // Formula/code/link/image/alert markup is atomic. Never convert its
            // previews, syntax, paths or hidden metadata into another formula.
            if (inline && !["plain","strong","em","del","underline","highlight","html_inline"].includes(inline)) return;
            if (inline === "html_inline") {
                const before = node.querySelector(":scope > .md-before"), after = node.querySelector(":scope > .md-after");
                const content = Array.from(node.children).find(child => !child.matches(".md-meta,.md-content"));
                if (!content || !before || !after || !/^(SPAN|B|STRONG|I|EM|U|S|MARK)$/.test(content.tagName)) return;
                if (raw(node) !== before.textContent + raw(content) + after.textContent) return;
                visit(content,offset+before.textContent.length); return;
            }
            const children = Array.from(node.childNodes);
            // A mismatched renderer is opaque; offset guesses could damage source.
            if (children.map(raw).join("") !== raw(node)) return;
            for (const child of children) {visit(child,offset); offset += raw(child).length;}
        };
        visit(block,0);
        return this._applyAsciiMathEdits(source,edits);
    }

    _applyAsciiMathEdits(source, edits) {
        let text = "", position = 0;
        for (const edit of edits) {
            if (edit.start < position) throw new Error("Overlapping math conversion edits");
            text += source.slice(position,edit.start) + edit.text; position = edit.end;
        }
        text += source.slice(position);
        const mapOffset = offset => {
            let delta = 0;
            for (const edit of edits) {
                if (offset < edit.start) break;
                if (offset < edit.end) return edit.start+delta+(offset-edit.start);
                delta += edit.text.length-(edit.end-edit.start);
            }
            return offset+delta;
        };
        return {text,mapOffset,count:edits.length};
    }

    _wrapAsciiSegmentsWithInlineMath(text) {
        // Retained for existing callers; document conversion uses the source tree.
        return String(text || "").replace(/\r\n?/g,"\n").split("\n").map(line => this._wrapAsciiLineWithInlineMath(line)).join("\n");
    }

    _wrapAsciiLineWithInlineMath(line) {
        return this._applyAsciiMathEdits(line,this._asciiMathTextEdits(line)).text;
    }


    _toggleMathBlock() {
        this._withEditorSelection((editor, selection) => {
            if (this._formatSelectedCodeBlock(editor, selection, "math_block")) return;
            if (editor?.stylize?.toggleMathBlock) {
                editor.stylize.toggleMathBlock();
                return;
            }

            this._insertTextAtCaret("$$\n\n$$", 2);
        });
    }

    _insertHorizontalRule() {
        this._withEditorSelection((editor) => {
            if (editor?.stylize?.insertBlock) {
                editor.stylize.insertBlock("hr");
                return;
            }
            this._pasteText("\n---\n");
        });
    }

    _getAlignmentBlocks(range) {
        const writeEl = document.getElementById("write");
        if (!writeEl || !range
            || !writeEl.contains(range.startContainer)
            || !writeEl.contains(range.endContainer)) return [];

        const selector = "p, h1, h2, h3, h4, h5, h6, li, td, th";
        const excluded = "pre, .md-fences, .md-math-block, .md-htmlblock, .md-toc";
        // Only leaf paragraphs/cells: never align #write, an arbitrary div,
        // a whole quote, or a list item that contains other paragraphs/items.
        const blocks = Array.from(writeEl.querySelectorAll(selector)).filter((block) =>
            !block.closest(excluded) && !block.querySelector(selector)
        );

        if (range.collapsed) {
            let node = range.startContainer;
            if (node.nodeType === 1 && node === writeEl) {
                node = node.childNodes[range.startOffset] || node.lastChild;
            }
            const element = node?.nodeType === 1 ? node : node?.parentElement;
            const block = element?.closest(selector);
            return block && blocks.includes(block) ? [block] : [];
        }

        const start = range.cloneRange();
        const end = range.cloneRange();
        start.collapse(true);
        end.collapse(false);
        return blocks.filter((block) => {
            const blockStart = document.createRange();
            blockStart.selectNodeContents(block);
            const blockEnd = blockStart.cloneRange();
            blockStart.collapse(true);
            blockEnd.collapse(false);
            // Strict overlap excludes a paragraph when the selection ends
            // at its first character (or starts at the previous one's end).
            if (start.compareBoundaryPoints(Range.START_TO_START, blockEnd) >= 0
                || end.compareBoundaryPoints(Range.START_TO_START, blockStart) <= 0) return false;

            const overlap = document.createRange();
            overlap.selectNodeContents(block);
            if (start.compareBoundaryPoints(Range.START_TO_START, blockStart) > 0) {
                overlap.setStart(range.startContainer, range.startOffset);
            }
            if (end.compareBoundaryPoints(Range.START_TO_START, blockEnd) < 0) {
                overlap.setEnd(range.endContainer, range.endOffset);
            }
            // A text-node offset of zero and its parent's offset of zero
            // compare differently in DOM Range, despite containing no text.
            const fragment = overlap.cloneContents();
            return Boolean(fragment.textContent.length
                || fragment.querySelector("img, video, audio, svg, br, .md-image"));
        });
    }

    _alignmentTag(element) {
        if (element?.getAttribute?.("md-inline") !== "html_inline") return null;
        const before = element.querySelector(":scope > .md-before");
        const after = element.querySelector(":scope > .md-after");
        const content = Array.from(element.children).find(child => !child.matches(".md-meta,.md-content"));
        if (!before || !after || !content || !/^<span\s/i.test(before.textContent)) return null;
        const template = document.createElement("template");
        template.innerHTML = before.textContent + after.textContent;
        const tag = template.content.firstElementChild;
        if (tag?.tagName !== "SPAN" || tag.style.display !== "inline-block" || tag.style.width !== "100%") return null;
        const level = tag.getAttribute("data-et-indent"), indent = /^(?:[1-9]|1[0-2])$/.test(level || "") && tag.style.paddingLeft === (Number(level)*2)+"em" && tag.style.boxSizing === "border-box" ? Number(level) : 0;
        if (!indent && !["left", "center", "right", "justify"].includes(tag.style.textAlign)) return null;
        return {before, after, content, tag, indent};
    }

    _getBlockAlignment(block) {
        return this._getBlockLayout(block).alignment || getComputedStyle(block).textAlign;
    }

    _alignedBlockSource(block, alignment, indent = alignment === null ? 0 : this._getBlockLayout(block).indent) {
        indent = Math.max(0,Math.min(12,Math.trunc(indent)||0));
        const raw = node => node.nodeType === 1 && typeof node.rawText === "function" ? node.rawText(true) : node.textContent || "";
        const source = raw(block);
        const edits = [];
        const visit = (element, offset) => {
            if (element.nodeType !== 1) return;
            const info = this._alignmentTag(element);
            if (info) {
                const {before, after, content, tag} = info;
                const opening = before.textContent, closing = after.textContent, inner = raw(content);
                if (raw(element) !== opening + inner + closing) throw new Error("Unrecognized alignment source");
                // Remove only layout properties; retain independent colors,
                // font sizes and any other source attributes on this wrapper.
                ["display", "width", "text-align", "text-indent"].forEach(key => tag.style.removeProperty(key));
                if (info.indent) {tag.style.removeProperty("padding-left");tag.style.removeProperty("box-sizing");tag.removeAttribute("data-et-indent");}
                if (!tag.getAttribute("style")?.trim()) tag.removeAttribute("style");
                const keep = tag.attributes.length > 0;
                const open = keep ? tag.outerHTML.slice(0, tag.outerHTML.indexOf(">") + 1) : "";
                edits.push({start:offset, end:offset + opening.length, text:open});
                visit(content, offset + opening.length);
                edits.push({start:offset + opening.length + inner.length, end:offset + raw(element).length, text:keep ? closing : ""});
                return;
            }
            // Raw math/code/HTML syntax is opaque. Never reinterpret lookalike
            // <span> strings in code, URLs, hidden metadata or LaTeX.
            if (element.matches(".md-meta,.md-content,[md-inline='code'],[md-inline='inline_math'],mjx-container")) return;
            const children = Array.from(element.childNodes);
            if (children.map(raw).join("") !== raw(element)) return;
            for (const child of children) {visit(child, offset); offset += raw(child).length;}
        };
        visit(block, 0);
        edits.sort((a,b) => a.start - b.start);
        let cleaned = "", position = 0;
        for (const edit of edits) {
            if (edit.start < position) throw new Error("Overlapping alignment source edits");
            cleaned += source.slice(position, edit.start) + edit.text;
            position = edit.end;
        }
        cleaned += source.slice(position);
        const opening = alignment || indent ? `<span${indent ? ` data-et-indent="${indent}"` : ""} style="display:inline-block;width:100%;${alignment ? `text-align:${alignment};text-indent:0;` : ""}${indent ? `box-sizing:border-box;padding-left:${indent*2}em;` : ""}">` : "";
        const mapOffset = offset => {
            let delta = 0;
            for (const edit of edits) {
                if (offset < edit.start) break;
                if (offset <= edit.end) return opening.length + edit.start + delta + Math.min(offset - edit.start, edit.text.length);
                delta += edit.text.length - (edit.end - edit.start);
            }
            return opening.length + offset + delta;
        };
        return {text: opening + cleaned + (opening ? "</span>" : ""), mapOffset};
    }

    _setAlignment(alignment, indent) {
        if (alignment !== null && !["left", "center", "right", "justify"].includes(alignment)) return;
        this._withEditorSelection((editor, selection) => {
            if (!editor?.undo?.buildReplaceUndo || !editor.MarkParser?.renderHtmlWithBlockMeta
                || editor.sourceView?.inSourceMode || window.File?.isLocked || window.File?.bundle?.isLocked) return;
            const range = this._resolveRange(selection);
            const blocks = this._getAlignmentBlocks(range);
            const changes = [];
            try {
                for (const block of blocks) {
                    // The [!NOTE] marker is structural Markdown, not body text.
                    if (block.querySelector('[md-inline="alert_text"]')) continue;
                    const sourceBlock = block.matches("td,th") ? block.querySelector(".td-span[cid]") : block;
                    const node = sourceBlock && editor.getNode(sourceBlock.getAttribute("cid"));
                    if (!node || typeof sourceBlock.rawText !== "function" || typeof node.get("text") !== "string") continue;
                    const source = node.get("text");
                    if (!source.trim()) continue;
                    if (sourceBlock.rawText(true) !== source) throw new Error("Editor source is not synchronized");
                    const result = this._alignedBlockSource(sourceBlock, alignment, indent);
                    changes.push({node, result, changed:result.text !== source});
                }
            } catch (error) {
                console.warn("[EditingToolbar] Alignment skipped:", error);
                this._showToolbarNotice("段落仍在更新，请重新选择后设置对齐。");
                return;
            }
            if (!changes.some(change => change.changed)) return;
            editor.undo.endSnap(true);
            const cursor = editor.selection.buildUndo();
            const command = {undo:cursor ? [cursor] : [], redo:[]};
            for (const change of changes.filter(change => change.changed)) command.undo.push(editor.undo.buildReplaceUndo(change.node));
            editor.brush.pause(true);
            try {
                for (const {node, result, changed} of changes) {
                    if (!changed) continue;
                    node.set("text", result.text);
                    editor.findElemById(node.cid).replaceWith(editor.MarkParser.renderHtmlWithBlockMeta(node, editor.brush));
                    command.redo.push(editor.undo.buildReplaceUndo(node));
                    editor.brush.addToQueue(node.cid, true);
                }
                if (cursor) {
                    const restored = {...cursor};
                    const startId = cursor.startId || cursor.id, endId = cursor.endId || cursor.id;
                    const first = changes.find(change => change.node.cid === startId && change.changed);
                    const last = changes.find(change => change.node.cid === endId && change.changed);
                    if (first) restored.start = first.result.mapOffset(cursor.start);
                    if (last) restored.end = last.result.mapOffset(cursor.end);
                    editor.undo.exeCommand(restored);
                    command.redo.push(restored);
                }
            } catch (error) {
                command.undo.slice().reverse().forEach(undo => editor.undo.exeCommand(undo));
                console.error("[EditingToolbar] Alignment rolled back:", error);
                this._showToolbarNotice("对齐未完成，已恢复原文。");
                return;
            } finally {editor.brush.resume();}
            editor.undo.register(command);
            editor.refresh();
            this._saveSelection();
            this._updateToolbarState();
        });
    }

    _bindAlignedParagraphEditing() {
        if (this.alignedEditingBound) return;
        this.alignedEditingBound = true;
        const finish = () => this._finishAlignedParagraphEdit();
        window.addEventListener("keydown", event => {
            if (this.alignedEdit) finish();
            if (!["Enter", "Backspace", "Delete"].includes(event.key) || event.ctrlKey || event.altKey || event.metaKey || event.isComposing) return;
            const editor = this._getEditor();
            if (this.settingsDialog || editor?.sourceView?.inSourceMode || editor?.isIME || window.File?.isLocked) return;
            const range = this._resolveRange(window.getSelection());
            if (!this._selectionInEditor(range) || !document.getElementById("write").contains(event.target)) return;
            const blocks = this._getAlignmentBlocks(range);
            if (!blocks.length || !blocks.every(block => block.matches("p,h1,h2,h3,h4,h5,h6"))) return;
            const block = blocks[0];
            const {alignment,indent} = this._getBlockLayout(block);
            if (!alignment && !indent) return;
            editor.undo.endSnap(true);
            const state = {editor, cid:block.getAttribute("cid"), alignment, indent, commands:[], register:editor.undo.register};
            this.alignedEdit = state;
            // Let Typora perform its normal paragraph/list/heading split on
            // plain Markdown, then restore layout. Group these synchronous
            // edits into one native undo command instead of several steps.
            editor.undo.register = command => {if (command) state.commands.push(command);};
            try {this._saveSelection(); this._setAlignment(null);}
            catch (error) {finish(); console.warn("[EditingToolbar] Paragraph edit setup:",error);}
            state.timer = setTimeout(finish, 1200);
        }, true);
        window.addEventListener("keyup", event => {if (["Enter", "Backspace", "Delete"].includes(event.key)) finish();}, true);
        window.addEventListener("blur", finish);
    }

    _finishAlignedParagraphEdit() {
        const state = this.alignedEdit;
        if (!state) return;
        this.alignedEdit = null;
        clearTimeout(state.timer);
        const {editor, commands, register, cid, alignment, indent} = state;
        try {
            const cursor = editor.selection.buildUndo();
            const current = editor.selection.getRangy();
            const last = current && this._getAlignmentBlocks(current).at(-1);
            const first = editor.findElemById(cid)?.[0] || last;
            if (first && last && document.getElementById("write").contains(first)) {
                const range = document.createRange();
                range.setStart(first,0);range.setEnd(last,last.childNodes.length);
                const targets = this._getAlignmentBlocks(range);
                const restored = cursor && {...cursor};
                if (restored) {
                    for (const block of targets) {
                        if (!block.rawText(true).trim()) continue;
                        const map = this._alignedBlockSource(block,alignment,indent).mapOffset;
                        if (block.getAttribute("cid") === (cursor.startId || cursor.id)) restored.start = map(cursor.start);
                        if (block.getAttribute("cid") === (cursor.endId || cursor.id)) restored.end = map(cursor.end);
                    }
                }
                const selection = window.getSelection();selection.removeAllRanges();selection.addRange(range);
                this._saveSelection();this._setAlignment(alignment,indent);
                if (restored) {editor.undo.exeCommand(restored);commands.push({undo:[],redo:[restored]});}
            }
        } catch (error) {console.warn("[EditingToolbar] Paragraph layout restoration:",error);}
        finally {
            editor.undo.register = register;
            if (commands.length) register.call(editor.undo, {
                undo:commands.flatMap(command => command.undo || []),
                redo:commands.flatMap(command => command.redo || [])
            });
            this._saveSelection();this._updateToolbarState();
        }
    }

    _clearFormat() {
        this._withEditorSelection((editor) => {
            if (editor?.stylize?.clearStyle) {
                editor.stylize.clearStyle();
                return;
            }
            document.execCommand("removeFormat", false, null);
        });
    }

    _insertTable() {
        this._withEditorSelection((editor) => {
            if (editor?.tableEdit?.insertTable) {
                editor.tableEdit.insertTable();
                return;
            }
            this._pasteText("\n| 列1 | 列2 | 列3 |\n| --- | --- | --- |\n| 内容 | 内容 | 内容 |\n");
        });
    }

    _insertLinkReference() {
        this._withEditorSelection((editor) => {
            if (editor?.stylize?.insertBlock) {
                editor.stylize.insertBlock("def_link");
                return;
            }
            this._pasteText("\n[ref]: https://example.com \"title\"\n");
        });
    }

    _insertFootnote() {
        this._withEditorSelection((editor) => {
            if (editor?.stylize?.insertBlock) {
                editor.stylize.insertBlock("def_footnote");
                return;
            }
            this._pasteText("[^1]\n\n[^1]: ");
        });
    }

    _insertEmoji(emoji) {
        if (!emoji) return;

        this._withEditorSelection((editor, selection) => {
            const selectedText = String(this._getSelectionText(selection) || "")
                .replace(/\r\n?/g, "\n")
                .trim();

            if (selectedText) {
                this._replaceSelectionWithText(editor, `${emoji} ${selectedText}`);
                return;
            }

            this._replaceSelectionWithText(editor, `${emoji} `);
        });
    }

    _insertWarningBlock(kind = "warning") {
        const kinds = ["note", "tip", "important", "warning", "caution"];
        if (!kinds.includes(kind)) kind = "warning";
        this._withEditorSelection((editor, selection) => {
            if (!editor || window.File?.isLocked || editor.sourceView?.inSourceMode) return;
            const range = this._resolveRange(selection);
            if (!this._selectionInEditor(range)) {
                this._showToolbarNotice("请先将光标放入正文，再插入警告框。");
                return;
            }
            const elementOf = node => node.nodeType === 1 ? node : node.parentElement;
            const firstQuote = elementOf(range.startContainer)?.closest('[mdtype="blockquote"]');
            const lastQuote = elementOf(range.endContainer)?.closest('[mdtype="blockquote"]');
            if (firstQuote && firstQuote === lastQuote) {
                // Typora 1.13.6 toggleIndent's alert branch dereferences a null
                // end node for a single-paragraph quote. Replace the containing
                // quote through native model snapshots, keeping all descendants.
                const quote = editor.getNode(firstQuote.getAttribute("cid"));
                const Model = quote?.constructor;
                if (!quote || !editor.undo?.buildReplaceUndo || !Model) return;
                if (quote.get("alert") === kind) return;
                editor.undo.endSnap(true);
                editor.store();
                const cursor = editor.selection.buildUndo();
                const command = {undo:[], redo:[]};
                if (cursor) command.undo.push(cursor);
                command.undo.push(editor.undo.buildReplaceUndo(quote));
                editor.brush.pause(true);
                try {
                    const header = quote.getFirstChild();
                    if (quote.get("alert") && header && /^\s*\[![a-z]+\]/i.test(header.get("text") || "")) {
                        header.set("text", header.get("text").replace(/\[![a-z]+\]/i, "[!" + kind.toUpperCase() + "]"));
                    } else {
                        quote.prependChild(new Model({type:"paragraph", text:"[!" + kind.toUpperCase() + "]"}));
                    }
                    quote.set("alert", kind);
                    editor.findElemById(quote.cid).replaceWith(quote.toHTML());
                    command.redo.push(editor.undo.buildReplaceUndo(quote));
                    if (cursor) command.redo.push(cursor);
                    editor.undo.register(command);
                    editor.quickRefresh();
                    if (cursor) editor.undo.exeCommand(cursor);
                } finally { editor.brush.resume(); }
                editor.refocus();
                this._saveSelection();
                return;
            }
            // The native alert overload also fails when a selection starts in
            // an existing alert and ends outside it. Wrap model siblings with
            // Typora's own wrap/insert undo primitives, preserving their trees.
            const blocks = this._getAlignmentBlocks(range);
            const first = blocks[0]?.closest("[cid]");
            const last = blocks[blocks.length - 1]?.closest("[cid]");
            const firstNode = first && editor.getNode(first.getAttribute("cid"));
            const lastNode = last && editor.getNode(last.getAttribute("cid"));
            const Model = firstNode?.constructor;
            const Undo = editor.undo?.constructor;
            if (!lastNode || !Model?.wrap || !Model?.getTreePosition || !Undo?.addUndoForWrap || !Undo?.addUndoForInsert) {
                this._showToolbarNotice("请在正文段落中插入警告框。");
                return;
            }
            const position = Model.getTreePosition(firstNode, lastNode);
            // List items and table cells are virtual nodes, not legal quote
            // siblings. Promote to their containing block like Typora does.
            const start = position[1]?.getClosetBlock(), end = position[2]?.getClosetBlock();
            if (!start || !end || start.get("parent") !== end.get("parent")) return;
            editor.undo.endSnap(true);
            editor.store();
            const cursor = editor.selection.buildUndo();
            const command = {undo: cursor ? [cursor] : [], redo: []};
            editor.brush.pause(true);
            try {
                const quote = new Model({type:"blockquote", alert:kind});
                Model.wrap(quote, start, end, editor);
                Undo.addUndoForWrap(command, quote);
                const header = new Model({type:"paragraph", text:"[!" + kind.toUpperCase() + "]"});
                quote.prependChild(header);
                Undo.addUndoForInsert(command, header);
                editor.findElemById(quote.cid).replaceWith(quote.toHTML());
                if (cursor) command.redo.push(cursor);
                editor.undo.register(command);
                editor.quickRefresh();
                if (cursor) editor.undo.exeCommand(cursor);
            } finally { editor.brush.resume(); }
            editor.refocus();
            this._saveSelection();
        });
    }

    _convertSelectionToHtmlCard() {
        this._withEditorSelection((editor, selection) => {
            const text = String(this._getSelectionText(selection) || this.lastSelectionText || "")
                .replace(/\r\n?/g, "\n")
                .trim();
            if (!text) return;

            const markup = this._buildSelectedHtmlCardMarkup(selection, text);
            if (!markup) return;

            const compactMarkup = this._compactHtmlCardMarkup(markup);
            if (!compactMarkup) return;

            this._replaceSelectionWithText(editor, `\n${compactMarkup}\n`);
            this.hide();
        });
    }

    _buildSelectedHtmlCardMarkup(selection, fallbackText) {
        const themeState = this._normalizeMarkdownCardSource(fallbackText);
        const theme = this._getMarkdownHtmlCardTheme(themeState.variant);
        const range = this._resolveRange(selection) || this.savedRange || this.savedRangy;
        let bodyMarkup = "";

        if (range?.cloneContents) {
            try {
                const fragment = range.cloneContents();
                const container = document.createElement("div");
                container.appendChild(fragment);
                bodyMarkup = this._renderHtmlCardBlocksFromDom(container, theme);
            } catch (error) {
                console.warn("[EditingToolbar] Failed to build card from DOM selection:", error);
            }
        }

        if (!bodyMarkup) {
            bodyMarkup = this._renderHtmlCardBlocksFromMarkdown(themeState.lines, theme);
        }

        if (!bodyMarkup) {
            return "";
        }

        return this._wrapHtmlCardMarkup(bodyMarkup, theme);
    }

    _buildMarkdownHtmlCardMarkup(markdown, variant = "note") {
        const themeState = this._normalizeMarkdownCardSource(markdown);
        const theme = this._getMarkdownHtmlCardTheme(variant || themeState.variant);
        const bodyMarkup = this._renderHtmlCardBlocksFromMarkdown(themeState.lines, theme);
        if (!bodyMarkup) {
            return "";
        }
        return this._wrapHtmlCardMarkup(bodyMarkup, theme);
    }

    _wrapHtmlCardMarkup(bodyMarkup, theme) {
        if (!bodyMarkup || !theme) {
            return "";
        }

        return [
            `<div data-et-html-card="1" style="border:2px solid ${theme.border};border-radius:14px;padding:18px 22px;background:${theme.background};margin:16px 0;line-height:1.85;color:${theme.text};box-shadow:0 2px 8px rgba(31, 41, 55, 0.04);">`,
            bodyMarkup,
            `</div>`
        ].join("\n");
    }

    _compactHtmlCardMarkup(markup) {
        return String(markup || "")
            .replace(/\r\n?/g, "\n")
            .split("\n")
            .map((line) => line.trim())
            .filter(Boolean)
            .join("\n");
    }

    _normalizeMarkdownCardSource(markdown) {
        let lines = String(markdown || "")
            .replace(/\r\n?/g, "\n")
            .split("\n")
            .map((line) => line.replace(/\t/g, "    "));

        const nonEmptyLines = lines.filter((line) => line.trim());
        if (nonEmptyLines.length > 0 && nonEmptyLines.every((line) => /^\s*>\s?/.test(line))) {
            lines = lines.map((line) => line.replace(/^\s*>\s?/, ""));
        }

        let variant = "note";
        const firstNonEmptyIndex = lines.findIndex((line) => line.trim());
        if (firstNonEmptyIndex >= 0) {
            const variantMatch = lines[firstNonEmptyIndex].trim().match(/^\[!([A-Z]+)\]\s*$/);
            if (variantMatch) {
                variant = variantMatch[1].toLowerCase();
                lines.splice(firstNonEmptyIndex, 1);
            }
        }

        while (lines.length && !lines[0].trim()) {
            lines.shift();
        }
        while (lines.length && !lines[lines.length - 1].trim()) {
            lines.pop();
        }

        return {
            variant,
            lines
        };
    }

    _getMarkdownHtmlCardTheme(variant) {
        const themes = {
            note: {
                border: "#45556C",
                background: "#FAFAF9",
                text: "#222222",
                heading: "#1F2937",
                link: "#325B9B"
            },
            tip: {
                border: "#3F6E63",
                background: "#F7FBF8",
                text: "#1F2930",
                heading: "#24463E",
                link: "#2F6B8E"
            },
            important: {
                border: "#445E8A",
                background: "#F8FAFD",
                text: "#1F2937",
                heading: "#1F365C",
                link: "#315F9C"
            },
            warning: {
                border: "#B7791F",
                background: "#FFF9ED",
                text: "#3A2A12",
                heading: "#7A4A00",
                link: "#8C5410"
            },
            caution: {
                border: "#A63B2E",
                background: "#FFF5F2",
                text: "#3B1F1A",
                heading: "#7B2F25",
                link: "#92423B"
            }
        };

        return themes[variant] || themes.note;
    }

    _renderHtmlCardBlocksFromDom(container, theme) {
        if (!(container instanceof Element)) {
            return "";
        }

        const hasStructuredBlocks = Boolean(container.querySelector("h1,h2,h3,h4,h5,h6,p,ul,ol,blockquote,table"));
        if (!hasStructuredBlocks) {
            const content = this._renderHtmlCardInlineNodes(Array.from(container.childNodes), theme);
            return content.trim() ? `<p style="margin:10px 0;">${content}</p>` : "";
        }

        const state = { hasTitle: false };
        const blocks = [];
        Array.from(container.childNodes).forEach((node) => {
            const rendered = this._renderHtmlCardBlockNode(node, theme, state, 0);
            if (rendered) {
                blocks.push(rendered);
            }
        });
        return blocks.join("\n");
    }

    _renderHtmlCardBlockNode(node, theme, state, depth = 0) {
        if (!node) return "";
        if (node.nodeType === 3) {
            const text = String(node.textContent || "").trim();
            if (!text) return "";
            return `<p style="margin:10px 0;">${this._renderMarkdownCardInline(text, theme)}</p>`;
        }

        if (node.nodeType !== 1) {
            return "";
        }

        const tagName = node.tagName.toLowerCase();
        if (tagName === "blockquote" || tagName === "div" || tagName === "section" || tagName === "article") {
            const blocks = [];
            Array.from(node.childNodes).forEach((child) => {
                const rendered = this._renderHtmlCardBlockNode(child, theme, state, depth);
                if (rendered) {
                    blocks.push(rendered);
                }
            });
            return blocks.join("\n");
        }

        if (/^h[1-6]$/.test(tagName)) {
            const content = this._renderHtmlCardInlineNodes(Array.from(node.childNodes), theme).trim();
            if (!content) return "";

            if (!state.hasTitle) {
                state.hasTitle = true;
                return `<h3 style="margin:0 0 14px;font-size:24px;line-height:1.35;color:${theme.heading};">${content}</h3>`;
            }

            return `<p style="font-size:1.15em;font-weight:700;margin:18px 0 10px;color:${theme.heading};">${content}</p>`;
        }

        if (tagName === "p") {
            const content = this._renderHtmlCardInlineNodes(Array.from(node.childNodes), theme).trim();
            if (!content) return "";

            if (!state.hasTitle && this._looksLikeMarkdownCardTitle(node.textContent || "")) {
                state.hasTitle = true;
                return `<h3 style="margin:0 0 14px;font-size:24px;line-height:1.35;color:${theme.heading};">${content}</h3>`;
            }

            return `<p style="margin:10px 0;">${content}</p>`;
        }

        if (tagName === "ul" || tagName === "ol") {
            return this._renderHtmlCardListElement(node, theme, state, depth);
        }

        if (tagName === "table") {
            const cloned = node.cloneNode(true);
            cloned.removeAttribute("style");
            cloned.querySelectorAll("[style]").forEach((element) => element.removeAttribute("style"));
            cloned.querySelectorAll("th,td").forEach((cell) => {
                cell.innerHTML = this._renderHtmlCardInlineNodes(Array.from(cell.childNodes), theme);
            });
            return `<div style="overflow:auto;margin:12px 0;"><table style="width:100%;border-collapse:collapse;font-size:0.96em;">${cloned.innerHTML}</table></div>`;
        }

        const content = this._renderHtmlCardInlineNodes(Array.from(node.childNodes), theme).trim();
        if (!content) return "";
        return `<p style="margin:10px 0;">${content}</p>`;
    }

    _renderHtmlCardListElement(listElement, theme, state, depth = 0) {
        const items = Array.from(listElement.children).filter((child) => child.tagName?.toLowerCase() === "li");
        if (items.length === 0) return "";

        if (listElement.tagName.toLowerCase() === "ol" && depth === 0) {
            const sections = [];
            items.forEach((item, index) => {
                const { leadHtml, childBlocks } = this._extractHtmlCardListItemLead(item, theme, state, depth + 1);
                const titleHtml = leadHtml || `第 ${index + 1} 节`;
                sections.push(`<p style="font-size:1.15em;font-weight:700;margin:18px 0 10px;color:${theme.heading};">${index + 1}. ${titleHtml}</p>`);
                if (childBlocks.length) {
                    sections.push(childBlocks.join("\n"));
                }
            });
            return sections.join("\n");
        }

        const tagName = listElement.tagName.toLowerCase() === "ol" ? "ol" : "ul";
        const listStyle = depth > 0
            ? "padding-left:22px;margin:6px 0 0;"
            : "padding-left:24px;margin:8px 0 12px;";
        const itemsHtml = items.map((item) => {
            const { leadHtml, childBlocks } = this._extractHtmlCardListItemLead(item, theme, state, depth + 1);
            const segments = [];
            if (leadHtml) {
                segments.push(leadHtml);
            }
            if (childBlocks.length) {
                segments.push(childBlocks.join("\n"));
            }
            return `<li style="margin:6px 0;">${segments.join("\n")}</li>`;
        }).join("\n");
        return `<${tagName} style="${listStyle}">${itemsHtml}</${tagName}>`;
    }

    _extractHtmlCardListItemLead(item, theme, state, depth = 0) {
        const leadNodes = [];
        const childBlocks = [];

        Array.from(item.childNodes).forEach((child) => {
            if (child.nodeType === 1) {
                const tagName = child.tagName.toLowerCase();
                if (tagName === "ul" || tagName === "ol" || tagName === "blockquote" || tagName === "table") {
                    const rendered = this._renderHtmlCardBlockNode(child, theme, state, depth);
                    if (rendered) {
                        childBlocks.push(rendered);
                    }
                    return;
                }

                if (tagName === "p") {
                    if (leadNodes.length === 0) {
                        leadNodes.push(...Array.from(child.childNodes));
                    } else {
                        const rendered = this._renderHtmlCardBlockNode(child, theme, state, depth);
                        if (rendered) {
                            childBlocks.push(rendered);
                        }
                    }
                    return;
                }
            }

            leadNodes.push(child);
        });

        const leadHtml = this._renderHtmlCardInlineNodes(leadNodes, theme).trim();
        return { leadHtml, childBlocks };
    }

    _renderHtmlCardInlineNodes(nodes, theme) {
        return nodes.map((node) => this._renderHtmlCardInlineNode(node, theme)).join("");
    }

    _renderHtmlCardInlineNode(node, theme) {
        if (!node) return "";
        if (node.nodeType === 3) {
            return this._escapeHtml(String(node.textContent || ""));
        }
        if (node.nodeType !== 1) {
            return "";
        }

        if (node.matches(".md-entity")) return this._escapeHtml(node.getAttribute("data-content") || "");
        if (node.matches('[md-inline="inline_math"]')) {
            const source = node.querySelector('.md-math-content')?.textContent
                || node.querySelector('script[type^="math/tex"]')?.textContent || "";
            return this._escapeHtml('$' + source + '$');
        }
        if (node.matches('.md-meta,.md-content,mjx-container,.md-math-after-sym,.md-emoji-control-ch')) return "";

        const tagName = node.tagName.toLowerCase();
        const content = this._renderHtmlCardInlineNodes(Array.from(node.childNodes), theme);

        if (tagName === "strong" || tagName === "b") return `<strong>${content}</strong>`;
        if (tagName === "em" || tagName === "i") return `<em>${content}</em>`;
        if (tagName === "u") return `<u>${content}</u>`;
        if (tagName === "del" || tagName === "s") return `<del>${content}</del>`;
        if (tagName === "sub") return `<sub>${content}</sub>`;
        if (tagName === "sup") return `<sup>${content}</sup>`;
        if (tagName === "br") return "<br>";
        if (tagName === "code") {
            return `<code style="padding:0 4px;border-radius:4px;background:rgba(69, 85, 108, 0.08);font-family:'Cascadia Code','Consolas',monospace;">${content}</code>`;
        }
        if (tagName === "mark") {
            return `<mark style="background:#fff3a3;padding:0 2px;">${content}</mark>`;
        }
        if (tagName === "a") {
            const href = node.getAttribute("href") || "";
            return `<a href="${this._escapeAttribute(href)}" style="color:${theme.link};text-decoration:none;border-bottom:1px solid rgba(50, 91, 155, 0.25);">${content}</a>`;
        }
        if (tagName === "span") {
            const style = this._sanitizeHtmlCardInlineStyle(node.getAttribute("style"));
            if (style) {
                return `<span style="${this._escapeAttribute(style)}">${content}</span>`;
            }
            return `<span>${content}</span>`;
        }
        if (tagName === "img") {
            const src = node.getAttribute("src") || "";
            const alt = node.getAttribute("alt") || "";
            return `<img src="${this._escapeAttribute(src)}" alt="${this._escapeAttribute(alt)}" style="max-width:100%;border-radius:10px;display:block;margin:12px 0;" />`;
        }

        return content;
    }

    _sanitizeHtmlCardInlineStyle(styleText) {
        return String(styleText || "")
            .split(";")
            .map((part) => part.trim())
            .filter(Boolean)
            .filter((part) => /^(color|background-color|font-size|font-style|font-weight|text-decoration)\s*:/i.test(part))
            .join("; ");
    }

    _renderHtmlCardBlocksFromMarkdown(lines, theme) {
        if (!Array.isArray(lines) || lines.length === 0) {
            return "";
        }

        const state = { hasTitle: false };
        const blocks = [];
        const paragraphLines = [];
        let index = 0;

        const flushParagraph = () => {
            if (!paragraphLines.length) return;
            const text = paragraphLines.join(" ").trim();
            paragraphLines.length = 0;
            if (!text) return;

            if (!state.hasTitle && this._looksLikeMarkdownCardTitle(text)) {
                state.hasTitle = true;
                blocks.push(`<h3 style="margin:0 0 14px;font-size:24px;line-height:1.35;color:${theme.heading};">${this._renderMarkdownCardInline(text, theme)}</h3>`);
                return;
            }

            blocks.push(`<p style="margin:10px 0;">${this._renderMarkdownCardInline(text, theme)}</p>`);
        };

        while (index < lines.length) {
            const line = lines[index];
            const trimmed = String(line || "").trim();

            if (!trimmed) {
                flushParagraph();
                index += 1;
                continue;
            }

            const headingMatch = trimmed.match(/^(#{1,6})\s+(.*)$/);
            if (headingMatch) {
                flushParagraph();
                const content = this._renderMarkdownCardInline(headingMatch[2], theme);
                if (!state.hasTitle) {
                    state.hasTitle = true;
                    blocks.push(`<h3 style="margin:0 0 14px;font-size:24px;line-height:1.35;color:${theme.heading};">${content}</h3>`);
                } else {
                    blocks.push(`<p style="font-size:1.15em;font-weight:700;margin:18px 0 10px;color:${theme.heading};">${content}</p>`);
                }
                index += 1;
                continue;
            }

            const orderedHeadingMatch = trimmed.match(/^(\d+)\.\s+(.*)$/);
            if (orderedHeadingMatch) {
                flushParagraph();
                blocks.push(`<p style="font-size:1.15em;font-weight:700;margin:18px 0 10px;color:${theme.heading};">${orderedHeadingMatch[1]}. ${this._renderMarkdownCardInline(orderedHeadingMatch[2], theme)}</p>`);
                index += 1;
                continue;
            }

            const listInfo = this._parseMarkdownCardListItem(line);
            if (listInfo) {
                flushParagraph();
                const parsed = this._parseMarkdownCardList(lines, index, listInfo.indent, theme);
                if (parsed.html) {
                    blocks.push(parsed.html);
                }
                index = parsed.nextIndex;
                continue;
            }

            paragraphLines.push(trimmed);
            index += 1;
        }

        flushParagraph();
        return blocks.join("\n");
    }

    _parseMarkdownCardListItem(line) {
        const taskMatch = String(line || "").match(/^(\s*)[-+*]\s+\[([ xX])\]\s+(.*)$/);
        if (taskMatch) {
            return {
                indent: taskMatch[1].length,
                type: "task",
                checked: taskMatch[2].toLowerCase() === "x",
                text: taskMatch[3]
            };
        }

        const unorderedMatch = String(line || "").match(/^(\s*)[-+*]\s+(.*)$/);
        if (unorderedMatch) {
            return {
                indent: unorderedMatch[1].length,
                type: "ul",
                checked: false,
                text: unorderedMatch[2]
            };
        }

        const orderedMatch = String(line || "").match(/^(\s*)(\d+)\.\s+(.*)$/);
        if (orderedMatch) {
            return {
                indent: orderedMatch[1].length,
                type: "ol",
                checked: false,
                text: orderedMatch[3]
            };
        }

        return null;
    }

    _parseMarkdownCardList(lines, startIndex, baseIndent, theme) {
        const items = [];
        let index = startIndex;
        let listType = null;

        while (index < lines.length) {
            const line = lines[index];
            if (!String(line || "").trim()) {
                index += 1;
                continue;
            }

            const info = this._parseMarkdownCardListItem(line);
            if (!info || info.indent < baseIndent) {
                break;
            }

            if (info.indent > baseIndent) {
                if (!items.length) {
                    break;
                }
                const nested = this._parseMarkdownCardList(lines, index, info.indent, theme);
                if (nested.html) {
                    items[items.length - 1].children.push(nested.html);
                }
                index = nested.nextIndex;
                continue;
            }

            if (!listType) {
                listType = info.type === "task" ? "ul" : info.type;
            }

            const item = {
                checked: info.checked,
                type: info.type,
                text: info.text,
                children: []
            };
            items.push(item);
            index += 1;

            while (index < lines.length) {
                const continuation = lines[index];
                const continuationInfo = this._parseMarkdownCardListItem(continuation);
                if (continuationInfo) {
                    if (continuationInfo.indent <= baseIndent) {
                        break;
                    }
                    const nested = this._parseMarkdownCardList(lines, index, continuationInfo.indent, theme);
                    if (nested.html) {
                        item.children.push(nested.html);
                    }
                    index = nested.nextIndex;
                    continue;
                }

                if (!String(continuation || "").trim()) {
                    index += 1;
                    continue;
                }

                const currentIndent = (String(continuation || "").match(/^\s*/) || [""])[0].length;
                if (currentIndent > baseIndent) {
                    item.text += ` ${String(continuation).trim()}`;
                    index += 1;
                    continue;
                }
                break;
            }
        }

        const tagName = listType === "ol" ? "ol" : "ul";
        const listStyle = baseIndent > 0
            ? "padding-left:22px;margin:6px 0 0;"
            : "padding-left:24px;margin:8px 0 12px;";
        const itemsHtml = items.map((item) => {
            const checkbox = item.type === "task"
                ? `<span style="display:inline-block;min-width:1.1em;font-weight:700;color:${theme.heading};">${item.checked ? "☑" : "☐"}</span> `
                : "";
            const lead = `${checkbox}${this._renderMarkdownCardInline(item.text, theme)}`.trim();
            const children = item.children.length ? `\n${item.children.join("\n")}` : "";
            return `<li style="margin:6px 0;">${lead}${children}</li>`;
        }).join("\n");

        return {
            html: itemsHtml ? `<${tagName} style="${listStyle}">${itemsHtml}</${tagName}>` : "",
            nextIndex: index
        };
    }

    _looksLikeMarkdownCardTitle(text) {
        const trimmed = String(text || "").trim();
        if (!trimmed) return false;
        if (/^<span\b[^>]*>.*<\/span>$/i.test(trimmed)) return true;
        if (/^(?:\*\*|__)[\s\S]+(?:\*\*|__)$/.test(trimmed)) return true;
        return false;
    }

    _renderMarkdownCardInline(text, theme) {
        const htmlPlaceholders = [];
        let content = String(text || "").replace(/<[^>]+>/g, (tag) => {
            const token = `@@ET_HTML_${htmlPlaceholders.length}@@`;
            htmlPlaceholders.push(tag);
            return token;
        });

        content = this._escapeHtml(content);
        content = content.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, (_, alt, src) => {
            return `<img src="${this._escapeAttribute(src)}" alt="${this._escapeAttribute(alt)}" style="max-width:100%;border-radius:10px;display:block;margin:12px 0;" />`;
        });
        content = content.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (_, label, href) => {
            return `<a href="${this._escapeAttribute(href)}" style="color:${theme.link};text-decoration:none;border-bottom:1px solid rgba(50, 91, 155, 0.25);">${label}</a>`;
        });
        content = content.replace(/`([^`]+)`/g, `<code style="padding:0 4px;border-radius:4px;background:rgba(69, 85, 108, 0.08);font-family:'Cascadia Code','Consolas',monospace;">$1</code>`);
        content = content.replace(/==([^=]+)==/g, `<mark style="background:#fff3a3;padding:0 2px;">$1</mark>`);
        content = content.replace(/\*\*\*([\s\S]+?)\*\*\*/g, `<strong><em>$1</em></strong>`);
        content = content.replace(/___([\s\S]+?)___/g, `<strong><em>$1</em></strong>`);
        content = content.replace(/\*\*([\s\S]+?)\*\*/g, `<strong>$1</strong>`);
        content = content.replace(/__([\s\S]+?)__/g, `<strong>$1</strong>`);
        content = content.replace(/~~([\s\S]+?)~~/g, `<del>$1</del>`);
        content = content.replace(/(^|[^*])\*([^*\n]+)\*(?!\*)/g, `$1<em>$2</em>`);
        content = content.replace(/@@ET_HTML_(\d+)@@/g, (_, index) => {
            return htmlPlaceholders[Number(index)] || "";
        });
        return content;
    }

    _insertTemplate(templateId) {
        const template = TEMPLATE_LIBRARY[templateId];
        if (!template) return;

        const variant = String(template.variant || "note").trim().toLowerCase();
        const markdown = String(template.markdown || "").trim();
        if (!markdown) return;

        const markup = this._buildMarkdownHtmlCardMarkup(markdown, variant);
        if (!markup) return;

        const compactMarkup = this._compactHtmlCardMarkup(markup);
        if (!compactMarkup) return;

        this._withEditorSelection((editor) => {
            this._replaceSelectionWithText(editor, `\n${compactMarkup}\n`);
        });
    }

    async _insertLink() {
        this._saveSelection();
        const selectedText = String(this.lastSelectionText || "")
            .replace(/\r\n?/g, " ")
            .trim();

        let nativeHandled = false;
        this._withEditorSelection((editor) => {
            if (editor?.stylize?.toggleStyle) {
                try {
                    editor.stylize.toggleStyle("link");
                    nativeHandled = true;
                    return;
                } catch (error) {
                    console.warn("[EditingToolbar] Native link failed:", error);
                }
            }
        });
        if (nativeHandled) return;

        const result = await this._openLinkDialog(selectedText);
        if (!result?.url) return;

        this._withEditorSelection((editor) => {
            const markdown = `[${result.title}](${result.url})`;
            if (!selectedText && this._insertTextAtCaret(markdown)) {
                return;
            }
            this._replaceSelectionWithText(editor, markdown);
        });
    }

    _openLinkDialog(selectedText) {
        if (!this.linkDialog || !this.linkDialogUrlInput || !this.linkDialogTitleInput) {
            return Promise.resolve(null);
        }

        if (this.linkDialogResolver) {
            this.linkDialogResolver(null);
            this.linkDialogResolver = null;
        }

        this.linkDialogUrlInput.value = "https://";
        this.linkDialogTitleInput.value = selectedText || "";
        this.dialogSelectionRange = this.savedRange ? this.savedRange.cloneRange() : null;
        this.dialogSelectionText = this.lastSelectionText;
        this.linkDialog.hidden = false;

        requestAnimationFrame(() => {
            this.linkDialogUrlInput.focus();
            this.linkDialogUrlInput.setSelectionRange(0, this.linkDialogUrlInput.value.length);
        });

        return new Promise((resolve) => {
            this.linkDialogResolver = resolve;
        });
    }

    _closeLinkDialog(result) {
        if (!this.linkDialog) return;
        this.linkDialog.hidden = true;
        this.linkDialogUrlInput.value = "";
        this.linkDialogTitleInput.value = "";

        if (this.dialogSelectionRange) {
            this.savedRange = this.dialogSelectionRange.cloneRange();
            this.lastSelectionText = this.dialogSelectionText;
        }
        this.dialogSelectionRange = null;
        this.dialogSelectionText = "";

        if (this.linkDialogResolver) {
            const resolve = this.linkDialogResolver;
            this.linkDialogResolver = null;
            resolve(result);
        }
    }

    _insertImage() {
        this._saveSelection();

        const insertPaths = (filePaths) => {
            if (!filePaths || filePaths.length === 0) return;
            const normalized = filePaths.map((filePath) => String(filePath).replace(/\\/g, "/"));

            this._withEditorSelection((editor) => {
                if (window.MediaOp?.insertURL && normalized.length === 1) {
                    window.MediaOp.insertURL(normalized[0]);
                    return;
                }
                const markdown = normalized.map((filePath) => `![](${filePath})`).join("\n");
                if (editor?.UserOp?.pasteHandler) {
                    editor.UserOp.pasteHandler(editor, markdown);
                    return;
                }
                document.execCommand("insertText", false, markdown);
            });
        };

        if (window.JSBridge?.invoke) {
            window.JSBridge.invoke("dialog.showOpenDialog", {
                filters: [
                    {
                        name: "Images",
                        extensions: ["png", "jpg", "jpeg", "jfif", "bmp", "svg", "tiff", "webp", "gif"]
                    }
                ],
                properties: ["openFile", "multiSelections"],
                buttonLabel: "Select"
            }).then(({ filePaths }) => {
                insertPaths(filePaths || []);
            }).catch((error) => {
                console.warn("[EditingToolbar] Failed to open image picker:", error);
            });
            return;
        }

        const src = window.prompt("输入图片地址或本地路径");
        if (!src) return;
        insertPaths([src]);
    }

    _insertVideo() {
        this._saveSelection();

        const insertPaths = (filePaths) => {
            if (!filePaths || filePaths.length === 0) return;
            const normalized = filePaths
                .map((filePath) => String(filePath || "").trim())
                .filter(Boolean)
                .map((filePath) => filePath.replace(/\\/g, "/"));
            if (!normalized.length) return;

            const markup = normalized.map((filePath) => this._buildVideoMarkup(filePath)).join("\n\n");
            this._withEditorSelection((editor) => {
                this._replaceSelectionWithText(editor, `\n${markup}\n`);
            });
        };

        const promptForVideo = () => {
            const src = window.prompt("输入视频地址或本地路径");
            if (!src) return;
            insertPaths([src]);
        };

        if (window.JSBridge?.invoke) {
            window.JSBridge.invoke("dialog.showOpenDialog", {
                filters: [
                    {
                        name: "Videos",
                        extensions: ["mp4", "webm", "ogg", "mov", "m4v", "avi", "mkv"]
                    }
                ],
                properties: ["openFile", "multiSelections"],
                buttonLabel: "Select"
            }).then(({ filePaths }) => {
                if (filePaths?.length) {
                    insertPaths(filePaths);
                    return;
                }
                promptForVideo();
            }).catch((error) => {
                console.warn("[EditingToolbar] Failed to open video picker:", error);
                promptForVideo();
            });
            return;
        }

        promptForVideo();
    }

    _buildVideoMarkup(src) {
        const escapedSrc = this._escapeAttribute(String(src || "").replace(/\\/g, "/"));
        return `<video src="${escapedSrc}" controls preload="metadata" width="640" style="display:block;max-width:100%;height:auto;margin:12px 0;"></video>`;
    }

    _applyFontColor(color) {
        this._applySelectionStyle("color", color || null);
        this._rememberColor("font-color",color);
    }

    _applyBgColor(color) {
        this._applySelectionStyle("background-color", color || null);
        this._rememberColor("bg-color",color);
    }

    _adjustFontSize(direction = "increase") {
        this._applySelectionStyle("font-size", direction);
    }

    // Keep Typora's source-bearing inline tree intact: only decorate text runs,
    // never rebuild a rich selection from Selection.toString().
    _styleSelectionBlock(block, range, property, value) {
        const raw = (node) => typeof node.rawText === "function"
            ? node.rawText(true) : (node.textContent || "");
        const plain = (text, selected = false) => ({ text, start: selected ? 0 : null, end: selected ? text.length : null });
        const join = (parts) => parts.reduce((result, part) => {
            if (part.start !== null && result.start === null) result.start = result.text.length + part.start;
            if (part.end !== null) result.end = result.text.length + part.end;
            result.text += part.text;
            return result;
        }, plain(""));
        const surround = (part, before, after) => join([plain(before), part, plain(after)]);
        const overlap = (node) => {
            const bounds = document.createRange();
            bounds.selectNodeContents(node);
            // Strict boundaries exclude the next paragraph when selection ends at its start.
            if (range.compareBoundaryPoints(1, bounds) <= 0 || range.compareBoundaryPoints(3, bounds) >= 0) return null;
            if (range.compareBoundaryPoints(0, bounds) > 0) bounds.setStart(range.startContainer, range.startOffset);
            if (range.compareBoundaryPoints(2, bounds) < 0) bounds.setEnd(range.endContainer, range.endOffset);
            return bounds.collapsed ? null : bounds;
        };
        const styled = (part, style) => style && part.text
            ? surround(part, `<span style="${property}:${this._escapeAttribute(style)}">`, "</span>") : part;
        const visit = (node, inherited = null) => {
            const hit = overlap(node);
            if (node.nodeType === 3) {
                const text = node.textContent || "";
                const current = property === "font-size" && inherited
                    ? getComputedStyle(node.parentElement).fontSize : inherited;
                if (!hit) return styled(plain(text), current);
                const start = hit.startContainer === node ? hit.startOffset : 0;
                const end = hit.endContainer === node ? hit.endOffset : text.length;
                const next = property === "font-size"
                    ? this._getAdjustedFontSizeValue(getComputedStyle(node.parentElement).fontSize, value) : value;
                return join([styled(plain(text.slice(0, start)), current),
                    styled(plain(text.slice(start, end), true), next), styled(plain(text.slice(end)), current)]);
            }
            if (node.nodeType !== 1) return plain("");
            // Syntax delimiters, link destinations and rendered math previews are not editable text runs.
            if (node.matches(".md-meta,.md-content,mjx-container,.md-math-after-sym,.md-emoji-control-ch")) return plain(raw(node));
            const inline = node.getAttribute("md-inline");
            const atomic = inline && !["plain", "strong", "em", "del", "underline", "highlight",
                "superscript", "subscript", "link", "reflink", "html_inline"].includes(inline);
            if (atomic) {
                const current = property === "font-size" && inherited ? getComputedStyle(node).fontSize : inherited;
                const next = property === "font-size" ? this._getAdjustedFontSizeValue(getComputedStyle(node).fontSize, value) : value;
                return styled(plain(raw(node), Boolean(hit)), hit ? next : current);
            }
            if (inline === "html_inline") {
                const before = node.querySelector(":scope > .md-before");
                const after = node.querySelector(":scope > .md-after");
                const content = Array.from(node.children).find((child) => !child.matches(".md-meta,.md-content"));
                const opening = before?.textContent || "";
                // Parse only the opening tag, leaving all Markdown, entities and LaTeX untouched.
                if (content && after && /^<([a-z][\w:-]*)\b[^>]*>$/i.test(opening)) {
                    const template = document.createElement("template");
                    template.innerHTML = opening + after.textContent;
                    const tag = template.content.firstElementChild;
                    const own = tag?.style.getPropertyValue(property);
                    if (own && hit) {
                        tag.style.removeProperty(property);
                        if (!tag.getAttribute("style")?.trim()) tag.removeAttribute("style");
                        const inner = join(Array.from(content.childNodes, (child) => visit(child, own)));
                        if (tag.tagName === "SPAN" && !tag.attributes.length) return inner;
                        const cleanOpen = tag.outerHTML.slice(0, tag.outerHTML.indexOf(">") + 1);
                        return surround(inner, cleanOpen, after.textContent);
                    }
                    if (!hit) return styled(plain(raw(node)), inherited);
                    return surround(join(Array.from(content.childNodes, (child) => visit(child, inherited))), opening, after.textContent);
                }
                // An opaque inline HTML token can be styled as a whole without corrupting its source.
                const next = property === "font-size" ? this._getAdjustedFontSizeValue(getComputedStyle(node).fontSize, value) : value;
                return styled(plain(raw(node), Boolean(hit)), hit ? next : inherited);
            }
            return join(Array.from(node.childNodes, (child) => visit(child, inherited)));
        };
        return visit(block);
    }

    _applySelectionStyle(property, value) {
        this._withEditorSelection((editor) => {
            if (!editor?.undo?.buildReplaceUndo || !editor?.MarkParser?.renderHtmlWithBlockMeta
                || editor.sourceView?.inSourceMode || window.File?.isLocked || window.File?.bundle?.isLocked) return;
            if (property === "font-size" && !this._selectionHasText(window.getSelection())) {
                this._selectAdjacentInlineHtmlSelection((element) => this._inlineHtmlHasFontSize(element));
            }
            const range = editor.selection.getRangy();
            if (range?.collapsed && property === "font-size") {
                const size = value === "decrease" ? "0.9em" : "1.15em";
                if (this._insertTextAtCaret(`<span style="font-size:${size};"></span>`, 7)) this._stabilizeInlineHtmlCursor();
                return;
            }
            if (!range || range.collapsed || !this._selectionInEditor(range)) return;
            const blocks = this._getAlignmentBlocks(range).filter((block) => block.hasAttribute("cid"));
            const changes = [];
            for (const block of blocks) {
                const node = editor.getNode(block.getAttribute("cid"));
                if (!node || typeof node.get("text") !== "string" || typeof block.rawText !== "function") continue;
                // Refuse a stale renderer/model pair; never guess at lost text or formula offsets.
                if (block.rawText(true) !== node.get("text")) {
                    console.warn("[EditingToolbar] Style skipped: editor source is not synchronized.");
                    return;
                }
                const result = this._styleSelectionBlock(block, range, property, value);
                if (result.start !== null) changes.push({ block, node, result, changed: result.text !== node.get("text") });
            }
            if (!changes.some((change) => change.changed)) return;
            editor.undo.endSnap(true);
            const cursor = editor.selection.buildUndo();
            const command = { undo: cursor ? [cursor] : [], redo: [] };
            for (const change of changes.filter((item) => item.changed)) {
                command.undo.push(editor.undo.buildReplaceUndo(change.node));
            }
            try {
                for (const { node, result, changed } of changes) {
                    if (!changed) continue;
                    node.set("text", result.text);
                    editor.findElemById(node.cid).replaceWith(editor.MarkParser.renderHtmlWithBlockMeta(node, editor.brush));
                    command.redo.push(editor.undo.buildReplaceUndo(node));
                    editor.brush.addToQueue(node.cid, true);
                }
                const first = changes[0], last = changes[changes.length - 1];
                const selection = { type: "cursor", startId: first.node.cid, endId: last.node.cid,
                    start: first.result.start, end: last.result.end };
                editor.undo.exeCommand(selection);
                command.redo.push(selection);
            } catch (error) {
                // Roll back the entire batch if Typora changes an internal API.
                command.undo.slice().reverse().forEach((undo) => editor.undo.exeCommand(undo));
                console.error("[EditingToolbar] Style change rolled back:", error);
                return;
            }
            editor.undo.register(command);
            editor.refresh();
            this._saveSelection();
        });
    }

    _wrapSelectionWithMarkup(builder, mode = "auto") {
        this._withEditorSelection((editor) => {
            const selection = window.getSelection();
            const text = this._getSelectionText(selection) || this.lastSelectionText || "";
            const selectionState = this._extractInjectedSelectionState(selection, text);
            const hasContent = selectionState.some((line) => line.text);
            if (!hasContent) return;

            const markup = builder(selectionState);
            if (!markup) return;

            if (mode === "text") {
                this._replaceSelectionWithText(editor, markup);
                return;
            }

            this._pasteMarkup(editor, markup, mode);
        });
    }

    _replaceSelectionWithText(editor, text) {
        if (!text) return false;
        if (typeof editor?.insertText === "function") {
            editor.insertText(text);
            this._stabilizeInlineHtmlCursor();
            return true;
        }
        if (editor?.UserOp?.pasteHandler) {
            editor.UserOp.pasteHandler(editor, text, true, true, true);
            this._stabilizeInlineHtmlCursor();
            return true;
        }
        document.execCommand("insertText", false, text);
        this._stabilizeInlineHtmlCursor();
        return false;
    }

    _replaceSelectionWithLiteralText(editor, text) {
        if (!text) return false;

        if (editor?.UserOp?.pasteHandler) {
            editor.UserOp.pasteHandler(editor, text, true, true, true);
            this._stabilizeInlineHtmlCursor();
            return true;
        }

        try {
            const success = document.execCommand("insertText", false, text);
            if (success) {
                this._stabilizeInlineHtmlCursor();
                return true;
            }
        } catch (error) {
            console.warn("[EditingToolbar] Literal insertText failed:", error);
        }

        if (typeof editor?.insertText === "function") {
            editor.insertText(text);
            this._stabilizeInlineHtmlCursor();
            return true;
        }

        return false;
    }

    _pasteText(text) {
        const editor = this._getEditor();
        return this._replaceSelectionWithText(editor, text);
    }

    _selectionHasText(selection = window.getSelection()) {
        const range = this._resolveRange(selection);
        if (!range || range.collapsed) return false;
        return Boolean(String(this._getSelectionText(selection, range) || "").trim());
    }

    _restoreRecentFontSizeSelection() {
        const tryRestore = () => {
            if (this._selectAdjacentInlineHtmlSelection((element) => this._inlineHtmlHasFontSize(element))) {
                this._onSelectionChange();
            }
        };

        requestAnimationFrame(tryRestore);
        setTimeout(tryRestore, 30);
        setTimeout(tryRestore, 90);
    }

    _inlineHtmlHasFontSize(element) {
        if (!(element instanceof Element)) return false;
        if (element.querySelector?.("[style*='font-size']")) {
            return true;
        }
        const combined = `${element.getAttribute("style") || ""}\n${element.innerHTML || ""}\n${element.textContent || ""}`;
        return /font-size\s*:/i.test(combined);
    }

    _resolveInlineHtmlElement(node) {
        if (!node) return null;
        let element = node.nodeType === 1 ? node : node.parentElement;
        if (!(element instanceof Element)) return null;
        if (element.matches?.("[md-inline='html_inline']")) return element;
        return element.closest?.("[md-inline='html_inline']") || element.querySelector?.("[md-inline='html_inline']") || null;
    }

    _findAdjacentInlineHtmlElement(range, predicate = null) {
        if (!range) return null;

        const seen = new Set();
        const matches = (candidate) => {
            const inline = this._resolveInlineHtmlElement(candidate);
            if (!(inline instanceof Element) || seen.has(inline)) {
                return null;
            }
            seen.add(inline);
            if (typeof predicate === "function" && !predicate(inline)) {
                return null;
            }
            return inline;
        };

        const collectFromSiblings = (startNode, direction) => {
            let node = startNode;
            while (node) {
                const found = matches(node);
                if (found) return found;
                node = direction === "next" ? node.nextSibling : node.previousSibling;
            }
            return null;
        };

        const container = range.startContainer;
        const offset = range.startOffset;
        const containerElement = container?.nodeType === 1 ? container : container?.parentElement;

        const direct = matches(containerElement);
        if (direct) return direct;

        if (container?.nodeType === 1) {
            const prev = collectFromSiblings(container.childNodes[offset - 1] || null, "prev");
            if (prev) return prev;
            const next = collectFromSiblings(container.childNodes[offset] || null, "next");
            if (next) return next;
        } else if (container?.nodeType === 3) {
            if (offset === 0) {
                const prev = collectFromSiblings(container.previousSibling, "prev");
                if (prev) return prev;
            } else if (offset === container.textContent.length) {
                const next = collectFromSiblings(container.nextSibling, "next");
                if (next) return next;
                const prev = collectFromSiblings(container.previousSibling, "prev");
                if (prev) return prev;
            }
        }

        let ancestor = containerElement;
        while (ancestor && ancestor !== document.body) {
            const prev = collectFromSiblings(ancestor.previousSibling, "prev");
            if (prev) return prev;
            const next = collectFromSiblings(ancestor.nextSibling, "next");
            if (next) return next;
            ancestor = ancestor.parentElement;
        }

        return null;
    }

    _selectAdjacentInlineHtmlSelection(predicate = null) {
        const selection = window.getSelection();
        if (!selection?.rangeCount) return false;

        const range = selection.getRangeAt(0);
        if (!range.collapsed) return false;

        const inline = this._findAdjacentInlineHtmlElement(range, predicate);
        if (!(inline instanceof Element)) return false;

        const nextRange = document.createRange();
        nextRange.selectNode(inline);
        selection.removeAllRanges();
        selection.addRange(nextRange);
        this._saveSelection(selection);
        return true;
    }

    _insertTextAtCaret(text, suffixLength = 0) {
        if (!text) return false;

        const selection = window.getSelection();
        if (!selection?.rangeCount) return false;

        try {
            const success = document.execCommand("insertText", false, text);
            if (!success) {
                throw new Error("insertText returned false");
            }
        } catch (error) {
            const range = selection.getRangeAt(0);
            range.deleteContents();
            const node = document.createTextNode(text);
            range.insertNode(node);

            const fallbackRange = document.createRange();
            fallbackRange.setStart(node, Math.max(0, text.length - suffixLength));
            fallbackRange.collapse(true);
            selection.removeAllRanges();
            selection.addRange(fallbackRange);
            return true;
        }

        if (!suffixLength) return true;

        const anchorNode = selection.anchorNode;
        const anchorOffset = selection.anchorOffset;
        if (anchorNode?.nodeType === 3 && anchorOffset >= suffixLength) {
            const range = document.createRange();
            range.setStart(anchorNode, anchorOffset - suffixLength);
            range.collapse(true);
            selection.removeAllRanges();
            selection.addRange(range);
        }

        return true;
    }

    _extractInjectedSelectionState(selection, text) {
        const inheritedStyles = this._extractSelectionStylesFromRange(selection, this.savedRange);

        return String(text || "")
            .replace(/\r\n?/g, "\n")
            .split("\n")
            .map((line) => {
                const lineState = this._extractInjectedLineState(line);
                return {
                    text: lineState.text,
                    styles: {
                        ...inheritedStyles,
                        ...lineState.styles
                    }
                };
            });
    }

    _extractInjectedLineState(text) {
        const decoded = this._decodeHtmlEntities(String(text || ""));
        if (!decoded) {
            return { text: "", styles: {} };
        }

        if (!/<span\b[^>]*style\s*=|&lt;span\b[^&]*style=/i.test(String(text || ""))) {
            return { text: decoded, styles: {} };
        }

        const container = document.createElement("div");
        container.innerHTML = decoded;

        const styles = {};
        container.querySelectorAll("span[style]").forEach((span) => {
            const parsed = this._parseInjectedColorStyles(span.getAttribute("style"));
            if (parsed.color) {
                styles.color = parsed.color;
            }
            if (parsed.backgroundColor) {
                styles.backgroundColor = parsed.backgroundColor;
            }
            if (parsed.fontSize) {
                styles.fontSize = parsed.fontSize;
            }
        });

        return {
            text: this._decodeHtmlEntities(container.textContent || ""),
            styles
        };
    }

    _parseInjectedColorStyles(styleText) {
        const parsed = {};
        String(styleText || "")
            .split(";")
            .map((part) => part.trim())
            .filter(Boolean)
            .forEach((part) => {
                const separatorIndex = part.indexOf(":");
                if (separatorIndex === -1) return;

                const key = part.slice(0, separatorIndex).trim().toLowerCase();
                const value = part.slice(separatorIndex + 1).trim();
                if (!value) return;

                if (key === "color") {
                    parsed.color = value;
                } else if (key === "background-color") {
                    parsed.backgroundColor = value;
                } else if (key === "font-size") {
                    parsed.fontSize = value;
                }
            });
        return parsed;
    }

    _extractSelectionStylesFromRange(selection, fallbackRange = null) {
        const collected = {};
        const applyStylesFromElement = (element) => {
            if (!(element instanceof Element)) return;
            const parsed = this._parseInjectedColorStyles(element.getAttribute("style"));
            if (parsed.color) {
                collected.color = parsed.color;
            }
            if (parsed.backgroundColor) {
                collected.backgroundColor = parsed.backgroundColor;
            }
            if (parsed.fontSize) {
                collected.fontSize = parsed.fontSize;
            }

            const inlineState = this._extractInjectedLineState(`${element.innerHTML || ""}\n${element.textContent || ""}`);
            if (inlineState.styles.color) {
                collected.color = inlineState.styles.color;
            }
            if (inlineState.styles.backgroundColor) {
                collected.backgroundColor = inlineState.styles.backgroundColor;
            }
            if (inlineState.styles.fontSize) {
                collected.fontSize = inlineState.styles.fontSize;
            }
        };

        const targetRange = this._resolveRange(selection) || fallbackRange;
        if (targetRange) {
            try {
                const fragment = targetRange.cloneContents();
                const container = document.createElement("div");
                container.appendChild(fragment);
                container.querySelectorAll("[style]").forEach((element) => {
                    applyStylesFromElement(element);
                });
            } catch (error) {
                console.warn("[EditingToolbar] Failed to inspect selection styles:", error);
            }
        }

        if (collected.color || collected.backgroundColor || collected.fontSize) {
            return collected;
        }

        let node = selection?.anchorNode || targetRange?.commonAncestorContainer || null;
        if (node?.nodeType === 3) {
            node = node.parentElement;
        }
        if (node instanceof Element) {
            applyStylesFromElement(node);
            node.closest("[md-inline='html_inline']")?.querySelectorAll("[style]")?.forEach((element) => {
                applyStylesFromElement(element);
            });
        }

        return collected;
    }

    _decodeHtmlEntities(text) {
        const textarea = document.createElement("textarea");
        textarea.innerHTML = String(text || "");
        return textarea.value;
    }

    _stabilizeInlineHtmlCursor() {
        const moveOutOfInlineHtml = () => {
            const selection = window.getSelection();
            if (!selection?.rangeCount) return false;

            let node = selection.anchorNode;
            if (!node) return false;
            if (node.nodeType === 3) {
                node = node.parentElement;
            }
            if (!(node instanceof Element)) return false;

            const inline = node.closest("[md-inline='html_inline']");
            if (!inline?.parentNode) return false;

            const range = document.createRange();
            range.setStartAfter(inline);
            range.collapse(true);
            selection.removeAllRanges();
            selection.addRange(range);
            return true;
        };

        requestAnimationFrame(() => {
            moveOutOfInlineHtml();
            setTimeout(moveOutOfInlineHtml, 30);
            setTimeout(moveOutOfInlineHtml, 90);
        });
    }

    _pasteMarkup(editor, markup, mode = "auto") {
        if (editor?.UserOp?.pasteHandler) {
            if (mode === "plain") {
                editor.UserOp.pasteHandler(editor, markup, true);
                return true;
            }
            if (mode === "html") {
                editor.UserOp.pasteHandler(editor, markup, false);
                return true;
            }
            editor.UserOp.pasteHandler(editor, markup);
            return true;
        }

        if (mode !== "plain" && document.queryCommandSupported?.("insertHTML")) {
            if (document.execCommand("insertHTML", false, markup)) return true;
        }

        document.execCommand("insertText", false, markup);
        return false;
    }

    _replaceSelectionWithHtml(editor, markup) {
        if (!markup) return false;

        if (document.queryCommandSupported?.("insertHTML")) {
            try {
                const inserted = document.execCommand("insertHTML", false, markup);
                if (inserted) {
                    this._saveSelection(window.getSelection());
                    return true;
                }
            } catch (error) {
                console.warn("[EditingToolbar] insertHTML failed:", error);
            }
        }

        if (editor?.UserOp?.pasteHandler) {
            try {
                editor.UserOp.pasteHandler(editor, markup, false);
                this._saveSelection(window.getSelection());
                return true;
            } catch (error) {
                console.warn("[EditingToolbar] HTML pasteHandler failed:", error);
            }
        }

        const selection = window.getSelection();
        const range = this._resolveRange(selection) || this.savedRange || this.savedRangy;
        if (range && this._selectionInEditor(range)) {
            try {
                const workingRange = range.cloneRange();
                const fragment = workingRange.createContextualFragment
                    ? workingRange.createContextualFragment(markup)
                    : this._createHtmlFragment(markup);
                const insertedNodes = Array.from(fragment.childNodes);

                workingRange.deleteContents();
                workingRange.insertNode(fragment);

                const lastNode = insertedNodes[insertedNodes.length - 1];
                if (selection && lastNode?.parentNode) {
                    const afterRange = document.createRange();
                    afterRange.setStartAfter(lastNode);
                    afterRange.collapse(true);
                    selection.removeAllRanges();
                    selection.addRange(afterRange);
                    this._saveSelection(selection);
                }
                return true;
            } catch (error) {
                console.warn("[EditingToolbar] Direct HTML replacement failed:", error);
            }
        }

        return false;
    }

    _createHtmlFragment(markup) {
        const template = document.createElement("template");
        template.innerHTML = String(markup || "");
        return template.content.cloneNode(true);
    }

    _escapeHtml(text) {
        return text
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/\"/g, "&quot;");
    }

    _buildStyledSelectionMarkup(selectionState, styleMap) {
        const lines = Array.isArray(selectionState)
            ? selectionState
            : this._extractInjectedSelectionState(selectionState);

        return lines.map((line) => {
            if (!line.text) return "";

            const mergedStyles = {
                ...line.styles,
                ...styleMap
            };
            const style = Object.entries(mergedStyles)
                .filter(([, value]) => value != null && value !== "")
                .map(([key, value]) => `${this._toKebabCase(key)}:${value}`)
                .join("; ");

            if (!style) {
                return this._escapeHtml(line.text);
            }

            return `<span style="${style}">${this._escapeHtml(line.text)}</span>`;
        }).join("\n");
    }

    _buildAdjustedFontSizeMarkup(selectionState, direction) {
        const lines = Array.isArray(selectionState)
            ? selectionState
            : this._extractInjectedSelectionState(selectionState);

        return lines.map((line) => {
            if (!line.text) return "";

            const mergedStyles = { ...line.styles };
            mergedStyles.fontSize = this._getAdjustedFontSizeValue(line.styles?.fontSize, direction);

            const style = Object.entries(mergedStyles)
                .filter(([, value]) => value != null && value !== "")
                .map(([key, value]) => `${this._toKebabCase(key)}:${value}`)
                .join("; ");

            if (!style) {
                return this._escapeHtml(line.text);
            }

            return `<span style="${style}">${this._escapeHtml(line.text)}</span>`;
        }).join("\n");
    }

    _getAdjustedFontSizeValue(currentSize, direction) {
        const isIncrease = direction !== "decrease";
        const fallback = isIncrease ? "1.15em" : "0.9em";
        const match = String(currentSize || "").trim().match(/^(-?\d*\.?\d+)(px|em|rem|%)$/i);
        if (!match) {
            return fallback;
        }

        const numeric = Number.parseFloat(match[1]);
        const unit = match[2].toLowerCase();
        if (!Number.isFinite(numeric) || numeric <= 0) {
            return fallback;
        }

        const ratio = isIncrease ? 1.15 : (1 / 1.15);
        let nextValue = numeric * ratio;

        if (unit === "px") {
            nextValue = Math.max(8, Math.min(96, nextValue));
        } else if (unit === "%") {
            nextValue = Math.max(50, Math.min(400, nextValue));
        } else {
            nextValue = Math.max(0.55, Math.min(4, nextValue));
        }

        const rounded = unit === "%" ? Math.round(nextValue) : Math.round(nextValue * 100) / 100;
        const normalized = Number.isInteger(rounded) ? String(rounded) : String(rounded).replace(/\.0+$/, "").replace(/(\.\d*[1-9])0+$/, "$1");
        return `${normalized}${unit}`;
    }

    _toKebabCase(text) {
        return String(text).replace(/[A-Z]/g, (char) => `-${char.toLowerCase()}`);
    }

    _escapeAttribute(text) {
        return String(text)
            .replace(/&/g, "&amp;")
            .replace(/\"/g, "&quot;");
    }

    _toggleFullscreen() {
        try {
            if (document.fullscreenElement) {
                document.exitFullscreen();
            } else {
                document.documentElement.requestFullscreen();
            }
        } catch (error) {
            console.warn("[EditingToolbar] Fullscreen failed:", error);
        }
    }
}

const ICONS = {
    undo: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7v6h6"/><path d="M3 13a9 9 0 0 1 15.4-6.4L21 9"/></svg>`,
    redo: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 7v6h-6"/><path d="M21 13a9 9 0 0 0-15.4-6.4L3 9"/></svg>`,
    bold: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M6 4h8a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z"/><path d="M6 12h9a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z"/></svg>`,
    italic: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="19" y1="4" x2="10" y2="4"/><line x1="14" y1="20" x2="5" y2="20"/><line x1="15" y1="4" x2="9" y2="20"/></svg>`,
    strikethrough: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 4H9a3 3 0 0 0-3 3v.5a3 3 0 0 0 3 3h6a3 3 0 0 1 3 3v.5a3 3 0 0 1-3 3H8"/><line x1="4" y1="12" x2="20" y2="12"/></svg>`,
    underline: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 3v7a6 6 0 0 0 6 6 6 6 0 0 0 6-6V3"/><line x1="4" y1="21" x2="20" y2="21"/></svg>`,
    highlight: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M9.3 3.6a1 1 0 0 1 1.4 0l3.7 3.7a1 1 0 0 1 0 1.4l-6.8 6.8a1 1 0 0 1-1.4 0l-3.7-3.7a1 1 0 0 1 0-1.4z"/><rect x="3" y="18" width="18" height="3" rx="1.5" fill="#F5DA61"/></svg>`,
    fontSizeDecrease: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><text x="3" y="16" font-size="13" font-weight="700" font-family="Segoe UI, sans-serif">A</text><line x1="13" y1="15.5" x2="20" y2="15.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>`,
    fontSizeIncrease: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><text x="3" y="16" font-size="13" font-weight="700" font-family="Segoe UI, sans-serif">A</text><line x1="16.5" y1="10" x2="16.5" y2="19" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><line x1="12" y1="14.5" x2="21" y2="14.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>`,
    blockquote: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M10 8H6a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h2l-2 4h2.5l2-4V10a2 2 0 0 0-2-2zm10 0h-4a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h2l-2 4h2.5l2-4V10a2 2 0 0 0-2-2z"/></svg>`,
    code: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>`,
    codeblock: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><polyline points="9 8 5 12 9 16"/><polyline points="15 8 19 12 15 16"/></svg>`,
    inlineMath: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><text x="5" y="16" font-size="13" font-family="Georgia, serif">$</text></svg>`,
    inlineMathAscii: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><text x="1.5" y="15.5" font-size="8" font-weight="700" font-family="Segoe UI, sans-serif">A1</text><text x="13.2" y="15.5" font-size="11" font-family="Georgia, serif">$</text></svg>`,
    mathBlock: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><text x="2" y="16" font-size="11" font-family="Georgia, serif">$$</text></svg>`,
    warningBlock: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 3l9 16H3l9-16z"/><rect x="11" y="8" width="2" height="6" fill="#fff"/><rect x="11" y="16.5" width="2" height="2" fill="#fff"/></svg>`,
    link: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 1 0-7.1-7.1L11.7 5"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 1 0 7.1 7.1l1.7-1.7"/></svg>`,
    linkReference: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><text x="1" y="15" font-size="8" font-family="Segoe UI, sans-serif">[]:</text></svg>`,
    footnote: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><text x="1" y="15" font-size="8" font-family="Segoe UI, sans-serif">[^]</text></svg>`,
    image: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>`,
    video: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M10 9l5 3-5 3z"/></svg>`,
    emoji: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M8.5 14.5c.8 1.2 2 1.8 3.5 1.8s2.7-.6 3.5-1.8"/><circle cx="9" cy="10" r="1" fill="currentColor" stroke="none"/><circle cx="15" cy="10" r="1" fill="currentColor" stroke="none"/></svg>`,
    h1: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><text x="2" y="18" font-size="15" font-weight="700" font-family="Segoe UI, sans-serif">H1</text></svg>`,
    h2: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><text x="2" y="18" font-size="15" font-weight="700" font-family="Segoe UI, sans-serif">H2</text></svg>`,
    h3: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><text x="2" y="18" font-size="15" font-weight="700" font-family="Segoe UI, sans-serif">H3</text></svg>`,
    h4: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><text x="3" y="17" font-size="13" font-weight="700" font-family="Segoe UI, sans-serif">H4</text></svg>`,
    h5: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><text x="3" y="17" font-size="13" font-weight="700" font-family="Segoe UI, sans-serif">H5</text></svg>`,
    h6: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><text x="3" y="17" font-size="13" font-weight="700" font-family="Segoe UI, sans-serif">H6</text></svg>`,
    orderedList: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="10" y1="6" x2="21" y2="6"/><line x1="10" y1="12" x2="21" y2="12"/><line x1="10" y1="18" x2="21" y2="18"/><text x="3" y="8" font-size="8" fill="currentColor" stroke="none">1</text><text x="3" y="14" font-size="8" fill="currentColor" stroke="none">2</text><text x="3" y="20" font-size="8" fill="currentColor" stroke="none">3</text></svg>`,
    unorderedList: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="9" y1="6" x2="20" y2="6"/><line x1="9" y1="12" x2="20" y2="12"/><line x1="9" y1="18" x2="20" y2="18"/><circle cx="5" cy="6" r="1.5" fill="currentColor"/><circle cx="5" cy="12" r="1.5" fill="currentColor"/><circle cx="5" cy="18" r="1.5" fill="currentColor"/></svg>`,
    taskList: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.5 2.5L16.5 9"/></svg>`,
    indent: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="4" x2="21" y2="4"/><line x1="11" y1="9" x2="21" y2="9"/><line x1="11" y1="14" x2="21" y2="14"/><line x1="3" y1="19" x2="21" y2="19"/><polyline points="4 9 8 12 4 15"/></svg>`,
    outdent: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="4" x2="21" y2="4"/><line x1="11" y1="9" x2="21" y2="9"/><line x1="11" y1="14" x2="21" y2="14"/><line x1="3" y1="19" x2="21" y2="19"/><polyline points="8 9 4 12 8 15"/></svg>`,
    alignLeft: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="6" x2="15" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="3" y1="14" x2="15" y2="14"/><line x1="3" y1="18" x2="21" y2="18"/></svg>`,
    alignCenter: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="6" y1="6" x2="18" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="6" y1="14" x2="18" y2="14"/><line x1="3" y1="18" x2="21" y2="18"/></svg>`,
    alignRight: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="9" y1="6" x2="21" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="9" y1="14" x2="21" y2="14"/><line x1="3" y1="18" x2="21" y2="18"/></svg>`,
    alignJustify: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="3" y1="14" x2="21" y2="14"/><line x1="3" y1="18" x2="21" y2="18"/></svg>`,
    fontColor: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M11 2L5.5 16h2.25l1.12-3h6.25l1.13 3h2.25L13 2h-2zm-1.38 9L12 4.67 14.38 11H9.62z"/><rect x="3" y="19" width="18" height="3" rx="1.5" fill="#2F6FEB"/></svg>`,
    bgColor: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M16.56 8.94L7.62 0 6.21 1.41l2.38 2.38-5.15 5.15a1.49 1.49 0 0 0 0 2.12l5.5 5.5c.29.29.68.44 1.06.44s.77-.15 1.06-.44l5.5-5.5a1.49 1.49 0 0 0 0-2.12zM10 16.12L4.94 11h10.12L10 16.12z"/><rect x="3" y="19" width="18" height="3" rx="1.5" fill="#F28C38"/></svg>`,
    hr: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="12" x2="21" y2="12"/></svg>`,
    superscript: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><text x="1" y="18" font-size="14" font-family="Segoe UI, sans-serif">x</text><text x="13" y="10" font-size="9" font-family="Segoe UI, sans-serif">2</text></svg>`,
    subscript: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><text x="1" y="16" font-size="14" font-family="Segoe UI, sans-serif">x</text><text x="13" y="20" font-size="9" font-family="Segoe UI, sans-serif">2</text></svg>`,
    clearFormat: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 19h12"/><path d="M12 3L8 19"/><path d="M16 3h-5"/><line x1="3" y1="3" x2="21" y2="21" stroke-width="2.5" stroke="#DA4A4A"/></svg>`,
    fullscreen: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>`,
    templateLibrary: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="4" width="12" height="16" rx="2"/><path d="M8 8h4"/><path d="M8 12h6"/><path d="M8 16h5"/><path d="M17 7l3 3-7.5 7.5H9.5V14.5z"/></svg>`,
    floatingToolbarOn: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="14" rx="3"/><path d="M8 9h8"/><path d="M8 13h5"/><circle cx="18" cy="18" r="2.5" fill="currentColor" stroke="none"/></svg>`,
    floatingToolbarOff: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="14" rx="3"/><path d="M8 9h8"/><path d="M8 13h5"/><line x1="5" y1="19" x2="19" y2="5" stroke="#DA4A4A" stroke-width="2.4" stroke-linecap="round"/></svg>`,
    table: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="3" y1="15" x2="21" y2="15"/><line x1="9" y1="3" x2="9" y2="21"/><line x1="15" y1="3" x2="15" y2="21"/></svg>`
};

const TEMPLATE_MENU_ITEMS = [
    { type: "header", label: "基础卡片" },
    { id: "template-info-card", label: "信息卡片", description: "总述、对比、建议" },
    { id: "template-alert-card", label: "警示卡片", description: "风险、限制、提醒" },
    { id: "template-method-card", label: "方法步骤卡", description: "流程、步骤、输出" },
    { id: "template-summary-card", label: "结论卡片", description: "结论、边界、摘要" },
    { id: "template-parameter-card", label: "参数表卡片", description: "参数、范围、说明" },
    { type: "divider" },
    { type: "header", label: "科研笔记" },
    { id: "template-compare-card", label: "对比分析卡", description: "对象差异、推荐选择" },
    { id: "template-paper-card", label: "论文摘录卡", description: "题目、方法、结论" },
    { id: "template-dataset-card", label: "数据集说明卡", description: "来源、范围、限制" },
    { id: "template-experiment-card", label: "实验记录卡", description: "输入、步骤、结果" },
    { id: "template-result-card", label: "结果解读卡", description: "现象、原因、判断" },
    { id: "template-research-card", label: "研究问题卡", description: "问题、缺口、思路" },
    { id: "template-method-choice-card", label: "方法选择卡", description: "候选方案与取舍" },
    { type: "divider" },
    { type: "header", label: "整理复盘" },
    { id: "template-troubleshoot-card", label: "问题排查卡", description: "现象、原因、修复" },
    { id: "template-checklist-card", label: "流程清单卡", description: "清单、完成标准、备注" },
    { id: "template-todo-card", label: "小结与待办卡", description: "小结、待办、优先级" }
];

const TEMPLATE_LIBRARY = Object.freeze({
    "template-info-card": {
        variant: "note",
        markdown: `## 标题

这里写一段总述，先把背景、对象和结论范围交代清楚。

### 1. 核心对比
- **对象 A**：这里写对象 A 的定义、特征或参数。
- **对象 B**：这里写对象 B 的定义、特征或参数。

### 2. 适用场景
- **场景一**：这里写典型用途。
- **场景二**：这里写另一类用途。

### 3. 使用建议
- **建议一**：这里写建议。
- **建议二**：==这里写需要强调的关键点==。`
    },
    "template-alert-card": {
        variant: "warning",
        markdown: `## 注意事项

- **关键提醒**：**这里写高风险或必须避免的操作**
- **补充说明**：这里写原因、条件或例外情况。`
    },
    "template-method-card": {
        variant: "tip",
        markdown: `## 方法步骤

这里先写一句方法概述。

### 1. 前处理
1. 第一步做什么。
2. 第二步做什么。

### 2. 核心处理
1. 这里写核心处理流程。
2. 这里写参数或判断条件。

### 3. 输出说明
- 输出结果一
- 输出结果二`
    },
    "template-summary-card": {
        variant: "important",
        markdown: `## 结论

- **结论一**：这里写最重要的判断。
- **结论二**：这里写边界条件。
- **结论三**：==这里写最值得引用的一句总结==`
    },
    "template-parameter-card": {
        variant: "note",
        markdown: `## 参数表说明

这里先写一句表格用途说明。

| 参数 | 数值 | 说明 |
| --- | --- | --- |
| 参数 A | 10 | 这里写说明 |
| 参数 B | 20 | 这里写说明 |
| 参数 C | 30 | 这里写说明 |

- **补充说明**：如果参数之间有约束关系，可以在表格下面继续补充。`
    },
    "template-compare-card": {
        variant: "important",
        markdown: `## 对比分析

这里先写一句对比目的，例如“用于区分两个方法、两个波段或两种处理路线的适用边界”。

### 1. 对比对象
- **对象 A**：这里写定义。
- **对象 B**：这里写定义。

### 2. 核心差异
| 维度 | 对象 A | 对象 B |
| --- | --- | --- |
| 分辨率 | 这里写 | 这里写 |
| 适用场景 | 这里写 | 这里写 |
| 优势 | 这里写 | 这里写 |
| 局限 | 这里写 | 这里写 |

### 3. 结论
- **推荐选择**：**这里写更推荐的对象或条件**
- **注意事项**：**这里写容易误用的地方**`
    },
    "template-paper-card": {
        variant: "note",
        markdown: `## 论文摘录

- **标题**：这里写论文标题
- **作者/年份**：这里写作者和年份
- **研究问题**：这里写论文试图解决什么问题
- **方法**：这里写核心方法
- **数据**：这里写数据来源、样本、区域或实验条件
- **结论**：这里写主要发现
- **我自己的判断**：==这里写你最想记住的观点==`
    },
    "template-dataset-card": {
        variant: "tip",
        markdown: `## 数据集说明

- **数据集名称**：这里写名称
- **来源**：这里写平台、机构或下载地址
- **时间范围**：这里写时间
- **空间范围**：这里写区域
- **空间分辨率**：这里写分辨率
- **波段/字段**：这里写主要字段或波段
- **适用任务**：这里写适合做什么
- **限制**：**这里写使用限制、误差来源或缺失项**`
    },
    "template-experiment-card": {
        variant: "tip",
        markdown: `## 实验记录

- **实验名称**：这里写实验名
- **日期**：这里写日期
- **目的**：这里写本次实验想验证什么
- **输入数据**：这里写输入
- **处理步骤**：
  1. 第一步
  2. 第二步
  3. 第三步
- **结果**：这里写观察到的结果
- **问题**：这里写遇到的问题
- **下一步**：这里写后续动作`
    },
    "template-result-card": {
        variant: "important",
        markdown: `## 结果解读

- **结果对象**：这里写图表、模型结果或输出文件
- **直观现象**：这里写你看到了什么
- **可能原因**：这里写原因解释
- **是否可信**：**这里写支持可信的证据**
- **需要警惕**：**这里写异常点、噪声或偏差**
- **一句话判断**：==这里写最终判断==`
    },
    "template-research-card": {
        variant: "important",
        markdown: `## 研究问题

- **核心问题**：这里写你要回答的问题
- **为什么重要**：这里写研究意义
- **已有认识**：这里写目前已知内容
- **缺口**：这里写还缺什么
- **我的思路**：这里写你准备怎么做
- **当前状态**：待验证 / 进行中`
    },
    "template-method-choice-card": {
        variant: "tip",
        markdown: `## 方法选择

- **任务目标**：这里写目标
- **候选方法 A**：这里写方法 A
- **候选方法 B**：这里写方法 B
- **选择依据**：
  - 数据条件
  - 精度要求
  - 时间成本
  - 可解释性
- **最终选择**：**这里写最终采用的方法**
- **放弃原因**：这里写未采用另一方法的原因`
    },
    "template-troubleshoot-card": {
        variant: "caution",
        markdown: `## 问题排查

- **问题现象**：这里写报错或异常现象
- **可能原因 1**：这里写原因
- **可能原因 2**：这里写原因
- **检查步骤**：
  1. 先检查什么
  2. 再检查什么
  3. 最后确认什么
- **解决方案**：这里写最终修复办法
- **复盘**：这里写下次怎么避免同类问题`
    },
    "template-checklist-card": {
        variant: "tip",
        markdown: `## 流程清单

- [ ] 步骤一
- [ ] 步骤二
- [ ] 步骤三
- [ ] 步骤四

- **完成标准**：这里写什么叫完成
- **备注**：这里写额外说明`
    },
    "template-todo-card": {
        variant: "note",
        markdown: `## 小结与待办

- **本节小结**：这里写一句总结
- **已确认事项**：
  - 事项一
  - 事项二
- **待完成事项**：
  - [ ] 待办一
  - [ ] 待办二
  - [ ] 待办三
- **优先级**：高 / 中 / 低`
    }
});

const BUTTON_DEFINITIONS = {
    "undo": { icon: ICONS.undo, title: "撤销" },
    "redo": { icon: ICONS.redo, title: "重做" },
    "bold": { icon: ICONS.bold, title: "加粗" },
    "italic": { icon: ICONS.italic, title: "斜体" },
    "strikethrough": { icon: ICONS.strikethrough, title: "删除线" },
    "underline": { icon: ICONS.underline, title: "下划线" },
    "highlight": { icon: ICONS.highlight, title: "高亮" },
    "font-size-decrease": { icon: ICONS.fontSizeDecrease, title: "缩小字号" },
    "font-size-increase": { icon: ICONS.fontSizeIncrease, title: "放大字号" },
    "blockquote": { icon: ICONS.blockquote, title: "引用" },
    "code": { icon: ICONS.code, title: "行内代码" },
    "codeblock": { icon: ICONS.codeblock, title: "代码块" },
    "inline-math": { icon: ICONS.inlineMath, title: "公式" },
    "inline-math-ascii": { icon: ICONS.inlineMathAscii, title: "字母数字转公式" },
    "math-block": { icon: ICONS.mathBlock, title: "公式块" },
    "warning-block": {
        icon: ICONS.warningBlock,
        title: "警告框",
        menuItems: [
            { id: "warning-note", label: "提醒内容" },
            { id: "warning-tip", label: "建议内容" },
            { id: "warning-important", label: "重要内容" },
            { id: "warning-warning", label: "警告内容" },
            { id: "warning-caution", label: "注意内容" }
        ]
    },
    "link": { icon: ICONS.link, title: "插入链接" },
    "link-reference": { icon: ICONS.linkReference, title: "链接引用" },
    "footnote": { icon: ICONS.footnote, title: "脚注" },
    "image": { icon: ICONS.image, title: "插入图片" },
    "video": { icon: ICONS.video, title: "插入视频" },
    "emoji": { icon: ICONS.emoji, title: "插入 Emoji", emojiPicker: true },
    "table": { icon: ICONS.table, title: "插入表格" },
    "h1": { icon: ICONS.h1, title: "一级标题" },
    "h2": { icon: ICONS.h2, title: "二级标题" },
    "h3": { icon: ICONS.h3, title: "三级标题" },
    "h4": { icon: ICONS.h4, title: "四级标题" },
    "h5": { icon: ICONS.h5, title: "五级标题" },
    "h6": { icon: ICONS.h6, title: "六级标题" },
    "ordered-list": { icon: ICONS.orderedList, title: "有序列表" },
    "unordered-list": { icon: ICONS.unorderedList, title: "无序列表" },
    "task-list": { icon: ICONS.taskList, title: "任务列表" },
    "indent": { icon: ICONS.indent, title: "增加缩进" },
    "outdent": { icon: ICONS.outdent, title: "减少缩进" },
    "align-left": { icon: ICONS.alignLeft, title: "左对齐" },
    "align-center": { icon: ICONS.alignCenter, title: "居中对齐" },
    "align-right": { icon: ICONS.alignRight, title: "右对齐" },
    "align-justify": { icon: ICONS.alignJustify, title: "两端对齐" },
    "font-color": { icon: ICONS.fontColor, title: "字体颜色", colorPicker: true },
    "bg-color": { icon: ICONS.bgColor, title: "背景颜色", colorPicker: true },
    "hr": { icon: ICONS.hr, title: "分割线" },
    "superscript": { icon: ICONS.superscript, title: "上标" },
    "subscript": { icon: ICONS.subscript, title: "下标" },
    "clear-format": { icon: ICONS.clearFormat, title: "清除格式" },
    "fullscreen": { icon: ICONS.fullscreen, title: "全屏" }
    ,
    "floating-toolbar-toggle": { icon: ICONS.floatingToolbarOn, title: "关闭小窗", stateful: true }
};


Object.assign(BUTTON_DEFINITIONS, {
    "heading-menu": {icon:"",title:"标题",label:"标题",actions:["h1","h2","h3","h4","h5","h6"]},
    "paragraph-menu": {icon:ICONS.alignLeft,title:"段落",label:"段落",actions:["align-left","align-center","align-right","align-justify","|","ordered-list","unordered-list","task-list","blockquote","indent","outdent"]},
    "math-menu": {icon:ICONS.inlineMath,title:"数学",label:"数学",actions:["code","codeblock","inline-math","inline-math-ascii","math-block"]},
    "common-menu": {icon:ICONS.bold,title:"常用",label:"常用",actions:["font-size-increase","font-size-decrease","bold","italic","underline","strikethrough","highlight","superscript","subscript","font-color","bg-color","clear-format"]},
    "insert-menu": {icon:ICONS.link,title:"插入",label:"插入",actions:["link","link-reference","footnote","image","video","table","hr","emoji","warning-block"]},
    "more-menu": {icon:'<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/></svg>',title:"更多功能",actions:["fullscreen","floating-toolbar-toggle"]},
    "toolbar-settings": {icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 6h16M4 12h16M4 18h16"/><circle cx="9" cy="6" r="2.5" fill="var(--et-surface)"/><circle cx="15" cy="12" r="2.5" fill="var(--et-surface)"/><circle cx="9" cy="18" r="2.5" fill="var(--et-surface)"/></svg>',title:"工具栏设置"}
});

if (typeof module !== "undefined" && module.exports) {
    module.exports = {
        plugin: EditingToolbarPlugin
    };
}

(function () {
    "use strict";

    if (window.__editingToolbarNoAutoInit) {
        return;
    }

    function initPlugin() {
        if (window.__editingToolbar) return;
        const plugin = new EditingToolbarPlugin();
        plugin.init();
        window.__editingToolbar = plugin;
        console.log("[EditingToolbar] initialized");
    }

    function waitForTypora() {
        const writeEl = document.getElementById("write");
        if (writeEl) {
            initPlugin();
            return;
        }
        setTimeout(waitForTypora, 300);
    }

    if (document.readyState === "complete" || document.readyState === "interactive") {
        waitForTypora();
    } else {
        document.addEventListener("DOMContentLoaded", waitForTypora);
    }
})();
