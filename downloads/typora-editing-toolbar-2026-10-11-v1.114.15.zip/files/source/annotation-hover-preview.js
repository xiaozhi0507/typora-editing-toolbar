// CSS Highlights leave the Markdown DOM untouched; hit-test their existing ranges.
class EditingToolbarAnnotationHover {
    constructor(manager) {
        this.manager = manager;
        this.serial = 0;
        this.settingsKey = 'et-annotation-preview-settings-v1';
        this.settings = this.readSettings();
        document.addEventListener('pointermove', event => {
            if (this.resizing) { this.resizeMove(event); return; }
            if (this.pinned) return;
            if ((event.pointerType === 'touch' || event.buttons) && !this.popup?.contains(event.target)) { this.hide(); return; }
            this.point = {x: event.clientX, y: event.clientY, target: event.target};
            if (!this.moveFrame) this.moveFrame = requestAnimationFrame(() => { this.moveFrame = 0; this.move(); });
        }, true);
        document.addEventListener('pointerdown', event => {
            if (!this.popup?.contains(event.target)) { this.closeTiming(); if (!this.pinned) this.hide(); }
        }, true);
        document.addEventListener('pointerup', event => { if (this.resizing?.pointerId === event.pointerId) this.finishResize(true); }, true);
        document.addEventListener('pointercancel', event => { if (this.resizing?.pointerId === event.pointerId) this.finishResize(false); }, true);
        document.addEventListener('keydown', event => {
            if (event.key === 'Escape') {
                if (this.resizing) this.finishResize(false);
                else if (this.timing && !this.timing.hidden) this.closeTiming();
                else this.hide();
            } else if (!this.pinned && !this.popup?.contains(event.target)) this.hide();
        }, true);
        document.addEventListener('selectionchange', () => {
            if (this.pinned || this.resizing) return;
            const selection = getSelection();
            if (!selection?.isCollapsed && !(this.popup?.contains(selection.anchorNode) && this.popup.contains(selection.focusNode))) this.hide();
        });
        document.addEventListener('scroll', event => { if (!this.pinned && !this.resizing && !this.popup?.contains(event.target)) this.hide(); }, true);
        document.addEventListener('pointerout', event => { if (!event.relatedTarget && !this.pinned && !this.resizing) this.hide(); });
        window.addEventListener('blur', () => { if (this.resizing) this.finishResize(false); if (!this.pinned) this.hide(); });
        window.addEventListener('resize', () => {
            if (this.resizing) this.finishResize(false);
            if (this.pinned) { this.applySize(); this.place(); } else this.hide();
        });
        window.addEventListener('storage', event => {
            if (event.key !== this.settingsKey || this.resizing) return;
            this.settings = this.readSettings(); this.updateTiming();
            if (this.popup && !this.popup.hidden) { this.applySize(); this.place(); }
            else this.hide();
        });
    }
    readSettings() {
        let saved; try { saved = JSON.parse(localStorage.getItem(this.settingsKey)); } catch {}
        const number = (value, fallback, min, max) => typeof value === 'number' && Number.isFinite(value) ? Math.max(min, Math.min(max, Math.round(value))) : fallback;
        return {width: number(saved?.width, 400, 180, 1600), height: saved?.height ? number(saved.height, 0, 96, 1200) : 0, delay: Math.round(number(saved?.delay, 1500, 300, 2000) / 100) * 100};
    }
    saveSettings() {
        try { localStorage.setItem(this.settingsKey, JSON.stringify(this.settings)); }
        catch (error) { console.warn('[EditingToolbar] Preview settings:', error); }
    }
    applySize() {
        if (!this.popup) return;
        const height = this.settings.height && Math.max(this.settings.height, this.timing && !this.timing.hidden ? 190 : 96);
        this.popup.style.width = Math.min(this.settings.width, innerWidth - 16) + 'px';
        this.popup.style.height = height ? Math.min(height, innerHeight - 16) + 'px' : '';
        this.popup.style.maxHeight = Math.min(height || 560, innerHeight - 16) + 'px';
    }
    updateTiming() {
        if (!this.timing) return;
        const text = (this.settings.delay / 1000).toFixed(1) + ' 秒';
        this.timing.querySelector('input').value = this.settings.delay;
        this.timing.querySelector('input').setAttribute('aria-valuetext', text);
        this.timing.querySelector('output').textContent = text;
    }
    closeTiming() {
        if (this.timing) this.timing.hidden = true;
        this.popup?.querySelector('[data-preview-time]')?.setAttribute('aria-expanded', 'false');
        if (this.popup && !this.popup.hidden) { this.applySize(); this.place(); }
    }
    setPinned(value) {
        this.pinned = value;
        if (!this.popup) return;
        const button = this.popup.querySelector('[data-preview-pin]');
        button.setAttribute('aria-pressed', String(value));
        button.setAttribute('aria-label', value ? '取消置顶' : '置顶'); button.title = value ? '取消置顶' : '置顶';
        this.popup.classList.toggle('et-preview-pinned', value);
        clearTimeout(this.leaveTimer); this.leaveTimer = 0;
        if (value) { const rect = this.popup.getBoundingClientRect(); this.fixedPosition = {left: rect.left, top: rect.top}; }
    }
    startResize(event, direction) {
        if (event.button !== 0) return;
        event.preventDefault();
        cancelAnimationFrame(this.moveFrame); this.moveFrame = 0;
        clearTimeout(this.leaveTimer); this.leaveTimer = 0;
        const rect = this.popup.getBoundingClientRect();
        this.resizing = {pointerId: event.pointerId, handle: event.currentTarget, direction, x: event.clientX, y: event.clientY, left: rect.left, top: rect.top, width: rect.width, height: rect.height, settings: {...this.settings}, fixedPosition: this.fixedPosition};
        this.popup.classList.add('et-preview-resizing');
        event.currentTarget.setPointerCapture(event.pointerId);
    }
    resizeMove(event) {
        const r = this.resizing;
        if (event.pointerId !== r.pointerId) return;
        const dx = event.clientX - r.x, dy = event.clientY - r.y, minW = Math.min(180, innerWidth - 16), minH = Math.min(this.timing && !this.timing.hidden ? 190 : 96, innerHeight - 16);
        const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
        let {left, top, width, height} = r;
        if (r.direction.includes('e')) width = clamp(r.width + dx, minW, Math.min(1600, innerWidth - r.left - 8));
        if (r.direction.includes('s')) height = clamp(r.height + dy, minH, Math.min(1200, innerHeight - r.top - 8));
        if (r.direction.includes('w')) { width = clamp(r.width - dx, minW, Math.min(1600, r.left + r.width - 8)); left = r.left + r.width - width; }
        if (r.direction.includes('n')) { height = clamp(r.height - dy, minH, Math.min(1200, r.top + r.height - 8)); top = r.top + r.height - height; }
        this.fixedPosition = {left, top};
        Object.assign(this.popup.style, {left: left + 'px', top: top + 'px', width: width + 'px', height: height + 'px', maxHeight: (innerHeight - 16) + 'px'});
    }
    finishResize(commit) {
        const r = this.resizing;
        if (!r) return;
        this.resizing = null; this.popup.classList.remove('et-preview-resizing');
        if (r.handle.hasPointerCapture(r.pointerId)) r.handle.releasePointerCapture(r.pointerId);
        if (commit) {
            const rect = this.popup.getBoundingClientRect();
            this.settings.width = Math.round(rect.width); this.settings.height = Math.round(rect.height); this.saveSettings();
        } else { this.settings = r.settings; this.fixedPosition = r.fixedPosition; this.applySize(); this.place(); }
    }
    valid() {
        const m = this.manager;
        return !!m.ctx && m.ctx.key === m._key() && !m.savingAs && !m._loading() && !File.editor?.sourceView?.inSourceMode;
    }
    hit(point) {
        if (!this.valid() || !point || !getSelection()?.isCollapsed || !document.getElementById('write')?.contains(point.target)) return null;
        const caret = document.caretRangeFromPoint(point.x, point.y);
        if (!caret) return null;
        let found = null;
        for (const [id, location] of this.manager.locations) {
            const range = location.range;
            if (!range.startContainer.isConnected || !range.endContainer.isConnected) continue;
            try { if (range.comparePoint(caret.startContainer, caret.startOffset) !== 0) continue; } catch { continue; }
            const rect = [...range.getClientRects()].find(r => r.width > 0 && point.x >= r.left && point.x <= r.right && point.y >= r.top && point.y <= r.bottom);
            if (rect && (!found || location.end - location.start < found.length)) found = {id, rect, length: location.end - location.start};
        }
        return found;
    }
    move() {
        if (!this.valid()) { this.hide(); return; }
        if (this.pinned || this.resizing) return;
        if (this.popup && !this.popup.hidden && this.popup.contains(this.point?.target)) { clearTimeout(this.leaveTimer); this.leaveTimer = 0; return; }
        const hit = this.hit(this.point);
        if (!hit) { this.leave(); return; }
        clearTimeout(this.leaveTimer);
        this.leaveTimer = 0;
        if (this.id === hit.id && this.key === this.manager.ctx.key) return;
        this.hide();
        this.id = hit.id; this.key = this.manager.ctx.key;
        this.timer = setTimeout(() => {
            this.timer = 0;
            const current = this.hit(this.point);
            if (current?.id === this.id && this.key === this.manager.ctx?.key) this.show(current);
            else this.hide();
        }, this.settings.delay);
    }
    leave() {
        if (this.pinned || this.resizing) return;
        clearTimeout(this.timer); this.timer = 0;
        if (!this.popup || this.popup.hidden) { this.hide(); return; }
        if (!this.leaveTimer) this.leaveTimer = setTimeout(() => this.hide(), 260);
    }
    hide() {
        if (this.resizing) this.finishResize(false);
        this.setPinned(false); this.closeTiming(); this.fixedPosition = null;
        cancelAnimationFrame(this.moveFrame); this.moveFrame = 0;
        clearTimeout(this.timer); clearTimeout(this.leaveTimer);
        this.timer = this.leaveTimer = 0; this.id = this.key = null; this.serial++;
        if (this.popup) this.popup.hidden = true;
    }
    create() {
        if (this.popup) return;
        const popup = document.createElement('aside'); popup.id = 'et-annotation-preview'; popup.hidden = true;
        popup.setAttribute('role', 'dialog'); popup.setAttribute('aria-label', '注释');
        const svg = paths => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + paths + '</svg>';
        popup.innerHTML = '<header><strong>注释</strong><div class="et-preview-actions"><button type="button" data-preview-time aria-label="悬停触发时间" title="悬停触发时间" aria-expanded="false" aria-controls="et-preview-timing">'+svg('<circle cx="12" cy="12" r="8.5"/><path d="M12 7v5l3 2"/>')+'</button><button type="button" data-preview-pin aria-label="置顶" title="置顶" aria-pressed="false">'+svg('<path d="M8 3h8l-1.5 6 3.5 5H6l3.5-5L8 3ZM12 14v7"/>')+'</button><button type="button" data-preview-close aria-label="关闭预览" title="关闭">×</button></div></header><div id="et-preview-timing" hidden><label for="et-preview-delay">悬停时间</label><output for="et-preview-delay"></output><input id="et-preview-delay" type="range" min="300" max="2000" step="100" aria-label="悬停触发时间"><div class="et-preview-time-limits"><span>0.3 秒</span><span>2.0 秒</span></div></div><div class="et-preview-content"></div>';
        document.body.append(popup); this.popup = popup;
        this.timing = popup.querySelector('#et-preview-timing');
        popup.querySelector('[data-preview-time]').onclick = () => { this.timing.hidden = !this.timing.hidden; popup.querySelector('[data-preview-time]').setAttribute('aria-expanded', String(!this.timing.hidden)); this.updateTiming(); this.applySize(); this.place(); };
        this.timing.querySelector('input').oninput = event => { this.settings.delay = Number(event.target.value); this.updateTiming(); this.saveSettings(); };
        popup.querySelector('[data-preview-pin]').onclick = () => this.setPinned(!this.pinned);
        for (const direction of ['n','e','s','w','ne','se','sw','nw']) {
            const handle = document.createElement('div'); handle.className = 'et-preview-resize'; handle.dataset.resize = direction;
            handle.title = '拖动调整大小'; handle.onpointerdown = event => this.startResize(event, direction);
            handle.onlostpointercapture = () => { if (this.resizing?.handle === handle) this.finishResize(false); };
            popup.append(handle);
        }
        this.updateTiming();
        this.resizeObserver = new ResizeObserver(() => { if (!popup.hidden && !this.resizing) this.place(); });
        this.resizeObserver.observe(popup);
        for (const type of ['pointerdown','mousedown','mouseup','click','keydown','keyup','keypress','copy','cut','paste','beforeinput']) popup.addEventListener(type, event => event.stopPropagation());
        popup.querySelector('[data-preview-close]').onclick = () => this.hide();
    }
    show(hit) {
        if (!this.valid()) return this.hide();
        this.create(); this.render();
        if (!this.id) return;
        this.anchorRect = hit.rect;
        this.settings = this.readSettings(); this.applySize(); this.updateTiming();
        this.popup.hidden = false;
        this.place();
    }
    place() {
        const rect = this.anchorRect;
        if (!rect) return;
        const width = this.popup.offsetWidth, height = this.popup.offsetHeight, gap = 10;
        let left = Math.max(8, Math.min(innerWidth - width - 8, this.fixedPosition?.left ?? rect.left));
        let top = this.fixedPosition?.top ?? rect.bottom + gap;
        if (!this.fixedPosition && top + height > innerHeight - 8) top = rect.top - height - gap;
        this.popup.style.left = left + 'px';
        this.popup.style.top = Math.max(8, Math.min(innerHeight - height - 8, top)) + 'px';
    }
    render() {
        const m = this.manager, note = m.ctx?.notes.find(n => n.id === this.id);
        if (!note) return this.hide();
        this.markdown = note.markdown;
        const serial = ++this.serial, key = this.key, content = this.popup.querySelector('.et-preview-content');
        content.scrollTop = 0;
        if (!note.markdown.trim()) { content.textContent = '还没有填写笔记'; return; }
        try {
            m._ensureRenderer().renderPreview(content, note.markdown, {
                imageURL: src => m._imageURL(src), renderMath: (tex, display) => m._renderMath(tex, display),
                openLink: url => reqnode('electron').shell.openExternal(url),
                isCurrent: () => serial === this.serial && key === m.ctx?.key && this.valid(),
            });
        } catch (error) { content.textContent = note.markdown; console.warn('[EditingToolbar] Annotation preview:', error); }
    }
    sync() {
        if (!this.id) return;
        const m = this.manager, note = m.ctx?.notes.find(n => n.id === this.id);
        if (!this.valid() || this.key !== m.ctx.key || !note || !m.locations.has(this.id)) return this.hide();
        if (this.popup && !this.popup.hidden && note.markdown !== this.markdown) this.render();
    }
}
