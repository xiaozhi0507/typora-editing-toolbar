const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
function fixture(){
  const frames=[],timers=[],observed=new Set();
  const node=()=>{const classes=new Set();return {dataset:{},attrs:{},events:{},children:[],classList:{toggle(k,v){v?classes.add(k):classes.delete(k)},add:k=>classes.add(k),remove:k=>classes.delete(k),contains:k=>classes.has(k)},before(){},append(...v){this.children.push(...v)},setAttribute(k,v){this.attrs[k]=v},addEventListener(k,v){this.events[k]=v},focus(){this.focused=true},getBoundingClientRect:()=>({top:0,bottom:100})};};
  const box={requestAnimationFrame:f=>(frames.push(f),frames.length),setTimeout:f=>(timers.push(f),timers.length),clearTimeout(){},ResizeObserver:class{constructor(fn){this.fn=fn}observe(x){observed.add(x)}disconnect(){observed.clear()}}};vm.createContext(box);
  vm.runInContext(fs.readFileSync(require.resolve('./ai-chat-navigation.js'),'utf8')+';globalThis.Nav=EditingToolbarAIChatNavigation;',box);
  const messages=Object.assign(node(),{scrollHeight:1000,clientHeight:400,scrollTop:600}),ai={node,messages,turns:[{}],busy:true},nav=new box.Nav(ai);
  const frame=()=>{const pending=frames.splice(0);for(const f of pending)f();};
  return {ai,nav,node,frame,observed};
}
test('streaming follows delayed height changes until the reader scrolls up',()=>{
  const {ai,nav,frame}=fixture();ai.messages.scrollHeight=1200;nav.schedule();frame();assert.equal(ai.messages.scrollTop,1200);
  ai.messages.scrollTop=300;ai.messages.events.scroll();ai.messages.scrollHeight=1500;nav.observer.fn();frame();assert.equal(ai.messages.scrollTop,300);assert.equal(nav.following,false);assert.equal(nav.button.attrs['aria-hidden'],'false');assert.equal(nav.button.dataset.working,'true');
  nav.latest();assert.equal(ai.messages.scrollTop,1500);assert.equal(nav.following,true);assert.equal(nav.button.attrs['aria-hidden'],'true');
});
test('upward input cancels a queued follow before rendering the next frame',()=>{
  const {ai,nav,frame}=fixture();ai.messages.scrollHeight=1200;nav.schedule();ai.messages.events.wheel({deltaY:-100});frame();assert.equal(ai.messages.scrollTop,600);assert.equal(nav.following,false);
});
test('a resize-triggered scroll event cannot switch off following before ResizeObserver runs',()=>{
  const {ai,nav,frame}=fixture();ai.messages.clientHeight=350;ai.messages.events.scroll();assert.equal(nav.following,true);frame();assert.equal(ai.messages.scrollTop,1000);
});
test('completion hides an off-bottom indicator without moving the reader',()=>{
  const {ai,nav,frame}=fixture();ai.messages.scrollTop=100;ai.messages.events.scroll();ai.busy=false;nav.schedule();frame();assert.equal(ai.messages.scrollTop,100);assert.equal(nav.button.dataset.working,'false');assert.equal(nav.button.hidden,true);assert.equal(nav.button.disabled,true);assert.equal(nav.button.tabIndex,-1);
});
test('history reveals the exact turn while busy and rejects stale turns',()=>{
  const {ai,nav,node,frame}=fixture(),article=node(),turn={article};article.isConnected=true;article.getBoundingClientRect=()=>({top:-300,bottom:-200});ai.turns.unshift(turn);
  assert.equal(nav.reveal(turn),true);assert.equal(ai.messages.scrollTop,288);assert.equal(article.focused,true);assert.ok(article.classList.contains('et-ai-turn-located'));nav.schedule();frame();assert.equal(ai.messages.scrollTop,288);assert.equal(nav.reveal({article}),false);
});
test('new conversation resets observation and following without retaining old highlights',()=>{
  const {ai,nav,node,observed,frame}=fixture(),turn={article:node()};turn.article.isConnected=true;ai.turns.push(turn);nav.observe(turn);nav.reveal(turn);ai.turns=[];nav.reset();frame();assert.equal(observed.size,1);assert.equal(nav.following,true);assert.equal(nav.button.disabled,true);assert.equal(turn.article.classList.contains('et-ai-turn-located'),false);
});
test('history jump delegates navigation and leaves draft untouched while busy',()=>{
  const box={};vm.createContext(box);vm.runInContext(fs.readFileSync(require.resolve('./ai-conversations.js'),'utf8')+';globalThis.Conversations=EditingToolbarAIConversations;',box);
  const turn={},draft={text:'保留草稿',quotes:[{text:'引用'}],images:['image']};let revealed,closed=false;
  const c=Object.assign(Object.create(box.Conversations.prototype),{ai:{busy:true,draft,navigation:{reveal:t=>{revealed=t;return true}}},closePopup(){closed=true;}});
  assert.equal(c.jumpToTurn(turn),true);assert.equal(revealed,turn);assert.equal(closed,true);assert.deepEqual(draft,{text:'保留草稿',quotes:[{text:'引用'}],images:['image']});
});
test('duplicate turn errors keep bottom banner hidden; preflight and settings errors remain visible elsewhere',()=>{
  const box={};vm.createContext(box);vm.runInContext(fs.readFileSync(require.resolve('./ai-assistant.js'),'utf8')+';globalThis.AI=EditingToolbarAI;',box);const notices=[];
  const a=Object.assign(Object.create(box.AI.prototype),{status:{dataset:{}},preferencesStatus:{dataset:{}},toolbar:{_showToolbarNotice:s=>notices.push(s)}});
  a.notice('请求中断',true,true);assert.equal(a.status.hidden,true);assert.equal(notices.length,0);
  a.notice('请先选择图片',true);assert.deepEqual(notices,['请先选择图片']);assert.equal(a.status.hidden,true);
  a.preferences={open:true};a.notice('模型名称不能为空',true);assert.equal(a.preferencesStatus.textContent,'模型名称不能为空');assert.equal(a.preferencesStatus.dataset.error,'true');assert.equal(notices.length,1);
});

test('idle and follow mode never expose the indicator during transient overflow',()=>{
  const {ai,nav}=fixture();ai.messages.scrollHeight+=100;nav.update();assert.equal(nav.button.hidden,true);
  ai.messages.events.wheel({deltaY:-100});nav.update();assert.equal(nav.button.hidden,false);
  ai.busy=false;nav.update();assert.equal(nav.button.hidden,true);assert.equal(nav.button.attrs['aria-hidden'],'true');
});
