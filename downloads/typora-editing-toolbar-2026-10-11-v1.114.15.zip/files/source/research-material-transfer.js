Object.assign(EditingToolbarResearchMaterials.prototype,{
    accepts(dt){return !!dt&&[...dt.types].some(t=>['Files','text/plain','text/html','text/uri-list','application/x-et-materials','application/x-et-document-image'].includes(t));},
    storePNG(buffer,ctx){
        if(ctx===this.ctx)this._syncDisk();if(ctx.readonly)throw Error('素材文件只读，无法存入图片');
        if(buffer.length>20*1024*1024)throw Error('图片超过 20 MB');const img=reqnode('electron').nativeImage.createFromBuffer(buffer);if(img.isEmpty())throw Error('无法识别图片');const size=img.getSize();if(size.width>12000||size.height>12000)throw Error('图片尺寸过大');const png=img.toPNG();if(png.length>20*1024*1024)throw Error('PNG 图片超过 20 MB');
        this._prepareStorage(ctx.folder);const src='assets/'+this._hash(png).slice(0,32)+'.png',file=this.path.join(ctx.dir,src);this._mkdirStorage(this.path.dirname(file));if(!this.fs.existsSync(file))this.fs.writeFileSync(file,png,{flag:'wx'});return src;
    },
    addImage(buffer,ctx=this.ctx,title,tabId=this.activeTab){if(ctx!==this.ctx||ctx.readonly)return;const src=this.storePNG(buffer,ctx),extra={tabId};if(title)extra.title=title;return this.add('![图片]('+src+')','image',ctx,extra);},
    importImage(src,documentFile,ctx=this.ctx,tabId=this.activeTab){
        if(/^data:image\/[a-z0-9.+-]+;base64,/i.test(src))return this.addImage(this.Buffer.from(src.slice(src.indexOf(',')+1),'base64'),ctx,undefined,tabId);
        if(/^[a-z]+:/i.test(src)&&!/^file:/i.test(src)&&!this.path.isAbsolute(src))throw Error('网络图片请复制截图后粘贴到素材盘。');
        const file=/^file:/i.test(src)?reqnode('url').fileURLToPath(src):this.path.resolve(documentFile?this.path.dirname(documentFile):ctx.folder||'',decodeURIComponent(src));const stat=this.fs.statSync(file);if(!stat.isFile()||stat.size>20*1024*1024)throw Error('图片文件无效或超过 20 MB');return this.addImage(this.fs.readFileSync(file),ctx,this.path.basename(file),tabId);
    },
    paste(){
        this._switchDocument();if(this.ctx.readonly)return;try{const c=reqnode('electron').clipboard,image=c.readImage();if(!image.isEmpty())this.addImage(image.toPNG());else{const text=c.readText();if(text.trim())this.add(text,/^\s*\${1,2}[\s\S]*\${1,2}\s*$/.test(text)?'math':'text');}}catch(e){this._status(e.message,true);}
    },
    async receive(dt){
        this._switchDocument();const ctx=this.ctx,tabId=this.activeTab;if(ctx.readonly)return;
        try{
            const own=this.materialDrag(dt);if(own){if(own.ctx===ctx){for(const n of own.items)n.tabId=tabId;this._touch();}else{this._copyAssets(own.ctx.dir,ctx.dir,own.items);for(const n of own.items)this.add(n.markdown,n.kind,ctx,{title:n.title,tabId});}return;}
            if(this.inboundDrag?.file===this._docKey()&&dt.types.includes('application/x-et-document-image'))return this.importImage(this.inboundDrag.image,File.bundle?.filePath,ctx,tabId);
            const files=[...dt.files].filter(f=>/^image\//.test(f.type)||/\.(png|jpe?g|gif|webp|bmp)$/i.test(f.name));if(files.length){for(const f of files){if(f.size>20*1024*1024)throw Error('图片超过 20 MB');const bytes=this.Buffer.from(await f.arrayBuffer());if(ctx!==this.ctx)return;this.addImage(bytes,ctx,f.name,tabId);}return;}
            const html=dt.getData('text/html');if(html){const doc=new DOMParser().parseFromString(html,'text/html'),image=doc.querySelector('img');if(image&&!doc.body.textContent.trim())return this.importImage(image.getAttribute('src'),File.bundle?.filePath,ctx,tabId);}
            const uri=dt.getData('text/uri-list').split(/\r?\n/).find(s=>s&&!s.startsWith('#'));if(uri&&/^file:/i.test(uri)&&/\.(png|jpe?g|gif|webp|bmp)$/i.test(uri))return this.importImage(uri,File.bundle?.filePath,ctx,tabId);
            const text=dt.getData('text/plain');if(text.trim())this.add(text,/^\s*\${1,2}[\s\S]*\${1,2}\s*$/.test(text)?'math':'text',ctx,{tabId});
        }catch(e){this._status('素材未收集：'+e.message,true);}
    },
    startDrag(event,item){
        if(!event.dataTransfer)return;if(!this.picked.has(item.id)){this.picked.clear();this.picked.add(item.id);}this._paintSelection();const items=this._visible().filter(n=>this.picked.has(n.id));
        try{const session={token:this._id(),ctx:this.ctx,items},markdown=this.bodyMarkdown(session);this.dragSession=session;event.dataTransfer.effectAllowed='copy';event.dataTransfer.setData('application/x-et-materials',session.token);event.dataTransfer.setData('text/plain',markdown);this._closePopover();this.cardMenu?.remove();}catch(error){this.dragSession=null;event.preventDefault();this._status(error.message,true);}
    },
    materialDrag(dt){return dt&&this.dragSession&&dt.getData('application/x-et-materials')===this.dragSession.token?this.dragSession:null;},
    bodyMarkdown(session){
        const folder=File.bundle?.filePath?this.path.dirname(File.bundle.filePath):this._scope().folder;
        return session.items.map(n=>n.markdown.replace(/assets\/[a-f0-9]{32}\.(?:png|mp4|webm|ogg|mov|m4v)/g,src=>{const abs=this.path.join(session.ctx.dir,src);if(!this.fs.existsSync(abs))throw Error('素材附件不存在');const relative=folder?this.path.relative(folder,abs):null;return relative&&!this.path.isAbsolute(relative)?relative.split(this.path.sep).map(s=>encodeURIComponent(s).replace(/[!'()*]/g,c=>'%'+c.charCodeAt(0).toString(16))).join('/'):reqnode('url').pathToFileURL(abs).href;})).join('\n\n');
    },
    dropIntoEditor(event,manager){
        const drag=this.materialDrag(event.dataTransfer);if(!drag)return null;if(manager.ctx.readonly)throw Error('当前笔记只读');const note=manager._selected();if(!note)throw Error('请先打开一篇笔记');this._copyAssets(drag.ctx.dir,manager.ctx.dir,drag.items);for(const n of drag.items)if(n.imageOriginals)note.imageOriginals={...note.imageOriginals,...n.imageOriginals};return drag.items.map(n=>n.markdown).join('\n\n');
    },
    dropIntoBody(e){
        const drag=this.materialDrag(e.dataTransfer);if(!drag)return;e.preventDefault();e.stopImmediatePropagation();
        try{
            if(File.editor?.sourceView?.inSourceMode)throw Error('请退出源代码模式后拖入素材。');const write=document.getElementById('write');let range=document.caretRangeFromPoint(e.clientX,e.clientY);
            if(!range||!write.contains(range.startContainer)){range=document.createRange();range.selectNodeContents(write);range.collapse(false);}range.collapse(true);
            const markdown=this.bodyMarkdown(drag);write.focus({preventScroll:true});const selection=getSelection();selection.removeAllRanges();selection.addRange(range);File.editor.selection?.setRange?.(range,true);this.toolbar.savedRange=range.cloneRange();
            if(!this.toolbar._pasteText(markdown))throw Error('请点击正文中的插入位置后重试。');this.toolbar.hide();
        }catch(error){this._status(error.message,true);}
    },
    _wireDrag(){
        // Typora cancels all drags from #write at document bubble phase. Allow image copies only.
        document.addEventListener('dragstart',e=>{const img=e.target.closest?.('#write img');if(img){this.inboundDrag={image:img.getAttribute('src'),file:this._docKey()};e.dataTransfer.setData('application/x-et-document-image','1');e.dataTransfer.effectAllowed='copy';e.stopPropagation();}},true);
        document.addEventListener('dragend',()=>{this.inboundDrag=null;this.dragSession=null;this.panel.classList.remove('drag-over');this._renderList();},true);
        document.addEventListener('dragover',e=>{if(document.getElementById('write')?.contains(e.target)&&this.dragSession&&e.dataTransfer.types.includes('application/x-et-materials')){e.preventDefault();e.stopImmediatePropagation();e.dataTransfer.dropEffect='copy';}},true);
        document.addEventListener('drop',e=>{if(document.getElementById('write')?.contains(e.target)&&this.materialDrag(e.dataTransfer))this.dropIntoBody(e);},true);
    }
});
