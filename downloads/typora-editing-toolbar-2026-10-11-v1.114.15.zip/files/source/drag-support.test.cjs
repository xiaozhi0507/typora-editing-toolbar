const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),{JSDOM}=require('jsdom');
const support=require('./drag-support.cjs'),Scope=require('./ai-module-scope.cjs'),build=require('./build-drag-support.cjs');
test('separate gestures coalesce independently, cancel pending paint and can resume',()=>{
 const frames=new Map();let id=0,a=0,b=0;const request=fn=>{frames.set(++id,fn);return id},cancel=id=>frames.delete(id);
 const first=support.frame(()=>a++,request,cancel),second=support.frame(()=>b++,request,cancel);
 for(let i=0;i<100;i++){first.queue();second.queue();}assert.equal(frames.size,2);
 first.cancel();const flush=()=>{const tasks=[...frames.values()];frames.clear();tasks.forEach(f=>f());};flush();assert.equal(a,0);assert.equal(b,1);
 first.queue();flush();assert.equal(a,1);first.cancel();assert.equal(frames.size,0);
});
test('new host shares one implementation without loading fallback styles',t=>{
 const dom=new JSDOM('<body></body>');t.after(()=>dom.window.close());
 const actual=vm.runInNewContext(build()+';ETDragSupport',{host:{toolbar:{dragSupport:support}},document:dom.window.document});
 assert.equal(actual,support);assert.equal(dom.window.document.querySelectorAll('[data-et-drag-fallback]').length,0);
});
test('old host gets scoped fallback; repeated AI disable removes style, shield and queued frame',t=>{
 const dom=new JSDOM('<body></body>',{pretendToBeVisual:true});t.after(()=>dom.window.close());
 for(let i=0;i<3;i++){
  const scope=new Scope(dom.window,dom.window.document);
  const fallback=vm.runInNewContext(build()+';ETDragSupport',{host:{toolbar:{}},document:scope.document});
  assert.equal(fallback.version,1);assert.equal(dom.window.document.querySelectorAll('[data-et-drag-fallback]').length,1);
  const shield=fallback.shield(scope.document,'et-workspace-drag-shield');assert.equal(shield.tabIndex,-1);
  fallback.frame(()=>assert.fail('cancelled paint ran'),scope.requestAnimationFrame,scope.cancelAnimationFrame).queue();assert.equal(scope.frames.size,1);
  scope.close();assert.equal(scope.frames.size,0);assert.equal(dom.window.document.querySelectorAll('[data-et-drag-fallback],.et-workspace-drag-shield').length,0);
 }
});
