const {test}=require('node:test'),assert=require('node:assert/strict'),http=require('node:http');
const Client=require('./ai-client.cjs');
const event=p=>'data: '+(typeof p==='string'?p:JSON.stringify(p))+'\n\n';
async function request(t,data,{protocol='openai-chat',type='text/event-stream',status=200,limits,...callbacks}={}) {
  const server=http.createServer((req,res)=>{req.resume();res.writeHead(status,type?{'Content-Type':type}:{});const bytes=Buffer.from(data);for(let i=0;i<bytes.length;i+=16381)res.write(bytes.subarray(i,i+16381));res.end();});
  await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>{server.closeAllConnections();server.close();});
  class LimitedClient extends Client {static responseLimits={...Client.responseLimits,...limits};}
  return new LimitedClient(require).request({model:'mock',url:'http://127.0.0.1:'+server.address().port,protocol,documentEdit:true},'',[{role:'user',content:'test'}],callbacks);
}
test('token-sized thinking packets exceeding the former 4 MiB wire cap still reach the final answer',async t=>{
  const thought='检查α。',packet=event({id:'chatcmpl-'+ 'a'.repeat(100),object:'chat.completion.chunk',created:1800000000,model:'deepseek-flash',choices:[{index:0,delta:{reasoning_content:thought},finish_reason:null}],usage:null});
  const count=18000,data=packet.repeat(count)+event({choices:[{delta:{content:'最终答案'},finish_reason:'stop'}]})+event('[DONE]');
  assert.ok(Buffer.byteLength(data)>4*1024*1024);
  let last='';const r=await request(t,data,{onReasoning:s=>last=s});assert.equal(r.text,'最终答案');assert.equal(r.reasoning,thought.repeat(count));assert.equal(last,r.reasoning);
});
test('SSE without a content-type uses the streaming budget, including split UTF-8',async t=>{
  const data=event({choices:[{delta:{reasoning_content:'中文α'.repeat(4000)}}]})+event({choices:[{delta:{content:'完成'},finish_reason:'stop'}]})+event('[DONE]');
  const r=await request(t,data,{type:null,limits:{jsonBytes:1000}});assert.equal(r.text,'完成');assert.equal(r.reasoning,'中文α'.repeat(4000));
});
test('decoded output has a separate cap and keeps the last valid partial text',async t=>{
  let answer='',reasoning='';const data=event({choices:[{delta:{content:'已收到',reasoning_content:'过程'}}]})+event({choices:[{delta:{reasoning_content:'x'.repeat(100)},finish_reason:'stop'}]})+event('[DONE]');
  await assert.rejects(request(t,data,{limits:{outputChars:30},onText:s=>answer=s,onReasoning:s=>reasoning=s}),/模型输出过长.*Max Tokens/);assert.equal(answer,'已收到');assert.equal(reasoning,'过程');
});
test('oversized edit arguments are rejected before successful completion across protocols',async t=>{
  const args=JSON.stringify({replacement:'x'.repeat(100)});
  for(const [protocol,packets]of [
    ['openai-chat',[{choices:[{delta:{tool_calls:[{index:0,id:'t1',function:{name:'edit_current_document',arguments:args}}]},finish_reason:'tool_calls'}]},'[DONE]']],
    ['openai-responses',[{type:'response.completed',response:{status:'completed',output:[{id:'t1',call_id:'c1',type:'function_call',name:'edit_current_document',arguments:args}]}}]],
    ['anthropic-messages',[{type:'content_block_start',index:0,content_block:{id:'t1',type:'tool_use',name:'edit_current_document',input:{}}},{type:'content_block_delta',index:0,delta:{type:'input_json_delta',partial_json:args}},{type:'content_block_stop',index:0},{type:'message_stop'}]]
  ])await assert.rejects(request(t,packets.map(event).join(''),{protocol,limits:{outputChars:60}}),/模型输出过长/);
});
test('Responses final reasoning snapshots obey the text cap without counting replayed summaries twice',async t=>{
  const packets=[{type:'response.reasoning_summary_text.delta',item_id:'r1',delta:'过程'},{type:'response.output_text.delta',delta:'回答'},{type:'response.completed',response:{status:'completed',output:[{type:'reasoning',summary:[{type:'summary_text',text:'过程'}]}]}}];
  assert.equal((await request(t,packets.map(event).join(''),{protocol:'openai-responses',limits:{outputChars:4}})).text,'回答');
  packets[2].response.output[0].summary[0].text='x'.repeat(50);
  await assert.rejects(request(t,packets.map(event).join(''),{protocol:'openai-responses',limits:{outputChars:20}}),/模型输出过长/);
});
test('single, unfinished and multiline SSE events are bounded',async t=>{
  for(const data of ['data: '+'x'.repeat(300),'data: '+'x'.repeat(300)+'\n\n',('data: '+'x'.repeat(50)+'\n').repeat(6)])
    await assert.rejects(request(t,data,{limits:{eventChars:200}}),/单条响应过大/);
});
test('ordinary JSON and HTTP error bodies retain a bounded byte budget',async t=>{
  const data=JSON.stringify({choices:[{message:{content:'中'.repeat(100)},finish_reason:'stop'}]});
  for(const options of [{type:'application/json'},{type:null},{type:'application/json',status:500}])
    await assert.rejects(request(t,data,{...options,limits:{jsonBytes:200}}),/非流式响应过大/);
});
test('heartbeat/ignored event traffic is still bounded and incomplete streams stay errors',async t=>{
  await assert.rejects(request(t,': keepalive\n\n'.repeat(100),{limits:{wireBytes:500}}),/流量超过接收上限/);
  await assert.rejects(request(t,event({choices:[{delta:{content:'部分回答'}}]})),/连接提前结束/);
});

test('large token-sized tool arguments coalesce UI events while preserving exact final JSON',async t=>{const args=JSON.stringify({summary:'edit',edits:[{old_text:'old',new_text:'x'.repeat(20000)}]}),events=[];const packets=[event({choices:[{delta:{tool_calls:[{index:0,id:'large',function:{name:'edit_current_document',arguments:''}}]}}]})];for(let i=0;i<args.length;i+=4)packets.push(event({choices:[{delta:{tool_calls:[{index:0,function:{arguments:args.slice(i,i+4)}}]}}]}));packets.push(event({choices:[{delta:{},finish_reason:'tool_calls'}]}),event('[DONE]'));const r=await request(t,packets.join(''),{onEvent:e=>{if(e.type==='tool')events.push(e);}});assert.equal(r.toolCalls[0].arguments,args);assert.equal(events.at(-1).arguments,args);assert.ok(events.length<100,'tool UI event count '+events.length);});
