// Isolated ordinary browser session for CNKI. No Node, preload, host bridge, or CAPTCHA automation.
class KnowledgeLibraryCNKIBrowser {
  constructor(host){this.host=host;this.tail=Promise.resolve();this.blocked=false;}
  mount(){
    if(this.panel)return;
    const panel=this.panel=document.createElement('div');panel.id='et-cnki-browser';
    panel.style.cssText='position:fixed;inset:5vh 5vw;z-index:2147483000;display:flex;flex-direction:column;background:#fff;color:#222;border:1px solid #aaa;border-radius:8px;box-shadow:0 15px 65px #0005;overflow:hidden';
    const header=document.createElement('div');header.style.cssText='display:flex;align-items:center;gap:12px;padding:12px 16px;border-bottom:1px solid #ddd;font:14px system-ui';
    const title=document.createElement('strong');title.textContent='知网验证';header.append(title);
    const hint=document.createElement('span');hint.textContent='请人工完成下方验证，再点“完成验证”继续更新。关闭后本轮不再弹出。';hint.style.flex='1';header.append(hint);
    for(const [label,action]of [['完成验证',()=>this.finish()],['关闭',()=>this.cancel()]]){const b=document.createElement('button');b.textContent=label;b.type='button';b.style.cssText='padding:5px 12px;color:#222;background:#f5f5f5;border:1px solid #ccc;border-radius:4px';b.addEventListener('click',action);header.append(b);}
    panel.append(header);
    const view=this.view=document.createElement('webview');view.setAttribute('partition','persist:et-knowledge-cnki');view.setAttribute('webpreferences','contextIsolation=yes,sandbox=yes,nodeIntegration=no,nodeIntegrationInSubFrames=no');view.style.cssText='display:flex;flex:1;width:100%;min-height:0';
    const allowed=url=>{try{const u=new URL(url);return u.protocol==='https:'&&/(^|\.)cnki\.net$/i.test(u.hostname);}catch(_){return false;}};
    for(const event of ['will-navigate','will-redirect'])view.addEventListener(event,e=>{if(!allowed(e.url)){e.preventDefault();this.blocked=true;}});
    view.addEventListener('new-window',e=>e.preventDefault());
    view.src='about:blank';this.ready=new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(Error('知网浏览器未就绪')),12000);view.addEventListener('dom-ready',()=>{clearTimeout(timeout);resolve();},{once:true});});this.ready.catch(()=>{});
    panel.append(view);document.body.append(panel);this.hide();
  }
  hide(){if(!this.panel)return;this.visible=false;this.panel.style.visibility='hidden';this.panel.style.pointerEvents='none';}
  cancel(){const pending=this.verification;this.verification=null;this.hide();pending?.resolve(false);}
  waitForVerification(){
    if(this.verification)return this.verification.promise;
    this.mount();const pending={};pending.promise=new Promise(resolve=>pending.resolve=resolve);this.verification=pending;
    void this.show();return pending.promise;
  }
  async navigate(){
    if(this.navigation)return this.navigation;
    this.navigation=this.loadPage();try{await this.navigation;this.loaded=true;}finally{this.navigation=null;}
  }
  async loadPage(){
    this.mount();await this.ready;
    const view=this.view;
    await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>done(Error('知网页面加载超时')),20000);const ready=()=>done(),fail=e=>{if(e.isMainFrame!==false&&e.errorCode!==-3)done(Error('知网页面加载失败'));};function done(error){clearTimeout(timeout);view.removeEventListener('dom-ready',ready);view.removeEventListener('did-fail-load',fail);error?reject(error):resolve();}view.addEventListener('dom-ready',ready);view.addEventListener('did-fail-load',fail);view.src='https://kns.cnki.net/kns8s/';});
  }
  async show(){this.mount();this.visible=true;this.panel.style.visibility='visible';this.panel.style.pointerEvents='auto';try{if(!this.loaded)await this.navigate();else if((this.blocked||this.host.metrics?.cnkiVerificationRequired)&&!(await this.inspect()).challenge)await this.navigate();if(this.visible)this.view.focus();}catch(e){if(this.visible)this.host.notice(e.message);}}
  async finish(){
    const pending=this.verification,metrics=this.host.metrics;
    try{const state=await this.inspect();if(!this.visible||pending!==this.verification||metrics!==this.host.metrics)return;
      if(!state.valid||state.challenge){this.host.notice('请先完成知网页面中的安全验证。');return;}
      this.blocked=false;if(metrics)metrics.cnkiVerificationRequired=false;
      for(const [key,failure]of metrics?.failures||[])if(key.startsWith('cnki:')&&failure.code==='CNKI_VERIFY')metrics.failures.delete(key);
      this.verification=null;this.hide();pending?.resolve(true);this.host.notice(pending?'验证已完成，正在继续更新文献指标…':'知网页面已就绪，可在“被引数”的列设置中更新指标。');
    }catch(e){this.host.notice(e.message);}
  }
  async inspect(){return this.view.executeJavaScript(`(()=>({valid:location.origin==='https://kns.cnki.net',challenge:/安全验证|访问验证|验证码|captcha/i.test(document.title+' '+(document.body?.innerText||'').slice(0,500))}))()`);}
  request(url,options){const job=this.tail.then(()=>this.requestOnce(url,options));this.tail=job.catch(()=>{});return job;}
  async requestOnce(url,options){
    if(url!=='https://kns.cnki.net/kns8s/brief/grid'||options.method!=='POST')throw Error('不支持的知网请求');
    if(this.blocked)throw Object.assign(Error('知网需要安全验证，请在“被引数”的列设置中打开“知网验证”，完成后重试'),{code:'CNKI_VERIFY'});
    this.mount();if(!this.loaded){await this.navigate();this.loaded=true;}
    const state=await this.inspect();if(!state.valid||state.challenge){this.blocked=true;throw Object.assign(Error('知网需要安全验证，请在“被引数”的列设置中打开“知网验证”，完成后重试'),{code:'CNKI_VERIFY'});}
    const result=await this.view.executeJavaScript(`(async(body)=>{const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);let reader;try{const r=await fetch('/kns8s/brief/grid',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Accept':'text/html,application/json'},body,credentials:'same-origin',redirect:'error',signal:controller.signal});if(r.status!==200){await r.body?.cancel();return {status:r.status,retryAfter:r.headers.get('Retry-After')};}reader=r.body.getReader();const parts=[];let size=0;for(;;){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>4*1024*1024){await reader.cancel();return {error:'知网响应过大'};}parts.push(value);}const data=new Uint8Array(size);let offset=0;for(const part of parts){data.set(part,offset);offset+=part.length;}return {status:r.status,body:new TextDecoder().decode(data)};}catch(e){return {error:'知网连接失败或超时，请稍后重试'};}finally{clearTimeout(timer);reader?.releaseLock();}})(${JSON.stringify(options.body)})`);
    if(result.status===403||result.status===401){this.blocked=true;throw Object.assign(Error('知网需要验证或登录，请打开“知网验证”后重试'),{code:'CNKI_VERIFY',status:result.status});}
    if(result.status!==200)throw Object.assign(Error(result.error||'知网返回 HTTP '+result.status),{status:result.status,retryAfter:result.retryAfter});
    return result.body;
  }
}
