// Independent panels stay in place in the DOM: moving an iframe would reload its editor.
class EditingToolbarPanelWorkspace {
  constructor(toolbar) {
    this.frame=ETDragSupport.frame(()=>{try{this.paint();}catch(error){this.finish(true);this.reportMotionError(error);}},requestAnimationFrame,cancelAnimationFrame);
    this.toolbar=toolbar;this.key='et-panel-workspace-v1';this.entries=new Map();this.z=100110;
    try{this.saved=JSON.parse(localStorage.getItem(this.key))||{};}catch{this.saved={};}
    this.width=Number(this.saved.width)||420;this.count=Math.max(1,Math.min(3,Number(this.saved.count)||1));
    this.weights=Array.isArray(this.saved.weights)&&this.saved.weights.length===this.count?this.saved.weights.map(v=>Math.max(.1,Number(v)||1)):Array(this.count).fill(1);
    this.slots=Array(this.count).fill(null);
    document.addEventListener('pointerdown',e=>this.start(e),true);
    document.addEventListener('pointermove',e=>this.move(e),true);
    document.addEventListener('pointerup',e=>{if(this.drag?.pointerId===e.pointerId){this.move(e);this.finish(false);}},true);
    document.addEventListener('pointercancel',()=>this.finish(true),true);
    document.addEventListener('click',e=>{
      if(performance.now()<(this.suppressClickUntil||0)&&this.suppressClickTarget?.contains(e.target)){e.preventDefault();e.stopImmediatePropagation();return;}
      const id=this.toolbarId(e.target);if(!id)return;
      e.preventDefault();e.stopImmediatePropagation();if(id==='terminal'){void this.toolbar.terminal.toggle();return;}this.openDock(id);
    },true);
    document.addEventListener('keydown',e=>{
      if(e.key==='Escape'&&(this.drag||this.picker&&!this.picker.hidden)){e.preventDefault();e.stopImmediatePropagation();this.finish(true);this.hidePicker();}
    },true);
    document.addEventListener('lostpointercapture',e=>{if(this.drag?.active&&e.target===this.drag.shield)this.finish(true);},true);
    // Focusing a note iframe also blurs the parent window, although the document
    // still has focus. Only leaving the application should cancel the gesture.
    window.addEventListener('blur',()=>{if(!document.hasFocus()){this.finish(true);this.hidePicker();}});
    window.addEventListener('resize',()=>{this.finish(true);this.hidePicker();this.scheduleLayout();},true);
    window.addEventListener('optimizedResize',()=>this.scheduleLayout());
    // A restored/background window may receive its final size after the first event.
    window.visualViewport?.addEventListener('resize',()=>this.scheduleLayout());
    window.addEventListener('pageshow',()=>this.scheduleLayout());
    document.addEventListener('visibilitychange',()=>{if(!document.hidden)this.scheduleLayout();});
  }
  id(owner){return owner===this.toolbar.knowledgeLibrary?'library':owner===this.toolbar.aiAssistant?'ai':owner.isManualMark?'marks':owner.isDocumentNote?'notes':'annotations';}
  owner(id){if(id==='terminal')return this.toolbar.terminal;return this.toolbar[{library:'knowledgeLibrary',ai:'aiAssistant',notes:'documentNotes',annotations:'annotations',marks:'manualMarks'}[id]];}
  toolbarId(target){const button=target.closest('#editing-toolbar-top [data-action],#editing-toolbar [data-action]');return {terminal:'terminal','knowledge-library':'library','ai-assistant':'ai','document-note':'notes',annotation:'annotations','manual-mark':'marks'}[button?.dataset.action];}
  availableCount(){return Math.max(1,Math.min(3,Math.floor((innerHeight-24)/220)));}
  openDock(id){
    const owner=this.owner(id);if(!owner)return;
    if(id==='library'){void owner.toggle();return;}
    // Keep selection-to-annotation behavior on a click, but never create a note during a drag.
    if(['ai','notes'].includes(id)||id==='annotations'&&!this.toolbar.documentNotes?.panel.contains(document.activeElement))owner.openFromSelection();else owner.open();
    const entry=this.ensure(owner);if(!this.active(entry))return;
    if(entry.mode==='dock'&&this.slots.includes(id)){this.layout();this.focus(entry);return;}
    const occupied=this.visibleDock().map(item=>item.entry.id),limit=this.availableCount();
    if(occupied.length>=limit){const displaced=(this.order||[]).find(other=>occupied.includes(other))||occupied[0];occupied.splice(occupied.indexOf(displaced),1);this.entries.get(displaced).mode='float';}
    this.count=Math.min(limit,Math.max(this.count,occupied.length+1));this.slots=[...occupied,id,...Array(this.count-occupied.length-1).fill(null)];this.weights=Array(this.count).fill(1);entry.mode='dock';
    this.hidePicker();this.layout();this.focus(entry);this.persist();
  }
  title(id){return {terminal:'终端',library:'知识库',ai:'AI 阅读助手',notes:'笔记',annotations:'注释',marks:'标注'}[id];}
  active(entry){return entry&&!entry.owner.panel.hidden&&!entry.owner.panel.classList.contains('et-library-note-docked');}
  bounds(){return{left:8,top:8,right:innerWidth-8,bottom:innerHeight-26};}
  documentLeft(){return File.editor?.library?.isSidebarShown()?Math.max(0,Math.min(innerWidth,document.getElementById('typora-sidebar')?.getBoundingClientRect().width||0)):0;}
  maxWidth(){const sidebar=File.editor?.library?.isSidebarShown()?document.getElementById('typora-sidebar')?.getBoundingClientRect().width||0:0;return Math.max(280,innerWidth-sidebar-220);}
  rect(rect={}){const b=this.bounds(),width=Math.min(Math.max(300,Number(rect.width)||400),b.right-b.left),height=Math.min(Math.max(240,Number(rect.height)||540),b.bottom-b.top);return {left:Math.max(b.left,Math.min(Number.isFinite(Number(rect.left))?Number(rect.left):innerWidth-width-30,b.right-width)),top:Math.max(b.top,Math.min(Number.isFinite(Number(rect.top))?Number(rect.top):72,b.bottom-height)),width,height};}
  ensure(owner){
    const id=this.id(owner);if(this.entries.has(id))return this.entries.get(id);
    const p=owner.panel;if(!p)return null;
    const saved=this.saved.panels?.[id],legacy=id==='ai'?owner.config:null;
    const entry={id,owner,mode:saved?.mode||(id==='library'?'full':id==='ai'?legacy?.layout||'dock':'float'),rect:this.rect(saved?.rect||{width:id==='library'?880:legacy?.width||owner.width||400,height:id==='library'?620:legacy?.height,left:legacy?.position?.x??Math.min(110+this.entries.size*28,innerWidth-440),top:legacy?.position?.y??(80+this.entries.size*28)})};
    this.entries.set(id,entry);p.classList.add('et-workspace-panel');p.dataset.workspaceId=id;
    if(entry.mode==='dock'){
      const slot=Number.isInteger(saved?.slot)?saved.slot:0;
      if(slot<this.count&&!this.slots[slot])this.slots[slot]=id;else entry.mode='float';
    }
    const header=p.querySelector(id==='ai'?'.et-ai-header':'header');header.classList.add('et-workspace-header');
    const button=id==='ai'?p.querySelector('[data-ai=layout]'):document.createElement('button');
    if(id!=='ai'){button.type='button';button.className='et-workspace-layout';header.insertBefore(button,header.lastElementChild);}
    button.title='窗口布局';button.setAttribute('aria-label',this.title(id)+'窗口布局');button.setAttribute('aria-haspopup','dialog');
    button.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3.5" y="4.5" width="17" height="15" rx="2"/><path d="M14 5v14M14 12h6"/></svg>';
    button.addEventListener('click',e=>{e.preventDefault();e.stopImmediatePropagation();this.showPicker(id);});
    for(const edge of ['n','s','e','w','ne','nw','se','sw']){const h=document.createElement('div');h.className='et-workspace-resize';h.dataset.wsEdge=edge;h.setAttribute('role','separator');h.setAttribute('aria-label','调整'+this.title(id)+'大小 '+edge);h.tabIndex=edge==='se'?0:-1;p.append(h);h.addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key))return;e.preventDefault();this.float(id);entry.rect=this.rect({...entry.rect,width:entry.rect.width+(e.key==='ArrowRight'?20:e.key==='ArrowLeft'?-20:0),height:entry.rect.height+(e.key==='ArrowDown'?20:e.key==='ArrowUp'?-20:0)});this.layout();this.persist();});}
    p.addEventListener('pointerdown',()=>this.focus(entry));
    return entry;
  }
  focus(entry){if(!entry)return;this.order=(this.order||[]).filter(id=>id!==entry.id);this.order.push(entry.id);this.order.forEach((id,i)=>{const e=this.entries.get(id);e.owner.panel.style.zIndex=String((e.mode==='full'?100120:e.mode==='dock'?100080:100090)+i);e.owner.notePane?.schedule();});}
  opened(owner){const e=this.ensure(owner);if(!e||this.openingDrop===e)return;this.layout();this.focus(e);this.persist();}
  closed(owner){if(this.drag?.entry?.owner===owner)this.finish(true);this.hidePicker();this.layout();}
  layoutOwner(owner){if(!owner.panel||owner.panel.hidden||owner.panel.classList.contains('et-library-note-docked'))return false;this.ensure(owner);if(!this.drag?.active)this.layout();return true;}
  dockEntries(){return this.slots.map(id=>this.entries.get(id));}
  visibleDock(){return this.slots.flatMap((id,slot)=>{const entry=this.entries.get(id);return this.active(entry)&&entry.mode==='dock'?[{entry,slot}]:[];});}
  visibleDockRects(items=this.visibleDock()){return this.dockRects(items.length,items.map(item=>this.weights[item.slot]||1));}
  activeDockPanel(){return this.dockEntries().find(e=>e?.mode==='dock'&&this.active(e))?.owner.panel;}
  dockWidth(){return this.activeDockPanel()?this.width:0;}
  applyRect(p,r){for(const k of ['left','top','width','height']){const value=r[k]+'px';if(p.style[k]!==value)p.style[k]=value;}if(p.style.right!=='auto')p.style.right='auto';if(p.style.bottom!=='auto')p.style.bottom='auto';}
  dockRects(count=this.count,weights=this.weights){
    const height=innerHeight-24-(this.toolbar.terminal?.rightReservation||0),sum=weights.reduce((a,b)=>a+b,0),minimum=Math.min(220,height/count);
    const sizes=weights.map(w=>height*w/sum),deficit=sizes.reduce((n,h)=>n+Math.max(0,minimum-h),0),room=sizes.reduce((n,h)=>n+Math.max(0,h-minimum),0);
    // Reopening a hidden slot must not reuse a ratio that crushes its neighbour.
    let y=0;return Array.from({length:count},(_,i)=>{const raw=sizes[i],h=raw<minimum?minimum:raw-(room?deficit*(raw-minimum)/room:0),r={left:innerWidth-this.width,top:y,width:this.width,height:h};y+=h;return r;});
  }
  inset(width){
    // Local geometric writes avoid inherited custom-property invalidation on formula-heavy documents.
    if(!this.insetNodes)this.insetNodes=[...[...document.querySelectorAll('content')].map(node=>({node,prop:'right'})),...[...document.querySelectorAll('#editing-toolbar-top-host')].map(node=>({node,prop:'max-width'}))].map(i=>({...i,value:i.node.style.getPropertyValue(i.prop),priority:i.node.style.getPropertyPriority(i.prop)}));
    for(const i of this.insetNodes){if(i.prop==='right'&&!i.node.hasAttribute('data-et-workspace-inset'))i.node.setAttribute('data-et-workspace-inset','');const value=i.prop==='right'?width+'px':width?'calc(100vw - '+width+'px - 16px)':'100%';if(i.node.style.getPropertyValue(i.prop)!==value)i.node.style.setProperty(i.prop,value,'important');}
  }
  liveResize(){return !this.toolbar?.splitView?.enabled&&!!(this.drag?.active&&this.drag.divider!==undefined||this.toolbar?.sidebarMotion?.drag);}
  scheduleLayout(){
    if(this.liveResize()||this.layoutFrame)return;
    this.layoutFrame=requestAnimationFrame(()=>{this.layoutFrame=0;this.layout();});
  }
  layout(){
    if(this.liveResize()||this.layingOut||this.layoutFrame)return;this.layingOut=true;
    try{
      this.width=Math.max(Math.min(280,innerWidth-16),Math.min(this.drag?.active&&this.drag.maxWidth||this.maxWidth(),this.width));
      this.toolbar.splitView?.restore();
      this.toolbar.terminal?.layout(true);
      const available=Math.max(1,Math.min(3,Math.floor((innerHeight-24-(this.toolbar.terminal?.rightReservation||0))/220)));
      if(this.count>available){for(const id of this.slots.slice(available)){const e=this.entries.get(id);if(e)e.mode='float';}this.count=available;this.slots.length=available;this.weights=Array(available).fill(1);}
      const items=this.visibleDock(),dock=this.visibleDockRects(items);
      for(const entry of this.entries.values()){
        if(!this.active(entry))continue;const p=entry.owner.panel;
        if(entry.id==='library'&&entry.mode==='full'){p.dataset.layout='full';p.style.transform='';p.style.zIndex='100120';this.applyRect(p,{left:0,top:0,width:innerWidth,height:innerHeight});entry.owner.syncWorkspace?.('full');continue;}
        const slot=items.findIndex(item=>item.entry===entry),isDock=slot>=0;
        const mode=isDock?'dock':'float',compact=String((isDock?dock[slot].height:entry.rect.height)<430);if(p.dataset.layout!==mode)p.dataset.layout=mode;if(p.dataset.wsCompact!==compact)p.dataset.wsCompact=compact;if(p.style.transform)p.style.transform='';
        if(!isDock)entry.rect=this.rect(entry.rect);
        const z=String((isDock?100080:100090)+Math.max(0,(this.order||[]).indexOf(entry.id)));if(p.style.zIndex!==z)p.style.zIndex=z;
        this.applyRect(p,isDock?dock[slot]:entry.rect);
        entry.owner.syncWorkspace?.(mode);
      }
      // Legacy module classes no longer control the editor's geometry.
      document.body.classList.remove('et-ai-docked','et-annotations-open');
      this.inset(this.dockWidth());this.renderDockTools();this.toolbar.splitView?.layout();this.toolbar.codeEditor?.layout();
    }finally{this.layingOut=false;}
  }
  renderDockTools(){
    if(!this.dockTools){this.dockTools=document.createElement('div');this.dockTools.className='et-workspace-dock-tools';document.body.append(this.dockTools);}
    const items=this.visibleDock(),hidden=!items.length;if(this.dockTools.hidden!==hidden)this.dockTools.hidden=hidden;if(hidden)return;
    const rects=this.visibleDockRects(items),signature=items.map(item=>item.entry.id+':'+item.slot).join('|');
    if(this.dockTools.dataset.signature!==signature){
      this.dockTools.dataset.signature=signature;this.dockTools.replaceChildren();
      const width=document.createElement('div');width.className='et-workspace-divider et-workspace-width';width.dataset.wsDivider='width';width.setAttribute('role','separator');width.setAttribute('aria-label','调整右侧工作区宽度');width.setAttribute('aria-orientation','vertical');width.tabIndex=0;this.dockTools.append(width);
      width.onkeydown=e=>{if(!['ArrowLeft','ArrowRight'].includes(e.key))return;e.preventDefault();this.width+=e.key==='ArrowLeft'?20:-20;this.layout();this.persist();this.dockTools.firstChild.focus();};
      items.slice(0,-1).forEach((item,i)=>{const h=document.createElement('div');h.className='et-workspace-divider';h.dataset.wsDivider=String(i);h.tabIndex=0;h.setAttribute('role','separator');h.setAttribute('aria-label','调整右侧第 '+(i+1)+' 个分隔线');h.setAttribute('aria-orientation','horizontal');h.style.height='8px';this.dockTools.append(h);h.onkeydown=e=>{if(!['ArrowUp','ArrowDown'].includes(e.key))return;e.preventDefault();this.adjustDivider(i,e.key==='ArrowDown'?20:-20,this.visibleDockRects(),this.visibleDock().map(v=>v.slot));this.layout();this.persist();h.focus();};});
    }
    for(const n of this.dockTools.children){if(n.dataset.wsDivider==='width'){n.style.left=(innerWidth-this.width-4)+'px';n.style.height=(innerHeight-24-(this.toolbar.terminal?.rightReservation||0))+'px';}else{const r=rects[Number(n.dataset.wsDivider)];n.style.left=r.left+'px';n.style.top=(r.top+r.height-4)+'px';n.style.width=r.width+'px';}}
  }
  persist(){
    const panels={...this.saved.panels};for(const e of this.entries.values())panels[e.id]={mode:e.mode,rect:e.rect,slot:this.slots.indexOf(e.id)};
    this.saved={version:1,width:this.width,count:this.count,weights:this.weights,panels};try{localStorage.setItem(this.key,JSON.stringify(this.saved));}catch{}
  }
  float(id,rect){const e=this.entries.get(id);if(!e)return;this.slots=this.slots.map(x=>x===id?null:x);e.mode='float';if(rect)e.rect=this.rect(rect);this.layout();this.focus(e);}
  full(id){const e=this.entries.get(id);if(!e||id!=='library')return;this.slots=this.slots.map(x=>x===id?null:x);e.mode='full';this.layout();this.focus(e);this.persist();}
  snapPlan(id,count,index){
    const others=this.slots.filter(x=>x&&x!==id&&this.active(this.entries.get(x)));
    const oldSlot=this.slots.indexOf(id),same=count===this.count;const next=same?this.slots.map(x=>x!==id&&this.active(this.entries.get(x))?x:null):Array(count).fill(null);
    const displaced=next[index];next[index]=id;
    if(displaced){const free=oldSlot>=0&&oldSlot!==index?oldSlot:next.indexOf(null);if(free>=0)next[free]=displaced;}
    if(!same)for(const other of others){const free=next.indexOf(null);if(free>=0)next[free]=other;}
    return {next,same,displaced:others.filter(other=>!next.includes(other))};
  }
  snap(id,count,index,defer=false){
    const e=this.entries.get(id);if(!e)return;
    const {next,same,displaced}=this.snapPlan(id,count,index);
    for(const other of displaced)this.entries.get(other).mode='float';
    this.count=count;this.slots=next;if(!same)this.weights=Array(count).fill(1);e.mode='dock';
    if(!this.openingDrop&&!defer){this.hidePicker();this.layout();this.focus(e);this.persist();}
  }
  createPicker(){
    if(this.picker)return;const p=document.createElement('div');p.className='et-workspace-snap';p.hidden=true;p.setAttribute('role','dialog');p.setAttribute('aria-label','窗口布局');
    p.innerHTML='<div class="et-workspace-snap-options"></div><button type="button" data-ws-float><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 4H4v12h12v-5M11 3h6v6M17 3l-8 8"/></svg><span>浮动窗口</span></button>';
    for(let count=1;count<=3;count++){const group=document.createElement('div');group.className='et-workspace-snap-option';const diagram=document.createElement('div');diagram.className='et-workspace-snap-diagram';for(let i=0;i<count;i++){const b=document.createElement('button');b.type='button';b.dataset.wsCount=count;b.dataset.wsSlot=i;b.setAttribute('aria-label',count+' 个窗口，第 '+(i+1)+' 格');b.onclick=()=>this.snap(this.pickerId,count,i);diagram.append(b);}const label=document.createElement('span');label.textContent=count+' 个窗口';group.append(diagram,label);p.querySelector('.et-workspace-snap-options').append(group);}
    p.querySelector('[data-ws-float]').onclick=()=>{this.float(this.pickerId);this.persist();this.hidePicker();};
    document.body.append(p);this.picker=p;
    this.preview=document.createElement('div');this.preview.className='et-workspace-snap-preview';this.preview.hidden=true;document.body.append(this.preview);
    document.addEventListener('pointerdown',e=>{if(!this.drag&&!p.hidden&&!p.contains(e.target)&&!e.target.closest('.et-workspace-layout,[data-ai=layout]'))this.hidePicker();},true);
  }
  showPicker(id,dragging=false,y=innerHeight/2){
    this.createPicker();this.pickerId=id;this.picker.dataset.dragging=String(dragging);
    for(const b of this.picker.querySelectorAll('[data-ws-count]')){b.classList.remove('active');b.disabled=Number(b.dataset.wsCount)>this.availableCount();b.title=b.disabled?'窗口高度不足，请先扩大 Typora 窗口':'';}
    this.picker.hidden=false;const r=this.picker.getBoundingClientRect();
    this.picker.style.left=Math.max(8,innerWidth-r.width-12)+'px';this.picker.style.top=Math.max(8,Math.min(innerHeight-r.height-28,y-r.height/2))+'px';
    this.pickerBounds=this.picker.getBoundingClientRect();this.pickerRects=[...this.picker.querySelectorAll('[data-ws-count]')].map(node=>({node,rect:node.getBoundingClientRect(),count:Number(node.dataset.wsCount),index:Number(node.dataset.wsSlot)}));
    if(!dragging)this.picker.querySelector('button[data-ws-count]').focus();
  }
  hidePicker(){if(this.picker)this.picker.hidden=true;if(this.preview)this.preview.hidden=true;this.target=null;}
  previewAt(x,y){
    if(!this.picker||this.picker.hidden){if(x<innerWidth-52)return;this.showPicker(this.drag.id||this.drag.entry.id,true,y);}
    let target=this.pickerRects.find(t=>!t.node.disabled&&x>=t.rect.left&&x<=t.rect.right&&y>=t.rect.top&&y<=t.rect.bottom);
    if(!target&&x>=innerWidth-52){const id=this.drag.id||this.drag.entry.id,visible=this.visibleDock(),count=Math.min(this.availableCount(),Math.max(this.count,visible.length+(visible.some(v=>v.entry.id===id)?0:1)));target={count,index:Math.min(count-1,Math.max(0,Math.floor(y/(innerHeight-24)*count)))};}
    this.target=target?{count:target.count,index:target.index}:null;
    for(const t of this.pickerRects)t.node.classList.toggle('active',!!target&&t.count===target.count&&t.index===target.index);
    this.preview.hidden=!target;if(target){const id=this.drag.id||this.drag.entry.id,plan=this.snapPlan(id,target.count,target.index),occupied=plan.next.map((id,slot)=>({id,slot})).filter(v=>v.id),rects=this.dockRects(occupied.length,occupied.map(v=>plan.same?this.weights[v.slot]||1:1));this.applyRect(this.preview,rects[occupied.findIndex(v=>v.id===id)]);}
    if(x<innerWidth-200)this.hidePicker();
  }
  snapshot(){return {width:this.width,count:this.count,weights:[...this.weights],slots:[...this.slots],entries:[...this.entries.values()].map(e=>({id:e.id,mode:e.mode,rect:{...e.rect}}))};}
  restore(s){this.width=s.width;this.count=s.count;this.weights=s.weights;this.slots=s.slots;for(const v of s.entries)Object.assign(this.entries.get(v.id),{mode:v.mode,rect:v.rect});}
  start(e){
    if(e.button!==0||e.isPrimary===false||this.drag)return;
    const divider=e.target.closest('[data-ws-divider]'),p=e.target.closest('.et-workspace-panel:not(.et-library-note-docked)'),edge=e.target.closest('[data-ws-edge]')?.dataset.wsEdge;
    const button=e.target.closest('#editing-toolbar-top [data-action],#editing-toolbar [data-action]'),id=this.toolbarId(e.target);
    if(!divider&&!id&&(!p||!edge&&(!e.target.closest('.et-workspace-header')||e.target.closest('button,input,select,textarea,a,[contenteditable]'))))return;
    if(id&&!this.owner(id))return;
    const entry=p?this.entries.get(p.dataset.workspaceId):id?this.entries.get(id):null;
    this.drag={pointerId:e.pointerId,x:e.clientX,y:e.clientY,px:e.clientX,py:e.clientY,edge,entry,id,divider:divider?.dataset.wsDivider,active:false,saved:this.snapshot(),wasHidden:entry?.owner.panel.hidden,handle:divider||button||e.target};
    this.drag.handle.setPointerCapture?.(e.pointerId);
    if(divider||edge){e.preventDefault();e.stopImmediatePropagation();this.activateSafely(e);}
  }
  activateSafely(e){try{this.activate(e);}catch(error){this.finish(true);this.reportMotionError(error);}}
  reportMotionError(error){console.warn('[EditingToolbar] Panel motion cancelled:',error);this.toolbar._showToolbarNotice('窗口拖动已取消，请重试');}
  activate(e){
    const d=this.drag;if(!d)return;d.active=true;d.saved=this.snapshot();
    if(d.id){
      // Keep the real module untouched until a valid release, including hidden note editors.
      d.ghost=document.createElement('div');d.ghost.className='et-workspace-icon-ghost';d.ghost.setAttribute('aria-hidden','true');
      const icon=d.handle.querySelector('svg')?.cloneNode(true);if(icon)d.ghost.append(icon);
      const label=document.createElement('span');label.textContent=this.title(d.id);d.ghost.append(label);document.body.append(d.ghost);
      const area=document.querySelector('content')?.getBoundingClientRect();const toolbar=document.getElementById('editing-toolbar-top')?.getBoundingClientRect();
      d.dropArea=area?{left:area.left,right:area.right,top:Math.max(area.top,toolbar?.bottom||0),bottom:area.bottom}:null;
    }else if(d.entry){const p=d.entry.owner.panel,r=p.getBoundingClientRect();d.base={left:r.left,top:r.top,width:r.width,height:r.height};
      if(d.entry.mode==='dock'||d.entry.mode==='full'){
        const size=this.rect(d.entry.rect),anchor=Math.max(0,Math.min(1,(d.x-r.left)/r.width));
        // Keep the grip under the pointer after detaching near the right edge.
        // Clamping the first frame must not become a new, shifted drag origin.
        d.grabX=anchor*size.width;d.grabY=Math.min(38,Math.max(8,d.y-r.top));
        this.float(d.entry.id,{...size,left:e.clientX-d.grabX,top:e.clientY-d.grabY});
        d.base={...d.entry.rect};d.x=e.clientX;d.y=e.clientY;
      }
      p.classList.add('et-workspace-moving');this.focus(d.entry);d.entry.owner.composerUI?.closeMenu();
    }else{const items=this.visibleDock();d.rects=this.visibleDockRects(items);d.slotIndices=items.map(item=>item.slot);d.panels=items.map(item=>item.entry.owner.panel);d.width=this.width;d.maxWidth=this.maxWidth();d.panels.forEach(p=>p.classList.add('et-workspace-moving'));}
    if(this.drag!==d)return;
    d.shield=ETDragSupport.shield(document,'et-workspace-drag-shield');d.shield.style.cursor=d.divider==='width'?'ew-resize':d.divider!==undefined?'ns-resize':d.edge?({n:'ns',s:'ns',e:'ew',w:'ew',ne:'nesw',sw:'nesw',nw:'nwse',se:'nwse'}[d.edge]+'-resize'):'grabbing';d.shield.setPointerCapture(d.pointerId);
    // Keyboard events stay inside an active note iframe unless the gesture owns
    // focus. Preserve that editor and selection, then return focus on release.
    d.focus=document.activeElement;d.shield.tabIndex=-1;d.shield.focus({preventScroll:true});
    e.preventDefault();e.stopImmediatePropagation();
  }
  move(e){const d=this.drag;if(!d||d.pointerId!==e.pointerId)return;d.px=e.clientX;d.py=e.clientY;if(!d.active&&Math.hypot(d.px-d.x,d.py-d.y)>6)this.activateSafely(e);if(this.drag!==d||!d.active)return;e.preventDefault();e.stopImmediatePropagation();this.frame.queue();}
  adjustDivider(index,dy,rects,slots){const a=rects[index],b=rects[index+1],min=Math.min(220,(a.height+b.height)/2);const h=Math.max(min,Math.min(a.height+b.height-min,a.height+dy));const sum=slots.reduce((total,slot)=>total+this.weights[slot],0),height=rects.reduce((total,r)=>total+r.height,0);slots.forEach((slot,i)=>this.weights[slot]=rects[i].height/height*sum);this.weights[slots[index]]=h/height*sum;this.weights[slots[index+1]]=(a.height+b.height-h)/height*sum;}
  paint(){
    const d=this.drag;if(!d?.active)return;const dx=d.px-d.x,dy=d.py-d.y;
    if(d.divider!==undefined){
      if(d.divider==='width'){
        const width=Math.max(280,Math.min(d.maxWidth,d.width-dx));if(width===this.width)return;this.width=width;
        // One write-only pass: panels, native scroll container and divider share
        // the same edge. Full lifecycle/layout work belongs to release, not motion.
        d.panels.forEach((panel,i)=>this.applyRect(panel,{...d.rects[i],left:innerWidth-width,width}));
        this.inset(width);this.toolbar.terminal?.layout(true);this.toolbar.codeEditor?.layout();
        for(const handle of this.dockTools.children){handle.style.left=(innerWidth-width-(handle.dataset.wsDivider==='width'?4:0))+'px';if(handle.dataset.wsDivider!=='width')handle.style.width=width+'px';}
      }else{this.adjustDivider(Number(d.divider),dy,d.rects,d.slotIndices);const rects=this.dockRects(d.panels.length,d.slotIndices.map(slot=>this.weights[slot]));d.panels.forEach((p,i)=>this.applyRect(p,rects[i]));for(const h of this.dockTools.children)if(h.dataset.wsDivider!=='width'){const r=rects[Number(h.dataset.wsDivider)];h.style.top=(r.top+r.height-4)+'px';}}
      return;
    }
    if(d.id){d.ghost.style.transform='translate3d('+Math.min(innerWidth-120,d.px+14)+'px,'+Math.min(innerHeight-48,d.py+14)+'px,0)';if(d.id!=='terminal')this.previewAt(d.px,d.py);return;}
    const r=d.base,b=this.bounds();let next={...r};
    if(!d.edge){next=this.rect({...r,left:d.grabX===undefined?r.left+dx:d.px-d.grabX,top:d.grabY===undefined?r.top+dy:d.py-d.grabY});d.entry.owner.panel.style.transform=`translate3d(${next.left-r.left}px,${next.top-r.top}px,0)`;const note=d.entry.owner.notePane?.manager?.panel;if(note)note.style.transform=d.entry.owner.panel.style.transform;this.previewAt(d.px,d.py);}
    else {let l=r.left,t=r.top,right=l+r.width,bottom=t+r.height;const mw=Math.min(300,b.right-b.left),mh=Math.min(240,b.bottom-b.top);if(d.edge.includes('w'))l=Math.max(b.left,Math.min(l+dx,right-mw));if(d.edge.includes('e'))right=Math.min(b.right,Math.max(right+dx,l+mw));if(d.edge.includes('n'))t=Math.max(b.top,Math.min(t+dy,bottom-mh));if(d.edge.includes('s'))bottom=Math.min(b.bottom,Math.max(bottom+dy,t+mh));next={left:l,top:t,width:right-l,height:bottom-t};this.applyRect(d.entry.owner.panel,next);}
    d.next=next;
  }
  openDrop(id,x,y,target){
    if(id==='terminal'){void this.toolbar.terminal.openFloatingAt(x,y).catch(error=>this.reportMotionError(error));return;}
    const owner=this.owner(id);if(!owner)return;if(!owner.panel)owner.mount?.();
    const entry=this.ensure(owner);if(!entry)return;
    const before=this.snapshot(),hidden=owner.panel.hidden;
    this.openingDrop=entry;
    try{
      // Choose the final geometry before open() can measure or focus its contents.
      // A floating drop must never briefly dock and reflow the entire document.
      if(target)this.snap(id,target.count,target.index);
      else{this.slots=this.slots.map(slot=>slot===id?null:slot);entry.mode='float';entry.rect=this.rect({...entry.rect,left:x-60,top:y-22});}
      // A placement change must not rescan/re-render an already open editor.
      if(hidden)owner.open();
      if(!this.active(entry)){this.restore(before);return;}
      this.focus(entry);
    }catch(error){owner.panel.hidden=hidden;this.restore(before);this.layout();throw error;}
    finally{this.openingDrop=null;}
  }
  finish(cancel){
    const d=this.drag;if(!d)return;this.frame.cancel();
    let failure;
    try{if(d.active&&!cancel)this.paint();}catch(error){cancel=true;failure=error;}
    const target=this.target,rail=this.picker&&!this.picker.hidden?this.pickerBounds:null,overPicker=rail&&d.px>=rail.left&&d.px<=rail.right&&d.py>=rail.top&&d.py<=rail.bottom;this.drag=null;
    // Release input before restoring layout or running module callbacks. Even a
    // failed layout must never leave a full-page shield intercepting buttons.
    try{for(const node of [d.shield,d.handle])if(node?.hasPointerCapture?.(d.pointerId))node.releasePointerCapture(d.pointerId);}
    finally{const restoreFocus=document.hasFocus()&&document.activeElement===d.shield;d.shield?.remove();d.ghost?.remove();d.panels?.forEach(p=>p.classList.remove('et-workspace-moving'));if(restoreFocus&&d.focus?.isConnected)d.focus.focus({preventScroll:true});if(d.entry){d.entry.owner.panel.classList.remove('et-workspace-moving');d.entry.owner.panel.style.transform='';const note=d.entry.owner.notePane?.manager?.panel;if(note)note.style.transform='';}this.hidePicker();}
    try{if(d.active){this.suppressClickUntil=performance.now()+100;this.suppressClickTarget=d.handle;
      if(cancel){if(!d.id)this.restore(d.saved);}
      else if(d.id){
        const a=d.dropArea,inside=a&&d.px>=a.left&&d.px<=a.right&&d.py>=a.top&&d.py<=a.bottom;
        if(target||inside&&!overPicker){
          this.openDrop(d.id,d.px,d.py,target);
        }
      }
      else if(d.entry){d.entry.rect=d.next||d.base;if(target)this.snap(d.entry.id,target.count,target.index,true);}
      this.hidePicker();this.layout();if(!cancel)this.persist();this.toolbar._applyTopPlacement();
    }}catch(error){failure=error;}
    if(failure)this.reportMotionError(failure);
  }
}

// Keep module-specific data/lifecycle methods; only geometry and mutual exclusion change.
EditingToolbarPanelWorkspace.bindType=function(Type){
  const proto=Type.prototype;
  if(Object.hasOwn(proto,'open')){const open=proto.open;proto.open=function(...args){const result=open.apply(this,args);this.toolbar.panelWorkspace?.opened(this);return result;};}
  if(Object.hasOwn(proto,'close')){const close=proto.close;proto.close=function(...args){const result=close.apply(this,args);this.toolbar.panelWorkspace?.closed(this);return result;};}
}

for(const Type of [EditingToolbarAnnotations,EditingToolbarDocumentNotes,EditingToolbarManualMarks])EditingToolbarPanelWorkspace.bindType(Type);
