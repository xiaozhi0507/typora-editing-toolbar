// Command selection stays separate from the user's text and the API prompt body.
class EditingToolbarAIComposer {
  constructor(ai) { this.ai=ai; this.command=null;this.draft=new EditingToolbarAIDraft(ai); }
  static chevron='<svg viewBox="0 0 16 16" aria-hidden="true"><path d="m4 6 4 4 4-4"/></svg>';
  static arrow='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V5m-6 6 6-6 6 6"/></svg>';
  static isFree(p) {return p?.id==='builtin-12'&&p.name==='自由提问'&&p.type==='quickFill'&&p.prompt==='请根据当前资料回答：';}
  static bindPromptKeys(input,send) {
    let composing=false;input.title='Enter 发送，Ctrl+Enter 换行';input.setAttribute('aria-description',input.title);
    input.addEventListener('compositionstart',()=>composing=true);input.addEventListener('compositionend',()=>composing=false);input.addEventListener('blur',()=>composing=false);
    input.addEventListener('keydown',e=>{
      if(e.key!=='Enter'||e.defaultPrevented||e.isComposing||composing||e.keyCode===229||input.disabled||input.readOnly)return;
      if(e.ctrlKey||e.metaKey){
        e.preventDefault();
        // Use Chromium's editing command to keep cursor replacement and native undo.
        if(input.richEditor)input.richEditor.newline();else if(!document.execCommand('insertText',false,'\n')){input.setRangeText('\n',input.selectionStart,input.selectionEnd,'end');input.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertLineBreak'}));}
      }else if(!e.shiftKey&&!e.altKey){e.preventDefault();if(!e.repeat)send();}
    },!!input.richEditor);
  }
  mount() {
    const a=this.ai;
    this.bar=a.node('div','et-ai-command-bar');
    this.bar.innerHTML='<button type="button" class="et-ai-command-trigger" aria-haspopup="menu" aria-expanded="false" aria-controls="et-ai-command-menu"><svg class="et-ai-command-icon" viewBox="0 0 20 20" aria-hidden="true"><path d="m10 2 2.2 5.8L18 10l-5.8 2.2L10 18l-2.2-5.8L2 10l5.8-2.2Z"/></svg><span class="et-ai-control-label">快捷命令</span>'+EditingToolbarAIComposer.chevron+'</button><button type="button" class="et-ai-command-chip" hidden></button>';
    a.panel.querySelector('.et-ai-composer').before(this.bar);
    this.trigger=this.bar.querySelector('.et-ai-command-trigger');this.trigger.setAttribute('aria-label','快捷命令');this.trigger.title='选择快捷命令';this.chip=this.bar.querySelector('.et-ai-command-chip');
    this.commandMenu=this.makeMenu('et-ai-command-menu','快捷命令');this.modelMenu=this.makeMenu('et-ai-model-menu','选择模型');
    this.modelMenu.setAttribute('popover','manual');this.modelMenu.setAttribute('role','dialog');this.modelMenu.setAttribute('aria-label','选择模型与思考程度');a.model.setAttribute('aria-haspopup','dialog');
    this.trigger.onclick=()=>this.toggle(this.commandMenu,this.trigger);
    this.chip.onclick=()=>this.command?this.select(null):this.toggle(this.commandMenu,this.trigger);
    a.model.onclick=()=>this.toggle(this.modelMenu,a.model);
    this.scopeTrigger=a.node('button','et-ai-scope-trigger');this.scopeTrigger.type='button';this.scopeTrigger.setAttribute('aria-haspopup','dialog');this.scopeTrigger.setAttribute('aria-expanded','false');this.scopeTrigger.setAttribute('aria-controls','et-ai-scope-menu');this.trigger.after(this.scopeTrigger);
    this.scopeMenu=this.makeMenu('et-ai-scope-menu','资料范围');this.scopeMenu.setAttribute('role','dialog');this.scopeMenu.dataset.width='350';this.scopeMenu.onkeydown=null;
    this.scopeMenu.append(a.node('div','et-ai-scope-heading','资料范围'));this.scopeOptions=a.node('div','et-ai-scope-options');this.scopeOptions.setAttribute('role','menu');this.scopeOptions.setAttribute('aria-label','选择资料范围');this.scopeMenu.append(this.scopeOptions);
    const icons={none:'M5 5h14v10H9l-4 4z',selection:'M4 3v4M4 3h4M20 3h-4M20 3v4M4 17v4h4M20 17v4h-4M8 9h8M8 13h6',document:'M6 3h8l4 4v14H6zM14 3v5h4M9 12h6M9 16h6',abstract:'M5 5h14M5 10h14M5 15h9M5 20h6',section:'M5 4h14v16H5zM9 4v16M12 8h4M12 12h4',sections:'M8 3h13v14H8zM3 7v14h14',note:'M5 3h14v18H5zM3 7h4M3 12h4M3 17h4M10 8h5M10 12h5',image:'M3 3h18v18H3zM4 18l6-6 4 4 3-3 4 4M7 7h2'};
    for(const value of ['none','selection','document','abstract','section','sections','note','image']){
      const option=[...a.scope.options].find(o=>o.value===value),b=a.node('button','et-ai-scope-option');b.type='button';b.dataset.scope=value;b.setAttribute('role','menuitemradio');b.title=option.text;
      b.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="'+icons[value]+'"/></svg>';b.append(a.node('span','',option.text),a.node('span','et-ai-scope-check','✓'));
      b.onclick=()=>{a.scope.value=value;a.scope.onchange();if(value==='none')this.closeMenu(true);else if(value==='image')this.showImageScope();else{delete this.scopeMenu.dataset.view;this.positionMenu();b.focus({preventScroll:true});}};this.scopeOptions.append(b);
    }
    this.scopeOptions.onkeydown=e=>{if(!['ArrowDown','ArrowUp','ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();const rows=[...this.scopeOptions.querySelectorAll('button:not(:disabled)')],at=rows.indexOf(document.activeElement),step=e.key==='ArrowDown'?2:e.key==='ArrowUp'?-2:e.key==='ArrowLeft'?-1:1;rows[e.key==='Home'?0:e.key==='End'?rows.length-1:(at+step+rows.length)%rows.length]?.focus();};
    a.scope.hidden=true;a.scope.tabIndex=-1;a.scope.setAttribute('aria-hidden','true');this.scopeMenu.append(a.panel.querySelector('.et-ai-context'));this.scopeMenu.addEventListener('toggle',()=>{if(this.menu===this.scopeMenu)this.positionMenu();},true);
    this.scopeTrigger.onclick=()=>this.menu===this.scopeMenu?this.closeMenu(true):this.openScope();
    a.prompt.addEventListener('input',()=>{a.status.hidden=true;this.sync();});
    document.addEventListener('pointerdown',e=>{if(this.menu&&!this.menu.contains(e.target)&&!this.anchor?.contains(e.target))this.closeMenu();});
    window.addEventListener('blur',()=>this.closeMenu());
    window.addEventListener('resize',()=>{if(this.menu===this.modelMenu)this.closeMenu();});
    // A model picker follows the bottom button, including scrolling inside split panes.
    this.followModel=()=>{if(this.menu!==this.modelMenu||this.modelFrame)return;this.modelFrame=requestAnimationFrame(()=>{this.modelFrame=null;if(this.menu===this.modelMenu)this.positionModelMenu();});};
    a.panel.addEventListener('scroll',e=>{if(!this.modelMenu.contains(e.target))this.followModel();},true);
    this.modelObserver=new ResizeObserver(this.followModel);this.modelObserver.observe(a.model);this.modelObserver.observe(a.panel);
    a.panel.addEventListener('keydown',e=>{
      if(e.key==='Escape'&&this.menu){e.preventDefault();e.stopPropagation();this.closeMenu(true);}
      if(['ArrowDown','ArrowUp'].includes(e.key)&&[this.trigger,this.scopeTrigger,a.model].includes(e.target)){e.preventDefault();if(e.target===this.scopeTrigger)this.openScope();else this.openMenu(e.target===a.model?this.modelMenu:this.commandMenu,e.target);}
    });
    a.panel.addEventListener('focusout',e=>{if(this.menu&&e.relatedTarget&&!this.menu.contains(e.relatedTarget)&&e.relatedTarget!==this.anchor)this.closeMenu();});
    this.refresh();
  }
  makeMenu(id,label) {
    const menu=this.ai.node('div','et-ai-composer-menu');menu.id=id;menu.hidden=true;menu.setAttribute('role','menu');menu.setAttribute('aria-label',label);this.ai.panel.append(menu);
    menu.onkeydown=e=>{
      if(menu===this.modelMenu)return EditingToolbarAIEffort.keydown(e,menu,{onBack:this.ai.profile()?()=>this.showModelView('effort'):null,onClose:()=>this.closeMenu(true)});
      const items=[...menu.querySelectorAll('[role^=menuitem]:not(:disabled)')],at=items.indexOf(document.activeElement);
      if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){e.preventDefault();const next=items[e.key==='Home'?0:e.key==='End'?items.length-1:(at+(e.key==='ArrowDown'?1:-1)+items.length)%items.length];next?.focus({preventScroll:true});this.revealItem(menu,next);}
      if(e.key==='Tab'&&menu!==this.modelMenu)this.closeMenu(true);
    };
    return menu;
  }
  item(menu,name,selected,onClick,detail='') {
    const a=this.ai,b=a.node('button');b.type='button';b.setAttribute('role','menuitemradio');b.setAttribute('aria-checked',String(selected));b.title=detail?name+' · '+detail:name;
    const copy=a.node('span','et-ai-menu-copy');copy.append(a.node('span','et-ai-menu-name',name));if(detail)copy.append(a.node('small','',detail));
    const check=a.node('span','et-ai-menu-check',selected?'✓':'');check.setAttribute('aria-hidden','true');
    b.append(copy,check);b.onclick=()=>{this.closeMenu();onClick();};menu.append(b);return b;
  }
  refresh() {
    if(!this.bar)return;
    const a=this.ai,rows=a.config.prompts.filter(p=>!EditingToolbarAIComposer.isFree(p));
    if(this.command){const current=rows.find(p=>p.id===this.command.id);this.command=current?.type===this.command.type?{...current}:null;}
    this.commandMenu.replaceChildren();
    for(const [type,label] of ETAIPrompts.types){
      const group=rows.filter(p=>p.type===type);if(!group.length&&type!=='fullText')continue;
      this.commandMenu.append(a.node('div','et-ai-menu-heading',label));
      if(type==='fullText')a.paperTranslation?.add(this.commandMenu);
      for(const p of group)this.item(this.commandMenu,p.name,p.id===this.command?.id,()=>a.promptsManager.use(p.id));
    }
    const manage=this.item(this.commandMenu,'管理快捷命令',false,()=>a.promptsManager.open());manage.setAttribute('role','menuitem');manage.removeAttribute('aria-checked');manage.classList.add('et-ai-menu-manage');
    this.refreshModels();this.sync();
  }
  refreshModels() {
    if(!this.modelMenu)return;const a=this.ai;this.syncModelButton();
    this.modelList=EditingToolbarAIEffort.render(a,this.modelMenu,{
      profiles:a.modelProfiles(),profile:a.profile(),view:this.modelView||'effort',
      onView:view=>this.showModelView(view),
      onModel:p=>{if(!a.selectModel(p))return;a.editingId=p.id;a.settingsInitialized=false;this.showModelView('effort');if(p.authType==='chatgpt-web')void a.webChat.browser.select('version',{label:p.webVersion}).catch(e=>a.notice(e.message,true));},
      onChange:effort=>{const p=a.profile();if(!p)return;p.reasoningEffort=effort;a.rememberModel(p);a.persist();this.syncModelButton();}
    });
    if(this.menu===this.modelMenu)this.positionModelMenu();
  }
  showModelView(view){this.modelView=view;this.refreshModels();EditingToolbarAIEffort.focus(this.modelMenu);}
  syncModelButton(){
    const a=this.ai,p=a.profile(),effort=p?.authType==='chatgpt-web'?a.webChat.label():EditingToolbarAIEffort.label(p||{});
    a.model.replaceChildren(a.node('span','et-ai-model-label',EditingToolbarAIEffort.modelName(p)));
    if(effort)a.model.append(a.node('span','et-ai-model-effort',effort));
    a.model.insertAdjacentHTML('beforeend',EditingToolbarAIComposer.chevron);a.model.title=p?EditingToolbarAIEffort.modelName(p)+(effort?' · '+effort:''):'选择模型';a.shellUI?.sync();
  }
  select(command) {
    const a=this.ai;if(a.busy)return;this.command=command?{...command}:null;
    a.webChat?.translation.clear();
    if(!command)this.restoreSource();
    a.status.hidden=true;this.refresh();a.prompt.focus();
    if(command&&['sections','note','image'].includes(a.scope.value)&&!a.attachments.selected.some(f=>f.kind===(a.scope.value==='image'?'image':'text')))this.openScope();
    a.conversations.schedule();
  }
  hasSourceDraft() {return !!(this.sourceDraft||this.sourceChanged);}
  markSourceChanged() {if(!this.sourceDraft&&(this.ai.turns.length||this.ai.attachments.frozen))this.sourceChanged=true;}
  changeScope(value) {
    const a=this.ai;if(a.scopeLocked()||!a.followDocument())return false;
    this.restoreSource();this.command=null;this.markSourceChanged();a.scope.value=value;
    a.capture();this.sync();a.conversations.schedule();return true;
  }
  stageSource() {
    const a=this.ai;if(!a.turns.length||this.sourceDraft)return;
    this.sourceDraft={context:a.context,scope:a.scope.value,selected:a.attachments.selected,persistent:!!this.sourceChanged};this.sourceChanged=false;a.attachments.selected=[];
  }
  restoreSource() {
    if(!this.sourceDraft)return;const a=this.ai,previous=this.sourceDraft;this.sourceDraft=null;
    a.context=previous.context;a.scope.value=previous.scope;a.attachments.selected=previous.selected;this.sourceChanged=previous.persistent;
    a.promptsManager.renderContextTools();a.updateContext();
  }
  snapshot() {
    const a=this.ai,draft=this.draft.snapshot();
    const serialize=s=>({context:{...s.context,range:null},scope:s.scope,selected:s.selected,persistent:!!s.persistent});
    return {...draft,webTranslation:a.webChat?.translation.snapshot(),queue:a.queue?.snapshot(),commandId:this.command?.id||null,...(this.hasSourceDraft()?{source:{...serialize({context:a.context,scope:a.scope.value,selected:a.attachments.selected,persistent:this.sourceChanged}),...(this.sourceDraft?.persistent?{returnTo:serialize(this.sourceDraft)}:{})}}:{})};
  }
  restore(data,text) {
    this.ai.queue?.restore(data?.queue);this.draft.restore(data,text);this.command=this.ai.config.prompts.find(p=>p.id===data?.commandId)||null;
    this.ai.webChat?.translation.restore(data?.webTranslation);
    if(data?.source){
      const apply=s=>{this.ai.context={...s.context,range:null};this.ai.scope.value=s.scope;this.ai.attachments.selected=s.selected||[];this.sourceChanged=!!s.persistent;};
      if(data.source.returnTo)apply(data.source.returnTo);
      if(!data.source.persistent)this.stageSource();apply(data.source);
    }
    this.refresh();
  }
  request() {
    const input=this.draft.text().trim(),p=this.command;
    return {skills:this.ai.skillsUI?.request(input),question:p?p.prompt+(input?'\n\n补充要求：\n'+input:''):input,displayQuestion:p?'⚡ '+p.name+(input?'\n'+input:''):input,command:p?{id:p.id,name:p.name}:null};
  }
  consumed() {this.command=null;this.ai.webChat?.translation.clear();this.restoreSource();this.draft.clear();this.refresh();}
  openScope(preview=false) {
    if(this.ai.scopeLocked())return;
    this.openMenu(this.scopeMenu,this.scopeTrigger);
    if(this.ai.scope.value==='image'){this.showImageScope();return;}
    delete this.scopeMenu.dataset.view;
    if(preview)this.ai.contextPreview.hidden=false;
    this.positionMenu();this.scopeOptions.querySelector('[aria-checked=true]:not(:disabled)')?.focus({preventScroll:true});
  }
  showImageScope() {this.scopeMenu.dataset.view='images';this.ai.imagesUI.activate();this.positionMenu();this.scopeMenu.scrollTop=0;this.ai.imagesUI.root?.querySelector('button')?.focus({preventScroll:true});}
  showScopeChoices() {this.scopeMenu.dataset.view='choices';this.positionMenu();this.scopeOptions.querySelector('[aria-checked=true]')?.focus({preventScroll:true});}
  syncContext() {
    if(!this.scopeTrigger)return;const a=this.ai,name=a.promptsManager.reference().name;
    this.scopeTrigger.dataset.empty=String(a.scope.value==='none');this.scopeTrigger.dataset.active=String(a.scope.value!=='none');this.scopeTrigger.setAttribute('aria-label','资料范围：'+(a.scope.value==='none'?'未选择':name));this.scopeTrigger.replaceChildren(a.node('span','et-ai-control-label',a.scope.value==='none'?'资料范围':name));this.scopeTrigger.insertAdjacentHTML('beforeend',EditingToolbarAIComposer.chevron);this.scopeTrigger.title='资料范围：'+(a.scope.value==='none'?'未选择':name);
    for(const b of this.scopeOptions.children){b.setAttribute('aria-checked',String(b.dataset.scope===a.scope.value));b.disabled=a.scope.disabled;}
    this.scopeMenu.querySelector('.et-ai-context').hidden=a.scope.value==='none';
    a.attachments.renderChips();if(this.menu===this.scopeMenu)this.positionMenu();
  }
  sync() {
    if(!this.bar)return;const a=this.ai,p=this.command,translation=a.webChat?.active()&&a.webChat.translation.draft;
    this.chip.hidden=true;this.trigger.dataset.active=String(!!p||!!translation);this.trigger.title=translation?'当前命令：一键文献翻译':p?'当前命令：'+p.name:'选择快捷命令';
    a.prompt.placeholder=translation?'补充翻译要求（可选），点击发送开始…':p?'补充要求（可选）…':a.editUI?.enabled?'描述你想修改的内容…':'问点什么…';
    for(const b of [this.trigger,this.chip,a.model])b.disabled=!!a.busy||a.attachments.pending||!!a.webChat?.browser.switching;
    this.scopeTrigger.disabled=a.scopeLocked();
    a.panel.querySelector('[data-ai=add-context]').disabled=a.attachments.locked();
    const locked=a.composerLocked?.()??!!a.busy,send=a.panel.querySelector('[data-ai=send]'),queueing=!!a.queue&&(!!a.busy||!!a.queue.items.length);
    send.disabled=locked||(a.webChat?.active()&&(a.busy||a.webChat.browser.switching||!!a.webChat.browser.refreshJob||!!a.webChat.browser.blocked))||a.settingsBusy||a.attachments.pending||this.draft.media.pending||(!p&&!translation&&!this.draft.text().trim());
    send.hidden=!!a.busy&&!a.queue;send.title=queueing?'加入队列':'发送';send.setAttribute('aria-label',send.title);
    const icon=queueing?EditingToolbarAIMessageQueue.icon:EditingToolbarAIComposer.arrow;if(send.innerHTML!==icon)send.innerHTML=icon;
    a.prompt.readOnly=locked;
    this.syncContext();this.draft.sync();a.shellUI?.sync();a.paperTranslation?.sync();a.webChat?.projects?.sync();a.webChat?.translation.sync();
  }
  toggle(menu,anchor) {if(this.menu===menu)this.closeMenu(true);else this.openMenu(menu,anchor);}
  openMenu(menu,anchor) {
    if((this.ai.busy&&menu!==this.scopeMenu&&menu!==this.ai.attachments.preview&&menu!==this.ai.attachments.menu)||(anchor.disabled&&menu!==this.ai.attachments.preview))return;this.closeMenu();if(menu===this.modelMenu){menu._webOptionsRequested=false;this.modelView='effort';this.refreshModels();}this.menu=menu;this.anchor=anchor;menu.hidden=false;anchor.setAttribute('aria-expanded','true');
    if(menu===this.commandMenu)void this.ai.paperTranslation?.refresh();
    if(menu===this.modelMenu){menu.showPopover();if(this.ai.webChat?.active())this.ai.webChat.loadOptions(menu);else this.ai.chatgptUI.schedulePickerModels();}
    this.positionMenu();
    const selected=menu.querySelector('[aria-checked=true]')||menu.querySelector('button');selected?.focus({preventScroll:true});
    this.revealItem(menu,selected);
  }
  revealItem(menu,item) {
    if(!item)return;const scroller=menu===this.modelMenu?this.modelList:menu;if(!scroller.contains(item))return;
    const r=item.getBoundingClientRect(),s=scroller.getBoundingClientRect();if(r.top<s.top)scroller.scrollTop+=r.top-s.top;else if(r.bottom>s.bottom)scroller.scrollTop+=r.bottom-s.bottom;
  }
  positionModelMenu() {
    if(!this.ai.model.getClientRects().length){this.closeMenu();return;}
    EditingToolbarAIEffort.position(this.modelMenu,this.ai.model);
  }
  positionMenu() {
    const menu=this.menu,anchor=this.anchor;if(!menu||!anchor)return;
    if(menu===this.modelMenu){this.positionModelMenu();return;}
    const panel=this.ai.panel;let r=panel.getBoundingClientRect(),bar=this.bar.getBoundingClientRect();
    // A short floating window may borrow height while a menu is open. Never cover the draft.
    if(bar.top-r.top<200&&panel.dataset.layout==='float'&&!this.menuGeometry){
      const height=Math.min(innerHeight-16,r.height+220-(bar.top-r.top));
      if(height>r.height+1){this.menuGeometry={top:panel.style.top,height:panel.style.height};panel.style.height=height+'px';panel.style.top=Math.max(8,Math.min(r.bottom-height,innerHeight-height-8))+'px';r=panel.getBoundingClientRect();bar=this.bar.getBoundingClientRect();}
    }
    const composer=panel.querySelector('.et-ai-composer').getBoundingClientRect(),wide=menu===this.ai.attachments.menu;
    const gallery=menu===this.scopeMenu&&menu.dataset.view==='images';
    const width=gallery?Math.min(420,r.width-24):wide?Math.min(420,composer.width):Math.min(Number(menu.dataset.width)||(menu===this.modelMenu?310:260),r.width-24);
    menu.style.width=width+'px';
    const x=wide?composer.left:anchor.getBoundingClientRect().left;
    menu.style.left=Math.max(11,Math.min(x-r.left,r.width-width-12))+'px';
    const bottom=bar.top-r.top-7;
    menu.style.maxHeight=Math.max(32,Math.min(gallery?460:360,bottom-8))+'px';
    menu.style.top=Math.max(8,bottom-menu.offsetHeight)+'px';
  }
  closeMenu(focus=false) {
    if(!this.menu)return;if(this.menu===this.ai.attachments.menu)this.ai.attachments.dismiss();const anchor=this.anchor;
    if(this.menu===this.modelMenu){this.modelMenu.hidePopover();cancelAnimationFrame(this.modelFrame);this.modelFrame=null;}
    this.menu.hidden=true;anchor?.setAttribute('aria-expanded','false');this.menu=this.anchor=null;if(this.menuGeometry){Object.assign(this.ai.panel.style,this.menuGeometry);this.menuGeometry=null;}if(focus)anchor?.focus();
  }
}
