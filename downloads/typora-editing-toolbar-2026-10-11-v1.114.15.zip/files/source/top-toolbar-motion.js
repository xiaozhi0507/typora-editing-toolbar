// Placement and dragging stay in the host, independent of optional modules.
class EditingToolbarTopMotion {
  constructor(toolbar) {
    this.frame=ETDragSupport.frame(()=>this.paint(),requestAnimationFrame,cancelAnimationFrame);
    this.toolbar=toolbar;this.host=toolbar.topHost;this.bar=toolbar.topToolbar;
    this.bar.removeAttribute('title');
    this.bar.tabIndex=0;
    this.bar.setAttribute('aria-label','编辑工具栏；拖动空白处移动，靠近顶部松开吸附');
    this.bar.addEventListener('keydown',e=>{
      if(e.target!==this.bar||!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home'].includes(e.key))return;
      e.preventDefault();e.stopPropagation();if(e.key==='Home'){this.toolbar.uiSettings.topMode='docked';this.apply();this.toolbar._persistTopPlacement();return;}
      const s=this.toolbar.uiSettings,r=this.host.getBoundingClientRect(),step=e.shiftKey?40:10;
      s.topMode='floating';s.topPosition={x:r.left+(e.key==='ArrowLeft'?-step:e.key==='ArrowRight'?step:0),y:r.top+(e.key==='ArrowUp'?-step:e.key==='ArrowDown'?step:0)};this.apply();this.toolbar._persistTopPlacement();
    });
    this.host.addEventListener('pointerdown',e=>this.start(e),true);
    window.addEventListener('pointermove',e=>this.move(e),true);
    window.addEventListener('pointerup',e=>{if(this.drag?.id===e.pointerId){this.move(e);this.finish(false);}},true);
    window.addEventListener('pointercancel',()=>this.finish(true),true);
    this.bar.addEventListener('lostpointercapture',e=>{if(e.target===this.bar)this.finish(true);});
    window.addEventListener('blur',()=>this.finish(true));
    window.addEventListener('keydown',e=>{if(e.key==='Escape'&&this.drag){e.preventDefault();e.stopImmediatePropagation();this.finish(true);}},true);
    window.addEventListener('resize',()=>{this.finish(true);this.apply();});
    this.apply();
  }
  start(e){
    if(e.button!==0||e.isPrimary===false||this.drag)return;
    if(!this.bar.contains(e.target)||e.target.closest?.('button,input,textarea,select,a,[role=button],.et-popover,.et-menu-panel,.et-color-picker'))return;
    e.preventDefault();e.stopPropagation();this.toolbar._saveSelection();
    const r=this.bar.getBoundingClientRect(),s=this.toolbar.uiSettings;
    this.drag={id:e.pointerId,x:e.clientX,y:e.clientY,left:r.left,top:r.top,next:{x:r.left,y:r.top},mode:s.topMode,position:{...s.topPosition},focus:document.activeElement,moved:false};
    this.bar.setPointerCapture(e.pointerId);
  }
  move(e){
    const d=this.drag;if(!d||d.id!==e.pointerId)return;e.preventDefault();e.stopPropagation();
    if(!d.moved&&Math.hypot(e.clientX-d.x,e.clientY-d.y)<4)return;
    if(!d.moved){
      d.moved=true;this.toolbar._closeActivePopover();this.toolbar.hide();document.body.classList.add('et-top-dragging');
      d.shield=ETDragSupport.shield(document,'et-top-drag-shield');d.shield.focus({preventScroll:true});
    }
    d.next={x:d.left+e.clientX-d.x,y:d.top+e.clientY-d.y};
    this.frame.queue();
  }
  paint(){const d=this.drag;if(!d?.moved)return;this.toolbar.uiSettings.topMode='floating';this.toolbar.uiSettings.topPosition={...d.next};this.host.toggleAttribute('data-snap-top',d.next.y<=24);this.apply();}
  finish(cancel){
    const d=this.drag;if(!d)return;this.frame.cancel();
    if(cancel){this.toolbar.uiSettings.topMode=d.mode;this.toolbar.uiSettings.topPosition=d.position;this.apply();}else{this.paint();if(d.moved&&d.next.y<=24){this.toolbar.uiSettings.topMode='docked';this.apply();}}
    this.drag=null;const focus=document.hasFocus()&&document.activeElement===d.shield;d.shield?.remove();if(focus&&d.focus?.isConnected)d.focus.focus({preventScroll:true});document.body.classList.remove('et-top-dragging');
    this.host.removeAttribute('data-snap-top');
    if(this.bar.hasPointerCapture(d.id))this.bar.releasePointerCapture(d.id);
    if(d.moved&&!cancel)this.toolbar._persistTopPlacement();
  }
  apply() {
    const s=this.toolbar.uiSettings,floating=s.topMode==='floating';s.topCollapsed=false;s.responsive=true;
    this.host.dataset.placement=floating?'floating':'docked';this.host.dataset.collapsed='false';this.host.style.transform='';this.bar.inert=false;
    this.toolbar._applyToolbarButtonSize(this.bar,true);
    if(floating){
      const r=this.host.getBoundingClientRect(),position=s.topPosition||{x:24,y:100},w=document.documentElement.clientWidth,h=document.documentElement.clientHeight;
      this.host.style.left=Math.max(8,Math.min(Number.isFinite(position.x)?position.x:24,w-r.width-8))+'px';
      this.host.style.top=Math.max(8,Math.min(Number.isFinite(position.y)?position.y:100,h-r.height-8))+'px';
    }else{this.host.style.left='';this.host.style.top='';}
  }
}
