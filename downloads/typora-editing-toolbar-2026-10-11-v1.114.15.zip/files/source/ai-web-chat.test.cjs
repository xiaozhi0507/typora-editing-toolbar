const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {JSDOM}=require('jsdom'),pageBridge=require('./ai-web-chat-page.cjs');
function dom(html){const d=new JSDOM(html,{url:'https://chatgpt.com/c/test',runScripts:'outside-only'}),w=d.window;w.HTMLElement.prototype.getBoundingClientRect=function(){return {height:this.hidden?0:20,width:100};};w.setTimeout=f=>{queueMicrotask(f);return 1;};w.eval('window.bridge='+pageBridge.toString());return w;}
function browser(settled=true){const box={window:{addEventListener(){}},setTimeout,clearTimeout,URL,AbortController,ETAIWebChatPage:pageBridge,ETAIWebChatFormat:{markdown:html=>html.replace(/<[^>]*>/g,'')}};vm.createContext(box);vm.runInContext(fs.readFileSync(path.join(__dirname,'ai-web-chat-browser.js'),'utf8')+';globalThis.Browser=EditingToolbarWebChatBrowser',box);const ai={busy:false,webChat:{refreshUI(){},confirm(s){ai.confirmed=s;}}};const b=new box.Browser(ai);if(settled)b.settleConversation=async base=>base;return b;}

test('reopening connected pickers reuses options without changing webpage settings',async()=>{
 const b=browser();b.status='已连接';b.ready=true;b.snapshot={mode:'High',version:'Latest'};b.capabilities={modes:[{label:'High'}],versions:[{label:'Latest'}]};let notifications=0;const notify=b.notify.bind(b);b.notify=()=>{notifications++;notify();};let reads=0;b.call=async action=>{assert.equal(action,'snapshot');reads++;return {ready:true,mode:'High',version:''};};b.refresh=async()=>{throw Error('must not resync');};await b.options();await b.options();await b.select('version',{label:'Latest'});assert.equal(reads,1);assert.ok(notifications>0,'selecting an already cached model still refreshes project controls');assert.equal(b.snapshot.version,'Latest');assert.equal(b.status,'已连接');b.block('login');b.refresh=async()=>{reads++;return {};};await b.options();assert.equal(reads,2);
});
test('public activity belongs to the latest user and excludes hidden text and the final answer',async()=>{
 const w=dom('<div data-message-role="user">Old</div><div><span data-chatgpt-agent-turn-start hidden></span><div class="group/activity-header">Old step</div></div><div data-message-role="user">New</div><div><span data-chatgpt-agent-turn-start hidden></span><div class="group/activity-header"><button aria-expanded="false" aria-labelledby="summary"></button><span id="summary">正在思考</span></div><section hidden><div data-markdown-text-style="assistant-message">检查文件完成</div><div class="group/activity-header"><div data-markdown-text-style="assistant-message">正在生成中文稿</div></div></section><div hidden data-markdown-text-style="assistant-message">Hidden content</div></div><div data-message-role="assistant"><div class="markdown">Final answer</div><button>复制</button></div><textarea id="prompt-textarea"></textarea>');
 w.document.querySelector('button[aria-expanded]').onclick=e=>{e.target.setAttribute('aria-expanded','true');w.document.querySelector('section').hidden=false;};const snap=await w.bridge('snapshot',{progress:true});assert.deepEqual(Array.from(snap.activity,x=>x.text),['正在思考','检查文件完成','正在生成中文稿']);assert.match(snap.answerHTML,/Final answer/);assert(!snap.answerHTML.includes('检查文件'));w.close();
});
test('public file mentions preserve a clickable filename and inline code',()=>{
 const w=dom(''),bundle=require('esbuild').buildSync({entryPoints:[path.join(__dirname,'ai-web-chat-format.js')],bundle:true,format:'iife',globalName:'Format',platform:'browser',write:false}).outputFiles[0].text;w.eval(bundle+';window.convert=Format.markdown');const out=w.convert('<p><span data-markdown-copy="inline-code">complete:true</span></p><span data-file-reference="true" data-markdown-copy-text="translation-test.zip" role="button"><svg></svg>下载 translation-test.zip</span><script>alert(1)</script>');assert.match(out,/`complete:true`/);assert.match(out,/\[下载 translation-test.zip\]\(#et-web-file\/translation-test.zip\)/);assert.doesNotMatch(out,/alert/);w.close();
});
test('download capture transfers the clicked public blob and restores handlers',async()=>{
 const w=dom('<div data-message-role="assistant"><span data-file-reference="true" data-markdown-copy-text="translation-test.zip" role="button">下载 translation-test.zip</span></div><textarea id="prompt-textarea"></textarea>');w.setTimeout=()=>1;w.clearTimeout=()=>{};let clicks=0;const original=w.HTMLAnchorElement.prototype.click;w.fetch=async url=>{assert.equal(url,'blob:https://chatgpt.com/generated');return {arrayBuffer:async()=>new Uint8Array([80,75,3,4]).buffer};};w.document.querySelector('[data-file-reference]').onclick=()=>{clicks++;const a=w.document.createElement('a');a.href='blob:https://chatgpt.com/generated';a.download='translation-test.zip';a.click();};await w.bridge('file-download-start',{id:'test',name:'translation-test.zip'});await new Promise(r=>setImmediate(r));const state=await w.bridge('file-download-state',{id:'test',offset:0});assert.equal(state.base64,'UEsDBA==');assert.equal(state.length,4);assert.equal(clicks,1);assert.equal(w.HTMLAnchorElement.prototype.click,original);await w.bridge('file-download-end',{id:'other'});assert.equal(w.__etWebDownload.id,'test');await w.bridge('file-download-end',{id:'test'});assert.equal(w.__etWebDownload,undefined);w.close();
});
test('ambiguous file mentions and path names never trigger downloads',async()=>{
 const w=dom('<div data-message-role="assistant"><span data-file-reference="true" data-markdown-copy-text="translation-test.zip">one</span><span data-file-reference="true" data-markdown-copy-text="translation-test.zip">two</span></div>');let clicked=0;w.document.querySelectorAll('[data-file-reference]').forEach(e=>e.onclick=()=>clicked++);await assert.rejects(w.bridge('file-download-start',{id:'x',name:'translation-test.zip'}),/唯一/);await assert.rejects(w.bridge('file-download-start',{id:'x',name:'../test.zip'}),/无效/);assert.equal(clicked,0);w.close();
});

test('download navigation that leaves the document intact restores readiness without reloading',()=>{
 const d=new JSDOM('<body></body>'),w=d.window,box={window:w,document:w.document,setTimeout,clearTimeout,URL,EditingToolbarAIWebSession:{partition:'persist:test'}};vm.createContext(box);vm.runInContext(fs.readFileSync(path.join(__dirname,'ai-web-chat-browser.js'),'utf8')+';globalThis.Browser=EditingToolbarWebChatBrowser',box);
 const ai={node(tag,cls,text){const n=w.document.createElement(tag);n.className=cls||'';n.textContent=text||'';return n;},webChat:{refreshUI(){}}},b=new box.Browser(ai);b.inspectReadiness=()=>{};b.mount();b.ready=true;let loading=true;b.view.isLoading=()=>loading;
 const start=new w.Event('did-start-navigation');Object.assign(start,{isMainFrame:true,isInPlace:false});b.view.dispatchEvent(start);assert.equal(b.ready,false);b.view.dispatchEvent(new w.Event('did-stop-loading'));assert.equal(b.ready,false);loading=false;b.view.dispatchEvent(new w.Event('did-stop-loading'));assert.equal(b.ready,true);b.destroy();w.close();
});

test('resynchronizing a completed answer reads only its bound question and never sends or clears',async()=>{
 const b=browser(),binding={url:'https://chatgpt.com/c/test',userCount:1,answerCount:0,input:{text:'Original question'}},base={url:binding.url,userCount:1,answerCount:1,lastUser:'Original question',complete:true,answerHTML:'<p>Restored</p>'};
 b.conversation=async url=>{assert.equal(url,binding.url);return base;};b.call=async()=>{throw Error('no page mutation');};assert.equal(await b.readAnswer(binding),'Restored');
 for(const change of [{userCount:2},{answerCount:2},{lastUser:'Other question'},{busy:true},{complete:false}]){b.conversation=async()=>({...base,...change});await assert.rejects(b.readAnswer(binding),/不对应|尚未完成/);}
});
test('DOM adapter reads only visible account controls and distinguishes login/challenge from ready',async()=>{
 const w=dom('<button hidden>登录</button><textarea id="mobile-composer-prompt"></textarea><button data-composer-submit>Send</button><li data-message-role="assistant"><button>登录</button></li>');
 assert.equal((await w.bridge('snapshot')).ready,true);w.document.body.insertAdjacentHTML('afterbegin','<button>登录</button>');assert.equal((await w.bridge('snapshot')).login,true);w.document.querySelector('textarea').remove();w.document.title='Just a moment';assert.equal((await w.bridge('snapshot')).challenge,true);w.close();
});

function challengeFrame(w){
 const e=w.document.createElement('iframe');e.src='https://challenges.cloudflare.com/cdn-cgi/challenge-platform/h/g/turnstile/if/fixture';e.getBoundingClientRect=()=>({width:300,height:65});
 Object.defineProperty(e,'contentDocument',{get(){throw Error('must not read challenge document');}});w.document.body.append(e);return e;
}
test('frame-only verification blocks model controls, draft, uploads and send without touching the challenge',async()=>{
 const w=dom('<textarea id="mobile-composer-prompt"></textarea><button>Pro</button><button data-composer-submit>Send</button>');challengeFrame(w);let clicks=0;for(const b of w.document.querySelectorAll('button'))b.onclick=()=>clicks++;
 const s=await w.bridge('snapshot');assert.equal(s.challenge,true);assert.equal(s.ready,false);
 for(const action of ['open-mode','open-version','clear-composer','prepare','upload','send','slider-focus','new-chat'])await assert.rejects(w.bridge(action,{}),/Cloudflare 网页验证/);
 assert.equal(clicks,0);assert.equal(w.document.querySelector('textarea').value,'');w.close();
});
test('hidden, transparent, tiny and lookalike frames or conversation text never block a working chat',async()=>{
 const w=dom('<textarea id="mobile-composer-prompt"></textarea><li data-message-role="assistant"><p>verify you are human</p></li>');w.document.title='Just a moment';const f=challengeFrame(w);
 for(const style of ['display:none','visibility:hidden','opacity:0']){f.style.cssText=style;assert.equal((await w.bridge('snapshot')).challenge,false);}
 f.style.cssText='';f.hidden=true;assert.equal((await w.bridge('snapshot')).challenge,false);f.hidden=false;
 const parent=w.document.createElement('div');parent.style.display='none';w.document.body.append(parent);parent.append(f);assert.equal((await w.bridge('snapshot')).challenge,false);w.document.body.append(f);
 f.getBoundingClientRect=()=>({width:1,height:1});assert.equal((await w.bridge('snapshot')).challenge,false);f.getBoundingClientRect=()=>({width:300,height:65});
 f.src='https://challenges.cloudflare.com.example.org/cdn-cgi/challenge-platform/test';assert.equal((await w.bridge('snapshot')).ready,true);
 f.src='https://challenges.cloudflare.com/cdn-cgi/challenge-platform/test';w.document.querySelector('li').append(f);assert.equal((await w.bridge('snapshot')).ready,true);w.close();
});
test('interstitial title or visible verification prompt is recognized when no composer exists',async()=>{
 const w=dom('<p>正在验证…</p>');assert.equal((await w.bridge('snapshot')).challenge,true);w.document.querySelector('p').remove();w.document.title='Just a moment...';assert.equal((await w.bridge('snapshot')).challenge,true);w.close();
});
test('blocked sync clears stale settings and never reopens a hidden window; recovery requires explicit sync',async()=>{
 const b=browser(),w=dom('<section></section><div hidden></div>');b.panel=w.document.querySelector('section');b.loginHelp=w.document.querySelector('div');b.mount=()=>{};b.ready=true;b.snapshot={mode:'High'};b.capabilities.modes=[{label:'High'}];let opens=0,probes=0;
 b.show=()=>opens++;b.call=async()=>{probes++;return {challenge:true,ready:false};};
 await assert.rejects(b.refresh(),/Cloudflare.*不会自动同步/);assert.equal(b.snapshot,null);assert.equal(b.capabilities.modes.length,0);assert.equal(b.loginHelp.hidden,false);
 b.hide();await new Promise(r=>setImmediate(r));assert.equal(opens,0);assert.equal(probes,1);assert.equal(b.panel.classList.contains('is-background'),true);
 b.call=async()=>({ready:true});await b.ensure();assert.equal(b.blocked,'');assert.equal(b.loginHelp.hidden,true);assert.equal(b.ai.confirmed,undefined);assert.match(b.status,/正在读取模型选项/);b.destroy();w.close();
});
test('load inspection observes readiness only and ignores a stale result after navigation',async()=>{
 const b=browser();b.ready=true;let resolve,actions=[];b.view={getURL:()=> 'https://chatgpt.com/',executeJavaScript:code=>{actions.push(code);return new Promise(r=>resolve=r);}};
 b.inspectReadiness();b.cancelInspection();resolve({challenge:true,ready:false});await new Promise(r=>setImmediate(r));assert.equal(b.blocked,undefined);assert.equal(actions.length,1);assert.match(actions[0],/\("snapshot",\{\}\)$/);b.destroy();
});
test('verification during upload fails promptly without submission or retry',async()=>{
 const b=browser(),base={url:'https://chatgpt.com/',userCount:0,answerCount:0,draft:''};b.conversation=async()=>base;b.verifySelection=async()=>{};b.wait=async()=>{};const calls=[];
 b.call=async action=>{calls.push(action);return action==='snapshot'?{...base,challenge:true}:{...base,uploadReady:true};};
 await assert.rejects(b.request({id:'t',text:'Q',files:[{name:'test.txt'}],expected:{},onProgress(){},onText(){},onBinding(){throw Error('must not mark submitted');}}),e=>e.webSubmitted===false&&/Cloudflare/.test(e.message));
 assert.deepEqual(calls,['clear-composer','prepare','upload-ready','upload','snapshot']);
});
test('composer refuses existing drafts and sends a given turn exactly once even after lost acknowledgement',async()=>{
 const w=dom('<textarea id="mobile-composer-prompt">old draft</textarea><button data-composer-submit>发送消息</button>');let sends=0;w.document.querySelector('button').onclick=()=>sends++;
 await assert.rejects(w.bridge('prepare',{text:'new draft'}),/已有草稿/);assert.equal(sends,0);
 w.document.querySelector('textarea').value='';await w.bridge('prepare',{text:'Hello'});await w.bridge('send',{id:'turn-1',text:'Hello',userCount:0});const again=await w.bridge('send',{id:'turn-1',text:'Hello',userCount:0});assert.equal(sends,1);assert.equal(again.duplicate,true);w.close();
});
test('send rejects disabled controls and unexpected message changes without clicking',async()=>{
 const w=dom('<textarea id="mobile-composer-prompt">Hello</textarea><button data-composer-submit aria-disabled="true">发送消息</button>');let sends=0;w.document.querySelector('button').onclick=()=>sends++;
 await assert.rejects(w.bridge('send',{id:'1',text:'Hello',userCount:0}),/未发送/);w.document.querySelector('button').removeAttribute('aria-disabled');w.document.body.insertAdjacentHTML('beforeend','<li data-message-role="user">manual</li>');await assert.rejects(w.bridge('send',{id:'1',text:'Hello',userCount:0}),/未发送/);assert.equal(sends,0);w.close();
});

test('clear composer replaces text and removes quoted image/document cards through their controls only',async()=>{
 const w=dom('<div data-message-role="user" id="history"><img alt="sent.png"><button aria-label="Remove sent image"></button>Sent question</div><form><div data-composer-attachments><div><img alt="old.png"><button aria-label="移除“old.png”" style="visibility:hidden"></button></div><div><span>old.md</span><button aria-label="Remove old.md"></button></div></div><textarea id="mobile-composer-prompt">Old question</textarea><button data-composer-submit>Send</button></form>');
 const history=w.document.querySelector('#history').outerHTML,events=[];let clicks=0,sends=0;
 w.document.querySelector('#history button').onclick=()=>{throw Error('history is not draft');};w.document.querySelector('[data-composer-submit]').onclick=()=>sends++;
 const wire=()=>w.document.querySelectorAll('[data-composer-attachments] button').forEach(b=>b.onclick=()=>{clicks++;queueMicrotask(()=>{const root=w.document.querySelector('[data-composer-attachments]');b.parentElement.remove();const clone=root.cloneNode(true);root.replaceWith(clone);wire();});});wire();
 w.document.querySelector('textarea').addEventListener('input',e=>events.push(e.target.value));
 const s=await w.bridge('clear-composer',{url:'https://chatgpt.com/c/test',userCount:1});
 assert.equal(s.draft,'');assert.equal(s.composerHasAttachments,false);assert.equal(s.composerAttachmentCount,0);assert.equal(clicks,2);assert.equal(sends,0);assert.deepEqual(events,['']);assert.equal(w.document.querySelector('#history').outerHTML,history);
 await w.bridge('prepare',{text:'Only the new question'});await w.bridge('send',{id:'replacement',text:'Only the new question',userCount:1});assert.equal(sends,1);w.close();
});

test('clear composer deletes rich text using editing events and verifies the remounted editor',async()=>{
 const w=dom('<form><div id="prompt-textarea" contenteditable="true"><p>Old text</p><p>More text</p></div><button data-composer-submit>Send</button></form>');let deletes=0;
 w.document.execCommand=(command,_ui,value)=>{assert.equal(command,'delete');assert.equal(value,'');assert.equal(w.getSelection().toString(),'Old textMore text');deletes++;const e=w.document.querySelector('#prompt-textarea'),clone=e.cloneNode(false);clone.innerHTML='<p><br class="ProseMirror-trailingBreak"></p>';e.replaceWith(clone);return true;};
 assert.equal((await w.bridge('clear-composer')).draft,'');assert.equal(deletes,1);w.close();
});

test('unremovable or pending attachments block cleanup without repeatedly clicking a stuck control',async()=>{
 for(const html of ['<div data-composer-attachments>Unknown attachment</div>','<div data-composer-attachments><button aria-label="Remove broken.png"></button></div>','<div role="progressbar"></div>']){
  const w=dom('<form>'+html+'<textarea id="mobile-composer-prompt">Old</textarea><button data-composer-submit>Send</button></form>');let clicks=0;
  const remove=w.document.querySelector('[aria-label]');if(remove)remove.onclick=()=>clicks++;
  await assert.rejects(w.bridge('clear-composer'),/尚未清空/);assert.equal(clicks,remove?1:0);w.close();
 }
});

test('cleanup refuses generation, login, invalid binding or manual conversation changes',async()=>{
 for(const extra of ['<button data-testid="stop-button">Stop</button>','<button>登录</button>']){
  const w=dom('<form><textarea id="mobile-composer-prompt">Keep</textarea>'+extra+'</form>');await assert.rejects(w.bridge('clear-composer'),/状态发生变化/);assert.equal(w.document.querySelector('textarea').value,'Keep');w.close();
 }
 const w=dom('<form><div data-composer-attachments><button aria-label="Remove old.md"></button></div><textarea id="mobile-composer-prompt">Old</textarea></form>');
 await assert.rejects(w.bridge('clear-composer',{userCount:1}),/会话发生变化/);assert.equal(w.document.querySelector('textarea').value,'Old');
 w.document.querySelector('button').onclick=()=>w.document.body.insertAdjacentHTML('afterbegin','<div data-message-role="user">Manual send</div>');
 await assert.rejects(w.bridge('clear-composer'),/状态发生变化/);w.close();
});

test('rich composer reads Chromium div lines and ProseMirror paragraphs without losing blank lines or indentation',async()=>{
 const source='Intro\n\nQuestion:\n    x = 1\n\nEnd',layouts=[
  'Intro<div><br></div><div>Question:</div><div>&nbsp; &nbsp; x = 1</div><div><br></div><div>End</div>',
  '<p>Intro</p><p><br class="ProseMirror-trailingBreak"></p><p>Question:</p><p>&nbsp; &nbsp; x = 1</p><p><br></p><p>End</p>',
  '<p>Intro<br><br>Question:<br>&nbsp; &nbsp; x = 1<br><br>End<br class="ProseMirror-trailingBreak"></p>'
 ];
 for(const html of layouts){const w=dom('<div id="prompt-textarea" contenteditable="true">'+html+'</div><button data-composer-submit>Send</button>');let sends=0;w.document.querySelector('button').onclick=()=>sends++;
  assert.equal((await w.bridge('snapshot')).draft,source);
  await w.bridge('send',{id:'rich',text:source,userCount:0});assert.equal(sends,1);
  await assert.rejects(w.bridge('send',{id:'changed',text:source.replace('    x','  x'),userCount:0}),/未发送/);
  await assert.rejects(w.bridge('prepare',{text:source.replace('End','Wrong')}),/已有草稿/);w.close();
 }
});

test('prepare verifies the remounted rich editor after input and permits the identical unsubmitted draft',async()=>{
 const w=dom('<div id="prompt-textarea" contenteditable="true"></div><button data-composer-submit>Send</button>');
 w.getSelection=()=>({removeAllRanges(){},addRange(){}});let inserts=0;
 w.document.execCommand=()=>{inserts++;const next=w.document.createElement('div');next.id='prompt-textarea';next.contentEditable='true';next.innerHTML='<p>A</p><p><br></p><p>B</p>';w.document.querySelector('#prompt-textarea').replaceWith(next);return true;};
 assert.equal((await w.bridge('prepare',{text:'A\r\n\r\nB'})).draft,'A\n\nB');
 assert.equal((await w.bridge('prepare',{text:'A\n\nB'})).draft,'A\n\nB');assert.equal(inserts,2);
 await assert.rejects(w.bridge('prepare',{text:'A\nB'}),/已有草稿/);w.close();
});
test('response requires its own completion control and exposes website connection errors',async()=>{
 const w=dom('<li data-message-role="user">Hello</li><li data-message-role="assistant" id="a1"><div class="markdown"><p>Answer</p></div><button>复制</button></li><button data-testid="stop-button">停止</button>');let s=await w.bridge('snapshot');assert.equal(s.complete,false);assert.equal(s.answerId,'a1');w.document.querySelector('[data-testid=stop-button]').remove();s=await w.bridge('snapshot');assert.equal(s.complete,true);w.document.body.insertAdjacentHTML('beforeend','<li data-conversation-recovery>无法建立连接</li>');assert.match((await w.bridge('snapshot')).error,/无法建立连接/);w.close();
});

test('current website search units identify user bubbles, answer markdown and sibling completion controls',async()=>{
 const w=dom('<div id="thread"><section><div data-content-search-unit-key="fallback-turn-0:0:user"><div data-user-message-bubble="true">Question</div><button aria-label="复制消息"></button></div><div data-content-search-unit-key="fallback-turn-0:2:assistant"><h4 data-conversation-role="assistant">ChatGPT 说：</h4><div data-chatgpt-selection-message-id="answer-real"><div data-markdown-text-style="assistant-message"><p>Answer</p></div></div></div><div><button aria-label="复制"></button></div></section></div>');
 let s=await w.bridge('snapshot');assert.equal(s.userCount,1);assert.equal(s.answerCount,1);assert.equal(s.lastUser,'Question');assert.equal(s.answerId,'answer-real');assert.equal(s.answerHTML,'<p>Answer</p>');assert.equal(s.complete,true);
 w.document.querySelector('#thread').insertAdjacentHTML('beforeend','<section><div data-content-search-unit-key="fallback-turn-1:0:user">Next</div><div data-content-search-unit-key="fallback-turn-1:2:assistant"><div data-markdown-text-style="assistant-message">Partial</div></div></section>');
 s=await w.bridge('snapshot');assert.equal(s.answerCount,2);assert.equal(s.complete,false);assert.equal(s.answerHTML,'Partial');w.close();
});

test('current website message controls cannot masquerade as login or model controls',async()=>{
 const w=dom('<textarea id="mobile-composer-prompt"></textarea><div data-content-search-unit-key="fallback-turn-0:2:assistant"><button>登录</button><button>Pro</button></div>');
 assert.equal((await w.bridge('snapshot')).login,false);await assert.rejects(w.bridge('open-mode'),/未提供/);w.close();
});

test('closed model menus use the composer trigger, not unrelated page labels, and normalize localized effort labels',async()=>{
 const w=dom('<div>高</div><button data-codex-intelligence-trigger>Extra High</button>');assert.equal((await w.bridge('snapshot')).mode,'Extra High');
 w.document.querySelector('button').textContent='极高';assert.equal((await w.bridge('snapshot')).mode,'Extra High');w.close();
});
test('discrete DOM slider reports actual labels and native value, not API effort aliases',async()=>{
 const w=dom('<button>思考强度</button><div role="dialog"><span id="mode">Medium</span><input type="range" min="0" max="4" value="1" aria-valuetext="Medium"></div>');const input=w.document.querySelector('input');input.oninput=()=>{const labels=['Instant','Medium','High','Extra High','6 Pro'];input.setAttribute('aria-valuetext',labels[input.value]);w.document.querySelector('#mode').textContent=labels[input.value];};
 const s=await w.bridge('slider-value',{value:4});assert.equal(s.mode,'6 Pro');assert.equal(s.slider.value,4);await assert.rejects(w.bridge('slider-value',{value:5}),/无效/);w.close();
});

test('the idle Pro composer trigger opens thinking controls and repeated sync does not close them',async()=>{
 const w=dom('<textarea id="mobile-composer-prompt"></textarea><button id="pro">Pro</button><div role="dialog" hidden><span>6 Pro</span><input type="range" min="0" max="4" value="4" aria-valuetext="6 Pro"></div>');let clicks=0;w.document.querySelector('#pro').onclick=()=>{clicks++;const d=w.document.querySelector('[role=dialog]');d.hidden=!d.hidden;};const first=await w.bridge('open-mode');assert.equal(first.slider.value,4);assert.equal(first.mode,'6 Pro');assert.equal((await w.bridge('open-mode')).slider.value,4);assert.equal(clicks,1);w.close();
});

test('website errors omit the Electron remote-call wrapper in visible status',async()=>{
 const b=browser();b.ready=true;b.view={getURL:()=> 'https://chatgpt.com/',executeJavaScript:async()=>{throw Error("Error invoking remote method 'GUEST_VIEW_MANAGER_CALL': Error: 网页档位不可用");}};await assert.rejects(b.call('open-mode'),e=>e.message==='网页档位不可用');
});

test('Google embedded-login rejection gives an actionable notice without reading or executing the auth page',async()=>{
 const b=browser();b.ready=true;let calls=0;b.view={getURL:()=> 'https://accounts.google.com/v3/signin/rejected?private=do-not-read',executeJavaScript:()=>{calls++;}};
 await assert.rejects(b.call('snapshot'),e=>/Google.*内嵌/.test(e.message)&&/不会自动同步/.test(e.message)&&!e.message.includes('private'));assert.equal(calls,0);
 b.view.getURL=()=> 'https://accounts.google.com/v3/signin/identifier';assert.equal(b.loginNotice(),'');await assert.rejects(b.call('snapshot'),/请先完成/);
});

function sharedModelMenu(){
 const w=dom('<button data-codex-intelligence-trigger aria-expanded="false">Pro</button><div role="menu" hidden><div id="intensity"><span id="announcement">6 Pro，第 5 项，共 5 项。</span><div data-model-picker-view-toggle="true" role="menuitem">Pro</div><div data-reasoning-slider="true" role="menuitem" tabindex="-1" aria-describedby="announcement"><span role="slider" aria-hidden="true" aria-valuemin="0" aria-valuemax="4" aria-valuenow="4"></span></div></div><div id="versions" aria-hidden="true"><div role="menuitemradio" aria-checked="true">Latest</div><div role="menuitemradio" aria-checked="false">GPT-5.6 Sol</div></div></div>');
 const d=w.document,menu=d.querySelector('[role=menu]'),trigger=d.querySelector('button'),simple=d.querySelector('#intensity'),versions=d.querySelector('#versions');
 trigger.onclick=()=>{menu.hidden=!menu.hidden;trigger.setAttribute('aria-expanded',String(!menu.hidden));};
 d.querySelector('[data-model-picker-view-toggle]').onclick=()=>{simple.setAttribute('aria-hidden','true');versions.setAttribute('aria-hidden','false');};
 for(const row of d.querySelectorAll('[role=menuitemradio]'))row.onclick=()=>{for(const r of d.querySelectorAll('[role=menuitemradio]'))r.setAttribute('aria-checked',String(r===row));simple.setAttribute('aria-hidden','false');versions.setAttribute('aria-hidden','true');d.querySelector('#announcement').textContent=(row.textContent==='Latest'?'6':'5.6')+' Pro，第 5 项，共 5 项。';};
 return w;
}

test('real website menu focuses its accessible keyboard control and reads hidden thumb metadata',async()=>{
 const w=sharedModelMenu(),d=w.document;let s=await w.bridge('open-mode');assert.equal(s.slider.value,4);assert.equal(s.mode,'6 Pro');await w.bridge('slider-focus');assert.equal(d.activeElement,d.querySelector('[data-reasoning-slider]'));
 d.querySelector('#announcement').textContent='5.6 Extra High，第 4 项，共 5 项。';d.querySelector('[role=slider]').setAttribute('aria-valuenow','3');s=await w.bridge('snapshot');assert.equal(s.mode,'Extra High');assert.equal(s.slider.value,3);w.close();
});

test('shared version view can open directly, select a model, and return to its observed intensity',async()=>{
 const w=sharedModelMenu();let s=await w.bridge('open-version');assert.equal(s.version,'Latest');assert.equal(s.options.length,2);
 await w.bridge('choose-option',{label:'GPT-5.6 Sol'});s=await w.bridge('open-mode');assert.equal(s.mode,'5.6 Pro');s=await w.bridge('open-version');assert.equal(s.version,'GPT-5.6 Sol');s=await w.bridge('open-mode');assert.equal(s.mode,'5.6 Pro');
 // Reopening a remembered version view still returns the selected version.
 await w.bridge('open-version');w.document.querySelector('button').click();s=await w.bridge('open-version');assert.equal(s.version,'GPT-5.6 Sol');w.close();
});

test('closing or inert model menus do not count as active selectable options',async()=>{
 const w=dom('<div role="menu" data-state="closed"><div role="menuitemradio" aria-checked="true">Latest</div></div><div inert><button>Pro</button></div>');assert.equal((await w.bridge('snapshot')).options.length,0);await assert.rejects(w.bridge('open-mode'),/未提供/);w.close();
});

test('the navigation-target composer trigger also opens the shared version menu',async()=>{
 const w=sharedModelMenu(),trigger=w.document.querySelector('button');trigger.removeAttribute('data-codex-intelligence-trigger');trigger.setAttribute('data-composer-navigation-target','reasoning');trigger.textContent='Extra High';
 const s=await w.bridge('open-version');assert.equal(s.version,'Latest');assert.equal(s.options.length,2);w.close();
});

test('an ordinary labelled effort button opens versions through the shared popup too',async()=>{
 const w=sharedModelMenu(),trigger=w.document.querySelector('button');trigger.removeAttribute('data-codex-intelligence-trigger');trigger.textContent='Extra High';
 assert.equal((await w.bridge('open-version')).version,'Latest');w.close();
});

test('version discovery waits for the complete menu when Latest mounts after older models',async()=>{
 const w=sharedModelMenu(),latest=w.document.querySelector('[role=menuitemradio]');latest.hidden=true;
 let ticks=0;w.setTimeout=f=>{queueMicrotask(()=>{if(++ticks===4)latest.hidden=false;f();});return ticks;};
 const s=await w.bridge('open-version');assert.deepEqual(Array.from(s.options,o=>o.label),['Latest','GPT-5.6 Sol']);assert.equal(s.version,'Latest');w.close();
});

test('an already open partial version menu is settled before reuse',async()=>{
 const w=sharedModelMenu(),d=w.document;d.querySelector('button').click();d.querySelector('[data-model-picker-view-toggle]').click();
 const latest=d.querySelector('[role=menuitemradio]');latest.hidden=true;let ticks=0;w.setTimeout=f=>{queueMicrotask(()=>{if(++ticks===2)latest.hidden=false;f();});return ticks;};
 assert.equal((await w.bridge('open-version')).version,'Latest');w.close();
});

test('version labels use the menu row title without selection icons or retirement descriptions',async()=>{
 const w=dom('<div role="menu"><div role="menuitemradio" data-model-selected="true"><svg><title>Selected</title></svg><div data-menu-row-content="true"><span>Latest</span><span aria-hidden="true">✓</span></div></div><div role="menuitemradio"><div data-menu-row-content="true"><div><span>GPT-5.5</span><span>Leaving on October 14</span></div></div></div></div>');
 const s=await w.bridge('open-version');assert.deepEqual(Array.from(s.options,o=>o.label),['Latest','GPT-5.5']);assert.equal(s.version,'Latest');
 let clicked=false;w.document.querySelector('[data-model-selected]').onclick=()=>clicked=true;await w.bridge('choose-option',{label:'Latest'});assert.equal(clicked,true);w.close();
});

test('a stable menu without Latest does not fabricate an available version',async()=>{
 const w=dom('<div role="menu"><div role="menuitemradio" aria-checked="true">GPT-5.5</div></div>');const s=await w.bridge('open-version');assert.deepEqual(Array.from(s.options,o=>o.label),['GPT-5.5']);w.close();
});

test('localized 最新 is exposed as Latest and selected through the same real menu row',async()=>{
 const w=dom('<div role="menu"><div role="menuitemradio" aria-checked="true" data-model-selected="true"><div data-menu-row-content="true"><span>最新</span><svg><title>已选择</title></svg></div></div><div role="menuitemradio" aria-checked="false"><div data-menu-row-content="true"><span>GPT-5.6 Sol</span></div></div><div role="menuitemradio" aria-checked="false">GPT-5.5</div></div>');
 let clicks=0;w.document.querySelector('[data-model-selected]').onclick=()=>clicks++;const s=await w.bridge('open-version');assert.deepEqual(Array.from(s.options,o=>o.label),['Latest','GPT-5.6 Sol','GPT-5.5']);assert.equal(s.version,'Latest');await w.bridge('choose-option',{label:'Latest'});assert.equal(clicks,1);assert.equal(w.document.querySelector('span').textContent,'最新');w.close();
});

test('document upload selects the unrestricted input, not an image/video-only picker',async()=>{
 const w=dom('<input id="media" type="file" accept="image/*,video/*"><input id="all" type="file">');let target;
 Object.defineProperty(w.HTMLInputElement.prototype,'files',{set(){target=this.id;},configurable:true});w.DataTransfer=class{constructor(){this.items={add(){}};this.files=[];}};
 await w.bridge('upload',{files:[{name:'probe.txt',type:'text/plain',base64:'YWJj'}]});assert.equal(target,'all');w.document.querySelector('#all').remove();await assert.rejects(w.bridge('upload',{files:[{name:'probe.txt',type:'text/plain',base64:'YWJj'}]}),/上传控件/);w.close();
});

test('upload waits for enabled controls in the current composer and refuses disabled or unrelated inputs',async()=>{
 const w=dom('<input type="file" id="unrelated"><form><textarea id="mobile-composer-prompt"></textarea><fieldset disabled><input id="document" type="file" aria-label="附加文件"></fieldset></form>');
 const args={files:[{name:'probe.md',type:'text/markdown',base64:'YWJj'}]};let dispatched=0;
 Object.defineProperty(w.HTMLInputElement.prototype,'files',{set(){dispatched++;},configurable:true});w.DataTransfer=class{constructor(){this.items={add(){}};this.files=[];}};
 assert.equal((await w.bridge('upload-ready',args)).uploadReady,false);await assert.rejects(w.bridge('upload',args),/上传控件尚未可用/);assert.equal(dispatched,0);
 w.document.querySelector('fieldset').disabled=false;assert.equal((await w.bridge('upload-ready',args)).uploadReady,true);await w.bridge('upload',args);assert.equal(dispatched,1);
 w.document.querySelector('#document').disabled=true;assert.equal((await w.bridge('upload-ready',args)).uploadReady,false);await assert.rejects(w.bridge('upload',args),/上传控件尚未可用/);assert.equal(dispatched,1);w.close();
});

test('attachment initialization can be canceled before uploading or marking a submission',async()=>{
 const b=browser(),controller=new AbortController();b.conversation=async()=>({draft:'',userCount:0});b.verifySelection=async()=>{};let uploads=0,bindings=0;
 b.call=async action=>{if(action==='upload')uploads++;return {uploadReady:false};};const wait=b.wait.bind(b);b.wait=async ms=>{controller.abort();await wait(ms,controller.signal);};
 await assert.rejects(b.request({id:'cancel-upload',text:'Q',files:[{name:'probe.md',type:'text/markdown'}],expected:{},signal:controller.signal,onProgress(){},onText(){},onBinding(){bindings++;}}),e=>e.name==='AbortError'&&e.webSubmitted===false);
 assert.equal(uploads,0);assert.equal(bindings,0);
});

test('completed upload accepts website numeric renames but not partial names or one chip for two files',()=>{
 const b=browser(),files=[{name:'paper[1].md'},{name:'data.csv'}];
 assert.equal(b.uploadedNamesMatch(files,'paper[1](2).md\n\ndata (1).csv\nQuestion'),true);
 assert.equal(b.uploadedNamesMatch(files,'paper[1].md\n\ndata.csv'),true);
 assert.equal(b.uploadedNamesMatch(files,'paper[1].md.old\n\ndata.csv'),false);
 assert.equal(b.uploadedNamesMatch(files,'Please read paper[1].md\n\ndata.csv'),false);
 assert.equal(b.uploadedNamesMatch([{name:'paper.md'},{name:'paper.md'}],'paper.md'),false);
});

test('composer attachment snapshots read thumbnail metadata and exclude filenames in the draft or old replies',async()=>{
 const w=dom('<div data-message-role="assistant"><img alt="old.png"><button>Remove</button></div><form><div><img id="icon" alt="avatar"><div id="mobile-composer-prompt" contenteditable="true">not-uploaded.md</div><div><span>paper.md</span><button>Remove file</button></div><div><img id="pic" alt="figure.png"><button aria-label="移除图片"></button></div><div role="progressbar"></div></div></form>');
 const img=w.document.querySelector('#pic');Object.defineProperty(img,'complete',{value:true});Object.defineProperty(img,'naturalWidth',{value:20});
 let s=await w.bridge('snapshot');assert.equal(s.composerImages.length,1);assert.equal(s.composerImages[0].names[0],'figure.png');assert.equal(s.composerImages[0].ready,true);assert.match(s.composerText,/paper.md/);assert.doesNotMatch(s.composerText,/not-uploaded/);assert.equal(s.uploadBusy,true);
 w.document.querySelector('[role=progressbar]').remove();assert.equal((await w.bridge('snapshot')).uploadBusy,false);w.close();
});

test('real composer image card with a quoted Chinese removal label is recognized without hovering',async()=>{
 const w=dom('<form><div data-composer-attachments data-visible-attachments><div class="composer-attachment-surface" role="button" aria-label="diagram.png"><span><img alt="diagram.png"></span><button aria-label="移除“diagram.png”" style="visibility:hidden"></button></div></div><div contenteditable="true" class="ProseMirror">Question</div><button data-composer-submit>发送</button></form>');
 const pic=w.document.querySelector('img');Object.defineProperty(pic,'complete',{value:true});Object.defineProperty(pic,'naturalWidth',{value:240});
 const s=await w.bridge('snapshot');assert.equal(s.composerImages.length,1);assert.equal(s.composerImages[0].ready,true);assert.equal(s.composerAttachmentCount,1);assert.equal(s.uploadBusy,false);w.close();
});

test('mixed document/image upload accepts ready thumbnail cards without visible filenames',()=>{
 const b=browser(),files=[{name:'paper.md',type:'text/markdown'},{name:'figure.png',type:'image/png'}],s={composerText:'paper.md',composerImages:[{names:['图像'],ready:true}]};
 assert.equal(b.uploadedFilesMatch(files,s),true);
 assert.equal(b.uploadedFilesMatch(files,{...s,composerText:''}),false);
 assert.equal(b.uploadedFilesMatch(files,{...s,composerImages:[{names:['figure(1).png'],ready:true}]}),true);
 assert.equal(b.uploadedFilesMatch(files,{...s,composerImages:[{names:['different.png'],ready:true}]}),false);
 assert.equal(b.uploadedFilesMatch(files,{...s,composerImages:[{names:[],ready:false}]}),false);
 assert.equal(b.uploadedFilesMatch([...files,{name:'other.png',type:'image/png'}],s),false);
 assert.equal(b.uploadedFilesMatch(files,{...s,composerImages:[...s.composerImages,...s.composerImages]}),false);
});

test('mixed attachment transport waits for thumbnail readiness then sends only once',async()=>{
 const b=browser(),base={url:'https://chatgpt.com/',draft:'',ready:true,userCount:0,answerCount:0};b.conversation=async()=>base;b.verifySelection=async()=>{};b.wait=async()=>{};let reads=0,sends=0,uploads=0;
 b.call=async action=>{
  if(action==='upload-ready')return {...base,uploadReady:true};if(action==='upload'){uploads++;return base;}if(action==='send'){sends++;return {};}
  if(action==='snapshot'&&!sends)return {...base,composerText:'paper.md',composerImages:[{names:[],ready:++reads>=2}],uploadBusy:reads<3,sendReady:true};
  if(action==='snapshot')return {...base,url:'https://chatgpt.com/c/mixed',userCount:1,lastUser:'Q',answerCount:1,answerHTML:'<p>Done</p>',complete:true};return base;
 };
 const out=await b.request({id:'mixed',text:'Q',files:[{name:'paper.md',type:'text/markdown'},{name:'image.png',type:'image/png'}],expected:{},onProgress(){},onText(){},onBinding(){}});assert.equal(out.text,'Done');assert.equal(sends,1);assert.equal(uploads,1);assert.ok(reads>=6);
});

test('every send replaces an existing web draft and attachments before preparing its own payload',async()=>{
 for(const draft of ['Different old question','Q',''])for(const files of [[],[{name:'diagram.png',type:'image/png'}]]){
  const b=browser(),base={url:'https://chatgpt.com/',draft,ready:true,userCount:0,answerCount:0,composerHasAttachments:true,composerImages:[{names:['old.png'],ready:true}],composerAttachmentCount:1,sendReady:true};
  b.conversation=async(_url,_signal,options)=>{assert.equal(options.replaceDraft,true);return base;};b.verifySelection=async()=>{};b.wait=async()=>{};const actions=[];let sends=0;
  b.call=async(action,args)=>{actions.push(action);if(action==='clear-composer'){assert.equal(args.userCount,0);return {...base,draft:'',composerHasAttachments:false,composerImages:[],composerAttachmentCount:0};}
   if(action==='prepare'){assert.equal(args.text,'Q');assert.equal(actions[0],'clear-composer');return base;}
   if(action==='upload-ready')return {...base,uploadReady:true};if(action==='upload'){assert.deepEqual(args.files,files);return base;}
   if(action==='send'){sends++;return {};}
   return sends?{...base,url:'https://chatgpt.com/c/ok',userCount:1,lastUser:'Q',answerCount:1,answerHTML:'Done',complete:true}:{...base,draft:'Q',composerHasAttachments:!!files.length,composerImages:files.map(f=>({names:[f.name],ready:true})),composerAttachmentCount:files.length};
  };
  const result=await b.request({id:'replace',text:'Q',files,expected:{},onProgress(){},onText(){},onBinding(){}});
  assert.equal(result.text,'Done');assert.equal(sends,1);assert.equal(actions.filter(x=>x==='upload').length,files.length?1:0);
 }
});

test('failed or canceled composer cleanup never prepares, uploads or submits',async()=>{
 for(const canceled of [false,true]){
  const b=browser(),base={url:'https://chatgpt.com/',draft:'Old',userCount:0},controller=new AbortController(),calls=[];
  b.conversation=async()=>base;b.verifySelection=async()=>{};
  b.call=async action=>{calls.push(action);assert.equal(action,'clear-composer');if(canceled){controller.abort();return {...base,draft:''};}throw Error('旧附件尚未清空');};
  await assert.rejects(b.request({id:'blocked',text:'Q',files:[],expected:{},signal:controller.signal,onProgress(){},onText(){},onBinding(){throw Error('must not submit');}}),e=>e.webSubmitted===false&&(canceled?e.name==='AbortError':/尚未清空/.test(e.message)));
  assert.deepEqual(calls,['clear-composer']);
 }
});

test('only a send can discard the draft before navigating; merely opening a conversation preserves it',async()=>{
 const b=browser(),source={url:'https://chatgpt.com/c/old',draft:'Old',userCount:1},target='https://chatgpt.com/c/new';let src=source.url,cleared=0;
 b.view={get src(){return src;},set src(v){assert.equal(cleared,1);src=v;}};b.ensure=async()=>({...source,url:src});b.wait=async()=>{};
 b.call=async(action,args)=>{assert.equal(action,'clear-composer');assert.equal(src,source.url);assert.equal(args.url,source.url);cleared++;return {...source,draft:''};};
 await assert.rejects(b.conversation(target),/未发送草稿/);assert.equal(cleared,0);
 await assert.rejects(b.conversation('https://example.com/',undefined,{replaceDraft:true}),/地址无效/);assert.equal(cleared,0);
 assert.equal((await b.conversation(target,undefined,{replaceDraft:true})).url,target);assert.equal(cleared,1);
});

test('a stray attachment added after cleanup prevents text-only submission',async()=>{
 const b=browser(),base={url:'https://chatgpt.com/',draft:'',userCount:0};b.conversation=async()=>base;b.verifySelection=async()=>{};b.wait=async()=>{};
 b.call=async action=>{assert.notEqual(action,'send');return action==='snapshot'?{...base,composerHasAttachments:true}:base;};
 await assert.rejects(b.request({id:'stray',text:'Q',files:[],expected:{},onProgress(){},onText(){},onBinding(){throw Error('must not submit');}}),/附件在发送前发生变化/);
});

test('file request waits for hydration and renamed upload before submitting exactly once',async()=>{
 const b=browser(),base={url:'https://chatgpt.com/',draft:'',userCount:0,answerCount:0};b.conversation=async()=>base;b.verifySelection=async()=>{};b.wait=async()=>{};
 let checks=0,uploads=0,sends=0,polls=0;
 b.call=async action=>{
  if(action==='upload-ready')return {...base,uploadReady:++checks>2};
  if(action==='upload'){assert.equal(checks,3);uploads++;return base;}
  if(action==='send'){assert.ok(polls>=3);sends++;return base;}
  if(action==='snapshot'&&!sends){polls++;return {...base,composerText:'probe(2).md\nQuestion',sendReady:true,uploadBusy:false};}
  if(action==='snapshot')return {...base,url:'https://chatgpt.com/c/file-test',userCount:1,lastUser:'Question',answerCount:1,answerHTML:'<p>File answer</p>',complete:true};
  return base;
 };
 const result=await b.request({id:'file-ready',text:'Question',files:[{name:'probe.md',type:'text/markdown'}],expected:{},onProgress(){},onText(){},onBinding(){}});
 assert.equal(result.text,'File answer');assert.equal(uploads,1);assert.equal(sends,1);
});

test('initial loading may retry only a timed-out read-only snapshot within the readiness wait',async()=>{
 const b=browser();b.mount=()=>{};b.ready=true;b.wait=async()=>{};let reads=0;
 b.call=async action=>{assert.equal(action,'snapshot');if(++reads<3)throw Error('网页操作超时，请打开网页检查');return {ready:true,modeReady:true};};
 assert.equal((await b.ensure(undefined,{modelControls:true})).ready,true);assert.equal(reads,3);
 b.call=async()=>{throw Error('Other error');};await assert.rejects(b.ensure(),/Other error/);
});

test('keyboard slider waits for the range and announced label to settle before confirming',async()=>{
 const b=browser();b.wait=async()=>{};let reads=0,keys=0;b.view={sendInputEvent(){keys++;}};
 b.call=async action=>action==='slider-focus'?{slider:{value:1,native:false}}:++reads===1?{slider:{value:1},mode:'Medium'}:reads===2?{slider:{value:2},mode:''}:{slider:{value:2},mode:'High'};
 const s=await b.setSlider(2);assert.equal(s.mode,'High');assert.equal(reads,4);assert.equal(keys,2);
});

test('version verification tolerates popup remounting without selecting or sending anything',async()=>{
 const b=browser();b.wait=async()=>{};let calls=0;b.call=async action=>{assert.equal(action,'open-version');if(++calls===1)throw Error('网页未提供可识别的模型版本菜单，请打开网页检查');if(calls===2)return {options:[]};return {options:[{label:'Latest',selected:true}]};};
 assert.equal((await b.versionOptions()).options[0].label,'Latest');assert.equal(calls,3);
 b.call=async()=>{throw Error('请先完成 GPT 网页登录');};await assert.rejects(b.versionOptions(),/登录/);
});
test('capability discovery restores the original website position and accepts only distinct observed labels',async()=>{
 const b=browser();let current=1,restored=false;const labels=['Instant','Medium','High','Extra High','6 Pro'];b.call=async()=>({slider:{min:0,max:4,value:current,native:true},mode:labels[current]});b.setSlider=async n=>{current=n;if(n===1)restored=true;return b.call();};b.dismiss=async()=>{};await b.discoverModes();assert.equal(current,1);assert.equal(restored,true);assert.deepEqual(Array.from(b.capabilities.modes,m=>m.label),labels);
 b.call=async()=>({slider:{min:0,max:4,value:current,native:true},mode:'Medium'});await assert.rejects(b.discoverModes(),/可确认/);assert.equal(current,1);
});
test('failed website selection never commits a local success or silently falls back',async()=>{
 const b=browser();b.ensure=async()=>({ready:true});b.call=async()=>({slider:{value:1},mode:'Medium'});b.setSlider=b.call;b.dismiss=async()=>{};
 await assert.rejects(b.select('mode',{label:'High',value:2}),/未确认/);assert.equal(b.ai.confirmed,undefined);assert.equal(b.snapshot,null);assert.equal(b.switching,false);
});
test('Pro version selection requires a checked option and keeps the website label',async()=>{
 const b=browser();b.ensure=async()=>({ready:true});b.snapshot={mode:'6 Pro'};b.dismiss=async()=>{};b.discoverModes=async()=>{b.snapshot={mode:'6 Pro'};};let picked=false;b.call=async action=>{if(action==='choose-option')picked=true;return {options:[{label:'Latest',selected:picked}]};};await b.select('version',{label:'Latest'});assert.equal(b.ai.confirmed.version,'Latest');assert.equal(b.ai.confirmed.mode,'6 Pro');
});

test('version changes rediscover model-specific effort names before committing',async()=>{
 const b=browser();b.ensure=async()=>({ready:true});b.snapshot={mode:'6 Pro'};b.dismiss=async()=>{};b.discoverModes=async()=>{b.snapshot={mode:'5.6 Pro'};};b.call=async()=>({options:[{label:'GPT-5.6 Sol',selected:true}]});await b.select('version',{label:'GPT-5.6 Sol'});assert.equal(b.ai.confirmed.mode,'5.6 Pro');assert.equal(b.ai.confirmed.version,'GPT-5.6 Sol');
});

test('readiness snapshots with closed menus cannot erase verified model settings',async()=>{
 const b=browser();b.mount=()=>{};b.ready=true;b.snapshot={mode:'High',version:'Latest'};b.call=async()=>({ready:true,mode:'',version:'Pro'});await b.ensure();assert.equal(b.snapshot.mode,'High');assert.equal(b.snapshot.version,'Latest');
});

test('a new conversation waits for both composer and hydrated model controls before verification',async()=>{
 const b=browser();b.mount=()=>{};b.ready=true;b.wait=async()=>{};b.dismiss=async()=>{};b.capabilities.modes=[{label:'Extra High'}];let reads=0,opened=false;
 b.call=async action=>{if(action==='snapshot'){reads++;return {ready:reads>=2,modeReady:reads>=4};}if(action==='open-mode'){opened=true;assert.ok(reads>=4);return {mode:'Extra High'};}throw Error('unexpected '+action);};
 await b.verifySelection({mode:'Extra High'});assert.equal(opened,true);assert.equal(reads,4);
});

test('verified navigation restores cleared capabilities for the following assistant turn',async()=>{
 const b=browser(),known={modes:[{label:'High',value:2}],versions:[{label:'Latest'}]};b.capabilities=known;
 b.conversation=async()=>{b.capabilities={modes:[],versions:[]};return {draft:'',userCount:0};};let verified=false;
 b.verifySelection=async()=>{verified=true;};b.call=async action=>{assert.equal(action,'clear-composer');assert.equal(verified,true);assert.equal(b.capabilities,known);throw Error('fixture ends before sending');};
 const request={id:'t',text:'Q',files:[],expected:{mode:'High'},onProgress(){},onText(){},onBinding(){}};
 await assert.rejects(b.request(request),/fixture ends/);
 b.verifySelection=async()=>{throw Error('selection changed');};await assert.rejects(b.request(request),/selection changed/);assert.equal(b.capabilities.modes.length,0);
});
test('readiness waiting stops on cancellation, website failure or challenge without clicking controls',async()=>{
 const b=browser();b.mount=()=>{};b.ready=true;const controller=new AbortController();b.call=async action=>{assert.equal(action,'snapshot');return {ready:true,modeReady:false};};b.wait=async()=>controller.abort();
 await assert.rejects(b.verifySelection({mode:'High'},controller.signal),e=>e.name==='AbortError');
 b.call=async()=>({ready:false,error:'网站连接失败'});await assert.rejects(b.ensure(),/网站连接失败/);
 b.call=async()=>({ready:false,challenge:true});await assert.rejects(b.ensure(),/Cloudflare/);
});

test('changing a mode refreshes the checked version before committing to the assistant',async()=>{
 const b=browser();b.ensure=async()=>({ready:true});b.snapshot={mode:'Medium',version:'Latest'};b.dismiss=async()=>{};b.call=async()=>({slider:{value:4},mode:'6 Pro',version:'Pro'});b.setSlider=b.call;b.discoverVersions=async()=>{b.snapshot.version='GPT-5.6 Sol';};await b.select('mode',{label:'6 Pro',value:4});assert.equal(b.ai.confirmed.mode,'6 Pro');assert.equal(b.ai.confirmed.version,'GPT-5.6 Sol');
});
test('web transport ignores old responses, streams the new reply, and waits for verified completion',async()=>{
 const b=browser(),base={url:'https://chatgpt.com/c/test',userCount:1,answerCount:1,draft:'',ready:true};b.conversation=async()=>base;b.verifySelection=async()=>{};b.wait=async()=>{};let sent=false,polls=0;const text=[],bindings=[];
 b.call=async action=>{if(action==='send'){sent=true;return {submitted:true};}if(!sent)return base;polls++;return {...base,userCount:2,answerCount:2,lastUser:'Question',answerHTML:polls===1?'<p>Par</p>':'<p>Complete</p>',busy:polls<3,complete:polls>=3};};
 const out=await b.request({id:'t',text:'Question',files:[],expected:{},onProgress(){},onText:t=>text.push(t),onBinding:t=>bindings.push(t)});assert.equal(out.text,'Complete');assert.deepEqual(text,['Par','Complete']);assert.ok(polls>=4);assert.ok(bindings.every(b=>b.submitted));
});
test('uncertain send is surfaced as submitted and never automatically retried',async()=>{
 const b=browser(),base={url:'https://chatgpt.com/c/test',userCount:0,answerCount:0,draft:''};b.conversation=async()=>base;b.verifySelection=async()=>{};b.wait=async()=>{};let sends=0;b.call=async action=>{if(action==='send'){sends++;throw Error('ack lost');}return base;};
 await assert.rejects(b.request({id:'t',text:'Q',files:[],expected:{},onProgress(){},onText(){},onBinding(){}}),e=>e.webSubmitted===true&&/ack lost/.test(e.message));assert.equal(sends,1);
});
test('abort after submission actually requests website stop',async()=>{
 const b=browser(),controller=new AbortController(),base={url:'https://chatgpt.com/c/test',userCount:0,answerCount:0,draft:''};b.conversation=async()=>base;b.verifySelection=async()=>{};let stops=0;
 b.call=async action=>{if(action==='send')controller.abort();if(action==='stop')stops++;return {...base,busy:false};};
 await assert.rejects(b.request({id:'t',text:'Q',files:[],expected:{},signal:controller.signal,onProgress(){},onText(){},onBinding(){}}),e=>e.name==='AbortError');assert.equal(stops,1);
});
test('request cannot navigate away from another website draft or import another conversation reply',async()=>{
 const b=browser();b.ensure=async()=>({busy:false,draft:'unsent',url:'https://chatgpt.com/c/other',userCount:1});await assert.rejects(b.conversation('https://chatgpt.com/c/test'),/未发送草稿/);
 const base={url:'https://chatgpt.com/c/test',userCount:0,answerCount:0,draft:''};b.conversation=async()=>base;b.verifySelection=async()=>{};b.wait=async()=>{};let sent=false;b.call=async action=>{if(action==='send')sent=true;return sent?{...base,url:'https://chatgpt.com/c/other'}:base;};await assert.rejects(b.request({id:'t',text:'Q',files:[],conversation:base.url,expected:{},onProgress(){},onText(){},onBinding(){}}),/其他对话/);
});

test('a new chat binds to its first conversation URL and refuses later navigation',async()=>{
 const b=browser(),base={url:'https://chatgpt.com/',userCount:0,answerCount:0,draft:''};b.conversation=async()=>base;b.verifySelection=async()=>{};b.wait=async()=>{};let sent=false,polls=0;b.call=async action=>{if(action==='send')sent=true;if(!sent)return base;polls++;return {...base,url:'https://chatgpt.com/c/'+(polls<3?'first':'other'),userCount:1,lastUser:'Question',answerCount:1,answerHTML:'<p>Partial</p>',busy:true};};await assert.rejects(b.request({id:'new',text:'Question',files:[],expected:{},onProgress(){},onText(){},onBinding(){}}),/其他对话/);
});

test('a local provisional conversation URL may become permanent after matching the submitted message',async()=>{
 const b=browser(),base={url:'https://chatgpt.com/',userCount:0,answerCount:0,draft:''};b.conversation=async()=>base;b.verifySelection=async()=>{};b.wait=async()=>{};let sent=false,polls=0;const bindings=[];
 b.call=async action=>{if(action==='send')sent=true;if(!sent)return base;polls++;return {...base,url:polls===1?'https://chatgpt.com/c/local-chatgpt%3Afixture':'https://chatgpt.com/c/permanent',userCount:1,lastUser:'Question',answerCount:1,answerHTML:'<p>Answer</p>',complete:polls>1,busy:polls===1};};
 const result=await b.request({id:'temporary',text:'Question',files:[],expected:{},onProgress(){},onText(){},onBinding:x=>bindings.push(x)});
 assert.equal(result.url,'https://chatgpt.com/c/permanent');assert.equal(bindings.some(x=>x.url.includes('local-chatgpt')),false);assert.equal(bindings.at(-1).url,result.url);
});
test('answer conversion preserves math, links, tables and fenced code without executing remote HTML',()=>{
 const w=dom(''),bundle=require('esbuild').buildSync({entryPoints:[path.join(__dirname,'ai-web-chat-format.js')],bundle:true,format:'iife',globalName:'Format',platform:'browser',write:false}).outputFiles[0].text;w.eval(bundle+';window.convert=Format.markdown');
 const out=w.convert('<h2>Result</h2><p><a href="https://example.com/a">Source</a> <span class="katex"><math><semantics><annotation encoding="application/x-tex">x^2</annotation></semantics></math></span></p><table><thead><tr><th>A</th><th>B</th></tr></thead><tbody><tr><td>1</td><td>2</td></tr></tbody></table><pre><code class="language-js">const x = 1;</code></pre><script>window.evil=true</script><a href="javascript:alert(1)">bad</a>');
 assert.match(out,/## Result/);assert.match(out,/\[Source\]\(https:\/\/example.com\/a\)/);assert.match(out,/\$x\^2\$/);assert.match(out,/\| A \| B \|/);assert.match(out,/```js\nconst x = 1;/);assert.doesNotMatch(out,/javascript:|window.evil/);assert.equal(w.evil,undefined);w.close();
});
test('website source input captures unsaved current document and explicit skill instructions only',async()=>{
 const box={reqnode:require,window:{addEventListener(){}},EditingToolbarAIWebProjects:class{target(){return null;} bind(){}},EditingToolbarAIWebTranslation:class{bind(){} decorate(){}},EditingToolbarWebChatBrowser:class{},AbortController};vm.createContext(box);vm.runInContext(fs.readFileSync(path.join(__dirname,'ai-web-chat.js'),'utf8')+';globalThis.Web=EditingToolbarAIWebChat',box);
 const ai={scope:{value:'document'},source:()=> '# Unsaved\n\nActual current text.',file:()=> 'C:\\papers\\source.md',promptsManager:{reference:()=>({text:'OLD DISK CONTENT'})},composerUI:{draft:{quotes:{reference:()=>''},media:{snapshot:()=>[]}}},attachments:{selected:[]},skillsUI:{init:async()=>{},store:{load:async()=>({body:'Preserve equations.'})}}};const web=new box.Web(ai),out=await web.input({question:'Explain',skills:{selected:['paper']}},new AbortController().signal);assert.equal(Buffer.from(out.files[0].base64,'base64').toString(),'# Unsaved\n\nActual current text.');assert.match(out.text,/Preserve equations/);assert.doesNotMatch(out.text,/OLD DISK CONTENT/);
});

test('answer conversion keeps LaTeX backslashes, subscripts and display delimiters byte-for-byte',()=>{
 const w=dom(''),bundle=require('esbuild').buildSync({entryPoints:[path.join(__dirname,'ai-web-chat-format.js')],bundle:true,format:'iife',globalName:'Format',platform:'browser',write:false}).outputFiles[0].text;w.eval(bundle+';window.convert=Format.markdown');const tex=String.raw`\\frac{x_{i}}{y^{*}} + \\alpha_1`;
 const out=w.convert('<p>Inline <span class="katex"><annotation encoding="application/x-tex">'+tex+'</annotation></span>.</p><span class="katex-display"><span class="katex"><annotation encoding="application/x-tex">'+tex+'</annotation></span></span>');assert.ok(out.includes('$'+tex+'$'));assert.ok(out.includes('$$\n'+tex+'\n$$'));w.close();
});


test('existing project chat reply stays bound through canonical project-title URL changes',async()=>{
 const b=browser(),saved='https://chatgpt.com/g/g-p-test/c/existing',base={url:'https://chatgpt.com/c/existing',userCount:2,answerCount:2,draft:''},actual='https://chatgpt.com/g/g-p-test-title/c/existing';
 b.projectRoute=async()=>base;b.verifySelection=async()=>{};b.wait=async()=>{};let sent=false,sends=0;const bindings=[];
 b.call=async action=>{if(action==='send'){sent=true;sends++;}return sent?{...base,url:actual,userCount:3,lastUser:'Question',answerCount:3,answerHTML:'<p>Complete</p>',complete:true,busy:false}:base;};
 const out=await b.request({id:'alias',text:'Question',files:[],projectTarget:{enabled:true,project:{url:'https://chatgpt.com/g/g-p-test/project'},chat:{url:saved}},expected:{},onProgress(){},onText(){},onBinding:x=>bindings.push(x)});assert.equal(out.text,'Complete');assert.equal(out.url,actual);assert.equal(sends,1);assert.equal(bindings.at(-1).url,actual);
});


test('saved chat history hydrates after model verification then accepts two new turns without old-answer capture',async()=>{
 const w=dom('<main><div id="history"></div><form><textarea id="prompt-textarea">Old draft</textarea><button data-composer-submit>Send</button></form></main>'),b=browser(false);let reads=0,sends=0;
 b.wait=async()=>{};b.projectRoute=async()=>w.bridge('snapshot');b.verifySelection=async()=>{w.history.replaceState({},'','/g/g-p-test-title/c/test?view=chat');};
 b.call=async(action,args)=>{if(action==='snapshot'&&++reads===3)w.document.querySelector('#history').innerHTML='<div data-message-role="user" data-message-id="old-user">Old question</div><div data-message-role="assistant" data-message-id="old-answer"><p>Old answer</p><button>Copy</button></div>';return w.bridge(action,args);};
 w.document.querySelector('[data-composer-submit]').onclick=()=>{const e=w.document.querySelector('textarea'),history=w.document.querySelector('#history');sends++;history.insertAdjacentHTML('beforeend','<div data-message-role="user" data-message-id="new-user-'+sends+'">'+e.value+'</div><div data-message-role="assistant" data-message-id="new-answer-'+sends+'"><p>New answer '+sends+'</p><button>Copy</button></div>');e.value='';};
 for(let n=1;n<=2;n++){const answers=[],bindings=[];const out=await b.request({id:'append-'+n,text:'New question '+n,files:[],projectTarget:{enabled:true},expected:{},onProgress(){},onText:t=>answers.push(t),onBinding:x=>bindings.push(x)});assert.equal(out.text,'New answer '+n);assert.ok(answers.every(x=>!x.includes('Old answer')));assert.equal(bindings.at(-1).userCount,n+1);assert.equal(bindings.at(-1).answerCount,n);}
 assert.equal(sends,2);assert.equal(w.document.querySelector('[data-message-id="old-user"]').textContent,'Old question');assert.equal((await w.bridge('snapshot')).userCount,3);w.close();
});

test('history loader and empty saved chat do not become a false send baseline',async()=>{
 const b=browser(false),base={url:'https://chatgpt.com/c/saved',ready:true,userCount:0,answerCount:0};b.wait=async()=>{};let reads=0;
 b.call=async()=>{reads++;return {...base,userCount:reads<4?0:1,answerCount:1,historyLoading:reads<7,lastUser:'Old',answerHTML:'Old'};};const s=await b.settleConversation(base);assert.equal(s.userCount,1);assert.equal(reads,9);
 b.call=async()=>base;await assert.rejects(b.settleConversation(base),/尚未加载完成/);
});

test('real conversation changes before cleanup or after prepare never send or clear a different chat',async()=>{
 for(const phase of ['hydration','prepare']){const w=dom('<main><div data-message-role="user" data-message-id="old">Old question</div><form><textarea id="prompt-textarea">Keep draft</textarea><button data-composer-submit>Send</button></form></main>'),b=browser(false);let sends=0,clears=0;b.wait=async()=>{};b.conversation=async()=>w.bridge('snapshot');b.verifySelection=async()=>{if(phase==='hydration')w.history.replaceState({},'','/c/different');};
 b.call=async(action,args)=>{if(action==='clear-composer')clears++;const s=await w.bridge(action,args);if(action==='prepare')w.history.replaceState({},'','/c/different');return s;};w.document.querySelector('button').onclick=()=>sends++;
 await assert.rejects(b.request({id:'wrong-'+phase,text:'Q',files:[],expected:{},onProgress(){},onText(){},onBinding(){assert.fail('no submission');}}),e=>e.webSubmitted===false&&/切换对话/.test(e.message));assert.equal(sends,0);assert.equal(clears,phase==='hydration'?0:1);if(phase==='hydration')assert.equal(w.document.querySelector('textarea').value,'Keep draft');w.close();}
});

test('guest mutation guard allows canonical same-ID URLs and rejects other chats at each mutation',async()=>{
 const w=dom('<form><textarea id="prompt-textarea">Q</textarea><button data-composer-submit>Send</button></form><div data-message-role="user" data-message-id="old">Old</div>'),guard={url:'https://chatgpt.com/g/g-p-title/c/test/',userCount:1,lastUserId:'old'};let sends=0;w.document.querySelector('button').onclick=()=>sends++;
 await w.bridge('clear-composer',guard);assert.equal(w.document.querySelector('textarea').value,'');await w.bridge('prepare',{...guard,text:'Q'});
 w.history.replaceState({},'','/c/other');for(const action of ['clear-composer','prepare','upload-ready','upload','send'])await assert.rejects(w.bridge(action,{...guard,id:'t',text:'Q',files:[]}),/会话发生变化/);assert.equal(sends,0);assert.equal(w.document.querySelector('textarea').value,'Q');
 w.history.replaceState({},'','/g/g-p-renamed/c/test');await w.bridge('send',{...guard,id:'t',text:'Q'});await w.bridge('send',{...guard,id:'t',text:'Q'});assert.equal(sends,1);w.close();
});


test('collapsed long user message expands locally and excludes show-more/copy controls from matching',async()=>{
 const full='Translate full paper. '+('A paragraph. '.repeat(100))+'taskId:unique-end',w=dom('<main><div data-message-role="user" data-message-id="u-long"><div data-user-message-bubble><p></p><button>显示更多</button><button>复制</button></div></div><form><textarea id="prompt-textarea"></textarea></form></main>');let expanded=0;
 const bubble=w.document.querySelector('[data-user-message-bubble]');bubble.querySelector('p').textContent=full.slice(0,90)+'...';bubble.querySelector('button').onclick=e=>{expanded++;bubble.querySelector('p').textContent=full;e.target.remove();};
 const s=await w.bridge('snapshot',{expectedText:full});assert.equal(s.lastUser,full);assert.equal(s.lastUserId,'u-long');assert.equal(s.lastUserCollapsed,false);assert.equal(expanded,1);await w.bridge('snapshot',{expectedText:full});assert.equal(expanded,1);w.close();
});

test('bound user identity survives a collapsed display while only its new reply streams',async()=>{
 const b=browser(),full='Long task '+('body '.repeat(60))+'END',base={url:'https://chatgpt.com/c/test',userCount:1,answerCount:1};let polls=0;const text=[],activity=[],bindings=[];b.wait=async()=>{};
 b.call=async(action,args)=>{assert.equal(action,'snapshot');polls++;return {...base,userCount:2,lastUserId:'u-new',lastUser:polls===1?full:full.slice(0,30)+'...',lastUserCollapsed:polls>1,answerCount:polls>1?2:1,replyAfterUser:polls>1,answerHTML:polls>1?'<p>New streamed answer</p>':'Old answer',answerId:'a-new',activity:[{id:'step',text:'正在核对文档'}],busy:polls<3,complete:polls>=3};};
 const result=await b.receive({text:full,base,onText:t=>text.push(t),onActivity:rows=>activity.push(rows),onBinding:x=>bindings.push(x),onProgress(){}});assert.equal(result.text,'New streamed answer');assert.deepEqual(text,['New streamed answer']);assert.ok(activity.length>0);assert.equal(bindings.at(-1).userId,'u-new');
});

test('same prefix and tail do not authorize another user message, even with a new answer present',async()=>{
 const b=browser(),tail='END '.repeat(50),expected='same start ORIGINAL MIDDLE '+tail,other='same start DIFFERENT MIDDLE '+tail,base={url:'https://chatgpt.com/c/test',userCount:1,answerCount:1};b.wait=async()=>{};let rendered=0;b.call=async()=>({...base,userCount:2,lastUser:other,lastUserId:'wrong',answerCount:2,replyAfterUser:true,answerHTML:'Wrong answer',complete:true});
 await assert.rejects(b.receive({text:expected,base,onText(){rendered++;},onBinding(){assert.fail('must not bind');},onProgress(){}}),/不一致/);assert.equal(rendered,0);
});

test('resume reads a legacy submitted turn, binds its full message and imports reply without sending',async()=>{
 const w=dom('<main><div data-message-role="user">Old task</div><div data-message-role="assistant"><p>Old answer</p></div><div data-message-role="user" data-message-id="current"><div data-user-message-bubble>Saved task<button>复制</button></div></div><div data-message-role="assistant" data-message-id="reply"><div class="markdown"><p>Recovered reply</p><a href="https://example.com/file.zip">Download</a></div><button>复制</button></div><textarea id="prompt-textarea">Preserve draft</textarea></main>'),b=browser();const calls=[],bindings=[];b.wait=async()=>{};b.conversation=async(_url,_signal,options)=>{assert.equal(options.observe,true);return w.bridge('snapshot');};b.call=async(action,args)=>{calls.push(action);assert.equal(action,'snapshot');return w.bridge(action,args);};
 const result=await b.resumeReply({submitted:true,url:'https://chatgpt.com/c/test',userCount:1,answerCount:1,input:{text:'Saved task'}},{onProgress(){},onText(){},onBinding:x=>bindings.push(x)});assert.match(result.text,/Recovered reply/);assert.doesNotMatch(result.text,/Old answer/);assert.equal(bindings.at(-1).userId,'current');assert.equal(w.document.querySelector('textarea').value,'Preserve draft');assert.ok(calls.every(x=>x==='snapshot'));w.close();
});

test('resume rejects a different message identity even if its text is identical',async()=>{
 const b=browser();b.wait=async()=>{};b.conversation=async()=>({});b.call=async()=>({url:'https://chatgpt.com/c/test',userCount:2,lastUser:'Saved task',lastUserId:'wrong',answerCount:2,replyAfterUser:true,answerHTML:'Wrong answer',complete:true});
 await assert.rejects(b.resumeReply({submitted:true,url:'https://chatgpt.com/c/test',userCount:1,answerCount:0,userId:'bound',input:{text:'Saved task'}},{onProgress(){},onText(){assert.fail('wrong reply');},onBinding(){assert.fail('wrong binding');}}),/不一致/);
});

test('disconnect preserves current public progress and partial reply while old errors are ignored',async()=>{
 const w=dom('<main><div data-message-role="user">Old</div><div role="alert">Old error failed</div><div data-message-role="user" data-message-id="current">Q</div><div data-agent-activity><p class="markdown">正在核对 ZIP</p></div><div data-message-role="assistant"><p>Partial reply</p></div><div data-conversation-recovery>连接已中断，正在等待完整答复</div></main>'),b=browser(),texts=[],steps=[];b.wait=async()=>{};b.call=async(action,args)=>w.bridge(action,args);
 const s=await w.bridge('snapshot');assert.equal(s.error,'');assert.equal(s.disconnected,true);
 await assert.rejects(b.receive({text:'Q',base:{url:'https://chatgpt.com/c/test',userCount:1,answerCount:0},onProgress(){},onBinding(){},onText:t=>texts.push(t),onActivity:rows=>steps.push(...rows)}),/连接已中断/);assert.deepEqual(texts,['Partial reply']);assert.ok(steps.some(x=>x.text==='正在核对 ZIP'));w.close();
});


test('an acknowledged message can receive its server ID while the long bubble collapses',async()=>{
 const full='Full task '+('body '.repeat(80))+'unique-end',w=dom('<div data-message-role="user" data-message-id="temporary"><div data-user-message-bubble></div></div><div data-message-role="assistant"><div class="markdown">New answer</div><button>Copy</button></div>'),b=browser();let polls=0,expands=0;const bindings=[];w.document.querySelector('[data-user-message-bubble]').textContent=full;b.wait=async()=>{};
 b.call=async(action,args)=>{assert.equal(action,'snapshot');polls++;if(polls===2){const user=w.document.querySelector('[data-message-role="user"]'),bubble=user.querySelector('[data-user-message-bubble]');user.dataset.messageId='permanent';bubble.innerHTML='<p>Full task body...</p><button>显示更多</button>';bubble.querySelector('button').onclick=e=>{expands++;bubble.querySelector('p').textContent=full;e.target.remove();};}return w.bridge(action,args);};
 const result=await b.receive({text:full,base:{url:'https://chatgpt.com/c/test',userCount:0,answerCount:0},onProgress(){},onText(){},onBinding:x=>bindings.push(x)});assert.equal(result.text,'New answer');assert.equal(expands,1);assert.equal(bindings.at(-1).userId,'permanent');w.close();
});


test('Show more adjacent to the user content expands that turn and never an older message',async()=>{
 const w=dom('<main><div><div data-message-role="user">Older</div><button id="old">显示更多</button></div><div><div data-content-search-unit-key="bound:user">Truncated...</div><button id="current">显示更多内容</button></div></main>');let current=0,old=0;w.document.getElementById('old').onclick=()=>old++;w.document.getElementById('current').onclick=e=>{current++;w.document.querySelector('[data-content-search-unit-key]').textContent='Complete long input';e.target.remove();};const s=await w.bridge('snapshot',{expectedText:'Complete long input'});assert.equal(s.lastUser,'Complete long input');assert.equal(s.lastUserId,'bound:user');assert.equal(current,1);assert.equal(old,0);w.close();
});


test('numeric website version titles remain selectable without inventing a Latest alias',async()=>{
 const w=dom('<div role="menu"><div role="menuitemradio" aria-checked="true"><div data-menu-row-content="true"><span>6</span></div></div><div role="menuitemradio">6.1 Sol</div><div role="menuitemradio">GPT-5.6 Sol</div></div>');
 const s=await w.bridge('open-version');assert.equal(s.version,'6');assert.deepEqual(Array.from(s.options,o=>o.label),['6','6.1 Sol','GPT-5.6 Sol']);let clicked=false;w.document.querySelector('[aria-checked]').onclick=()=>clicked=true;await w.bridge('choose-option',{label:'6'});assert.equal(clicked,true);w.close();
});

test('shared activity and answer containers preserve final text, multiple blocks and final actions',async()=>{
 const w=dom('<div data-content-search-unit-key="turn:0:user">Question</div><div><span data-chatgpt-agent-turn-start hidden></span><section data-testid="reasoning"><p>Public progress</p></section><div data-chatgpt-search-unit-key="turn:2:assistant"><div data-chatgpt-selection-message-id="a"><div data-markdown-text-style="assistant-message"><p>Final paragraph</p><span hidden>Secret</span><div style="display:none">Hidden</div></div><div data-markdown-text-style="assistant-message"><table><tr><td>Second block</td></tr></table></div></div></div><button aria-label="复制消息">复制消息</button></div><textarea id="prompt-textarea"></textarea>');
 const s=await w.bridge('snapshot',{progress:true});assert.equal(s.answerCount,1);assert.equal(s.complete,true);assert.equal(s.replyAfterUser,true);assert.equal(s.answerId,'a');assert.match(s.answerHTML,/Final paragraph/);assert.match(s.answerHTML,/Second block/);assert.doesNotMatch(s.answerHTML,/Public progress|Secret|Hidden/);assert.deepEqual(Array.from(s.activity,r=>r.text),['Public progress']);w.close();
});

test('public selection wrappers and zero-size content containers still identify one bound answer',async()=>{
 const w=dom('<div data-user-message-bubble>Question</div><div data-chatgpt-selection-message-id="a"><div data-markdown-text-style="assistant-message"><p>Done</p></div></div><button data-testid="copy-turn-action-button"></button><textarea id="prompt-textarea"></textarea>');
 const s=await w.bridge('snapshot');assert.equal(s.answerId,'a');assert.equal(s.answerCount,1);assert.equal(s.replyAfterUser,true);assert.match(s.answerHTML,/Done/);
 const wrapper=w.document.querySelector('[data-chatgpt-selection-message-id]');wrapper.setAttribute('data-message-role','assistant');wrapper.getBoundingClientRect=()=>({height:0,width:0});assert.equal((await w.bridge('snapshot')).answerCount,1);wrapper.style.display='none';assert.equal((await w.bridge('snapshot')).answerCount,0);w.close();
});

test('code copy and earlier user or answer actions never finish a current unfinished answer',async()=>{
 const w=dom('<div data-message-role="assistant"><div class="markdown">Old</div><button>Copy message</button></div><div data-message-role="user">Question<button>Copy message</button></div><div data-message-role="assistant"><div class="markdown"><p>Partial</p><pre><button>Copy</button><code>x</code></pre></div></div><textarea id="prompt-textarea"></textarea>');
 const s=await w.bridge('snapshot');assert.equal(s.complete,false);assert.match(s.answerHTML,/Partial/);assert.doesNotMatch(s.answerHTML,/Old|Copy/);w.close();
});

test('website catalog refresh accepts 6 and omits retired menu entries, and refresh failures are visible',async()=>{
 const b=browser();b.dismiss=async()=>{};b.snapshot={mode:'High',version:'GPT-5.6 Sol'};b.call=async()=>({options:[{label:'6',selected:true},{label:'GPT-5.6 Sol'},{label:'GPT-5.5'}]});await b.discoverVersions();assert.equal(b.snapshot.version,'6');assert.deepEqual(Array.from(b.capabilities.versions,r=>r.label),['6','GPT-5.6 Sol']);
 b.status='已连接';b.capabilities.modes=[{label:'High'}];b.versionsReadAt=Date.now()-61000;let refreshes=0;b.refresh=async()=>{refreshes++;};await b.options();assert.equal(refreshes,1);
 const bad=browser();bad.ensure=async()=>({ready:true});bad.discoverModes=async()=>{};bad.discoverVersions=async()=>{throw Error('Version menu unavailable');};await assert.rejects(bad.refresh(),/Version menu unavailable/);assert.notEqual(bad.status,'已连接');
});
test('hidden guest keyboard stepping targets the public slider control',async()=>{
 const w=sharedModelMenu(),d=w.document;await w.bridge('open-mode');const control=d.querySelector('[data-reasoning-slider]');control.addEventListener('keydown',e=>{if(e.key==='ArrowLeft'){d.querySelector('[role=slider]').setAttribute('aria-valuenow','3');d.querySelector('#announcement').textContent='6 Extra High，第4项';}});const s=await w.bridge('slider-step',{key:'ArrowLeft'});assert.equal(s.slider.value,3);assert.equal(s.mode,'Extra High');await assert.rejects(w.bridge('slider-step',{key:'Enter'}),/不可用/);w.close();
});
test('ready idle page automatically refreshes capabilities after login without opening the panel',async()=>{
 const b=browser();b.ready=true;let options=0;b.call=async()=>({ready:true,mode:'High',busy:false});b.options=async()=>{options++;};b.inspectReadiness();await new Promise(r=>setImmediate(r));assert.equal(options,1);b.destroy();
});
