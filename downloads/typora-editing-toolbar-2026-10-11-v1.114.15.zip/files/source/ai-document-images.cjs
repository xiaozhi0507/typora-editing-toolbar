'use strict';
const MarkdownIt = require('markdown-it');
// Parse references only. Files are described separately; never fetch remote URLs.
class ETAIDocumentImages {
  static limit=200;
  constructor(requireNode=require) {
    this.path=requireNode('path');this.url=requireNode('url');
    this.parser=new MarkdownIt('commonmark',{html:true});
    // Discovery does not render links. Resolve/validate each reference below,
    // including file: URLs that MarkdownIt's renderer normally rejects.
    this.parser.validateLink=()=>true;
  }
  references(markdown,htmlImages=()=>[]) {
    const source=String(markdown);if(source.length>4*1024*1024)throw Error('文档过大，请拆分章节后扫描图片');
    // Metadata and code examples are not document images; retain line positions.
    const text=source.replace(/^\uFEFF?---[^\S\n]*\r?\n[\s\S]*?\r?\n(?:---|\.\.\.)[^\S\n]*(?:\r?\n|$)/,m=>m.replace(/[^\n]/g,' '));
    const out=[];
    const walk=(tokens,line=1)=>{for(const t of tokens){const at=t.map?t.map[0]+1:line;
      if(t.type==='image')out.push({src:t.attrGet('src')||'',label:t.content||t.attrGet('title')||'',line:at});
      else if(t.type==='html_inline'||t.type==='html_block')for(const image of htmlImages(t.content))out.push({...image,line:at});
      if(t.children&&t.type!=='image')walk(t.children,at);
    }};
    walk(this.parser.parse(text,{}));return out.filter(r=>r.src.trim());
  }
  root(markdown,fallback='') {
    const meta=String(markdown).match(/^\uFEFF?---[^\S\n]*\r?\n([\s\S]*?)\r?\n(?:---|\.\.\.)[^\S\n]*(?:\r?\n|$)/)?.[1];
    const value=meta?.match(/^\s*typora-root-url\s*:\s*(.*?)\s*$/m)?.[1];
    return String(value??fallback).trim().replace(/^(['"])(.*)\1$/,'$2');
  }
  resolve(ref,file,root='') {
    const raw=ref.src.trim();let name=ref.label||raw.split(/[\\/]/).at(-1)||'图片';
    const unavailable=reason=>({...ref,name,error:reason,id:'ref:'+raw});
    if(/^https?:/i.test(raw)||/^\/\//.test(raw))return unavailable('网络图片 · 请先保存到本机');
    if(/^data:/i.test(raw))return unavailable('内嵌图片 · 请先另存为图片文件');
    if(/^[a-z][\w+.-]*:/i.test(raw)&&!/^file:/i.test(raw)&&!/^\w:[\\/]/.test(raw))return unavailable('不支持的图片地址');
    try{
      let local;
      if(/^file:/i.test(raw))local=this.url.fileURLToPath(new URL(raw));
      else{
        const decoded=decodeURIComponent(raw.replace(/[?#].*$/,''));
        if(!decoded||decoded.includes('\0'))return unavailable('图片路径无效');
        if(/^\\\\/.test(decoded))return unavailable('网络路径 · 暂不读取');
        if(this.path.isAbsolute(decoded)&&(!root||/^\w:[\\/]/.test(decoded)))local=decoded;
        else{
          if(!file||file.startsWith('untitled:'))return unavailable('请先保存 Markdown，以解析相对路径');
          if(/^[a-z][\w+.-]*:/i.test(root)&&!/^\w:[\\/]/.test(root)&&!/^file:/i.test(root))return unavailable('网络图片根目录 · 请先保存到本机');
          const base=root?(/^file:/i.test(root)?this.url.fileURLToPath(new URL(root)):this.path.resolve(this.path.dirname(file),root)):this.path.dirname(file);
          local=this.path.resolve(base,root?decoded.replace(/^[\\/]+/,''):decoded);
        }
      }
      local=this.path.normalize(local);if(/^\\\\/.test(local))return unavailable('网络路径 · 暂不读取');
      name=this.path.basename(local);
      if(!/\.(png|jpe?g|webp)$/i.test(name))return {...unavailable('暂不支持此格式'),name};
      return {...ref,path:local,name,id:local.toLowerCase()};
    }catch{return unavailable('图片路径无效');}
  }
  async scan(markdown,file,fallback,htmlImages,describe,current=()=>true) {
    const refs=this.references(markdown,htmlImages),root=this.root(markdown,fallback),unique=new Map();
    for(const ref of refs){const entry=this.resolve(ref,file,root),old=unique.get(entry.id);if(old)old.occurrences++;else unique.set(entry.id,{...entry,occurrences:1});}
    const rows=[...unique.values()].slice(0,ETAIDocumentImages.limit),result=[],seen=new Map();
    // Small sequential metadata reads remain cancellable, including file switches.
    for(const row of rows){if(!current())return null;let item=row;
      if(!row.error)try{item={...row,...await describe(row.path,'当前文档')};}catch(e){item={...row,error:e.code==='ENOENT'?'图片文件不存在':e.code==='EACCES'?'无权读取图片':e.message};}
      const old=seen.get(item.id);if(old)old.occurrences+=item.occurrences;else{seen.set(item.id,item);result.push(item);}
    }
    return current()?{items:result,references:refs.length,truncated:unique.size>rows.length}:null;
  }
}
module.exports=ETAIDocumentImages;
