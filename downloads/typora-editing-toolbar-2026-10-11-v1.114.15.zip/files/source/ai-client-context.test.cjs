const {test}=require('node:test'),assert=require('node:assert/strict');
const Client=require('./ai-client.cjs');

test('each completed turn keeps its own quoted source immediately before its question',()=>{
  const initial={text:'初始文档',label:'全文'},first={text:'翻译所选段落',label:'选区'},current={text:'新的段落',label:'章节'};
  const turns=[{question:'翻译',answer:'译文',status:'done',requestContext:first},{question:'失败请求',answer:'半句',status:'error',requestContext:{text:'失败资料'}}];
  const messages=Client.messages({},initial,turns,'解释',current);
  assert.deepEqual(messages.map(m=>m.role),['system','user','user','user','assistant','user','user']);
  assert.ok(messages[1].content.includes(initial.text));assert.ok(messages[2].content.includes(first.text));assert.equal(messages[3].content,'翻译');
  assert.ok(messages[5].content.includes(current.text));assert.equal(messages[6].content,'解释');
  assert.ok(!JSON.stringify(messages).includes('失败资料'));assert.equal(initial.text,'初始文档');
});

test('per-turn images remain user material and sources retain the size guard',()=>{
  const data='data:image/png;base64,dGVzdA==',context={text:'',label:'无资料'},ref={text:'说明',label:'图片',images:[{data}]};
  const messages=Client.messages({},context,[],'阅读',ref),image=messages.find(m=>Array.isArray(m.content));
  assert.equal(image.role,'user');assert.equal(image.content[1].image_url.url,data);
  assert.throws(()=>Client.messages({},context,[],'阅读',{text:'x'.repeat(Client.referenceLimit+1)}),/2,097,153.*源码|源码.*2,097,153/);
});

test('16000 English words and Chinese text with markup are read completely above the old cutoff',()=>{
  for(const text of ['research '.repeat(16000)+'END_OF_PAPER',('<span style="font-family:serif">文</span>').repeat(16000)+'END_OF_PAPER']){
    const messages=Client.messages({},{text,label:'全文'},[],'解释');
    assert.ok(text.length>100000);assert.ok(messages[1].content.includes(text));assert.match(messages[1].content,/END_OF_PAPER/);
    for(const protocol of ['openai-chat','openai-responses','anthropic-messages'])assert.ok(JSON.stringify(Client.body({model:'fixture',protocol},messages)).includes('END_OF_PAPER'));
  }
});
test('request-size protection still bounds large history and preserves the editing budget',()=>{
  assert.throws(()=>Client.body({model:'fixture'},[{role:'user',content:'x'.repeat(Client.requestTextLimit)}]),/本次对话过长/);
  assert.throws(()=>Client.body({model:'fixture',documentEdit:true},[{role:'user',content:'x'.repeat(800001)}]),/本次对话过长/);
});
test('the initial source and identical staged/history references are not repeated, changed source remains',()=>{
  const ref={text:'UNIQUE_PAPER',label:'全文',images:[{data:'data:image/png;base64,YQ=='}]};
  const turns=[{status:'done',question:'第一问',answer:'回答',requestContext:{...ref}}];
  const m=Client.messages({},ref,turns,'第二问',{...ref});
  assert.equal(JSON.stringify(m).split('UNIQUE_PAPER').length-1,1);
  assert.equal(JSON.stringify(m).split('data:image/png;base64,YQ==').length-1,1);
  assert.equal(m.filter(x=>x.content==='第一问').length,1);
  const changed=Client.messages({},ref,turns,'第二问',{...ref,text:'UPDATED_PAPER'});
  assert.ok(JSON.stringify(changed).includes('UPDATED_PAPER'));
});
