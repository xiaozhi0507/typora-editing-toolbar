const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{JSDOM}=require('jsdom'),adapter=require('./ai-web-project-page.cjs');
const project='https://chatgpt.com/g/g-p-test-research/project',chat='https://chatgpt.com/g/g-p-test-research/c/chat-one';
test('fresh scoped chat cache avoids navigation, force refresh works, requests coalesce',async()=>{
 const {w,p,b}=projectMenu(),target=p.projects[0];b.ensure=async()=>({});b.scope=async()=> 'user/workspace';let reads=0,release,started;const began=new Promise(r=>started=r);b.projectChats=async()=>{reads++;started();return new Promise(r=>release=r);};
 const first=p.showChats(target);await began;const second=p.showChats(target);release([{url:chat,name:'Only title'}]);await Promise.all([first,second]);assert.equal(reads,1);assert.equal(p.menu.getAttribute('aria-busy'),'false');await p.showChats(target);assert.equal(reads,1);
 b.projectChats=async()=>{reads++;return [];};await p.showChats(target,{force:true});assert.equal(reads,2);assert.equal(p.chats.get(project).length,0);w.close();
});
test('delayed list from old account cannot populate the next account cache',async()=>{
 const {w,p,b}=projectMenu(),target=p.projects[0];b.ensure=async()=>({});let scope='A',release,started;const began=new Promise(r=>started=r);b.scope=async()=>scope;b.projectChats=async()=>{started();return new Promise(r=>release=r);};const reading=p.showChats(target);await began;scope='B';await p.checkScope();release([{url:chat,name:'Private A'}]);await reading;assert.equal(p.chats.size,0);assert.equal(p.projects.length,0);assert.equal(p.menu.textContent.includes('Private A'),false);w.close();
});
test('fresh project menu skips forced reads and concurrent refreshes share one operation',async()=>{
 const {w,p,b,a}=projectMenu();a.composerUI.openMenu=()=>{};b.ensure=async()=>({});b.scope=async()=> 'A';let reads=0;b.projectCall=async()=>{reads++;return {projects:[{url:project,name:'P'}]};};await Promise.all([p.refresh(),p.refresh()]);assert.equal(reads,1);await p.open();assert.equal(reads,1);await p.refresh();assert.equal(reads,2);assert.equal(p.projects.length,1);w.close();
});
test('same verified project chat avoids navigation only within current principal and TTL',async()=>{
 const b=browser(),target={enabled:true,project:{url:project},chat:{url:chat}},routes=[];let scope='A',reads=0;b.scope=async()=>scope;b.ensure=async()=>({url:chat,ready:true,userCount:3});b.navigateTarget=async url=>{routes.push(url);return {url};};b.projectChats=async()=>{reads++;return [{url:chat}];};await b.projectRoute(target);await b.projectRoute(target);assert.equal(reads,1);assert.equal(routes.length,1);scope='B';await b.projectRoute(target);assert.equal(reads,2);b.memberships.forEach(p=>p.at=Date.now()-46000);await b.projectRoute(target);assert.equal(reads,3);scope='';await b.projectRoute(target);await b.projectRoute(target);assert.equal(reads,5);
});
test('identity responses arriving out of order cannot restore an old principal',async()=>{
 const b=browser();let a,hint='A',started;const began=new Promise(r=>started=r);b.events=async action=>action==='scope-hint'?hint:new Promise(r=>{a=r;started();});const first=b.scope();await began;hint='B';b.events=async action=>action==='scope-hint'?hint:{status:'verified',key:'B'};assert.equal(await b.scope(),'B');a({status:'verified',key:'A'});assert.equal(await first,'');assert.equal(b.principal,'B');
});
test('saved project identity changes reject both existing and new chats before navigation',async()=>{
 const b=browser();b.scope=async()=> 'B';b.navigateTarget=async()=>assert.fail('must not navigate');for(const selected of [null,{url:chat}])await assert.rejects(b.projectRoute({enabled:true,scope:'A',project:{url:project},chat:selected}),/重新选择项目/);
});
test('a different workspace does not rename or mark the saved project as selected',async()=>{
 const {w,p,b,a}=projectMenu();a.config.webChat={projectTarget:{enabled:true,scope:'A',project:{url:project,name:'Private A'},chat:{url:chat,name:'Saved A'}}};p.scopeKey='B';b.ensure=async()=>{};b.scope=async()=> 'B';b.projectCall=async()=>({projects:[{url:project,name:'Workspace B'}]});await p.refresh();p.sync();assert.equal(p.selection.project.name,'Private A');assert.equal(p.projectButton.textContent,'请选择项目');assert.equal(p.chatButton.textContent,'网页账号已切换');assert.equal(p.menu.querySelector('[aria-label="Workspace B"]').getAttribute('aria-pressed'),'false');assert.equal(p.menu.querySelector('.et-ai-project-badge'),null);w.close();
});
test('project chat cards return only the title without prompts dates or actions',async()=>{
 const w=dom('<main><a href="'+chat+'"><div><h3>翻译文献 ZIP交付</h3><p>请调用当前空间已上传的技能</p></div><time>今天</time><button>更多</button></a><a href="/c/two"><div class="truncate">Second title</div><div class="line-clamp-2">Preview text</div></a><a href="/c/three"><div><span>Third title</span></div><div>Prompt preview</div></a><a href="/c/four" aria-labelledby="four"><span id="four">Fourth title</span><span>Preview</span></a></main>');
 assert.deepEqual(Array.from((await w.adapter('chats',{project})).chats,r=>r.name),['翻译文献 ZIP交付','Second title','Third title','Fourth title']);w.close();
});
test('refresh repairs the saved chat title and chip without changing chat or draft',async()=>{
 const {w,p,a,b}=projectMenu();a.config.webChat={projectTarget:{enabled:true,project:p.projects[0],chat:{url:chat,name:'Title Preview prompt'}}};b.projectChats=async()=>[{url:chat,name:'Title'}];await p.showChats(p.projects[0]);assert.equal(p.chatButton.textContent,'Title');assert.equal(p.chatButton.title,'Title');assert.equal(p.selection.chat.url,chat);assert.equal(p.menu.querySelector('.et-ai-project-description'),null);assert.equal(w.document.querySelector('textarea').value,'保留草稿');w.close();
});
function dom(html,url=project){const w=new JSDOM(html,{url,runScripts:'outside-only'}).window;w.HTMLElement.prototype.getBoundingClientRect=function(){return {left:0,top:0,width:20,height:this.hidden?0:20};};w.setTimeout=f=>queueMicrotask(f);w.eval('window.adapter='+adapter.toString());return w;}
test('project list uses project links and excludes assistant content, foreign origins and normal chats',async()=>{const w=dom('<aside><a href="'+project+'">Research</a><a href="/c/other">Recent</a></aside><a href="https://evil.test/g/g-p-wrong/project">Wrong</a><article data-testid="conversation-turn-1"><a href="/g/g-p-injected/project">Fake</a></article>');const r=await w.adapter('projects');assert.deepEqual(JSON.parse(JSON.stringify(r.projects)),[{url:project,name:'Research'}]);w.close();});
test('skip-content anchors cannot steal the current project name or appear as conversations',async()=>{const w=dom('<a href="#main">跳转到内容</a><a href="">Empty</a><a href="?view=chat">Same page</a><a href="'+project+'#main">Skip</a><aside><a href="'+project+'">Typora</a></aside><main><button role="tab" aria-selected="true">聊天</button><a href="#composer">Jump</a><a href="'+chat+'">Paper</a></main>');assert.deepEqual(JSON.parse(JSON.stringify((await w.adapter('projects')).projects)),[{url:project,name:'Typora'}]);assert.deepEqual(JSON.parse(JSON.stringify((await w.adapter('chats',{project})).chats)),[{url:chat,name:'Paper'}]);w.close();});
test('project chat membership comes from main list, not unrelated sidebar or injected messages',async()=>{const w=dom('<aside><a href="/c/outside">Other chat</a></aside><main><button role="tab" aria-selected="true">聊天</button><a href="'+chat+'">Paper</a><div data-message-role="assistant"><a href="/c/fake">Fake</a></div></main>');assert.deepEqual(JSON.parse(JSON.stringify((await w.adapter('chats',{project})).chats)),[{url:chat,name:'Paper'}]);await assert.rejects(w.adapter('chats',{project:project.replace('test','other')}),/尚未进入/);w.close();});
test('create project fills public dialog and confirms observed identity instead of inventing URLs',async()=>{const w=dom('<button>新建项目</button>','https://chatgpt.com/');w.document.querySelector('button').onclick=()=>{const d=w.document.createElement('div');d.setAttribute('role','dialog');d.innerHTML='<h2>创建项目</h2><input><button>创建项目</button>';d.querySelector('button').onclick=()=>{assert.equal(d.querySelector('input').value,'Exact project');d.remove();w.history.pushState({},'',project);};w.document.body.append(d);};const r=await w.adapter('create-project',{name:'Exact project'});assert.equal(r.previousURL,'');assert.equal(w.document.querySelector('input').value,'Exact project');await w.adapter('submit-project',{name:'Exact project'});assert.equal(w.location.href,project);w.close();});
function browser(){const box={window:{addEventListener(){}},ETAIWebProjectPage:adapter,URL,setTimeout,clearTimeout};vm.createContext(box);vm.runInContext(fs.readFileSync(path.join(__dirname,'ai-web-chat-browser.js'),'utf8')+';globalThis.B=EditingToolbarWebChatBrowser;',box);const b=new box.B({});b.settleConversation=async base=>base;return b;}

const buttonRow=name=>`<li><div role="button" tabindex="0"><span>${name}</span><div><button aria-label="${name} 的项目操作">…</button><button aria-label="在 ${name} 中开启新聊天">＋</button></div></div><ul><li>暂无聊天</li></ul></li>`;
const markedRow=(name,id)=>`<div role="button" data-app-action-sidebar-project-row data-app-action-sidebar-project-id="${id}" data-app-action-sidebar-project-label="${name}" aria-labelledby="label-${id}" style="content-visibility:auto"><span id="label-${id}">${name}</span><div><button aria-label="${name} 的项目操作"></button></div></div>`;
test('real sidebar public project IDs survive virtualized descendants and collapsed navigation',async()=>{
 const w=dom('<aside hidden>'+markedRow('Typora','g-p-public-1')+markedRow('Same title','g-p-public-2')+markedRow('Same title','g-p-public-3')+'</aside><aside>'+markedRow('Typora','g-p-public-1')+'</aside><article data-testid="conversation-turn-1">'+markedRow('Ignore','g-p-injected')+'</article>','https://chatgpt.com/');
 w.HTMLElement.prototype.getBoundingClientRect=()=>({height:0});const projects=(await w.adapter('projects')).projects;
 assert.equal(projects.length,3);assert.deepEqual(JSON.parse(JSON.stringify(projects[0])),{name:'Typora',buttonName:'Typora',buttonId:'g-p-public-1',url:'https://chatgpt.com/g/g-p-public-1/project'});assert.notEqual(projects[1].url,projects[2].url);w.close();
});
test('current project identity is read from its public row without requiring a visible title',async()=>{
 const w=dom('<aside hidden>'+markedRow('Typora','g-p-test-research')+'</aside><main><h2>今天想聊点什么</h2></main>');const r=await w.adapter('projects');assert.equal(r.current.name,'Typora');assert.equal(r.current.url,project);w.close();
});
test('a partially mounted project page preserves the last complete project list',async()=>{
 const w=dom('');w.eval(fs.readFileSync(path.join(__dirname,'ai-web-projects.js'),'utf8')+';window.P=EditingToolbarAIWebProjects');
 const first={url:project,name:'Typora'},second={url:project.replace('test','second'),name:'Second'};
 const p=new w.P({ai:{config:{}},browser:{ensure:async()=>{},projectCall:async()=>({partial:true,projects:[first]})},refreshUI(){}});p.projects=[first,second];p.renderProjects=()=>{};p.error=e=>assert.fail(e.message);await p.refresh();assert.equal(p.projects.length,2);assert.ok(p.projects.some(x=>x.name==='Second'));w.close();
});
test('current website pinned button projects are listed without requiring href or reading their chat descendants',async()=>{
 const w=dom('<aside><ul>'+buttonRow('Typora')+buttonRow('向老师')+'</ul></aside><article data-testid="conversation-turn-1">'+buttonRow('Injected')+'</article>','https://chatgpt.com/');
 assert.deepEqual(JSON.parse(JSON.stringify((await w.adapter('projects')).projects)),[{name:'Typora',buttonName:'Typora'},{name:'向老师',buttonName:'向老师'}]);
 let opened=0,menus=0;w.document.querySelector('[role=button]').onclick=()=>{opened++;w.history.pushState({},'',project);};w.document.querySelector('[aria-label="Typora 的项目操作"]').onclick=()=>menus++;
 await w.adapter('open-project',{name:'Typora'});assert.equal(opened,1);assert.equal(menus,0);assert.equal(w.location.href,project);w.close();
});
test('duplicate project names and removed button rows fail without clicking any target',async()=>{
 const w=dom('<aside>'+buttonRow('Same')+buttonRow('Same')+'</aside>');let clicks=0;for(const b of w.document.querySelectorAll('[role=button]'))b.onclick=()=>clicks++;
 await assert.rejects(w.adapter('open-project',{name:'Same'}),/同名/);await assert.rejects(w.adapter('open-project',{name:'Removed'}),/入口已变化/);assert.equal(clicks,0);w.close();
});
test('refresh opens a collapsed sidebar before reading delayed public project buttons',async()=>{
 const w=dom('<button aria-label="显示/隐藏侧边栏"></button>','https://chatgpt.com/');let opens=0;w.document.querySelector('button').onclick=()=>{opens++;w.document.body.insertAdjacentHTML('beforeend','<aside><button aria-label="添加新项目">＋</button>'+buttonRow('Typora')+'</aside>');};
 assert.equal((await w.adapter('projects',{expand:true})).projects[0].name,'Typora');await w.adapter('projects',{expand:true});assert.equal(opens,1);w.close();
});
test('project button resolution waits for an observed changed route and never constructs a URL',async()=>{
 const b=browser();b.ensure=async()=>({draft:'',url:'https://chatgpt.com/'});b.ready=true;b.wait=async()=>{};let polls=0,opens=0;
 b.projectCall=async action=>action==='open-project'?(opens++,{opened:true}):{url:++polls<3?'https://chatgpt.com/':project,projects:[]};
 const resolved=await b.resolveProject({name:'Typora',buttonName:'Typora'});assert.equal(resolved.url,project);assert.equal(opens,1);assert.equal(polls,3);
 b.ensure=async()=>({draft:'Do not lose me'});await assert.rejects(b.resolveProject({name:'Other',buttonName:'Other'}),/草稿/);assert.equal(opens,1);
 b.ensure=async()=>({draft:''});b.projectCall=async()=>({current:{name:'Same',url:project},projects:[{name:'Same',buttonName:'Same'},{name:'Same',buttonName:'Same'}]});await assert.rejects(b.resolveProject({name:'Same',buttonName:'Same'}),/同名/);
});
test('a current project uses its own main heading and excludes sidebar names',async()=>{
 const w=dom('<aside><h1>ChatGPT</h1>'+buttonRow('Typora')+'</aside><main><h1>Current unpinned</h1></main>');const result=await w.adapter('projects');assert.equal(result.current.name,'Current unpinned');assert.equal(result.projects.at(-1).url,project);w.close();
});

test('Chinese add-new-project sidebar button opens and submits the real creation dialog once',async()=>{
 const w=dom('<aside><button aria-label="添加新项目"><svg></svg></button></aside><div role="menu" data-state="closed"><button aria-label="添加新项目">stale</button></div>','https://chatgpt.com/');let opened=0,created=0;
 w.document.querySelector('aside button').onclick=()=>{opened++;const d=w.document.createElement('div');d.setAttribute('role','dialog');d.innerHTML='<h2>创建项目</h2><label>项目名称<input placeholder="副本哈根之旅"></label><button disabled>创建项目</button>';d.querySelector('input').oninput=()=>d.querySelector('button').disabled=false;d.querySelector('button').onclick=()=>{created++;assert.equal(d.querySelector('input').value,'11');d.remove();w.history.pushState({},'',project);};w.document.body.append(d);};
 await w.adapter('create-project',{name:'11'});assert.equal(opened,1);assert.equal(created,0);await w.adapter('submit-project',{name:'11'});assert.equal(created,1);assert.equal(w.location.href,project);w.close();
});

test('ambiguous project entry stops without clicking or creating a project',async()=>{
 const w=dom('<button aria-label="添加新项目"></button><button>创建项目</button>');let clicks=0;for(const e of w.document.querySelectorAll('button'))e.onclick=()=>clicks++;await assert.rejects(w.adapter('create-project',{name:'11'}),/无法确认/);assert.equal(clicks,0);w.close();
});

test('project errors expose readable website failure without Electron IPC prefix',async()=>{
 const b=browser();b.call=async()=>({ready:true});b.view={executeJavaScript:async()=>{throw Error("Error invoking remote method 'GUEST_VIEW_MANAGER_CALL': Error: 项目名称发生变化，未创建");}};await assert.rejects(b.projectCall('submit-project',{name:'11'}),e=>e.message==='项目名称发生变化，未创建');
});
test('routing fails closed for a chat outside selected project and handles empty project new chat',async()=>{const b=browser();b.projectChats=async url=>{assert.equal(url,project);return [{url:chat}];};const routes=[];b.navigateTarget=async url=>{routes.push(url);return {url};};b.ensure=async()=>({url:project});await assert.rejects(b.projectRoute({enabled:true,project:{url:project},chat:{url:'https://chatgpt.com/c/wrong'}}),/确认所选聊天/);assert.equal(routes.length,0);assert.equal((await b.projectRoute({enabled:true,project:{url:project},chat:{url:chat}})).url,chat);assert.equal((await b.projectRoute({enabled:true,project:{url:project},chat:null})).url,project);});
test('ordinary new chat leaves project landing even when its composer has no messages',async()=>{const b=browser(),s={url:project,draft:'',userCount:0};b.ensure=async()=>s;b.view={};await b.conversation();assert.equal(b.view.src,'https://chatgpt.com/');assert.equal(b.chatURL(chat),true);assert.equal(b.chatURL('https://chatgpt.com/c/local-chatgpt%3Aid'),false);});
test('project controls stay highlighted when opened and only explicit Exit removes the independent route',async()=>{
 const w=dom('<section id="et-ai-panel"><div class="et-ai-composer"><textarea>保留草稿</textarea><button data-ai="add-context"></button></div><div id="attachments"><label class="et-ai-library-search"></label></div></section>');w.eval('window.EditingToolbarAIAttachments={icon:()=>"<svg></svg>"}');w.eval(fs.readFileSync(path.join(__dirname,'ai-web-projects.js'),'utf8')+';window.P=EditingToolbarAIWebProjects');
 const a={panel:w.document.querySelector('section'),prompt:w.document.querySelector('textarea'),config:{webChat:{projectTarget:{enabled:true,project:{url:project,name:'Typora'},chat:null}}},configKey:'test',turns:[],node:(tag,cls='',text='')=>{const e=w.document.createElement(tag);e.className=cls;e.textContent=text;return e;},composerUI:{makeMenu:()=>w.document.body.appendChild(w.document.createElement('div')),positionMenu(){},closeMenu(){},sync(){}},conversations:{schedule(){}},notice(){}};
 let opened=0,cancelled=0;const p=new w.P({ai:a,active:()=>true,translation:{clear(){cancelled++;}}});p.mount(w.document.querySelector('#attachments'));p.open=async()=>{opened++;};p.toggle.click();await Promise.resolve();assert.equal(opened,1);assert.equal(p.row.dataset.active,'true');assert.equal(p.toggle.getAttribute('aria-pressed'),'true');assert.equal(p.chip.parentElement,a.panel);assert.match(p.chatButton.textContent,/新建聊天/);assert.match(p.chatButton.title,/首条消息发送后/);assert.equal(p.exitButton.getAttribute('aria-label'),'退出项目');p.renderProjects();assert.equal(p.menu.textContent.includes('不使用项目'),false);assert.match(p.menu.textContent,/退出项目/);await p.select(null);assert.equal(p.row.dataset.active,'false');assert.equal(p.chip.hidden,true);assert.equal(a.prompt.value,'保留草稿');assert.equal(cancelled,1);w.close();
});

function projectMenu(){
 const w=dom('<section id="et-ai-panel"><div class="et-ai-composer"><textarea>保留草稿</textarea><button data-ai="add-context"></button></div><div id="attachments"><label class="et-ai-library-search"></label></div></section>');w.eval('window.EditingToolbarAIAttachments={icon:()=>"<svg></svg>"}');w.eval(fs.readFileSync(path.join(__dirname,'ai-web-projects.js'),'utf8')+';window.P=EditingToolbarAIWebProjects');
 const a={panel:w.document.querySelector('section'),config:{},configKey:'ui-test',turns:[],node:(tag,cls='',text='')=>{const e=w.document.createElement(tag);e.className=cls;e.textContent=text;return e;},composerUI:{makeMenu:()=>w.document.body.appendChild(w.document.createElement('div')),positionMenu(){},closeMenu(){},sync(){}},notice(){}};
 const b={resolveProject:async p=>p,projectChats:async()=>[],chatIdentity:url=>url?.split('/c/')[1]||'',projectRoute:async()=>{}};
 const p=new w.P({ai:a,browser:b,active:()=>true,refreshUI(){}});p.mount(w.document.querySelector('#attachments'));p.menu.hidden=false;p.projects=[{url:project,name:'Typora'}];return {w,p,a,b};
}
test('returning to projects during a delayed chat read keeps the parent menu and preserves the draft',async()=>{
 const {w,p,b}=projectMenu();let complete,started;const reading=new Promise(resolve=>started=resolve);b.projectChats=()=>{started();return new Promise(resolve=>complete=resolve);};const job=p.showChats(p.projects[0]);await reading;assert.match(p.menu.textContent,/正在读取聊天/);assert.equal(p.menu.querySelector('[data-kind=primary]').disabled,true);assert.equal(p.menu.querySelector('[data-back]').disabled,false);
 p.menu.querySelector('[data-back]').click();await Promise.resolve();complete([{url:chat,name:'Delayed chat'}]);await job;assert.equal(p.menu.dataset.view,'projects');assert.equal(p.menu.textContent.includes('Delayed chat'),false);assert.equal(p.chats.get(project)[0].name,'Delayed chat');assert.equal(p.menu.getAttribute('aria-busy'),'false');assert.equal(w.document.querySelector('textarea').value,'保留草稿');w.close();
});
test('a failed chat refresh keeps cached choices, announces failure, and can recover without changing the selected route',async()=>{
 const {w,p,a,b}=projectMenu(),target={enabled:true,project:p.projects[0],chat:{url:chat,name:'Saved'}};a.config.webChat={projectTarget:target};p.chats.set(project,[target.chat]);b.projectChats=async()=>{throw Error('暂时无法读取聊天，请重试');};await p.showChats(target.project).catch(e=>p.error(e));assert.equal(p.menu.querySelector('[role=alert] .et-ai-project-status-copy').textContent,'暂时无法读取聊天，请重试');assert.equal(p.menu.querySelector('[aria-label=Saved]').disabled,false);assert.equal(p.selection,target);
 b.projectChats=async()=>[target.chat,{url:chat+'-new',name:'New'}];await p.showChats(target.project);assert.equal(p.menu.querySelector('[role=alert]'),null);assert.equal(p.menu.querySelector('[aria-label=Saved]').getAttribute('aria-pressed'),'true');assert.equal(p.menu.querySelector('.et-ai-project-count').textContent,'2');assert.equal(p.selection,target);w.close();
});
test('chat choices preserve literal long titles, project identity and keyboard navigation',async()=>{
 const {w,p,a,b}=projectMenu(),title='<img src=x onerror=alert(1)> '+ '很长的文献讨论标题'.repeat(12);b.projectChats=async()=>[{url:chat,name:title}];a.config.webChat={projectTarget:{enabled:true,project:{url:project+'-other',name:'Other'},chat:{url:chat,name:title}}};await p.showChats(p.projects[0]);const row=p.menu.querySelector('[data-kind=item][aria-label^="<img"]');assert.equal(row.title,title);assert.equal(row.querySelector('img'),null);assert.equal(row.getAttribute('aria-pressed'),'false');let selected;p.select=async target=>selected=target;row.click();await Promise.resolve();await Promise.resolve();assert.equal(selected.chat.url,chat);assert.equal(selected.project.url,project);
 row.focus();row.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Home',bubbles:true}));assert.equal(w.document.activeElement.getAttribute('aria-label'),'返回项目列表');w.document.activeElement.dispatchEvent(new w.KeyboardEvent('keydown',{key:'End',bubbles:true}));assert.equal(w.document.activeElement,row);w.close();
});


test('background discovery opens delayed sidebar despite a visible rail new-project action and preserves draft',async()=>{
 const w=dom('<button aria-label="打开边栏"></button><button aria-label="添加新项目"></button><textarea>保留网页草稿</textarea>','https://chatgpt.com/c/existing');let opens=0,expands=0,ticks=0;
 w.document.querySelector('[aria-label="打开边栏"]').onclick=()=>opens++;
 w.setTimeout=fn=>queueMicrotask(()=>{ticks++;if(ticks===9){w.document.body.insertAdjacentHTML('beforeend','<aside><button aria-expanded="false">项目</button></aside>');w.document.querySelector('aside button').onclick=e=>{expands++;e.currentTarget.setAttribute('aria-expanded','true');};}if(ticks===15)w.document.querySelector('aside').insertAdjacentHTML('beforeend',markedRow('Delayed project','g-p-delayed'));fn();});
 const r=await w.adapter('projects',{expand:true});assert.equal(r.projects[0].name,'Delayed project');assert.equal(opens,1);assert.equal(expands,1);assert.equal(w.location.href,'https://chatgpt.com/c/existing');assert.equal(w.document.querySelector('textarea').value,'保留网页草稿');assert.ok(ticks>=15);w.close();
});
test('background project refresh expands remaining sections even when pinned projects are already mounted',async()=>{
 const w=dom('<aside>'+markedRow('Pinned project','g-p-pinned')+'<button aria-expanded="false">项目</button></aside>','https://chatgpt.com/');let clicks=0;
 w.document.querySelector('aside>button').onclick=e=>{clicks++;e.currentTarget.setAttribute('aria-expanded','true');w.document.querySelector('aside').insertAdjacentHTML('beforeend',markedRow('Other project','g-p-other'));};const r=await w.adapter('projects',{expand:true});assert.equal(r.projects.length,2);assert.equal(clicks,1);w.close();
});
test('hidden legacy sidebar project links can be read without opening the sidebar and ambiguous toggles are not clicked',async()=>{
 const w=dom('<button aria-label="Open sidebar"></button><aside hidden><a href="'+project+'">Hidden project</a></aside>','https://chatgpt.com/');let clicks=0;w.document.querySelector('button').onclick=()=>clicks++;
 const r=await w.adapter('projects',{expand:true});assert.equal(r.projects[0].name,'Hidden project');assert.equal(clicks,0);w.document.querySelector('aside').remove();w.document.body.insertAdjacentHTML('beforeend','<button aria-label="Open sidebar"></button>');w.document.querySelectorAll('button').forEach(b=>b.onclick=()=>clicks++);assert.equal((await w.adapter('projects',{expand:true})).projects.length,0);assert.equal(clicks,0);w.close();
});

const homeRail=(extra='')=>'<nav data-app-navigation-rail="true"><button data-sidebar-destination="builtin:home" data-slate-sidebar-peek-area="home" aria-current="page" aria-expanded="false" '+extra+'><span>首页</span></button></nav>';
test('cold background discovery peeks the real Home rail and waits for delayed pinned projects without clicking or navigating',async()=>{
 const w=dom(homeRail()+'<a href="/">首页</a><textarea>原聊天草稿</textarea>','https://chatgpt.com/c/existing');let opens=0,expands=0,ticks=0,clicks=0,leaves=0;
 const rail=w.document.querySelector('nav button');rail.onclick=()=>{clicks++;w.history.pushState({},'','/');};rail.addEventListener('pointerover',e=>{opens++;e.currentTarget.setAttribute('aria-expanded','true');});rail.addEventListener('pointerout',e=>{leaves++;e.currentTarget.setAttribute('aria-expanded','false');});
 w.setTimeout=fn=>queueMicrotask(()=>{ticks++;if(opens&&ticks===10){w.document.body.insertAdjacentHTML('beforeend','<aside id="app-shell-sidebar"><button aria-expanded="false">置顶</button><div role="progressbar"></div></aside>');w.document.querySelector('aside button').onclick=e=>{expands++;e.currentTarget.setAttribute('aria-expanded','true');};}if(opens&&ticks===35){w.document.querySelector('[role="progressbar"]').remove();w.document.querySelector('aside').insertAdjacentHTML('beforeend',markedRow('Typora','g-p-one')+markedRow('向老师','g-p-two')+markedRow('鲁星星','g-p-three'));}fn();});
 const first=await w.adapter('projects',{expand:true});assert.deepEqual(Array.from(first.projects,p=>p.name),['Typora','向老师','鲁星星']);assert.equal(opens,1);assert.equal(expands,1);assert.equal(leaves,1);assert.equal(clicks,0);assert.ok(ticks>=35);assert.equal(w.location.href,'https://chatgpt.com/c/existing');assert.equal(w.document.querySelector('textarea').value,'原聊天草稿');assert.equal((await w.adapter('projects',{expand:true})).projects.length,3);assert.equal(opens,1);w.close();
});
test('background lookup never follows ordinary home links or ambiguous, inactive and message-injected Home buttons',async()=>{
 for(const html of ['<nav><a href="/">首页</a><button aria-expanded="false">首页</button></nav>',homeRail()+homeRail(),homeRail().replace('aria-current="page"',''),'<main>'+homeRail()+'</main>','<article data-testid="conversation-turn-1">'+homeRail()+'</article>',homeRail('disabled'),'<div role="dialog">'+homeRail()+'</div>']){
  const w=dom(html,'https://chatgpt.com/c/existing');let clicks=0;w.document.querySelectorAll('a,button').forEach(e=>{e.onclick=()=>clicks++;e.addEventListener('pointerover',()=>clicks++);});const r=await w.adapter('projects',{expand:true});assert.equal(r.projects.length,0);assert.equal(clicks,0);assert.equal(w.location.href,'https://chatgpt.com/c/existing');w.close();
 }
});
test('project discovery waits for remaining sidebar rows while its visible loader is active',async()=>{
 const w=dom('<aside id="app-shell-sidebar">'+markedRow('First','g-p-first')+'<div aria-busy="true"></div></aside>','https://chatgpt.com/');let ticks=0;
 w.setTimeout=fn=>queueMicrotask(()=>{if(++ticks===12){w.document.querySelector('[aria-busy]').remove();w.document.querySelector('aside').insertAdjacentHTML('beforeend',markedRow('Second','g-p-second'));}fn();});assert.equal((await w.adapter('projects',{expand:true})).projects.length,2);assert.ok(ticks>=12);w.close();
});


test('same chat ID with a project title suffix or plain route is verified against its project before navigation',async()=>{
 const b=browser(),projectURL='https://chatgpt.com/g/g-p-6ac310a2a0cc81918efd0424764ed6be/project',id='6ac38fdb-e948-83e8-9db7-fed02c865b5b',saved=projectURL.replace('/project','/c/'+id),fresh=projectURL.replace('/project','-typora/c/'+id),visited=[];
 b.projectChats=async(url,signal,options)=>{assert.equal(url,projectURL);assert.equal(options.expectedChat,saved);return [{url:fresh,name:'翻译文献 ZIP交付'}];};b.navigateTarget=async url=>(visited.push(url),{url});
 assert.equal((await b.projectRoute({enabled:true,project:{url:projectURL},chat:{url:saved}})).url,fresh);assert.deepEqual(visited,[fresh]);assert.equal(b.chatIdentity(saved),b.chatIdentity('https://chatgpt.com/c/'+id+'?from=project'));assert.equal(b.sameTarget(fresh,saved),true);assert.equal(b.chatIdentity('https://evil.test/c/'+id),'');assert.equal(b.chatIdentity('https://user@chatgpt.com/c/'+id),'');
 b.projectChats=async()=>[{url:'https://chatgpt.com/c/different-id',name:'翻译文献 ZIP交付'}];await assert.rejects(b.projectRoute({enabled:true,project:{url:projectURL},chat:{url:saved}}),/没有发送/);assert.equal(visited.length,1);
});
test('navigation accepts a project-name redirect only when the confirmed chat ID remains the same',async()=>{
 const b=browser(),destination='https://chatgpt.com/g/g-p-test/c/verified',actual='https://chatgpt.com/g/g-p-test-title/c/verified';let calls=0;b.ensure=async()=>++calls===1?{url:project,draft:''}:{url:actual,draft:''};b.view={};assert.equal((await b.navigateTarget(destination)).url,actual);assert.equal(b.view.src,destination);
 calls=0;b.ensure=async()=>++calls===1?{url:project,draft:''}:{url:'https://chatgpt.com/c/wrong',draft:''};await assert.rejects(b.navigateTarget(destination),/未进入指定/);
});
test('project membership waits for delayed rows and paginated target instead of trusting the first empty read',async()=>{
 const b=browser();b.navigateTarget=async()=>({url:project});b.wait=async()=>{};let polls=0,moreClicks=0,afterMore=0;const first={url:'https://chatgpt.com/c/first',name:'First'},wanted={url:chat,name:'Wanted'};
 b.projectCall=async(action,args)=>{polls++;if(args.more){moreClicks++;afterMore=1;return {chats:[first],more:true,advanced:true,loading:true};}if(afterMore){afterMore++;return afterMore<5?{chats:[first],more:true,loading:true}:{chats:[first,wanted],more:false};}return polls<7?{chats:[],more:false,loading:true}:{chats:[first],more:true};};
 const result=await b.projectChats(project,undefined,{expectedChat:chat});assert.equal(result.at(-1).url,chat);assert.ok(polls>=13);assert.equal(moreClicks,1);
});
test('cancelled project lookup stops polling before navigating to any conversation',async()=>{
 const b=browser(),controller=new AbortController();let polls=0;b.navigateTarget=async()=>({url:project});b.wait=async()=>{controller.abort();};b.projectCall=async()=>{polls++;return {chats:[],more:false,loading:true};};await assert.rejects(b.projectChats(project,controller.signal,{expectedChat:chat}),e=>e.name==='AbortError');assert.equal(polls,1);
});
test('mounted offscreen project chat links are readable and pagination state is checked after advancing',async()=>{
 const w=dom('<main><button role="tab" aria-selected="true">聊天</button><a href="'+chat+'">Existing</a><button id="more">加载更多</button></main>');w.document.querySelector('a').getBoundingClientRect=()=>({height:0});w.document.querySelector('#more').onclick=e=>{e.currentTarget.remove();w.document.querySelector('main').insertAdjacentHTML('beforeend','<a href="/c/second">Second</a>');};const r=await w.adapter('chats',{project,more:true});assert.equal(r.chats.length,2);assert.equal(r.advanced,true);assert.equal(r.more,false);w.close();
});


test('project entry remains visible but disabled outside GPT web and restores the saved target',async()=>{
 const {w,p,a,b}=projectMenu();a.config.webChat={projectTarget:{enabled:true,project:{url:project,name:'Typora'},chat:{url:chat,name:'Existing'}}};let active=false,opens=0;p.web.active=()=>active;a.composerUI.openMenu=()=>opens++;p.refresh=async()=>{};
 p.sync();assert.equal(p.target(),null);assert.equal(p.row.hidden,false);assert.equal(p.toggle.disabled,true);assert.equal(p.chip.hidden,true);assert.equal(p.toggle.getAttribute('aria-pressed'),'false');p.toggle.click();await p.open();assert.equal(opens,0);assert.equal(a.config.webChat.projectTarget.chat.url,chat);
 active=true;p.sync();assert.equal(p.target().chat.url,chat);assert.equal(p.toggle.disabled,false);assert.equal(p.chip.hidden,false);assert.equal(p.chatButton.textContent,'Existing');await p.open();assert.equal(opens,1);w.close();
});

test('unavailable identity after list read keeps verified principal and usable project menu',async()=>{
 const {w,p,b,a}=projectMenu();a.composerUI.openMenu=()=>{};let scope='A';b.ensure=async()=>{};b.scope=async()=>scope;b.projectCall=async()=>{scope='';return{projects:[{url:project,name:'Retained project'}]};};await p.open();assert.equal(p.scopeKey,'A');assert.equal(p.scopeVerified,false);assert.equal(p.menu.querySelector('.et-ai-project-heading strong').textContent,'项目模式');assert.ok(p.menu.querySelector('[aria-label="Retained project"]'));assert.ok(p.menu.querySelector('[aria-label="查看 GPT 网页"]'));assert.equal(p.menu.getAttribute('aria-busy'),'false');w.close();
});
test('identity lookup keeps menu shell visible and failures use one inline retry that recovers',async()=>{
 const {w,p,b,a}=projectMenu();a.composerUI.openMenu=()=>{};let notices=0,release,started;a.notice=()=>notices++;const began=new Promise(r=>started=r);b.ensure=async()=>{};b.scope=async()=>{started();return new Promise(r=>release=r);};const opening=p.open();await began;assert.ok(p.menu.querySelector('.et-ai-project-heading'));assert.ok(p.menu.querySelector('[aria-label="查看 GPT 网页"]'));assert.match(p.menu.textContent,/正在读取项目/);b.scope=async()=> 'A';b.projectCall=async()=>{throw Error('暂时无法读取项目');};release('A');await opening.catch(e=>p.error(e));assert.equal(notices,0);assert.ok(p.menu.querySelector('[role=alert]'));assert.equal(p.menu.querySelector('[aria-label="重新读取列表"]').disabled,false);b.projectCall=async()=>({projects:[{url:project,name:'Recovered'}]});p.menu.querySelector('[aria-label="重新读取列表"]').click();await p.refreshJob;assert.ok(p.menu.querySelector('[aria-label=Recovered]'));assert.equal(p.menu.querySelector('[role=alert]'),null);w.close();
});
