const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),os=require('node:os');
function fixture(){
  let now=0,serial=0;const timers=new Map(),box={ETAIExecution:require('./ai-execution.cjs'),performance:{now:()=>now},setInterval:fn=>{timers.set(++serial,fn);return serial;},clearInterval:id=>timers.delete(id)};
  vm.createContext(box);vm.runInContext(fs.readFileSync(require.resolve('./ai-turn-timing.js'),'utf8')+';globalThis.Timing=EditingToolbarAITiming;',box);
  return {T:box.Timing,box,timers,at:ms=>now=ms,tick:()=>[...timers.values()].forEach(fn=>fn())};
}
test('duration formatting covers seconds, minutes, hours and subsecond completion',()=>{
  const {T}=fixture();for(const [ms,label] of [[0,'0秒'],[59999,'59秒'],[60000,'1分0秒'],[228000,'3分48秒'],[1436000,'23分56秒'],[3723000,'1小时2分3秒']])assert.equal(T.format(ms),label);
  assert.equal(T.label({elapsedMs:450,status:'done'}),'用时 不足 1秒');assert.equal(T.label({elapsedMs:0,status:'running'}),'已处理 0秒');
});
test('waiting clock ticks without chunks, updates only metadata and never duplicates timers',()=>{
  const {T,at,tick,timers}=fixture(),turn={model:'mock',status:'running',meta:{textContent:''},article:{isConnected:true}};
  T.begin(turn);T.watch(turn);T.watch(turn);assert.equal(timers.size,1);assert.equal(turn.meta.textContent,'mock · 已处理 0秒');at(228400);tick();assert.equal(turn.meta.textContent,'mock · 已处理 3分48秒');
  turn.status='done';T.finish(turn);T.update(turn);assert.equal(turn.elapsedMs,228400);assert.equal(timers.size,0);at(500000);tick();assert.equal(T.elapsed(turn),228400);assert.equal(turn.meta.textContent,'mock · 用时 3分48秒');
});
test('stops and failures freeze time; retries start from zero',()=>{
  const {T,at}=fixture(),turn={model:'mock',status:'running'};T.begin(turn);at(3600);turn.status='stopped';T.finish(turn);assert.equal(T.label(turn),'已停止 · 用时 3秒');at(10000);assert.equal(T.elapsed(turn),3600);
  turn.status='running';T.begin(turn);assert.equal(T.elapsed(turn),0);at(12020);turn.status='error';turn.detail='连接中断';T.finish(turn);assert.equal(T.label(turn),'连接中断 · 用时 2秒');assert.equal(turn.elapsedMs,2020);
});
test('detached content stops repainting and leaves no interval',()=>{
  const {T,at,tick,timers}=fixture(),turn={model:'mock',status:'running',meta:{textContent:''},article:{isConnected:true}};T.begin(turn);T.watch(turn);turn.article.isConnected=false;at(5000);tick();assert.equal(timers.size,0);assert.equal(turn.meta.textContent,'mock · 已处理 0秒');T.finish(turn);assert.equal(turn.elapsedMs,5000);
});
test('legacy and invalid durations never infer time from historical timestamps',()=>{
  const {T,at,timers}=fixture();at(999999);for(const elapsedMs of [undefined,null,-1,Infinity,NaN,'1200']){const turn={status:'done',elapsedMs,time:'2020-01-01'};assert.equal(T.elapsed(turn),undefined);assert.equal(T.label(turn),'完成');T.watch(turn);}assert.equal(timers.size,0);assert.equal(T.label({status:'stopped'}),'已停止');
});
test('conversation snapshots persist sampled elapsed without clock or DOM state',()=>{
  const {T,box,at}=fixture();vm.runInContext(fs.readFileSync(require.resolve('./ai-conversations.js'),'utf8')+';globalThis.C=EditingToolbarAIConversations;',box);
  const turn={id:'t',status:'running',question:'q',answer:'a',meta:{textContent:''}};T.begin(turn);at(7321);
  const c=Object.assign(Object.create(box.C.prototype),{store:{id:()=> 'session'},ai:{context:{file:'a.md'},turns:[turn],composerUI:{draft:{text:()=>''},snapshot:()=>({})}}});
  const saved=c.data().turns[0];assert.equal(saved.elapsedMs,7321);assert.equal(saved.meta,undefined);assert.equal(JSON.stringify(saved).includes('timer'),false);assert.equal(turn.elapsedMs,0);
});
test('elapsed duration survives session storage and JSON export without creating timers',t=>{
  const Store=require('./ai-session-store.cjs'),Export=require('./ai-conversation-export.cjs'),base=path.join(os.homedir(),'Downloads','codex-temp');fs.mkdirSync(base,{recursive:true});const dir=fs.mkdtempSync(path.join(base,'ai-timing-test-'));
  t.after(()=>{if(!path.resolve(dir).startsWith(path.resolve(base)+path.sep))throw Error('Unsafe cleanup');fs.rmSync(dir,{recursive:true,force:true});});
  const store=new Store(require,dir),record=store.write({id:store.id(),title:'timing',file:'fixture.md',created:new Date().toISOString(),turns:[{id:store.id(),question:'q',answer:'a',status:'done',elapsedMs:1436123}]},null),loaded=new Store(require,dir).read(record.id);
  assert.equal(loaded.turns[0].elapsedMs,1436123);assert.equal(JSON.parse(Export.serialize(loaded,'json')).turns[0].elapsedMs,1436123);const {T,timers}=fixture();T.watch(loaded.turns[0]);assert.equal(timers.size,0);assert.equal(T.label(loaded.turns[0]),'用时 23分56秒');
});

test('question timestamps use local today, Monday-based week, current year and full other-year dates',()=>{
 const {T}=fixture(),now=new Date(2026,9,3,12,0),iso=(y,m,d,h=8,minute=53)=>new Date(y,m-1,d,h,minute).toISOString();
 for(const [value,expected] of [[iso(2026,10,3),'8:53'],[iso(2026,10,1),'星期四 8:53'],[iso(2026,9,28),'星期一 8:53'],[iso(2026,9,27),'9月27日 8:53'],[iso(2026,1,3),'1月3日 8:53'],[iso(2025,10,3),'2025年10月3日 8:53']])assert.equal(T.questionTime(value,now).label,expected);
 const full=T.questionTime(iso(2026,10,3,0,4),now);assert.equal(full.label,'0:04');assert.equal(full.full,'2026年10月3日 0:04');assert.equal(full.dateTime,iso(2026,10,3,0,4));
});
test('question timestamps handle week/month/year boundaries and missing legacy values',()=>{
 const {T}=fixture(),iso=(y,m,d)=>new Date(y,m-1,d,8,53).toISOString();
 assert.equal(T.questionTime(iso(2026,10,4),new Date(2026,9,5)).label,'10月4日 8:53');
 assert.equal(T.questionTime(iso(2026,10,3),new Date(2026,9,10)).label,'10月3日 8:53');
 assert.equal(T.questionTime(iso(2026,9,30),new Date(2026,9,1)).label,'星期三 8:53');
 assert.equal(T.questionTime(iso(2025,12,31),new Date(2026,0,1)).label,'2025年12月31日 8:53');
 for(const bad of [undefined,null,'','invalid',false,Infinity,NaN,{}])assert.equal(T.questionTime(bad),null);
});

test('execution panel owns elapsed label while model metadata stays concise; legacy turns retain duration',()=>{
 const {T}=fixture(),turn={model:'gpt-6.1-sol',status:'done',elapsedMs:26000,execution:[{type:'tool'}],meta:{textContent:''},executionUI:{updateClock(){this.calls=(this.calls||0)+1;}}};T.update(turn);assert.equal(turn.meta.textContent,'gpt-6.1-sol');assert.equal(turn.executionUI.calls,1);turn.execution=[];T.update(turn);assert.equal(turn.meta.textContent,'gpt-6.1-sol · 用时 26秒');
});


test('receiving an existing submission adds active recovery time without resetting prior elapsed',()=>{
 const {T,at}=fixture(),turn={status:'error',elapsedMs:55000};at(100000);T.begin(turn,{resume:true});assert.equal(T.elapsed(turn),55000);at(102500);T.finish(turn);assert.equal(turn.elapsedMs,57500);T.begin(turn);assert.equal(T.elapsed(turn),0);
});
