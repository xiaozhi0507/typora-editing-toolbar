'use strict';
// Runs only in the local helper. Tokens never cross the UI IPC boundary.
const fs=require('fs'),path=require('path'),crypto=require('crypto'),http=require('http'),https=require('https'),cp=require('child_process');
const Client=require('./ai-client.cjs');
const ISSUER='https://auth.openai.com',RESOURCE='https://api.openai.com/v1';
// The catalog is version-gated: omitting client_version returns a legacy list.
// Identify this assistant's actual release, not the installed Codex version.
const CLIENT_VERSION='1.107.0';
const SCOPES='openid profile email offline_access resource.invoke chatgpt.tokens.use.direct';
const fail=(message,code='CHATGPT_ERROR')=>Object.assign(Error(message),{code});
const abortError=()=>Object.assign(Error('已取消'),{name:'AbortError',code:'ABORT_ERR'});
const random=()=>crypto.randomBytes(32).toString('base64url');
function publicError(e){
  const code=String(e.code||'CHATGPT_ERROR');
  const text={subscription_sharing_usage_limit_exceeded:'ChatGPT 套餐或本应用达到使用上限，请打开“管理额度”查看。',subscription_sharing_user_not_eligible:'当前账号、工作区或策略暂不允许在此应用使用 ChatGPT 套餐。',subscription_sharing_usage_unavailable:'暂时无法查询 ChatGPT 额度，请稍后重试。',subscription_sharing_user_unavailable:'ChatGPT 账号服务暂不可用，请稍后重试。',subscription_sharing_unsupported_capability:'此账号接口不支持本次请求的某项能力。',subscription_sharing_route_not_supported:'此账号暂不支持官方 Responses 接入。',subscription_sharing_invalid_user:'登录凭据已失效，请重新登录。',chatpass_v2_scope_not_authorized:'尚未获得 ChatGPT 套餐使用权限，请重新授权。',chatpass_v2_invalid_authorization_context:'ChatGPT 授权上下文无效，请重新授权。',invalid_grant:'登录凭据已过期，请重新登录。',invalid_client:'账号注册信息无效，请重新连接。',access_denied:'你取消了 ChatGPT 授权。'}[code];
  return {message:text||e.message||'ChatGPT 连接失败',code,status:e.status,name:e.name==='AbortError'?'AbortError':'Error'};
}
function requestJSON(url,{form,token,signal}={}){
  const u=new URL(url);if(u.protocol!=='https:'||u.username||u.password||u.hash||![ISSUER,new URL(RESOURCE).origin].includes(u.origin))throw fail('拒绝非官方授权地址');
  return new Promise((resolve,reject)=>{
    let request,done=false;const finish=(e,v)=>{if(done)return;done=true;signal?.removeEventListener('abort',abort);request?.destroy();e?reject(e):resolve(v);},abort=()=>finish(abortError());
    if(signal?.aborted)return abort();signal?.addEventListener('abort',abort,{once:true});
    const body=form?new URLSearchParams(form).toString():null;
    request=https.request(u,{method:body?'POST':'GET',headers:{Accept:'application/json',...(body?{'Content-Type':'application/x-www-form-urlencoded'}:{}),...(token?{Authorization:'Bearer '+token}:{})}},res=>{
      let data='',bytes=0;res.setEncoding('utf8');res.on('data',s=>{bytes+=Buffer.byteLength(s);if(bytes>2*1024*1024)return finish(fail('授权服务响应过大'));data+=s;});
      res.on('end',()=>{let value;try{value=data?JSON.parse(data):{};}catch{return finish(fail('授权服务返回格式无效'));}
        if(res.statusCode<200||res.statusCode>=300){const code=typeof value.error==='string'?value.error:value.error?.code;const safeCode=/^[a-z0-9_]{1,100}$/.test(code||'')?code:'HTTP_'+res.statusCode;return finish(Object.assign(fail('ChatGPT 服务请求失败（HTTP '+res.statusCode+'）',safeCode),{status:res.statusCode}));}finish(null,value);});
      res.on('aborted',()=>finish(fail('授权连接中断')));res.on('error',()=>finish(fail('授权连接中断')));
    });request.on('error',()=>finish(fail('无法连接官方服务，请检查网络后重试')));request.setTimeout(30000,()=>finish(fail('官方服务连接超时')));request.end(body);
  });
}
function protect(text,decrypt=false){
  const script="$ErrorActionPreference='Stop';Add-Type -AssemblyName System.Security;try{$b=[Convert]::FromBase64String([Console]::In.ReadToEnd());$r=[Security.Cryptography.ProtectedData]::"+(decrypt?'Unprotect':'Protect')+"($b,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser);[Console]::Out.Write([Convert]::ToBase64String($r))}catch{exit 1}";
  return new Promise((resolve,reject)=>{const p=cp.execFile('powershell.exe',['-NoProfile','-NonInteractive','-Command',script],{windowsHide:true,timeout:15000,maxBuffer:2*1024*1024},(e,out)=>e?reject(fail('无法读取或加密本机 ChatGPT 凭据')):resolve(decrypt?Buffer.from(out.trim(),'base64').toString('utf8'):out.trim()));p.stdin.on('error',()=>{});p.stdin.end(decrypt?text:Buffer.from(text,'utf8').toString('base64'));});
}
class ChatGPTService {
  constructor(directory,deps={}){this.dir=path.resolve(directory);this.transport=deps.transport||requestJSON;this.protect=deps.protect||protect;this.client=deps.client||new Client(require);this.now=deps.now||Date.now;this.catalogs=new Map();}
  async locked(fn){
    fs.mkdirSync(this.dir,{recursive:true});const file=path.join(this.dir,'credentials.lock');let fd;
    for(let attempt=0;attempt<25;attempt++){
      try{fd=fs.openSync(file,'wx');fs.writeFileSync(fd,JSON.stringify({pid:process.pid}));break;}catch(e){if(e.code!=='EEXIST')throw e;
        try{const owner=JSON.parse(fs.readFileSync(file,'utf8'));try{process.kill(owner.pid,0);}catch(e){if(e.code==='ESRCH'){fs.unlinkSync(file);continue;}}}catch{}
        await new Promise(r=>setTimeout(r,100));
      }
    }
    if(fd===undefined)throw fail('另一个窗口正在登录或更新 ChatGPT 凭据，请稍后重试');
    try{return await fn();}finally{fs.closeSync(fd);fs.unlinkSync(file);}
  }
  async read(){
    const file=path.join(this.dir,'credentials.dpapi');if(!fs.existsSync(file))return {version:1,accounts:[]};
    try{const state=JSON.parse(await this.protect(fs.readFileSync(file,'utf8'),true));if(state.version!==1||!Array.isArray(state.accounts))throw Error();return state;}catch{throw fail('ChatGPT 本机凭据无法解密，原文件已保留。');}
  }
  async save(state){const file=path.join(this.dir,'credentials.dpapi'),tmp=file+'.'+crypto.randomUUID()+'.tmp';try{fs.writeFileSync(tmp,await this.protect(JSON.stringify(state)),{flag:'wx',mode:0o600});fs.renameSync(tmp,file);}finally{if(fs.existsSync(tmp))fs.unlinkSync(tmp);}}
  host(){const file=path.join(this.dir,'host.json');if(fs.existsSync(file)){const id=JSON.parse(fs.readFileSync(file,'utf8')).id;if(!/^urn:uuid:[a-f0-9-]{36}$/.test(id))throw fail('本机 ChatGPT 标识损坏');return id;}const id='urn:uuid:'+crypto.randomUUID();fs.writeFileSync(file,JSON.stringify({id}),{flag:'wx',mode:0o600});return id;}
  publicAccount(a){return {id:a.client_id,email:a.email||'',name:a.name||'ChatGPT 账号',subjectTag:a.subject?crypto.createHash('sha256').update(a.subject).digest('hex').slice(0,6):'',connected:!!a.access_token,enabled:!!a.access_token&&a.scopes?.includes('chatgpt.tokens.use.direct')&&a.scopes?.includes('resource.invoke')};}
  async list(){return this.locked(async()=>{const s=await this.read();return s.accounts.map(a=>this.publicAccount(a));});}
  // SIWC plan sharing does not expose Codex account/rateLimits/read. Never reuse another app's credentials.
  async usage(id){const accounts=await this.list(),account=accounts.find(a=>a.id===id);if(!account?.connected)throw fail('ChatGPT 账号未连接，请先登录');return {available:false,checkedAt:this.now(),reason:'当前 ChatGPT 套餐授权没有提供剩余额度查询接口。请在 ChatGPT 用量页查看。',manageUrl:'https://chatgpt.com/settings/usage'};}
  async discovery(){
    if(this.metadata)return this.metadata;const d=await this.transport(ISSUER+'/.well-known/openid-configuration');
    if(d.issuer!==ISSUER)throw fail('官方身份服务标识不匹配');
    for(const name of ['jwks_uri','revocation_endpoint']){const u=new URL(d[name]);if(u.protocol!=='https:'||u.origin!==ISSUER)throw fail('官方身份服务地址不匹配');}
    this.metadata=d;return d;
  }
  async verify(token,clientId,nonce,subject){
    try{
      const chunks=String(token||'').split('.');if(chunks.length!==3)throw Error();const header=JSON.parse(Buffer.from(chunks[0],'base64url')),p=JSON.parse(Buffer.from(chunks[1],'base64url'));
      if(!['RS256','ES256'].includes(header.alg)||typeof header.kid!=='string')throw Error();
      const d=await this.discovery(),keys=await this.transport(d.jwks_uri),matching=keys.keys.filter(k=>k.kid===header.kid&&(!k.use||k.use==='sig')&&(!k.alg||k.alg===header.alg));if(matching.length!==1)throw Error();
      const key=crypto.createPublicKey({key:matching[0],format:'jwk'});if((header.alg==='RS256'&&key.asymmetricKeyType!=='rsa')||(header.alg==='ES256'&&(key.asymmetricKeyType!=='ec'||matching[0].crv!=='P-256')))throw Error();
      if(!crypto.verify('sha256',Buffer.from(chunks[0]+'.'+chunks[1]),{key,dsaEncoding:'ieee-p1363'},Buffer.from(chunks[2],'base64url')))throw Error();
      const aud=Array.isArray(p.aud)?p.aud:[p.aud],now=this.now()/1000;
      if(p.iss!==ISSUER||!aud.includes(clientId)||((aud.length>1||p.azp)&&p.azp!==clientId)||!Number.isFinite(p.exp)||p.exp<=now||!p.sub||typeof p.sub!=='string'||(p.nbf&&p.nbf>now+30)||(p.iat&&p.iat>now+30)||(nonce&&p.nonce!==nonce)||(subject&&p.sub!==subject))throw Error();return p;
    }catch(e){throw fail('ChatGPT 身份校验未通过，请重新登录。','IDENTITY_INVALID');}
  }
  tokens(result,old={}){
    const scopes=typeof result.scope==='string'?result.scope.split(/\s+/):old.scopes||[];
    if(scopes.includes('chatgpt.tokens.use.direct')&&(!result.access_token||String(result.token_type).toLowerCase()!=='bearer'))throw fail('授权响应缺少套餐访问凭据');
    const seconds=Number(result.expires_in);if(result.access_token&&(!Number.isFinite(seconds)||seconds<=0||seconds>86400))throw fail('授权响应有效期无效');
    return {...old,access_token:result.access_token||'',refresh_token:result.refresh_token||old.refresh_token||'',id_token:result.id_token||old.id_token||'',scopes,expiresAt:this.now()+seconds*1000,earliestRefreshAt:result.earliest_refresh_at};
  }
  async signIn(accountId,{signal,onAuthorize=()=>{}}={}){
    return this.locked(async()=>{
      const state=await this.read(),old=accountId?state.accounts.find(a=>a.client_id===accountId):null;if(accountId&&!old)throw fail('账号注册不存在，请重新选择');
      const host=this.host(),verifier=random(),nonce=random(),expectedState=random();let server,timer,settled=false;
      const result=await new Promise((resolve,reject)=>{
        const finish=(e,value)=>{if(settled)return;settled=true;clearTimeout(timer);signal?.removeEventListener('abort',abort);server?.close();e?reject(e):resolve(value);},abort=()=>finish(abortError());
        if(signal?.aborted)return abort();signal?.addEventListener('abort',abort,{once:true});
        server=http.createServer(async(req,res)=>{
          const reply=(code,text)=>{res.writeHead(code,{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store','Content-Security-Policy':"default-src 'none'",'X-Content-Type-Options':'nosniff'});res.end(text);};
          let u;try{u=new URL(req.url,'http://127.0.0.1');}catch{return reply(400,'Invalid callback');}
          if(req.headers.host!=='127.0.0.1:'+server.address().port)return reply(400,'Invalid host');
          if(req.method!=='GET'||u.pathname!=='/auth/callback')return reply(404,'Not found');
          if(u.searchParams.getAll('state').length!==1||u.searchParams.get('state')!==expectedState)return reply(400,'登录状态不匹配，请回到原授权页面。');
          if(settled)return reply(409,'本次登录已结束。');
          const error=u.searchParams.get('error');if(error){reply(400,'未完成授权，请返回 Typora。');return finish(fail('未完成 ChatGPT 授权',error==='access_denied'?error:'OAUTH_ERROR'));}
          const issued=u.searchParams.get('client_id')||old?.client_id,code=u.searchParams.get('code');
          if(!issued||issued==='dynamic_agent_client'||!/^oaiapp_[A-Za-z0-9_-]+$/.test(issued)||!code||u.searchParams.getAll('client_id').length>1||u.searchParams.getAll('code').length!==1||(old&&issued!==old.client_id)){reply(400,'账号注册信息不匹配，请返回 Typora 重新登录。');return finish(fail('账号注册信息不匹配'));}
          reply(200,'已收到授权，请返回 Typora 查看连接结果。');finish(null,{issued,code});
        });server.on('error',()=>finish(fail('无法启动本机登录回调')));server.listen(0,'127.0.0.1',()=>{
          if(settled){server.close();return;}
          const redirect='http://127.0.0.1:'+server.address().port+'/auth/callback';this.redirect=redirect;
          const u=new URL(ISSUER+'/api/accounts/authorize');const params={client_id:old?.client_id||'dynamic_agent_client',ext_agent_host_id:host,response_type:'code',redirect_uri:redirect,scope:SCOPES,resource:RESOURCE,state:expectedState,nonce,code_challenge_method:'S256',code_challenge:crypto.createHash('sha256').update(verifier).digest('base64url')};
          if(!old)params.agent_name_hint='Typora AI 阅读助手';else if(old.email)params.login_hint=old.email;
          // Omit optional id_token_hint so no credential enters the UI's browser-opening event.
          if(old&&!old.scopes?.includes('chatgpt.tokens.use.direct'))params.prompt='consent';
          for(const [k,v]of Object.entries(params))u.searchParams.set(k,v);try{onAuthorize(u.toString());}catch{finish(fail('无法打开系统浏览器'));}
        });timer=setTimeout(()=>finish(fail('登录等待超时，请重新连接')),300000);
      });
      const registration=old||{client_id:result.issued};if(!old){state.accounts.push(registration);await this.save(state);}
      const token=await this.transport(ISSUER+'/api/accounts/oauth/token',{form:{grant_type:'authorization_code',client_id:result.issued,code:result.code,code_verifier:verifier,redirect_uri:this.redirect,resource:RESOURCE},signal});
      const identity=await this.verify(token.id_token,result.issued,nonce,old?.subject);const next=this.tokens(token,registration);Object.assign(registration,next,{subject:identity.sub,email:identity.email||'',name:identity.name||'ChatGPT 账号'});await this.save(state);this.catalogs.delete(registration.client_id);return this.publicAccount(registration);
    });
  }
  async credentials(id){return this.locked(async()=>{
    const state=await this.read(),a=state.accounts.find(a=>a.client_id===id);if(!a?.access_token)throw fail('请先连接或重新登录 ChatGPT');if(!a.scopes?.includes('chatgpt.tokens.use.direct')||!a.scopes?.includes('resource.invoke'))throw fail('此账号尚未授权套餐使用，请重新授权');
    if(a.expiresAt>this.now()+90000)return {...a};if(!a.refresh_token)throw fail('登录已过期，请重新登录');
    try{const token=await this.transport(ISSUER+'/api/accounts/oauth/token',{form:{grant_type:'refresh_token',client_id:a.client_id,refresh_token:a.refresh_token,resource:RESOURCE}});if(!token.refresh_token)throw fail('刷新响应缺少新凭据，请重新登录');if(token.id_token)await this.verify(token.id_token,a.client_id,null,a.subject);Object.assign(a,this.tokens(token,a));await this.save(state);}
    catch(e){if(['invalid_grant','invalid_refresh_token','token_expired','refresh_token_expired','refresh_token_invalidated','refresh_token_reused'].includes(e.code)){delete a.access_token;delete a.refresh_token;delete a.id_token;await this.save(state);}throw e;}
    if(!this.publicAccount(a).enabled)throw fail('ChatGPT 套餐权限已失效，请重新授权');return {...a};
  });}
  async models(id){const a=await this.credentials(id),url=new URL(RESOURCE+'/models');url.searchParams.set('client_version',CLIENT_VERSION);const result=await this.transport(url.toString(),{token:a.access_token});if(!Array.isArray(result.models))throw fail('账号未返回可用模型列表');const models=result.models.filter(m=>m.visibility==='list'&&typeof m.slug==='string').map(m=>({id:m.slug,name:String(m.display_name||m.slug),...Client.effortMetadata(m)}));this.catalogs.set(id,models);return models;}
  async disconnect(id){return this.locked(async()=>{const s=await this.read(),a=s.accounts.find(a=>a.client_id===id);if(!a)return {revoked:true};let revoked=true;try{if(a.refresh_token){const d=await this.discovery();await this.transport(d.revocation_endpoint,{form:{token:a.refresh_token,token_type_hint:'refresh_token',client_id:a.client_id}});}}catch{revoked=false;}delete a.access_token;delete a.refresh_token;delete a.id_token;delete a.expiresAt;await this.save(s);this.catalogs.delete(id);return {revoked};});}
  async request(profile,messages,callbacks){
    const codeFiles=Client.attachedFiles(profile);
    const models=this.catalogs.get(profile.chatgptAccount)||await this.models(profile.chatgptAccount);const selected=models.find(m=>m.id===profile.model);if(!selected)throw fail('此账号的模型列表已变化，请在 ChatGPT 登录设置中刷新模型');
    const a=await this.credentials(profile.chatgptAccount);if(callbacks.signal?.aborted)throw abortError();
    const p={model:profile.model,url:RESOURCE+'/responses',fullUrl:true,protocol:'openai-responses',authType:'chatgpt',...('reasoningEfforts' in selected?{reasoningEfforts:selected.reasoningEfforts,defaultReasoningEffort:selected.defaultReasoningEffort}:{}),reasoningEffort:profile.reasoningEffort};
    if(profile.reasoningEffort!=null&&!Client.effortLevels(p).length)throw fail('该模型未提供可用的思考档位，请刷新模型列表');
    p.reasoningEffort=Client.effortValue(p);p.codeFiles=codeFiles;p.documentEdit=profile.documentEdit===true;p.webSearch=profile.webSearch===true;p.shellEnabled=profile.shellEnabled===true;p.skillsEnabled=profile.skillsEnabled===true;p.pluginsEnabled=Array.isArray(profile.pluginsEnabled)?profile.pluginsEnabled.filter(id=>/^(?:github|google-drive|data|plugin-creator|local:[a-z0-9][a-z0-9-]{0,63})$/.test(id)):[];p.skillScripts=profile.skillScripts===true;p.project=profile.project?.trusted?{trusted:true}:null;
    return this.client.request(p,a.access_token,messages,callbacks);
  }
}
module.exports={ChatGPTService,requestJSON,protect,publicError,CLIENT_VERSION};
