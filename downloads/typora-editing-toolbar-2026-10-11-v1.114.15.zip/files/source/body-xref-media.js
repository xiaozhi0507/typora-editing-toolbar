// Figure/table fragments share the existing inert Markdown preview renderer.
class EditingToolbarXrefMedia {
 constructor(owner){this.owner=owner;this.path=owner.path;this.url=reqnode('url');}
 prepare(source) {
  // Typora's centered HTML image wrappers are not Markdown image syntax.
  // Parse only an inert individual IMG tag; never attach arbitrary index HTML.
  return source.replace(/<img\b[^>]*>/gi,tag=>{
   const template=document.createElement('template');template.innerHTML=tag;
   const img=template.content.querySelector('img'),src=img?.getAttribute('src')||'';
   if(!src||/[<>\r\n]/.test(src))return '';
   return '!['+(img.getAttribute('alt')||'图片').replace(/[[\]\\]/g,'\\$&')+'](<'+src+'>)';
  });
 }
 key(source) {
  return this.owner.normalize(source.replace(/<[^>]*>/g,'').replace(/!\[([^\]]*)\]\([^)]*\)/g,'')
   .replace(/\[([^\]]+)\]\([^)]*\)/g,'$1'));
 }
 record(target) {
  if(!['figure','table'].includes(target?.kind)||!this.owner.validId(target.id)||
     !(target.kind==='figure'?/^fig-/:/^(?:tab|table)-/).test(target.id)||
     typeof target.content!=='string'||!target.content.trim()||target.content.length>150000)return null;
  const content=this.prepare(target.content),label=target.kind==='figure'?/^(?:图|Fig(?:ure)?\.?)\s*(?:[A-Z][.．\s-]*)?\d/i:/^(?:表|Table)\s*(?:[A-Z][.．\s-]*)?\d/i;
  const caption=content.split(/\n\s*\n/).find(p=>label.test(p.replace(/<[^>]*>/g,'').replace(/[*_]/g,'').trim()))||'';
  return {id:target.id,kind:target.kind,content,key:this.key(caption),urls:[],centerCaption:/<span\b[^>]*style=["'][^"']*text-align\s*:\s*center/i.test(caption),threeLine:target.kind==='table'&&target.table_style==='three-line'};
 }
 imageURL(src,file) {
  if(typeof src!=='string'||src.length>4096||/[<>:"\u0000-\u001f]/.test(src)||/^(?:[/\\]|[a-z]+:)/i.test(src))return '';
  try{
   src=decodeURIComponent(src);if(/[<>:"\u0000-\u001f]/.test(src))return '';
   const root=this.path.dirname(file),absolute=this.path.resolve(root,src),relative=this.path.relative(root,absolute);
   if(!relative||relative==='..'||relative.startsWith('..'+this.path.sep)||this.path.isAbsolute(relative)||!/\.(?:png|jpe?g|gif|webp|bmp|svg|avif)$/i.test(absolute))return '';
   return this.url.pathToFileURL(absolute).href;
  }catch{return '';}
 }
 locate(record) {
  if(!record.key)return null;
  const candidates=[...this.owner.write.querySelectorAll(this.owner.context?'p,h1,h2,h3,h4,h5,h6':'p[cid],h1[cid],h2[cid],h3[cid],h4[cid],h5[cid],h6[cid]')]
   .filter(el=>!el.closest('table,.md-fences,.md-toc'));
  const matches=candidates.filter(el=>{
   const raw=this.owner.context?null:File.editor.getNode?.(el.getAttribute('cid'))?.get('text');
   const key=this.key(typeof raw==='string'?raw:el.rawText?.(true)||el.textContent);
   return key===record.key||(record.key.length>=12&&key.startsWith(record.key));
  });
  if(matches.length!==1)return null;
  const caption=matches[0];
  if(record.kind==='figure'){
   const before=caption.previousElementSibling;
   if(before?.querySelector('img,.md-image')&&!before.matches('h1,h2,h3,h4,h5,h6'))return before;
  }
  return caption;
 }
 renderTable(host,source,renderer,options) {
  const doc=host.ownerDocument,template=doc.createElement('template');template.innerHTML=source;
  const original=template.content.querySelector('table');if(!original||original.querySelector('table'))return false;
  // Rebuild only table structure. Never attach HTML or attributes from the index.
  const inline=node=>{
   if(node.nodeType===3)return node.nodeValue;if(node.nodeType!==1)return '';
   if(node.matches('script,style,iframe,object,embed,link,meta,form,input,button,svg,math'))return '';
   const inner=()=>[...node.childNodes].map(inline).join(''),tag=node.localName;
   if(tag==='br')return '  \n';
   if(['b','strong'].includes(tag))return '**'+inner()+'**';
   if(['i','em'].includes(tag))return '*'+inner()+'*';
   if(['sub','sup'].includes(tag))return '<'+tag+'>'+inner()+'</'+tag+'>';
   if(tag==='a'){const href=this.owner.safeURL(node.getAttribute('href'));return href?'['+inner()+'](<'+href+'>)':inner();}
   return inner();
  };
  const table=doc.createElement('table');
  const row=sourceRow=>{const tr=doc.createElement('tr');for(const sourceCell of sourceRow.cells){const cell=doc.createElement(sourceCell.localName);for(const key of ['colSpan','rowSpan'])cell[key]=Math.max(1,Math.min(100,sourceCell[key]||1));if(['row','col','rowgroup','colgroup'].includes(sourceCell.scope))cell.scope=sourceCell.scope;renderer.renderPreview(cell,inline(sourceCell),options);tr.append(cell);}return tr;};
  for(const child of original.children){if(child.localName==='tr')table.append(row(child));else if(['thead','tbody','tfoot'].includes(child.localName)){const section=doc.createElement(child.localName);for(const r of child.rows)section.append(row(r));table.append(section);}}
  host.append(table);return true;
 }
 renderContent(host,content,renderer,options) {
  const fragments=[...content.matchAll(/^<table\b[^>]*>[\s\S]*?<\/table>/gm)];
  if(!fragments.length){renderer.renderPreview(host,content,options);return;}
  host.replaceChildren();let offset=0;
  const paragraph=text=>{if(!text.trim())return;const part=host.ownerDocument.createElement('div');renderer.renderPreview(part,text,options);host.append(part);};
  for(const fragment of fragments){paragraph(content.slice(offset,fragment.index));if(!this.renderTable(host,fragment[0],renderer,options))paragraph(fragment[0]);offset=fragment.index+fragment[0].length;}
  paragraph(content.slice(offset));
 }
 render(host,record,isCurrent) {
  const m=this.owner.toolbar.annotations;
  if(!m?.frame)return false;
  const renderer=m._ensureRenderer();if(!renderer?.renderPreview)return false;
  const file=this.owner.file,images=[];
  this.renderContent(host,record.content,renderer,{
   documentHTML:true,contextKey:file,
   imageURL:src=>{const url=this.imageURL(src,file);if(url)images.push(url);return url;},
   renderMath:(tex,display)=>m._renderMath(tex,display),
   openLink:url=>{const safe=this.owner.safeURL(url);if(safe)File.editor.tryOpenUrl(safe);},
   isCurrent
  });
  for(const img of host.querySelectorAll('img')){
   img.loading='eager';img.decoding='async';
   img.addEventListener('error',()=>{if(isCurrent()){const missing=document.createElement('p');missing.className='et-xref-missing';missing.textContent='图片暂时无法读取：'+(img.alt||'图片');img.replaceWith(missing);this.owner.place();}});
  }
  // Internal references inside a fragment stay local and never open another file.
  // The safe renderer omits href for these, so only DOI/publisher links are active.
  if(record.kind==='figure'&&!images.length)return false;
  if(record.kind==='table'&&!host.querySelector('table,img'))return false;
  if(record.centerCaption)for(const p of host.querySelectorAll('p'))if(this.key(p.textContent)===record.key){p.style.textAlign='center';p.style.textIndent='0';}
  if(record.kind==='table'){const caption=this.locate(record),table=caption?.nextElementSibling?.querySelector('table.md-table'),columns=this.owner.toolbar.tableColumns;const three=table&&columns?columns.isThreeLine(table):(record.threeLine||this.owner.tableStyle==='three-line');for(const t of host.querySelectorAll('table'))t.classList.toggle('et-table-three-line',!!three);}
  return true;
 }
}

