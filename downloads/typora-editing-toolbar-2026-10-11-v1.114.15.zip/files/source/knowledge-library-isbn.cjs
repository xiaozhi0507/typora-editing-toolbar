'use strict';
// Independent metadata client. Source contracts: Zotero lookup.js, translators_CN/CCPINFO.js,
// and https://openlibrary.org/dev/docs/api/books. No library writes or attachments here.
class KnowledgeLibraryISBN {
  constructor({ requireNode = require, parseHTML, request, interval = 1000 } = {}) {
    this.require = requireNode; this.parseHTML = parseHTML; this.transport = request;
    this.interval = interval; this.nextRequest = 0; this.queue = Promise.resolve(); this.jobs = new Map(); this.cache = new Map();
  }
  static normalize(value) {
    let s = String(value || '').trim().replace(/^ISBN(?:-1[03])?\s*:?\s*/i, '').replace(/[\s\-‐‑–—]/g, '').toUpperCase();
    if (/^\d{9}[\dX]$/.test(s)) {
      if ([...s].reduce((n,c,i)=>n+(c==='X'?10:Number(c))*(10-i),0)%11) return '';
      s='978'+s.slice(0,9); s+=String((10-[...s].reduce((n,c,i)=>n+Number(c)*(i%2?3:1),0)%10)%10);
    }
    return /^97[89]\d{10}$/.test(s)&&[...s].reduce((n,c,i)=>n+Number(c)*(i%2?3:1),0)%10===0?s:'';
  }
  lookup(value) {
    const isbn=KnowledgeLibraryISBN.normalize(value); if(!isbn)return Promise.reject(Error('ISBN 格式或校验位不正确，请核对书号。'));
    const cached=this.cache.get(isbn);if(cached&&Date.now()-cached.time<900000)return Promise.resolve(JSON.parse(JSON.stringify(cached.result)));
    if(this.jobs.has(isbn))return this.jobs.get(isbn);
    const job=this.queue.catch(()=>{}).then(()=>this.find(isbn)).then(result=>{this.cache.set(isbn,{time:Date.now(),result});return JSON.parse(JSON.stringify(result));}).finally(()=>this.jobs.delete(isbn));
    this.jobs.set(isbn,job);this.queue=job;return job;
  }
  async request(url, body) {
    const parsed=new URL(url);
    if(parsed.protocol!=='https:'||!['book.cppinfo.cn','openlibrary.org'].includes(parsed.hostname))throw Error('不支持的书目来源');
    const wait=this.nextRequest-Date.now();if(wait>0)await new Promise(r=>setTimeout(r,wait));
    try { if(this.transport)return await this.transport(url,body);
      return await new Promise((resolve,reject)=>{
        const headers={'User-Agent':'Typora-Knowledge-Library/1.14 (ISBN metadata)','Accept':'text/html, application/json'};
        if(body!==undefined){headers['Content-Type']='application/x-www-form-urlencoded';headers['Referer']='https://book.cppinfo.cn/So/Home/QHSearch';}
        const req=this.require('https').request(parsed,{method:body===undefined?'GET':'POST',headers},res=>{
          if(res.statusCode!==200){res.resume();reject(Error('书目来源 HTTP '+res.statusCode+(res.statusCode===429?'，请稍后重试':'')));return;}
          const chunks=[];let bytes=0;
          res.on('data',chunk=>{bytes+=chunk.length;if(bytes>2*1024*1024){req.destroy(Error('书目响应过大'));return;}chunks.push(chunk);});
          res.on('error',reject);res.on('end',()=>resolve(this.require('buffer').Buffer.concat(chunks).toString('utf8')));
        });
        const timer=setTimeout(()=>req.destroy(Error('书目查询超时，请稍后重试')),15000);
        req.on('close',()=>clearTimeout(timer));req.on('error',reject);req.end(body);
      });
    } finally {this.nextRequest=Date.now()+this.interval;}
  }
  cppFields(html,url,isbn) {
    const doc=this.parseHTML(html),text=e=>(e?.textContent||'').replace(/\s+/g,' ').trim(),data={};
    for(const row of doc.querySelectorAll('.book_intro .book_con > .fl, .book_intro .book_con > .fr')){
      const label=text(row.querySelector('.fl:first-child')).replace(/[：:]$/,'');data[label]=text(row.querySelector('.val_txt'));
    }
    if(KnowledgeLibraryISBN.normalize(data.ISBN)!==isbn)return null;
    const title=text(doc.querySelector('.book_intro > h2 > span'));if(!title)return null;
    const names=(label)=>String(data[label]||'').replace(/[等主编原著译]+$/,'').split(/[;；、]/).map(s=>s.trim()).filter(s=>s&&s!=='暂无').join('；');
    const date=(data['出版时间']||'').replace(/年|月/g,'-').replace(/日/g,'').replace(/-$/,'');
    return {title,author:names('著者'),editor:names('编者')||names('编辑'),translator:names('译者'),publisher:data['出版社']||'',date,isbn,
      url,libraryCatalog:'国家出版发行信息公共服务平台',summary:text(doc.querySelector('.field_1 > p')),
      extra:[data['中图分类']&&'CLC: '+data['中图分类'],data['定价']&&'price: '+data['定价']].filter(Boolean).join('\n')};
  }
  async cppinfo(isbn) {
    const params=new URLSearchParams({key:'',author:'',keyword:'',isbn,sm:'',publishedClassification:'',offset:'1',sort:'',order:'',ids:'',minprice:'',maxprice:'',languages:'',cip:'',hasEbook:'false',pubyear:'',authorsure:'',publishersure:'',cipsearch:''});
    const search=this.parseHTML(await this.request('https://book.cppinfo.cn/So/Search/Index',params.toString()));
    const urls=[...new Set([...search.querySelectorAll('.p-text a[href]')].map(a=>new URL(a.getAttribute('href'),'https://book.cppinfo.cn').href))].filter(url=>/^https:\/\/book\.cppinfo\.cn\/Encyclopedias\/home\/index\?id=\d+$/i.test(url));
    // Verify the edition's ISBN, never adopt the first loosely matched title.
    for(const url of urls.slice(0,3)){
      const fields=this.cppFields(await this.request(url),url,isbn);if(!fields)continue;
      try{const lang=await this.request('https://book.cppinfo.cn/So/Search/LangSearch',new URLSearchParams({key:isbn,offset:'1',hasEbook:'false'}).toString());const flag=lang.match(/(?:language[s]?|lang)=([^&"\s]+)/i)?.[1];const map={chi:'zh-CN',eng:'en-US',ger:'de-DE',fre:'fr-FR',jpn:'ja-JP'};if(map[flag])fields.language=map[flag];}catch(_){}
      return {fields,source:'国家出版发行信息公共服务平台',url};
    }
    return null;
  }
  async openLibrary(isbn) {
    const key='ISBN:'+isbn,raw=JSON.parse(await this.request('https://openlibrary.org/api/books?bibkeys='+encodeURIComponent(key)+'&jscmd=data&format=json')),book=raw[key];
    if(!book?.title)return null;
    if(![...(book.identifiers?.isbn_13||[]),...(book.identifiers?.isbn_10||[])].some(v=>KnowledgeLibraryISBN.normalize(v)===isbn))return null;
    const fields={title:book.title,author:(book.authors||[]).map(a=>a.name).filter(Boolean).join('；'),publisher:(book.publishers||[]).map(p=>p.name).join('；'),date:book.publish_date||'',numPages:String(book.number_of_pages||''),place:(book.publish_places||[]).map(p=>p.name).join('；'),isbn,url:book.url||'',libraryCatalog:'Open Library'};
    return {fields,source:'Open Library',url:book.url||''};
  }
  async find(isbn) {
    const errors=[];
    if(isbn.startsWith('9787')){try{const result=await this.cppinfo(isbn);if(result)return result;}catch(e){errors.push(e.message);}}
    try{const result=await this.openLibrary(isbn);if(result)return result;}catch(e){errors.push(e.message);}
    throw Error(errors.length?'未能完成 ISBN 查询：'+errors.join('；'):'未找到与此 ISBN 完全匹配的书目，可继续手动填写。');
  }
}
module.exports=KnowledgeLibraryISBN;
