const fs=require('node:fs'),path=require('node:path');
module.exports=code=>{
  const start=code.indexOf('    _createTopChrome() {'),end=code.indexOf('    _alertHeaderFor(node)',start);
  if(start<0||end<0)throw Error('Missing top toolbar placement methods');
  code=code.slice(0,start)+`    _createTopChrome() {
        this.topMotion=new EditingToolbarTopMotion(this);
    }

    _applyTopPlacement() {
        this.topMotion?.apply();
    }

`+code.slice(end);
  const pos=code.lastIndexOf('(function () {');if(pos<0)throw Error('Missing toolbar boot');
  return code.slice(0,pos)+fs.readFileSync(path.join(__dirname,'top-toolbar-motion.js'),'utf8')+'\n'+code.slice(pos);
};
