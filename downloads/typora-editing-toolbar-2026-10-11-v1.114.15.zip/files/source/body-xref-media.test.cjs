const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const {JSDOM}=require('jsdom'),MarkdownIt=require('markdown-it');
const C=vm.runInNewContext(fs.readFileSync(path.join(__dirname,'body-xref-media.js'),'utf8')+'\nEditingToolbarXrefMedia');
function fixture(){const dom=new JSDOM('<div id="host"></div>'),host=dom.window.document.querySelector('#host'),calls=[],md=new MarkdownIt({html:false}),m=Object.assign(Object.create(C.prototype),{owner:{safeURL:u=>/^https:\/\//.test(u||'')?u:null}});const renderer={renderPreview:(h,text,options)=>{calls.push({text,options});h.innerHTML=md.render(text);}};return{dom,host,calls,m,renderer};}
test('HTML table preview preserves sections and merges and sends cell math through the safe renderer',()=>{
 const {dom,host,calls,m,renderer}=fixture(),options={isCurrent:()=>true};
 m.renderContent(host,'Table 1. Values\n\n<table><thead><tr><th colspan="2">Traits</th></tr></thead><tbody><tr><td rowspan="2"><em>leaf</em></td><td>${C}_{w}$</td></tr><tr><td>C<sub>m</sub></td></tr></tbody></table>\n\nTable notes.',renderer,options);
 const t=host.querySelector('table');assert.equal(t.rows.length,3);assert.equal(t.tHead.rows[0].cells[0].colSpan,2);assert.equal(t.tBodies[0].rows[0].cells[0].rowSpan,2);assert.match(host.textContent,/Table 1.*Traits.*leaf.*Table notes/s);
 assert.ok(calls.some(c=>c.text==='${C}_{w}$'&&c.options===options));assert.ok(calls.some(c=>c.text==='C<sub>m</sub>'));assert.ok(t.querySelector('em'));dom.window.close();
});
test('index table preview never attaches scripts, events, style or arbitrary link attributes',()=>{
 const {dom,host,m,renderer}=fixture();m.renderContent(host,'<table onclick="bad()" style="position:fixed"><tbody><tr><td colspan="9000" onmouseover="bad()"><script>bad()</script><img src="https://bad.example/a" onerror="bad()"><iframe src="https://bad.example"></iframe><a href="javascript:bad()">label</a><strong>safe</strong></td></tr></tbody></table>',renderer,{});
 assert.equal(host.querySelector('td').colSpan,100);assert.equal(host.querySelectorAll('script,img,iframe,[onclick],[onmouseover],[style],[onerror],a').length,0);assert.equal(host.querySelector('strong').textContent,'safe');assert.doesNotMatch(host.textContent,/bad\(\)/);dom.window.close();
});
test('plain Markdown keeps the existing renderer and nested HTML tables do not attach',()=>{
 const {dom,host,m,renderer,calls}=fixture();m.renderContent(host,'Ordinary **caption**.',renderer,{});assert.equal(calls.length,1);assert.equal(host.querySelector('strong').textContent,'caption');assert.equal(m.renderTable(host,'<table><tr><td><table><tr><td>nested</td></tr></table></td></tr></table>',renderer,{}),false);assert.equal(host.querySelector('table'),null);dom.window.close();
});
