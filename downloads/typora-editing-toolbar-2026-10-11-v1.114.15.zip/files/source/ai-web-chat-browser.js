class EditingToolbarWebChatBrowser {
  constructor(ai){this.ai=ai;this.snapshot=null;this.capabilities={modes:[],versions:[]};this.status='尚未连接';this.switching=false;this.memberships=new Map();this.scopeGeneration=0;window.addEventListener('unload',()=>this.destroy());}
  notify(){if(this.message)this.message.textContent=this.status;this.ai.webChat?.refreshUI();}
  challengeNotice(){return 'Cloudflare 网页验证尚未通过。若持续停留在此页，内嵌浏览器可能不兼容，请在 Chrome/Edge 中打开 GPT。浏览器登录和聊天不会自动同步回助手。';}
  block(kind){this.invalidateScope();this.blocked=kind;this.snapshot=null;this.capabilities={modes:[],versions:[]};this.status=kind==='challenge'?this.challengeNotice():kind==='google'?this.loginNotice():'请在 GPT 网页登录后重试';this.updateHelp();this.notify();}
  updateHelp(){if(this.loginHelp)this.loginHelp.hidden=!['challenge','google'].includes(this.blocked);}
  acceptReadiness(s){
    if(s.challenge)this.block('challenge');else if(s.login)this.block('login');
    else if(s.ready&&this.blocked){this.blocked='';this.status='网页已就绪，正在读取模型选项…';this.updateHelp();this.notify();}
    return s;
  }
  cancelInspection(){clearTimeout(this.inspectTimer);this.inspectEpoch=(this.inspectEpoch||0)+1;}
  inspectReadiness(){
    this.cancelInspection();const epoch=this.inspectEpoch;
    // Bounded readiness checks; discover public model controls only when idle.
    // Discovery restores the initial selection and never submits a message.
    const probe=async left=>{
      if(epoch!==this.inspectEpoch||!this.ready)return;
      if(this.syncLoginNotice())return;
      try{if(!this.ai.busy&&!this.switching&&!this.refreshJob){const s=await this.call('snapshot');if(epoch!==this.inspectEpoch)return;this.acceptReadiness(s);if(s.ready&&!s.busy&&!s.login&&!s.challenge)await this.options();}}catch{}
      if(left>0&&epoch===this.inspectEpoch)this.inspectTimer=setTimeout(()=>void probe(left-1),2000);
    };void probe(2);
  }
  loginNotice(){
    let u;try{u=new URL(this.view?.getURL());}catch{return '';}
    if(u.hostname==='accounts.google.com'&&/\/(?:rejected|denied)(?:\/|$)/.test(u.pathname))return 'Google 不允许在此内嵌窗口登录。请在浏览器中打开 GPT；浏览器登录状态不会自动同步到此窗口。';
    return '';
  }
  syncLoginNotice(){const note=this.loginNotice();if(note)this.block('google');else if(this.blocked==='google'){this.blocked='';this.updateHelp();}return note;}
  async openInBrowser(){try{await reqnode('electron').shell.openExternal('https://chatgpt.com/');}catch(e){this.fail(e);}}
  allowed(url){try{const u=new URL(url);return u.protocol==='https:'&&['chatgpt.com','auth.openai.com','auth0.openai.com','accounts.google.com','login.microsoftonline.com','appleid.apple.com'].includes(u.hostname);}catch{return false;}}
  mount(){
    if(this.view)return;
    const a=this.ai,panel=this.panel=a.node('section','et-ai-web-chat-browser is-background'),head=a.node('div','et-ai-web-chat-browser-head'),title=a.node('strong','','GPT 网页'),view=this.view=document.createElement('webview');
    panel.setAttribute('aria-label','GPT 网页');
    const controls=a.node('div','et-ai-web-chat-browser-actions');
    for(const [name,run] of [['刷新网页',()=>{if(this.ai.busy)return;view.reload();}],['同步状态',()=>this.refresh().catch(e=>this.fail(e))],['收起网页',()=>this.hide()]]){const b=a.node('button','',name);b.type='button';b.onclick=run;controls.append(b);}
    head.append(title,controls);this.message=a.node('div','et-ai-web-chat-browser-status','请在网页中登录。完成后点击“同步状态”。');this.message.setAttribute('role','status');
    const help=this.loginHelp=a.node('div','et-ai-web-chat-login-help');help.hidden=true;
    for(const [name,run]of [['在浏览器打开 GPT',()=>this.openInBrowser()],['返回 GPT 网页',()=>{this.blocked='';view.src='https://chatgpt.com/';this.status='请在网页中登录。完成后点击“同步状态”。';help.hidden=true;this.notify();}]]){const b=a.node('button','',name);b.type='button';b.onclick=run;help.append(b);}
    panel.append(head,view,this.message,help);
    view.setAttribute('partition',EditingToolbarAIWebSession.partition);view.setAttribute('webpreferences','contextIsolation=yes,sandbox=yes,nodeIntegration=no,nodeIntegrationInSubFrames=no,backgroundThrottling=no');
    for(const type of ['will-navigate','will-redirect'])view.addEventListener(type,e=>{if(!this.allowed(e.url)){e.preventDefault();this.status='已阻止离开登录或聊天页面';this.notify();}});
    view.addEventListener('new-window',e=>{e.preventDefault();if(this.allowed(e.url)&&!a.busy)view.src=e.url;});
    view.addEventListener('did-start-navigation',e=>{if(e.isMainFrame&&!e.isInPlace){this.memberships.clear();this.cancelInspection();this.ready=false;this.snapshot=null;}});
    view.addEventListener('dom-ready',()=>{this.ready=true;view.setZoomFactor?.(1);this.inspectReadiness();this.notify();});
    // A download can abort navigation without replacing the existing document.
    // Recover the host readiness flag; ensure() still validates the actual composer.
    view.addEventListener('did-stop-loading',()=>{if(!this.ready&&!view.isLoading()){this.ready=true;this.inspectReadiness();this.notify();}});
    view.addEventListener('did-navigate',()=>this.syncLoginNotice());view.addEventListener('did-navigate-in-page',()=>this.syncLoginNotice());
    view.addEventListener('did-fail-load',e=>{if(e.isMainFrame!==false&&e.errorCode!==-3){this.status='网页加载失败，请打开网页重试';this.notify();}});
    view.addEventListener('render-process-gone',()=>{this.ready=false;this.snapshot=null;this.capabilities={modes:[],versions:[]};this.status='网页进程已退出，请刷新网页';this.notify();});
    panel.addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Escape')this.hide();});for(const event of ['pointerdown','mousedown','click','dblclick'])panel.addEventListener(event,e=>e.stopPropagation());
    document.body.append(panel);view.src='https://chatgpt.com/';
  }
  show(){this.ai.manualUsageCache?.delete(EditingToolbarAIWebSession.usageKey);this.mount();this.panel.classList.remove('is-background');this.panel.setAttribute('role','dialog');this.panel.removeAttribute('aria-hidden');this.message.textContent=this.status;this.view.focus();this.inspectReadiness();}
  hide(){if(!this.panel)return;this.cancelInspection();this.panel.classList.add('is-background');this.panel.removeAttribute('role');this.panel.setAttribute('aria-hidden','true');}
  destroy(){this.cancelInspection();this.invalidateScope();this.panel?.remove();this.panel=this.view=this.loginHelp=null;}
  invalidateScope({forget=true}={}){if(forget){this.principal='';this.identityHint='';}this.scopeRead=(this.scopeRead||0)+1;this.scopeGeneration++;this.scopeCache=null;this.scopeJob=null;this.scopeRetryAt=0;this.memberships.clear();this.ai.webChat?.projects?.invalidate?.();}
  async events(action,args={}){
    if(typeof ETAIWebEvents!=='function'||!this.view||!this.ready)return null;
    if(new URL(this.view.getURL()).origin!=='https://chatgpt.com')return null;
    let timer;try{return await Promise.race([this.view.executeJavaScript('('+ETAIWebEvents.toString()+')('+JSON.stringify(action)+','+JSON.stringify(args)+',('+ETAIWebStream.toString()+'))'),new Promise((_,reject)=>timer=setTimeout(()=>reject(Error('网页事件读取超时')),action==='scope'?1100:action==='scope-hint'?300:4000))]);}finally{clearTimeout(timer);}
  }
  async scope({force=false}={}){
    let observed;try{observed=await this.events('scope-hint');}catch{}
    const stamp=typeof observed==='string'?observed:observed?.stamp||'',hint=stamp?String(observed?.documentId||'')+'|'+stamp:'';
    if(stamp&&this.identityHint&&stamp!==this.identityHint)this.invalidateScope({forget:false});
    if(stamp)this.identityHint=stamp;
    const cache=hint&&this.scopeCache?.hint===hint?this.scopeCache:null,age=cache?Date.now()-cache.at:Infinity;
    if(!force&&age<15000)return cache.key;
    if(!force&&this.scopeRetryHint===hint&&Date.now()<(this.scopeRetryAt||0))return age<60000?cache.key:'';
    const refresh=this.refreshScope(hint);
    // The cookie stamp is only an invalidation hint, never account identity.
    // Revalidate in the background within a bounded last-known-good window.
    if(!force&&age<60000){void refresh;return cache.key;}return refresh;
  }
  async refreshScope(hint){
    const epoch=this.inspectEpoch,jobKey=String(epoch)+'|'+hint;
    if(this.scopeJob?.key===jobKey)return this.scopeJob.promise;
    const read=this.scopeRead=(this.scopeRead||0)+1,job={key:jobKey};
    job.promise=(async()=>{
      let result;try{result=await this.events('scope');}catch{}
      if(epoch!==this.inspectEpoch||read!==this.scopeRead)return '';
      const key=typeof result==='string'?result:result?.status==='verified'?result.key:'';
      if(!key){this.scopeStatus='unavailable';this.scopeRetryHint=hint;this.scopeRetryAt=Date.now()+5000;return '';}
      if(this.principal&&this.principal!==key){this.principal=key;this.invalidateScope({forget:false});}
      this.principal=key;this.scopeStatus='verified';this.scopeRetryAt=0;this.scopeCache={key,hint,at:Date.now()};return key;
    })();this.scopeJob=job;try{return await job.promise;}finally{if(this.scopeJob===job)this.scopeJob=null;}
  }
  differentScope(left,right){return !!left&&!!right&&left!==right;}
  async armEvents(text,base,observeOnly=false){
    const id='reply-'+Date.now()+'-'+Math.random().toString(36).slice(2);
    try{const scope=await this.scope(),state=await this.events('arm',{id,text,conversationId:this.chatIdentity(base.url),observeOnly});return state?{id,revision:0,scope}:null;}catch{return null;}
  }
  async waitEvents(watch,signal,ms){
    if(signal?.aborted)throw Object.assign(Error('已停止处理'),{name:'AbortError'});
    let abort;try{return await Promise.race([this.events('wait',{id:watch.id,revision:watch.revision,ms}),new Promise((_,reject)=>{abort=()=>reject(Object.assign(Error('已停止处理'),{name:'AbortError'}));signal?.addEventListener('abort',abort,{once:true});})]);}finally{signal?.removeEventListener('abort',abort);}
  }
  markTiming(name,onTiming){this.timings ||= {startedAt:Date.now()};if(this.timings[name]===undefined)this.timings[name]=Date.now()-this.timings.startedAt;onTiming?.({...this.timings});}
  fail(e){if(/Cloudflare 网页验证/.test(e.message)){this.block('challenge');e.message=this.status;}else{this.status=e.message;this.notify();}return e;}
  async wait(ms,signal){if(signal?.aborted)throw Object.assign(Error('已停止处理'),{name:'AbortError'});await new Promise((resolve,reject)=>{const end=()=>{clearTimeout(timer);signal?.removeEventListener('abort',abort);resolve();},abort=()=>{clearTimeout(timer);signal?.removeEventListener('abort',abort);reject(Object.assign(Error('已停止处理'),{name:'AbortError'}));},timer=setTimeout(end,ms);signal?.addEventListener('abort',abort,{once:true});});}
  async call(action,args={}){
    if(!this.view||!this.ready)throw Error('GPT 网页尚未就绪');if(new URL(this.view.getURL()).origin!=='https://chatgpt.com')throw Error(this.syncLoginNotice()||'请先完成 GPT 网页登录');
    const epoch=this.inspectEpoch;let timer;try{const result=await Promise.race([this.view.executeJavaScript('('+ETAIWebChatPage.toString()+')('+JSON.stringify(action)+','+JSON.stringify(args)+')',true),new Promise((_,reject)=>timer=setTimeout(()=>reject(Error('网页操作超时，请打开网页检查')),7000))]);if(action==='snapshot'&&epoch===this.inspectEpoch)this.acceptReadiness(result);return result;}catch(e){e.message=String(e.message||e).replace(/^Error invoking remote method '[^']+':\s*/,'').replace(/^Error:\s*/,'');if(/Cloudflare 网页验证/.test(e.message))this.fail(e);throw e;}finally{clearTimeout(timer);}
  }

  async downloadTo(binding,name,folder){
    const io=reqnode('fs').promises,path=reqnode('path'),Buffer=reqnode('buffer').Buffer,id=reqnode('crypto').randomUUID(),file=path.join(folder,'download-'+id+'.zip');
    if(!this.chatURL(binding.url))throw Error('原聊天地址无效');
    await this.conversation(binding.url);const deadline=Date.now()+20000;let started=false;
    while(Date.now()<deadline){try{await this.call('file-download-start',{id,name});started=true;break;}catch(e){if(!/未找到唯一/.test(e.message))throw e;await this.wait(300);}}
    if(!started)throw Error('未读取到此任务的译稿下载链接，请查看原聊天');
    try{
      await io.mkdir(folder,{recursive:true});const end=Date.now()+90000;
      while(Date.now()<end){
        if(this.view.getURL().split('?')[0]!==binding.url.split('?')[0])throw Error('网页聊天已切换，下载停止');
        const state=await this.call('file-download-state',{id});if(state.state==='error')throw Error(state.error||'文件下载失败');
        if(state.state==='bytes'){
          if(!Number.isInteger(state.size)||state.size<1||state.size>60*1024*1024)throw Error('下载文件大小无效');
          const handle=await io.open(file,'wx');try{let offset=0;while(offset<state.size){const part=await this.call('file-download-state',{id,offset}),bytes=Buffer.from(part.base64||'','base64');if(!bytes.length||bytes.length!==part.length||part.size!==state.size||offset+bytes.length>state.size)throw Error('文件下载不完整');await handle.writeFile(bytes);offset+=bytes.length;}}finally{await handle.close();}return file;
        }
        if(state.state==='url'){
          const u=new URL(state.url);if(u.protocol!=='https:'||u.username||u.password||!/(^|\.)(oaiusercontent\.com|usercontent\.openai\.com|blob\.core\.windows\.net)$/.test(u.hostname))throw Error('此文件需要在网页中下载，请使用原聊天下载链接');
          let timer;const result=await Promise.race([JSBridge.invoke('app.download',u.href,folder,path.basename(file)),new Promise((_,reject)=>timer=setTimeout(()=>reject(Error('文件下载超时，请重试')),90000))]).finally(()=>clearTimeout(timer));if(result?.state!=='completed'||path.resolve(result.path||'')!==path.resolve(file))throw Error('文件未下载完成，请在网页重试');return file;
        }
        await this.wait(300);
      }throw Error('网页文件下载等待超时，请重试');
    }finally{await this.call('file-download-end',{id}).catch(()=>{});}
  }
  async projectCall(action,args={}){
    await this.call('snapshot');if(this.blocked)throw Error(this.status);
    const timeout=action==='projects'&&args.expand?10000:5000;
    let timer;try{return await Promise.race([this.view.executeJavaScript('('+ETAIWebProjectPage.toString()+')('+JSON.stringify(action)+','+JSON.stringify(args)+')',true),new Promise((_,reject)=>timer=setTimeout(()=>reject(Error('网页项目操作超时，请查看网页')),timeout))]);}catch(e){e.message=String(e.message||e).replace(/^Error invoking remote method '[^']+':\s*/,'').replace(/^Error:\s*/,'');throw e;}finally{clearTimeout(timer);}
  }
  async createProject(name){
    await this.ensure();const before=await this.projectCall('create-project',{name});let submissionError;
    try{await this.projectCall('submit-project',{name});}catch(e){submissionError=e;}
    const deadline=Date.now()+20000;while(Date.now()<deadline){if(this.ready){try{const now=await this.projectCall('projects');if(this.projectURL(now.url)&&now.url!==before.previousURL)return {project:{url:now.url,name}};const matches=now.projects.filter(p=>p.name===name&&!before.previousLinks.includes(p.url));if(matches.length===1)return {project:matches[0]};}catch(e){if(this.blocked)throw e;}}await this.wait(200);}
    throw Error('创建结果尚未确认，请查看网页后刷新列表，避免重复创建'+(submissionError?'：'+submissionError.message:''));
  }
  projectURL(url){return /^https:\/\/chatgpt\.com\/g\/g-p-[\w-]+\/project$/.test(url||'');}
  chatIdentity(url){try{const u=new URL(url);return u.origin==='https://chatgpt.com'&&!u.username&&!u.password?(u.pathname.match(/^\/(?:g\/[\w-]+\/)?c\/([\w-]+)\/?$/)?.[1]||''):'';}catch{return '';}}
  chatURL(url){return !!this.chatIdentity(url);}
  sameTarget(left,right){const id=this.chatIdentity(right);return id?this.chatIdentity(left)===id:String(left||'').split('?')[0].replace(/\/$/,'')===String(right||'').split('?')[0].replace(/\/$/,'');}
  async resolveProject(target,signal){
    if(this.projectURL(target?.url))return target;
    if(!target?.buttonName||target.buttonName!==target.name)throw Error('项目入口无效，请刷新项目列表');
    const before=await this.ensure(signal);
    if(before.busy)throw Error('网页已有回答正在生成，请先处理该对话');
    if(before.draft.trim()||before.composerHasAttachments||before.uploadBusy)throw Error('网页有未发送草稿，请先处理后再切换项目');
    const start=await this.projectCall('projects');
    if(start.projects.filter(p=>!p.url&&p.buttonName===target.buttonName).length>1)throw Error('存在同名项目，无法确认目标，请在网页打开所需项目后重试');
    if(start.current?.name===target.name)return {...target,url:start.current.url};
    await this.projectCall('open-project',{name:target.buttonName,id:target.buttonId});
    const deadline=Date.now()+15000;
    while(Date.now()<deadline){
      await this.wait(150,signal);if(!this.ready)continue;
      const state=await this.projectCall('projects');
      if(this.projectURL(state.url)&&(state.url!==start.url||state.current?.name===target.name))return {...target,url:state.url};
    }
    throw Error('尚未确认进入所选项目，请查看 GPT 网页后重试');
  }
  async navigateTarget(url,signal,{replaceDraft=false}={}){
    let s=await this.ensure(signal);if(s.busy)throw Error('网页已有回答正在生成，请先处理该对话');
    if(!this.sameTarget(s.url,url)){if(replaceDraft)await this.clearComposer(signal,await this.settleConversation(s,signal));else if(s.draft.trim()||s.composerHasAttachments||s.uploadBusy)throw Error('网页有未发送草稿，请先处理后再切换项目');this.ready=false;this.view.src=url;s=await this.ensure(signal);}
    if(!this.sameTarget(s.url,url))throw Error('网页未进入指定位置，已停止操作');return s;
  }
  async projectChats(url,signal,options={}){
    if(!this.projectURL(url))throw Error('项目地址无效，请刷新项目列表');await this.navigateTarget(url,signal,options);
    const expected=this.chatIdentity(options.expectedChat),rows=new Map();let previous='',stable=0,advance=false,pending=null,pages=0;
    // The composer becomes ready before the project list. A missing row during
    // loading is not proof that the selected conversation left this project.
    for(let n=0;n<50;n++){
      if(signal?.aborted)throw Object.assign(Error('已停止处理'),{name:'AbortError'});
      const s=await this.projectCall('chats',{project:url,more:advance,activate:n===0});
      if(advance&&s.advanced){pending=previous;pages++;}advance=false;
      for(const c of s.chats){const id=this.chatIdentity(c.url);if(id)rows.set(id,c);}
      const signature=JSON.stringify(s.chats.map(c=>[this.chatIdentity(c.url),c.name]));
      if(pending!==null&&signature!==pending)pending=null;
      stable=!s.loading&&signature===previous?stable+1:0;previous=signature;
      if(expected&&rows.has(expected))return [...rows.values()];
      if(pending===null&&s.more&&stable>=2&&pages<20)advance=true;
      if(!expected&&!s.loading&&!s.more&&pending===null&&stable>=3&&(s.empty||rows.size||n>=18))return [...rows.values()];
      if(expected&&s.empty&&!s.loading&&stable>=3)break;
      await this.wait(200,signal);
    }
    return [...rows.values()];
  }
  async projectRoute(target,signal,options={}){
    if(!target?.enabled||!this.projectURL(target.project?.url))throw Error('请先选择有效项目');
    const scope=await this.scope();
    if(this.differentScope(target.scope,scope))throw Error('所选项目的网页账号或工作区已变化，请重新选择项目；没有发送消息');
    if(!target.chat){const current=await this.navigateTarget(target.project.url,signal,options);if(scope&&this.differentScope(scope,await this.scope()))throw Error('网页账号或工作区在切换项目时发生变化，未发送');return current;}
    const id=this.chatIdentity(target.chat.url);if(!id)throw Error('聊天地址无效，请重新选择项目对话；没有发送消息');
    const key=scope+'|'+target.project.url+'|'+id,proof=this.memberships.get(key);
    if(scope&&proof&&Date.now()-proof.at<45000){const current=await this.ensure(signal);if(this.sameTarget(current.url,target.chat.url)&&current.ready&&!current.historyLoading&&current.userCount>0){this.checkConversation(current,current);return current;}}
    const chats=await this.projectChats(target.project.url,signal,{...options,expectedChat:target.chat.url}),matched=chats.find(c=>this.chatIdentity(c.url)===id);
    if(!matched)throw Error('暂未在当前项目中确认所选聊天，可能仍在加载或已被移出；请稍后重试或重新选择聊天。没有发送消息');
    // Membership comes from the current project's list. The same chat may be
    // linked as /c/id, /g/g-p-id/c/id or with a human-readable project suffix.
    const current=await this.navigateTarget(matched.url,signal,options);
    if(scope){const after=await this.scope();if(this.differentScope(scope,after))throw Error('网页账号或工作区在切换聊天时发生变化，未发送');if(after)this.memberships.set(key,{at:Date.now()});}return current;
  }
  async ensure(signal,{modelControls=false}={}){
    this.mount();const end=Date.now()+25000;let s;
    while(Date.now()<end){
      if(signal?.aborted)throw Object.assign(Error('已停止处理'),{name:'AbortError'});
      if(this.ready){
        try{s=this.acceptReadiness(await this.call('snapshot'));}
        catch(e){if(!/网页操作超时/.test(e.message))throw e;await this.wait(150,signal);continue;}
        if(s.login||s.challenge)throw Error(this.status);if(s.error)throw Error(s.error);if(s.ready&&(!modelControls||s.modeReady!==false))return s;
      }
      await this.wait(150,signal);
    }
    throw Error(s?.ready&&modelControls?'网页模型菜单仍在加载，请稍后同步状态':'网页输入框尚未就绪，请打开网页检查');
  }
  async setSlider(n){
    let s;try{s=await this.call('slider-focus');}catch{await this.call('open-mode');s=await this.call('slider-focus');}if(!s.slider)throw Error('未找到网页思考滑块');
    if(s.slider.native)return this.call('slider-value',{value:n});
    const from=s.slider.value;if(!Number.isInteger(from)||!Number.isInteger(n)||Math.abs(n-from)>12)throw Error('网页档位结构无法识别');
    for(let i=0;i<Math.abs(n-from);i++){
      const key=n>from?'Right':'Left',before=from+(n>from?i:-i);
      // Dispatch to the public DOM control: hidden webviews do not own native keyboard focus.
      const stepped=await this.call('slider-step',{key:'Arrow'+key});
      if(stepped.slider?.value===before){this.view.sendInputEvent({type:'keyDown',keyCode:key});this.view.sendInputEvent({type:'keyUp',keyCode:key});await this.wait(160);}
    }
    // The public range and announcement can update after the key event.
    // Confirm a settled label before exposing the new setting to the assistant.
    let previous='',stable=0;
    for(let i=0;i<16;i++){const current=await this.call('snapshot'),key=current.slider?.value+'|'+current.mode;
      if(current.slider?.value===n&&current.mode){stable=key===previous?stable+1:1;if(stable>=2)return current;}else stable=0;
      previous=key;await this.wait(100);
    }
    throw Error('网页档位仍在更新，请稍后重试');
  }
  async dismiss(){this.view?.sendInputEvent({type:'keyDown',keyCode:'Escape'});this.view?.sendInputEvent({type:'keyUp',keyCode:'Escape'});for(let i=0;i<10;i++){await this.wait(50);try{if((await this.call('menu-closed')).closed)break;}catch{break;}}}
  async discoverModes(){
    const start=await this.call('open-mode'),modes=[];
    if(start.slider){
      const s=start.slider;if(!Number.isInteger(s.min)||!Number.isInteger(s.max)||s.max-s.min>10||s.max<=s.min)throw Error('网页思考档位范围无法识别');
      try{for(let n=s.min;n<=s.max;n++){const current=await this.setSlider(n);if(!current.slider||current.slider.value!==n||!current.mode)throw Error('无法确认网页档位名称');modes.push({label:current.mode,value:n});}}
      finally{const restored=await this.setSlider(s.value);if(restored.slider?.value!==s.value)throw Error('网页原档位未能恢复，请打开网页确认');}
    }else for(const row of start.options.filter(o=>/^(Instant|Medium|High|Extra High|(?:(?:GPT[- ]?)?\d+(?:\.\d+)?\s*)?Pro|即时|中|高|极高)$/i.test(o.label)))modes.push({...row,value:row.label});
    if(!modes.length||new Set(modes.map(m=>m.label)).size!==modes.length)throw Error('网页未提供可确认的思考档位，请直接查看网页');
    this.capabilities.modes=modes;this.snapshot=await this.call('snapshot');await this.dismiss();
  }
  isVersion(name){return /^(?:Latest|GPT[- ]\d[^\n]*|\d+(?:\.\d+)?(?:[ -](?:Sol|Astra|Luna|Terra))?)$/i.test(name)&&! /^(?:GPT[- ]?)?5\.5(?:$|[ -])/i.test(name);}
  async discoverVersions(){
    this.capabilities.versions=[];if(this.snapshot)this.snapshot.version='';try{const s=await this.versionOptions();this.capabilities.versions=s.options.filter(o=>this.isVersion(o.label));if(!this.capabilities.versions.length)throw Error('网页未提供可用的模型版本，请打开网页确认');if(this.snapshot)this.snapshot.version=this.capabilities.versions.find(o=>o.selected)?.label||'';this.versionsReadAt=Date.now();}finally{await this.dismiss();}
  }
  async versionOptions(signal){
    // Closing or resizing the embedded page remounts the shared model popup.
    // Only re-open/read menus here; never retry a selection or message send.
    const deadline=Date.now()+2500;let failure;
    do{
      try{const s=await this.call('open-version');if(s.options?.some(o=>this.isVersion(o.label)))return s;failure=Error('网页模型版本选项尚未就绪');}
      catch(e){if(!/网页未提供可识别的模型版本菜单/.test(e.message))throw e;failure=e;}
      await this.wait(120,signal);
    }while(Date.now()<deadline);
    throw failure;
  }
  options(){
    if(this.refreshJob)return this.refreshJob;
    if(this.status==='已连接'&&!this.blocked&&this.capabilities.modes.length&&this.capabilities.versions.length){
      // Re-read the real version menu periodically so renamed Latest rows do not stay cached forever.
      this.versionsReadAt ||= Date.now();
      if(!this.ai.busy&&!this.switching&&Date.now()-this.versionsReadAt>60000)return this.refresh();
      // Picker reopening is read-only; keep the guest and confirmed options for this window.
      if(this.ready&&!this.ai.busy&&!this.switching&&Date.now()-(this.lastOptionCheck||0)>10000){
        this.lastOptionCheck=Date.now();void this.call('snapshot').then(s=>{if(s.ready&&!s.login&&!s.challenge&&s.mode){this.snapshot={...this.snapshot,...s,version:s.version||this.snapshot?.version||''};this.ai.webChat.confirm(this.snapshot);}}).catch(()=>{});
      }
      return Promise.resolve(this.snapshot);
    }
    return this.refresh();
  }
  refresh(){if(this.refreshJob)return this.refreshJob;if(this.ai.busy||this.switching)return Promise.resolve(this.snapshot);
    return this.refreshJob=(async()=>{this.status='正在读取网页选项…';this.notify();try{const s=await this.ensure(undefined,{modelControls:true});if(s.busy)throw Error('网页正在生成回答，完成后再同步设置');await this.discoverModes();await this.discoverVersions();this.status='已连接';this.ai.webChat.confirm(this.snapshot);return this.snapshot;}catch(e){this.capabilities={modes:[],versions:[]};throw this.fail(e);}finally{this.refreshJob=null;this.notify();}})();
  }
  async select(kind,choice){
    if(this.ai.busy||this.switching)throw Error('请等待当前任务完成');if(this.refreshJob)await this.refreshJob;if(this.status==='已连接'&&this.snapshot?.[kind]===choice.label){this.notify();return;}this.switching=true;this.status='切换中…';this.notify();
    try{await this.ensure(undefined,{modelControls:true});let result;
      if(kind==='mode'){const s=await this.call('open-mode');result=s.slider?await this.setSlider(choice.value):await this.call('choose-option',{label:choice.label});
        if(!result.slider){await this.call('open-mode');result=await this.call('snapshot');}
        if((result.slider&&result.slider.value!==choice.value)||result.mode!==choice.label)throw Error('网页未确认所选档位，请刷新状态后重试');
      }else{await this.versionOptions();await this.call('choose-option',{label:choice.label});const s=await this.versionOptions();if(!s.options.some(o=>o.label===choice.label&&o.selected))throw Error('网页未确认所选模型版本，请打开网页检查');result={...this.snapshot,version:choice.label};}
      await this.dismiss();this.snapshot={...this.snapshot,...result};
      if(kind==='mode'){this.snapshot.version='';await this.discoverVersions().catch(()=>{});}
      else {await this.discoverModes();this.snapshot.version=choice.label;await this.discoverVersions();}
      this.ai.webChat.confirm(this.snapshot);this.status='已连接';
    }catch(e){this.snapshot=null;throw this.fail(e);}finally{await this.dismiss().catch(()=>{});this.switching=false;this.notify();}
  }
  async clearComposer(signal,base){
    await this.wait(0,signal);
    const s=await this.call('clear-composer',this.conversationGuard(base));
    await this.wait(0,signal);return s;
  }
  conversationGuard(s){return {url:s.url,userCount:s.userCount,lastUserId:s.lastUserId};}
  checkConversation(s,base){
    if(s.login||s.challenge)throw Error(s.challenge?this.challengeNotice():'请在 GPT 网页登录后重试');
    if(s.error)throw Error(s.error);
    if(s.busy||(base.url&&!this.sameTarget(s.url,base.url)))throw Error('网页已切换对话或正在生成回答，未发送');
  }
  async settleConversation(base,signal){
    // The composer is mounted before a saved chat's history. Capture the send
    // baseline only after model verification and history hydration have settled.
    let previous='',stable=0;
    for(let i=0;i<60;i++){
      await this.wait(150,signal);const s=await this.call('snapshot');this.checkConversation(s,base);
      const key=JSON.stringify([s.userCount,s.answerCount,s.lastUserId,s.lastUser,s.answerId,s.answerHTML]);
      stable=s.ready&&!s.historyLoading&&(!this.chatURL(base.url)||s.userCount>0)?(key===previous?stable+1:1):0;
      if(stable>=3)return s;previous=key;
    }
    throw Error('当前聊天记录尚未加载完成，未发送；请稍后重试');
  }
  async conversation(url,signal,{replaceDraft=false,observe=false}={}){
    let s=await this.ensure(signal);if(s.busy&&!(observe&&url&&this.sameTarget(s.url,url)))throw Error('网页已有回答正在生成，请先处理该对话');
    if(url&&!this.chatURL(url))throw Error('保存的网页会话地址无效');
    const changing=!this.sameTarget(s.url,url||'https://chatgpt.com/');
    if(changing){
      if(replaceDraft)s=await this.clearComposer(signal,await this.settleConversation(s,signal));
      else if(s.draft.trim()||s.composerHasAttachments||s.uploadBusy)throw Error('网页另一个对话中有未发送草稿，请先处理后再切换');
    }
    if(url){if(!this.sameTarget(s.url,url)){this.ready=false;this.view.src=url;s=await this.ensure(signal);}}
    else if(changing){this.ready=false;this.view.src='https://chatgpt.com/';s=await this.ensure(signal);}
    return s;
  }
  async verifySelection(expected,signal){
    await this.ensure(signal,{modelControls:true});
    try{const s=await this.call('open-mode');if(expected.mode&&s.mode!==expected.mode)throw Error('网页思考档位已变化，请同步状态后再发送');}finally{await this.dismiss();}
    if(expected.version){try{const v=await this.versionOptions(signal);if(!v.options.some(o=>o.label===expected.version&&o.selected))throw Error('网页模型版本已变化，请同步状态后再发送');}finally{await this.dismiss();}}
  }
  async readAnswer(binding){
    if(!binding.url||!Number.isInteger(binding.userCount)||!Number.isInteger(binding.answerCount))throw Error('这条消息缺少网页定位信息，请打开原网页查看');
    let s=await this.conversation(binding.url);
    if(s.lastUserCollapsed)s=await this.call('snapshot',{expectedText:binding.input?.text,userId:binding.userId});
    if(s.busy||!s.complete||!s.answerHTML)throw Error('网页回答尚未完成，请稍后再同步');
    if(s.userCount!==binding.userCount||s.answerCount!==binding.answerCount+1||!binding.input?.text||!this.messageMatches(s,binding.input.text))throw Error('网页当前回答与这条消息不对应，未覆盖原回答');
    return ETAIWebChatFormat.markdown(s.answerHTML);
  }
  uploadedNamesMatch(files,composerText){
    // The website may add a numeric suffix after uploading a same-named file.
    // Consume complete visible filename lines, never arbitrary substrings.
    const lines=String(composerText||'').split(/\r?\n/).map(s=>s.trim());
    const escape=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    for(const f of files){const dot=f.name.lastIndexOf('.'),stem=dot>0?f.name.slice(0,dot):f.name,ext=dot>0?f.name.slice(dot):'';
      const exact=lines.indexOf(f.name),re=new RegExp('^'+escape(stem)+' ?\\([1-9]\\d*\\)'+escape(ext)+'$');
      const index=exact>=0?exact:lines.findIndex(s=>re.test(s));if(index<0)return false;lines.splice(index,1);
    }
    return true;
  }
  uploadedFilesMatch(files,s,{requireNames=false}={}){
    const images=files.filter(f=>/^image\//.test(f.type)),thumbs=s.composerImages||[];
    if(thumbs.some(i=>!i.ready))return false;
    if(s.composerAttachmentCount&&s.composerAttachmentCount!==files.length)return false;
    if(!thumbs.length)return this.uploadedNamesMatch(files,s.composerText);
    if(!images.length||thumbs.length!==images.length||!this.uploadedNamesMatch(files.filter(f=>!/^image\//.test(f.type)),s.composerText))return false;
    const remaining=[...thumbs];
    for(const f of images){
      let index=remaining.findIndex(i=>this.uploadedNamesMatch([f],i.names.join('\n')));
      // A freshly uploaded nameless preview is valid only inside an attachment
      // card. Do not treat a differently named picture as this message's file.
      if(index<0&&!requireNames)index=remaining.findIndex(i=>!i.names.some(n=>/\.(png|jpe?g|webp)(?:\s|$)/i.test(n)));
      if(index<0)return false;remaining.splice(index,1);
    }
    return true;
  }
  messageMatches(s,text){const normalized=value=>String(value||'').normalize('NFC').replace(/[\u200b\ufeff]/g,'').replace(/\s+/g,' ').trim();return !!normalized(text)&&normalized(s.lastUser)===normalized(text);}
  async resumeReply(binding,{signal,onProgress,onText,onBinding,onActivity,onTiming}){
    this.timings={startedAt:Date.now(),recovery:true};
    if(!binding.submitted||!this.chatURL(binding.url)||!binding.input?.text||!Number.isInteger(binding.userCount)||!Number.isInteger(binding.answerCount))throw Error('缺少此消息的网页定位信息，请查看原聊天');
    onProgress('正在恢复网页回答');await this.conversation(binding.url,signal,{observe:true});
    const base={url:binding.url,userCount:binding.baselineUserCount??Math.max(0,binding.userCount-1),answerCount:binding.answerCount};
    // Receiving an existing submission must never call prepare, upload or send.
    return this.receive({text:binding.input.text,base,recover:binding,signal,onProgress,onText,onBinding,onActivity,onTiming});
  }
  async receive({text,base,recover,signal,onProgress,onText,onBinding,onActivity,onTiming,watch}){
    const deadline=Date.now()+30*60*1000,ackDeadline=Date.now()+25000;
    watch ||= await this.armEvents(text,base,true);
    let accepted=false,userId=recover?.userId||'',userCount=0,boundURL=this.chatURL(base.url)?base.url.split('?')[0]:'',bindingKey='',lastHTML='',lastText='',published='',stable=0,mismatch='',mismatches=0,finishing=false,finishPoll=500,changedAt=Date.now(),lastSnapshot,readAt=0,domRevision;
    try{
    while(Date.now()<deadline){
      let event;
      if(watch){try{event=await this.waitEvents(watch,signal,finishing?finishPoll:2000);if(!event||event.disposed){watch=null;}else {watch.revision=event.revision;if(event.scopeChanged){const current=await this.scope();if(this.differentScope(watch.scope,current))throw Error('网页登录身份发生变化，停止同步');if(current)await this.events('accept-scope',{id:watch.id});else {await this.events('dispose',{id:watch.id});watch=null;event=null;}}}}catch(e){if(e.name==='AbortError'||/登录身份发生变化/.test(e.message))throw e;await this.events('dispose',{id:watch.id}).catch(()=>{});watch=null;}}
      else await this.wait(500,signal);
      if(event?.url&&boundURL&&!this.sameTarget(event.url,boundURL))throw Error('网页已切换到其他对话，停止同步');
      const unchanged=accepted&&!finishing&&Number.isInteger(event?.domRevision)&&event.domRevision===domRevision&&Date.now()-readAt<2000;
      const s=unchanged?lastSnapshot:await this.call('snapshot',{progress:true,expectedText:text,userId,bound:accepted});
      if(!unchanged){lastSnapshot=s;domRevision=event?.domRevision;readAt=Date.now();this.timings||={startedAt:Date.now()};this.timings.snapshotReads=(this.timings.snapshotReads||0)+1;}
      if(s.login||s.challenge)throw Error(s.challenge?this.challengeNotice():'网页需要重新登录，请打开网页处理');
      if(boundURL&&!this.sameTarget(s.url,boundURL))throw Error('网页已切换到其他对话，停止同步');
      const matches=this.messageMatches(s,text),known=accepted&&userId&&s.lastUserId===userId&&(matches||s.lastUserCollapsed);
      const candidate=accepted?s.userCount===userCount:recover?(recover.userId?s.lastUserId===recover.userId:s.userCount>=recover.userCount&&s.userCount<=recover.userCount+1):s.userCount>base.userCount;
      if(known||(candidate&&matches)){
        accepted=true;userId=s.lastUserId||userId;userCount=s.userCount;mismatches=0;
        if(this.chatURL(s.url))boundURL=s.url.split('?')[0];
        const key=boundURL+'|'+userId+'|'+userCount;
        if(key!==bindingKey){bindingKey=key;onBinding({submitted:true,url:boundURL,userId,userCount,answerCount:base.answerCount,baselineUserCount:base.userCount});}
      }else if(s.lastUser&&(candidate||accepted||recover)){
        // Expanding or hydrating a bubble can briefly expose a partial body.
        // Require a stable mismatch, never accept a matching prefix or tail.
        const key=s.lastUserId+'|'+s.lastUser;mismatches=key===mismatch?mismatches+1:1;mismatch=key;
        if(mismatches>=3&&!s.lastUserCollapsed)throw Error('网页最新消息与本次任务不一致，停止同步');
        if(Date.now()>ackDeadline)throw Error('尚未确认本次网页消息，请继续接收或查看原聊天；不会重新发送');
        continue;
      }
      if(!accepted){if(s.error)throw Error(s.error);if(Date.now()>ackDeadline)throw Error('发送状态尚未确认，请查看网页；本次消息不会自动重发');continue;}
      const stream=event?.supported&&event.text&&(!event.conversationId||event.conversationId===this.chatIdentity(s.url))&&(!s.answerId||!event.messageId||s.answerId===event.messageId)?event:null;
      if(stream?.text)this.markTiming('firstPublicTextMs',onTiming);
      if(stream?.completed)this.markTiming('semanticFinishMs',onTiming);
      if(s.activity?.length)onActivity?.(s.activity,s.busy);
      const hasReply=s.replyAfterUser===true||(s.replyAfterUser===undefined&&s.answerCount>base.answerCount);
      if(stream&&!s.complete&&stream.text!==published){published=stream.text;onText(published);this.markTiming('firstRenderQueuedMs',onTiming);onProgress('正在接收网页回答');}
      if(hasReply&&s.answerHTML){
        if(lastHTML!==s.answerHTML){lastHTML=s.answerHTML;lastText=ETAIWebChatFormat.markdown(lastHTML);stable=0;changedAt=Date.now();}else stable++;
        if((!stream||s.complete)&&lastText!==published){published=lastText;onText(lastText);this.markTiming('firstPublicTextMs',onTiming);this.markTiming('firstRenderQueuedMs',onTiming);onProgress('正在接收网页回答');}
        const files=[...(stream?.text||'').matchAll(/sandbox:\/[^\s)\]]*\/([^/\s)\]]+)/g)].map(m=>{try{return decodeURIComponent(m[1]);}catch{return m[1];}}),filesReady=files.every(name=>lastHTML.includes(name)||lastHTML.includes(encodeURIComponent(name)));
        // A matched public end_turn can complete without a visible hover action bar.
         finishing=!!(s.complete||(stream?.completed&&hasReply&&s.answerId&&s.answerId===stream.messageId))&&!s.busy;
        finishPoll=stream?.completed?180:500;
        if(filesReady&&(files.length||lastText.includes('#et-web-file/')))this.markTiming('fileLinksReadyMs',onTiming);
        const settled=watch?stable>=(stream?.completed?1:2)&&Date.now()-changedAt>=(stream?.completed?160:1000):stable>=2;
        if(finishing&&settled&&filesReady){onBinding({submitted:true,url:s.url,userId,userCount,answerCount:base.answerCount,answerId:s.answerId});this.markTiming('finishedMs',onTiming);onProgress('网页回答已完成');return {text:lastText,url:s.url,finishReason:'stop'};}
      }
      if(s.error)throw Error(s.error);
      if(s.disconnected)throw Error('网页连接已中断，已保留收到的内容；可继续接收原回答');
    }
    throw Error('网页回答等待超时，已收到的内容已保留，可继续接收原回答');
    }finally{if(watch)await this.events('dispose',{id:watch.id}).catch(()=>{});}
  }
  async request({id,text,files,conversation,projectTarget,expected,signal,onProgress,onText,onBinding,onActivity,onTiming}){
    let submitted=false,base,s,watch,requestScope;this.timings={startedAt:Date.now()};this.markTiming('connectMs',onTiming);
    try{
      const capabilities=this.capabilities;
      onProgress('正在连接 GPT 网页');base=projectTarget?await this.projectRoute(projectTarget,signal,{replaceDraft:true}):await this.conversation(conversation,signal,{replaceDraft:true});requestScope=this.principal;await this.verifySelection(expected,signal);
      // Reuse the observed options only after the selected settings survive
      // navigation and are read back. Do not cycle the slider during sending.
      if(!this.capabilities.modes.length)this.capabilities=capabilities;
      onProgress('正在读取当前聊天记录');base=await this.settleConversation(base,signal);
      onProgress('正在清理网页旧草稿');await this.clearComposer(signal,base);
      const guard=this.conversationGuard(base);
      s=await this.call('prepare',{text,...guard});
      if(files.length){
        onProgress('正在等待网页附件控件');const inputDeadline=Date.now()+25000;
        while(true){
          s=await this.call('upload-ready',{files:files.map(({name,type})=>({name,type})),...guard});
          if(s.login||s.challenge)throw Error(s.challenge?this.challengeNotice():'请在 GPT 网页登录后重试');if(s.error)throw Error(s.error);
          if(s.uploadReady)break;
          if(Date.now()>=inputDeadline)throw Error('网页附件控件仍不可用，未上传或发送。请打开网页检查');
          await this.wait(200,signal);
        }
        onProgress('正在上传 '+files.length+' 个文件');await this.call('upload',{files,...guard});
        const end=Date.now()+180000;let ready=0;
        while(Date.now()<end){await this.wait(450,signal);s=await this.call('snapshot');if(s.login||s.challenge)throw Error(s.challenge?this.challengeNotice():'请在 GPT 网页登录后重试');if(s.error)throw Error(s.error);if(this.uploadedFilesMatch(files,s)&&!s.uploadBusy&&s.sendReady){if(++ready>=3)break;}else ready=0;}
        if(ready<3)throw Error('尚未确认文件上传完成，未发送消息。请打开网页检查附件');
      }
      await this.wait(80,signal);s=await this.call('snapshot');this.checkConversation(s,base);if(s.userCount!==base.userCount||(base.lastUserId&&s.lastUserId!==base.lastUserId))throw Error('网页会话发生变化，未发送');
      if((files.length?!this.uploadedFilesMatch(files,s):s.composerHasAttachments||s.composerAttachmentCount||s.composerImages?.length)||s.uploadBusy)throw Error('网页附件在发送前发生变化，未发送，请检查附件');
      watch=await this.armEvents(text,base);
      if(this.differentScope(requestScope,this.principal))throw Error('网页账号或工作区在准备消息时发生变化，未发送');
      // Persist uncertainty before dispatch. Only a verified pre-click refusal is safe to retry.
      submitted=true;onBinding({submitted:true,url:s.url,userCount:s.userCount,answerCount:s.answerCount,baselineUserCount:base.userCount});
      await this.call('send',{id,text,...guard});this.markTiming('submittedMs',onTiming);onProgress('已提交，正在等待网页回答');
      return await this.receive({text,base,signal,onProgress,onText,onBinding,onActivity,onTiming,watch});
    }catch(e){
      if(e.name==='AbortError'&&submitted){try{const s=await this.call('stop');if(s.busy)e.message='已停止本地接收；网页尚未确认停止，请打开网页检查';}catch{e.message='已停止本地接收；请打开网页确认生成状态';}}
      e.webSubmitted=submitted;throw e;
    }finally{if(watch)await this.events('dispose',{id:watch.id}).catch(()=>{});}
  }
}
