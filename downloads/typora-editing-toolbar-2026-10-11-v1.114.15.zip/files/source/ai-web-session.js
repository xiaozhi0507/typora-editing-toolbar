// Both website surfaces share the existing chat partition. Electron owns login
// persistence; no credential copying or changes to the separate API grant.
class EditingToolbarAIWebSession {
  static partition='persist:et-chatgpt-web-v1';
  static usageKey='chatgpt-shared-web';
}
