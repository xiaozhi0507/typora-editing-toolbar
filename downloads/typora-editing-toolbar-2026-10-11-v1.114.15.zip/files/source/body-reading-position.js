// Local reading state only: never adds markup or files to the document.
class EditingToolbarReadingPosition {
 constructor(toolbar){
  this.toolbar=toolbar;this.storageKey='et-body-reading-v1';this.file='';this.suspended=0;this.restoring=false;this.navigation=null;this.generation=0;
  this.wrapLifecycle();
  document.addEventListener('scroll',e=>{if(e.target===this.scroller)this.scheduleSave();},true);
  document.addEventListener('selectionchange',()=>this.scheduleSave());
  const interrupt=e=>{if(e.isTrusted){this.cancelRestore();this.scheduleSave();}};
  document.addEventListener('wheel',interrupt,{capture:true,passive:true});document.addEventListener('pointerdown',interrupt,true);document.addEventListener('keydown',interrupt,true);
  window.addEventListener('blur',()=>this.save());window.addEventListener('beforeunload',()=>this.save());
  this.poll=setInterval(()=>this.switchFile(),350);this.switchFile();
 }
 key(file){try{return reqnode('path').resolve(file).replace(/\\/g,'/').toLowerCase();}catch(_){return file;}}
 loading(){return this.suspended||File.isFileLoading?.();}
 source(){return document.body.classList.contains('typora-sourceview-on');}
 readDB(){try{const db=JSON.parse(localStorage.getItem(this.storageKey));return db?.version===1&&db.entries&&typeof db.entries==='object'?db:{version:1,entries:{}};}catch(_){return{version:1,entries:{}};}}
 writeEntry(file,entry){if(!file||!entry)return;try{const db=this.readDB();db.entries[this.key(file)]=entry;const keys=Object.keys(db.entries).sort((a,b)=>(db.entries[b]?.time||0)-(db.entries[a]?.time||0));for(const key of keys.slice(400))delete db.entries[key];localStorage.setItem(this.storageKey,JSON.stringify(db));}catch(e){console.warn('[EditingToolbar] 阅读位置未保存：',e.message);}}
 navigationTo(url){
  if(typeof url!=='string'||!url.includes('#'))return;
  let part=url.slice(0,url.indexOf('#')),file=File.bundle?.filePath;
  if(part){if(/^[a-z]+:\/\//i.test(part)&&!part.startsWith('file:'))return;try{part=decodeURIComponent(part).replace(/^file:\/\//,'');file=reqnode('path').resolve(reqnode('path').dirname(file||''),part);}catch(_){return;}}
  if(file)this.navigation=this.file&&this.key(file)===this.key(this.file)&&!this.loading()?null:{key:this.key(file),until:Date.now()+5000};this.cancelRestore();
 }
 wrapLifecycle(){
  const self=this,load=File.loadFile;
  File.loadFile=async function(...args){self.save(true);self.cancelRestore();self.suspended++;document.dispatchEvent(new CustomEvent('et-document-leaving',{detail:{file:typeof args[0]==='string'?args[0]:''}}));
   const anchor=File.option?.initAnchor;if(anchor)self.navigationTo((args[0]||'')+anchor);
   try{return await load.apply(this,args);}finally{self.suspended--;self.switchFile(true);
    // Native snapshot recovery can skip the initial-anchor branch. Keep the
    // requested link destination authoritative in that case as well.
    if(anchor&&File.option?.initAnchor===anchor){File.option.initAnchor='';const file=File.bundle?.filePath,generation=self.generation;setTimeout(()=>{if(self.file===file&&self.generation===generation)File.editor.tryOpenUrl(anchor);},80);}
   }
  };
  const open=File.editor.tryOpenUrl;
  if(typeof open==='function')File.editor.tryOpenUrl=function(url,...args){self.navigationTo(url);return open.call(this,url,...args);};
  const save=File.saveAsUseNode;
  if(typeof save==='function'){
   const wrapped=async function(...args){self.save();const from=File.bundle?.filePath,entry=self.readDB().entries[self.key(from||'')];self.suspended++;
    try{const result=await save.apply(this,args);if(!(result instanceof Error)){const to=File.bundle?.filePath;if(to&&to!==from){self.writeEntry(to,entry);self.file=to;document.dispatchEvent(new CustomEvent('et-document-saved-as',{detail:{from,to}}));}}return result;}
    finally{self.suspended--;self.switchFile();}
   };File.saveAsUseNode=wrapped;if(File.FileSave?.saveAsUseNode===save)File.FileSave.saveAsUseNode=wrapped;
  }
  if(File.option?.initAnchor||window._options?.initAnchor)this.navigationTo((File.bundle?.filePath||'')+(File.option?.initAnchor||window._options.initAnchor));
 }
 blocks(){return [...this.write.querySelectorAll('[cid]')].filter(e=>e.matches('p,h1,h2,h3,h4,h5,h6,li,figure,pre')&&!e.closest('.md-toc,.md-fences .CodeMirror,.md-htmlblock .CodeMirror')&&e.getClientRects().length);}
 text(el){return(el.textContent||'').replace(/\s+/g,' ').trim();}
 describe(el,blocks){const text=this.text(el);return{index:blocks.indexOf(el),tag:el.tagName,text:text.slice(0,180),length:text.length};}
 find(desc,blocks){if(!desc)return null;const same=e=>e.tagName===desc.tag&&this.text(e).slice(0,180)===desc.text;
  if(blocks[desc.index]&&same(blocks[desc.index]))return blocks[desc.index];const matches=blocks.filter(same);return matches.length===1?matches[0]:null;
 }
 readOffset(){return this.toolbar.chapterMinimap?.readOffset||Math.max(28,(this.toolbar.topHost?.getBoundingClientRect().bottom||0)+12);}
 capture(){
  if(!this.write?.isConnected||!this.scroller||this.source())return null;const blocks=this.blocks();if(!blocks.length)return null;
  const top=this.scroller.getBoundingClientRect().top,readY=top+this.readOffset();let anchor=blocks[0],heading=null;
  for(const el of blocks){const r=el.getBoundingClientRect();if(r.top<=readY){anchor=el;if(/^H[1-6]$/.test(el.tagName))heading=el;}else break;}
  const rect=anchor.getBoundingClientRect(),scroll=this.scroller.scrollTop,max=this.scroller.scrollHeight-this.scroller.clientHeight;
  const entry={time:Date.now(),scroll,ratio:max>0?scroll/max:0,anchor:this.describe(anchor,blocks),within:(readY-rect.top)/Math.max(1,rect.height),heading:heading?this.describe(heading,blocks):null};
  const selection=getSelection(),endpoint=(node,offset)=>{const el=(node.nodeType===1?node:node.parentElement)?.closest('[cid]');if(!el||!blocks.includes(el))return null;try{const r=document.createRange();r.selectNodeContents(el);r.setEnd(node,offset);return{block:this.describe(el,blocks),offset:r.toString().length};}catch(_){return null;}};
  if(selection?.rangeCount){const r=selection.getRangeAt(0),a=endpoint(r.startContainer,r.startOffset),b=endpoint(r.endContainer,r.endOffset);if(a&&b)entry.selection={a,b};}
  if(!entry.selection&&this.lastEntry?.selection)entry.selection=this.lastEntry.selection;
  return entry;
 }
 scheduleSave(){if(this.restoring||this.loading())return;clearTimeout(this.saveTimer);this.saveTimer=setTimeout(()=>this.save(),300);}
 save(force=false){clearTimeout(this.saveTimer);if(!this.file||!force&&this.loading()||this.restoring||this.file!==File.bundle?.filePath)return;
  const entry=this.capture();if(entry){this.lastEntry=entry;this.writeEntry(this.file,entry);}
 }
 cancelRestore(){this.generation++;this.restoring=false;clearTimeout(this.restoreTimer);}
 switchFile(force=false){
  if(this.loading())return;const file=File.bundle?.filePath||'',write=document.getElementById('write');if(!write||!force&&file===this.file&&write===this.write)return;
  this.cancelRestore();this.file=file;this.write=write;this.scroller=write.closest('content')||document.scrollingElement;this.lastEntry=null;
  document.dispatchEvent(new CustomEvent('et-document-loaded',{detail:{file}}));
  if(!file)return;const saved=this.readDB().entries[this.key(file)],nav=this.navigation,linked=nav?.key===this.key(file)&&nav.until>Date.now();
  if(linked)this.navigation=null;
  if(!saved||linked)return;
  if(!Number.isFinite(saved.scroll)||!Number.isFinite(saved.ratio))return;
  this.lastEntry=saved;this.restoring=true;const generation=this.generation;let count=0;const restore=()=>{
   if(generation!==this.generation||this.file!==File.bundle?.filePath||this.loading()||this.source()){this.restoring=false;return;}
   const blocks=this.blocks();if(blocks.length){if(count===0)this.restoreSelection(saved.selection,blocks);const el=this.find(saved.anchor,blocks),section=this.find(saved.heading,blocks);
    let y=saved.ratio*Math.max(0,this.scroller.scrollHeight-this.scroller.clientHeight);
    if(el)y=el.getBoundingClientRect().top-this.scroller.getBoundingClientRect().top+this.scroller.scrollTop+Math.max(-2,Math.min(3,saved.within||0))*el.getBoundingClientRect().height-this.readOffset();
    else if(section)y=section.getBoundingClientRect().top-this.scroller.getBoundingClientRect().top+this.scroller.scrollTop-this.readOffset();
    this.scroller.scrollTop=Math.max(0,y);
   }
   if(++count<6)this.restoreTimer=setTimeout(restore,count<3?140:350);else{this.restoring=false;this.scheduleSave();}
  };this.restoreTimer=setTimeout(restore,120);
 }
 restoreSelection(saved,blocks){
  if(!saved||document.activeElement?.matches('input,textarea,[contenteditable=true]:not(#write)'))return;
  const point=p=>{const el=this.find(p?.block,blocks);if(!el)return null;let offset=Math.max(0,p.offset||0),walker=document.createTreeWalker(el,NodeFilter.SHOW_TEXT),n,last;
   while(n=walker.nextNode()){last=n;if(offset<=n.length)return[n,offset];offset-=n.length;}return last?[last,last.length]:[el,0];};
  const a=point(saved.a),b=point(saved.b);if(!a||!b)return;
  try{const range=document.createRange();range.setStart(...a);range.setEnd(...b);this.write.focus({preventScroll:true});File.editor.selection.setRange(range,true);}catch(_){}
 }
}
