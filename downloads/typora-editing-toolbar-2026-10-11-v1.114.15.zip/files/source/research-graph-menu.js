import {GraphLinkRemoval} from './research-graph-unlink.js';
const el=(tag,cls,text)=>{const n=document.createElement(tag);n.className=cls;if(text!=null)n.textContent=text;return n;};
export class ResearchGraphMenu {
 constructor(sidebar){
  this.sidebar=sidebar;this.unlink=new GraphLinkRemoval(sidebar);this.menu=el('div','et-rs-node-menu');this.menu.hidden=true;this.menu.setAttribute('role','menu');this.menu.setAttribute('aria-label','图谱右键菜单');document.body.append(this.menu);
  for(const event of ['pointerdown','mousedown','click','dblclick','contextmenu'])this.menu.addEventListener(event,e=>{e.stopPropagation();if(event==='contextmenu')e.preventDefault();});
  document.addEventListener('pointerdown',e=>{if(!this.menu.contains(e.target))this.close();},true);
  document.addEventListener('keydown',e=>{if(!this.menu.hidden&&e.key==='Escape'){e.preventDefault();e.stopPropagation();this.close(true);}},true);
  window.addEventListener('blur',()=>this.close());window.addEventListener('resize',()=>this.close());document.addEventListener('wheel',e=>{if(!this.menu.contains(e.target))this.close();},{capture:true,passive:true});
  this.menu.addEventListener('keydown',e=>{e.stopPropagation();const buttons=[...this.menu.querySelectorAll('button:not(:disabled)')],index=buttons.indexOf(document.activeElement);let next;
   if(e.key==='ArrowDown')next=(index+1)%buttons.length;if(e.key==='ArrowUp')next=(index+buttons.length-1)%buttons.length;if(e.key==='Home')next=0;if(e.key==='End')next=buttons.length-1;
   if(next!=null){e.preventDefault();buttons[next]?.focus();}if(e.key==='Tab')this.close();
  });
 }
 close(focus=false){if(this.menu.hidden)return;this.menu.hidden=true;if(focus&&this.returnFocus?.isConnected)this.returnFocus.focus({preventScroll:true});}
 copy(text){reqnode('electron').clipboard.writeText(text);this.sidebar.notify('已复制。');}
 async reveal(target,file){
  const s=this.sidebar;if(!target?.path||!target.exists)return s.notify('目标文件尚不存在，无法打开文件位置。');
  try{const stat=await s.fs.promises.stat(target.path);if(!stat.isFile())return s.notify('目标已不再是文件，请刷新图谱。');}
  catch(e){if(e.code==='ENOENT'||e.code==='ENOTDIR'){s.refresh();return s.notify('文件已移动或删除，请刷新图谱。');}throw e;}
  if(s.file!==file||File.bundle?.filePath!==file)return s.notify('文档已切换，请重新右键操作。');
  reqnode('electron').shell.showItemInFolder(s.path.normalize(target.path));
 }
 show(node,event){
  event.preventDefault();event.stopPropagation();const s=this.sidebar,file=s.file;if(node?.kind==='tag'||!file||File.bundle?.filePath!==file||File.isFileLoading?.())return;
  const target=node?{...node}:null;this.returnFocus=event.currentTarget||s.graph.canvas;s.graph.tip.hidden=true;this.menu.replaceChildren();
  this.menu.append(el('div','et-rs-menu-title',target?.label||s.title.textContent));
  if(target){const desc=el('div','et-rs-menu-detail',target.kind==='heading'?'本文档 · '+(['','一级标题','二级标题','三级标题'][target.headingLevel]):target.kind==='tag'?'标签':target.exists?(target.relative||target.path):'链接目标尚不存在');desc.title=target.path||target.label;this.menu.append(desc);}
  const item=(label,action,disabled=false,hint='')=>{const b=el('button','et-rs-menu-item',label);b.type='button';b.setAttribute('role','menuitem');b.disabled=disabled;if(hint)b.title=hint;b.onclick=async()=>{this.close(true);if(s.file!==file||File.bundle?.filePath!==file)return s.notify('文档已切换，请重新右键操作。');try{await action();}catch(e){s.notify('操作未完成：'+e.message);}};this.menu.append(b);};
  const separator=()=>this.menu.append(el('div','et-rs-menu-separator'));
  if(target?.kind==='heading'){
   item('跳转到标题',()=>s.outline.jump(target));item('收起文档标题',()=>s.outline.collapse());
  }else if(target?.kind==='library'){
   item('查看文库条目',()=>s.openNode(target));
   item('复制标题',()=>this.copy(target.label));
   item(s.hiddenNodes().includes(target.id)?'恢复此节点':'从图谱隐藏',()=>s.setNodeHidden(target.id,!s.hiddenNodes().includes(target.id)));
  }else if(target){
   {
    item(target.current?'当前文档':'打开文件',()=>s.openNode(target),!target.exists||!!target.current);
    item('打开文件位置',()=>this.reveal(target,file),!target.exists||!target.path,target.exists?'在资源管理器中选中此文件':'目标文件尚不存在，无法定位');
    item('复制文件路径',()=>this.copy(target.path),!target.path);
    item('复制 Markdown 链接',()=>{const relative=s.path.relative(s.path.dirname(file),target.path).replace(/\\/g,'/'),url=(s.path.isAbsolute(relative)?reqnode('url').pathToFileURL(target.path).href:relative.split('/').map(encodeURIComponent).join('/')).replace(/[()]/g,c=>'%'+c.charCodeAt(0).toString(16)),label=target.label.replace(/[\\\[\]]/g,'\\$&');this.copy('['+label+']('+url+')');},!target.path);
    if(!target.exists){
     separator();const direct=s.index?.edges.some(e=>e.source===s.key(file)&&e.target===target.id),enabled=direct&&this.unlink.enabled();
     item('删除失效链接（保留文字）',()=>this.unlink.remove(target,file),!enabled,enabled?'移除当前正文中指向此目标的链接；Ctrl+Z 可撤销':'只可删除当前文档正文中的失效链接；可使用从图谱隐藏');
    }
   }
   if(target.id!==s.key(file)){separator();const hidden=s.hiddenNodes().includes(target.id);item(hidden?'恢复此节点':'从图谱隐藏',()=>s.setNodeHidden(target.id,!hidden));}
  }else{item('适应图谱',()=>s.graph.fit());item('自然布局',()=>s.naturalLayout());item('刷新索引',()=>s.refresh());if(s.hiddenNodes().length||!s.options.incoming||!s.options.outgoing)item('清除临时筛选',()=>s.clearFilters());}
  if(s.hiddenNodes().length){separator();item('恢复隐藏节点（'+s.hiddenNodes().length+'）',()=>s.restoreHiddenNodes());}
  this.menu.hidden=false;const r=this.menu.getBoundingClientRect(),anchor=event.currentTarget?.getBoundingClientRect(),x=event.clientX||anchor?.left||12,y=event.clientY||anchor?.bottom||12;
  this.menu.style.left=Math.max(8,Math.min(innerWidth-r.width-8,x))+'px';this.menu.style.top=Math.max(8,Math.min(innerHeight-r.height-8,y))+'px';this.menu.querySelector('button:not(:disabled)')?.focus({preventScroll:true});
 }
}
