// Windows ConPTY bridge. Each instance owns one Job Object and one shell session.
// Wire format: newline-delimited JSON; terminal bytes are base64 (never re-encoded).
using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Diagnostics;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Web.Script.Serialization;
using Microsoft.Win32.SafeHandles;

internal static class TerminalHost {
    [StructLayout(LayoutKind.Sequential)] struct COORD { public short X,Y; public COORD(short x,short y){X=x;Y=y;} }
    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)] struct STARTUPINFO {
        public int cb; public string reserved,desktop,title; public int x,y,xSize,ySize,xCount,yCount,fill,flags; public short show,reserved2; public IntPtr reservedPtr,input,output,error;
    }
    [StructLayout(LayoutKind.Sequential)] struct STARTUPINFOEX { public STARTUPINFO info; public IntPtr attributes; }
    [StructLayout(LayoutKind.Sequential)] struct PROCESS_INFORMATION { public IntPtr process,thread; public int pid,tid; }
    [StructLayout(LayoutKind.Sequential)] struct BASIC_LIMIT { public long perProcess,perJob; public uint flags; public UIntPtr min,max; public uint active; public UIntPtr affinity; public uint priority,scheduling; }
    [StructLayout(LayoutKind.Sequential)] struct IO_COUNTERS { public ulong readOps,writeOps,otherOps,readBytes,writeBytes,otherBytes; }
    [StructLayout(LayoutKind.Sequential)] struct EXTENDED_LIMIT { public BASIC_LIMIT basic; public IO_COUNTERS io; public UIntPtr processMemory,jobMemory,peakProcess,peakJob; }
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool CreatePipe(out IntPtr read,out IntPtr write,IntPtr security,int size);
    [DllImport("kernel32.dll")] static extern int CreatePseudoConsole(COORD size,IntPtr input,IntPtr output,uint flags,out IntPtr console);
    [DllImport("kernel32.dll")] static extern int ResizePseudoConsole(IntPtr console,COORD size);
    [DllImport("kernel32.dll")] static extern void ClosePseudoConsole(IntPtr console);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool InitializeProcThreadAttributeList(IntPtr list,int count,int flags,ref IntPtr size);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool UpdateProcThreadAttribute(IntPtr list,uint flags,IntPtr attribute,IntPtr value,IntPtr size,IntPtr previous,IntPtr returned);
    [DllImport("kernel32.dll")] static extern void DeleteProcThreadAttributeList(IntPtr list);
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool CreateProcess(string app,StringBuilder command,IntPtr psa,IntPtr tsa,bool inherit,uint flags,IntPtr env,string cwd,ref STARTUPINFOEX startup,out PROCESS_INFORMATION process);
    [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr CreateJobObject(IntPtr security,string name);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool SetInformationJobObject(IntPtr job,int info,ref EXTENDED_LIMIT limits,int length);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool AssignProcessToJobObject(IntPtr job,IntPtr process);
    [DllImport("kernel32.dll")] static extern bool TerminateJobObject(IntPtr job,uint code);
    [DllImport("kernel32.dll")] static extern bool TerminateProcess(IntPtr process,uint code);
    [DllImport("kernel32.dll")] static extern uint ResumeThread(IntPtr thread);
    [DllImport("kernel32.dll")] static extern uint WaitForSingleObject(IntPtr handle,uint ms);
    [DllImport("kernel32.dll")] static extern bool GetExitCodeProcess(IntPtr process,out uint code);
    [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
    [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint access,bool inherit,int pid);

    static IntPtr console,job,process,ownerHandle; static FileStream input,output; static Thread reader;
    static int closing; static readonly object sendLock=new object();
    static readonly JavaScriptSerializer json=new JavaScriptSerializer { MaxJsonLength=1024*1024 };
    static readonly StreamWriter wire=new StreamWriter(Console.OpenStandardOutput(),new UTF8Encoding(false)) { AutoFlush=true };
    static void Send(object message){lock(sendLock){try{wire.WriteLine(json.Serialize(message));}catch{Environment.Exit(1);}}}
    static void Check(bool ok,string action){if(!ok)throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error(),action);}
    static string Str(Dictionary<string,object> m,string key){object v;return m.TryGetValue(key,out v)?Convert.ToString(v):"";}
    static int Num(Dictionary<string,object> m,string key,int fallback){int v;return Int32.TryParse(Str(m,key),out v)?v:fallback;}
    static COORD Size(Dictionary<string,object> m){return new COORD((short)Math.Max(2,Math.Min(500,Num(m,"cols",80))),(short)Math.Max(2,Math.Min(300,Num(m,"rows",24))));}
    // CreateProcess uses the standard Windows argument quoting rules, without cmd concatenation.
    static string Quote(string value){var b=new StringBuilder("\"");int slash=0;foreach(char c in value){if(c=='\\'){slash++;continue;}if(c=='"'){b.Append('\\',slash*2+1);b.Append(c);}else{b.Append('\\',slash);b.Append(c);}slash=0;}b.Append('\\',slash*2);b.Append('"');return b.ToString();}
    static void Start(Dictionary<string,object> m){
        string exe=Path.GetFullPath(Str(m,"exe")),cwd=Path.GetFullPath(Str(m,"cwd"));
        if(!File.Exists(exe)||!Directory.Exists(cwd))throw new IOException("Shell executable or working directory does not exist.");
        // Typora narrows its own PATHEXT to .CPL. A shell must see the user's
        // normal executable extensions, or PowerShell silently shell-opens .exe files.
        string extensions=Environment.GetEnvironmentVariable("PATHEXT")??"";
        if(Array.IndexOf(extensions.ToUpperInvariant().Split(';'),".EXE")<0){
            extensions=Environment.GetEnvironmentVariable("PATHEXT",EnvironmentVariableTarget.User);
            if(String.IsNullOrWhiteSpace(extensions))extensions=Environment.GetEnvironmentVariable("PATHEXT",EnvironmentVariableTarget.Machine);
            if(String.IsNullOrWhiteSpace(extensions))extensions=".COM;.EXE;.BAT;.CMD;.VBS;.VBE;.JS;.JSE;.WSF;.WSH;.MSC;.CPL";
            Environment.SetEnvironmentVariable("PATHEXT",extensions);
        }
        int owner=Num(m,"ownerPid",0);if(owner>0){ownerHandle=OpenProcess(0x00100000,false,owner);Check(ownerHandle!=IntPtr.Zero,"Watch terminal owner");}
        IntPtr inRead=IntPtr.Zero,inWrite=IntPtr.Zero,outRead=IntPtr.Zero,outWrite=IntPtr.Zero,list=IntPtr.Zero;
        bool listReady=false; PROCESS_INFORMATION pi=new PROCESS_INFORMATION();
        try {
            Check(CreatePipe(out inRead,out inWrite,IntPtr.Zero,0),"Create input pipe");
            Check(CreatePipe(out outRead,out outWrite,IntPtr.Zero,0),"Create output pipe");
            int hr=CreatePseudoConsole(Size(m),inRead,outWrite,0,out console);if(hr!=0)Marshal.ThrowExceptionForHR(hr);
            CloseHandle(inRead);inRead=IntPtr.Zero;CloseHandle(outWrite);outWrite=IntPtr.Zero;
            input=new FileStream(new SafeFileHandle(inWrite,true),FileAccess.Write,4096,false);inWrite=IntPtr.Zero;
            output=new FileStream(new SafeFileHandle(outRead,true),FileAccess.Read,4096,false);outRead=IntPtr.Zero;
            reader=new Thread(()=>{byte[] buffer=new byte[16384];try{int n;while((n=output.Read(buffer,0,buffer.Length))>0)Send(new {type="data",data=Convert.ToBase64String(buffer,0,n)});}catch(IOException){}catch(ObjectDisposedException){}});reader.IsBackground=true;reader.Start();
            IntPtr length=IntPtr.Zero;InitializeProcThreadAttributeList(IntPtr.Zero,1,0,ref length);list=Marshal.AllocHGlobal(length);
            Check(InitializeProcThreadAttributeList(list,1,0,ref length),"Initialize process attributes");listReady=true;
            Check(UpdateProcThreadAttribute(list,0,new IntPtr(0x00020016),console,new IntPtr(IntPtr.Size),IntPtr.Zero,IntPtr.Zero),"Attach pseudoconsole");
            job=CreateJobObject(IntPtr.Zero,null);Check(job!=IntPtr.Zero,"Create session job");
            EXTENDED_LIMIT limits=new EXTENDED_LIMIT();limits.basic.flags=0x2000;
            Check(SetInformationJobObject(job,9,ref limits,Marshal.SizeOf(typeof(EXTENDED_LIMIT))),"Set session job limits");
            var cmd=new StringBuilder(Quote(exe));object args;if(m.TryGetValue("args",out args))foreach(object arg in (System.Collections.IEnumerable)args)cmd.Append(" ").Append(Quote(Convert.ToString(arg)));
            var si=new STARTUPINFOEX();si.info.cb=Marshal.SizeOf(typeof(STARTUPINFOEX));si.attributes=list;
            // Do not let redirected host JSON pipes become the shell's standard handles.
            // NULL handles + STARTF_USESTDHANDLES select the attached pseudoconsole.
            si.info.flags=0x100;
            Check(CreateProcess(exe,cmd,IntPtr.Zero,IntPtr.Zero,false,0x00080004,IntPtr.Zero,cwd,ref si,out pi),"Start shell");
            process=pi.process;Check(AssignProcessToJobObject(job,process),"Own shell process tree");
            Check(ResumeThread(pi.thread)!=0xffffffff,"Resume shell");
            Send(new {type="ready",pid=pi.pid});
        } finally {
            if(pi.thread!=IntPtr.Zero)CloseHandle(pi.thread);
            if(listReady)DeleteProcThreadAttributeList(list);if(list!=IntPtr.Zero)Marshal.FreeHGlobal(list);
            foreach(IntPtr h in new[]{inRead,inWrite,outRead,outWrite})if(h!=IntPtr.Zero)CloseHandle(h);
        }
        var watcher=new Thread(()=>{while(Volatile.Read(ref closing)==0){if(WaitForSingleObject(process,250)==0){uint code;GetExitCodeProcess(process,out code);if(Finish((int)code))Environment.Exit(0);return;}if(ownerHandle!=IntPtr.Zero&&WaitForSingleObject(ownerHandle,0)==0){if(Finish(-1))Environment.Exit(0);return;}}});watcher.IsBackground=true;watcher.Start();
    }
    static bool Finish(int code){
        if(Interlocked.Exchange(ref closing,1)!=0)return false;
        if(job!=IntPtr.Zero)TerminateJobObject(job,1);
        if(process!=IntPtr.Zero){TerminateProcess(process,1);WaitForSingleObject(process,2000);}
        if(input!=null)input.Dispose();
        // The output reader stays alive while ConPTY drains its final screen update.
        if(console!=IntPtr.Zero){ClosePseudoConsole(console);console=IntPtr.Zero;}
        if(reader!=null)reader.Join(1500);
        if(output!=null)output.Dispose();
        if(process!=IntPtr.Zero)CloseHandle(process);if(job!=IntPtr.Zero)CloseHandle(job);if(ownerHandle!=IntPtr.Zero)CloseHandle(ownerHandle);
        Send(new {type="exit",code=code});return true;
    }
    static void Main(){
        try {
            using(var source=new StreamReader(Console.OpenStandardInput(),new UTF8Encoding(false,true))){
                string line=source.ReadLine();if(line==null)return;var m=json.Deserialize<Dictionary<string,object>>(line);
                if(Str(m,"type")!="start")throw new IOException("Expected start message.");Start(m);
                while(Volatile.Read(ref closing)==0&&(line=source.ReadLine())!=null){
                    if(line.Length>1024*1024)throw new IOException("Input exceeds limit.");m=json.Deserialize<Dictionary<string,object>>(line);string kind=Str(m,"type");
                    if(kind=="input"){byte[] bytes=Convert.FromBase64String(Str(m,"data"));input.Write(bytes,0,bytes.Length);input.Flush();}
                    else if(kind=="resize"){int hr=ResizePseudoConsole(console,Size(m));if(hr!=0)Marshal.ThrowExceptionForHR(hr);}
                    else if(kind=="stop")break;
                }
            }
        }catch(Exception e){Send(new {type="error",message=e.Message});}
        finally{Finish(-1);}
    }
}
