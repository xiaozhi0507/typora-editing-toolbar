import {forceSimulation,forceManyBody,forceLink,forceX,forceY,forceCollide} from 'd3-force';
import {matchQuery} from './research-note-core.js';
import {prepareLayout,seedPosition,linkStrength,nodeColor} from './research-graph-layout.js';
import {depthUnit,makeScene,projectNode,unprojectPoint,edgeOpacity} from './research-graph-perspective.js';
import {layoutHeadingTree} from './research-graph-tree.js';

const overlaps=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
// Check nearby label obstacles only, even when the graph contains thousands of nodes.
class LabelGrid {
 constructor(size){this.size=size;this.cells=new Map();}
 keys(r){const keys=[];for(let x=Math.floor(r.x/this.size);x<=Math.floor((r.x+r.w)/this.size);x++)for(let y=Math.floor(r.y/this.size);y<=Math.floor((r.y+r.h)/this.size);y++)keys.push(x+','+y);return keys;}
 add(r){for(const key of this.keys(r)){if(!this.cells.has(key))this.cells.set(key,[]);this.cells.get(key).push(r);}}
 hits(r,except){for(const key of this.keys(r))for(const other of this.cells.get(key)||[])if(other.node!==except&&overlaps(r,other))return true;return false;}
}

export class ResearchGraphView {
 constructor(host,open,contextMenu){
  this.host=host;this.open=open;this.canvas=document.createElement('canvas');this.canvas.tabIndex=0;
  this.canvas.setAttribute('aria-label','局部关系图谱，滚轮缩放，拖动节点或空白平移，右键操作节点；节点也可从关系列表打开');
  this.tip=document.createElement('div');this.tip.className='et-rs-tooltip';this.tip.hidden=true;host.append(this.canvas,this.tip);
  this.ctx=this.canvas.getContext('2d');this.labelContext=document.createElement('canvas').getContext('2d');this.labelContext.font='12px system-ui';this.labelCache=new Map();
  document.fonts?.addEventListener('loadingdone',()=>{this.labelCache.clear();this.request();});
  this.scale=.85;this.pan={x:0,y:0};this.nodes=[];this.edges=[];this.positions=new Map();this.frames=0;this.autoFit=true;
  this.yaw=.2;this.pitch=-.12;this.viewHint=document.createElement('div');this.viewHint.className='et-rs-view-hint';this.viewHint.textContent='拖动空白旋转 · Shift 拖动平移';this.viewHint.hidden=true;host.append(this.viewHint);
  this.reducedMotion=window.matchMedia('(prefers-reduced-motion: reduce)');
  this.observer=new ResizeObserver(entries=>this.resize(entries[0]?.contentRect));this.observer.observe(host);
  this.canvas.addEventListener('pointerdown',e=>this.down(e));this.canvas.addEventListener('pointermove',e=>this.move(e));this.canvas.addEventListener('pointerup',e=>this.up(e));this.canvas.addEventListener('pointercancel',()=>this.cancel());this.canvas.addEventListener('lostpointercapture',()=>this.cancel());
  this.canvas.addEventListener('pointerleave',()=>{if(!this.drag){this.hover=null;this.tip.hidden=true;this.request();}});
  this.canvas.addEventListener('contextmenu',e=>{this.cancel();this.tip.hidden=true;contextMenu?.(this.hit(e),e);});
  this.canvas.addEventListener('wheel',e=>{e.preventDefault();e.stopPropagation();this.autoFit=false;const p=this.point(e);this.zoom={scale:Math.max(.04,Math.min(5,(this.zoom?.scale||this.scale)*Math.exp(-e.deltaY*.0015))),x:p.x,y:p.y,wx:(p.x-this.pan.x)/this.scale,wy:(p.y-this.pan.y)/this.scale};this.tip.hidden=true;this.request();},{passive:false});
  this.canvas.addEventListener('keydown',e=>{if(e.key==='0'){this.fit();e.preventDefault();}if(e.key==='Escape')this.cancel();});window.addEventListener('blur',()=>this.cancel());
 }
 resize(size){
  const r=size||this.host.getBoundingClientRect();if(!r.width||!r.height)return;
  const dpr=Math.min(devicePixelRatio||1,2);if(this.width===r.width&&this.height===r.height&&this.dpr===dpr)return;
  this.width=r.width;this.height=r.height;this.dpr=dpr;this.canvas.width=Math.round(r.width*dpr);this.canvas.height=Math.round(r.height*dpr);this.canvas.style.width=r.width+'px';this.canvas.style.height=r.height+'px';this.request();
 }
 set(data,options,current){
  const signature=JSON.stringify([options.scope,options.scope==='global'?null:current,data.headingDepth||0,data.nodes.map(n=>[n.id,n.connectionCount]),data.edges.map(e=>[e.source,e.target,e.kind])]);
  this.options=options;this.data=data;this.labelHits=[];
  if(signature===this.signature){this.current=current;data.nodes.forEach((n,i)=>Object.assign(this.nodes[i],n));this.configure(options);return;}
  const changed=current!==this.current;this.current=current;this.signature=signature;this.zoom=null;
  if(!this.outlineMode)for(const n of this.nodes)this.positions.set(n.id,{x:n.x,y:n.y,depthUnit:n.depthUnit});if(this.positions.size>3000)this.positions.clear();
  this.outlineMode=Boolean(data.headingDepth);
  this.nodes=data.nodes.map(n=>({...n}));this.topology=prepareLayout(this.nodes,data.edges,options,(this.width||300)/(this.height||350));
  for(const n of this.nodes)Object.assign(n,{depthUnit:n.current?.65:depthUnit(n.id)},this.positions.get(n.id)||seedPosition(n,this.nodes.length));
  const map=new Map(this.nodes.map(n=>[n.id,n]));this.edges=data.edges.map(e=>({...e,source:map.get(e.source),target:map.get(e.target)}));
  this.hover=null;this.tip.hidden=true;this.simulation?.stop();this.simulation=forceSimulation(this.nodes).stop().alphaDecay(.025).velocityDecay(.4);this.physicsKey='';
  if(changed){this.autoFit=true;this.scale=.85;this.pan={x:0,y:0};this.yaw=.2;this.pitch=-.12;}
  this.configure(options);
 }
 configure(options){
  this.options=options;const depth=!!options.depthView&&!this.outlineMode;this.viewHint.hidden=!depth&&!this.outlineMode;this.viewHint.textContent=this.outlineMode?'按正文顺序排列 · 拖动平移 · 滚轮缩放':'拖动空白旋转 · Shift 拖动平移';const name=options.scope==='global'?'全局关系图谱':'局部关系图谱';this.canvas.setAttribute('aria-label',this.outlineMode?'文档标题图谱，按正文顺序分层排列，点击标题跳转，拖动平移，滚轮缩放':depth?'3D '+name+'，拖动空白旋转，Shift 拖动平移，滚轮缩放，拖动节点，右键操作':name+'，滚轮缩放，拖动节点或空白平移，右键操作节点');
  if(this.depthMode!==depth){this.depthMode=depth;this.cancel();this.autoFit=true;}if(!this.simulation)return;
  if(this.outlineMode){this.topology=prepareLayout(this.nodes,this.edges,options);layoutHeadingTree(this.nodes,options);this.simulation.alpha(0);this.request();return;}
  const key=JSON.stringify([options.repulsion,options.attraction,options.linkDistance,options.center,options.nodeSize,options.folderGrouping]);
  if(key===this.physicsKey){this.request();return;}this.physicsKey=key;
  this.topology=prepareLayout(this.nodes,this.edges,options,(this.width||300)/(this.height||350));
  this.simulation.force('charge',forceManyBody().strength(-600*options.repulsion).distanceMin(20).theta(.9))
   .force('link',forceLink(this.topology.springs).id(n=>n.id).distance(options.linkDistance).strength(e=>linkStrength(e,options.attraction)))
   .force('x',forceX(n=>n.layoutX).strength(n=>n.layoutGroup ? .075 : options.center))
   .force('y',forceY(n=>n.layoutY).strength(n=>n.layoutGroup ? .075 : options.center))
   .force('collision',forceCollide(n=>n.radius+14).strength(.7).iterations(2)).alpha(.75);
  this.request();
 }
 relayout(){if(this.outlineMode)layoutHeadingTree(this.nodes,this.options);else{for(const n of this.nodes)Object.assign(n,seedPosition(n,this.nodes.length),{vx:0,vy:0,fx:null,fy:null});this.simulation?.alpha(.75);}this.fit();}
 visible(){return this.host.getClientRects().length&&this.host.clientHeight>0&&document.body.classList.contains('pin-outline')&&!document.hidden;}
 request(){if(!this.raf)this.raf=requestAnimationFrame(()=>this.frame());}
 frame(){
  this.raf=0;if(!this.visible())return;const t=performance.now();
  if(this.simulation?.alpha()>.008)this.simulation.tick();
  const zooming=this.stepZoom(),moving=this.autoFit&&this.updateCamera();this.draw();this.frames++;this.lastFrameMs=performance.now()-t;
  if(this.simulation?.alpha()>.008||moving||zooming||this.paintMoving)this.request();
 }
 stepZoom(){const z=this.zoom;if(!z)return false;const done=this.reducedMotion.matches||Math.abs(z.scale-this.scale)<.0005;this.scale=done?z.scale:this.scale+(z.scale-this.scale)*.25;this.pan={x:z.x-z.wx*this.scale,y:z.y-z.wy*this.scale};if(done)this.zoom=null;return !done;}
 blend(object,key,target){const from=object[key]??target,next=this.reducedMotion.matches||Math.abs(from-target)<.002?target:from+(target-from)*.25;object[key]=next;if(next!==target)this.paintMoving=true;return next;}
 project(){
  if(this.depthMode){const next=makeScene(this.nodes,this.yaw,this.pitch);if(!this.autoFit&&this.scene)for(const key of ['cx','cy','span','depth','focal'])next[key]=this.scene[key];this.scene=this.drag?.scene||next;for(const n of this.nodes)n.view=projectNode(n,this.scene);}
  else{this.scene=null;for(const n of this.nodes)n.view={x:n.x,y:n.y,z:0,k:1,r:n.radius,opacity:1,worldZ:0};}
  // Nodes shrink more slowly than distances when zooming out, keeping their weights readable.
  const nodeScale=Math.sqrt(1/this.scale);for(const n of this.nodes)n.view.r*=nodeScale;
 }
 updateCamera(){
  if(!this.nodes.length||!this.width||!this.height)return false;
  this.project();
  let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
  for(const n of this.nodes){const v=n.view;minX=Math.min(minX,v.x-v.r);maxX=Math.max(maxX,v.x+v.r);minY=Math.min(minY,v.y-v.r);maxY=Math.max(maxY,v.y+v.r);}
  if(this.outlineMode)for(const n of this.nodes){minX=Math.min(minX,n.x-(n.current||n.kind==='heading'?10:75));maxX=Math.max(maxX,n.x+(n.current||n.kind==='heading'?215:75));}
  const scale=Math.max(.04,Math.min(1.4,Math.max(25,this.width-68)/(maxX-minX+30),Math.max(25,this.height-90)/(maxY-minY+30))),x=-(minX+maxX)/2*scale,y=-(minY+maxY)/2*scale+8;
  const moving=Math.abs(this.scale-scale)>.0005||Math.abs(this.pan.x-x)>.15||Math.abs(this.pan.y-y)>.15,k=this.reducedMotion.matches||!moving?1:.16;
  this.scale+=(scale-this.scale)*k;this.pan.x+=(x-this.pan.x)*k;this.pan.y+=(y-this.pan.y)*k;return moving&&k<1;
 }
 fit(){this.zoom=null;this.autoFit=true;this.request();}
 color(n){if(n.kind==='heading')return nodeColor(this.paletteAccent||'#9864d8',n.headingLevel===1?6:n.headingLevel===2?3:1);const groups=this.options.groups||[];let base=n.kind==='tag'?'#c89a53':n.kind==='attachment'?'#42a2a9':!n.exists?'#9b97a4':this.paletteNode||(this.options.darkGraph?'#8e899d':'#628bb7');for(const g of groups)if(g.query.trim()&&matchQuery(n,g.query)){base=g.color;break;}return nodeColor(base,n.connectionCount??n.degree);}
 labelMetrics(text,maxWidth){
  // Labels stay 12 screen pixels throughout camera animation. Measure that
  // stable size once, instead of creating a different font size each frame.
  const limit=Math.floor(maxWidth),key=limit+':'+text,cached=this.labelCache.get(key);if(cached)return cached;
  const c=this.labelContext;let label=text,width=c.measureText(label).width;
  if(width>limit){const chars=Array.from(text);let lo=0,hi=chars.length;while(lo<hi){const mid=Math.ceil((lo+hi)/2);if(c.measureText(chars.slice(0,mid).join('')+'…').width<=limit)lo=mid;else hi=mid-1;}label=chars.slice(0,lo).join('')+'…';width=c.measureText(label).width;}
  const result={label,width};if(this.labelCache.size>=1000)this.labelCache.clear();this.labelCache.set(key,result);return result;
 }
 draw(){
  const c=this.ctx,o=this.options;if(!o||!this.width)return;
  this.project();this.paintMoving=false;this.labelHits=[];
  c.setTransform(this.dpr,0,0,this.dpr,0,0);c.clearRect(0,0,this.width,this.height);c.translate(this.width/2+this.pan.x,this.height/2+this.pan.y);c.scale(this.scale,this.scale);
  const css=getComputedStyle(this.host),textColor=o.darkGraph?'#d8d7df':css.color,accent=o.darkGraph?'#a47bff':css.getPropertyValue('--et-graph-accent').trim()||'#9864d8',edgeColor=o.darkGraph?'#a5a0ad':css.getPropertyValue('--et-graph-edge').trim()||'#77727e',graphBackground=o.darkGraph?'#111113':css.getPropertyValue('--et-graph-bg').trim()||'#f8f8fa',focused=this.hover&&this.topology.neighbors.get(this.hover.id),near=n=>!focused||n===this.hover||focused.has(n.id),dense=this.nodes.length>80;
  this.paletteNode=o.darkGraph?'':css.getPropertyValue('--et-graph-node').trim();this.paletteAccent=accent;
  c.lineWidth=o.lineWidth/this.scale;
  for(const e of this.edges){
   const a=e.source,b=e.target;if(!a||!b||!Number.isFinite(a.x+b.x))continue;const av=a.view,bv=b.view;
   const active=this.hover&&(a===this.hover||b===this.hover),length=Math.hypot(a.x-b.x,a.y-b.y,av.worldZ-bv.worldZ);
   c.strokeStyle=active||e.kind==='heading'?accent:edgeColor;c.setLineDash(e.kind==='heading'?[3/this.scale,3/this.scale]:[]);
   c.globalAlpha=this.blend(e,'renderAlpha',this.outlineMode&&e.kind==='heading'?(active?.8:focused?.18:.48):edgeOpacity(length,o.linkDistance,o.distanceFade,(av.opacity+bv.opacity)/2,!!focused,!!active,dense));
   if(this.outlineMode&&e.kind==='heading'){const bend=Math.min(8,(bv.x-av.x)/2);c.beginPath();c.moveTo(av.x,av.y+av.r);c.lineTo(av.x,bv.y-bend);c.quadraticCurveTo(av.x,bv.y,av.x+bend,bv.y);c.lineTo(bv.x-bv.r-3/this.scale,bv.y);c.stroke();continue;}
   const dx=bv.x-av.x,dy=bv.y-av.y,len=Math.hypot(dx,dy)||1,ux=dx/len,uy=dy/len;if(len<=av.r+bv.r+3/this.scale)continue;
   const x=bv.x-ux*(bv.r+3/this.scale),y=bv.y-uy*(bv.r+3/this.scale);c.beginPath();c.moveTo(av.x+ux*av.r,av.y+uy*av.r);c.lineTo(x,y);c.stroke();
   if(e.kind==='library'||o.arrows&&(!dense||active)){const s=3/this.scale;c.beginPath();c.moveTo(x-ux*s-uy*s,y-uy*s+ux*s);c.lineTo(x,y);c.lineTo(x-ux*s+uy*s,y-uy*s-ux*s);c.stroke();}
  }
  c.setLineDash([]);
  if(this.topology.grouped&&!focused){
   const groups=new Map();for(const n of this.nodes)if(n.layoutGroup){let g=groups.get(n.layoutGroup);if(!g)groups.set(n.layoutGroup,g={x:0,y:Infinity,count:0});g.x+=n.view.x;g.y=Math.min(g.y,n.view.y);g.count++;}
   c.font=(10/this.scale)+'px system-ui';c.textAlign='center';c.textBaseline='bottom';c.fillStyle=textColor;c.globalAlpha=.48;
   for(const [name,g]of groups){const label=name.split('/').pop();c.fillText(label.length>18?label.slice(0,17)+'…':label,g.x/g.count,g.y-14/this.scale);}
  }
  const labels=[],zoomLabels=dense?Math.max(0,Math.min(1,(this.scale-.08)/.24)):1,hubs=new Set(dense?this.nodes.filter(n=>n.degree>1).sort((a,b)=>(b.connectionCount??b.degree)-(a.connectionCount??a.degree)).slice(0,Math.min(12,Math.floor(this.width/30))):[]);
  const ordered=this.depthMode?this.nodes.slice().sort((a,b)=>a.view.z-b.view.z):this.nodes;
  for(const n of ordered){
   const active=near(n),v=n.view,color=n===this.hover?accent:this.color(n);c.globalAlpha=this.blend(n,'renderAlpha',(active?1:.22)*(n.current||n===this.hover?1:v.opacity));c.fillStyle=color;
   c.lineWidth=o.lineWidth/this.scale;c.beginPath();c.arc(v.x,v.y,v.r,0,Math.PI*2);
   if(n.exists)c.fill();else{c.strokeStyle=c.fillStyle;c.stroke();}
   // A translucent wash keeps the node color intact without a bright sphere highlight.
   if(n.exists&&this.depthMode&&v.r*this.scale>=5){const gradient=c.createRadialGradient(v.x-v.r*.25,v.y-v.r*.3,0,v.x,v.y,v.r);gradient.addColorStop(0,'rgba(255,255,255,.2)');gradient.addColorStop(.85,'rgba(255,255,255,0)');gradient.addColorStop(1,'rgba(255,255,255,0)');c.fillStyle=gradient;c.fill();}
   if(n.current||n===this.hover){c.globalAlpha=n.current?.85:.4;c.strokeStyle=accent;c.lineWidth=2/this.scale;c.beginPath();c.arc(v.x,v.y,v.r+4/this.scale,0,Math.PI*2);c.stroke();}
   if(this.outlineMode||n.current||n===this.hover||zoomLabels>.08||focused&&active||hubs.has(n))labels.push(n);
  }
  c.font=(12/this.scale)+'px system-ui';c.textAlign='center';c.textBaseline='top';c.fillStyle=textColor;
  const used=new LabelGrid(64/this.scale),obstacles=new LabelGrid(64/this.scale);if(!this.outlineMode)labels.sort((a,b)=>Number(b===this.hover)-Number(a===this.hover)||Number(b.current)-Number(a.current)||Number(near(b))-Number(near(a))||b.degree-a.degree);
  const left=(10-this.width/2-this.pan.x)/this.scale,right=(this.width-10-this.width/2-this.pan.x)/this.scale,top=(30-this.height/2-this.pan.y)/this.scale,bottom=(this.height-25-this.height/2-this.pan.y)/this.scale;
  for(const n of this.nodes){const v=n.view;if(v.x+v.r<left||v.x-v.r>right||v.y+v.r<top||v.y-v.r>bottom)continue;obstacles.add({node:n,x:v.x-v.r,y:v.y-v.r,w:2*v.r,h:2*v.r});}
  for(const n of labels){const v=n.view;if(v.x<left-v.r||v.x>right+v.r||v.y<top-v.r||v.y>bottom+v.r)continue;const treeLabel=this.outlineMode&&(n.current||n.kind==='heading'),start=v.x+v.r+7/this.scale,maxWidth=treeLabel?Math.max(20/this.scale,Math.min(260/this.scale,right-start)):Math.min(this.outlineMode?145:185,this.width-24)/this.scale;const metrics=this.labelMetrics(n.label,maxWidth*this.scale),label=metrics.label,w=metrics.width/this.scale,h=14/this.scale,gap=3/this.scale;
   const choices=(treeLabel?[{x:start,y:v.y-h/2}]:[{x:v.x-w/2,y:v.y+v.r+gap},{x:v.x-w/2,y:v.y-v.r-gap-h},{x:v.x+v.r+gap,y:v.y-h/2},{x:v.x-v.r-gap-w,y:v.y-h/2}]).map(r=>({...r,x:Math.max(left,Math.min(right-w,r.x)),w,h}));
   let place=choices.find(r=>r.y>=top&&r.y+h<=bottom&&!used.hits(r,null)&&!obstacles.hits(r,n));
   if(!place&&(n.current||n===this.hover))place=choices[0];if(!place)continue;used.add(place);const priority=this.outlineMode||n.current||n===this.hover||focused&&near(n)||hubs.has(n);c.globalAlpha=(n.current||n===this.hover?1:treeLabel?Math.max(.85,o.textOpacity):o.textOpacity)*(priority?1:zoomLabels)*n.renderAlpha;
   if(this.outlineMode)this.labelHits.push({...place,node:n});
   if(o.darkGraph){c.strokeStyle=graphBackground;c.lineWidth=2.5/this.scale;c.lineJoin='round';c.strokeText(label,place.x+w/2,place.y);}c.fillText(label,place.x+w/2,place.y);
  }c.globalAlpha=1;
 }
 point(e){const r=this.canvas.getBoundingClientRect();return{x:e.clientX-r.left-this.width/2,y:e.clientY-r.top-this.height/2};}
 world(e){const p=this.point(e);return{x:(p.x-this.pan.x)/this.scale,y:(p.y-this.pan.y)/this.scale};}
 hit(e){this.project();const p=this.world(e);let found=null,distance=Infinity;for(const n of this.nodes){const v=n.view,d=Math.hypot(v.x-p.x,v.y-p.y);if(d<v.r+5/this.scale&&(this.depthMode?(!found||v.z>found.view.z):d<distance)){found=n;distance=d;}}if(!found&&this.outlineMode)found=this.labelHits?.find(r=>p.x>=r.x&&p.x<=r.x+r.w&&p.y>=r.y&&p.y<=r.y+r.h)?.node;return found;}
 down(e){if(e.button!==0)return;e.preventDefault();e.stopPropagation();this.zoom=null;this.canvas.focus({preventScroll:true});this.autoFit=false;const node=this.hit(e);this.drag={node,x:e.clientX,y:e.clientY,pan:{...this.pan},yaw:this.yaw,pitch:this.pitch,rotate:!node&&this.depthMode&&!e.shiftKey,scene:node&&this.scene?this.scene:null,z:node?.view.z,moved:false};this.canvas.setPointerCapture(e.pointerId);this.tip.hidden=true;if(node&&!this.outlineMode){node.fx=node.x;node.fy=node.y;}this.request();}
 move(e){
  if(this.drag){e.preventDefault();const d=this.drag,dx=e.clientX-d.x,dy=e.clientY-d.y;d.moved ||=Math.hypot(dx,dy)>4;if(d.node&&this.outlineMode)this.pan={x:d.pan.x+dx,y:d.pan.y+dy};else if(d.node){const p=d.scene?unprojectPoint(this.world(e),d.scene,d.z):this.world(e);d.node.fx=p.x;d.node.fy=p.y;if(d.scene)d.node.depthUnit=Math.max(-2.5,Math.min(2.5,p.z/d.scene.depth));this.simulation.alpha(.3);}else if(d.rotate){this.yaw=d.yaw+dx*.008;this.pitch=Math.max(-1.3,Math.min(1.3,d.pitch+dy*.008));}else this.pan={x:d.pan.x+dx,y:d.pan.y+dy};this.request();return;}
  this.hover=this.hit(e);this.canvas.style.cursor=this.hover?'pointer':'grab';
  if(this.hover){const n=this.hover,count=n.connectionCount??n.degree;this.tip.textContent=n.kind==='heading'?n.title+'\n'+(['','一级标题','二级标题','三级标题'][n.headingLevel])+' · 点击跳转到正文':(n.relative||n.label)+'\n'+(count?'关联 '+count+' 个文件（入链与出链去重）':'孤立笔记：没有入链或出链')+(n.currentAction?'\n'+n.currentAction:'');this.tip.hidden=false;}else this.tip.hidden=true;this.request();
 }
 up(e){const d=this.drag;if(!d)return;this.drag=null;if(d.node&&!this.outlineMode){d.node.fx=null;d.node.fy=null;}if(this.canvas.hasPointerCapture(e.pointerId))this.canvas.releasePointerCapture(e.pointerId);if(!d.moved&&d.node)this.open(d.node);this.request();}
 cancel(){const d=this.drag;this.drag=null;if(d?.node&&!this.outlineMode){d.node.fx=null;d.node.fy=null;}this.tip.hidden=true;this.request();}
}
