'use strict';
class IllustratorLauncher {
 constructor(req=require){this.fs=req('fs').promises;this.path=req('path');this.cp=req('child_process');this.env=req('process').env;}
 static supports(file){return typeof file==='string'&&/\.(ai|ait|pdf|svg|svgz|eps|ps|psd|png|jpe?g|tiff?|bmp|gif)$/i.test(file);}
 async file(file){if(typeof file!=='string'||!this.path.isAbsolute(file)||file.includes('\0')||!IllustratorLauncher.supports(file))throw Error('请选择 PDF、SVG、AI 或其他图形文件');const stat=await this.fs.stat(file);if(!stat.isFile())throw Error('请选择文件，而不是文件夹');return this.path.normalize(file);}
 async executable(file){
  if(typeof file!=='string'||!this.path.isAbsolute(file)||file.includes('\0')||this.path.basename(file).toLowerCase()!=='illustrator.exe')return false;
  let handle;try{if(!(await this.fs.stat(file)).isFile())return false;handle=await this.fs.open(file,'r');const header=Buffer.alloc(2);await handle.read(header,0,2,0);return header[0]===0x4d&&header[1]===0x5a;}catch{return false;}finally{await handle?.close();}
 }
 expand(value){return value.replace(/%([^%]+)%/g,(all,key)=>Object.entries(this.env).find(([name])=>name.toLowerCase()===key.toLowerCase())?.[1]||all).replace(/^"(.*)"$/,'$1');}
 async registryPath(key){
  const reg=this.path.join(this.env.SystemRoot||'C:\\Windows','System32','reg.exe');
  return new Promise(resolve=>this.cp.execFile(reg,['query',key,'/ve'],{windowsHide:true,timeout:1500,maxBuffer:32768,encoding:'utf8'},(error,stdout)=>resolve(error?'':this.expand(String(stdout).match(/REG_(?:EXPAND_)?SZ\s+([^\r\n]+)/)?.[1]?.trim()||''))));
 }
 async discover(){
  const keys=['HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\Illustrator.exe','HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\Illustrator.exe','HKLM\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\App Paths\\Illustrator.exe'];
  const paths=await Promise.all(keys.map(key=>this.registryPath(key)));
  const roots=[this.env.ProgramW6432,this.env.ProgramFiles,this.env['ProgramFiles(x86)'],'C:\\Program Files'].filter(Boolean);
  for(const root of roots)paths.push(this.path.join(root,'Adobe','Adobe Illustrator 2026','Support Files','Contents','Windows','Illustrator.exe'));
  for(const file of new Set(paths))if(/Adobe Illustrator 2026[\\/]/i.test(file)&&await this.executable(file))return this.path.normalize(file);
  return '';
 }
 async launch(exe,file){
  file=await this.file(file);if(!await this.executable(exe))throw Object.assign(Error('Illustrator 程序路径已失效，请重新选择 Illustrator.exe'),{code:'ET_ILLUSTRATOR_PATH'});
  return new Promise((resolve,reject)=>{const child=this.cp.spawn(exe,[file],{shell:false,detached:true,stdio:'ignore',windowsHide:true,cwd:this.path.dirname(exe)});child.once('error',reject);child.once('spawn',()=>{child.unref();resolve({pid:child.pid});});});
 }
}
module.exports=IllustratorLauncher;
