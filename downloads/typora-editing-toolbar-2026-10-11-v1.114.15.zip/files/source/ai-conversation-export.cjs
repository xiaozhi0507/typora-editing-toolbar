// Portable text transcripts, independent of any provider's private session schema.
const PortableConversation = {
  reference(snapshot) {
    if(!snapshot)return '';
    const c=snapshot.context||{},parts=[];
    if(snapshot.reference?.text)parts.push(snapshot.reference.text);
    else if(c.markdown)parts.push(c.markdown);
    if(c.selected&&!parts.some(p=>p.includes(c.selected)))parts.push('选中文字：\n'+c.selected);
    return parts.join('\n\n');
  },
  messages(record,snapshot) {
    const messages=[],reference=this.reference(snapshot);
    if(reference)messages.push({role:'user',content:'以下是本次阅读的参考资料，作为引用内容供理解后续问答：\n\n'+reference});
    for(const t of record.turns){if(snapshot&&t.requestContext?.text)messages.push({role:'user',content:'本轮参考资料：\n\n'+t.requestContext.text});messages.push({role:'user',content:String(t.question||t.displayQuestion||'')});if(t.answer)messages.push({role:'assistant',content:String(t.answer)});}
    return messages;
  },
  serialize(record,format,snapshot) {
    const messages=this.messages(record,snapshot);
    if(format==='jsonl')return messages.map(m=>JSON.stringify(m)).join('\n')+'\n';
    if(format==='json')return JSON.stringify({format:'typora-ai-conversation',version:1,title:record.title,document:record.file,created:record.created,exportedAt:new Date().toISOString(),messages,turns:record.turns.map(t=>({question:t.question,displayQuestion:t.displayQuestion,answer:t.answer,...(t.reasoning?{reasoning:t.reasoning,reasoningKind:t.reasoningKind}:{}),model:t.model,time:t.time,...(Number.isFinite(t.elapsedMs)&&t.elapsedMs>=0?{elapsedMs:t.elapsedMs}:{}),status:t.status})),referenceIncluded:!!snapshot&&!!(this.reference(snapshot)||record.turns.some(t=>t.requestContext?.text))},null,2)+'\n';
    if(format!=='md')throw Error('不支持的导出格式');
    return '# '+record.title+'\n\n> 文档：'+String(record.file||'未命名文档').replace(/[\r\n]+/g,' ')+'\n\n'+(this.reference(snapshot)?'## 阅读资料\n\n'+this.reference(snapshot)+'\n\n---\n\n':'')+record.turns.map((t,i)=>'## '+(i+1)+'. 提问\n\n'+(snapshot&&t.requestContext?.text?'### 本轮参考资料\n\n'+t.requestContext.text+'\n\n':'')+(t.displayQuestion||t.question)+'\n\n### 回答\n\n'+t.answer+(t.status==='done'?'':'\n\n> 回答未完整生成。')+'\n\n> 模型：'+(t.model||'')+' · '+(t.time||'')).join('\n\n---\n\n')+'\n';
  }
};
module.exports=PortableConversation;
