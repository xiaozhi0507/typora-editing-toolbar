const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const { JSDOM } = require('jsdom');

function setup({ mode = 'float', maximized = false } = {}) {
  const dom = new JSDOM('<body><content></content><section><header></header></section></body>');
  const { window } = dom, { document } = window, frames = new Map();
  let serial = 0, layouts = 0, persists = 0;
  const Terminal = vm.runInNewContext(fs.readFileSync(__dirname + '/terminal-panel.js', 'utf8') + ';EditingToolbarTerminal', {
    window, document, innerWidth: 1400, innerHeight: 1000,
    requestAnimationFrame(fn) { frames.set(++serial, fn); return serial; },
    cancelAnimationFrame(id) { frames.delete(id); }
  });
  const t = Object.create(Terminal.prototype), panel = document.querySelector('section'), head = document.querySelector('header');
  const rect = { left: 350, top: 260, width: 640, height: 310 };
  Object.assign(t, { panel, rect: { ...rect }, mode, maximized, height: 280,
    toolbar: { panelWorkspace: { dockWidth: () => 0 } },
    menu: {}, context: {}, appearanceMenu: {}, focus() {},
    persist() { persists++; },
    layout() { layouts++; },
  });
  panel.getBoundingClientRect = () => maximized ? { left: 8, top: 52, width: 1384, height: 916 }
    : mode === 'bottom' ? { left: 0, top: 696, width: 1400, height: 280 } : rect;
  head.setPointerCapture = head.releasePointerCapture = () => {};
  const event = (type, x, y, extra = {}) => {
    const e = new window.Event(type, { cancelable: true });
    Object.assign(e, { pointerId: 1, clientX: x, clientY: y, ...extra });
    window.dispatchEvent(e); return e;
  };
  const begin = (x = 380, y = 280, kind = 'move') => t.drag({ button: 0, pointerId: 1, clientX: x, clientY: y, currentTarget: head }, kind);
  const flush = () => { const pending = [...frames.values()]; frames.clear(); pending.forEach(fn => fn()); };
  const clean = () => {
    assert.equal(frames.size, 0);
    assert.equal(document.querySelectorAll('.et-term-drag-shield,.et-term-snap-preview').length, 0);
    assert.equal(panel.style.transform, '');
    assert.equal(panel.classList.contains('et-term-moving'), false);
    assert.equal(t.moveGesture, false);
    assert.equal(t.sizeGesture, false);
    assert.equal(t.cancelDrag, null);
  };
  return { t, panel, document, begin, event, flush, frames, clean, dom, counts: () => ({ layouts, persists }) };
}

test('moving coalesces pointer samples without terminal layout and commits the final release position', () => {
  const h = setup(); h.begin();
  for (let i = 1; i <= 100; i++) h.event('pointermove', 380 + i, 280 + i / 2);
  assert.equal(h.frames.size, 1);
  h.flush();
  assert.equal(h.panel.style.transform, 'translate3d(100px,50px,0)');
  assert.deepEqual(h.counts(), { layouts: 0, persists: 0 });
  h.event('pointermove', 490, 340);
  h.event('pointerup', 500, 350);
  assert.equal(h.t.rect.left, 470); assert.equal(h.t.rect.top, 330);
  assert.deepEqual(h.counts(), { layouts: 1, persists: 1 }); h.clean();
  h.event('pointermove', 600, 500); h.flush();
  assert.equal(h.t.rect.left, 470); h.dom.window.close();
});

test('Escape and viewport resize discard pending movement and remove capture overlays', () => {
  for (const type of ['keydown', 'resize', 'pointercancel']) {
    const h = setup(); h.begin(); h.event('pointermove', 600, 500);
    const e = h.event(type, 0, 0, { key: 'Escape' });
    if (type === 'keydown') assert.equal(e.defaultPrevented, true);
    assert.equal(h.t.rect.left, 350); assert.equal(h.t.rect.top, 260);
    h.clean(); h.flush(); assert.equal(h.panel.style.transform, ''); h.dom.window.close();
  }
});

test('snap preview follows the lower window edge, hides when leaving it and commits on release', () => {
  const h = setup(); h.begin();
  h.event('pointermove', 400, 680); h.flush();
  assert.equal(h.document.querySelector('.et-term-snap-preview').hidden, false);
  assert.ok(680 < 1000 - 250, 'pointer remains far above the viewport bottom');
  h.event('pointermove', 400, 560); h.flush();
  assert.equal(h.document.querySelector('.et-term-snap-preview').hidden, true);
  h.event('pointerup', 400, 680);
  assert.equal(h.t.mode, 'bottom'); assert.equal(h.t.rect.top, 260);
  h.clean(); h.dom.window.close();
});

test('detaching a docked or maximized terminal performs one layout and Escape restores its mode', () => {
  for (const options of [{ mode: 'bottom' }, { maximized: true }]) {
    const h = setup(options), y = options.mode === 'bottom' ? 710 : 70;
    h.begin(700, y); h.event('pointermove', 710, y - 8); h.flush();
    assert.equal(h.t.mode, 'float'); assert.equal(h.t.maximized, false);
    assert.deepEqual(h.counts(), { layouts: 1, persists: 0 });
    h.event('keydown', 0, 0, { key: 'Escape' });
    assert.equal(h.t.mode, options.mode || 'float');
    assert.equal(h.t.maximized, options.maximized || false);
    h.clean(); h.dom.window.close();
  }
});

test('resizing coalesces size changes to a frame and does not lose the final release sample', () => {
  const h = setup(); h.begin(990, 570, 'se');
  for (let i = 1; i <= 40; i++) h.event('pointermove', 990 + i, 570 + i);
  assert.equal(h.frames.size, 1); assert.equal(h.counts().layouts, 0);
  h.flush(); assert.equal(h.counts().layouts, 1);
  assert.equal(h.t.rect.width, 680); assert.equal(h.t.rect.height, 350);
  h.event('pointerup', 1040, 630);
  assert.equal(h.t.rect.width, 690); assert.equal(h.t.rect.height, 370);
  h.clean(); h.dom.window.close();
});

test('resize previews never change the terminal grid until release, and cancellation leaves it unchanged', () => {
  for (const cancel of [false,true]) {
    const h=setup();let fits=0;
    h.t.active={term:{options:{}},fit:{fit(){fits++;}}};h.t.frame={clientWidth:640,clientHeight:240};h.t.layout=()=>h.t.fit();
    h.begin(990,570,'se');
    for(let i=1;i<=20;i++){h.event('pointermove',990-i*20,570+i);h.flush();}
    assert.equal(fits,0,'preview must not send intermediate sizes to ConPTY');
    if(cancel)h.event('keydown',0,0,{key:'Escape'});else h.event('pointerup',600,590);
    assert.equal(fits,1,'only the final or restored geometry is fitted');h.clean();h.dom.window.close();
  }
});


test('duplicate iframe and content notifications fit once; fonts, size and session changes refit',()=>{
 const h=setup();let fits=0;h.t.status=()=>{};
 h.t.frame={clientWidth:640,clientHeight:240};
 h.t.active={term:{options:{fontSize:12}},fit:{fit(){fits++;}}};
 h.t.fit();h.t.fit();assert.equal(fits,1);
 h.t.frame.clientWidth=600;h.t.fit();h.t.fit();assert.equal(fits,2);
 h.t.active.term.options.fontSize=14;h.t.fit();assert.equal(fits,3);
 h.t.active={term:{options:{fontSize:14}},fit:{fit(){fits++;}}};h.t.fit();assert.equal(fits,4);
 h.t.panel.hidden=true;h.t.frame.clientWidth=500;h.t.fit();assert.equal(fits,4);
 h.t.panel.hidden=false;h.t.fit();assert.equal(fits,5);h.dom.window.close();
});
