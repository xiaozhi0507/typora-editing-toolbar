const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const model=require('./paragraph-spacing.cjs');
test('corrupt and partial spacing preferences fall back to the theme',()=>{
 for(const raw of [null,'bad','null','[]','{"line":"NaN","paragraph":true}'])assert.deepEqual(model.read(raw),{line:null,paragraph:null});
 assert.deepEqual(model.read('{"line":2}'),{line:2,paragraph:null});
 assert.deepEqual(model.normalize({line:Infinity,paragraph:'1em;display:none'}),{line:null,paragraph:null});
});
test('spacing controls clamp persisted values and round to supported increments',()=>{
 assert.deepEqual(model.normalize({line:.2,paragraph:100}),{line:1,paragraph:3});
 assert.deepEqual(model.normalize({line:9,paragraph:-10}),{line:3,paragraph:0});
 assert.equal(model.value('line',1.632),1.65);assert.equal(model.value('paragraph',1.24),1.2);
});
test('reset and storage events restore the theme and do not access the editor',()=>{
 const {JSDOM}=require('jsdom'),dom=new JSDOM('<!doctype html><head></head><body><div id="write"><p>unchanged</p></div></body>',{url:'https://local.test',pretendToBeVisual:true});
 try{
  const w=dom.window;w.localStorage.setItem(model.key,'{"line":2,"paragraph":1.5}');
  const C=vm.runInNewContext(fs.readFileSync(__dirname+'/paragraph-spacing.js','utf8')+';EditingToolbarParagraphSpacing',{ETParagraphSpacing:model,document:w.document,window:w,localStorage:w.localStorage,getComputedStyle:w.getComputedStyle.bind(w),requestAnimationFrame:fn=>fn()});
  const instance=new C({_showToolbarNotice(){}}),content=w.document.querySelector('#write').innerHTML;
  assert.match(instance.style.textContent,/line-height:2.00/);
  w.dispatchEvent(new w.StorageEvent('storage',{key:model.key,newValue:null}));assert.deepEqual(JSON.parse(JSON.stringify(instance.state)),{line:null,paragraph:null});assert.equal(instance.style.textContent,model.css(null));
  instance.set('paragraph',0);assert.equal(JSON.parse(w.localStorage.getItem(model.key)).paragraph,0);
  w.dispatchEvent(new w.StorageEvent('storage',{key:null,newValue:null}));assert.equal(instance.style.textContent,model.css(null));assert.equal(w.document.querySelector('#write').innerHTML,content);
 }finally{dom.window.close();}
});
