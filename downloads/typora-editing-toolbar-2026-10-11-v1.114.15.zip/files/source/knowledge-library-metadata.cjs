'use strict';
// Read bibliographic metadata and existing abstracts; never rewrite Markdown or its sidecar.
class KnowledgeLibraryMetadata {
  constructor(store) { this.store = store; this.cache = new Map(); this.abstractCache = new Map(); this.languageCache = new Map(); this.authorCache = new Map(); }
  static equal(a, b) { return JSON.stringify(a) === JSON.stringify(b); }
  static blank(value) { return value == null || value === '' || Array.isArray(value) && !value.length; }
  static primary(item) {
    const files = (item.files || []).filter(file => file.linkType!=='url'&&/\.(md|markdown|mdown)$/i.test(file.path || ''));
    return files.find(file => file.id === item.defaultFile) || files[0];
  }
  static fields(metadata) {
    const text = value => typeof value === 'string' || typeof value === 'number' ? String(value).trim() : '';
    const list = value => [...new Set((Array.isArray(value) ? value : []).map(text).filter(Boolean))];
    const links = value => list(value).filter(url => /^https?:\/\/\S+$/i.test(url));
    const authors = (Array.isArray(metadata.authors) ? metadata.authors : []).map(author => typeof author === 'string' ? author.trim() : text(author?.name) || [text(author?.given), text(author?.family)].filter(Boolean).join(' ')).filter(Boolean);
    const doi = text(metadata.doi).replace(/^https?:\/\/(?:dx\.)?doi\.org\//i, '').replace(/^doi:\s*/i, '');
    const url = [metadata.publisher_url, metadata.doi_url, doi ? 'https://doi.org/' + doi : ''].map(text).find(value => /^https?:\/\/\S+$/i.test(value)) || '';
    const keywords = list(metadata.keywords);
    const values = {
      title: text(metadata.title_original) || text(metadata.title_zh), titleZh: text(metadata.title_zh),
      author: authors.join('；'), year: /^\d{4}$/.test(text(metadata.publication_year)) ? text(metadata.publication_year) : '',
      publicationTitle: text(metadata.journal) || text(metadata.conference), conference: text(metadata.conference),
      volume: text(metadata.volume), issue: text(metadata.issue), pages: text(metadata.pages), articleNumber: text(metadata.article_number),
      doi, url, articleType: text(metadata.article_type), affiliations: list(metadata.affiliations), keywords, tags: keywords,
      codeUrls: links(metadata.code_urls), dataUrls: links(metadata.data_urls),
      resourceUrls: [...new Set([...links(metadata.resource_urls), ...links(metadata.code_urls), ...links(metadata.data_urls)])],
      publisher: text(metadata.publisher), edition: text(metadata.edition), isbn: text(metadata.isbn), language: this.languageCode(metadata.language),
      summary: [metadata.abstract_zh, metadata.abstract, metadata.abstract_original, metadata.summary].find(value => typeof value === 'string' && value.trim())?.trim() || '',
    };
    const association = this.authorAssociation(metadata, values);
    if (association) values.authorAffiliations = association;
    return Object.fromEntries(Object.entries(values).filter(([, value]) => !this.blank(value)));
  }
  static authorKey(value) { return String(value || '').normalize('NFKC').replace(/\s+/g, ' ').trim(); }
  static authorAssociation(metadata, fields, source = 'index') {
    const names = String(fields.author || '').split('；').filter(Boolean), key = value => this.authorKey(value);
    const markers = value => [...new Set((Array.isArray(value) ? value : []).flatMap(v => typeof v === 'string' ? v.split(/[,，;；\s]+/) : []).filter(v => /^(?:[a-zA-Z]{1,3}|\d{1,3}|[*†‡]+)$/.test(v)))];
    if (!names.length || new Set(names.map(key)).size !== names.length || !Array.isArray(metadata.author_details)) return null;
    const authors = metadata.author_details.map(a => ({ name: typeof a?.name === 'string' ? a.name.trim() : '', markers: markers(a?.markers) }));
    // Match the entire ordered author list. Never attach a nearby author's markers by position alone.
    if (authors.length !== names.length || authors.some((a, n) => key(a.name) !== key(names[n]))) return null;
    const values = Array.isArray(fields.affiliations) ? fields.affiliations : [];
    const labeled = value => {
      const m = String(value).match(/^\s*([a-zA-Z]{1,3}|\d{1,3})(?:[.．)）、:]\s*|\s+)(\S[\s\S]*)$/);
      return m ? { label: m[1], text: m[2].trim() } : null;
    };
    const details = Array.isArray(metadata.affiliation_details) ? metadata.affiliation_details : values.map(labeled).filter(Boolean);
    const affiliations = [];
    for (const detail of details) {
      if (!detail || typeof detail.label !== 'string' || typeof detail.text !== 'string') continue;
      const label = detail.label.trim(), text = detail.text.trim();
      if (!/^(?:[a-zA-Z]{1,3}|\d{1,3})$/.test(label) || !text || affiliations.some(a => a.label === label)) return null;
      // Units shown by the item must be the same units the relation describes.
      if (!values.some(v => { const parsed = labeled(v); return key(v) === key(text) || parsed && parsed.label === label && key(parsed.text) === key(text); })) return null;
      affiliations.push({ label, text });
    }
    if (!affiliations.length || affiliations.length !== values.length || !authors.some(a => a.markers.some(m => affiliations.some(f => f.label === m)))) return null;
    return { authors, affiliations, author: fields.author, affiliationValues: [...values], source };
  }
  static authorAssociationFromMarkdown(markdown, fields) {
    // Legacy conversion headers can contain explicit superscripts omitted from the JSON.
    // Inspect only a labeled author line before the abstract/body; ignore examples and references.
    const header = String(markdown).replace(/^\uFEFF/, '').replace(/^---\s*\r?\n[\s\S]*?\r?\n---\s*\r?\n/, '').split(/^#{1,6}\s+(?:摘要|Abstract|\d+[.、]?\s+|Introduction|引言)/im)[0];
    let fenced = false, line = '';
    for (const row of header.split(/\r?\n/).slice(0, 100)) {
      if (/^\s*(```|~~~)/.test(row)) { fenced = !fenced; continue; }
      if (fenced) continue;
      const match = row.match(/^\s*\*\*(?:作者|Authors?)\s*[:：]\*\*\s*(.+?)\s*$/i);
      if (match) { if (line) return null; line = match[1]; }
    }
    if (!line || !/<sup\b/i.test(line)) return null;
    // Separators inside superscripts are not author separators.
    const protectedLine = line.replace(/<sup>([^<>]+)<\/sup>/gi, (_, m) => '<sup>' + m.replace(/[;；、，]/g, ',') + '</sup>');
    const authors = protectedLine.replace(/[。.]\s*$/, '').split(/[;；、，]/).map(part => {
      const m = part.trim().match(/^([^<>]+?)(?:\s*<sup>([^<>]+)<\/sup>)?$/i);
      return m ? { name: m[1].trim(), markers: m[2] ? m[2].split(',') : [] } : null;
    });
    if (authors.some(a => !a)) return null;
    return this.authorAssociation({ author_details: authors }, fields, 'markdown_header');
  }
  static authorAssociationView(item) {
    const value = item.authorAffiliations;
    if (!value || value.fileId && this.primary(item)?.id !== value.fileId || !this.equal(item.affiliations, value.affiliationValues) || this.authorKey(item.author) !== this.authorKey(value.author)) return null;
    return this.authorAssociation({ author_details: value.authors, affiliation_details: value.affiliations }, { author: item.author, affiliations: item.affiliations }, value.source);
  }
  async readAuthorAssociation(markdown, fields) {
    if (!fields.author || !fields.affiliations?.length) return null;
    const stat = await this.store.io.stat(markdown), signature = [stat.size, stat.mtimeMs, stat.ctimeMs, fields.author, JSON.stringify(fields.affiliations)].join(':'), old = this.authorCache.get(markdown);
    if (old?.signature === signature) return old.value;
    const handle = await this.store.io.open(markdown, 'r'), buffer = new Uint8Array(Math.min(stat.size, 64 * 1024)); let length = 0;
    try { while (length < buffer.length) { const r = await handle.read(buffer, length, buffer.length - length, length); if (!r.bytesRead) break; length += r.bytesRead; } } finally { await handle.close(); }
    const value = KnowledgeLibraryMetadata.authorAssociationFromMarkdown(new TextDecoder('utf-8').decode(buffer.subarray(0, length)), fields);
    this.authorCache.set(markdown, { signature, value }); if (this.authorCache.size > 1000) this.authorCache.delete(this.authorCache.keys().next().value);
    return value;
  }
  static abstractFromMarkdown(markdown, complete = true) {
    // Only explicit abstract labels qualify; incidental mentions, TOCs, YAML and code examples do not.
    const lines = markdown.replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n').replace(/<!--[\s\S]*?(?:-->|$)/g, '').split('\n');
    let fence = null, frontmatter = lines[0]?.trim() === '---';
    for (let n = 0; n < lines.length; n++) {
      const raw = lines[n];
      if (frontmatter) { lines[n] = ''; if (n && /^(---|\.\.\.)\s*$/.test(raw)) frontmatter = false; continue; }
      const marker = raw.match(/^ {0,3}(`{3,}|~{3,})(.*)$/);
      if (fence) { lines[n] = ''; if (marker && marker[1][0] === fence[0] && marker[1].length >= fence.length && !marker[2].trim()) fence = null; continue; }
      if (marker) { fence = marker[1]; lines[n] = ''; continue; }
      if (/^(?: {4}|\t)/.test(raw) || /^\s*>/.test(raw)) lines[n] = '';
    }
    const heading = n => {
      const atx = lines[n]?.match(/^ {0,3}(#{1,6})\s+(.*?)\s*#*\s*$/);
      if (atx) return { level: atx[1].length, text: atx[2], skip: 0 };
      if (lines[n]?.trim() && /^ {0,3}(?:=+|-+)\s*$/.test(lines[n+1] || '')) return { level: lines[n+1].trim()[0] === '=' ? 1 : 2, text: lines[n].trim(), skip: 1 };
      return null;
    };
    const plainLabel = text => text.replace(/\*\*|__/g, '').trim();
    const abstractLabel = text => plainLabel(text.replace(/^(\*\*|__)(Abstract|摘\s*要|中文摘要)\1\s+(\S)/i, '$2: $3')).match(/^(?:\d+(?:\.\d+)*[.)、]?\s*)?(摘\s*要|中文摘要|Abstract)(?:\s*[:：—–-]\s*(.*))?\s*$/i);
    const clean = text => text.replace(/!\[[^\]]*\]\([^\n]*?\)/g, '').replace(/\[([^\]\n]+)\]\([^\s)]*(?:\s+"[^"]*")?\)/g, '$1').replace(/\*\*([^\n]+?)\*\*|__([^\n]+?)__/g, (_, a, b) => a || b).replace(/(^|[^\w\\])\*(?=\S)([^*\n]*?\S)\*(?=$|[^\w])/g, '$1$2').replace(/`([^`\n]+)`/g, '$1').replace(/<br\s*\/?\s*>/gi, '\n').replace(/<\/?(?:p|div|span|a|b|i|em|strong|sup|sub|u)\b[^>]*>/gi, '').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
    let english = '';
    for (let n = 0; n < lines.length; n++) {
      const h = heading(n), label = abstractLabel(h?.text || lines[n]); if (!label) continue;
      const collected = label[2] ? [label[2]] : []; let ended = complete;
      for (let at = n + 1 + (h?.skip || 0); at < lines.length; at++) {
        const next = heading(at), text = plainLabel(next?.text || lines[at]);
        if (abstractLabel(text) || /^(?:关\s*键\s*词|key\s*words|index\s+terms)(?:\s*[:：]|\s|$)/i.test(text) || /^(?:\d+(?:\.\d+)*[.)、]?\s*)?(?:引言|绪论|Introduction)\s*[:：]?$/i.test(text) || next && (!h || next.level <= h.level)) { ended = true; break; }
        if (next) { collected.push(next.text); at += next.skip; } else collected.push(lines[at]);
        if (collected.join('\n').length > 30000) { ended = false; break; }
      }
      const summary = ended ? clean(collected.join('\n')) : '';
      if (!summary) continue;
      if (/摘/.test(label[1])) return summary;
      english ||= summary;
    }
    return english;
  }
  static languageCode(value){const v=String(value||'').trim().toLowerCase();return /^(?:zh|chi|zho|chinese|中文)(?:[-_]|$)/.test(v)?'zh':/^(?:en|eng|english|英文)(?:[-_]|$)/.test(v)?'en':'';}
  static detectLanguage(markdown){
    const text=String(markdown).replace(/^\uFEFF/,'').replace(/^---\s*\n[\s\S]*?\n---\s*\n/,'')
      .split(/^#{1,6}\s*(?:References|Bibliography|参考文献)\s*$/im)[0]
      .replace(/^ {0,3}(`{3,}|~{3,})[^\n]*\n[\s\S]*?^ {0,3}\1[^\n]*$/gm,'')
      .replace(/!?\[([^\]]*)\]\([^\n]*?\)/g,'$1').replace(/https?:\/\/\S+/g,'').replace(/<[^>]*>/g,'').replace(/\$\$[\s\S]*?\$\$|\$[^$\n]*\$/g,'');
    const han=(text.match(/[\u3400-\u9fff]/g)||[]).length,words=(text.match(/\b[A-Za-z]{2,}\b/g)||[]).length;
    if(han>=8&&han/(han+words)>.25)return 'zh';if(words>=10)return 'en';return '';
  }
  async readLanguage(markdown){
    const stat=await this.store.io.stat(markdown),signature=stat.size+':'+stat.mtimeMs+':'+stat.ctimeMs,old=this.languageCache.get(markdown);if(old?.signature===signature)return old.value;
    const handle=await this.store.io.open(markdown,'r'),buffer=new Uint8Array(Math.min(stat.size,512*1024));let length=0;
    try{while(length<buffer.length){const r=await handle.read(buffer,length,buffer.length-length,length);if(!r.bytesRead)break;length+=r.bytesRead;}}finally{await handle.close();}
    const value=KnowledgeLibraryMetadata.detectLanguage(new TextDecoder('utf-8').decode(buffer.subarray(0,length)));this.languageCache.set(markdown,{signature,value});if(this.languageCache.size>1000)this.languageCache.delete(this.languageCache.keys().next().value);return value;
  }
  async readAbstract(markdown) {
    const { io } = this.store;
    const stat = await io.stat(markdown);
    if (!stat.isFile()) return '';
    const signature = stat.mtimeMs + ':' + stat.ctimeMs + ':' + stat.size, cached = this.abstractCache.get(markdown);
    if (cached?.signature === signature) return cached.summary;
    // Abstracts are near the beginning; bound I/O even for books or embedded base64 images.
    const limit = Math.min(stat.size, 512 * 1024), buffer = new Uint8Array(limit), handle = await io.open(markdown, 'r');
    let length = 0;
    try { while (length < limit) { const { bytesRead } = await handle.read(buffer, length, limit - length, length); if (!bytesRead) break; length += bytesRead; } }
    finally { await handle.close(); }
    const summary = KnowledgeLibraryMetadata.abstractFromMarkdown(new TextDecoder('utf-8').decode(buffer.subarray(0, length)), stat.size <= length);
    this.abstractCache.set(markdown, { signature, summary });
    if (this.abstractCache.size > 1000) this.abstractCache.delete(this.abstractCache.keys().next().value);
    return summary;
  }
  async readFile(file) {
    if(file.linkType==='url')return null;
    const markdown = this.store.resolveFile(file), path = this.store.path;
    if (!/\.(md|markdown|mdown)$/i.test(markdown)) return null;
    const warnings = []; let record;
    try { record = await this.readIndex(file); } catch (error) { warnings.push('索引：' + error.message); }
    record ||= { file: { id: file.id, path: file.path, relative: !!file.relative }, filenameTitle: path.basename(markdown, path.extname(markdown)), fields: {} };
    if (!record.fields.authorAffiliations) {
      try { const association = await this.readAuthorAssociation(markdown, record.fields); if (association) record.fields.authorAffiliations = association; }
      catch (error) { warnings.push('作者单位关联：' + error.message); }
    }
    if (record.fields.authorAffiliations) record.fields.authorAffiliations = { ...record.fields.authorAffiliations, fileId: file.id };
    try{const language=await this.readLanguage(markdown);if(language)record.fields.language=language;}catch(error){warnings.push('语言：'+error.message);}
    if (record.fields.summary) record.summarySource = { kind: 'index' };
    if (!record.fields.summary) {
      try { const summary = await this.readAbstract(markdown); if (summary) { record.fields.summary = summary; record.summarySource = { kind: 'markdown' }; } }
      catch (error) { warnings.push('摘要：' + error.message); }
    }
    return Object.keys(record.fields).length || warnings.length ? { ...record, warnings } : null;
  }
  async readIndex(file) {
    const { io, path } = this.store, markdown = this.store.resolveFile(file), directory = path.dirname(markdown);
    if (!/\.(md|markdown|mdown)$/i.test(markdown)) return null;
    const stem = path.basename(markdown, path.extname(markdown)), indexPath = path.join(directory, '_xref', stem, 'xref-index.json');
    let stat;
    try { stat = await io.stat(indexPath); }
    catch (error) { if (['ENOENT', 'ENOTDIR'].includes(error.code)) { this.cache.delete(indexPath); return null; } throw error; }
    if (!stat.isFile() || stat.size > 16 * 1024 * 1024) throw new Error('元数据索引不是有效文件或超过 16 MB');
    const signature = stat.mtimeMs + ':' + stat.ctimeMs + ':' + stat.size;
    let cached = this.cache.get(indexPath);
    if (!cached || cached.signature !== signature) {
      const index = JSON.parse((await io.readFile(indexPath, 'utf8')).replace(/^\uFEFF/, ''));
      if (index.schema !== 'xref-sidecar-v2' || !Array.isArray(index.documents)) throw new Error('不支持的元数据索引格式');
      // Cache only bibliographic data, not the much larger citation target arrays.
      cached = { signature, documents: index.documents.map(doc => ({ markdown: doc.markdown, metadata: doc.metadata })) };
      this.cache.set(indexPath, cached);
      if (this.cache.size > 1000) this.cache.delete(this.cache.keys().next().value);
    }
    const key = value => this.store.process.platform === 'win32' ? path.normalize(value).toLowerCase() : path.normalize(value);
    const matches = cached.documents.filter(doc => typeof doc.markdown === 'string' && key(path.resolve(directory, doc.markdown)) === key(markdown));
    if (matches.length !== 1) throw new Error('索引与当前 Markdown 不匹配');
    const metadata = matches[0].metadata;
    if (!metadata || typeof metadata !== 'object' || Array.isArray(metadata)) return null;
    return { file: { id: file.id, path: file.path, relative: !!file.relative }, filenameTitle: stem, fields: KnowledgeLibraryMetadata.fields(metadata) };
  }
  async readItems(items) {
    const records = [], warnings = [];
    for (const item of items) {
      if (item.deleted) continue;
      const file = KnowledgeLibraryMetadata.primary(item); if (!file) continue;
      try { const record = await this.readFile(file); if (record) { records.push({ ...record, id: item.id }); warnings.push(...record.warnings.map(warning => file.name + '：' + warning)); } }
      catch (error) { warnings.push(file.name + '：' + error.message); }
    }
    return { records, warnings };
  }
  static allowed(item, key) {
    const common = ['title', 'titleZh', 'author', 'authorAffiliations', 'year', 'date', 'contributor', 'editor', 'translator', 'seriesEditor', 'keywords', 'tags', 'summary', 'url', 'doi', 'language', 'extra', 'libraryCatalog', 'place', 'numPages', 'thesisType', 'university'];
    const typed = item.type === 'paper' ? ['publicationTitle', 'publisher', 'conference', 'volume', 'issue', 'pages', 'articleNumber', 'doi', 'url', 'articleType', 'affiliations', 'codeUrls', 'dataUrls', 'resourceUrls', 'summary'] : item.type === 'book' ? ['publisher', 'edition', 'isbn'] : [];
    return common.includes(key) || typed.includes(key);
  }
  static automaticTags(item) {
    const meta = item.xrefMetadata || {}, tags = item.tags || [];
    // Older manually edited arrays have no per-tag evidence. Treat them as manual.
    const automatic = Array.isArray(meta.automaticTags) ? meta.automaticTags : !meta.locked?.includes('tags') && Array.isArray(meta.applied?.tags) && this.equal(tags, meta.applied.tags) ? tags : [];
    return [...new Set(automatic)].filter(tag => tags.includes(tag) && !['/done', '/reading', '/unread'].includes(tag));
  }
  static apply(item, record) {
    const file = this.primary(item);
    if (!file || !record || file.id !== record.file.id || file.path !== record.file.path || !!file.relative !== record.file.relative) return item;
    const next = JSON.parse(JSON.stringify(item));
    const previous = next.xrefMetadata || {}, applied = { ...(previous.applied || {}) }, locked = new Set(previous.locked || []), typeCleared = new Set(previous.typeCleared || []);
    let automaticTags = this.automaticTags(item);
    for (const [key, value] of Object.entries(record.fields)) {
      if (!this.allowed(item, key) || this.blank(value) || locked.has(key)) continue;
      // Migrate a manually curated legacy resource list without restoring removed URLs.
      if (key === 'resourceUrls' && !Object.hasOwn(next, key) && ['codeUrls', 'dataUrls'].some(k => locked.has(k) || !this.blank(item[k]) && (!Object.hasOwn(previous.applied || {}, k) || !this.equal(item[k], previous.applied[k])))) {
        next[key] = [...new Set([...(next.codeUrls || []), ...(next.dataUrls || [])])];
        locked.add(key); continue;
      }
      const tracked = Object.hasOwn(applied, key), current = next[key];
      if (tracked && !this.equal(current, applied[key])) { locked.add(key); continue; }
      if (tracked || this.blank(current) || key === 'title' && current === record.filenameTitle) {
        next[key] = value; applied[key] = value; typeCleared.delete(key);
        if (key === 'tags') automaticTags = [...value];
      }
    }
    next.xrefMetadata = { ...previous, version: 1, fileId: file.id, applied, locked: [...locked], automaticTags };
    if (previous.typeCleared) next.xrefMetadata.typeCleared = [...typeCleared];
    if (record.summarySource && !locked.has('summary') && this.equal(next.summary, record.fields.summary)) next.xrefMetadata.summarySource = record.summarySource;
    return this.equal(item, next) ? item : next;
  }
  static markEdited(item, values) {
    const previous = item.xrefMetadata || {}, locked = new Set(previous.locked || []), typeCleared = new Set(previous.typeCleared || []), legacyTypeLocks = new Set(previous.legacyTypeLocks || []);
    for (const [key, value] of Object.entries(values)) {
      if (!this.equal(item[key], value)) { typeCleared.delete(key); legacyTypeLocks.delete(key); }
      if (this.allowed({ ...item, type: values.type || item.type }, key) && !this.equal(item[key], value) && !(this.blank(item[key]) && this.blank(value))) locked.add(key);
    }
    const automaticTags = this.automaticTags(item).filter(tag => (values.tags || item.tags || []).includes(tag));
    return { ...item, xrefMetadata: { ...previous, version: 1, applied: previous.applied || {}, locked: [...locked], automaticTags, ...(previous.typeCleared ? { typeCleared: [...typeCleared] } : {}), ...(previous.legacyTypeLocks ? { legacyTypeLocks: [...legacyTypeLocks] } : {}) } };
  }
  static changeType(item, type, losses, supported, previousSupported) {
    const previous = item.xrefMetadata || {}, cleared = new Set(previous.typeCleared || []), allowed = new Set(supported), oldAllowed = new Set(previousSupported);
    // Keep old unresolved locks across intermediate conversions. An empty
    // typeCleared array alone must not discard the remaining legacy candidates.
    const legacyTypeLocks = new Set(previous.legacyTypeLocks || (!Array.isArray(previous.typeCleared) ? (previous.locked || []).filter(key => this.blank(item[key]) && !Object.hasOwn(previous.applied || {}, key)) : []));
    for (const key of legacyTypeLocks) {
      if (!this.blank(item[key]) || Object.hasOwn(previous.applied || {}, key)) { legacyTypeLocks.delete(key); continue; }
      if (!oldAllowed.has(key) && allowed.has(key)) { cleared.add(key); legacyTypeLocks.delete(key); }
    }
    const values = { type }; for (const key of losses) values[key] = Array.isArray(item[key]) ? [] : '';
    const next = { ...this.markEdited(item, values), ...values }, meta = next.xrefMetadata;
    const locked = new Set(meta.locked), applied = { ...meta.applied };
    for (const key of losses) { cleared.add(key); legacyTypeLocks.delete(key); locked.add(key); delete applied[key]; }
    for (const key of cleared) if (allowed.has(key)) {
      if (this.blank(next[key])) { locked.delete(key); delete applied[key]; }
      else cleared.delete(key);
    }
    next.xrefMetadata = { ...meta, applied, locked: [...locked], typeCleared: [...cleared], ...(legacyTypeLocks.size || previous.legacyTypeLocks ? { legacyTypeLocks: [...legacyTypeLocks] } : {}) };
    return next;
  }
}
module.exports = KnowledgeLibraryMetadata;
