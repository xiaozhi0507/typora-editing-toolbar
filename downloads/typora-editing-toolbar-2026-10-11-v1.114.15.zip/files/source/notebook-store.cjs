'use strict';
// Keep the complete nbformat tree: extension metadata, attachments and MIME bundles round-trip.
const clone = value => typeof structuredClone==='function'?structuredClone(value):JSON.parse(JSON.stringify(value));
const source = cell => Array.isArray(cell.source) ? cell.source.join('') : cell.source || '';
function normalize(doc, uuid) {
 if (!doc || doc.nbformat !== 4 || !Array.isArray(doc.cells)) throw Error('仅支持 nbformat 4 Notebook');
 const ids = new Set();
 for (const cell of doc.cells) {
  if (!cell || !['code','markdown','raw'].includes(cell.cell_type) || !(typeof cell.source==='string'||Array.isArray(cell.source)&&cell.source.every(x=>typeof x==='string'))) throw Error('Notebook 单元格格式无效');
  if (!cell.id || !/^[a-zA-Z0-9_-]{1,64}$/.test(cell.id) || ids.has(cell.id)) cell.id=uuid();
  ids.add(cell.id);cell.metadata ||= {};
  if(cell.cell_type==='code'){cell.outputs ||= [];cell.execution_count ??= null;if(!Array.isArray(cell.outputs))throw Error('Notebook 输出格式无效');}
 }
 doc.metadata ||= {};doc.nbformat_minor=Math.max(5,doc.nbformat_minor||0);return doc;
}
function newCell(type='code',text='',id){return {cell_type:type,id,metadata:{},source:text,...(type==='code'?{outputs:[],execution_count:null}:{})};}
function blank(uuid){return {nbformat:4,nbformat_minor:5,metadata:{kernelspec:{display_name:'Python 3',language:'python',name:'python3'},language_info:{name:'python'}},cells:[newCell('markdown','# Notebook',uuid()),newCell('code','',uuid())]};}
function apply(doc, edits, uuid){
 const next=clone(doc);if(!Array.isArray(edits)||!edits.length||edits.length>100)throw Error('请提供 1–100 项单元格修改');
 for(const edit of edits){
  const i=next.cells.findIndex(c=>c.id===edit.cell_id);
  if(edit.action==='insert'){
   if(edit.after_id && !next.cells.some(c=>c.id===edit.after_id))throw Error('插入位置已不存在');
   if(!['code','markdown','raw'].includes(edit.cell_type||'code')||typeof edit.source!=='string')throw Error('插入内容无效');
   next.cells.splice(edit.after_id?next.cells.findIndex(c=>c.id===edit.after_id)+1:0,0,newCell(edit.cell_type||'code',edit.source,uuid()));
  }else{
   if(i<0)throw Error('单元格已不存在，请重新读取 Notebook');
   const c=next.cells[i];
   if(edit.action==='delete')next.cells.splice(i,1);
   else if(edit.action==='move'){
    if(edit.after_id===c.id)continue;
    if(edit.after_id&&!next.cells.some(x=>x.id===edit.after_id))throw Error('移动位置已不存在');
    next.cells.splice(i,1);next.cells.splice(edit.after_id?next.cells.findIndex(x=>x.id===edit.after_id)+1:0,0,c);
   }else if(edit.action==='replace'){
    if(typeof edit.source!=='string')throw Error('单元格内容无效');
    c.source=edit.source;
    if(edit.cell_type&&edit.cell_type!==c.cell_type){if(!['code','markdown','raw'].includes(edit.cell_type))throw Error('单元格类型无效');c.cell_type=edit.cell_type;if(c.cell_type==='code'){c.outputs=[];c.execution_count=null;}else{delete c.outputs;delete c.execution_count;}}
    if(c.cell_type==='code'&&c.outputs.length)c.metadata.et_output_stale=true;
   }else throw Error('未知单元格操作');
  }
 }
 return normalize(next,uuid);
}
function describe(doc, ids){return doc.cells.filter(c=>!ids?.length||ids.includes(c.id)).map(c=>({id:c.id,cell_type:c.cell_type,source:source(c),execution_count:c.execution_count,output_count:c.outputs?.length||0}));}
function reviewText(doc,ids){return doc.cells.flatMap((c,i)=>!ids||ids.has(c.id)?[`# 单元格 ${i+1} · ${c.cell_type} · ${c.id}\n${source(c)}`]:[]).join('\n\n');}
function sourceState(doc){return JSON.stringify({...doc,cells:doc.cells.map(c=>{const {outputs,execution_count,...rest}=c,{et_output_stale,et_output_truncated,...metadata}=c.metadata||{};return {...rest,source:source(c),metadata};})});}
function withoutOutputs(doc){return {...doc,cells:doc.cells.map(c=>{const {outputs,...rest}=c;return {...rest,...(c.cell_type==='code'?{outputs:[],execution_count:null}:{})};})};}
function restoreSource(before,current){const doc=clone(before);for(const c of doc.cells){const live=current.cells.find(x=>x.id===c.id&&x.cell_type===c.cell_type);if(c.cell_type==='code'&&live){c.outputs=clone(live.outputs);c.execution_count=live.execution_count;if(source(c)!==source(live)&&c.outputs.length)c.metadata.et_output_stale=true;}}return doc;}
class NotebookStore {
 constructor(requireNode){this.require=requireNode;this.fs=requireNode('fs');this.path=requireNode('path');this.crypto=requireNode('crypto');this.Buffer=requireNode('buffer').Buffer;this.uuid=()=>this.crypto.randomUUID();this.jobs=new Map();this.serial=0;}
 codec(op,value,indent){
  if(!this.worker){
   const browser=typeof document!=='undefined'&&typeof globalThis.Worker==='function',run="try{send({id:m.id,value:m.op==='parse'?JSON.parse(m.value):JSON.stringify(m.value,null,m.indent)});}catch(e){send({id:m.id,error:e.message});}";
   if(browser){this.workerURL=URL.createObjectURL(new Blob(["const send=m=>postMessage(m);self.onmessage=e=>{const m=e.data;"+run+"};"],{type:'application/javascript'}));this.worker=new globalThis.Worker(this.workerURL);}else{const {Worker}=this.require('worker_threads');this.worker=new Worker("const {parentPort}=require('node:worker_threads');const send=m=>parentPort.postMessage(m);parentPort.on('message',m=>{"+run+"});",{eval:true});}
   const owned=this.worker,message=m=>{const p=this.jobs.get(m.id);if(!p)return;this.jobs.delete(m.id);m.error?p.reject(Error(m.error)):p.resolve(m.value);if(!this.jobs.size){owned.unref?.();clearTimeout(this.codecTimer);this.codecTimer=setTimeout(()=>this.dispose(),10000);this.codecTimer.unref?.();}},error=e=>{for(const p of this.jobs.values())p.reject(Error(e.message||'Notebook 后台解析失败'));this.jobs.clear();this.dispose();};
   if(browser){owned.onmessage=e=>message(e.data);owned.onerror=error;}else{owned.on('message',message);owned.on('error',error);}
  }
  clearTimeout(this.codecTimer);this.worker.ref?.();const id=++this.serial;return new Promise((resolve,reject)=>{this.jobs.set(id,{resolve,reject});this.worker.postMessage({id,op,value,indent});});
 }
 dispose(){if(this.jobs.size)return;clearTimeout(this.codecTimer);this.worker?.terminate();this.worker=null;if(this.workerURL){URL.revokeObjectURL(this.workerURL);this.workerURL=null;}}

 async read(file){
  if(!this.path.isAbsolute(file)||!/\.ipynb$/i.test(file))throw Error('请选择 .ipynb 文件');
  const real=await this.fs.promises.realpath(file),stat=await this.fs.promises.stat(real);if(!stat.isFile()||stat.size>64*1024*1024)throw Error('Notebook 超过 64 MB，请先清理大型输出');
  const base=await this.fs.promises.readFile(real),text=new TextDecoder('utf-8',{fatal:true}).decode(base).replace(/^\uFEFF/,'');
  const doc=normalize(await this.codec('parse',text),this.uuid);return {file:real,base,doc,saved:await this.codec('stringify',doc),mode:stat.mode};
 }
 async unchanged(r){try{return (await this.fs.promises.realpath(r.file)).toLowerCase()===r.file.toLowerCase()&&(await this.fs.promises.readFile(r.file)).equals(r.base);}catch{return false;}}
 async save(r,doc=r.doc,beforeCommit){
  const text=(await this.codec('stringify',normalize(clone(doc),this.uuid),1))+'\n',base=this.Buffer.from(text,'utf8');
  if(base.length>64*1024*1024)throw Error('Notebook 超过 64 MB，请清理大型输出后保存');
  const temp=r.file+'.'+this.uuid()+'.tmp';
  try{await this.fs.promises.writeFile(temp,base,{flag:'wx',mode:r.mode});if(!await this.unchanged(r))throw Error('磁盘文件已变化，当前草稿保留；请重新载入或另存为');await beforeCommit?.();await this.fs.promises.rename(temp,r.file);}finally{await this.fs.promises.unlink(temp).catch(()=>{});}
  return {...r,base,doc,saved:await this.codec('stringify',doc)};
 }
}
module.exports={NotebookStore,clone,source,normalize,newCell,blank,apply,describe,reviewText,sourceState,restoreSource,withoutOutputs};
