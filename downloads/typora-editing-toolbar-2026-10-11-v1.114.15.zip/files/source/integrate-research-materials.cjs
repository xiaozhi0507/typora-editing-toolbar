const fs=require('node:fs'),path=require('node:path');
module.exports=code=>{
 const replace=(a,b)=>{if(!code.includes(a))throw Error('Missing research integration '+a.slice(0,80));code=code.replace(a,b);};
 replace('this.manualMarks=new EditingToolbarManualMarks(this);','this.manualMarks=new EditingToolbarManualMarks(this);this.researchMaterials=new EditingToolbarResearchMaterials(this);');
 replace("this.isManualMark?'标注摘录.md':this.isDocumentNote?'笔记.md':'阅读笔记.md'","this.isResearchMaterial?'素材摘录.md':this.isManualMark?'标注摘录.md':this.isDocumentNote?'笔记.md':'阅读笔记.md'");
 replace('if(!this.panel.hidden)this.tabs?.render();', 'if(!this.panel.hidden){this.tabs?.render();this.toolbar.researchMaterials?._renderList();}');
 replace('onFocus:()=>this.toolbar.hide(),onBlur:', 'onFocus:()=>{this.toolbar.hide();this.toolbar.researchMaterials?.cardMenu?.remove();},onBlur:');
 const pos=code.lastIndexOf('(function () {');if(pos<0)throw Error('Missing boot');
 return code.slice(0,pos)+['research-material-store.js','research-materials.js','research-material-transfer.js'].map(f=>fs.readFileSync(path.join(__dirname,f),'utf8')).join('\n')+'\n'+code.slice(pos);
};
