'use strict';
class DocumentProjects {
 constructor(req=require){this.fs=req('fs').promises;this.path=req('path');this.crypto=req('crypto');}
 name(value,max=120){if(typeof value!=='string'||!value.trim()||value.length>max||/[\\/:*?"<>|\x00-\x1f]/.test(value)||/[. ]$/.test(value)||/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(value)||value==='.'||value==='..')throw Error('请输入有效的名称，不包含路径或特殊字符');return value.trim();}
 async plan(name,folder,library){name=this.name(name);if(!folder&&!library)throw Error('请先设置知识库文件夹，或选择项目文件夹');let parent,anchor;const requested=folder||library;if(!this.path.isAbsolute(requested))throw Error('请选择完整的文件夹路径');try{parent=await this.fs.realpath(requested);anchor=parent;}catch(e){if(folder||e.code!=='ENOENT')throw e;let cursor=this.path.resolve(library),tail=[];for(;;){try{anchor=await this.fs.realpath(cursor);parent=this.path.join(anchor,...tail);break;}catch(e){if(e.code!=='ENOENT'||cursor===this.path.dirname(cursor))throw e;tail.unshift(this.name(this.path.basename(cursor)));cursor=this.path.dirname(cursor);}}}if(!(await this.fs.stat(anchor)).isDirectory())throw Error('请选择文件夹');const root=folder?parent:this.path.join(parent,name);if(!folder){try{await this.fs.lstat(root);throw Error('已有同名文件夹，请选择该文件夹或使用其他名称');}catch(e){if(e.code!=='ENOENT')throw e;}}return {name,root,parent,anchor,create:!folder};}
 async trust(plan){if(await this.fs.realpath(plan.anchor||plan.parent)!==(plan.anchor||plan.parent))throw Error('文件夹已发生变化，请重新选择');if(plan.parent!==plan.anchor)await this.fs.mkdir(plan.parent,{recursive:true});if(await this.fs.realpath(plan.parent)!==plan.parent)throw Error('文件夹已发生变化，请重新选择');if(plan.create)await this.fs.mkdir(plan.root);const realRoot=await this.fs.realpath(plan.root);if(realRoot!==plan.root)throw Error('文件夹已发生变化，请重新选择');return {id:Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8),name:plan.name,root:realRoot,trusted:true};}
 async check(project){if(!project?.trusted||!this.path.isAbsolute(project.root||''))throw Error('请先创建并信任项目文件夹');if(!(await this.fs.stat(project.root)).isDirectory())throw Error('项目路径不是文件夹，请重新选择');if(await this.fs.realpath(project.root)!==project.root)throw Error('项目文件夹已移动或链接已更改，请重新选择并信任');return project.root;}
 segments(relative){if(typeof relative!=='string'||relative.length>240||/^[\\/]|^[a-z]:/i.test(relative))throw Error('请使用项目内的相对路径');const segments=relative.replace(/\\/g,'/').split('/');for(const part of segments)this.name(part);return segments;}
 async directory(project,segments,create=false){let folder=await this.check(project);for(const part of segments){folder=this.path.join(folder,part);try{const stat=await this.fs.lstat(folder);if(!stat.isDirectory()||stat.isSymbolicLink())throw Error('项目内路径不是普通文件夹');}catch(e){if(e.code!=='ENOENT'||!create)throw e;await this.fs.mkdir(folder);}const real=await this.fs.realpath(folder);if(real!==folder)throw Error('不能通过链接写入项目外部');}return folder;}
 async createFile(project,relative,content){if(typeof content!=='string'||Buffer.byteLength(content)>1024*1024||content.includes('\0'))throw Error('文件必须是 1 MB 以内的文本');const parts=this.segments(relative),name=parts.pop();const folder=await this.directory(project,parts,true),file=this.path.join(folder,name);await this.check(project);let handle;try{handle=await this.fs.open(file,'wx');await handle.writeFile(content,'utf8');}catch(e){if(e.code==='EEXIST')throw Error('文件已存在，请换一个名称');throw e;}finally{await handle?.close();}return {path:file,relative:parts.concat(name).join('/'),bytes:Buffer.byteLength(content)};}
 async createFolder(project,relative,name){name=this.name(name);const parts=relative?this.segments(relative):[],parent=await this.directory(project,parts),folder=this.path.join(parent,name);await this.check(project);try{await this.fs.mkdir(folder);}catch(e){if(e.code==='EEXIST')throw Error('已有同名文件或文件夹，请换一个名称');throw e;}return {path:folder,relative:parts.concat(name).join('/')};}
 async existingFile(project,file){await this.check(project);const relative=this.path.relative(project.root,file),parts=this.segments(relative),name=parts.pop(),folder=await this.directory(project,parts);const target=this.path.join(folder,name),stat=await this.fs.lstat(target);if(!stat.isFile()||stat.isSymbolicLink()||await this.fs.realpath(target)!==target)throw Error('请选择项目内的普通文件');return {path:target,stat};}
 contains(folder,file){if(typeof file!=='string'||!file)return false;const relative=this.path.relative(folder,file);return !relative||relative!=='..'&&!relative.startsWith('..'+this.path.sep)&&!this.path.isAbsolute(relative);}
 async folderSnapshot(project,relative){const parts=this.segments(relative),folder=await this.directory(project,parts),stat=await this.fs.lstat(folder);if(!parts.length||folder===project.root||!stat.isDirectory()||stat.isSymbolicLink())throw Error('只能删除项目内的普通子文件夹');return {path:folder,relative:parts.join('/'),dev:stat.dev,ino:stat.ino,mtimeMs:stat.mtimeMs,ctimeMs:stat.ctimeMs};}
 async trashFolder(project,before,trash){const current=await this.folderSnapshot(project,before.relative);if(['path','dev','ino','mtimeMs','ctimeMs'].some(k=>current[k]!==before[k]))throw Error('文件夹已变化，请关闭弹窗后重新确认删除');if(!await trash(current.path))throw Error('无法移到回收站，文件夹仍被保留');return current;}
 async renameFolder(project,before,name){
  name=this.name(name);const current=await this.folderSnapshot(project,before.relative);
  if(['path','dev','ino'].some(k=>current[k]!==before[k]))throw Error('文件夹已变化，请重新打开重命名');
  const target=this.path.join(this.path.dirname(current.path),name);
  if(!this.contains(project.root,target)||target===project.root)throw Error('只能重命名项目内的子文件夹');
  if(target===current.path)return {from:current.path,to:target};
  try{const stat=await this.fs.lstat(target);if(target.toLowerCase()!==current.path.toLowerCase()||stat.dev!==current.dev||stat.ino!==current.ino)throw Error('已有同名文件或文件夹，请换一个名称');}catch(e){if(e.code!=='ENOENT')throw e;}
  await this.directory(project,this.segments(before.relative).slice(0,-1));
  // Windows directory rename is atomic and fails when the target already exists.
  await this.fs.rename(current.path,target);return {from:current.path,to:target};
 }
 async renameFile(project,file,name){
  name=this.name(name);const source=await this.existingFile(project,file),target=this.path.join(this.path.dirname(source.path),name);if(target===source.path)return {from:source.path,to:target};
  if(target.toLowerCase()===source.path.toLowerCase()){await this.fs.rename(source.path,target);return {from:source.path,to:target};}
  try{await this.fs.link(source.path,target);}catch(e){if(e.code==='EEXIST')throw Error('已有同名文件，请换一个名称');throw e;}
  try{const stat=await this.fs.lstat(source.path);if(stat.ino!==source.stat.ino||stat.size!==source.stat.size||stat.mtimeMs!==source.stat.mtimeMs)throw Error('文件在重命名期间发生变化，未完成重命名');await this.fs.unlink(source.path);}catch(e){await this.fs.lstat(target).then(s=>{if(s.ino===source.stat.ino&&s.dev===source.stat.dev)return this.fs.unlink(target);}).catch(()=>{});throw e;}
  return {from:source.path,to:target};
 }

 async droppedFile(file){
  if(typeof file!=='string'||!this.path.isAbsolute(file)||file.includes('\0'))throw Error('未能取得本机文件路径，请从资源管理器重新拖入');
  const target=this.path.resolve(file),stat=await this.fs.lstat(target);this.name(this.path.basename(target),255);
  if(!stat.isFile()||stat.isSymbolicLink())throw Error('请拖入普通文件；暂不移动整个文件夹或链接');
  if((await this.fs.realpath(target)).toLowerCase()!==target.toLowerCase())throw Error('不能通过链接移动文件，请使用实际文件路径');
  return {path:target,stat};
 }
 sameFile(a,b,content=true){return a.dev===b.dev&&a.ino===b.ino&&(!content||a.size===b.size&&a.mtimeMs===b.mtimeMs);}
 async digest(file){const handle=await this.fs.open(file,'r'),hash=this.crypto.createHash('sha256');try{for await(const chunk of handle.createReadStream({autoClose:false,highWaterMark:256*1024}))hash.update(chunk);return hash.digest('hex');}finally{await handle.close();}}
 async copyDropped(source,target,onReserved=()=>{}){
  const input=await this.fs.open(source,'r');let output;const hash=this.crypto.createHash('sha256');
  try{output=await this.fs.open(target,'wx');onReserved(await output.stat());for await(const chunk of input.createReadStream({autoClose:false,highWaterMark:256*1024})){hash.update(chunk);let offset=0;while(offset<chunk.length){const {bytesWritten}=await output.write(chunk,offset,chunk.length-offset);if(!bytesWritten)throw Error('无法写入目标文件');offset+=bytesWritten;}}await output.sync();return hash.digest('hex');}
  finally{await output?.close();await input.close();}
 }
 async transferFiles(project,files,relative='',{copy=false,validate=async()=>{},progress=()=>{}}={}){
  if(!Array.isArray(files)||!files.length||files.length>100)throw Error('每次可拖入 1–100 个文件');
  const parts=relative?this.segments(relative):[],folder=await this.directory(project,parts),plans=[],seen=new Set(),sources=new Set();
  for(const file of files){const source=await this.droppedFile(file),key=source.path.toLowerCase();if(sources.has(key))continue;sources.add(key);const target=this.path.join(folder,this.path.basename(source.path));if(key===target.toLowerCase())continue;if(seen.has(target.toLowerCase()))throw Error('所选文件包含同名文件，请分别拖入');seen.add(target.toLowerCase());try{await this.fs.lstat(target);throw Error('目标已有同名文件：'+this.path.basename(target)+'。请先重命名或移走该文件');}catch(e){if(e.code!=='ENOENT')throw e;}plans.push({...source,target});}
  const created=[];let failure;
  try{
   await validate();
   for(const p of plans){await this.directory(project,parts);if(!this.sameFile((await this.droppedFile(p.path)).stat,p.stat))throw Error('源文件已变化，请重新拖入');
    if(!copy){try{await this.fs.link(p.path,p.target);p.linked=true;p.created=p.stat;created.push(p);p.created=await this.fs.lstat(p.target);}catch(e){if(!['EXDEV','ENOTSUP','EOPNOTSUPP','EPERM'].includes(e.code))throw e;}}
    if(!p.linked){p.hash=await this.copyDropped(p.path,p.target,s=>{p.created=s;created.push(p);});p.created=await this.fs.lstat(p.target);if(await this.digest(p.target)!==p.hash)throw Error('目标文件校验失败，原文件已保留');}
    progress(created.length,plans.length);
   }
   await validate();await this.directory(project,parts);
   for(const p of plans){const s=await this.droppedFile(p.path),d=await this.fs.lstat(p.target);if(!this.sameFile(s.stat,p.stat)||!this.sameFile(d,p.created)||p.linked&&!this.sameFile(s.stat,d))throw Error('传输期间文件发生变化，未完成移动');if(!p.linked&&(await this.digest(p.path)!==p.hash||await this.digest(p.target)!==p.hash))throw Error('传输期间文件内容发生变化，原文件已保留');}
   if(!copy)for(const p of plans){await validate();await this.directory(project,parts);if(!this.sameFile((await this.droppedFile(p.path)).stat,p.stat)||!this.sameFile(await this.fs.lstat(p.target),p.created))throw Error('移动期间文件发生变化');await this.fs.unlink(p.path);p.removed=true;}
  }catch(error){failure=error;const retained=[];
   for(const p of created.reverse()){try{const d=await this.fs.lstat(p.target);if(!this.sameFile(d,p.created,false))throw Error('目标路径已变化');if(p.removed){if(p.linked)await this.fs.link(p.target,p.path);else await this.copyDropped(p.target,p.path);p.removed=false;}if(!p.linked&&p.hash&&await this.digest(p.target)!==p.hash)throw Error('目标内容已变化');await this.fs.unlink(p.target);}catch{retained.push(p.target);}}
   error.moves=plans.filter(p=>p.removed).map(p=>({from:p.path,to:p.target}));if(retained.length)error.message+='；以下副本已保留，请检查：'+retained.join('、');
   if(error.code==='EEXIST')error.message='目标出现同名文件，未覆盖现有文件。'+error.message;
  }
  if(failure)throw failure;return plans.map(p=>({from:p.path,to:p.target}));
 }

 async moveFiles(project,files,relative=''){
  if(!Array.isArray(files)||!files.length||files.length>100)throw Error('每次可移动 1–100 个项目文件');
  const folder=await this.directory(project,relative?this.segments(relative):[]),plans=[],seen=new Set();
  for(const file of files){const source=await this.existingFile(project,file),target=this.path.join(folder,this.path.basename(source.path));if(source.path.toLowerCase()===target.toLowerCase())continue;if(seen.has(target.toLowerCase()))throw Error('所选文件包含同名文件，未移动');seen.add(target.toLowerCase());try{await this.fs.lstat(target);throw Error('目标已有同名文件：'+this.path.basename(target));}catch(e){if(e.code!=='ENOENT')throw e;}plans.push({...source,target});}
  // Exclusive hard links keep bytes/metadata intact and cannot overwrite a destination.
  // All targets are reserved before any source is removed; failures restore sources.
  const linked=[];
  try{
   for(const p of plans){await this.existingFile(project,p.path);await this.directory(project,relative?this.segments(relative):[]);await this.fs.link(p.path,p.target);linked.push(p);}
   for(const p of plans){const s=await this.fs.lstat(p.path),d=await this.fs.lstat(p.target);if(s.ino!==p.stat.ino||d.ino!==s.ino||s.size!==p.stat.size||s.mtimeMs!==p.stat.mtimeMs)throw Error('移动期间文件发生变化，未完成移动');}
   for(const p of plans){await this.fs.unlink(p.path);p.removed=true;}
  }catch(error){for(const p of linked.reverse()){try{const d=await this.fs.lstat(p.target);if(d.ino!==p.stat.ino)continue;if(p.removed)await this.fs.link(p.target,p.path);await this.fs.unlink(p.target);}catch{error.message+='；部分路径需要检查：'+p.path;}}if(['EPERM','ENOTSUP','EXDEV'].includes(error.code))error.message='此文件系统无法安全移动文件，原文件已保留：'+error.message;throw error;}
  return plans.map(p=>({from:p.path,to:p.target}));
 }
 async list(project,relative=''){const parts=relative?this.segments(relative):[],folder=await this.directory(project,parts);const entries=await this.fs.readdir(folder,{withFileTypes:true});return entries.filter(e=>!e.isSymbolicLink()&&!(e.isDirectory()&&['.git','node_modules','__pycache__'].includes(e.name))).sort((a,b)=>Number(b.isDirectory())-Number(a.isDirectory())||a.name.localeCompare(b.name)).slice(0,200).map(e=>({name:e.name,directory:e.isDirectory(),path:this.path.join(folder,e.name),relative:parts.concat(e.name).join('/')}));}
}
module.exports=DocumentProjects;
