import {Plugin, TextSelection} from 'prosemirror-state';
import {Decoration, DecorationSet} from 'prosemirror-view';

// Empty inline code is a typing mark, not document content. Keep its cue in
// decorations so saving, copying and undo never introduce placeholder text.
export function pendingInlineCode(state){
 const {selection,storedMarks,schema}=state,code=schema.marks.code;
 if(!(selection instanceof TextSelection)||!selection.empty||!code)return false;
 const {$from}=selection;
 return $from.parent.type.allowsMarkType(code)
  &&Boolean(code.isInSet(storedMarks||$from.marks()))
  &&![$from.nodeBefore,$from.nodeAfter].some(n=>n?.isText&&code.isInSet(n.marks));
}

export function inlineCodePlaceholder(){
 return new Plugin({props:{
  decorations(state){
   if(!pendingInlineCode(state))return null;
   return DecorationSet.create(state.doc,[Decoration.widget(state.selection.from,view=>{
    const cue=document.createElement('span');
    cue.className='note-code-placeholder';
    cue.dataset.placeholder='输入代码';
    cue.setAttribute('aria-hidden','true');
    cue.title='输入行内代码，按 Esc 取消';
    cue.addEventListener('mousedown',event=>{
     if(event.button!==0)return;
     event.preventDefault();view.focus();
    });
    return cue;
   },{side:1,marks:[],key:'empty-inline-code',stopEvent:event=>event.type==='mousedown'})]);
  },
  handleKeyDown(view,event){
   if(!view.editable||event.isComposing||event.keyCode===229||event.ctrlKey||event.metaKey||event.altKey||event.shiftKey
    ||!['Escape','Backspace','Delete'].includes(event.key)||!pendingInlineCode(view.state))return false;
   view.dispatch(view.state.tr.removeStoredMark(view.state.schema.marks.code));
   return true;
  }
 }});
}
