using System;
using System.IO;
using System.IO.Pipes;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.Web.Script.Serialization;

// GUI subsystem: Explorer starts this without a console or an editor window.
internal static class DocumentOpenLauncher {
    internal sealed class WindowInfo {
        public int version { get; set; }
        public int pid { get; set; }
        public string pipe { get; set; }
        public string file { get; set; }
        public string[] tabs { get; set; }
        public long focused { get; set; }
        public bool ready { get; set; }
    }
    static readonly JavaScriptSerializer Json=new JavaScriptSerializer();
    static string trace;
    static void Trace(string stage,string detail="") {
        try {
            if(String.IsNullOrEmpty(trace))return;
            if(File.Exists(trace)&&new FileInfo(trace).Length>65536)File.Delete(trace);
            File.AppendAllText(trace,Json.Serialize(new {at=DateTime.UtcNow.ToString("o"),pid=Process.GetCurrentProcess().Id,stage=stage,detail=detail})+Environment.NewLine,new UTF8Encoding(false));
        } catch {}
    }
    static string Key(string file) { try{return String.IsNullOrEmpty(file)?"":Path.GetFullPath(file).Replace('\\','/').ToLowerInvariant();}catch{return "";} }
    static string Prefix(string profile) { using(var hash=SHA256.Create())return "et-typora-open-"+BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(Key(profile)))).Replace("-","").ToLowerInvariant().Substring(0,24)+"-"; }
    static bool Supported(string file) { return new[]{".md",".markdown",".mdown",".mkd",".mkdn"}.Contains(Path.GetExtension(file).ToLowerInvariant()); }
    static List<WindowInfo> Windows(string profile,string prefix) {
        var result=new List<WindowInfo>();var dir=Path.Combine(profile,"editing-toolbar-windows");
        if(!Directory.Exists(dir))return result;
        foreach(var file in Directory.EnumerateFiles(dir,"*.json").OrderByDescending(File.GetLastWriteTimeUtc).Take(256))try{
            if(new FileInfo(file).Length>1048576)continue;
            var info=Json.Deserialize<WindowInfo>(File.ReadAllText(file,Encoding.UTF8));Guid id;
            // A loading editor still accepts requests into its serial queue.
            // "ready" in older metadata describes the document, not the pipe.
            if(info.version==1&&info.pipe!=null&&info.pipe.StartsWith(prefix,StringComparison.Ordinal)&&Guid.TryParse(info.pipe.Substring(prefix.Length),out id)&&info.pid>0){
                bool alive;try{using(var owner=Process.GetProcessById(info.pid))alive=!owner.HasExited;}catch{alive=false;}
                if(!alive){if(Path.GetFileNameWithoutExtension(file)==id.ToString())try{File.Delete(file);}catch{}continue;}
                result.Add(info);
            }
        }catch{}
        return result;
    }
    static bool Deliver(string profile,string file,string prefix) {
        string key=Key(file);
        var windows=Windows(profile,prefix).OrderByDescending(w=>Key(w.file)==key).ThenByDescending(w=>(w.tabs??new string[0]).Any(t=>Key(t)==key)).ThenByDescending(w=>w.focused).Take(32);
        foreach(var win in windows)try{
            using(var pipe=new NamedPipeClientStream(".",win.pipe,PipeDirection.InOut,PipeOptions.Asynchronous)){
                pipe.Connect(200);
                var bytes=Encoding.UTF8.GetBytes(Json.Serialize(new {version=1,file=file})+"\n");pipe.Write(bytes,0,bytes.Length);pipe.Flush();
                using(var reader=new StreamReader(pipe,new UTF8Encoding(false),false,1024,true)){
                    var read=reader.ReadLineAsync();
                    if(read.Wait(3000)&&read.Result!=null){var reply=Json.Deserialize<Dictionary<string,object>>(read.Result);object accepted;if(reply.TryGetValue("accepted",out accepted)&&accepted is bool&&(bool)accepted){Trace("delivered",win.pid.ToString());return true;}}
                }
            }
        }catch(Exception error){Trace("pipe-error",error.GetType().Name);}
        return false;
    }
    static string Quote(string value) { return "\""+value.Replace("\"","\\\"")+"\""; }
    static void Native(string exe,string file,string profile,bool custom) {
        Process.Start(new ProcessStartInfo(exe,(custom?"--user-data-dir="+Quote(profile)+" ":"")+Quote(file)){UseShellExecute=false,WorkingDirectory=Path.GetDirectoryName(exe)});
    }
    [STAThread] static int Main(string[] args) {
        var exe=Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"..","Typora.exe"));
        var profile=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"Typora");bool custom=false;
        var files=new List<string>();
        for(int i=0;i<args.Length;i++){if(args[i]=="--et-profile"&&i+1<args.Length){profile=Path.GetFullPath(args[++i]);custom=true;}else files.Add(args[i]);}
        trace=Path.Combine(profile,"editing-toolbar-open.log");Trace("started",files.Count.ToString());
        if(!File.Exists(exe))return 2;
        if(files.Count==0){Process.Start(new ProcessStartInfo(exe){UseShellExecute=false});return 0;}
        string prefix=Prefix(profile);
        using(var mutex=new Mutex(false,"Local\\"+prefix+"launcher")){
            bool locked=false;
            try{
                try{locked=mutex.WaitOne(15000);}catch(AbandonedMutexException){locked=true;}
                foreach(var argument in files){
                    string file=argument;try{file=Path.GetFullPath(argument);}catch{}
                    if(locked&&Supported(file)&&File.Exists(file)){
                        if(Deliver(profile,file,prefix))continue;
                        // A process in another profile is not a delivery endpoint.
                        // Let Typora start immediately when this profile has no usable
                        // pipe; its native startup/router handles concurrent launches.
                    }
                    Trace("native-fallback",Supported(file)?"markdown":"other");Native(exe,file,profile,custom);
                }
            }catch{return 1;}finally{if(locked)mutex.ReleaseMutex();}
        }
        return 0;
    }
}
