'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{zipSync}=require('fflate');
function release({directory,out,repository,tag}={}){
 directory=path.resolve(directory||path.join(__dirname,'../plugin/editing-toolbar.modules/ai-reading-assistant'));
 out=path.resolve(out||path.join(__dirname,'../../dist/modules'));
 const Store=require('./feature-module-store.cjs'),store=new Store(require,out),m=store.manifest(JSON.parse(fs.readFileSync(path.join(directory,'module.json'),'utf8')));
 if(repository&&!/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(repository))throw Error('repository 应为 owner/repository');
 tag=tag||m.id+'-v'+m.version;if(!/^[A-Za-z0-9_.-]+$/.test(tag))throw Error('tag 仅支持字母、数字、点、横线和下划线');
 const files={};function collect(dir,prefix=''){for(const entry of fs.readdirSync(dir,{withFileTypes:true})){if(entry.isSymbolicLink())throw Error('模块包不允许符号链接');const name=prefix+entry.name;if(entry.isDirectory())collect(path.join(dir,entry.name),name+'/');else if(entry.isFile())files[name]=[fs.readFileSync(path.join(dir,entry.name)),{mtime:new Date('2020-01-01T00:00:00Z')}];}}collect(directory);
 const zip=Buffer.from(zipSync(files,{level:9})),name=m.id+'-'+m.version+'.zip',sha256=crypto.createHash('sha256').update(zip).digest('hex');fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,name),zip);
 const row={id:m.id,name:m.name,icon:m.icon,documentationUrl:m.documentationUrl,description:m.description,author:m.author,version:m.version,minHostVersion:m.minHostVersion,apiVersion:m.apiVersion,sha256,...(repository?{packageUrl:'https://github.com/'+repository+'/releases/download/'+tag+'/'+name}:{})};
 fs.writeFileSync(path.join(out,name+'.sha256'),sha256+'  '+name+'\n');
 const result={package:path.join(out,name),sha256,tag};
 if(repository){const catalog={schemaVersion:1,name:'Typora 功能模块',modules:[row]};store.catalog(Buffer.from(JSON.stringify(catalog)),'https://github.com/'+repository+'/releases/latest/download/marketplace.json');result.catalog=path.join(out,'marketplace.json');fs.writeFileSync(result.catalog,JSON.stringify(catalog,null,2)+'\n');}
 return result;
}
if(require.main===module){const args=process.argv.slice(2),options={};for(let i=0;i<args.length;i+=2){if(!['--directory','--out','--repository','--tag'].includes(args[i])||!args[i+1])throw Error('用法：node build-module-release.cjs [--repository owner/repository] [--tag ai-reading-assistant-v1.1.0] [--out 目录]');options[args[i].slice(2)]=args[i+1];}console.log(JSON.stringify(release(options),null,2));}
module.exports=release;
