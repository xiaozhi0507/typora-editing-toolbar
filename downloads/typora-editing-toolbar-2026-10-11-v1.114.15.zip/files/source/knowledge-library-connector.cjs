'use strict';
// Local, paired browser connector. Files become library items only after every hash passes.
class KnowledgeLibraryConnector {
  constructor(options) {
    this.o=options;const req=options.requireNode||require;
    this.http=req('http');this.fs=req('fs');this.io=this.fs.promises;this.path=req('path');this.crypto=req('crypto');this.Buffer=req('buffer').Buffer;
    // Keep the Typora receiver separate from Zotero's 23119 connector.
    this.port=options.port||23120;this.jobs=new Map();this.queues=new Map();this.closed=false;
  }
  start() {
    if(this.closed)return;
    const server=this.server=this.http.createServer((q,s)=>this.handle(q,s));
    server.requestTimeout=120000;server.headersTimeout=15000;
    server.on('error',()=>{server.close();if(!this.closed)this.retry=setTimeout(()=>this.start(),4000);});
    server.listen(this.port,'127.0.0.1');return this;
  }
  close(){this.closed=true;clearTimeout(this.retry);this.server?.close();this.server?.closeAllConnections?.();}
  hash(value){return this.crypto.createHash('sha256').update(value).digest('hex');}
  async body(q,limit){const chunks=[];let size=0;for await(const chunk of q){size+=chunk.length;if(size>limit)throw Error('传输内容过大');chunks.push(chunk);}return this.Buffer.concat(chunks);}
  async json(q){return JSON.parse((await this.body(q,1024*1024)).toString('utf8'));}
  reply(s,code,data){if(!s.destroyed){s.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});s.end(JSON.stringify(data));}}
  async handle(q,s){
    // Chrome may omit Origin on extension-host-permitted GETs. The token is still
    // bound to this explicit extension identity; a website's real Origin wins.
    const origin=q.headers.origin||q.headers['x-typora-connector'],validOrigin=typeof origin==='string'&&/^chrome-extension:\/\/[a-p]{32}$/.test(origin);
    if(q.headers.host!==`127.0.0.1:${this.port}`||q.socket.remoteAddress!=='127.0.0.1'||!validOrigin)return this.reply(s,403,{error:'仅接受已连接的本机浏览器扩展'});
    s.setHeader('Access-Control-Allow-Origin',origin);s.setHeader('Vary','Origin');
    s.setHeader('Access-Control-Allow-Methods','GET, POST, PUT, OPTIONS');s.setHeader('Access-Control-Allow-Headers','Authorization, Content-Type, X-Typora-Connector');
    if(q.method==='OPTIONS'){s.writeHead(204);s.end();return;}
    try{
      if(q.url==='/v1/health'&&q.method==='GET')return this.reply(s,200,{service:'typora-library',version:1});
      if(q.url==='/v1/pair'&&q.method==='POST'){
        await this.json(q);if(this.pairing)throw Error('Typora 正在处理另一个连接请求，请稍后重试');this.pairing=true;
        try{if(!await this.o.approve(origin))throw Error('未允许连接');
          const token=this.crypto.randomBytes(32).toString('hex'),pairs=this.o.getPairs();pairs[origin]=this.hash(token);this.o.setPairs(pairs);
          return this.reply(s,200,{token});
        }finally{this.pairing=false;}
      }
      const token=String(q.headers.authorization||'').replace(/^Bearer /,''),expected=this.o.getPairs()[origin];
      if(!expected||this.hash(token)!==expected)return this.reply(s,401,{error:'请在扩展选项中连接 Typora'});
      if(q.url==='/v1/unpair'&&q.method==='POST'){const pairs=this.o.getPairs();delete pairs[origin];this.o.setPairs(pairs);return this.reply(s,200,{ok:true});}
      if(q.url==='/v1/library'&&q.method==='GET'){
        return this.reply(s,200,await this.libraryInfo());
      }
      if(q.url==='/v1/library/choose'&&q.method==='POST'){
        const input=await this.json(q),info=await this.libraryInfo();if(input.libraryId!==info.libraryId)throw Error('知识库已切换，请刷新后重试');
        if(this.choosingRoot)throw Error('请先完成 Typora 中的文件夹选择');if(!this.o.chooseRoot)throw Error('请更新 Typora 工具栏');
        this.choosingRoot=true;
        try{const changed=await this.o.chooseRoot(info.root);return this.reply(s,200,{...await this.libraryInfo(),canceled:!changed});}finally{this.choosingRoot=false;}
      }
      if(q.url==='/v1/import'&&q.method==='POST')return this.reply(s,200,await this.begin(await this.json(q),origin));
      const match=/^\/v1\/import\/([a-f0-9-]{36})\/(file\/\d+|commit|status|abort)$/.exec(q.url||'');
      if(match){
        const [,id,action]=match;
        const old=this.queues.get(id)||Promise.resolve();
        const work=old.catch(()=>{}).then(async()=>{
          const job=this.jobs.get(id);if(!job||job.origin!==origin)throw Error('传输已中断，请重新保存');
          this.checkRoot(job);
          if(action==='status'&&q.method==='GET')return {complete:!!job.result,result:job.result};
          if(action==='abort'&&q.method==='POST'){await this.json(q);return this.abort(job);}
          if(action.startsWith('file/')&&q.method==='PUT')return this.write(job,Number(action.slice(5)),q);
          if(action==='commit'&&q.method==='POST'){await this.json(q);return this.commit(job);}
          throw Error('未知操作');
        });this.queues.set(id,work);try{return this.reply(s,200,await work);}finally{if(this.queues.get(id)===work)this.queues.delete(id);}
      }
      this.reply(s,404,{error:'未知接口'});
    }catch(e){this.reply(s,400,{error:e.message});}
  }
  store(){return new this.o.Store(this.o.root(),this.o.requireNode);}
  async libraryInfo(){const store=this.store(),{data}=await store.open();return {libraryId:data.libraryId,root:store.root,capabilities:['choose-library'],collections:store.constructor.orderCollections(data.collections).map(({id,name,parentId})=>({id,name,parentId}))};}
  checkRoot(job){if(this.path.resolve(this.o.root())!==job.store.root)throw Error('Typora 已切换知识库，请重新选择分类');}
  validPath(p){
    if(typeof p!=='string'||p.length>230||/[\\:\x00-\x1f<>"|?*]/.test(p))return false;
    const parts=p.split('/');if(parts.some(x=>!x||x==='.'||x==='..'||/[. ]$/.test(x)||/^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(x)))return false;
    return parts.length===1?/\.md$/i.test(p):parts[0]==='_xref'?/\.json$/i.test(p):parts[0]==='_assets'&&/\.(?:jpe?g|png|gif|webp|svg|pdf|zip|docx?|xlsx?|txt|csv)$/i.test(p);
  }
  async noLinks(root,target){
    const relative=this.path.relative(root,target);if(relative.startsWith('..')||this.path.isAbsolute(relative))throw Error('无效的保存位置');
    let p=root;for(const part of ['',...relative.split(this.path.sep).filter(Boolean)]){if(part)p=this.path.join(p,part);try{if((await this.io.lstat(p)).isSymbolicLink())throw Error('保存目录中含有链接，请选择普通文件夹');}catch(e){if(e.code!=='ENOENT')throw e;}}
  }
  async begin(input,origin){
    const {id,files,libraryId,collectionId}=input;
    if(!/^[a-f0-9-]{36}$/.test(id)||!Array.isArray(files)||files.length<2||files.length>1000)throw Error('无效的论文包');
    const seen=new Set();let total=0;
    for(const f of files){
      if(!f||typeof f.path!=='string')throw Error('论文包中有文件缺少路径');
      const name=f.path.slice(0,240);
      if(!this.validPath(f.path))throw Error('论文文件路径或格式不受支持：'+name+'；请更新抓取扩展后重试');
      if(seen.has(f.path.toLowerCase()))throw Error('论文包内文件路径重复：'+name);
      if(!Number.isSafeInteger(f.bytes)||f.bytes<0||f.bytes>50*1024*1024)throw Error('论文文件大小无效或超过 50 MB：'+name);
      if(typeof f.sha256!=='string'||!/^[a-f0-9]{64}$/.test(f.sha256))throw Error('论文文件 SHA-256 校验信息无效：'+name);
      seen.add(f.path.toLowerCase());total+=f.bytes;
    }
    if(total>250*1024*1024||files.filter(f=>/^[^/]+\.md$/i.test(f.path)).length!==1||!files.some(f=>f.path.endsWith('/xref-index.json')))throw Error('论文包不完整或过大');
    const store=this.store(),{data}=await store.open();
    if(libraryId!==data.libraryId||collectionId&&!data.collections.some(c=>c.id===collectionId))throw Error('知识库或分类已变化，请重新选择');
    const plan={id,files,libraryId,collectionId:collectionId||'',origin},folder=this.path.join(store.root,'storage',id),record=this.path.join(folder,'.connector.json');
    await this.noLinks(store.root,folder);await this.io.mkdir(folder,{recursive:true});
    const raw=await store.readOptional(record);if(raw&&raw!==JSON.stringify(plan))throw Error('保存任务与已有文件不一致');
    if(!raw)await this.io.writeFile(record,JSON.stringify(plan),{flag:'wx'});
    const existing=this.jobs.get(id);if(existing&&JSON.stringify(existing.plan)!==JSON.stringify(plan))throw Error('保存任务不一致');
    const job=existing||{id,origin,store,folder,plan};this.jobs.set(id,job);return {accepted:true};
  }
  async write(job,index,q){
    if(job.result)throw Error('论文已经保存');const f=job.plan.files[index];if(!f)throw Error('未知文件');
    const data=await this.body(q,f.bytes+1);if(data.length!==f.bytes||this.hash(data)!==f.sha256)throw Error('文件校验失败，未导入文库');
    const file=this.path.join(job.folder,f.path);await this.noLinks(job.store.root,file);await this.io.mkdir(this.path.dirname(file),{recursive:true});
    try{await this.io.writeFile(file,data,{flag:'wx'});}catch(e){if(e.code!=='EEXIST')throw e;if(this.hash(await this.io.readFile(file))!==f.sha256)throw Error('已有文件发生变化，保留原文件');}
    return {ok:true};
  }
  async commit(job){
    if(job.result)return job.result;this.checkRoot(job);
    const store=job.store,{data}=await store.read();if(data.libraryId!==job.plan.libraryId)throw Error('知识库已被替换');
    const md=job.plan.files.find(f=>/^[^/]+\.md$/i.test(f.path)),file=this.path.join(job.folder,md.path);
    const quick=new this.o.QuickFile(store,{Importer:this.o.Importer,Metadata:this.o.Metadata,Managed:this.o.Managed}),snapshot=await quick.inspect(file);
    // A lost HTTP response is retried without creating a second item or overwriting edits.
    if(!snapshot.item)for(const f of job.plan.files){const p=this.path.join(job.folder,f.path);await this.noLinks(store.root,p);const bytes=await this.io.readFile(p);if(bytes.length!==f.bytes||this.hash(bytes)!==f.sha256)throw Error('文件未传完整，未导入文库');}
    const result=await quick.assign(snapshot,job.plan.collectionId,'add',()=>this.path.resolve(this.o.root())===store.root);
    job.result={itemId:result.itemID,collectionName:result.collectionName,created:result.created};
    this.o.changed?.();return job.result;
  }
  async abort(job){
    if(job.result)return {kept:true};
    const md=job.plan.files.find(f=>/^[^/]+\.md$/i.test(f.path)),file=this.path.join(job.folder,md.path);
    const quick=new this.o.QuickFile(job.store,{Importer:this.o.Importer,Metadata:this.o.Metadata,Managed:this.o.Managed});
    try{if((await quick.inspect(file)).item)return {kept:true};}catch(e){if(e.code!=='ENOENT')throw e;}
    const folders=new Set();
    for(const f of job.plan.files){const p=this.path.join(job.folder,f.path);await this.noLinks(job.store.root,p);
      try{if(this.hash(await this.io.readFile(p))!==f.sha256)continue;await this.io.unlink(p);}catch(e){if(e.code!=='ENOENT')throw e;}
      let parent=this.path.dirname(p);while(parent!==job.folder){folders.add(parent);parent=this.path.dirname(parent);}
    }
    for(const p of [...folders].sort((a,b)=>b.length-a.length))await this.io.rmdir(p).catch(()=>{});
    const record=this.path.join(job.folder,'.connector.json');if(await job.store.readOptional(record)===JSON.stringify(job.plan))await this.io.unlink(record);
    await this.io.rmdir(job.folder).catch(()=>{});this.jobs.delete(job.id);return {ok:true};
  }
}
module.exports=KnowledgeLibraryConnector;
