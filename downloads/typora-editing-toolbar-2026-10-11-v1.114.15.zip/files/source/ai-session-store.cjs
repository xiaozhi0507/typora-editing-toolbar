// Date-partitioned JSONL. Only a complete session_commit makes a transaction visible.
class AISessionStore {
  constructor(requireNode,directory,options={}) {
    this.fs=requireNode('fs');this.path=requireNode('path');this.crypto=requireNode('crypto');this.process=requireNode('process');
    this.directory=this.path.resolve(directory);this.legacy=options.legacy;this.paths=new Map();this.cache=new Map();this.duplicates=new Set();
  }
  id(){return this.crypto.randomUUID();}
  validate(id){if(!/^[a-f0-9-]{36}$/.test(id))throw Error('无效的会话 ID');return id;}
  stableId(text){const h=this.crypto.createHash('sha256').update(text).digest('hex').slice(0,32);return h.slice(0,8)+'-'+h.slice(8,12)+'-'+h.slice(12,16)+'-'+h.slice(16,20)+'-'+h.slice(20);}
  clone(data){return data==null?data:JSON.parse(JSON.stringify(data));}
  // Persisted comparisons must never share nested objects with live turns.
  normalize(data){data=this.clone(data);return {...data,...(!data.turns.length?{contextState:null}:{}),turns:data.turns.map((t,i)=>({...t,id:t.id||this.stableId(data.id+':'+i)}))};}
  entries(dir){try{return this.fs.readdirSync(dir,{withFileTypes:true});}catch(e){if(e.code==='ENOENT')return [];throw e;}}
  async files(){
    const list=[],read=async dir=>{try{return await this.fs.promises.readdir(dir,{withFileTypes:true});}catch(e){if(e.code==='ENOENT')return [];throw e;}};
    const walk=async(dir,depth)=>{for(const entry of await read(dir)){if(depth<3){if(entry.isDirectory()&&(depth===0?/^\d{4}$/:/^\d{2}$/).test(entry.name))await walk(this.path.join(dir,entry.name),depth+1);}else if(entry.isFile()){const id=this.fileId(entry.name);if(id)list.push({id,file:this.path.join(dir,entry.name)});}}};
    await walk(this.directory,0);return list;
  }
  fileId(name){return /^rollout-\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}-([a-f0-9-]{36})\.jsonl$/.exec(name)?.[1];}
  locate(id){
    this.validate(id);if(this.duplicates.has(id))throw Error('会话 ID 重复，请检查 sessions 目录');if(this.paths.has(id))return this.paths.get(id);let found;
    const walk=(dir,depth)=>{for(const entry of this.entries(dir)){if(depth<3){if(entry.isDirectory()&&(depth===0?/^\d{4}$/:/^\d{2}$/).test(entry.name))walk(this.path.join(dir,entry.name),depth+1);}else if(entry.isFile()&&this.fileId(entry.name)===id){if(found)throw Error('会话 ID 重复，请检查 sessions 目录');found=this.path.join(dir,entry.name);}}};
    walk(this.directory,0);if(found)this.paths.set(id,found);return found;
  }
  newPath(record){
    this.validate(record.id);const date=new Date(record.created||Date.now());if(!Number.isFinite(date.getTime()))throw Error('无效的会话日期');
    const p=n=>String(n).padStart(2,'0'),y=String(date.getFullYear()),m=p(date.getMonth()+1),d=p(date.getDate()),stamp=y+'-'+m+'-'+d+'T'+p(date.getHours())+'-'+p(date.getMinutes())+'-'+p(date.getSeconds());
    return this.path.join(this.directory,y,m,d,'rollout-'+stamp+'-'+record.id+'.jsonl');
  }
  lockPath(id){return this.path.join(this.directory,'.locks',this.validate(id)+'.lock');}
  acquire(lock){
    try{return this.fs.openSync(lock,'wx');}catch(e){if(e.code!=='EEXIST')throw e;}
    let owner;try{owner=JSON.parse(this.fs.readFileSync(lock,'utf8'));}catch{}
    let stale=false;if(Number.isInteger(owner?.pid)&&owner.pid>0){try{this.process.kill(owner.pid,0);}catch(e){stale=e.code==='ESRCH';}}else stale=Date.now()-this.fs.statSync(lock).mtimeMs>30000;
    if(!stale)throw Error('会话正在另一个窗口中保存，请稍后重试');this.fs.unlinkSync(lock);return this.fs.openSync(lock,'wx');
  }
  parse(bytes,id){
    let offset=0,end=0,record=null,snapshot=null,turns=new Map(),pending=[],tx=null;
    while(offset<bytes.length){const next=bytes.indexOf(10,offset);if(next<0)break;const raw=bytes.subarray(offset,next).toString('utf8');offset=next+1;if(!raw.trim())continue;
      let event;try{event=JSON.parse(raw);}catch{throw Error('会话 JSONL 中有损坏记录，原文件已保留');}
      if(!event.tx||!event.type||typeof event.payload!=='object')throw Error('不支持的会话 JSONL 格式');
      if(event.tx!==tx){pending=[];tx=event.tx;}
      if(event.type!=='session_commit'){pending.push(event);continue;}
      const state=event.payload;
      if(state.queueUnchanged){if(!record?.draftComposer?.queue||!state.draftComposer)throw Error('排队消息缺少已提交的快照');state.draftComposer={...state.draftComposer,queue:record.draftComposer.queue};delete state.queueUnchanged;}
      if(state.id!==id||state.version!==2||!Array.isArray(state.turns)||!state.revision)throw Error('会话提交记录损坏');
      for(const item of pending){const p=item.payload;
        if(item.type==='turn_context'){
          if(p.turn_id){const t=turns.get(p.turn_id)||{id:p.turn_id,question:'',answer:''};t.requestContext=p.reference;turns.set(p.turn_id,t);}
          else snapshot=p.snapshot;
        }
        else if(item.type==='response_item'){
          if(p.type==='reasoning'&&p.turn_id&&Array.isArray(p.content)){
            const t=turns.get(p.turn_id)||{id:p.turn_id,question:'',answer:''};t.reasoning=p.content.filter(c=>c.type==='reasoning_text').map(c=>String(c.text||'')).join('');turns.set(p.turn_id,t);continue;
          }
          if(p.type!=='message'||!p.turn_id||!['user','assistant'].includes(p.role)||!Array.isArray(p.content))throw Error('会话消息格式损坏');
          const t=turns.get(p.turn_id)||{id:p.turn_id,question:'',answer:''};t[p.role==='user'?'question':'answer']=p.content.map(c=>String(c.text||'')).join('');turns.set(p.turn_id,t);
        }else if(item.type==='event_msg'&&p.type==='assistant_delta'){
          const t=turns.get(p.turn_id);if(!t)throw Error('会话增量缺少原消息');t.answer+=String(p.text||'');
        }else if(item.type==='event_msg'&&p.type==='reasoning_delta'){
          const t=turns.get(p.turn_id);if(!t)throw Error('思考增量缺少原消息');t.reasoning=(t.reasoning||'')+String(p.text||'');
        }
      }
      record={...state,contextFile:snapshot?'embedded':null,turns:state.turns.map(meta=>{const t=turns.get(meta.id);if(!t)throw Error('会话提交缺少消息');if(meta.webInputUnchanged){if(!t.webChat?.input||!meta.webChat)throw Error('网页消息缺少已提交的附件快照');meta={...meta,webChat:{...meta.webChat,input:t.webChat.input}};delete meta.webInputUnchanged;}return {...meta,...(t.requestContext?{requestContext:t.requestContext}:{}),...(t.reasoning!==undefined?{reasoning:t.reasoning}:{}),question:t.question,answer:t.answer};})};
      turns=new Map(record.turns.map(t=>[t.id,t]));pending=[];end=offset;
    }
    return {record,snapshot,end};
  }
  load(file,id){
    const stat=this.fs.statSync(file),cached=this.cache.get(file);
    if(cached&&cached.size===stat.size&&cached.mtime===stat.mtimeMs)return cached;
    const parsed=this.parse(this.fs.readFileSync(file),id),result={...parsed,size:stat.size,mtime:stat.mtimeMs};this.cache.set(file,result);return result;
  }
  read(id){
    const file=this.locate(id),data=file?this.load(file,id):null;if(data?.record)return this.normalize(data.record);
    if(this.legacy)return this.legacy.read(id);throw Object.assign(Error('会话不存在或尚未完成保存'),{code:'ENOENT'});
  }
  context(record){const file=this.locate(record.id),data=file?this.load(file,record.id):null;return this.clone(data?.record?data.snapshot:this.legacy?.context(record)||null);}
  async list(){
    const files=await this.files(),records=[],seen=new Set(),shadowed=new Set(),duplicates=new Set();let errors=0;
    for(const {id,file}of files){if(seen.has(id)){duplicates.add(id);errors++;continue;}seen.add(id);this.paths.set(id,file);try{const data=this.load(file,id);if(data.record){shadowed.add(id);if(!data.record.deleted)records.push(this.normalize(data.record));}}catch{shadowed.add(id);errors++;}}
    if(this.legacy){const old=await this.legacy.list();errors+=old.errors;for(const record of old.records)if(!shadowed.has(record.id))records.push(this.normalize(record));}
    this.duplicates=duplicates;for(const id of duplicates)this.paths.delete(id);
    return {records:records.filter(r=>!duplicates.has(r.id)).sort((a,b)=>String(b.updated).localeCompare(String(a.updated))),errors};
  }
  encode(record,previous,snapshot,writeContext){
    const tx=record.revision,timestamp=record.updated,events=[],emit=(type,payload)=>events.push(JSON.stringify({timestamp,type,tx,payload}));
    if(!previous)emit('session_meta',{id:record.id,timestamp:record.created,format:'typora-ai-session',version:2,title:record.title,file:record.file});
    if(writeContext)emit('turn_context',{snapshot});
    const before=new Map((previous?.turns||[]).map(t=>[t.id,t]));
    for(const t of record.turns){const old=before.get(t.id);
      if(t.requestContext&&JSON.stringify(old?.requestContext)!==JSON.stringify(t.requestContext))emit('turn_context',{turn_id:t.id,reference:t.requestContext});
      if(!old||old.question!==t.question)emit('response_item',{type:'message',id:t.id+':user',turn_id:t.id,role:'user',content:[{type:'input_text',text:t.question||''}]});
      if(!old||old.answer!==t.answer||old.status!==t.status){
        if(old&&t.status==='running'&&String(t.answer||'').startsWith(old.answer||''))emit('event_msg',{type:'assistant_delta',turn_id:t.id,text:String(t.answer||'').slice((old.answer||'').length)});
        else emit('response_item',{type:'message',id:t.id+':assistant',turn_id:t.id,role:'assistant',content:[{type:'output_text',text:t.answer||''}]});
      }
      if((t.reasoning||old?.reasoning)&&old?.reasoning!==t.reasoning){
        const text=String(t.reasoning||'');
        if(old&&t.status==='running'&&text.startsWith(old.reasoning||''))emit('event_msg',{type:'reasoning_delta',turn_id:t.id,text:text.slice((old.reasoning||'').length)});
        else emit('response_item',{type:'reasoning',id:t.id+':reasoning',turn_id:t.id,content:[{type:'reasoning_text',text}]});
      }
    }
    const state={...record};delete state.contextFile;
    // Large pending attachments need one snapshot, not a duplicate on every streamed chunk.
    if(record.draftComposer?.queue&&JSON.stringify(record.draftComposer.queue)===JSON.stringify(previous?.draftComposer?.queue)){state.draftComposer={...record.draftComposer};delete state.draftComposer.queue;state.queueUnchanged=true;}
    state.turns=record.turns.map(t=>{const meta={...t};delete meta.question;delete meta.answer;delete meta.reasoning;delete meta.requestContext;
      if(t.webChat?.input&&JSON.stringify(t.webChat.input)===JSON.stringify(before.get(t.id)?.webChat?.input)){meta.webChat={...t.webChat};delete meta.webChat.input;meta.webInputUnchanged=true;}
      return meta;});emit('session_commit',state);return events.join('\n')+'\n';
  }
  write(input,expectedRevision,snapshot){
    const lock=this.lockPath(input.id);this.fs.mkdirSync(this.path.dirname(lock),{recursive:true});let handle;
    try{
      handle=this.acquire(lock);this.fs.writeFileSync(handle,JSON.stringify({pid:this.process.pid}));
      let previous;try{previous=this.read(input.id);}catch(e){if(e.code!=='ENOENT')throw e;}
      if((previous?.revision||null)!==(expectedRevision||null))throw Object.assign(Error('会话已在其他窗口更改'),{code:'CHAT_CONFLICT'});
      const file=this.locate(input.id)||this.newPath(input),data=this.fs.existsSync(file)?this.load(file,input.id):null;
      const context=snapshot!==undefined?snapshot:(data?.record?data.snapshot:previous?this.context(previous):null);
      const record=this.normalize({...input,version:2,revision:this.id(),created:input.created||previous?.created||new Date().toISOString(),updated:new Date().toISOString(),contextFile:context?'embedded':null});
      const replace=!!record.deleted||(snapshot===null&&record.turns.length===0),fresh=replace||!data?.record;
      const text=this.encode(record,fresh?null:previous,context,fresh||snapshot!==undefined);
      this.fs.mkdirSync(this.path.dirname(file),{recursive:true});
      if(replace){const tmp=file+'.'+this.id()+'.tmp';let fd;try{fd=this.fs.openSync(tmp,'wx');this.fs.writeFileSync(fd,text,'utf8');this.fs.fsyncSync(fd);this.fs.closeSync(fd);fd=undefined;this.fs.renameSync(tmp,file);}finally{if(fd!==undefined)this.fs.closeSync(fd);try{this.fs.unlinkSync(tmp);}catch{}}}
      else {if(data&&data.end!==data.size)this.fs.truncateSync(file,data.end);const fd=this.fs.openSync(file,'a');try{this.fs.writeFileSync(fd,text,'utf8');this.fs.fsyncSync(fd);}finally{this.fs.closeSync(fd);}}
      this.paths.set(input.id,file);const stat=this.fs.statSync(file);this.cache.set(file,{record,snapshot:this.clone(context),end:stat.size,size:stat.size,mtime:stat.mtimeMs});return this.normalize(record);
    }finally{if(handle!==undefined){this.fs.closeSync(handle);try{this.fs.unlinkSync(lock);}catch{}}}
  }
  remove(record){return this.write({...record,deleted:true,turns:[],draft:'',draftComposer:null,title:'',file:''},record.revision,null);}
}
module.exports=AISessionStore;
