'use strict';
// Independent CNKI search adapter. Reads the ordinary search-result table, never a Zotero cache.
class KnowledgeLibraryCNKI {
  static origin='https://kns.cnki.net';
  static endpoint='https://kns.cnki.net/kns8s/brief/grid';
  static normalize(value){return String(value||'').normalize('NFKC').toLowerCase().replace(/[\p{P}\p{S}\s]/gu,'');}
  static identifier(value){try{const u=new URL(value);if(!/(^|\.)cnki\.(net|com\.cn)$/i.test(u.hostname))return '';const q=new Map([...u.searchParams].map(([k,v])=>[k.toLowerCase(),v]));return String(q.get('filename')||'').toUpperCase();}catch(_){return '';}}
  static eligible(item){return ['paper','thesis','book'].includes(item.type)&&!!String(item.title||'').trim()&&(!!this.identifier(item.url)||/[\u3400-\u9fff]{2}/.test(item.title));}
  static key(item){return JSON.stringify([item.type,this.identifier(item.url),this.normalize(item.title),this.normalize(item.author),String(item.date||item.year||'').match(/\d{4}/)?.[0]||'']);}
  static count(value){const text=String(value??'').trim().replace(/[,，\s]/g,'');if(!/^\d+$/.test(text))return null;const n=Number(text);return Number.isSafeInteger(n)&&n>=0?n:null;}
  static form(item){
    // Only the title is searched; author/year are checked against the returned record.
    const title=String(item.title||'').normalize('NFKC').replace(/['"\r\n\x00-\x1f]/g,' ').trim().slice(0,500);
    if(!title)throw Error('知网查询需要文献标题');
    const codes='YSTT4HG0,LSTPFY1C,JUP3MUPD,MPMFIG1A,WQ0UVIAA,BLZOG7CK,PWFIRAGL,EMRPGLPA,NLBO1Z6R,NN3FJMUV';
    const query={Platform:'',Resource:'CROSSDB',Classid:'WD0FTY92',Products:'',QNode:{QGroup:[{Key:'Subject',Title:'',Logic:0,Items:[{Key:'Expert',Title:'',Logic:0,Field:'EXPERT',Operator:0,Value:"TI %= '"+title+"'",Value2:''}],ChildItems:[]},{Key:'ControlGroup',Title:'',Logic:0,Items:[],ChildItems:[]}]},ExScope:'1',SearchType:4,Rlang:'CHINESE',KuaKuCode:codes,SearchFrom:1};
    return new URLSearchParams({boolSearch:'true',QueryJson:JSON.stringify(query),pageNum:'1',pageSize:'20',sortField:'',sortType:'',dstyle:'listmode',productStr:codes+',',aside:"(TI %= &#39;"+title+"&#39;)",searchFrom:'资源范围：总库;++中英文扩展;++时间范围：更新时间：不限;++',CurPage:'1'}).toString();
  }
  static parse(html,parseHTML){
    if(typeof html!=='string'||html.length>4*1024*1024)throw Error('知网响应格式无效或过大');
    const doc=parseHTML(html),heading=String(doc.title||'')+' '+String(doc.body?.textContent||'').slice(0,1500);
    if(/安全验证|访问验证|验证码|访问过于频繁|访问异常|captcha|access denied/i.test(heading)&&!doc.querySelector('table.result-table-list'))throw Object.assign(Error('知网需要安全验证，请在“被引数”的列设置中打开“知网验证”，完成后重试'),{code:'CNKI_VERIFY'});
    const table=doc.querySelector('table.result-table-list');
    if(!table){if(/没有找到|未找到|暂无数据|无检索结果|0\s*条结果/.test(heading))return [];throw Error('知网页面未返回文献列表，已有指标保留');}
    return [...table.querySelectorAll('tbody tr')].flatMap(row=>{
      const link=row.querySelector('td.name a.fz14,td.name a'),title=link?.textContent?.trim();if(!title)return [];
      let url='';try{const u=new URL(link.getAttribute('href'),this.origin);if(u.protocol==='https:'&&/(^|\.)cnki\.(net|com\.cn)$/i.test(u.hostname))url=u.href;}catch(_){}
      const text=selector=>row.querySelector(selector)?.textContent?.trim()||'';
      const id=this.identifier(url)||String(row.querySelector('[data-filename]')?.getAttribute('data-filename')||'').toUpperCase();
      return [{title,url,id,author:text('td.author'),date:text('td.date'),source:text('td.source'),cited:this.count(text('td.quote')),downloads:this.count(text('td.download'))}];
    });
  }
  static match(item,rows){
    const id=this.identifier(item.url),title=this.normalize(item.title),year=String(item.date||item.year||'').match(/\d{4}/)?.[0];
    const authors=String(item.author||'').split(/[;；\n、]/).map(a=>this.normalize(a)).filter(Boolean);
    const found=rows.filter(row=>{
      if(id&&row.id!==id)return false;
      if(this.normalize(row.title)!==title)return false;
      if(!id&&authors.length&&!authors.some(a=>this.normalize(row.author).includes(a)))return false;
      if(!id&&year&&row.date.match(/\d{4}/)?.[0]!==year)return false;
      return true;
    });
    const unique=new Map();for(const row of found){const key=row.id||row.url;if(!key)continue;const prior=unique.get(key);if(prior&&(prior.cited!==row.cited||prior.downloads!==row.downloads))throw Error('知网同一文献返回了冲突统计，已有指标保留');unique.set(key,row);}
    if(unique.size!==1)throw Error(unique.size?'知网找到多个同名文献，未自动采用；请补充知网链接':'知网未找到标题、作者和年份相符的文献，请核对信息或补充知网链接');
    return [...unique.values()][0];
  }
  static async lookup(item,{request,parseHTML,now=Date.now}){
    const html=await request(this.endpoint,{method:'POST',body:this.form(item)}),row=this.match(item,this.parse(html,parseHTML)),fields={};
    for(const [key,value]of [['Total(CNKI)',row.cited],['Download',row.downloads]])if(value!==null)fields[key]={value,source:'中国知网',updatedAt:now(),url:row.url,match:this.key(item)};
    if(!Object.keys(fields).length)throw Error('知网未提供被引数和下载量，已有指标保留');
    return {fields,source:'中国知网',url:row.url,warning:Object.keys(fields).length<2?'知网部分统计未提供，缺失字段保留原值':''};
  }
}
module.exports=KnowledgeLibraryCNKI;
