// Share the chat website login; only public usage DOM enters the host.
class EditingToolbarAIUsageBrowser {
  constructor(ai){this.ai=ai;this.active=null;window.addEventListener('unload',()=>this.close());}
  result(status,reason){return {available:false,status,reason,metrics:[],source:'webpage',checkedAt:Date.now()};}
  close(){const state=this.active;if(!state)return;this.active=null;clearTimeout(state.timeout);state.cancelRead?.();state.panel.remove();state.resolve?.(this.result('cancelled','已关闭用量网页。'));}
  mount(profile,visible){
    if(this.active)throw Error('用量网页已打开，请先完成或关闭当前窗口');
    const a=this.ai,panel=a.node('section','et-ai-usage-browser'+(visible?'':' is-background')),view=document.createElement('webview');
    const state=this.active={profile,visible,panel,view};panel.setAttribute('aria-label','ChatGPT 用量网页');if(visible){panel.setAttribute('role','dialog');panel.setAttribute('aria-modal','true');}
    view.addEventListener('did-start-navigation',e=>{if(e.isMainFrame&&!e.isInPlace){state.ready=false;state.failed=false;}});
    view.addEventListener('dom-ready',()=>{state.ready=true;state.wakeRead?.();view.setZoomFactor?.(1);});
    view.setAttribute('partition',EditingToolbarAIWebSession.partition);view.setAttribute('webpreferences','contextIsolation=yes,sandbox=yes,nodeIntegration=no,nodeIntegrationInSubFrames=no'+(visible?'':',backgroundThrottling=no,images=no'));
    view.addEventListener('new-window',e=>e.preventDefault());
    for(const event of ['will-navigate','will-redirect'])view.addEventListener(event,e=>{if(!ETAIUsagePage.allowed(e.url)){e.preventDefault();state.blocked=true;}});
    view.addEventListener('did-fail-load',e=>{if(e.isMainFrame!==false&&e.errorCode!==-3){state.failed=true;if(state.message)state.message.textContent='网页加载失败，请重试。';}});
    if(visible){
      const head=a.node('div','et-ai-usage-browser-head'),title=a.node('strong','','ChatGPT 用量网页'),account=a.node('span','et-ai-usage-web-account','与 GPT 网页共用登录'),close=a.node('button','','关闭');close.type='button';close.onclick=()=>this.close();head.append(title,account,close);
      const footer=a.node('div','et-ai-usage-browser-footer'),login=a.node('button','','登录'),message=state.message=a.node('span','','使用 GPT 网页当前登录的账号。页面就绪后点击“读取用量”。'),reload=a.node('button','','前往用量页'),read=state.read=a.node('button','et-ai-primary','读取用量');login.type=reload.type=read.type='button';login.onclick=()=>{view.src='https://chatgpt.com/auth/login';};reload.onclick=()=>{view.src=ETAIUsagePage.url;};read.onclick=()=>void this.finish(state);footer.append(message,login,reload,read);panel.append(head,view,footer);
      panel.addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Escape')this.close();});
    }else panel.append(view);
    for(const type of ['pointerdown','mousedown','click','dblclick'])panel.addEventListener(type,e=>e.stopPropagation());
    // Existing browser cookies remain valid even if an earlier parser failed.
    view.src=ETAIUsagePage.url;document.body.append(panel);return state;
  }
  async inspect(state,wait=0){
    if(state!==this.active)throw Error('用量网页已关闭');
    const source=fn=>'('+fn.toString().replace(/^\w+\(/,'function(')+')';
    const script=wait?source(ETAIUsagePage.observe)+'('+source(ETAIUsagePage.snapshot)+','+source(ETAIUsagePage.parse)+','+Math.ceil(wait)+')':source(ETAIUsagePage.snapshot)+'()';
    let timer,cancel;try{return await Promise.race([state.view.executeJavaScript(script),new Promise((_,reject)=>{
      timer=setTimeout(()=>reject(Error('页面读取超时')),wait?wait+250:1800);
      state.cancelRead=cancel=()=>reject(Error('用量网页已关闭'));
    })]);}finally{clearTimeout(timer);if(state.cancelRead===cancel)state.cancelRead=null;}
  }
  async readPage(state){
    let stopped=false;const wait=()=>new Promise(resolve=>{
      const wake=()=>{clearTimeout(timer);if(state.wakeRead===wake)state.wakeRead=null;if(state.cancelRead===cancel)state.cancelRead=null;resolve();};
      const cancel=()=>{stopped=true;wake();},timer=setTimeout(wake,100);state.wakeRead=wake;state.cancelRead=cancel;
    });
    const end=Date.now()+20000;let snapshot,readFailed=false;
    while(this.active===state&&!stopped&&Date.now()<end){
      // Observe the live DOM in the guest. A quota change returns immediately,
      // without waiting for images, did-finish-load or another host polling tick.
      try{snapshot=await this.inspect(state,Math.max(1,end-Date.now()));readFailed=false;}catch{
        if(this.active!==state||stopped)break;
        readFailed=true;if(state.failed)throw Error('官方用量网页加载失败，请打开网页检查连接。');await wait();continue;
      }
      if(this.active!==state||stopped)break;
      if(snapshot.login||snapshot.challenge)return ETAIUsagePage.parse(snapshot);
      if(snapshot.usage){state.authenticated=true;return ETAIUsagePage.parse(snapshot);}
      // Retry only across guest startup/navigation. The observer handles SPA updates.
      await wait();
    }
    if(stopped||this.active!==state)return this.result('cancelled','已取消读取用量。');
    return this.result('unavailable',readFailed?'页面读取暂未完成，请稍后再次点击“读取用量”。':'未找到用量区域，请点击“前往用量页”后再读取。');
  }
  async finish(state){
    if(state!==this.active||state.read.disabled)return;state.read.disabled=true;state.message.textContent='正在读取页面…';
    try{
      const data=await this.readPage(state);if(this.active!==state)return;
      // Keep the authenticated page visible on failure so the user can retry.
      if(!data.available){state.message.textContent=data.reason;return;}
      const resolve=state.resolve;state.resolve=null;this.close();resolve(data);
    }catch(e){if(this.active===state)state.message.textContent=e.message;}
    finally{state.read.disabled=false;}
  }
  open(profile){
    if(this.active?.visible){this.active.view.focus();return Promise.resolve(this.result('unavailable','用量网页登录窗口已打开。'));}
    const state=this.mount(profile,true);return new Promise(resolve=>state.resolve=resolve);
  }
  async refresh(profile){
    const state=this.mount(profile,false);
    try{return await this.readPage(state);}finally{if(this.active===state)this.close();}
  }
}
