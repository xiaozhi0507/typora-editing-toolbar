// Loaded only for an explicitly attached PDF. Parsing runs in a dedicated worker.
async function etReadProjectPDF(data,signal){
 if(signal?.aborted)throw Object.assign(Error('已停止读取 PDF'),{name:'AbortError'});
 if(!window.ETProjectPDF){const script=document.createElement('script');script.textContent=ET_PROJECT_PDF_MAIN;document.head.append(script);script.remove();}
 const pdf=window.ETProjectPDF,url=URL.createObjectURL(new Blob([ET_PROJECT_PDF_WORKER],{type:'text/javascript'}));
 let nativeWorker,worker,loading,timer,abort,fail;
 try{
  nativeWorker=new Worker(url);worker=new pdf.PDFWorker({port:nativeWorker});
  loading=pdf.getDocument({data,worker,isEvalSupported:false,useWorkerFetch:false,disableFontFace:true,useSystemFonts:true,stopAtErrors:true,verbosity:0});
  const interrupted=new Promise((_,reject)=>{fail=reject;abort=()=>reject(Object.assign(Error('已停止读取 PDF'),{name:'AbortError'}));signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)abort();timer=setTimeout(()=>reject(Error('PDF 读取超时，请使用较小的文件')),30000);nativeWorker.onerror=()=>reject(Error('PDF 读取进程启动失败'));});
  loading.onPassword=()=>fail(Error('加密 PDF 暂不支持，请先解密后再拖入'));
  return await Promise.race([(async()=>{
   const doc=await loading.promise;if(doc.numPages>100)throw Error('PDF 超过 100 页，请先选择所需页面');let text='';
   for(let i=1;i<=doc.numPages;i++){
    if(signal?.aborted)throw Object.assign(Error('已停止读取 PDF'),{name:'AbortError'});
    const page=await doc.getPage(i),content=await page.getTextContent();const lines=content.items.map(x=>x.str+(x.hasEOL?'\n':' ')).join('').trim();
    if(lines)text+='\n[第 '+i+' 页]\n'+lines+'\n';page.cleanup();if(text.length>100000)throw Error('PDF 文本超过 10 万字符，请先选择所需页面');
   }
   if(!text.trim())throw Error('此 PDF 没有可提取的文字；扫描件请先 OCR，或拖入所需页面图片');return text;
  })(),interrupted]);
 }finally{clearTimeout(timer);signal?.removeEventListener('abort',abort);loading?.destroy().catch(()=>{});worker?.destroy();nativeWorker?.terminate();URL.revokeObjectURL(url);}
}
