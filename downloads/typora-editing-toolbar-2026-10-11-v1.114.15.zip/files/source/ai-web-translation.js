class EditingToolbarAIWebTranslation {
  constructor(web){this.web=web;this.ai=web.ai;this.pending=false;this.seen=new Map();this.jobs=new Map();this.serial=Promise.resolve();window.addEventListener('unload',()=>clearInterval(this.timer));}
  core(root=this.ai.toolbar.knowledgeLibrary.rootPath){const store=new ETKnowledgeStorage(root,reqnode);return new ETAIWebTranslation(store,new ETKnowledgeManaged(store),ETAIWebZip);}
  candidate(){const a=this.ai,h=a.toolbar.knowledgeLibrary;return this.core().candidate(a.file(),a.source(),h.isOpen?h.ui?.translationSelection?.():null,ETAIPaperTranslation);}
  async init(){const root=this.ai.toolbar.knowledgeLibrary.rootPath;if(this.root===root)return;this.root=root;this.jobs.clear();const core=this.core();for(const j of await core.jobs())this.jobs.set(j.id,j);if(!this.timer)this.timer=setInterval(()=>void this.scan(),2000);this.restoreOutputs();this.sync();}
  restoreOutputs(){let changed=false;for(const turn of this.ai.turns||[]){const job=this.jobs.get(turn.webChat?.translationJob);if(job?.state==='imported'&&job.output&&turn.webChat.translationOutput!==job.output){turn.webChat.translationOutput=job.output;this.ai.renderTurn(turn);changed=true;}}if(changed)this.ai.conversations.schedule();}
  mount(){const a=this.ai;this.card=a.node('div','et-ai-web-translation-draft');this.card.hidden=true;const top=a.node('div','et-ai-translation-top');this.title=a.node('strong','et-ai-translation-title');this.remove=a.node('button','','×');this.remove.type='button';this.remove.setAttribute('aria-label','取消待发送文献翻译');this.remove.onclick=()=>{if(a.busy)return;this.clear();a.composerUI.sync();a.conversations.schedule();};top.append(this.title,this.remove);this.detail=a.node('div','et-ai-translation-detail');const details=a.node('details');details.append(a.node('summary','','查看翻译提示词'));this.promptPreview=a.node('pre','et-ai-translation-prompt');details.append(this.promptPreview);this.card.append(top,this.detail,details);a.prompt.before(this.card);this.sync();}
  snapshot(){return this.draft?{...this.draft}:null;}
  restore(value){this.draft=value&&/^[a-f0-9-]{36}$/.test(value.id)&&typeof value.root==='string'?{id:value.id,root:value.root,title:String(value.title||'英文文献')}:null;this.sync();}
  clear(){this.draft=null;this.sync();}
  sync(){if(!this.card)return;const a=this.ai,d=this.draft;this.card.hidden=!this.web.active()||!d;if(!d)return;this.title.textContent='一键文献翻译 · '+d.title;this.title.title=this.title.textContent;this.detail.textContent='已准备 1 个文献压缩包 · 点击发送后上传';const job=this.jobs.get(d.id);this.promptPreview.textContent=job?this.core(d.root).prompt(job):'调用空间中的《文献PDF转markdown skill.md》完整翻译文献；发送时载入本地打包记录。';this.remove.disabled=!!a.busy;}
  async start(){
    const a=this.ai;if(this.pending||a.busy)return;this.pending=true;a.composerUI.closeMenu();let prepared,root;
    try{
      const target=this.web.projects.target();if(!target)throw Error('请在＋号的项目模式中选择项目和聊天');
      const file=a.file(),source=a.source();root=a.toolbar.knowledgeLibrary.rootPath;const core=this.core(root),controller=new AbortController();this.controller=controller;a.controller=controller;a.busyState(true);a.notice('正在打包英文文献和原始附件…');
      const candidate=await this.candidate();prepared=await core.prepare(candidate,target,{signal:controller.signal});
      if(a.file()!==file||a.source()!==source||a.toolbar.knowledgeLibrary.rootPath!==root||controller.signal.aborted)throw Error('当前文献已改变或操作已停止，未发送');
      await this.init();this.jobs.set(prepared.job.id,prepared.job);
      this.draft={id:prepared.job.id,root,title:candidate.item.title};a.composerUI.command=null;this.sync();a.conversations.schedule();a.notice('文献包已准备，可补充要求；点击发送后开始翻译');
    }catch(e){a.notice(e.message,true);prepared=null;}finally{this.pending=false;this.controller=null;a.controller=null;a.busyState(false);}
    a.composerUI.sync();
  }
  async sendDraft(){
    const a=this.ai,d=this.draft;if(!d||this.pending||a.busy)return;let prepared;this.pending=true;a.busyState(true);
    try{
      const target=this.web.projects.target(),root=a.toolbar.knowledgeLibrary.rootPath,file=a.file();if(!target)throw Error('请先选择项目和聊天');if(root!==d.root)throw Error('知识库已改变，请重新准备文献翻译');
      if(a.attachments?.selected?.length||a.composerUI.draft.media?.snapshot().length||a.composerUI.draft.quotes?.snapshot().length)throw Error('文献翻译会发送已准备的文献包；请先移除额外的附件、图片或引用，补充要求可写在输入框中');
      const core=this.core(root),job=await core.read(d.id);if(job.state!=='prepared')throw Error('此翻译任务已提交，请从原聊天查看或重试');
      const source=await core.io.readFile(job.source);if(core.hash(source)!==job.sourceSha256)throw Error('英文原稿已改变，请重新准备文献翻译');
      if(core.path.resolve(job.source).toLowerCase()===core.path.resolve(file).toLowerCase()&&/\.(md|markdown|mdown)$/i.test(file)&&a.source().replace(/\r\n?/g,'\n')!==source.toString('utf8').replace(/\r\n?/g,'\n'))throw Error('英文原稿有未保存修改，请保存后重新准备');
      const archive=core.path.join(core.folder(job.id),'source.zip'),st=await core.io.stat(archive);if(!st.isFile()||st.size>20*1024*1024)throw Error('文献包不可用，请重新准备');const bytes=await core.io.readFile(archive);
      if(this.draft!==d||a.file()!==file||a.toolbar.knowledgeLibrary.rootPath!==root)throw Error('当前文档或翻译草稿已改变，未发送');
      const extra=a.composerUI.draft.text().trim(),text=core.prompt(job)+(extra?'\n\n补充要求：\n'+extra:'');job.target=target;await core.save(job);this.jobs.set(job.id,job);
      prepared={job,target,fromDraft:true,input:{text,files:[{name:'source-'+job.id+'.zip',type:'application/zip',base64:bytes.toString('base64')}]},request:{question:text,displayQuestion:'⚡ 一键文献翻译 · '+job.title+(extra?'\n'+extra:''),command:{id:'builtin-web-translation',name:'一键文献翻译'}}};
    }catch(e){a.notice(e.message,true);}finally{this.pending=false;a.busyState(false);}
    if(prepared)await this.web.send(null,prepared);
  }
  bind(turn){const id=turn.webChat?.translationJob;if(!id)return;const binding={url:turn.webChat.url,submitted:turn.webChat.submitted};this.serial=this.serial.then(async()=>{await this.init();const job=this.jobs.get(id);if(!job)return;Object.assign(job,{conversation:binding.url||job.conversation,state:job.state==='imported'?'imported':binding.submitted?'awaiting-download':job.state});await this.core().save(job);}).catch(e=>this.ai.notice('翻译任务状态未保存：'+e.message,true));}
  async directory(){return this.ai.config.webTranslationDownloads||reqnode('path').join(reqnode('os').homedir(),'Downloads');}
  async scan(){
    if(this.scanning||!this.ai.panel||this.ai.panel.hidden)return;this.scanning=true;
    try{await this.init();const jobs=[...this.jobs.values()].filter(j=>j.state==='awaiting-download');if(!jobs.length)return;const directory=await this.directory(),io=reqnode('fs').promises;let entries;try{entries=await io.readdir(directory);}catch{return;}
      for(const job of jobs){const prefix=job.resultName.slice(0,-4),matches=entries.filter(n=>n===job.resultName||n.startsWith(prefix+' (')&&/^ \(\d+\)\.zip$/.test(n.slice(prefix.length)));
        for(const name of matches){const file=reqnode('path').join(directory,name),st=await io.stat(file),stamp=st.size+':'+st.mtimeMs;if(st.mtimeMs<Date.parse(job.created)||!st.isFile())continue;if(this.seen.get(file)!==stamp){this.seen.set(file,stamp);continue;}if(job.lastAttempt===stamp+file)continue;job.lastAttempt=stamp+file;await this.importFile(job,file).catch(e=>{job.error=e.message;this.ai.notice('译稿尚未归档：'+e.message,true);});}
      }
    }catch(e){this.ai.notice(e.message,true);}finally{this.scanning=false;}
  }
  async importFile(job,file){
    if(this.importing)throw Error('正在归档另一份译稿');this.importing=true;try{const a=this.ai,host=a.toolbar.knowledgeLibrary,core=this.core();if(host.isOpen&&host.ui&&!await host.ui.flush())throw Error('知识库有未保存修改，请先保存');const result=await core.import(job,file);job.state='imported';job.output=result.file;host.graphChanged();if(host.isOpen)await host.ui?.refresh();a.notice('中文译稿已加载到“'+job.title+'”下');for(const t of a.turns)if(t.webChat?.translationJob===job.id){t.webChat.translationOutput=result.file;a.renderTurn(t);}a.conversations.flush();return result;}finally{this.importing=false;}
  }

  resultName(turn){const id=turn.webChat?.translationJob;return /^[a-f0-9-]{36}$/.test(id||'')?'translation-'+id+'.zip':'';}
  link(node,url,turn){
    const name=this.resultName(turn);if(!name||url!=='#et-web-file/'+encodeURIComponent(name))return false;
    node.href=url;node.classList.add('et-ai-translation-link');node.dataset.translationDownload=turn.webChat.translationJob;
    node.title='下载、校验并添加到原文献条目';node.onclick=e=>{e.preventDefault();e.stopPropagation();void this.download(turn).catch(e=>this.ai.notice('译稿尚未归档：'+e.message,true));};return true;
  }
  decorateAnswer(turn,host){
    const name=this.resultName(turn);if(!name)return;const url='#et-web-file/'+encodeURIComponent(name);
    // Saved replies from older versions contain plain filenames; upgrade only this bound job's exact filename.
    if(!host.querySelector('[data-translation-download]')){
      const walker=host.ownerDocument.createTreeWalker(host,4);let node;while(node=walker.nextNode()){
        if(node.parentElement.closest('a,code,pre'))continue;const at=node.nodeValue.indexOf(name);if(at<0)continue;
        const link=this.ai.node('a','',name),before=node.nodeValue.slice(0,at),after=node.nodeValue.slice(at+name.length);this.link(link,url,turn);node.replaceWith(host.ownerDocument.createTextNode(before),link,host.ownerDocument.createTextNode(after));break;
      }
    }
    for(const link of host.querySelectorAll('[data-translation-download]')){
      const state=this.downloadStates?.get(turn.webChat.translationJob),output=turn.webChat.translationOutput||this.jobs.get(turn.webChat.translationJob)?.output;
      if(output&&link.previousSibling?.nodeType===3)link.previousSibling.nodeValue=link.previousSibling.nodeValue.replace(/(?:下载|Download)\s*$/i,'');
      link.textContent=output?'打开中文翻译.md':state==='running'?'正在下载并归档…':state?.phase==='archive'?'已下载，归档失败 · 点击重试':state?.phase==='download'?'下载失败，点击重试':name;
      link.setAttribute('aria-busy',String(state==='running'));link.title=output?'已添加到原文献条目，点击打开':state?.message||'下载后自动解压并归档到原文献条目';
    }
  }
  async download(turn){
    const a=this.ai,id=turn.webChat?.translationJob;if(!id)return;this.downloadStates ||=new Map();if(this.downloadStates.get(id)==='running')return;
    if(a.busy||this.web.browser.switching||this.web.browser.refreshJob)throw Error('请等待当前网页操作完成');
    await this.init();const core=this.core(),job=await core.read(id);if(!job)throw Error('当前知识库中未找到此翻译任务');this.jobs.set(id,job);
    if(job.state==='imported'&&job.output){this.restoreOutputs();const error=await reqnode('electron').shell.openPath(job.output);if(error)throw Error(error);return;}
    const root=this.root,b=this.web.browser;this.downloadStates.set(id,'running');b.switching=true;a.renderTurn(turn);this.web.refreshUI();let phase='download',file;
    try{
      // Resume a completed local transfer after an upgrade/restart; never resubmit the translation.
      // After an import failure a new click fetches a fresh ZIP, so a corrected web file can replace it.
      this.failedImports ||=new Set();file=this.failedImports.has(id)?null:await core.cachedDownload(job);
      if(!file)file=await b.downloadTo({url:job.conversation||turn.webChat.url},job.resultName,core.folder(id));phase='archive';
      if(a.toolbar.knowledgeLibrary.rootPath!==root)throw Error('知识库已切换，下载包已保留在原任务中');await this.importFile(job,file);this.downloadStates.delete(id);this.failedImports.delete(id);
    }
    catch(e){if(phase==='archive')this.failedImports.add(id);this.downloadStates.set(id,{phase,message:e.message});throw e;}finally{b.switching=false;a.renderTurn(turn);this.web.refreshUI();}
  }
}
