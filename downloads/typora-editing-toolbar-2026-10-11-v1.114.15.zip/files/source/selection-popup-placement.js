    _selectionToolbarPosition(rect,bar) {
        const width=Math.min(innerWidth,this.panelWorkspace?.activeDockPanel()?.getBoundingClientRect().left??innerWidth),height=innerHeight,gap=8;
        this.toolbar.style.maxWidth=Math.max(80,Math.min(600,width-20))+'px';bar=this.toolbar.getBoundingClientRect();
        const maxTop=Math.max(10,height-bar.height-10);
        const topBounds=this.topHost?.getBoundingClientRect(),floating=this.uiSettings.topMode === "floating";
        const minTop=Math.min(maxTop,floating?10:Math.max(10,(topBounds?.bottom || 0)+gap));
        const left=Math.max(10,Math.min(rect.left+rect.width/2-bar.width/2,width-bar.width-10));
        const intersectsX=b=>b.right>left && b.left<left+bar.width;
        const obstacles=Array.from(document.querySelectorAll("#write h1,#write h2,#write h3,#write h4,#write h5,#write h6"),e=>e.getBoundingClientRect())
            .filter(b=>b.height && b.bottom>minTop && b.top<height && intersectsX(b));
        if(floating && topBounds && intersectsX(topBounds))obstacles.push(topBounds);
        const primary=[rect.bottom+this.config.OFFSET_Y,rect.top-bar.height-this.config.OFFSET_Y];
        const overlaps=(y,b)=>b.bottom>y && b.top<y+bar.height;
        const within=y=>y>=minTop && y<=maxTop;
        const avoidsSelection=y=>!intersectsX(rect) || !overlaps(y,rect);
        const clear=y=>within(y) && avoidsSelection(y) && !obstacles.some(b=>overlaps(y,b));
        let top=primary.find(clear);
        if(top===undefined){
            // Above/below may both hit headings. Try the nearest clear band instead.
            const candidates=[minTop,maxTop,...obstacles.flatMap(b=>[b.bottom+gap,b.top-bar.height-gap])];
            top=candidates.filter(clear).sort((a,b)=>Math.abs(a-primary[0])-Math.abs(b-primary[0]))[0];
        }
        if(top===undefined){
            // A dense or very short viewport may have no clear band at all.
            // Keep the action reachable, preferring to leave the selected text visible.
            const candidates=[...primary,minTop,maxTop].map(y=>Math.max(minTop,Math.min(y,maxTop)));
            top=candidates.find(avoidsSelection) ?? candidates[0];
        }
        return {left,top};
    }
