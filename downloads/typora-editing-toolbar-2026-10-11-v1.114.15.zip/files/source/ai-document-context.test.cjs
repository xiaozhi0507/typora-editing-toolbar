const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const Client=require('./ai-client.cjs');
function fixture(realScope=false){
  const state={file:'A.md',loading:false,saved:[],requests:[],notices:[],draft:{text:'Question',folded:'',quotes:[]}};
  const storage=new Map();const sandbox={File:{isFileLoading:()=>state.loading},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},ETAIClient:Client,ETAIExecution:require('./ai-execution.cjs'),AbortController,console,performance:{now:()=>state.now||0},setInterval,clearInterval};
  vm.createContext(sandbox);vm.runInContext(fs.readFileSync(require.resolve('./ai-turn-timing.js'),'utf8')+'\n'+fs.readFileSync(require.resolve('./ai-assistant.js'),'utf8')+'\nglobalThis.AI=EditingToolbarAI;',sandbox);
  const a=Object.create(sandbox.AI.prototype);
  Object.assign(a,{context:{file:'A.md',markdown:'SOURCE_A'},file:()=>state.file,turns:[],scope:{value:'document'},status:{hidden:true},panel:{hidden:false},prompt:{focus(){}},empty:{},messages:{querySelectorAll:()=>[]},resetCopyFeedback(){},notice:m=>state.notices.push(m),updateContext(){},renderTurn(){},scheduleRender(){},mountTurn:t=>{t.article={remove(){}};t.actions={children:[]};},profile:()=>({model:'fixture',url:'https://example.invalid/v1',protocol:'openai-chat'}),keyFor:async()=>'',request:async(p,k,m)=>{state.requests.push(m);return{text:'ANSWER_'+state.file};},capture(){this.context={file:state.file,markdown:'SOURCE_'+state.file[0]};return true;}});
  a.composerUI={command:null,sourceDraft:null,hasSourceDraft(){return !!(this.sourceDraft||this.sourceChanged);},restoreSource(){if(this.sourceDraft){a.context=this.sourceDraft.context;this.sourceDraft=null;}},closeMenu(){},refresh(){},sync(){},draft:{snapshot:()=>({...state.draft}),clear:()=>state.draft={text:'',folded:'',quotes:[]},restore:d=>state.draft={text:d?.text||'',folded:d?.folded||'',quotes:d?.quotes||[]},quotes:{snapshot:()=>state.draft.quotes,reference:()=>state.draft.quotes.map(q=>q.text).join('\n')}},request:()=>({question:state.draft.text,displayQuestion:state.draft.text}),consumed(){this.command=null;this.restoreSource();this.draft.clear();}};
  a.attachments={selected:[],pending:false,frozen:null,reset(){this.selected=[];this.frozen=null;},async prepare(base){return this.frozen||base;},freeze(r){this.frozen=r;}};
  a.promptsManager={reference:()=>a.attachments.frozen||{text:a.scope.value==='none'?'':a.context.markdown,label:a.context.file}};
  a.conversations={library:{update(){}},record:null,saveError:false,flush(){if(state.failSave)return false;if(a.turns.length)state.saved.push({file:a.context.file,turns:a.turns.map(t=>({...t}))});return true;},beforeNew(){if(!this.flush())return false;this.record=null;return true;},reset(){},schedule(){},refreshTitle(){}};
  a.busyState=function(v){this.busy=v;this.checkDocument();};
  if(realScope){
    for(const [file,name] of [['ai-composer.js','EditingToolbarAIComposer'],['ai-prompt-manager.js','EditingToolbarPromptManager'],['ai-attachments.js','EditingToolbarAIAttachments']])vm.runInContext(fs.readFileSync(require.resolve('./'+file),'utf8')+';globalThis.'+name+'='+name+';',sandbox);
    for(const name of ['hasSourceDraft','markSourceChanged','changeScope','stageSource','restoreSource','snapshot','restore','consumed'])a.composerUI[name]=sandbox.EditingToolbarAIComposer.prototype[name];a.composerUI.ai=a;
    a.promptsManager={ai:a,reference:sandbox.EditingToolbarPromptManager.prototype.reference,renderContextTools(){}};
    a.attachments.ai=a;a.attachments.prepare=sandbox.EditingToolbarAIAttachments.prototype.prepare;
    a.config={prompts:[]};a.context.selected='SELECTED_A';
  }
  return {a,state};
}

test('current-document send above 100k keeps the complete paper and sends a staged source once',async()=>{
  const {a,state}=fixture(true),paper='<span style="font-family:serif">文</span>'.repeat(16000)+'FINAL_SENTENCE';
  a.context.markdown=paper;a.context.label='Paper';a.composerUI.markSourceChanged();
  await a.send();assert.equal(state.requests.length,1,state.notices.join('; '));
  const wire=JSON.stringify(state.requests[0]);assert.equal(wire.split('FINAL_SENTENCE').length-1,1);
  assert.ok(state.requests[0].some(m=>typeof m.content==='string'&&m.content.includes(paper)));assert.equal(a.context.markdown,paper);
});
test('switch saves old conversation and keeps only draft text, scope and command',()=>{
  const {a,state}=fixture();a.turns=[{question:'OLD',status:'done',actions:{children:[]}}];a.attachments.frozen={text:'OLD_REFERENCE'};a.attachments.selected=[{id:'old'}];a.composerUI.command={id:'translate'};state.draft={text:'new question',folded:'pasted',quotes:[{text:'old quote'}]};state.file='B.md';
  assert.equal(a.followDocument(),true);assert.equal(state.saved[0].file,'A.md');assert.equal(a.context.markdown,'SOURCE_B');assert.equal(a.turns.length,0);assert.equal(a.attachments.frozen,null);assert.equal(a.attachments.selected.length,0);assert.equal(a.scope.value,'document');assert.equal(a.composerUI.command.id,'translate');assert.equal(state.draft.text,'new question');assert.equal(state.draft.folded,'pasted');assert.equal(state.draft.quotes.length,0);assert.equal(state.notices.length,0);
});
test('same-document check retains the frozen conversation',()=>{
  const {a,state}=fixture();const frozen=a.attachments.frozen={text:'ORIGINAL'};a.turns=[{question:'OLD'}];assert.equal(a.followDocument(),true);assert.equal(a.attachments.frozen,frozen);assert.equal(a.turns.length,1);assert.equal(state.saved.length,0);
});
test('immediate send follows B before polling and excludes A history and reference',async()=>{
  const {a,state}=fixture();a.turns=[{question:'OLD_QUESTION',answer:'OLD_ANSWER',status:'done'}];a.attachments.frozen={text:'SOURCE_A'};state.file='B.md';await a.send();assert.equal(state.requests.length,1);const body=JSON.stringify(state.requests[0]);assert.ok(body.includes('SOURCE_B'));assert.ok(!/SOURCE_A|OLD_QUESTION|OLD_ANSWER/.test(body));assert.equal(a.turns[0].file,'B.md');
});
test('loading and failed persistence retain old data and make no request',async()=>{
  const {a,state}=fixture();state.file='B.md';state.loading=true;await a.send();assert.equal(a.context.file,'A.md');state.loading=false;state.failSave=true;await a.send();assert.equal(a.context.file,'A.md');assert.equal(state.requests.length,0);
});
test('file switch during attachment preparation prevents dispatch',async()=>{
  const {a,state}=fixture();a.attachments.prepare=async()=>{state.file='B.md';return{text:'SOURCE_A'};};await a.send();assert.equal(state.requests.length,0);assert.equal(a.context.file,'B.md');assert.equal(a.turns.length,0);assert.equal(state.draft.text,'Question');
});
test('file switch during key lookup preserves the unsent question before following B',async()=>{
  const {a,state}=fixture();a.keyFor=async()=>{state.file='B.md';return'fixture';};await a.send();assert.equal(state.requests.length,0);assert.equal(state.saved.length,0);assert.equal(state.draft.text,'Question');assert.equal(a.context.file,'B.md');assert.equal(a.turns.length,0);
});
test('streaming abort saves partial output under A before transition',async()=>{
  const {a,state}=fixture();a.request=async(p,k,m,opts)=>require('./ai-execution.cjs').request(opts.execution,async callbacks=>{callbacks.onText('PARTIAL_A');state.file='B.md';a.checkDocument();assert.equal(opts.signal.aborted,true);throw Object.assign(Error('stopped'),{name:'AbortError'});},opts);await a.send();assert.equal(state.saved.at(-1).file,'A.md');assert.equal(state.saved.at(-1).turns[0].execution.find(e=>e.type==='progress').text,'PARTIAL_A');assert.equal(state.saved.at(-1).turns[0].status,'stopped');assert.equal(a.context.file,'B.md');
});
test('provider ignoring abort cannot complete a turn for the new document',async()=>{
  const {a,state}=fixture();a.request=async()=>{state.file='B.md';return{text:'late response'};};await a.send();assert.equal(state.saved.at(-1).file,'A.md');assert.equal(state.saved.at(-1).turns[0].status,'stopped');assert.equal(a.turns.length,0);
});
test('stale retry cannot resend an A question into B',async()=>{
  const {a,state}=fixture(),retry={question:'OLD',file:'A.md',status:'error'};a.turns=[retry];state.file='B.md';await a.send(retry);assert.equal(state.requests.length,0);assert.equal(a.context.file,'B.md');
});
test('staged source is cleared and none scope stays unattached',async()=>{
  const {a,state}=fixture();a.composerUI.sourceDraft={context:a.context};a.scope.value='none';state.file='B.md';await a.send();assert.equal(a.composerUI.sourceDraft,null);assert.ok(!JSON.stringify(state.requests[0]).includes('SOURCE_'));assert.equal(a.context.file,'B.md');
});

test('per-question images are sent again only as matching request context on retry',async()=>{const {a,state}=fixture();const image={data:'data:image/png;base64,YQ==',name:'test.png'};const media={items:[image],snapshot:()=>[image]};a.composerUI.draft.media=media;await a.send();assert.equal(a.turns.length,1);assert.equal(a.turns[0].requestContext.images.length,1);assert.ok(JSON.stringify(state.requests[0]).includes('data:image/png'));const turn=a.turns[0];turn.status='error';await a.send(turn);assert.equal(a.turns.length,1);assert.equal(a.turns[0].requestContext.images.length,1);assert.equal(state.requests.length,2)});
test('pending draft image read blocks send',async()=>{const {a,state}=fixture();a.composerUI.draft.media={pending:true};await a.send();assert.equal(state.requests.length,0);assert.equal(a.turns.length,0)});
test('sent quote snapshots and images survive consumed draft and retry together',async()=>{
  const {a,state}=fixture(),quote={id:'q1',text:'原文\n$x^2$ <img onerror="unsafe">',source:'正文 · A.md',file:'A.md'},image={data:'data:image/png;base64,YQ==',name:'test.png'};
  state.draft.quotes=[quote];a.composerUI.draft.media={items:[image],snapshot:()=>[image]};await a.send();
  assert.equal(state.draft.quotes.length,0);assert.deepEqual(a.turns[0].requestContext.quotes,[quote]);assert.deepEqual(Array.from(a.turns[0].requestContext.images),[image]);assert.ok(JSON.stringify(state.requests[0]).includes('原文'));
  const original=a.turns[0];original.status='error';await a.send(original);assert.deepEqual(a.turns[0].requestContext.quotes,[quote]);assert.equal(a.turns.length,1);
});


test('manual scope after a free question reaches later messages without rewriting the initial reference',async()=>{
  const {a,state}=fixture(true);a.scope.value='none';await a.send();const initial=a.attachments.frozen;
  assert.equal(a.composerUI.changeScope('document'),true);state.draft.text='Read this document';await a.send();
  assert.equal(a.turns[1].requestContext.text,'SOURCE_A');assert.ok(JSON.stringify(state.requests[1].at(-2)).includes('SOURCE_A'));
  assert.equal(a.attachments.frozen,initial);assert.equal(initial.text,'');assert.equal(a.turns[0].requestContext,undefined);
  assert.equal(a.scope.value,'document');assert.equal(a.composerUI.sourceChanged,true);
  state.draft.text='Continue';await a.send();assert.equal(a.turns[2].requestContext.text,'SOURCE_A');
});
test('scope changes while streaming apply to next turn without aborting or mutating the active request',async()=>{
  const {a,state}=fixture(true);a.scope.value='none';let before,after,activeSignal;
  a.request=async(p,k,m,opts)=>{activeSignal=opts.signal;before=JSON.stringify(m);assert.equal(a.busy,true);assert.equal(a.scopeLocked(),false);a.composerUI.changeScope('document');after=JSON.stringify(m);return{text:'CURRENT'};};
  await a.send();assert.equal(before,after);assert.equal(activeSignal.aborted,false);assert.equal(a.turns[0].status,'done');assert.equal(a.scope.value,'document');
  a.request=async(p,k,m)=>{state.requests.push(m);return{text:'NEXT'};};state.draft.text='Next';await a.send();assert.equal(a.turns[1].requestContext.text,'SOURCE_A');
});
test('request preparation briefly locks scope and failed turn retry keeps its original source',async()=>{
  const {a,state}=fixture(true);a.keyFor=async()=>{assert.equal(a.scopeLocked(),true);assert.equal(a.composerUI.changeScope('none'),false);return '';};await a.send();
  a.keyFor=async()=>'';a.composerUI.changeScope('document');state.draft.text='Retry this';await a.send();const retry=a.turns[1],source=retry.requestContext;retry.status='error';
  a.composerUI.changeScope('none');await a.send(retry);assert.equal(a.turns[1].requestContext,source);assert.equal(a.turns[1].requestContext.text,'SOURCE_A');assert.equal(a.scope.value,'none');
});
test('one-shot command source restores persistent scope and no longer aborts during key lookup',async()=>{
  const {a,state}=fixture(true);a.scope.value='none';await a.send();a.composerUI.changeScope('document');const manual=a.context;
  a.composerUI.stageSource();a.context={file:'A.md',markdown:'COMMAND_SOURCE',selected:'COMMAND_SELECTION'};a.scope.value='selection';state.draft.text='Command';await a.send();
  assert.equal(a.turns[1].status,'done');assert.equal(a.turns[1].requestContext.text,'COMMAND_SELECTION');assert.equal(a.context,manual);assert.equal(a.scope.value,'document');assert.equal(a.composerUI.sourceChanged,true);
});
test('saved manual scope and nested one-shot source restore with the correct return scope',async()=>{
  const {a}=fixture(true);a.turns=[{}];a.composerUI.changeScope('document');a.context.markdown='LATEST_DOCUMENT';
  const saved=JSON.parse(JSON.stringify(a.composerUI.snapshot())),b=fixture(true).a;b.turns=[{}];b.composerUI.restore(saved,'');
  assert.equal(b.scope.value,'document');assert.equal(b.promptsManager.reference().text,'LATEST_DOCUMENT');assert.equal(b.composerUI.sourceChanged,true);
  a.composerUI.stageSource();a.context={file:'A.md',markdown:'COMMAND_DOCUMENT',selected:'QUOTE'};a.scope.value='selection';
  const nested=JSON.parse(JSON.stringify(a.composerUI.snapshot())),c=fixture(true).a;c.turns=[{}];c.composerUI.restore(nested,'');
  assert.equal(c.promptsManager.reference().text,'QUOTE');c.composerUI.restoreSource();assert.equal(c.scope.value,'document');assert.equal(c.promptsManager.reference().text,'LATEST_DOCUMENT');assert.equal(c.composerUI.sourceChanged,true);
});

test('send freezes total elapsed time on done, error and retry with a new clock',async()=>{
  const {a,state}=fixture();a.request=async()=>{state.now=63480;return {text:'timed answer'};};await a.send();assert.equal(a.turns[0].elapsedMs,63480);assert.equal(state.saved.at(-1).turns[0].elapsedMs,63480);
  const first=a.turns[0];first.status='error';a.request=async()=>{state.now=65480;throw Error('provider error');};await a.send(first);assert.equal(a.turns[0].elapsedMs,2000);assert.equal(a.turns[0].status,'error');assert.equal(state.saved.at(-1).turns[0].elapsedMs,2000);
});
test('aborted generation records partial elapsed before document switch',async()=>{
  const {a,state}=fixture();a.request=async()=>{state.now=5180;state.file='B.md';a.checkDocument();throw Object.assign(Error('stop'),{name:'AbortError'});};await a.send();assert.equal(state.saved.at(-1).turns[0].elapsedMs,5180);assert.equal(state.saved.at(-1).turns[0].status,'stopped');
});
