const fs=require('node:fs'),path=require('node:path');
module.exports=code=>{const pos=code.lastIndexOf('(function () {');return code.slice(0,pos)+'const ETCodeWorkspace=(()=>{const module={exports:{}};'+fs.readFileSync(path.join(__dirname,'code-workspace.cjs'),'utf8')+';return module.exports;})();\n'+code.slice(pos);};
