// Per-document notebook, with independent pages and a shared editor view.
class EditingToolbarDocumentNotes extends EditingToolbarAnnotations {
    get isDocumentNote(){return true;}
    _blankNote(title='笔记 1'){const now=new Date().toISOString();return{id:this._id(),anchor:{exact:''},title,markdown:'',created:now,updated:now};}
    _createPanel(){super._createPanel();this.tabs=new DocumentNoteTabs(this);const split=this.panel.querySelector('.et-note-editor-resize');this.tabs.root.before(split);split.setAttribute('aria-label','调整素材区与笔记区高度');split.setAttribute('aria-controls','et-material-grid');}
    _uiKey(ctx){return 'et-document-note-tabs:'+this._hash(ctx.key);}
    _load(key){const ctx=super._load(key);ctx.virgin=!ctx.base&&!ctx.notes.length&&!ctx.readonly;return ctx;}
    _ui(ctx=this.ctx){
        if(!ctx)return null;
        if(!ctx.ui){let stored;try{stored=JSON.parse(localStorage.getItem(this._uiKey(ctx)));}catch(_){}
            ctx.ui={opened:Array.isArray(stored?.opened)?stored.opened:[ctx.notes[0]?.id].filter(Boolean),active:stored?.active||null,appendTarget:stored?.appendTarget||null,collapsed:Boolean(stored?.collapsed),views:stored?.views&&typeof stored.views==='object'?stored.views:{}};
        }
        const ids=new Set(ctx.notes.map(n=>n.id)),u=ctx.ui;u.opened=[...new Set(u.opened)].filter(id=>ids.has(id));
        if(!u.opened.includes(u.active))u.active=u.opened[0]||null;
        if(!ids.has(u.appendTarget))u.appendTarget=null;
        for(const id of Object.keys(u.views))if(!ids.has(id))delete u.views[id];
        return u;
    }
    _saveUI(ctx=this.ctx){if(!ctx?.ui)return;try{localStorage.setItem(this._uiKey(ctx),JSON.stringify(ctx.ui));}catch(_){} }
    _rememberPage(){const d=this.displayed;if(!d||!this.editor||this.panel.hidden)return;const note=d.ctx.notes.find(n=>n.id===d.id);if(!note)return;this._ui(d.ctx).views[d.id]={hash:this._hash(this.editor.markdown()),...this.editor.captureView()};this._saveUI(d.ctx);}
    _flushEditor(){this.tabs?.finishRename();super._flushEditor();this._rememberPage();}
    _switchDocument(){
        if(this.savingAs||this._loading())return;const key=this._key();if(!key||this.ctx?.key===key)return;
        if(this.ctx){this._flushEditor();this._save();this.tabs?.dismiss();}
        this.ctx=this.contexts.get(key)||this._load(key);this.contexts.set(key,this.ctx);this.ctx.selected=this._ui().active;this.listHeight=null;this.toolbar.researchMaterials?.setCollapsed(true);
        this._renderList();this._showSelected();this._status(this.ctx.error||(!this.ctx.file?'未命名文档：笔记暂存为本机草稿':'已载入'));
        if(this.ctx.dirty){const ctx=this.ctx;clearTimeout(this.saveTimer);this.saveTimer=setTimeout(()=>this._save(ctx),650);}
    }
    _status(text,error=false){super._status(String(text).replace(/注释/g,'笔记'),error);}
    _export(ctx){return '<!-- 此文件由工具栏自动生成；请在工具栏「笔记」中编辑。 -->\n\n'+ctx.notes.map(n=>'# '+String(n.title||'未命名笔记').replace(/[\r\n]/g,' ')+'\n\n'+n.markdown+'\n').join('\n---\n\n');}
    _afterSaveAs(previous){
        if(!previous||(!previous.base&&!previous.dirty&&!previous.notes.length))return;
        const ui=structuredClone(this._ui(previous));super._afterSaveAs(previous);
        if(this.ctx!==previous){this.ctx.virgin=false;this.ctx.ui=ui;this.ctx.selected=this._ui().active;this.listHeight=null;this.toolbar.researchMaterials?.setCollapsed(true);this._saveUI();this._renderList();this._showSelected();}
    }
    _showSelected(){
        this.editorPending=this.panel.hidden;if(this.editorPending){this.displayed=null;return;}
        this._ensureEditor();
        this.ctx.selected=this._ui().active;const n=this._selected();this.displayed=null;
        this.panel.querySelector('.et-note-work').hidden=!n;const empty=this.panel.querySelector('.et-note-empty');empty.hidden=Boolean(n);
        empty.textContent=this.ctx.readonly?'笔记暂时无法读取，请查看下方提示。':this.ctx.notes.length?'标签已全部关闭，可从“全部笔记”重新打开。':'暂无笔记，点击 ＋ 新建。';
        this.editor?.setMarkdown(n?.markdown||'',this.ctx.key+':'+(n?.id||'closed'),!n||Boolean(this.ctx.readonly));
        if(n){this.displayed={ctx:this.ctx,id:n.id};const saved=this._ui().views[n.id];if(saved?.hash===this._hash(n.markdown))this.editor.restoreView(saved);}
        this._themeEditor();this._layoutNoteSplit();
    }
    _scan(){}
    _capture(){return null;}
    _updateQuote(){this.panel.querySelector('.et-note-anchor-status').textContent='';}
    _renderList(){if(this.ctx){const u=this._ui();if(this.ctx.selected&&this.ctx.notes.some(n=>n.id===this.ctx.selected)&&u.opened.includes(this.ctx.selected))u.active=this.ctx.selected;if(!this.panel.hidden)this.tabs?.render();}if(this.panel.hidden)return;this.panel.querySelector('.et-note-count').textContent=this.ctx?.notes.length?' · '+this.ctx.notes.length+' 篇':'';this._layoutNoteSplit();}
    _layoutNoteSplit(){
        for(const selector of ['.et-note-list','.et-note-anchor-status'])this.panel.querySelector(selector).hidden=true;
        this.panel.classList.remove('et-note-auto-split');const material=this.toolbar.researchMaterials,split=this.panel.querySelector('.et-note-editor-resize');
        split.hidden=!material||material.collapsed;if(!material||material.collapsed||this.panel.hidden)return;
        const grid=material.list,frame=this.frame,tabs=this.tabs?.root;if(!frame||!tabs)return;
        const body=this.panel.querySelector('.et-panel-scroll-body'),gap=parseFloat(getComputedStyle(body).rowGap)||0;
        const shelfChrome=material.panel.offsetHeight-grid.offsetHeight;
        this.splitMax=Math.max(64,Math.floor(body.clientHeight-shelfChrome-tabs.offsetHeight-split.offsetHeight-3*gap-180));this.splitMin=48;
        const desired=Number.isFinite(this.listHeight)?this.listHeight:Math.min(120,this.panel.clientHeight*.22);
        const height=Math.round(Math.max(this.splitMin,Math.min(this.splitMax,desired)));this.renderedListHeight=height;grid.style.height=height+'px';
        split.setAttribute('aria-valuemin',String(this.splitMin));split.setAttribute('aria-valuemax',String(this.splitMax));split.setAttribute('aria-valuenow',String(height));split.setAttribute('aria-valuetext','素材区高度 '+height+' 像素');
    }
    openFromSelection(){
        try{const item=this.toolbar.documentSelection?.bodyItem();if(!item)return this.open();
            this._switchDocument();const create=this.panel.hidden||!this._selected();let i=1;while(this.ctx.notes.some(n=>n.title==='笔记 '+i))i++;
            this.appendMarkdown(EditingToolbarDocumentSelection.insertableMarkdown(item.text),'笔记 '+i,{newNote:create});getSelection()?.removeAllRanges();this.toolbar.hide();
        }catch(e){this.toolbar._showToolbarNotice(e.message);}
    }
    open(){
        this._switchDocument();const wasHidden=this.panel.hidden;
        if(wasHidden){this.listHeight=null;this.toolbar.researchMaterials?.setCollapsed(true);}this.panel.hidden=false;if(!this.toolbar.panelWorkspace)document.body.classList.add('et-annotations-open');this.toolbar.hide();this._layout();
        if(this.ctx.virgin){this.ctx.virgin=false;this.newNote();}else{this._renderList();if(wasHidden)this._showSelected();if(this._selected())this._focusEditor();}
        if(this.ctx.readonly)this._status(this.ctx.error,true);
    }
    close(){this.tabs?.dismiss();super.close();}
    newNote(){
        if(this.ctx?.readonly)return;this._flushEditor();this._save();let i=1;while(this.ctx.notes.some(n=>n.title==='笔记 '+i))i++;
        const n=this._blankNote('笔记 '+i);this.ctx.notes.push(n);this.ctx.virgin=false;const u=this._ui();u.opened.push(n.id);u.active=n.id;this.ctx.selected=n.id;
        this._touch();this._saveUI();this._renderList();this._showSelected();this._focusEditor();this.tabs.reveal(n.id);
    }
    appendMarkdown(markdown,title='阅读摘录',options={}){
        this._switchDocument();if(!this.ctx||this.ctx.readonly||this.savingAs||this._loading())throw Error('当前文档的笔记暂时无法写入');
        this._flushEditor();if(!this._save())throw Error('原笔记尚未保存，请先处理笔记保存提示');
        const u=this._ui();let n=options.newNote?null:this.ctx.notes.find(n=>n.id===u.active)||this.ctx.notes.find(n=>n.id===u.appendTarget)||this.ctx.notes[0];
        if(!n){n=this._blankNote(title);this.ctx.notes.push(n);}
        // Flush the editor before appending; keep the original Markdown byte-for-byte.
        n.markdown+=(n.markdown.trim()?'\n\n---\n\n':'')+markdown;n.updated=new Date().toISOString();this.ctx.virgin=false;
        if(!u.opened.includes(n.id))u.opened.push(n.id);u.active=n.id;u.appendTarget=n.id;this.ctx.selected=n.id;
        this._touch();const saved=this._save();this._saveUI();this.open();this._renderList();this._showSelected();this.tabs.reveal(n.id);
        // Show the appended draft even on write failure, so a later editor flush cannot replace it with the old view.
        if(!saved)throw Error('摘录保留为草稿，请查看笔记面板的保存提示');
        return n;
    }
    selectNote(id){
        if(!this.ctx.notes.some(n=>n.id===id))return;this._flushEditor();this._save();const u=this._ui();if(!u.opened.includes(id))u.opened.push(id);u.active=id;this.ctx.selected=id;
        this.tabs.dismiss();this._saveUI();this._renderList();this._showSelected();this._focusEditor();this.tabs.reveal(id);
    }
    closeTab(id){
        this._flushEditor();this._save();const u=this._ui(),ordered=this.ctx.notes.map(n=>n.id).filter(id=>u.opened.includes(id)),at=ordered.indexOf(id);u.opened=u.opened.filter(x=>x!==id);
        if(u.active===id)u.active=ordered[at+1]||ordered[at-1]||null;this.ctx.selected=u.active;
        this.tabs.dismiss();this._saveUI();this._renderList();this._showSelected();
    }
    renameNote(id,title){const n=this.ctx.notes.find(n=>n.id===id);title=title.trim().replace(/[\r\n\t]+/g,' ').slice(0,100);if(!n||!title||this.ctx.readonly)return false;this._flushEditor();n.title=title;n.updated=new Date().toISOString();this._touch();this._renderList();return true;}
    moveNote(id,target,after=false){
        if(this.ctx.readonly||id===target)return;this._flushEditor();const n=this.ctx.notes.find(n=>n.id===id);if(!n||!this.ctx.notes.some(n=>n.id===target))return;
        this.ctx.notes=this.ctx.notes.filter(n=>n.id!==id);this.ctx.notes.splice(this.ctx.notes.findIndex(n=>n.id===target)+(after?1:0),0,n);this._touch();this._renderList();this.tabs.reveal(id);
    }
    deleteNote(id){
        if(this.ctx.readonly)return;this.closeTab(id);this.ctx.notes=this.ctx.notes.filter(n=>n.id!==id);this.ctx.virgin=false;delete this._ui().views[id];this.editor.forgetState(this.ctx.key+':'+id);this._touch();this._save();this._saveUI();this._renderList();this._showSelected();
    }
    deleteStoredNote(key,id){
        // Work with the owning document even when another document is open.
        const ctx=this.contexts.get(key)||this._load(key);
        if(ctx.readonly)throw Error(ctx.error||'笔记为只读，无法删除');
        if(ctx===this.ctx)this._flushEditor();
        if(!this._save(ctx))throw Error('笔记尚未保存，未删除：'+ctx.error);
        if(!ctx.notes.some(n=>n.id===id))throw Error('这篇笔记已不存在，请刷新后重试');
        const pending={...ctx,notes:ctx.notes.filter(n=>n.id!==id),dirty:true,virgin:false};
        // The shared saver locks the index, merges edits and keeps index.previous.json.
        // Keep the live editor page until the index has actually been saved.
        if(!this._save(pending,{draft:false})){
            throw Error('删除未保存，笔记已保留：'+pending.error);
        }
        Object.assign(ctx,{notes:pending.notes,base:pending.base,dirty:false,error:'',virgin:false});
        this.contexts.set(key,ctx);this._ui(ctx);ctx.selected=ctx.ui.active;this._saveUI(ctx);
        const retained=ctx.notes.some(n=>n.id===id);
        if(!retained)this.editor?.forgetState(key+':'+id);
        if(ctx===this.ctx){this.tabs?.dismiss();this._renderList();this._showSelected();}
        if(retained)throw Error('这篇笔记已在其他窗口修改，已保留新内容；请查看后重试');
        return true;
    }
    // Merge per stable note ID; retain divergent edits as a separate page.
    _mergeNotes(base,local,remote){
        const b=new Map(base.map(n=>[n.id,n])),l=new Map(local.map(n=>[n.id,n])),r=new Map(remote.map(n=>[n.id,n]));
        const same=(a,c)=>a?.markdown===c?.markdown&&a?.title===c?.title&&Boolean(a)===Boolean(c),merged=new Map(),conflicts=[];
        for(const id of new Set([...l.keys(),...r.keys(),...b.keys()])){const before=b.get(id),left=l.get(id),right=r.get(id);let note;
            if(same(left,right)||same(right,before))note=left;
            else if(same(left,before))note=right;
            else if(!left)note=right;else if(!right)note=left;
            else {note=left;conflicts.push({...right,id:this._id(),title:(right.title||'笔记')+'（另一版本）'});}
            if(note)merged.set(id,note);
        }
        const common=ids=>ids.filter(id=>b.has(id)&&l.has(id)&&r.has(id));const baseOrder=common(base.map(n=>n.id)),localOrder=common(local.map(n=>n.id));
        const order=JSON.stringify(baseOrder)===JSON.stringify(localOrder)?[...remote,...local]:[...local,...remote];
        const seen=new Set(),result=[];for(const n of order)if(merged.has(n.id)&&!seen.has(n.id)){seen.add(n.id);result.push(merged.get(n.id));}
        return [...result,...conflicts];
    }
}
