import {Plugin} from 'prosemirror-state';

// ProseMirror retains marksAcross() after deleting a selection, and Chromium
// retains the typing mark after backspacing the last character of <code>.
// Drop only that exhausted code mark; partial edits and explicit toggles remain.
export function resetExhaustedCode(schema){
 return new Plugin({appendTransaction(transactions,oldState,state){
  const code=schema.marks.code;
  if(!state.selection.empty||!code.isInSet(state.storedMarks||state.selection.$from.marks()))return null;
  const {$from}=state.selection;
  if([$from.nodeBefore,$from.nodeAfter].some(n=>n?.isText&&code.isInSet(n.marks)))return null;
  let deletedCode=false;
  for(const tr of transactions)tr.steps.forEach((step,i)=>{
   step.getMap().forEach((from,to,newFrom,newTo)=>{
    // Replacing selected code with new text keeps its intentional formatting.
    if(to>from&&newTo===newFrom&&tr.docs[i].rangeHasMark(from,to,code))deletedCode=true;
   });
  });
  return deletedCode?state.tr.removeStoredMark(code):null;
 }});
}
