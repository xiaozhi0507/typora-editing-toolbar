// Cache pointer geometry once; apply at most one visual update per animation frame.
function attachMovablePreferences(dialog, onStart = () => {}) {
    const backdrop=dialog.parentElement, key='et-preferences-geometry-v1', kind=dialog.classList.contains('et-theme-dialog')?'appearance':'toolbar';
    let disposed=false, gesture=null, frame=0, suppressUntil=0;
    const viewport=()=>({width:document.documentElement.clientWidth,height:innerHeight});
    const clamp=(n,min,max)=>Math.max(min,Math.min(n,Math.max(min,max)));
    const rect=()=>{const r=dialog.getBoundingClientRect();return {left:r.left,top:r.top,width:r.width,height:r.height};};
    const apply=r=>{for(const [k,v] of Object.entries(r))dialog.style[k]=v+'px';};
    const fit=r=>{const v=viewport(),width=clamp(r.width,Math.min(320,v.width-24),v.width-24),height=clamp(r.height,Math.min(260,v.height-24),v.height-24);return {width,height,left:clamp(r.left,12,v.width-width-12),top:clamp(r.top,12,v.height-height-12)};};
    const save=()=>{try{const all=JSON.parse(localStorage.getItem(key)||'{}');all[kind]=rect();localStorage.setItem(key,JSON.stringify(all));}catch{}};
    const paint=()=>{
        frame=0;const g=gesture;if(!g)return;
        let {left,top,width,height}=g.start,right=left+width,bottom=top+height;
        if(!g.edge){g.next={left:clamp(left+g.dx,12,g.view.width-width-12),top:clamp(top+g.dy,12,g.view.height-height-12),width,height};dialog.style.transform='translate3d('+(g.next.left-left)+'px,'+(g.next.top-top)+'px,0)';return;}
        const minW=Math.min(320,g.view.width-24),minH=Math.min(260,g.view.height-24);
        if(g.edge.includes('w'))left=clamp(left+g.dx,12,right-minW);
        if(g.edge.includes('e'))right=clamp(right+g.dx,left+minW,g.view.width-12);
        if(g.edge.includes('n'))top=clamp(top+g.dy,12,bottom-minH);
        if(g.edge.includes('s'))bottom=clamp(bottom+g.dy,top+minH,g.view.height-12);
        g.next={left,top,width:right-left,height:bottom-top};apply(g.next);
    };
    const finish=(cancel=false)=>{
        const g=gesture;if(!g)return;cancelAnimationFrame(frame);frame=0;if(!cancel&&g.changed)paint();gesture=null;
        dialog.style.transform='';if(cancel)apply(g.start);else if(g.next)apply(g.next);
        dialog.classList.remove('et-preferences-dragging','et-preferences-resizing');
        if(g.changed){suppressUntil=performance.now()+250;if(!cancel)save();}
        if(dialog.hasPointerCapture(g.id))dialog.releasePointerCapture(g.id);
    };
    const down=e=>{
        const edge=e.target.closest('[data-preferences-edge]')?.dataset.preferencesEdge||'';
        if(e.button!==0||e.isPrimary===false||gesture||(!edge&&(!e.target.closest('[data-preferences-move]')||e.target.closest('button,input,select,textarea,a'))))return;
        e.preventDefault();onStart();gesture={id:e.pointerId,x:e.clientX,y:e.clientY,dx:0,dy:0,edge,start:rect(),view:viewport(),changed:false};dialog.setPointerCapture(e.pointerId);
    };
    const move=e=>{const g=gesture;if(!g||g.id!==e.pointerId)return;g.dx=e.clientX-g.x;g.dy=e.clientY-g.y;if(!g.changed&&Math.hypot(g.dx,g.dy)<2)return;e.preventDefault();g.changed=true;dialog.classList.add(g.edge?'et-preferences-resizing':'et-preferences-dragging');if(!frame)frame=requestAnimationFrame(paint);};
    const up=e=>{if(gesture?.id===e.pointerId){move(e);finish();}};
    const cancel=()=>finish(true);
    const resize=()=>{finish(true);apply(fit(rect()));};
    const keydown=e=>{
        if(e.key==='Escape'&&gesture){e.preventDefault();e.stopImmediatePropagation();finish(true);return;}
        if(e.target.dataset.preferencesEdge==='se'&&['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();const r=rect(),step=e.shiftKey?40:10;r.width+=e.key==='ArrowRight'?step:e.key==='ArrowLeft'?-step:0;r.height+=e.key==='ArrowDown'?step:e.key==='ArrowUp'?-step:0;onStart();apply(fit(r));save();}
    };
    const click=e=>{if(e.detail&&performance.now()<suppressUntil){e.preventDefault();e.stopImmediatePropagation();suppressUntil=0;}};
    const ensureHandles=()=>{if(disposed||dialog.querySelector('[data-preferences-edge]'))return;for(const edge of ['n','s','e','w','ne','nw','se','sw']){const handle=document.createElement('div');handle.className='et-preferences-resize';handle.dataset.preferencesEdge=edge;handle.setAttribute('role','separator');handle.setAttribute('aria-label','调整窗口大小 '+edge);handle.tabIndex=edge==='se'?0:-1;dialog.append(handle);}};
    let initial=rect();try{const saved=JSON.parse(localStorage.getItem(key)||'{}')[kind];if(saved&&['left','top','width','height'].every(k=>Number.isFinite(saved[k])))initial=saved;}catch{}
    dialog.classList.add('et-movable-preferences');apply(fit(initial));ensureHandles();
    // Appearance replaces its controls when the mode changes; handles must survive that render.
    const observer=new MutationObserver(ensureHandles);observer.observe(dialog,{childList:true});
    dialog.addEventListener('pointerdown',down);dialog.addEventListener('lostpointercapture',cancel);
    window.addEventListener('pointermove',move,true);window.addEventListener('pointerup',up,true);window.addEventListener('pointercancel',cancel,true);window.addEventListener('blur',cancel);window.addEventListener('keydown',keydown,true);window.addEventListener('resize',resize);backdrop.addEventListener('click',click,true);
    return()=>{disposed=true;finish(true);observer.disconnect();dialog.removeEventListener('pointerdown',down);dialog.removeEventListener('lostpointercapture',cancel);window.removeEventListener('pointermove',move,true);window.removeEventListener('pointerup',up,true);window.removeEventListener('pointercancel',cancel,true);window.removeEventListener('blur',cancel);window.removeEventListener('keydown',keydown,true);window.removeEventListener('resize',resize);backdrop.removeEventListener('click',click,true);};
}
