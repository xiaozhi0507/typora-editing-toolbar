const fs=require('fs'),path=require('path');
module.exports=code=>{
 const replace=(a,b)=>{if(!code.includes(a))throw Error('Missing palette integration '+a.slice(0,80));code=code.replace(a,b);};
 // Preserve the early saved palette even before the full manager is ready.
 replace('        document.head.appendChild(link);','        document.head.insertBefore(link, document.getElementById("et-theme-palette-overrides"));');
 const icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M12 3a9 9 0 1 0 0 18h1a2 2 0 0 0 1-3.7 1.5 1.5 0 0 1 1-2.8h2a4 4 0 0 0 4-4C21 6 17 3 12 3Z"/><circle cx="7" cy="10" r=".8"/><circle cx="10" cy="7" r=".8"/><circle cx="15" cy="7" r=".8"/><circle cx="17" cy="11" r=".8"/></svg>';
 replace('const BUTTON_DEFINITIONS = {',`const BUTTON_DEFINITIONS = {\n"theme-palette":{icon:${JSON.stringify(icon)},title:'主题配色'},`);
 code=code.replaceAll('"more-menu","toolbar-settings"','"more-menu","theme-palette","toolbar-settings"');
 code=code.replaceAll('"floating-toolbar-toggle","toolbar-settings"','"floating-toolbar-toggle","theme-palette","toolbar-settings"');
 code=code.replaceAll('...this._menuActionIds("more-menu"),"toolbar-settings"','...this._menuActionIds("more-menu"),"theme-palette","toolbar-settings"');
 code=code.replaceAll('manualMarksRevision:1,','manualMarksRevision:1,themePaletteRevision:1,');
 replace('        const top = topLayout === "classic"',`        if(!input.themePaletteRevision){for(const ids of [compact.order,classic.buttons])if(!ids.includes('theme-palette'))ids.splice(Math.max(0,ids.indexOf('toolbar-settings')),0,'theme-palette');}
        const top = topLayout === "classic"`);
 replace('        if (action === "annotation")','        if (action === "theme-palette") {this.themePalette?.open();return;}\n        if (action === "annotation")');
 replace('this.researchSidebar=new ETResearchSidebar.ResearchSidebar(this,ETResearchIndexWorkerSource);','this.researchSidebar=new ETResearchSidebar.ResearchSidebar(this,ETResearchIndexWorkerSource);this.themePalette=new EditingToolbarThemePalette(this);');
 replace('root.style.setProperty(key,value.trim());}','root.style.setProperty(key,value.trim());this.toolbar.themePalette?.styleFrame(this.frame);}');
 const pos=code.lastIndexOf('(function () {');if(pos<0)throw Error('Missing palette boot');return code.slice(0,pos)+fs.readFileSync(path.join(__dirname,'preferences-dialogs.js'),'utf8')+'\n'+fs.readFileSync(path.join(__dirname,'theme-codex-presets.js'),'utf8')+'\n'+fs.readFileSync(path.join(__dirname,'theme-palette.js'),'utf8')+'\n'+code.slice(pos);
};
