class EditingToolbarAISkills {
 constructor(ai){this.ai=ai;this.items=[];this.selected=[];this.excluded=[];}
 init(){if(this.ready)return this.ready;this.store=new ETAISkills(reqnode,reqnode('path').join(File.option.userDataPath,'editing-toolbar','skills'));this.ready=this.refresh().catch(e=>{this.error(e);return [];});return this.ready;}
 icon(){return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m12 2 9 5v10l-9 5-9-5V7zM3 7l9 5 9-5M12 12v10M7.5 4.5l9 5v5"/></svg>';}
 button(label,fn,icon){const b=this.ai.node('button','',icon?null:label);b.type='button';b.title=label;b.setAttribute('aria-label',label);if(icon)b.innerHTML=icon;b.onclick=()=>Promise.resolve().then(fn).catch(e=>this.error(e));return b;}
 error(e){const el=this.dialog?.open?this.detailStatus:this.status;if(el){el.textContent=e.message;el.hidden=false;}else this.ai.notice(e.message,true);}
 mount(){
  const a=this.ai,tab=this.button('技能',()=>a.setView('skills'));tab.dataset.ai='skills';tab.setAttribute('role','tab');tab.setAttribute('aria-selected','false');tab.tabIndex=-1;a.nav.append(tab);
  this.panel=a.node('section','et-ai-skills');this.panel.hidden=true;this.panel.setAttribute('aria-label','技能管理');a.preferencesStatus.before(this.panel);
  const head=a.node('div','et-skills-head'),title=a.node('div','et-skills-heading');title.append(a.node('h2','','技能'),a.node('p','','通过任务专用技能扩展 AI 阅读助手'));
  const controls=a.node('div','et-skills-controls');this.search=a.node('input');this.search.type='search';this.search.placeholder='搜索技能';this.search.setAttribute('aria-label','搜索技能');this.search.oninput=()=>this.render();const searchbox=a.node('div','et-skills-search');searchbox.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/></svg>';searchbox.append(this.search);
  this.reload=this.button('刷新技能',()=>this.refreshFeedback(this,()=>this.refresh()),'<svg viewBox="0 0 24 24"><path d="M20 4v6h-6M4 20v-6h6M4.8 9a7.5 7.5 0 0 1 12.4-4L20 8M4 16l2.8 3A7.5 7.5 0 0 0 19.2 15"/></svg>');
  this.manage=this.button('技能管理设置',()=>this.management(),'<svg viewBox="0 0 24 24"><path d="M4 7h9m4 0h3M4 17h3m4 0h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/></svg>');const add=this.button('添加',()=>this.addDialog(),'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>');add.append(a.node('span','','添加'));add.className='et-skills-add';controls.append(searchbox,this.reload,this.manage,add);head.append(title,controls);
  this.status=a.node('p','et-skills-status');this.status.setAttribute('role','status');this.status.hidden=true;this.scroll=a.node('div','et-skills-scroll');const installed=a.node('div','et-skills-installed');this.count=a.node('span','et-skills-count','0');installed.append(a.node('h3','','已安装'),this.count);this.scroll.append(installed);this.list=a.node('div','et-skills-grid');this.scroll.append(this.list);this.panel.append(head,this.status,this.scroll);
  this.chips=a.node('div','et-ai-skill-chips');a.prompt.before(this.chips);a.prompt.addEventListener('input',()=>this.sync());void this.init();
 }
 async refreshFeedback(owner,run){
  if(owner._refreshFeedback)return owner._refreshFeedback;
  const button=owner.reload,list=owner.list;button?.classList.add('is-refreshing');if(button){button.disabled=true;button.setAttribute('aria-busy','true');}
  owner._refreshFeedback=(async()=>{try{
   const [result]=await Promise.all([Promise.resolve().then(run),new Promise(resolve=>setTimeout(resolve,520))]);
   if(list?.isConnected){list.classList.remove('et-refresh-flash');void list.offsetWidth;list.classList.add('et-refresh-flash');}return result;
  }finally{owner._refreshFeedback=null;button?.classList.remove('is-refreshing');if(button){button.disabled=false;button.removeAttribute('aria-busy');}}})();return owner._refreshFeedback;
 }
 async refresh(){if(this.reloading)return;this.reloading=true;if(this.reload){this.reload.disabled=true;this.reload.setAttribute('aria-busy','true');}try{this.items=await this.store.list();this.render();this.sync();if(this.status){this.status.hidden=true;this.status.textContent='';}return this.items;}finally{this.reloading=false;if(this.reload&&!this._refreshFeedback){this.reload.disabled=false;this.reload.removeAttribute('aria-busy');}}}
 render(){if(!this.list)return;this.closeMenu();const scroll=this.scroll.scrollTop,q=this.search.value.trim().toLowerCase();this.list.replaceChildren();const rows=this.items.filter(s=>[s.name,s.displayName,s.description,s.source].join(' ').toLowerCase().includes(q));this.count.textContent=String(this.items.length);this.count.setAttribute('aria-label',this.items.length+' 个已安装技能');this.list.classList.toggle('is-single',rows.length===1);
  for(const s of rows){const row=this.button(s.displayName||s.name,()=>this.details(s.id));row.className='et-skill-row';row.dataset.skill=s.name;row.dataset.skillId=s.id;row.setAttribute('aria-haspopup','menu');row.oncontextmenu=e=>{e.preventDefault();e.stopPropagation();this.cardMenu(row,s,{x:e.clientX,y:e.clientY});};row.onkeydown=e=>{if(e.key==='ContextMenu'||e.shiftKey&&e.key==='F10'){e.preventDefault();e.stopPropagation();this.cardMenu(row,s);}};if(this.exporting?.has(s.id))row.setAttribute('aria-busy','true');row.replaceChildren();row.append(this.image(s),this.copy(s));row.dataset.state=s.error?'error':s.enabled?'enabled':'disabled';const state=this.ai.node('span','et-skill-state');state.setAttribute('role','img');state.title=s.error?'无法读取':s.enabled?'已启用':'已禁用';state.setAttribute('aria-label',state.title);state.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true">'+(s.error?'<circle cx="12" cy="12" r="8"/><path d="M12 7v6m0 3v.2"/>':s.enabled?'<path d="m6 12 4 4 8-8"/>':'<circle cx="12" cy="12" r="7"/><path d="M8 12h8"/>')+'</svg>';row.append(state);row.title=s.error||s.description;this.list.append(row);}
  if(!rows.length)this.list.append(this.ai.node('p','et-skills-empty',q?'没有匹配的技能':'尚未添加技能'));this.scroll.scrollTop=scroll;
 }
 image(s){const n=this.ai.node('span','et-skill-icon');if(s.iconData){const img=this.ai.node('img');img.src=s.iconData;img.alt='';n.append(img);}else n.innerHTML=this.icon();return n;}
 copy(s){const n=this.ai.node('span','et-skill-copy');n.append(this.ai.node('strong','',s.displayName||s.name),this.ai.node('span','',s.error||s.shortDescription||s.description));return n;}
 async toggle(s,value){this.store.enable(s.id,value);s.enabled=value;const cached=this.items.find(x=>x.id===s.id);if(cached)cached.enabled=value;if(!value)this.selected=this.selected.filter(n=>n!==s.name);this.render();this.sync();this.ai.conversations.schedule();}
 modal(label,cls){const d=this.ai.node('dialog',cls);d.setAttribute('aria-label',label);document.body.append(d);this.ai.bindSurface(d);d.addEventListener('close',()=>d.remove(),{once:true});return d;}
 async details(id){this.closeMenu();const s=this.items.find(x=>x.id===id);if(!s)return;const focus=document.activeElement;const d=this.dialog=this.modal('技能详情','et-skill-dialog');const a=this.ai;const head=a.node('div','et-skill-detail-head'),top=a.node('div','et-skill-top'),actions=a.node('div','et-skill-actions'),toggle=this.button('启用技能',async()=>{await this.toggle(s,!s.enabled);toggle.setAttribute('aria-checked',String(s.enabled));trial.disabled=!s.enabled||!!s.error;});toggle.textContent='';toggle.className='et-skill-switch';toggle.setAttribute('role','switch');toggle.setAttribute('aria-checked',String(s.enabled));
  const more=this.button('技能操作',()=>this.moreMenu(more,s),'<svg viewBox="0 0 24 24"><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></svg>');more.setAttribute('aria-haspopup','menu');const close=this.button('关闭技能详情',()=>d.close(),'<svg viewBox="0 0 24 24"><path d="m6 6 12 12M18 6 6 18"/></svg>');actions.append(toggle,more,close);top.append(this.image(s),actions);
  head.append(top,a.node('h2','',s.displayName||s.name),a.node('p','et-skill-description',s.description));const source=a.node('div','et-skill-source',(s.mode==='copy'?'副本 · ':'引用 · ')+s.source);source.title=s.source;head.append(source);
  this.detailStatus=a.node('p','et-skills-status');this.detailStatus.setAttribute('role','status');this.detailStatus.hidden=true;head.append(this.detailStatus);const body=a.node('div','et-skill-markdown et-ai-answer');body.tabIndex=0;body.setAttribute('aria-label','技能 Markdown 内容');body.textContent='正在读取…';
  const foot=a.node('div','et-skill-footer'),uninstall=this.button('卸载',()=>this.confirmUninstall(s,d));uninstall.className='et-skill-uninstall';const trial=this.button('立即试用',()=>this.trySkill(s));trial.className='et-skill-try';trial.disabled=!s.enabled||!!s.error;foot.append(uninstall,trial);d.append(head,body,foot);d.addEventListener('close',()=>{this.closeMenu();if(this.dialog===d)this.dialog=null;(focus?.isConnected?focus:this.list.querySelector('[data-skill="'+CSS.escape(s.name)+'"]'))?.focus({preventScroll:true});});d.showModal();close.focus();
  try{const detail=await this.store.inspect(s.root,s.entry);if(!d.open)return;Object.assign(s,detail);const manager=a.toolbar.annotations;manager._ensureRenderer().renderPreview(body,detail.body,{isCurrent:()=>d.open,renderMath:(tex,display)=>manager._renderMath(tex,display),openLink:url=>{if(/^https?:\/\//i.test(url))reqnode('electron').shell.openExternal(url);}});const limits=detail.dependencies.length?'外部工具依赖尚未连接：'+detail.dependencies.map(x=>x.value||x.type).join('、'):'';if(detail.warnings.length||limits){this.detailStatus.hidden=false;this.detailStatus.textContent=[...detail.warnings,limits].filter(Boolean).join('；');}}
  catch(e){body.textContent='无法显示技能内容';trial.disabled=true;this.error(e);}
 }
 closeMenu(restore=false){const anchor=this.menuAnchor;this.menuCleanup?.();this.menuCleanup=null;this.menu?.remove();this.menu=null;this.menuAnchor=null;anchor?.setAttribute('aria-expanded','false');if(restore&&anchor?.isConnected)anchor.focus({preventScroll:true});}
 async viewDirectory(s){const row=await this.store.location(s.id),error=await reqnode('electron').shell.openPath(row.root);if(error)throw Error('无法打开技能目录：'+error);}
 async packageSkill(s){
  this.exporting??=new Set();if(this.exporting.has(s.id))return;this.exporting.add(s.id);
  const mark=value=>{for(const row of this.list.querySelectorAll('[data-skill-id]'))if(row.dataset.skillId===s.id){if(value)row.setAttribute('aria-busy','true');else row.removeAttribute('aria-busy');}};mark(true);
  try{const result=await JSBridge.invoke('dialog.showOpenDialog',{title:'选择技能打包保存文件夹',buttonLabel:'保存到此文件夹',properties:['openDirectory','createDirectory']});if(result?.canceled||!result?.filePaths?.[0])return;
   const status=this.dialog?.open?this.detailStatus:this.status;status.hidden=false;status.textContent='正在打包 '+(s.displayName||s.name)+'…';status.title='';
   const exported=await this.store.exportZip(s.id,result.filePaths[0]);status.textContent='';status.title='';status.hidden=true;return exported;
  }finally{this.exporting.delete(s.id);mark(false);}
 }
 menuIcon(name){return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="'+({folder:'M3 7V5h6l2 2h10v13H3Z',zip:'m12 3 9 5v12H3V8ZM3 8h18M12 8v12M9 3l3 5 3-5',open:'M14 3H4v18h16V11M13 4h7v7M10 14 20 4',copy:'M8 8h12v13H8ZM16 8V3H3v13h5'}[name])+'"/></svg>';}
 cardMenu(anchor,s,point){this.openSkillMenu(anchor,s,point,false);}
 moreMenu(anchor,s){this.openSkillMenu(anchor,s,null,true);}
 openSkillMenu(anchor,s,point,detail){
  const actions=[['查看目录','folder',()=>this.viewDirectory(s)],['一键打包…','zip',()=>this.packageSkill(s),!!this.exporting?.has(s.id)]];
  if(detail)actions.push(['打开 SKILL.md','open',async()=>{const file=await this.store.resolve(s.root,s.entry||'SKILL.md');const error=await reqnode('electron').shell.openPath(file);if(error)throw Error(error);}],['复制 Markdown','copy',async()=>this.ai.referencesUI.copyText(await this.store.text(s.root,s.entry||'SKILL.md'))]);
  this.openActionMenu(anchor,actions,{point,host:detail?this.dialog:this.ai.preferences});
 }
 openActionMenu(anchor,actions,{point,host=this.ai.preferences,owner=this,label='技能操作'}={}){
  if(this.menuAnchor===anchor&&!point){this.closeMenu(true);return;}this.closeMenu();if(!host)return;
  const menu=this.menu=this.ai.node('div','et-skill-menu et-skill-action-menu');this.menuAnchor=anchor;menu.setAttribute('role','menu');menu.setAttribute('aria-label',label);anchor.setAttribute('aria-expanded','true');host.append(menu);
  for(const [text,icon,fn,disabled] of actions){const b=owner.button(text,async()=>{this.closeMenu(true);await fn();},this.menuIcon(icon));b.append(this.ai.node('span','',text));b.setAttribute('role','menuitem');b.disabled=!!disabled;menu.append(b);}
  const r=anchor.getBoundingClientRect(),bounds=host.getBoundingClientRect(),m=menu.getBoundingClientRect(),x=point?.x??r.left,y=point?.y??r.bottom+5;
  const left=Math.max(bounds.left+8,Math.min(x,bounds.right-m.width-8,innerWidth-m.width-8)),top=Math.max(bounds.top+8,Math.min(y,bounds.bottom-m.height-8,innerHeight-m.height-8));
  menu.style.left=(left-bounds.left-host.clientLeft)+'px';menu.style.top=(top-bounds.top-host.clientTop)+'px';
  menu.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();this.closeMenu(true);}else if(e.key==='Tab'){this.closeMenu(true);}else if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){e.preventDefault();e.stopPropagation();const nodes=[...menu.querySelectorAll('button:not(:disabled)')],i=nodes.indexOf(document.activeElement);nodes[e.key==='Home'?0:e.key==='End'?nodes.length-1:(i+(e.key==='ArrowUp'?-1:1)+nodes.length)%nodes.length]?.focus();}});
  const outside=e=>{if(!menu.contains(e.target)&&!anchor.contains(e.target))this.closeMenu();},scroll=e=>{if(!menu.contains(e.target))this.closeMenu();},resize=()=>this.closeMenu();
  document.addEventListener('pointerdown',outside,true);document.addEventListener('scroll',scroll,true);window.addEventListener('resize',resize);
  const observer=new MutationObserver(()=>{if(owner.panel.hidden||this.ai.preferencesBackdrop?.hidden||!anchor.isConnected)this.closeMenu();});observer.observe(owner.panel,{attributes:true,attributeFilter:['hidden']});if(this.ai.preferencesBackdrop)observer.observe(this.ai.preferencesBackdrop,{attributes:true,attributeFilter:['hidden']});
  this.menuCleanup=()=>{document.removeEventListener('pointerdown',outside,true);document.removeEventListener('scroll',scroll,true);window.removeEventListener('resize',resize);observer.disconnect();};
  menu.querySelector('button:not(:disabled)')?.focus({preventScroll:true});
 }
 selectSkill(name){this.store.active(name);if(this.ai.busy)throw Error('请等待当前任务结束后再选择技能');if(!this.selected.includes(name))this.selected.push(name);this.excluded=this.excluded.filter(n=>n!==name);this.sync();this.ai.conversations.schedule();}
 async trySkill(s){this.selectSkill(s.name);if(!this.ai.prompt.value.trim()&&s.defaultPrompt)this.ai.prompt.value=s.defaultPrompt;this.dialog?.close();this.ai.settingsUI.closeWindow(false);this.ai.panel.hidden=false;this.sync();this.ai.composerUI.sync();this.ai.conversations.schedule();this.ai.prompt.focus();}
 confirmUninstall(s,parent){const d=this.modal('卸载技能','et-skill-form'),a=this.ai;d.append(a.node('h3','','卸载 '+(s.displayName||s.name)),a.node('p','',s.mode==='copy'?'将删除插件保存的技能副本，原始目录保留。':'仅移除此技能引用，原始文件保留。'));const actions=a.node('div','et-skill-form-actions'),error=a.node('p','et-skills-status');actions.append(this.button('取消',()=>d.close()),this.button('卸载',async()=>{try{await this.store.uninstall(s.id);this.selected=this.selected.filter(n=>n!==s.name);d.close();parent.close();await this.refresh();}catch(e){error.textContent=e.message;}}));d.append(error,actions);d.showModal();}
 addDialog(){
  const d=this.modal('添加技能','et-skill-form et-skill-import'),a=this.ai;
  const top=a.node('div','et-skill-import-head'),close=this.button('关闭添加技能',()=>d.close(),'<svg viewBox="0 0 24 24"><path d="m6 6 12 12M18 6 6 18"/></svg>');top.append(a.node('h3','','添加本机技能'),close);
  const content=a.node('div','et-skill-import-body'),pathbox=a.node('div','et-skill-path'),input=a.node('input');input.type='text';input.placeholder='技能 .zip、.md 或文件夹路径';input.setAttribute('aria-label','技能 ZIP、Markdown 或文件夹');input.spellcheck=false;
  const err=a.node('p','et-skills-status');err.setAttribute('role','status');err.hidden=true;
  const candidates=a.node('div','et-skill-candidates');candidates.hidden=true;
  let rows=[],loaded='',generation=0,busy=false;
  const report=message=>{err.textContent=message||'';err.hidden=!message;};
  const syncAdd=()=>{const count=rows.filter(r=>r.selected&&!r.error).length;add.disabled=busy||(!rows.length?!input.value.trim():!count);add.textContent=busy?'正在处理…':rows.length?(count>1?'添加 '+count+' 个技能':'添加技能'):'继续';add.setAttribute('aria-label',add.textContent);};
  const setBusy=value=>{busy=value;d.setAttribute('aria-busy',String(value));for(const el of [input,browse,add,close,cancel,...candidates.querySelectorAll('input,textarea')])el.disabled=value;syncAdd();};
  const scan=async paths=>{
   if(busy)return;const serial=++generation;setBusy(true);report('');rows=[];candidates.replaceChildren();candidates.hidden=true;loaded='';
   try{const files=new Set();for(const p of paths)for(const file of await this.store.discover(p))files.add(file);if(files.size>100)throw Error('一次最多添加 100 个技能');
    const state=this.store.state();
    for(const file of files){if(!d.open||serial!==generation)return;let s;try{s=await this.store.preview(file);}catch(e){s={file,error:e.message};}
     const row={...s,selected:!s.error};if(state.items.some(x=>x.name.toLowerCase()===s.name?.toLowerCase())){row.error='已安装同名技能：'+s.name;row.selected=false;}rows.push(row);
     const card=a.node('div','et-skill-candidate'),label=a.node('label'),check=a.node('input');check.type='checkbox';check.checked=row.selected;check.disabled=!!row.error;check.setAttribute('aria-label','选择 '+(s.displayName||reqnode('path').basename(file)));check.onchange=()=>{row.selected=check.checked;syncAdd();};row.check=check;
     const text=a.node('span','et-skill-candidate-text');text.append(a.node('strong','',s.displayName||reqnode('path').basename(file)),a.node('span','',s.archive?reqnode('path').basename(s.archive)+' · '+s.resourceCount+' 个文件':reqnode('path').basename(file)));label.append(check,this.image(s),text);card.append(label);
     if(row.error)card.append(a.node('p','et-skill-import-error',row.error));
     else if(s.needsMetadata){card.append(a.node('p','et-skill-import-note','确认名称和简介后，将在副本中补全技能信息。'));
      for(const [key,title] of [['name','技能名称'],['description','技能简介']]){const field=a.node('label','et-skill-metadata'),control=a.node(key==='description'?'textarea':'input');control.value=s[key];control.setAttribute('aria-label',title+' · '+reqnode('path').basename(file));if(key==='description')control.rows=3;else control.maxLength=100;control.oninput=()=>row[key]=control.value;field.append(a.node('span','',title),control);card.append(field);}
     }else card.append(a.node('p','et-skill-import-description',s.description));
     candidates.append(card);
    }
    candidates.hidden=false;loaded=input.value;report(rows.every(r=>r.error)?'未找到可添加的技能，请检查上面的具体原因。':'');
   }catch(e){report(e.message);}finally{if(serial===generation){setBusy(false);for(const row of rows)if(row.error)row.check.disabled=true;}}
  };
  const browse=this.button('选择技能文件',async()=>{if(busy)return;try{const result=await JSBridge.invoke('dialog.showOpenDialog',{title:'选择技能 ZIP 或 Markdown',properties:['openFile','multiSelections'],filters:[{name:'技能文件',extensions:['zip','md']}]});if(result?.filePaths?.[0]&&d.open){input.value=result.filePaths.length===1?result.filePaths[0]:'已选择 '+result.filePaths.length+' 个文件';await scan(result.filePaths);}}catch(e){report(e.message);}},'<svg viewBox="0 0 24 24"><path d="M3 7V6a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Zm0 1h18"/></svg>');const folder=this.button('选择技能文件夹',async()=>{if(busy)return;const result=await JSBridge.invoke('dialog.showOpenDialog',{title:'选择技能文件夹',properties:['openDirectory']});if(result?.filePaths?.[0]&&d.open){input.value=result.filePaths[0];await scan([input.value]);}});folder.className='et-skill-folder-pick';pathbox.append(input,browse);
  const drop=a.node('div','et-skill-drop-hint');drop.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 15V3m-4 4 4-4 4 4M4 15v5h16v-5"/></svg>';drop.append(a.node('span','','拖入技能 .zip、.md 或文件夹，也可粘贴路径'));
  const actions=a.node('div','et-skill-form-actions'),cancel=this.button('取消',()=>d.close()),add=this.button('继续',async()=>{
   if(busy)return;if(!rows.length||loaded!==input.value){await scan([input.value]);return;}
   const selected=rows.filter(r=>r.selected&&!r.error);if(!selected.length){report('请选择要添加的技能');return;}
   setBusy(true);report('');const failures=[];let count=0;
   try{for(const row of selected){try{await this.store.add(row.file,'copy',row.needsMetadata?{name:row.name,description:row.description}:undefined);row.selected=false;row.check.checked=false;row.error='已添加';count++;}catch(e){failures.push(reqnode('path').basename(row.file)+'：'+e.message);}}
    await this.refresh();if(!failures.length)d.close();else{report((count?'已添加 '+count+' 个技能。':'')+failures.join('；'));for(const row of rows)if(row.error==='已添加')row.check.closest('.et-skill-candidate').classList.add('is-added');}
   }finally{setBusy(false);for(const row of rows)if(row.error)row.check.disabled=true;}
  });actions.append(cancel,add);add.className='et-skill-import-submit';
  input.addEventListener('input',()=>{loaded='';rows=[];candidates.hidden=true;report('');syncAdd();});input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();void scan([input.value]);}});
  const hasFiles=e=>[...(e.dataTransfer?.types||[])].includes('Files');
  const drag=e=>{if(!hasFiles(e))return;e.preventDefault();e.stopImmediatePropagation();if(e.dataTransfer)e.dataTransfer.dropEffect=busy?'none':'copy';d.classList.toggle('is-dragging',!busy);};
  const receive=async e=>{if(!hasFiles(e))return;e.preventDefault();e.stopImmediatePropagation();d.classList.remove('is-dragging');if(busy)return;try{const files=[...(e.dataTransfer?.files||[])],webUtils=reqnode('electron').webUtils;const paths=files.map(file=>webUtils?.getPathForFile?.(file)||file.path).filter(Boolean);if(!paths.length)throw Error('无法取得本机文件路径，请使用文件夹按钮或粘贴路径');input.value=paths.length===1?paths[0]:'已拖入 '+paths.length+' 个文件';await scan(paths);}catch(error){report(error.message);}};
  // Capture before Typora's document drop handler, so importing never opens or edits the document.
  document.addEventListener('dragenter',drag,true);document.addEventListener('dragover',drag,true);document.addEventListener('drop',receive,true);
  d.addEventListener('dragleave',e=>{if(!d.contains(e.relatedTarget))d.classList.remove('is-dragging');});d.addEventListener('cancel',e=>{if(busy)e.preventDefault();});
  d.addEventListener('close',()=>{generation++;document.removeEventListener('dragenter',drag,true);document.removeEventListener('dragover',drag,true);document.removeEventListener('drop',receive,true);});
  content.append(pathbox,folder,drop,candidates,err);d.append(top,content,actions);d.showModal();syncAdd();input.focus();
 }
 management(){
  const d=this.modal('技能管理设置','et-skill-form et-skill-management'),a=this.ai;
  const top=a.node('div','et-skill-management-head'),close=this.button('关闭技能管理',()=>d.close(),'<svg viewBox="0 0 24 24"><path d="m6 6 12 12M18 6 6 18"/></svg>');top.append(a.node('h3','','技能管理'),close);
  const body=a.node('div','et-skill-management-body'),auto=a.node('div','et-skill-auto-row'),copy=a.node('div','et-skill-setting-copy');copy.append(a.node('strong','','自动匹配技能'),a.node('p','','根据当前任务的需要，选择已启用的技能'));
  const status=a.node('p','et-skills-status');status.setAttribute('role','status');status.hidden=true;const report=e=>{status.textContent=e?.message||'';status.hidden=!e;};
  const toggle=this.button('自动匹配技能',()=>{try{const value=!this.store.state().automatic;this.store.save(s=>s.automatic=value);toggle.setAttribute('aria-checked',String(value));report(null);}catch(e){report(e);}});toggle.textContent='';toggle.className='et-skill-switch';toggle.setAttribute('role','switch');toggle.setAttribute('aria-checked',String(this.store.state().automatic));auto.append(copy,toggle);
  const directory=a.node('div','et-skill-directory'),info=a.node('div','et-skill-setting-copy');info.append(a.node('strong','','技能存储位置'));const path=a.node('p','',this.store.directory);path.title=this.store.directory;info.append(path);
  const open=this.button('打开存储目录',async()=>{try{await reqnode('fs').promises.mkdir(this.store.directory,{recursive:true});const error=await reqnode('electron').shell.openPath(this.store.directory);if(error)throw Error(error);report(null);}catch(e){report(e);}},'<svg viewBox="0 0 24 24"><path d="M3 7V6a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v10a2 2 0 0 1-2-2H5a2 2 0 0 1-2-2V7Zm0 1h18"/></svg>');directory.append(info,open);
  const hint=a.node('p','et-skill-management-hint','仅在调用时读取技能指令；工具与文件权限沿用当前设置。');body.append(auto,directory,hint,status);
  const actions=a.node('div','et-skill-form-actions'),done=this.button('完成',()=>d.close());done.className='et-skill-management-done';actions.append(done);d.append(top,body,actions);d.showModal();close.focus();
 }
 snapshot(){return {selected:[...this.selected],excluded:[...this.excluded]};}
 restore(data){this.selected=Array.isArray(data?.selected)?data.selected.filter(x=>typeof x==='string'):[];this.excluded=Array.isArray(data?.excluded)?data.excluded.filter(x=>typeof x==='string'):[];this.sync();}
 request(text){return {...this.snapshot(),selected:[...new Set([...this.selected,...ETAISkills.mentions(text)])]};}
 clear(){this.selected=[];this.excluded=[];this.sync();}
 sync(){if(!this.chips)return;const names=[...new Set([...this.selected,...ETAISkills.mentions(this.ai.composerUI.draft.text())])];this.chips.replaceChildren();this.chips.hidden=!names.length;for(const name of names){const skill=this.items.find(x=>x.name===name),b=this.button('移除技能 '+name,()=>{this.selected=this.selected.filter(n=>n!==name);this.excluded.push(name);const strip=text=>text.replace(new RegExp('(^|\\s)\\$'+name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'(?=$|\\s|[，。！？,;:!?])','gu'),'$1');this.ai.prompt.value=strip(this.ai.prompt.value);this.ai.composerUI.draft.folded=strip(this.ai.composerUI.draft.folded);this.sync();this.ai.conversations.schedule();});b.className='et-ai-skill-chip';b.innerHTML=this.icon();b.append(this.ai.node('span','',skill?.displayName||name),this.ai.node('span','','×'));b.title='$'+name+(skill?.enabled?'':' · 未安装或已禁用');b.dataset.invalid=String(!skill?.enabled);b.disabled=!!this.ai.composerLocked();this.chips.append(b);}if(this.ai.contextUI?.kind==='slash')this.ai.contextUI.syncSlash();}
 async configure(profile,request){await this.init();profile.skillRequest=request||{};const state=this.store.state();profile.skillsEnabled=!!(request?.selected?.length||state.automatic&&state.items.some(x=>x.enabled));profile.skillScripts=profile.skillsEnabled&&!!profile.shellEnabled&&!this.ai.toolbar.readingMode?.protected;}
}
