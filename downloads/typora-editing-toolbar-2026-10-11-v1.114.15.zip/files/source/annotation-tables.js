import {Plugin,TextSelection,NodeSelection} from 'prosemirror-state';
import {DOMParser,DOMSerializer} from 'prosemirror-model';
import {closeHistory} from 'prosemirror-history';
import {ordinaryInputParagraph} from './annotation-after-input.js';
import {CellSelection,TableMap,TableView,columnResizing,addRowBefore,addRowAfter,addColumnBefore,addColumnAfter,deleteRow,deleteColumn,deleteTable,selectedRect,isInTable} from 'prosemirror-tables';

const height=v=>Number.isFinite(+v)&&+v>0?Math.round(Math.max(28,Math.min(2400,+v))):null;
export function noteTableNodes(nodes){
 const table=nodes.get('table');
 nodes=nodes.update('table',{...table,attrs:{...table.attrs,freezeHeader:{default:false}},parseDOM:[{tag:'table',getAttrs:e=>({freezeHeader:e.getAttribute('data-note-freeze-header')==='true'})}],toDOM:n=>['table',n.attrs.freezeHeader?{'data-note-freeze-header':'true'}:{},['tbody',0]]});
 const row=nodes.get('table_row');
 return nodes.update('table_row',{...row,attrs:{height:{default:null}},parseDOM:[{tag:'tr',getAttrs:e=>({height:height(parseFloat(e.style.height))})}],toDOM:n=>['tr',n.attrs.height?{style:'height:'+n.attrs.height+'px'}:{},0]});
}

// Simple tables stay Markdown. HTML is used only when Markdown cannot represent
// widths, row heights, individual-cell alignment, or multiple cell paragraphs.
export function serializeRichTable(state,node,schema){
 let rich=Boolean(node.attrs.freezeHeader);
 node.forEach((row,_,r)=>{if(row.attrs.height)rich=true;row.forEach((cell,__,c)=>{
  if(cell.attrs.colwidth||cell.attrs.colspan!==1||cell.attrs.rowspan!==1||cell.childCount!==1||cell.type.name!==(r===0?'table_header':'table_cell')||c>=node.firstChild.childCount||cell.attrs.align!==node.firstChild.child(c).attrs.align)rich=true;
  cell.descendants(n=>{if(n.type.name==='paragraph'&&(n.attrs.alignment||n.attrs.indent))rich=true;});
 });});
 if(!rich)return false;
 const dom=DOMSerializer.fromSchema(schema).serializeNode(node);dom.setAttribute('data-note-table','1');
 state.write(dom.outerHTML);state.closeBlock(node);return true;
}
export function installRichTables(md,parser,schema){
 md.block.ruler.before('html_block','note_rich_table',(state,start,end,silent)=>{
  const begin=state.bMarks[start]+state.tShift[start],line=state.src.slice(begin,state.eMarks[start]);
  if(!/^<table\b[^>]*data-note-table="1"/.test(line))return false;
  let last=start;while(last<end&&!state.src.slice(state.bMarks[last],state.eMarks[last]).includes('</table>'))last++;
  if(last===end)return false;if(silent)return true;
  const token=state.push('note_rich_table','table',0);token.content=state.src.slice(begin,state.eMarks[last]);state.line=last+1;return true;
 },{alt:['paragraph','reference','blockquote','list']});
 parser.tokenHandlers.note_rich_table=(state,token)=>{
  const template=document.createElement('template');template.innerHTML=token.content;
  template.content.querySelectorAll('script,style,iframe,object,embed,link,meta').forEach(e=>e.remove());
  for(const e of template.content.querySelectorAll('*')){
   for(const a of [...e.attributes])if(/^on/i.test(a.name))e.removeAttribute(a.name);
   if(e.tagName==='A'&&!/^(https?:\/\/|mailto:|#)/i.test(e.getAttribute('href')||''))e.removeAttribute('href');
   if(e.tagName==='IMG'&&!/^(assets\/|https?:\/\/|data:image\/(?:png|jpeg|gif|webp);base64,)/i.test(e.getAttribute('src')||''))e.remove();
  }
  const doc=DOMParser.fromSchema(schema).parse(template.content),table=doc.firstChild;
  if(table?.type===schema.nodes.table)state.push(table);
 };
}

export function selectedNoteCells(state){
 const s=state.selection,cells=[];
 if(s instanceof CellSelection)s.forEachCell((node,pos)=>cells.push({node,pos}));
 else for(let d=s.$from.depth;d>0;d--){const n=s.$from.node(d);if(['cell','header_cell'].includes(n.type.spec.tableRole)){cells.push({node:n,pos:s.$from.before(d)});break;}}
 return cells;
}
export function alignNoteCells(state,dispatch,value){
 const cells=selectedNoteCells(state);if(!cells.length)return false;
 let tr=closeHistory(state.tr);
 for(const {node,pos} of cells){tr.setNodeMarkup(pos,null,{...node.attrs,align:value});node.descendants((n,offset)=>{if(n.isTextblock)tr.setNodeMarkup(pos+1+offset,null,{...n.attrs,alignment:value});});}
 dispatch(tr.scrollIntoView());return true;
}
export const tableMenuItems=[['table-row-before','在行上插入'],['table-row-after','在行下插入'],['table-col-before','在列左插入'],['table-col-after','在列右插入'],['table-select-row','选中行'],['table-select-col','选中列'],['table-delete-row','删除行'],['table-delete-col','删除列'],['table-delete','删除表格']];
export const inNoteTable=state=>isInTable(state)||state.selection instanceof NodeSelection&&state.selection.node.type.spec.tableRole==='table';
export const isNoteTableFrozen=state=>Boolean(tableAtSelection(state)?.node.attrs.freezeHeader);
export function runNoteTableAction(view,id){
 if(!view.editable||!inNoteTable(view.state))return false;
 if(id==='table-freeze-header'){
  const {node,pos}=tableAtSelection(view.state),tr=closeHistory(view.state.tr).setNodeMarkup(pos,null,{...node.attrs,freezeHeader:!node.attrs.freezeHeader});
  view.dispatch(tr);view.dispatch(closeHistory(view.state.tr));view.focus();return true;
 }
 const commands={'table-row-before':addRowBefore,'table-row-after':addRowAfter,'table-col-before':addColumnBefore,'table-col-after':addColumnAfter,'table-delete-row':deleteRow,'table-delete-col':deleteColumn,'table-delete':deleteTable};
 if(id==='table-select-row'||id==='table-select-col'){
  const r=selectedRect(view.state),map=r.map,start=r.tableStart;
  const a=start+map.map[r.top*map.width+r.left],b=start+map.map[(r.bottom-1)*map.width+r.right-1];
  const selection=(id==='table-select-row'?CellSelection.rowSelection:CellSelection.colSelection)(view.state.doc.resolve(a),view.state.doc.resolve(b));
  view.dispatch(view.state.tr.setSelection(selection));view.focus();return true;
 }
 if(!commands[id])return false;
 if(id==='table-delete-row'||id==='table-delete-col'){const r=selectedRect(view.state);if(id==='table-delete-row'?r.top===0&&r.bottom===r.map.height:r.left===0&&r.right===r.map.width)id='table-delete';}
 view.dispatch(closeHistory(view.state.tr));const done=commands[id](view.state,tr=>view.dispatch(tr.scrollIntoView()));view.dispatch(closeHistory(view.state.tr));view.focus();return done;
}
function tableAtSelection(state){
 const s=state.selection;if(s instanceof NodeSelection&&s.node.type.spec.tableRole==='table')return{node:s.node,pos:s.from};
 for(let d=s.$from.depth;d>0;d--)if(s.$from.node(d).type.spec.tableRole==='table')return{node:s.$from.node(d),pos:s.$from.before(d)};
 return null;
}
export function emptyTableDelete(state,dispatch,view){
 if(!view?.editable||view.composing)return false;
 const table=tableAtSelection(state);if(!table)return false;
 let empty=true;table.node.descendants(n=>{if(n.isText&&n.text.length||n.isLeaf&&!['paragraph','table_cell','table_header'].includes(n.type.name))empty=false;});
 if(!empty)return false;
 const s=state.selection;if(!s.empty&&!(s instanceof CellSelection)&&!(s instanceof NodeSelection))return false;
 if(dispatch){const tr=closeHistory(state.tr).replaceWith(table.pos,table.pos+table.node.nodeSize,state.schema.nodes.paragraph.create());tr.setSelection(TextSelection.create(tr.doc,table.pos+1)).setStoredMarks([]);dispatch(tr.scrollIntoView());}return true;
}
function afterTable(view,pos,node){
 if(!view.editable)return;
 const end=pos+node.nodeSize,$end=view.state.doc.resolve(end),next=$end.nodeAfter;
 let tr=closeHistory(view.state.tr);
 if(!ordinaryInputParagraph(next))tr.insert(end,view.state.schema.nodes.paragraph.create());
 tr.setSelection(TextSelection.near(tr.doc.resolve(end+1),1)).setStoredMarks([]);view.dispatch(tr.scrollIntoView());view.focus();
}
// Row height previews and frozen-row transforms are view-only until a command
// commits them. A row node view keeps ProseMirror from reparsing those styles.
export class NoteTableRowView{
 constructor(node){this.dom=this.contentDOM=document.createElement('tr');this.update(node);}
 update(node){if(node.type.name!=='table_row')return false;this.node=node;this.dom.style.height=node.attrs.height?node.attrs.height+'px':'';return true;}
 ignoreMutation(record){return record.type==='attributes'&&record.target===this.dom;}
}
export class NoteTableView extends TableView{
 constructor(node,view,getPos){
  super(node,100);this.view=view;this.getPos=getPos;this.sizeColumns(node);
  this.dom.classList.add('note-table-wrapper');
  this.scroll=document.createElement('div');this.scroll.className='note-table-scroll';this.scroll.append(this.table);this.dom.prepend(this.scroll);
  this.after=document.createElement('div');this.after.className='note-table-after';this.after.contentEditable='false';this.after.setAttribute('role','button');this.after.setAttribute('aria-label','在表格下方输入');this.after.title='点击在表格下方继续输入';this.dom.append(this.after);
  this.after.addEventListener('mousedown',e=>{if(e.button!==0||!view.editable)return;e.preventDefault();e.stopPropagation();const pos=getPos();if(pos!=null)afterTable(view,pos,this.node);});
  this.headerFrame=0;this.headerRow=null;this.headerDead=false;
  this.scheduleHeader=()=>{if(!this.headerDead&&!this.headerFrame)this.headerFrame=requestAnimationFrame(()=>{this.headerFrame=0;this.positionHeader();});};
  window.addEventListener('scroll',this.scheduleHeader,true);window.addEventListener('resize',this.scheduleHeader);
  this.headerObserver=new ResizeObserver(this.scheduleHeader);this.headerObserver.observe(this.table);this.headerObserver.observe(this.dom);this.scheduleHeader();
 }
 sizeColumns(node){let width=0;node.firstChild?.forEach(cell=>{for(let i=0;i<cell.attrs.colspan;i++)width+=cell.attrs.colwidth?.[i]||100;});this.table.style.width=width+'px';}
 positionHeader(){
  const row=this.contentDOM.firstElementChild;
  if(this.headerRow&&this.headerRow!==row){this.headerRow.style.removeProperty('transform');this.headerRow.classList.remove('note-frozen-first-row');}
  this.headerRow=row;if(!row)return;
  const frozen=Boolean(this.node.attrs.freezeHeader);row.classList.toggle('note-frozen-first-row',frozen);
  if(!frozen){row.style.removeProperty('transform');return;}
  // The horizontal scroll container prevents native sticky from following the
  // editor viewport. Move the actual row, bounded by its own table, instead of
  // cloning it: selection, editing and horizontal scrolling use the same cells.
  const rect=this.table.getBoundingClientRect(),dock=document.querySelector('.note-editor-dock'),top=Math.max(0,dock?.getBoundingClientRect().bottom||0);
  const offset=Math.max(0,Math.min(top-rect.top,rect.height-row.getBoundingClientRect().height-1));
  row.style.transform=offset>0?'translateY('+offset+'px)':'';
 }
 update(node){if(!super.update(node))return false;this.sizeColumns(node);this.scheduleHeader();return true;}
 ignoreMutation(record){return record.type!=='selection'&&(this.after.contains(record.target)||record.target===this.dom||record.target===this.scroll||record.type==='attributes'&&record.target.tagName==='TR')||super.ignoreMutation(record);}
 stopEvent(e){return this.after.contains(e.target);}
 destroy(){this.headerDead=true;cancelAnimationFrame(this.headerFrame);this.headerObserver.disconnect();window.removeEventListener('scroll',this.scheduleHeader,true);window.removeEventListener('resize',this.scheduleHeader);}
}
export function tableArrowExit(state,dispatch,view){
 const t=tableAtSelection(state);if(!t||!state.selection.empty||!view?.endOfTextblock('down'))return false;
 const r=selectedRect(state);if(r.bottom!==r.map.height)return false;
 if(dispatch)afterTable(view,t.pos,t.node);return true;
}

export function noteTablePlugins(){
 const rows=new Plugin({view:view=>{
  let drag=null,hot=null,raf=0;
  const win=view.dom.ownerDocument.defaultView;
  const line=document.createElement('div');line.className='note-row-resize-line';line.hidden=true;line.setAttribute('aria-hidden','true');document.body.append(line);
  const paintLine=()=>{
   const target=drag||hot,row=target?.row;if(!view.editable||!row?.isConnected){line.hidden=true;return;}
   const r=row.getBoundingClientRect(),clip=row.closest('.note-table-scroll').getBoundingClientRect(),left=Math.max(0,r.left,clip.left),right=Math.min(win.innerWidth,r.right,clip.right),dock=document.querySelector('.note-editor-dock')?.getBoundingClientRect().bottom||0;
   line.hidden=right<=left||r.bottom<=Math.max(dock,clip.top)||r.bottom>Math.min(win.innerHeight,clip.bottom)+1;
   if(!line.hidden){line.style.left=left+'px';line.style.width=(right-left)+'px';line.style.top=(r.bottom-1.5)+'px';}
  };
  const locate=e=>{const cell=e.target.closest?.('td,th');if(!cell||!view.dom.contains(cell))return null;const row=cell.parentElement,rect=row.getBoundingClientRect();if(Math.abs(e.clientY-rect.bottom)>5||Math.abs(e.clientX-cell.getBoundingClientRect().right)<6)return null;const p=view.posAtDOM(row,0),$p=view.state.doc.resolve(p);for(let d=$p.depth;d>0;d--)if($p.node(d).type.spec.tableRole==='row')return{row,node:$p.node(d),pos:$p.before(d),height:rect.height};return null;};
  const clean=()=>{cancelAnimationFrame(raf);raf=0;view.dom.classList.remove('note-row-resizing','note-row-resize-ready');hot=null;line.hidden=true;};
  const finish=(event,cancel=false)=>{if(!drag)return;const old=drag;drag=null;clean();old.row.style.height=old.style;win.removeEventListener('mousemove',move);win.removeEventListener('mouseup',up);win.removeEventListener('blur',cancelDrag);win.removeEventListener('keydown',cancelKey,true);if(!cancel&&view.editable&&view.state.doc===old.doc&&Math.abs(old.y-old.startY)>1){view.dispatch(closeHistory(view.state.tr).setNodeMarkup(old.pos,null,{...old.node.attrs,height:height(old.height+old.y-old.startY)}));view.dispatch(closeHistory(view.state.tr));}view.focus();};
  const cancelDrag=()=>finish(null,true),cancelKey=e=>{if(e.key==='Escape'){e.preventDefault();cancelDrag();}},up=e=>{if(drag)drag.y=e.clientY;finish(e);};
  const move=e=>{if(!drag)return;if(e.buttons===0)return up(e);drag.y=e.clientY;if(!raf)raf=win.requestAnimationFrame(()=>{raf=0;if(drag){drag.row.style.height=height(drag.height+drag.y-drag.startY)+'px';paintLine();}});};
  const hover=e=>{if(drag)return;if(!view.editable)return clean();hot=locate(e);view.dom.classList.toggle('note-row-resize-ready',!!hot);paintLine();};
  const leave=()=>{if(!drag)clean();};
  const down=e=>{if(e.button!==0||!view.editable||!(hot=locate(e)))return;e.preventDefault();e.stopImmediatePropagation();drag={...hot,startY:e.clientY,y:e.clientY,style:hot.row.style.height,doc:view.state.doc};view.dom.classList.add('note-row-resizing');paintLine();win.addEventListener('mousemove',move);win.addEventListener('mouseup',up);win.addEventListener('blur',cancelDrag);win.addEventListener('keydown',cancelKey,true);};
  view.dom.addEventListener('mousemove',hover);view.dom.addEventListener('mouseleave',leave);view.dom.addEventListener('mousedown',down,true);win.addEventListener('scroll',paintLine,true);win.addEventListener('resize',paintLine);win.addEventListener('blur',leave);
  return{update(){if(drag&&(view.state.doc!==drag.doc||!view.editable))cancelDrag();if(!view.editable)clean();else paintLine();},destroy(){cancelDrag();clean();line.remove();view.dom.removeEventListener('mousemove',hover);view.dom.removeEventListener('mouseleave',leave);view.dom.removeEventListener('mousedown',down,true);win.removeEventListener('scroll',paintLine,true);win.removeEventListener('resize',paintLine);win.removeEventListener('blur',leave);}};
 }});
 const columns=columnResizing({View:null,cellMinWidth:48,defaultCellMinWidth:100});
 const down=columns.props.handleDOMEvents.mousedown;
 columns.props.handleDOMEvents.mousedown=(view,event)=>event.button===0?down(view,event):false;
 return[rows,columns];
}
