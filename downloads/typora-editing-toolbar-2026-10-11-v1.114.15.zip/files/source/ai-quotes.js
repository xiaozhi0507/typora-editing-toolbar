// Explicit selected-text references. Text stays data until the user sends a question.
class EditingToolbarAIQuotes {
  constructor(owner,changed) {this.owner=owner;this.changed=changed;this.items=[];}
  node(tag,cls,text) {const n=document.createElement(tag);if(cls)n.className=cls;if(text!=null)n.textContent=text;return n;}
  button(label,icon,action) {const b=this.node('button');b.type='button';b.title=label;b.setAttribute('aria-label',label);if(icon)b.innerHTML=icon;else b.textContent=label;b.onclick=action;return b;}
  static icon='<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M4 3h12a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1h-5l-4 3v-3H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1ZM6 7h8M6 10h5"/></svg>';
  static renderSent(owner,article,turn) {
    const quotes=turn.requestContext?.quotes;if(!Array.isArray(quotes))return;
    const items=quotes.filter(q=>q&&typeof q.text==='string'&&q.text.trim());if(!items.length)return;
    const node=(...args)=>owner.node(...args),group=node('div','et-ai-sent-quotes');group.setAttribute('aria-label','已发送的引用文字');
    for(const [i,q]of items.entries()){
      const card=node('details','et-ai-sent-quote'),summary=node('summary'),head=node('span','et-ai-sent-quote-head'),icon=node('span','et-ai-sent-quote-icon');icon.innerHTML=this.icon;
      const source=node('span','et-ai-sent-quote-source',q.source||'所选文本');source.title=q.source||'所选文本';
      const action=node('span','et-ai-sent-quote-action');action.append(node('span','et-ai-quote-expand','展开'),node('span','et-ai-quote-collapse','收起'));action.insertAdjacentHTML('beforeend','<svg viewBox="0 0 16 16" aria-hidden="true"><path d="m5 6 3 3 3-3"/></svg>');
      head.append(icon,node('span','et-ai-sent-quote-label','引用 '+(i+1)),source,action);
      const excerpt=q.text.replace(/\s+/g,' ').trim(),preview=node('span','et-ai-sent-quote-excerpt',excerpt.length>180?excerpt.slice(0,180)+'…':excerpt),text=node('div','et-ai-sent-quote-content',q.text);
      text.tabIndex=0;text.setAttribute('aria-label','引用 '+(i+1)+' 全文');summary.append(head,preview);card.append(summary,text);group.append(card);
    }
    article.append(group);
  }
  mount(before) {
    this.tray=this.node('div','et-ai-quote-tray');this.tray.hidden=true;
    this.trigger=this.button('查看引用文字',EditingToolbarAIQuotes.icon,()=>this.toggle());this.trigger.className='et-ai-quote-trigger';this.trigger.setAttribute('aria-expanded','false');this.trigger.setAttribute('aria-haspopup','dialog');this.count=this.node('span');this.trigger.append(this.count);
    this.remove=this.button('移除全部引用','',()=>{if((this.owner.composerLocked?.()??this.owner.busy))return;this.clear();this.changed();});this.remove.textContent='×';this.remove.className='et-ai-quote-clear';this.tray.append(this.trigger,this.remove);before.before(this.tray);
    this.popup=this.node('div','et-ai-quote-popup');this.popup.setAttribute('popover','manual');this.popup.setAttribute('role','dialog');this.popup.setAttribute('aria-label','引用文字');document.body.append(this.popup);
    this.events=new AbortController();const options={signal:this.events.signal};
    document.addEventListener('pointerdown',e=>{if(!this.popup.contains(e.target)&&!this.tray.contains(e.target))this.close();},{...options,capture:true});
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&this.popup.matches(':popover-open')){e.preventDefault();e.stopPropagation();this.close();this.trigger.focus();}},{...options,capture:true});
    window.addEventListener('resize',()=>this.close(),options);window.addEventListener('blur',()=>this.close(),options);
    this.popup.addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Escape'){e.preventDefault();this.close();this.trigger.focus();}},options);
    for(const type of ['mousedown','mouseup','keydown','input','paste','copy','cut'])this.popup.addEventListener(type,e=>e.stopPropagation(),options);
    this.sync();
  }
  snapshot() {return this.items.map(q=>({...q}));}
  restore(items) {this.close();this.items=Array.isArray(items)?items.filter(q=>typeof q.text==='string'&&q.text.trim()).map(q=>({id:q.id||crypto.randomUUID(),text:q.text,source:String(q.source||'所选文本'),file:String(q.file||'')})):[];this.sync();}
  add(item) {
    if((this.owner.composerLocked?.()??this.owner.busy))throw Error('请等待当前回答完成后再添加引用');
    if(this.items.some(q=>q.text===item.text&&q.file===item.file)){this.trigger.focus();return;}
    if(this.items.length>=20||this.items.reduce((n,q)=>n+q.text.length,0)+item.text.length>100000)throw Error('引用过多，请减少到 20 段、10 万字符以内');
    this.close();this.items.push({id:crypto.randomUUID(),text:item.text,source:item.source||'所选文本',file:item.file||''});this.sync();this.changed();
  }
  reference() {return this.items.map((q,i)=>'所选文本 '+(i+1)+' · '+q.source+'\n'+q.text).join('\n\n');}
  clear() {this.items=[];this.close();this.sync();}
  sync() {if(!this.tray)return;this.tray.hidden=!this.items.length;this.count.textContent=this.items.length+' 条引用';this.remove.disabled=!!(this.owner.composerLocked?.()??this.owner.busy);if((this.owner.composerLocked?.()??this.owner.busy))this.close();}
  toggle() {if(this.popup.matches(':popover-open'))this.close();else{this.render();this.popup.showPopover();this.trigger.setAttribute('aria-expanded','true');this.position();}}
  position() {if(!this.popup.matches(':popover-open'))return;const r=this.trigger.getBoundingClientRect(),p=this.popup;p.style.width=Math.min(380,innerWidth-20)+'px';const room=Math.max(r.top-20,innerHeight-r.bottom-20);p.style.maxHeight=Math.min(400,room)+'px';const h=p.getBoundingClientRect().height,w=p.getBoundingClientRect().width;p.style.left=Math.max(10,Math.min(r.left,innerWidth-w-10))+'px';p.style.top=Math.max(10,r.top>=h+10?r.top-h-8:Math.min(r.bottom+8,innerHeight-h-10))+'px';}
  render(editId=null) {
    this.popup.replaceChildren();
    this.items.forEach((q,i)=>{
      const row=this.node('section','et-ai-quote-row'),head=this.node('div','et-ai-quote-head'),text=this.node('div','et-ai-quote-text',q.text);
      head.append(this.node('span','',String(i+1)+'.'),this.node('strong','','所选文本'),this.node('small','',q.source));
      const edit=this.button('编辑引用 '+(i+1),'<svg viewBox="0 0 20 20"><path d="m3 13 10-10 4 4L7 17H3zM11 5l4 4"/></svg>',()=>{if(!(this.owner.composerLocked?.()??this.owner.busy)){this.render(q.id);this.position();this.popup.querySelector('textarea').focus();}});
      const remove=this.button('删除引用 '+(i+1),'<svg viewBox="0 0 20 20"><path d="M3 5h14M7 5V2h6v3M5 5l1 13h8l1-13M8 8v7M12 8v7"/></svg>',()=>{if((this.owner.composerLocked?.()??this.owner.busy))return;this.items=this.items.filter(x=>x.id!==q.id);this.sync();this.changed();if(this.items.length){this.render();this.position();}else this.close();});edit.disabled=remove.disabled=!!(this.owner.composerLocked?.()??this.owner.busy);head.append(edit,remove);row.append(head);
      if(q.id===editId){const input=this.node('textarea','et-ai-quote-editor');input.value=q.text;input.setAttribute('aria-label','编辑所选文本');const actions=this.node('div','et-ai-quote-edit-actions');actions.append(this.button('取消',null,()=>{this.render();this.position();}),this.button('保存',null,()=>{if(!input.value.trim())return input.focus();if(this.items.reduce((n,x)=>n+(x===q?0:x.text.length),0)+input.value.length>100000){input.setCustomValidity('引用总长度不能超过 10 万字符');return input.reportValidity();}q.text=input.value;this.changed();this.render();this.position();}));input.oninput=()=>input.setCustomValidity('');row.append(input,actions);}else row.append(text);
      this.popup.append(row);
    });
  }
  close() {if(this.popup?.matches(':popover-open'))this.popup.hidePopover();this.trigger?.setAttribute('aria-expanded','false');}
}
