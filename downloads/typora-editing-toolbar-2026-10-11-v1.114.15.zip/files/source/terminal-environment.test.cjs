const test=require('node:test'),assert=require('node:assert/strict'),path=require('node:path').win32;
const {projectDirectory,pythonEnvironment,environmentVariables}=require('./terminal-environment.cjs');
const root='C:\\工作 空间';
function mock(files=[],env={}){return name=>({path,process:{env},fs:{promises:{stat:async p=>{const found=files.find(f=>(typeof f==='string'?f:f.dir).toLowerCase()===p.toLowerCase());if(!found)throw Error('missing');return {isFile:()=>typeof found==='string',isDirectory:()=>typeof found!=='string'};}}}}[name]||(()=>{throw Error('Unexpected dependency '+name);})());}
test('terminal defaults to nearest containing trusted project, then selected project, then file directory',()=>{
 const outer={root,trusted:true},inner={root:root+'\\sub',trusted:true},selected={root:'D:\\Selected',trusted:true};
 assert.equal(projectDirectory(mock(),{items:[outer,inner],active:()=>selected},root+'\\sub\\notes\\article.md'),inner.root);
 assert.equal(projectDirectory(mock(),{items:[outer],active:()=>selected},root+'2\\article.md'),selected.root);
 assert.equal(projectDirectory(mock(),null,'D:\\Else\\article.md'),'D:\\Else');assert.equal(projectDirectory(mock(),null,''),null);
 assert.throws(()=>projectDirectory(mock(),{items:[{...inner,trusted:false}],active:()=>outer},inner.root+'\\a.md'),/信任/);
});
test('local venv wins over inherited Python without running activation scripts',async()=>{
 const exe=root+'\\.venv\\Scripts\\python.exe',req=mock([exe,root+'\\.venv\\pyvenv.cfg','D:\\Python\\python.exe'],{Path:'D:\\Python'});
 const p=await pythonEnvironment(req,root);assert.equal(p.exe,exe);assert.equal(p.kind,'venv');assert.deepEqual(p.paths,[root+'\\.venv\\Scripts']);
});
test('system lookup skips Windows Store aliases and tolerates absent Python',async()=>{
 const alias='C:\\Users\\a\\AppData\\Local\\Microsoft\\WindowsApps';
 assert.equal((await pythonEnvironment(mock([alias+'\\python.exe','D:\\Python\\python.exe'],{PATH:alias+';D:\\Python'}),root)).exe,'D:\\Python\\python.exe');
 assert.equal(await pythonEnvironment(mock([],{}),root),null);
});
test('explicit interpreter validates before spawning; missing override cannot silently switch Python',async()=>{
 const exe='D:\\Env\\Scripts\\python.exe';assert.equal((await pythonEnvironment(mock([exe]),root,exe)).exe,exe);
 await assert.rejects(pythonEnvironment(mock([]),root,exe),/有效/);await assert.rejects(pythonEnvironment(mock(['D:\\cmd.exe']),root,'D:\\cmd.exe'),/有效/);
 await assert.rejects(pythonEnvironment(mock(['D:\\python3.exe']),root,'D:\\python3.exe'),/python\.exe/);
});
test('environment patch isolates PATH and venv variables without mutating parent',()=>{
 const base={PATH:'C:\\Windows',Path:'D:\\Old',PYTHONHOME:'D:\\Bad',VIRTUAL_ENV:'D:\\Old',KEEP:'yes'},copy={...base};
 const env=environmentVariables(base,{kind:'venv',root,paths:[root+'\\.venv\\Scripts']});
 assert.deepEqual(base,copy);assert.equal(Object.keys(env).filter(k=>k.toLowerCase()==='path').length,1);assert.equal(env.VIRTUAL_ENV,root);assert(!('PYTHONHOME' in env));assert.equal(env.KEEP,'yes');assert(env.Path.startsWith(root+'\\.venv\\Scripts;'));
});
test('Conda environment includes native dependency paths without executing activate.d',async()=>{
 const exe=root+'\\.conda\\python.exe',p=await pythonEnvironment(mock([exe,{dir:root+'\\.conda\\conda-meta'}]),root);
 assert.equal(p.kind,'conda');assert(p.paths.includes(root+'\\.conda\\Library\\bin'));assert.equal(environmentVariables({},p).CONDA_PREFIX,p.root);
});
