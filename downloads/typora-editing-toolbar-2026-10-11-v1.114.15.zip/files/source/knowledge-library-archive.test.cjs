'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os');
const Store=require('./knowledge-library-store.cjs'),Managed=require('./knowledge-library-managed.cjs'),Archive=require('./knowledge-library-archive.cjs'),Zip=require('fflate');
async function fixture(t){
  const root=await fs.mkdtemp(path.join(os.tmpdir(),'kb-archive-'));t.after(()=>fs.rm(root,{recursive:true,force:true}));
  const store=new Store(path.join(root,'source')),target=new Store(path.join(root,'target'));const base=(await store.open()).data;await target.open();
  const folder=path.join(store.root,'文献'),md=path.join(folder,'论文.md'),notes=md+'.资料/笔记';
  await fs.mkdir(path.join(folder,'images'),{recursive:true});await fs.mkdir(notes+'/assets',{recursive:true});
  await fs.writeFile(md,'# 正文\n\n![图](images/plot.png)\n\n[第二章](第二章.md)');await fs.writeFile(path.join(folder,'第二章.md'),'# 第二章');
  await fs.writeFile(path.join(folder,'images/plot.png'),Buffer.from([1,2,3,4]));await fs.writeFile(notes+'/assets/note.png',Buffer.from([5,6,7]));
  await fs.writeFile(notes+'/index.json',JSON.stringify({version:1,documentId:'doc-test',notes:[{id:'note-one',title:'阅读笔记',markdown:'![笔记图片](assets/note.png)',anchor:{exact:''}}]}));
  await fs.writeFile(notes+'/笔记.md','# 阅读笔记\n![图](assets/note.png)');
  const f=store.fileRef(md),chapter=store.fileRef(path.join(folder,'第二章.md'));
  const item={id:'paper',type:'paper',title:'测试文献',status:'unread',files:[f,chapter],defaultFile:f.id,lastFile:chapter.id,tags:['科研'],collections:['child'],related:['book'],relatedOut:['book'],xrefMetadata:{version:1,fileId:f.id,applied:{authorAffiliations:{fileId:f.id}}},authorAffiliations:{fileId:f.id}};
  const book={id:'book',type:'book',title:'书籍',status:'done',files:[{...chapter,bookPath:'第二章.md'}],defaultFile:chapter.id,tags:[],collections:['parent'],related:['paper'],book:{version:1,entryFile:chapter.id,sourceRoot:folder,storageKey:'OLD'}};
  await store.commit(base,{...base,items:[item,book],collections:[{id:'parent',name:'书架',parentId:null},{id:'child',name:'文献',parentId:'parent'}]});
  const make=(s,limits)=>new Archive(s,{Managed,Zip,limits});return {root,store,target,make,folder,md,notes};
}
test('archive roundtrip preserves chapters, relative resources, note indexes, relationships and existing library',async t=>{
  const x=await fixture(t),prior=(await x.target.read()).data;
  await x.target.commit(prior,{...prior,items:[{id:'paper',type:'note',title:'现有条目',status:'unread',files:[],tags:[],collections:[],related:[]}]});
  const out=await x.make(x.store).export(x.root),result=await x.make(x.target).import(out.path);
  assert.equal(result.added,2);assert.equal(result.data.items.length,3);assert.equal(result.data.items.find(i=>i.id==='paper').title,'现有条目');
  const paper=result.data.items.find(i=>i.title==='测试文献'),book=result.data.items.find(i=>i.title==='书籍');
  assert.deepEqual(paper.related,[book.id]);assert.deepEqual(paper.relatedOut,[book.id]);assert.equal(book.book.entryFile,book.files[0].id);assert.equal(paper.defaultFile,paper.files[0].id);assert.equal(paper.lastFile,paper.files[1].id);
  assert.equal(paper.xrefMetadata.fileId,paper.defaultFile);assert.equal(paper.authorAffiliations.fileId,paper.defaultFile);assert.equal(paper.xrefMetadata.applied.authorAffiliations.fileId,paper.defaultFile);
  const doc=x.target.resolveFile(paper.files[0]),folder=path.dirname(doc);
  assert.equal(await fs.readFile(doc,'utf8'),await fs.readFile(x.md,'utf8'));
  assert.deepEqual(await fs.readFile(folder+'/images/plot.png'),Buffer.from([1,2,3,4]));
  assert.equal(JSON.parse(await fs.readFile(doc+'.资料/笔记/index.json','utf8')).notes[0].title,'阅读笔记');
  assert.deepEqual(await fs.readFile(doc+'.资料/笔记/assets/note.png'),Buffer.from([5,6,7]));
  assert.equal(await fs.readFile(x.target.resolveFile(book.files[0]),'utf8'),'# 第二章');
  const child=result.data.collections.find(c=>c.name==='文献'),parent=result.data.collections.find(c=>c.name==='书架');assert.equal(child.parentId,parent.id);assert.deepEqual(paper.collections,[child.id]);
  const before=await fs.readdir(x.target.root+'/storage'),again=await x.make(x.target).import(out.path);assert.equal(again.added,0);assert.equal(again.reused,2);assert.equal(again.data.revision,result.data.revision);assert.deepEqual(await fs.readdir(x.target.root+'/storage'),before);
  const reopen=await new Store(x.target.root).read();assert.equal(reopen.data.items.length,3);
});
test('export leaves linked sources intact and includes external attachments',async t=>{
  const x=await fixture(t),external=path.join(x.root,'外部.pdf');await fs.writeFile(external,'pdf-fixture');const base=(await x.store.read()).data,next=structuredClone(base);next.items[0].files.push(x.store.fileRef(external));await x.store.commit(base,next);
  const out=await x.make(x.store).export(x.root),result=await x.make(x.target).import(out.path),ref=result.data.items.find(i=>i.title==='测试文献').files[2];
  assert.equal(await fs.readFile(x.target.resolveFile(ref),'utf8'),'pdf-fixture');assert.equal(await fs.readFile(external,'utf8'),'pdf-fixture');
});
test('missing resources and changed metadata leave no completed export',async t=>{
  const x=await fixture(t);await fs.unlink(x.folder+'/images/plot.png');await assert.rejects(x.make(x.store).export(x.root),/ENOENT/);assert.ok(!(await fs.readdir(x.root)).some(f=>/\.zip/.test(f)));
});
test('corrupt payload, absent resources and truncated archives do not modify the target library',async t=>{
  const x=await fixture(t),out=await x.make(x.store).export(x.root),original=await fs.readFile(out.path),before=await fs.readFile(x.target.file,'utf8');
  for(const kind of ['corrupt','missing','truncated']){
    let bytes;if(kind==='truncated')bytes=original.subarray(0,original.length-10);else{const entries=Zip.unzipSync(original),name=Object.keys(entries).find(n=>n.endsWith('plot.png'));if(kind==='corrupt')entries[name]=new TextEncoder().encode('broken');else delete entries[name];bytes=Zip.zipSync(entries);}
    const bad=x.root+'/'+kind+'.zip';await fs.writeFile(bad,bytes);await assert.rejects(x.make(x.target).import(bad),/校验|损坏|完整/);
    assert.equal(await fs.readFile(x.target.file,'utf8'),before);assert.deepEqual(await fs.readdir(x.target.root+'/storage'),[]);
  }
});
test('path traversal, alternate data streams, reserved names, case collisions and unlisted files are rejected',async t=>{
  const x=await fixture(t),out=await x.make(x.store).export(x.root),original=await fs.readFile(out.path);
  for(const name of ['../outside.txt','data/../../outside.txt','data/a:stream','data/CON.txt','data/x.','data/unlisted.txt','LIBRARY.json']){
    const entries=Zip.unzipSync(original);entries[name]=new Uint8Array([1]);const bad=x.root+'/unsafe.zip';await fs.writeFile(bad,Zip.zipSync(entries));
    await assert.rejects(x.make(x.target).import(bad));assert.equal((await x.target.read()).data.items.length,0);assert.deepEqual(await fs.readdir(x.target.root+'/storage'),[]);
  }
});
test('cancellation and byte limits roll back staging and partial ZIP output',async t=>{
  const x=await fixture(t),out=await x.make(x.store).export(x.root),ctrl=new AbortController();
  await assert.rejects(x.make(x.target).import(out.path,{signal:ctrl.signal,onProgress:()=>ctrl.abort()}),{name:'AbortError'});assert.deepEqual(await fs.readdir(x.target.root+'/storage'),[]);
  await assert.rejects(x.make(x.target,{bytes:128}).import(out.path),/过大|限制/);
  const cancel=new AbortController();await assert.rejects(x.make(x.store).export(x.root,{signal:cancel.signal,onProgress:(text,phase)=>{if(phase==='copying')cancel.abort();}}),{name:'AbortError'});
  assert.ok(!(await fs.readdir(x.root)).some(f=>f.endsWith('.partial')));assert.equal((await x.target.read()).data.items.length,0);
});
test('concurrent library updates abort import without overwriting the concurrent revision',async t=>{
  const x=await fixture(t),out=await x.make(x.store).export(x.root),original=x.target.commit.bind(x.target);
  x.target.commit=async(base,next,validate)=>{await original(base,{...base,collections:[{id:'other',name:'其他窗口',parentId:null}]});return original(base,next,validate);};
  await assert.rejects(x.make(x.target).import(out.path),/已更新/);assert.equal((await x.target.read()).data.collections[0].name,'其他窗口');assert.deepEqual(await fs.readdir(x.target.root+'/storage'),[]);
});
test('empty libraries also roundtrip without leaving an unused storage bundle',async t=>{
  const x=await fixture(t),out=await x.make(x.target).export(x.root),again=await x.make(x.target).import(out.path);assert.equal(again.added,0);assert.deepEqual(await fs.readdir(x.target.root+'/storage'),[]);
});
test('plain text attachments include their note sidecars and URL references stay links',async t=>{
  const x=await fixture(t),txt=x.folder+'/说明.txt';await fs.writeFile(txt,'plain text');await fs.mkdir(txt+'.笔记');await fs.writeFile(txt+'.笔记/index.json','{"version":1,"notes":[]}');
  const base=(await x.store.read()).data,next=structuredClone(base);next.items[0].files.push(x.store.fileRef(txt),x.store.urlRef('https://example.com/paper','网页'));await x.store.commit(base,next);
  const out=await x.make(x.store).export(x.root),result=await x.make(x.target).import(out.path),paper=result.data.items.find(i=>i.title==='测试文献');
  const ref=paper.files.find(f=>f.name==='说明.txt');assert.equal(await fs.readFile(x.target.resolveFile(ref)+'.笔记/index.json','utf8'),'{"version":1,"notes":[]}');assert.equal(paper.files.at(-1).linkType,'url');assert.equal(paper.files.at(-1).path,'https://example.com/paper');
});
test('export detects files changing during transfer and discards the partial output',async t=>{
  const x=await fixture(t);let changed=false;
  await assert.rejects(x.make(x.store).export(x.root,{onProgress:(text,phase)=>{if(phase==='copying'&&!changed){changed=true;require('node:fs').appendFileSync(x.md,'\nchanged during export');}}}),/已修改/);
  assert.ok(!(await fs.readdir(x.root)).some(f=>f.endsWith('.zip')||f.endsWith('.partial')));
});
test('failed metadata commit removes only the new staging bundle',async t=>{
  const x=await fixture(t),out=await x.make(x.store).export(x.root);await fs.mkdir(x.target.root+'/storage/KEEP',{recursive:true});await fs.writeFile(x.target.root+'/storage/KEEP/sentinel','keep');
  x.target.commit=async()=>{throw Error('disk write failed');};await assert.rejects(x.make(x.target).import(out.path),/disk write failed/);
  assert.deepEqual(await fs.readdir(x.target.root+'/storage'),['KEEP']);assert.equal(await fs.readFile(x.target.root+'/storage/KEEP/sentinel','utf8'),'keep');
});
