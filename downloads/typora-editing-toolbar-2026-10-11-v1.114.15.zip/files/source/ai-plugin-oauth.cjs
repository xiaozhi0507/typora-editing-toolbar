'use strict';

// Keep the callback short-lived; exchange and identity checks share its deadline.
module.exports=async function authorize(req,open,{authorizeURL,params,signal,timeout=180000,onProgress},exchange){
 const progress=stage=>{try{onProgress?.(stage);}catch{}};
 const crypto=req('crypto'),controller=new AbortController(),random=()=>crypto.randomBytes(32).toString('base64url');
 const state=random(),verifier=random(),challenge=crypto.createHash('sha256').update(verifier).digest('base64url');
 const server=req('http').createServer();server.requestTimeout=10000;server.headersTimeout=10000;
 let redirect,consumed=false,settled=false,resolveCode,rejectCode;
 const codeResult=new Promise((resolve,reject)=>{resolveCode=resolve;rejectCode=reject;});
 const settle=(error,code)=>{if(settled)return;settled=true;server.close();error?rejectCode(error):resolveCode(code);};
 const abort=()=>controller.abort(Object.assign(Error('已取消登录'),{name:'AbortError'}));
 const onAbort=()=>settle(controller.signal.reason);
 controller.signal.addEventListener('abort',onAbort,{once:true});
 signal?.addEventListener('abort',abort,{once:true});
 const timer=setTimeout(()=>controller.abort(Error('登录超时，请重试')),timeout);
 server.on('error',()=>settle(Error('无法启动本机授权回调')));
 server.on('request',(request,response)=>{
  const reply=(status,msg)=>{response.writeHead(status,{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store','Content-Security-Policy':"default-src 'none'",Connection:'close'});response.end(msg);};
  let u;try{u=new URL(request.url,redirect);}catch{return reply(400,'无效请求');}
  if(consumed||request.method!=='GET'||u.pathname!=='/oauth/callback'||request.headers.host!==new URL(redirect).host)return reply(404,'未找到');
  if(u.searchParams.getAll('state').length!==1||u.searchParams.get('state')!==state)return reply(400,'授权状态不匹配');
  if(u.searchParams.has('error')){consumed=true;reply(200,'授权已取消，可以返回 Typora。');return settle(Error('授权已取消，请重试'));}
  const codes=u.searchParams.getAll('code');if(codes.length!==1||!codes[0]||codes[0].length>4096)return reply(400,'授权代码无效');
  consumed=true;progress('exchanging');reply(200,'授权已收到，Typora 正在换取令牌并验证账户。请返回 Typora 查看最终连接结果；此页面不代表账户已连接。');settle(null,codes[0]);
 });
 try{
  if(signal?.aborted)abort();
  else server.listen(0,'127.0.0.1',()=>{
   if(controller.signal.aborted){server.close();return;}
   redirect='http://127.0.0.1:'+server.address().port+'/oauth/callback';
   const u=new URL(authorizeURL);u.search=new URLSearchParams({...params,redirect_uri:redirect,response_type:'code',state,code_challenge:challenge,code_challenge_method:'S256'}).toString();
   Promise.resolve().then(()=>open(u.href)).then(()=>{if(!settled)progress('waiting');}).catch(()=>settle(Error('无法打开系统浏览器')));
  });
  const code=await codeResult;controller.signal.throwIfAborted();
  const value=await exchange({code,code_verifier:verifier,redirect_uri:redirect,signal:controller.signal,progress});
  controller.signal.throwIfAborted();return value;
 }finally{
  clearTimeout(timer);signal?.removeEventListener('abort',abort);controller.signal.removeEventListener('abort',onAbort);
  server.close();if(controller.signal.aborted)server.closeAllConnections?.();else server.closeIdleConnections?.();
 }
};
