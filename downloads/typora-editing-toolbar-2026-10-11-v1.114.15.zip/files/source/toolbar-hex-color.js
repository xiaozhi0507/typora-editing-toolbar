class ToolbarHexColor {
    _appendHexColorInput(picker,kind) {
        const row=document.createElement('div');row.className='et-hex-row';
        const input=document.createElement('input');input.type='text';input.maxLength=7;input.placeholder='#RRGGBB';input.spellcheck=false;input.autocomplete='off';input.setAttribute('aria-label',kind==='font-color'?'字体颜色十六进制码':'背景颜色十六进制码');
        const apply=document.createElement('button');apply.type='button';apply.className='et-hex-apply';apply.textContent='应用';
        const error=document.createElement('div');error.className='et-hex-error';error.setAttribute('role','status');
        let snapshot=null,docKey=null;
        picker._resetColorSelection=()=>{snapshot=null;docKey=null;error.textContent='';input.removeAttribute('aria-invalid');const history=picker.querySelector('.et-color-history');if(history)this._renderColorHistory(history,kind);};
        const capture=()=>{this._saveSelection();docKey=this.annotations?._key();snapshot={savedRange:this.savedRange?.cloneRange()||null,savedRangy:this.savedRangy,savedCursor:this.savedCursor,lastSelectionText:this.lastSelectionText};};
        input.addEventListener('mousedown',e=>{if(document.activeElement!==input)capture();e.stopPropagation();});
        input.addEventListener('focus',capture);
        const message=(text,bad=false)=>{error.textContent=text;error.classList.toggle('et-hex-hint',!bad);};
        const commit=()=>{let value=input.value.trim();if(!value.startsWith('#'))value='#'+value;if(!/^#[0-9a-f]{6}$/i.test(value)){message('请输入六位十六进制颜色，例如 #295BBA。',true);input.setAttribute('aria-invalid','true');return;}if(snapshot&&docKey!==this.annotations?._key()){message('文档已切换，请重新选择文字后设置颜色。',true);return;}error.textContent='';input.removeAttribute('aria-invalid');if(snapshot)Object.assign(this,snapshot);if(kind==='font-color')this._applyFontColor(value.toUpperCase());else this._applyBgColor(value.toUpperCase());this._closeActivePopover();snapshot=null;};
        apply.addEventListener('mousedown',e=>{e.preventDefault();e.stopPropagation();});apply.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();commit();});
        input.addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Enter'){e.preventDefault();commit();}});for(const name of ['keyup','keypress','input','paste','copy','cut'])input.addEventListener(name,e=>e.stopPropagation());
        row.append(input,apply);picker.append(row,error);
        picker._paletteTools=attachPalettePicker({screenPicker:false,host:picker,row,input,apply,capture,valid:()=>docKey===this.annotations?._key(),eyeDropper:()=>window.EyeDropper||this.annotations?.frame?.contentWindow?.EyeDropper,message});
    }
}
