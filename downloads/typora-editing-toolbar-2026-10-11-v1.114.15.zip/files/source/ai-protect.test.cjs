'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),Client=require('./ai-client.cjs');
test('Windows DPAPI round-trips a 330-file checkpoint and a large resumption record without stdout truncation',{skip:process.platform!=='win32'},async()=>{
 const client=new Client(require);
 for(const count of [330,20000]){
  const records=Object.fromEntries(Array.from({length:count},(_,i)=>['folder:'+String(i).padStart(64,'a'),{id:'file-'+i,sha256:String(i).padStart(64,'b'),url:'https://www.googleapis.com/upload/drive/v3/resume/example-'+i}])),plain=JSON.stringify(records);
  const encrypted=await client.protect(plain);assert.ok(encrypted.length>32768);assert.ok(!encrypted.includes('googleapis.com'));assert.equal(await client.protect(encrypted,true),plain);
 }
 const small='previous credential format';assert.equal(await client.protect(await client.protect(small),true),small);
});
test('DPAPI failures expose a generic local-storage error without API-key advice or payload data',async()=>{
 const secret='test-secret-not-for-output';let stdin,argv,options;
 const client=new Client(name=>name==='child_process'?{execFile:(command,args,opts,done)=>{argv=args;options=opts;return{stdin:{on(){},end(value){stdin=value;queueMicrotask(()=>done(Error(secret)));}}};}}:require(name));
 await assert.rejects(client.protect(secret),e=>e.code==='LOCAL_PROTECTION_FAILED'&&!/API Key|记住密钥|test-secret/.test(e.message));
 assert.equal(Buffer.from(stdin,'base64').toString(),secret);assert.ok(!argv.join(' ').includes(secret));assert.equal(options.windowsHide,true);
});
test('oversized protection input is rejected before starting a helper process',async()=>{
 let spawned=false;const client=new Client(name=>name==='child_process'?(spawned=true,{}):require(name));
 await assert.rejects(client.protect('x'.repeat(16*1024**2+1)),{code:'LOCAL_PROTECTION_LIMIT'});assert.equal(spawned,false);
});
