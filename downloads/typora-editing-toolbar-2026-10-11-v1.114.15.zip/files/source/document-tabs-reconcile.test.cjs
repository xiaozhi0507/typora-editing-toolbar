'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path').win32,{JSDOM}=require('jsdom');
const settle=()=>new Promise(resolve=>setTimeout(resolve,15));
async function fixture(t){
 const dom=new JSDOM('<main><div class="scroll"><div class="list"></div><div class="empty"></div></div></main>',{url:'https://fixture.invalid'});t.after(()=>dom.window.close());
 const {document,localStorage}=dom.window,files={a:'C:\\project\\a.md',b:'C:\\project\\b.md',c:'C:\\project\\c.md'},status={dirty:false,visible:'',codeDirty:new Set()},reads=[];
 const File={bundle:{filePath:files.a},isDocumentEdited:()=>status.dirty,isFileLoading:()=>false},scope={document,window:dom.window,localStorage,File,CSS:{escape:s=>s},setTimeout,clearTimeout};
 dom.window.HTMLElement.prototype.scrollIntoView=function(){};
 const T=vm.runInNewContext(fs.readFileSync(__dirname+'/document-tabs.js','utf8')+';EditingToolbarDocumentTabs',scope),P=vm.runInNewContext(fs.readFileSync(__dirname+'/document-projects.js','utf8')+';EditingToolbarProjects',scope);
 const tabs=Object.assign(Object.create(T.prototype),{path,storageKey:'tabs',toolbar:{codeEditor:{visibleKey:()=>status.visible,hasDirty:f=>status.codeDirty.has(f),supported:()=>false}},panel:document.querySelector('main'),list:document.querySelector('.list'),scroll:document.querySelector('.scroll'),empty:document.querySelector('.empty'),rows:new Map(),fileSelection:new Map(),mtimes:new Map(),tabs:[{path:files.a},{path:files.b}],current:'',file:files.a});
 localStorage.setItem('tabs',JSON.stringify({pinned:[{path:files.a}],favorites:[{path:files.b}]}));tabs.preferences=tabs.readPreferences();tabs.favoritesData=tabs.preferences.favorites;tabs.current=tabs.key(files.a);
 const p=Object.assign(Object.create(P.prototype),{tabs,key:'projects',host:tabs.list,core:{}});tabs.projects=p;
 localStorage.setItem('projects',JSON.stringify({items:[{id:'p',root:'C:\\project',name:'Project',trusted:true,pinned:false,collapsed:false,expandedFolders:['src']}]}));p.read();
 let entries=[{relative:'src',directory:true},...Object.values(files).map(f=>({relative:path.basename(f),directory:false}))];
 p.core.list=async(_p,relative)=>{reads.push(relative);return (relative?[{relative:'src/nested.md',directory:false}]:entries).map(f=>({...f,name:path.basename(f.relative),path:path.join('C:\\project',f.relative)}));};
 tabs.render();await settle();reads.length=0;
 return {tabs,p,document,File,files,status,reads,setEntries:v=>{entries=v;},row:(file,group='.et-dt-loose-files')=>[...document.querySelectorAll(group+' .et-dt-row')].find(r=>r.dataset.key===tabs.key(file))};
}
test('opening and closing Markdown retains project sections, folders, adjacent tabs and focused controls without directory reads',async t=>{
 const f=await fixture(t),{tabs,files,document}=f,project=document.querySelector('[data-section="projects"]'),folder=project.querySelector('details'),tree=project.querySelector('[data-project-files]'),a=f.row(files.a),b=f.row(files.b),pin=f.row(files.a,'[data-section="pinned"]');
 const mutations=[];const observer=new document.defaultView.MutationObserver(records=>mutations.push(...records));observer.observe(project,{childList:true,subtree:true});t.after(()=>observer.disconnect());
 a.querySelector('.et-dt-open').focus();tabs.scroll.scrollTop=123;tabs.pending={path:files.b};tabs.render();assert.equal(a.querySelector('.et-dt-open'),document.activeElement);assert.equal(tabs.scroll.scrollTop,123);
 f.File.bundle.filePath=files.b;tabs.sync();assert.equal(f.row(files.b),b);assert(b.classList.contains('active'));assert(!a.classList.contains('active'));assert.equal(b.querySelector('.et-dt-open').getAttribute('aria-selected'),'true');
 f.File.bundle.filePath=files.c;tabs.sync();assert(f.row(files.c));assert.equal(f.row(files.a),a);tabs.close(tabs.key(files.a));assert.equal(f.row(files.a),undefined);assert.equal(f.row(files.b),b);assert.equal(f.row(files.a,'[data-section="pinned"]'),pin);assert.equal(pin.querySelector('.et-dt-close').hidden,true);
 await settle();assert.equal(document.querySelector('[data-section="projects"]'),project);assert.equal(project.querySelector('[data-project-files]'),tree);assert.equal(project.querySelector('details'),folder);assert.equal(folder.open,true);assert.deepEqual(f.reads,[]);assert.equal(mutations.length,0);
});
test('dirty, pending, favorite and pin controls update on retained project rows without filesystem refresh',async t=>{
 const f=await fixture(t),row=f.row(f.files.a,'[data-section="projects"]'),tree=row.closest('[data-project-files]');
 f.status.dirty=true;f.tabs.render();assert(row.querySelector('.et-dt-dirty'));assert.match(row.querySelector('.et-dt-open').getAttribute('aria-label'),/未保存/);
 f.status.dirty=false;f.tabs.render();assert.equal(row.querySelector('.et-dt-dirty'),null);f.tabs.pending={path:f.files.a};f.tabs.render();assert(row.classList.contains('pending'));f.tabs.clearPending();f.tabs.render();assert(!row.classList.contains('pending'));
 f.tabs.toggleFavorite(f.files.a);f.tabs.togglePin(f.files.a);await settle();assert.equal(f.row(f.files.a,'[data-section="projects"]'),row);assert.equal(row.closest('[data-project-files]'),tree);assert.equal(row.querySelector('.et-dt-star').getAttribute('aria-pressed'),'true');assert.equal(row.querySelector('.et-dt-pin').getAttribute('aria-pressed'),'false');assert.deepEqual(f.reads,[]);
});
test('project multi-selection and folder expansion survive navigation independently from the active tab',async t=>{
 const f=await fixture(t),project=f.document.querySelector('[data-section="projects"]'),row=f.row(f.files.a,'[data-section="projects"]'),folder=project.querySelector('details');
 f.tabs.selectProjectFile(row,{});folder.open=false;await settle();folder.open=true;await settle();f.reads.length=0;
 f.File.bundle.filePath=f.files.b;f.tabs.sync();await settle();assert.equal(f.document.querySelector('[data-section="projects"]'),project);assert.equal(project.querySelector('details'),folder);assert(folder.open);assert(row.classList.contains('selected'));assert(!row.classList.contains('active'));assert.equal(row.querySelector('.et-dt-open').getAttribute('aria-selected'),'true');assert.deepEqual(f.reads,[]);
});
test('an in-flight directory read is reused and new rows receive the latest navigation state',async t=>{
 const f=await fixture(t);let resolve;f.p.invalidateFiles();f.p.core.list=()=>{f.reads.push('pending');return new Promise(r=>resolve=r);};f.tabs.render();const host=f.document.querySelector('[data-project-files]');
 f.File.bundle.filePath=f.files.b;f.tabs.sync();f.status.dirty=true;f.tabs.render();assert.equal(f.document.querySelector('[data-project-files]'),host);assert.deepEqual(f.reads,['pending']);
 resolve([{relative:'b.md',path:f.files.b,name:'b.md',directory:false}]);await settle();const row=f.row(f.files.b,'[data-section="projects"]');assert(row.classList.contains('active'));assert(row.querySelector('.et-dt-dirty'));assert.equal(row.querySelector('.et-dt-open').getAttribute('aria-selected'),'false');
});
test('explicit directory refresh still discovers added and renamed files',async t=>{
 const f=await fixture(t);f.setEntries([{relative:'renamed.md',directory:false},{relative:'new.md',directory:false}]);f.p.render();await settle();assert.equal(f.row(f.files.a,'[data-section="projects"]'),undefined);assert(f.row('C:\\project\\renamed.md','[data-section="projects"]'));assert(f.row('C:\\project\\new.md','[data-section="projects"]'));assert.deepEqual(f.reads,['']);
});
test('retained close button reflects the final tab and still invokes the existing native close path',async t=>{
 const f=await fixture(t),a=f.row(f.files.a);f.tabs.close(f.tabs.key(f.files.b));assert.equal(f.row(f.files.a),a);assert.equal(a.querySelector('.et-dt-close').title,'关闭最后一个标签及当前窗口');
 let closed;f.tabs.close=key=>closed=key;a.querySelector('.et-dt-close').click();assert.equal(closed,f.tabs.key(f.files.a));
});
test('code editor selection and unsaved state update retained Markdown and project rows',async t=>{
 const f=await fixture(t),a=f.row(f.files.a),b=f.row(f.files.b),projectRow=f.row(f.files.b,'[data-section="projects"]');f.status.visible=f.tabs.key(f.files.b);f.status.codeDirty.add(f.files.b);f.tabs.render();assert(!a.classList.contains('active'));assert(b.classList.contains('active'));assert(b.querySelector('.et-dt-dirty'));assert(projectRow.querySelector('.et-dt-dirty'));
 f.status.visible='';f.status.codeDirty.clear();f.tabs.render();assert(a.classList.contains('active'));assert(!b.classList.contains('active'));assert.equal(b.querySelector('.et-dt-dirty'),null);assert.deepEqual(f.reads,[]);
});
test('case-only rename updates the retained tab title and path while leaving neighbors intact',async t=>{
 const f=await fixture(t),b=f.row(f.files.b);f.tabs.change(db=>db.tabs[0]={path:'C:\\project\\A.md'});assert.equal(f.row(f.files.a).dataset.path,'C:\\project\\A.md');assert.equal(f.row(f.files.a).querySelector('.et-dt-name').textContent,'A');assert.equal(f.row(f.files.b),b);assert.deepEqual(f.reads,[]);
});

test('normalizing path separators while opening a new file does not replace existing tabs',async t=>{
 const f=await fixture(t);f.tabs.tabs=f.tabs.tabs.map(e=>({path:e.path.replaceAll('\\','/')}));f.tabs.render();const a=f.row(f.files.a),b=f.row(f.files.b);f.File.bundle.filePath=f.files.c;f.tabs.sync();assert.equal(f.row(f.files.a),a);assert.equal(f.row(f.files.b),b);assert(f.row(f.files.c));assert.deepEqual(f.reads,[]);
});

test('closing an earlier inactive tab never detaches the focused surviving tab',async t=>{
 const f=await fixture(t);f.File.bundle.filePath=f.files.c;f.tabs.sync();const b=f.row(f.files.b),button=b.querySelector('.et-dt-open'),mutations=[];button.focus();const observer=new f.document.defaultView.MutationObserver(ms=>mutations.push(...ms));observer.observe(b.parentElement,{childList:true});t.after(()=>observer.disconnect());f.tabs.close(f.tabs.key(f.files.a));await settle();assert.equal(f.document.activeElement,button);assert.equal(f.row(f.files.b),b);assert(!mutations.some(m=>[...m.removedNodes].includes(b)));assert.deepEqual(f.reads,[]);
});
