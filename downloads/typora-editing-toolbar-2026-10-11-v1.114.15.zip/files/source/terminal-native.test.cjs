// Real ConPTY checks are opt-in; all files and child processes belong to this test.
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),{spawn}=require('node:child_process');
const {TerminalSession}=require('./terminal-session.cjs');
const enabled=process.platform==='win32'&&process.env.ET_TERMINAL_NATIVE_TEST==='1';
const root=process.env.ET_TERMINAL_TEST_DIR||path.join(process.env.USERPROFILE||'.','Downloads','codex-temp','terminal-native-tests');
const host=path.resolve(__dirname,'../plugin/editing-toolbar.terminal.exe');
const delay=ms=>new Promise(r=>setTimeout(r,ms));
async function until(fn,ms=12000){const start=Date.now();while(!fn()){if(Date.now()-start>ms)throw Error('Native terminal wait timed out');await delay(30);}}
function alive(pid){try{process.kill(pid,0);return true;}catch{return false;}}
async function session(t,profile='cmd'){
 const cwd=path.join(root,'中文 目录');fs.mkdirSync(cwd,{recursive:true});let output='';const errors=[];
 const s=new TerminalSession(require,{onData:(bytes,ack)=>{output+=bytes.toString('utf8');ack();},onError:e=>errors.push(e.message)});
 t.after(async()=>{s.stop();await until(()=>!s.child||s.state==='exited',6000);});await s.start({host,profile,cwd,cols:120,rows:24});
 return {s,text:()=>output,errors};
}
for(const profile of ['cmd','powershell'])test('ConPTY '+profile+': Unicode interactive input, resize, interruption and normal exit',{skip:!enabled,timeout:30000},async t=>{
 const {s,text,errors}=await session(t,profile);await until(()=>text().includes('>'));s.write(profile==='cmd'?'echo UNICODE_中文\r':'Write-Output "UNICODE_中文"\r');await until(()=>text().split('UNICODE_中文').length>=3);
 s.resize(70,18);s.write(profile==='cmd'?'set /p answer=INPUT_READY:\r':'$answer = Read-Host "INPUT_READY"\r');await delay(350);s.write('回答内容\r');await delay(200);s.write(profile==='cmd'?'echo RECEIVED_%answer%\r':'Write-Output "RECEIVED_$answer"\r');await until(()=>text().includes('RECEIVED_回答内容'));
 s.write(profile==='cmd'?'ping -t 127.0.0.1\r':'Start-Sleep -Seconds 100\r');await delay(500);s.write('\x03');await delay(250);s.write(profile==='cmd'?'echo AFTER_INTERRUPT\r':'Write-Output "AFTER_INTERRUPT"\r');await until(()=>text().split('AFTER_INTERRUPT').length>=3);
 s.write('exit 0\r');await until(()=>s.state==='exited');assert.equal(s.exitCode,0);assert.deepEqual(errors,[]);assert(!alive(s.pid));
});
test('session termination kills the shell and its child process tree',{skip:!enabled,timeout:20000},async t=>{
 const {s,text}=await session(t,'powershell');const pidFile=path.join(root,'child-'+process.pid+'.txt');t.after(()=>{if(fs.existsSync(pidFile))fs.unlinkSync(pidFile);});
 await until(()=>text().includes('>'));s.write('$p = Start-Process powershell.exe -ArgumentList "-NoLogo -NoProfile -Command Start-Sleep -Seconds 100" -WindowStyle Hidden -PassThru; [IO.File]::WriteAllText(\''+pidFile.replaceAll("'","''")+'\', [string]$p.Id)\r');
 await until(()=>fs.existsSync(pidFile));const pid=Number(fs.readFileSync(pidFile,'utf8'));assert(alive(pid));s.stop();await until(()=>s.state==='exited');await until(()=>!alive(pid));assert(!alive(s.pid));
});
test('stdin EOF closes owned session even without a stop message',{skip:!enabled,timeout:15000},async t=>{
 const {s}=await session(t);s.child.stdin.end();await until(()=>s.state==='exited');assert(!alive(s.pid));
});
test('Typora PATHEXT restriction is repaired for native executable commands',{skip:!enabled,timeout:15000},async t=>{
 const previous=process.env.PATHEXT;let sample;
 try{process.env.PATHEXT='.CPL';sample=await session(t,'powershell');}finally{if(previous===undefined)delete process.env.PATHEXT;else process.env.PATHEXT=previous;}
 const {s,text}=sample;await until(()=>text().includes('>'));s.write('cmd.exe /d /c echo NATIVE_EXEC_OK\r');await until(()=>text().split('NATIVE_EXEC_OK').length>=3);assert.equal(s.state,'running');
});
test('host owner death cleans up terminal even while input pipe remains open',{skip:!enabled,timeout:15000},async t=>{
 fs.mkdirSync(root,{recursive:true});const owner=spawn(process.execPath,['-e','setInterval(()=>{},1000)'],{windowsHide:true,stdio:'ignore'}),child=spawn(host,[],{windowsHide:true,stdio:['pipe','pipe','ignore']});let pid,closed=false,buffer='';
 t.after(()=>{owner.kill();child.kill();});child.stdout.on('data',chunk=>{buffer+=chunk;let at;while((at=buffer.indexOf('\n'))>=0){const m=JSON.parse(buffer.slice(0,at));buffer=buffer.slice(at+1);if(m.type==='ready')pid=m.pid;}});child.on('close',()=>closed=true);child.stdin.on('error',()=>{});
 child.stdin.write(JSON.stringify({type:'start',exe:process.env.SystemRoot+'\\System32\\cmd.exe',args:['/d'],cwd:root,ownerPid:owner.pid,cols:80,rows:24})+'\n');await until(()=>pid);owner.kill();await until(()=>closed);assert(!alive(pid));
});

test('project Python executes in its venv and cwd without modifying the parent environment',{skip:!enabled||!process.env.ET_TERMINAL_PYTHON_EXE,timeout:20000},async t=>{
 const {pythonEnvironment,environmentVariables}=require('./terminal-environment.cjs'),cwd=path.join(root,'Python 项目'),venv=path.join(cwd,'.venv');fs.mkdirSync(cwd,{recursive:true});
 require('node:child_process').execFileSync(process.env.ET_TERMINAL_PYTHON_EXE,['-m','venv','--without-pip',venv],{windowsHide:true});
 const python=await pythonEnvironment(require,cwd),before={...process.env};assert.equal(python.kind,'venv');
 const env=environmentVariables(process.env,python),out=path.join(cwd,'python-result.json');if(fs.existsSync(out))fs.unlinkSync(out);let text='';
 const s=new TerminalSession(require,{onData:(b,ack)=>{text+=b.toString();ack();}});t.after(async()=>{s.stop();await until(()=>s.state==='exited',6000);});
 await s.start({host,cwd,environment:env,cols:150,rows:24});await until(()=>text.includes('>'));
 const program="import sys,os,json,pathlib; pathlib.Path('python-result.json').write_text(json.dumps(dict(exe=sys.executable,cwd=os.getcwd(),prefix=sys.prefix)))";
 s.write('python -c "'+program+'"\r');await until(()=>fs.existsSync(out));const actual=JSON.parse(fs.readFileSync(out,'utf8'));
 assert.equal(actual.exe.toLowerCase(),python.exe.toLowerCase());assert.equal(actual.cwd,cwd);assert.equal(actual.prefix,venv);assert.deepEqual({...process.env},before);
});
