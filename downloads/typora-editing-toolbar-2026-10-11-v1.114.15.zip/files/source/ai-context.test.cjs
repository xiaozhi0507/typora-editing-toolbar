const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),http=require('node:http');
const Core=require('./ai-context.cjs'),Client=require('./ai-client.cjs');
const sandbox={ETAIContext:Core,ETAIClient:Client,AbortController,console};vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(require.resolve('./ai-context.js'),'utf8')+';globalThis.Context=EditingToolbarAIContext;',sandbox);
function turns(n=5){return Array.from({length:n},(_,i)=>({id:'t'+i,status:'done',question:'问题'+i,answer:'回答'+i+' 已验证的事实、文件路径和约束。'.repeat(180),requestContext:{text:'参考资料'+i}}));}
function fixture(n=5){
  const a={turns:turns(n),config:{},context:{file:'fixture.md'},toolbar:{_showToolbarNotice(){}},profile:()=>({id:'p',model:'mock',url:'https://example.invalid',protocol:'openai-chat'}),assertRequestDocument(ctx,c){if(c.signal.aborted||ctx!==this.context)throw Object.assign(Error('已停止'),{name:'AbortError'});},source:()=>'',conversations:{flush:()=>true}};
  const ui=a.contextUI=new sandbox.Context(a),calls=[];
  a.request=async(p,k,m,o)=>{calls.push({p,m,o});return{text:'目标：修改插件。已完成阶段检查。保留路径 /project/main.py。待办：继续验证。',finishReason:'stop'};};
  return {a,ui,calls,controller:new AbortController(),run:()=>ui.compact(a.profile(),'',a.turns,new AbortController(),a.context)};
}
test('budget is per profile/model/endpoint and explicit local defaults do not imply model capacity',()=>{
  const p={id:'a',model:'m',url:'one'},s=Core.settings({},p),config={contextBudgets:{[s.key]:{budget:64000,threshold:90,auto:false}}};
  assert.equal(s.budget,32768);assert.equal(s.threshold,80);assert.equal(Core.settings(config,p).auto,false);assert.equal(Core.settings(config,{...p,model:'other'}).budget,32768);assert.equal(Core.settings(config,{...p,url:'other'}).budget,32768);
});
test('threshold reserves configured output and clamps invalid settings',()=>{
  assert.equal(Core.threshold({budget:10000,threshold:95},{maxTokensEnabled:true,maxTokens:4000}),6000);
  const s=Core.settings({contextBudgets:{[Core.settings({},{}).key]:{budget:-1,threshold:120}}});assert.equal(s.budget,4096);assert.equal(s.threshold,95);
});
test('estimation ignores base64 length, includes text and handles unicode',()=>{
  assert.equal(Core.tokens({type:'image_url',image_url:{url:'data:image/png;base64,'+'A'.repeat(1000000)}}),1536);
  assert.ok(Core.textTokens('中文测试')>Core.textTokens('test'));assert.equal(Core.textTokens('😀'),2);
});
test('chunking is bounded and never loses unicode data',()=>{
  let rest='中😀hello'.repeat(500),all='',i=0;while(rest){const [chunk,next]=Core.chunk(rest,127);assert.ok(chunk);assert.ok(Core.textTokens(chunk)<=127);assert.ok(!/[\uD800-\uDBFF]$/.test(chunk));all+=chunk;rest=next;i++;}assert.equal(all,'中😀hello'.repeat(500));assert.ok(i>5);
});
test('slash command only matches slash or compact prefix in an otherwise empty composer',()=>{
  for(const s of ['/','/c','/com','/compact','/压','/压缩'])assert.ok(Core.slash(s),s);
  for(const s of ['','/home/foo','请看 /compact',' /','/compact now','/compact\n'])assert.equal(Core.slash(s),false,s);
});
test('plan preserves recent turns and never compresses unfinished replies',()=>{
  const t=turns();t.push({id:'running',status:'running'});assert.equal(Core.plan(t).prefix.length,3);assert.equal(Core.plan(turns(1)).possible,false);assert.equal(Core.plan(turns(2)).prefix.length,1);
});
test('successful summary reduces next request while preserving full raw transcript and sources',async()=>{
  const {a,ui,calls,run}=fixture(),raw=JSON.stringify(a.turns);await run();assert.equal(JSON.stringify(a.turns),raw);assert.equal(ui.state.covered.length,3);assert.equal(calls[0].p.documentEdit,false);assert.equal(Client.tools(calls[0].p).length,0);assert.equal(calls[0].p.maxTokensEnabled,true);
  const m=Client.messages(a.profile(),{text:'KEEP ORIGINAL SOURCE'},ui.history(),'NEW QUESTION',{text:'KEEP NEW QUOTE'}),text=JSON.stringify(m);
  assert.ok(text.includes('history_summary'));assert.ok(text.includes('main.py'));assert.ok(text.includes('KEEP ORIGINAL SOURCE'));assert.ok(text.includes('KEEP NEW QUOTE'));assert.ok(text.includes(a.turns[4].answer));assert.ok(!text.includes(a.turns[0].answer));assert.equal(m[0].role,'system');assert.ok(!m[0].content.includes('main.py'));
});
test('checkpoint validity rejects edits, foreign sessions, reordered/deleted turns and corrupt shape',async()=>{
  const {a,ui,run}=fixture();await run();const state=JSON.parse(JSON.stringify(ui.state));assert.ok(Core.valid(state,a.turns));
  assert.equal(Core.valid({...state,covered:null},a.turns),false);assert.equal(Core.valid(state,a.turns.slice(1)),false);assert.equal(Core.valid(state,[a.turns[1],a.turns[0],...a.turns.slice(2)]),false);
  a.turns[0].answer+=' changed';assert.equal(Core.valid(state,a.turns),false);assert.equal(ui.history()[0],a.turns[0]);
});
test('second compaction incorporates old summary only once and covers only new prefix',async()=>{
  const {a,ui,calls,run}=fixture();await run();a.turns.push(...turns(3).map((t,i)=>({...t,id:'new'+i,answer:'全新答复'+i+' 新事实。'.repeat(180)})));await run();assert.equal(ui.state.covered.length,6);assert.ok(calls[1].m[1].content.includes('main.py'));assert.ok(!calls[1].m[2].content.includes(a.turns[0].answer));assert.equal(ui.history().length,3);
});
test('automatic trigger compacts before returning real request; disabled and below threshold do not',async()=>{
  const {a,ui,calls,controller}=fixture(),build=h=>Client.messages(a.profile(),{},h,'next');a.config.contextBudgets={[ui.settings().key]:{budget:4096,threshold:80,auto:false}};
  await ui.beforeSend(a.profile(),'',a.turns,build,controller,a.context);assert.equal(calls.length,0);a.config.contextBudgets[ui.settings().key].auto=true;
  const messages=await ui.beforeSend(a.profile(),'',a.turns,build,controller,a.context);assert.ok(calls.length>0);assert.ok(JSON.stringify(messages).includes('history_summary'));
  const n=calls.length;await ui.beforeSend(a.profile(),'',a.turns,build,controller,a.context);assert.equal(calls.length,n);
});
test('multi-batch summarization fits budget and commits once',async()=>{
  const {a,ui,calls,run}=fixture();a.turns[0].answer='长文数据'.repeat(3500);a.config.contextBudgets={[ui.settings().key]:{budget:4096,threshold:80}};let writes=0;a.conversations.flush=()=>{writes++;return true;};await run();assert.ok(calls.length>2);assert.equal(writes,1);for(const c of calls)assert.ok(Core.tokens(c.m)+c.p.maxTokens<4096);
});
for(const failure of ['abort','document','provider','truncated','empty','tool','not-smaller','save','edited-history'])test('failed compaction is atomic: '+failure,async()=>{
  const {a,ui,controller}=fixture(),raw=JSON.stringify(a.turns);ui.state={old:'untouched'};const old=ui.state;
  a.request=async()=>{
    if(failure==='abort')controller.abort();if(failure==='document')a.context={file:'other'};if(failure==='provider')throw Error('network');if(failure==='edited-history')a.turns[0].question='edited';
    if(failure==='save')a.conversations.flush=()=>false;
    return {text:failure==='empty'?'':failure==='not-smaller'?a.turns.map(t=>t.answer).join(''):'有效简短摘要',finishReason:failure==='truncated'?'length':'stop',...(failure==='tool'?{toolCalls:[{name:'edit_current_document'}]}:{})};
  };
  await assert.rejects(ui.compact(a.profile(),'',a.turns,controller,a.context));assert.equal(ui.state,old);assert.equal(ui.running,false);if(failure!=='edited-history')assert.equal(JSON.stringify(a.turns),raw);
});
test('restore roundtrip validates checkpoint and new conversation clears it',async()=>{const {a,ui,run}=fixture();await run();const snapshot=JSON.parse(JSON.stringify(ui.snapshot()));ui.reset();assert.equal(ui.state,null);ui.restore(snapshot);assert.equal(ui.state.summary,snapshot.summary);a.turns=[];ui.restore(snapshot);assert.equal(ui.state,null);});

async function usageFixture(t,protocol,packets){
  const server=http.createServer((req,res)=>{req.resume();res.writeHead(200,{'Content-Type':'text/event-stream'});res.end(packets.map(p=>'data: '+(typeof p==='string'?p:JSON.stringify(p))+'\n\n').join(''));});await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>{server.closeAllConnections();server.close();});
  return new Client(require).request({model:'mock',url:'http://127.0.0.1:'+server.address().port,protocol},'',[{role:'user',content:'test'}]);
}
test('Chat final usage chunk is captured without treating total billed tokens as active input',async t=>{
  const r=await usageFixture(t,'openai-chat',[{choices:[{delta:{content:'ok'},finish_reason:'stop'}]},{choices:[],usage:{prompt_tokens:120,completion_tokens:20,total_tokens:140}},'[DONE]']);assert.deepEqual(r.usage,{inputTokens:120,outputTokens:20});
});
test('Responses completion exposes input/output usage',async t=>{
  const r=await usageFixture(t,'openai-responses',[{type:'response.completed',response:{status:'completed',output_text:'ok',usage:{input_tokens:150,output_tokens:12}}}]);assert.deepEqual(r.usage,{inputTokens:150,outputTokens:12});
});
test('Anthropic separate cached input and final output usage are merged',async t=>{
  const r=await usageFixture(t,'anthropic-messages',[{type:'message_start',message:{usage:{input_tokens:50,cache_read_input_tokens:100,cache_creation_input_tokens:20}}},{type:'content_block_delta',index:0,delta:{type:'text_delta',text:'ok'}},{type:'message_delta',delta:{stop_reason:'end_turn'},usage:{output_tokens:12}},{type:'message_stop'}]);assert.deepEqual(r.usage,{inputTokens:170,outputTokens:12});
});

test('corrupt covered entries fall back to raw history',()=>{const t=turns();assert.equal(Core.valid({version:1,summary:'test',covered:[null]},t),false);});
test('automatic compression failure reports stopped state without returning a request',async()=>{const {a,ui,controller}=fixture();a.config.contextBudgets={[ui.settings().key]:{budget:4096,threshold:50}};a.request=async()=>{throw Error('offline');};await assert.rejects(ui.beforeSend(a.profile(),'',a.turns,h=>Client.messages(a.profile(),{},h,'new request'),controller,a.context),/offline/);assert.equal(ui.state,null);assert.equal(ui.running,false);assert.match(ui.message,/压缩失败/);});


test('known capacity does not replace compression budget and unknown aliases are not guessed',()=>{
 const p={id:'d',model:'deepseek-flash',url:'https://api.deepseek.com/v1'},cfg={contextBudgets:{[Core.settings({},p).key]:{budget:25800}}};
 assert.equal(Core.capacity(cfg,p).value,1000000);assert.equal(Core.settings(cfg,p).budget,25800);assert.equal(Core.capacity({}, {...p,url:'https://proxy.invalid'}).value,null);assert.equal(Core.capacity({}, {...p,contextWindow:131072}).value,131072);
});
test('creating a file never needs to estimate or read live whole-document text',()=>{
 const {a,ui}=fixture(0);a.source=()=>{throw Error('whole source must not be read')};const p={...a.profile(),documentEdit:true,project:{name:'p',trusted:true}},m=Client.messages(p,{},[],'create a.py');
 assert.ok(ui.estimate(p,m)<2200);assert.ok(!JSON.stringify(Client.contextMessages(p,m)).includes('完整 Markdown'));assert.ok(Client.tools(p).some(t=>t.name==='read_current_document'));
});
test('provider input calibrates estimates without billing output or leaking transient tool bodies into next history',()=>{
 const {a,ui}=fixture(),p=a.profile(),m=Client.messages(p,{},[],'test'),t=a.turns[0],raw=ui.raw(p,m);ui.recordUsage(p,m,{usage:{inputTokens:raw*2,outputTokens:90000}},t);
 assert.equal(ui.estimate(p,m),raw*2);assert.equal(t.requestContext.contextUsage.outputTokens,90000);assert.equal(ui.measurement({...p,model:'other'}),undefined);
 assert.ok(!JSON.stringify(Client.messages(p,{},ui.history(),'next')).includes('contextUsage'));
});

test('summary chunks respect known model capacity even when saved budget is larger',async()=>{
 const {a,ui,calls,controller}=fixture();const p={...a.profile(),contextWindow:4096};a.turns[0].answer='长文数据'.repeat(3500);a.config.contextBudgets={[ui.settings(p).key]:{budget:32768,threshold:80}};await ui.compact(p,'',a.turns,controller,a.context);assert.ok(calls.length>2);for(const c of calls)assert.ok(Core.tokens(c.m)+c.p.maxTokens<4096);
});
test('manual capacity overrides metadata and invalid values do not invent capacity',()=>{
 const p={id:'test',model:'alias',url:'https://proxy.invalid',contextWindow:131072},key=Core.settings({},p).key;assert.equal(Core.capacity({contextBudgets:{[key]:{capacity:65536}}},p).value,65536);assert.equal(Core.capacity({contextBudgets:{[key]:{capacity:-1}}},{...p,contextWindow:undefined}).value,null);assert.equal(Client.effortMetadata({context_window:258000}).contextWindow,258000);
});


test('slash skills search enabled metadata without matching paths or ordinary prose',()=>{
 const items=[{name:'paper-study',displayName:'论文阅读',description:'翻译 PDF',enabled:true},{name:'disabled',description:'PDF',enabled:false},{name:'broken',description:'PDF',enabled:true,error:'missing'}];
 assert.deepEqual(Core.slashMenu('/',items).skills.map(s=>s.name),['paper-study']);
 for(const query of ['/paper','/论文','/PDF','/技能','/skills','/skills 翻译 PDF'])assert.equal(Core.slashMenu(query,items).skills[0]?.name,'paper-study',query);
 assert.equal(Core.slashMenu('/unknown',items).skills.length,0);assert.equal(Core.slashMenu('/compact',items).compact,true);
 for(const query of ['', '/home/foo','/C:\\file','请看 /paper',' /paper','/compact now','/paper\n'])assert.equal(Core.slashMenu(query,items),null,query);
});
test('slash selection consumes only the command, never sends, and validates currently enabled inventory',async()=>{
 const {a,ui,calls}=fixture(0),selected=[],events=[],notices=[];a.prompt={value:'/paper',dispatchEvent:e=>events.push(e.type),focus(){}};
 a.skillsUI={items:[{name:'paper',enabled:true,description:'Paper'}],selectSkill:n=>selected.push(n)};a.notice=x=>notices.push(x);ui.close=()=>ui.kind=null;sandbox.Event=class{constructor(type){this.type=type;}};
 await ui.fromSlash('skill:paper');assert.deepEqual(selected,['paper']);assert.equal(a.prompt.value,'');assert.deepEqual(events,['input']);assert.equal(calls.length,0);
 a.prompt.value='/paper';a.skillsUI.items[0].enabled=false;await ui.fromSlash('skill:paper');assert.equal(selected.length,1);assert.equal(a.prompt.value,'/paper');
 a.skillsUI.items[0].enabled=true;a.busy=true;await ui.fromSlash('skill:paper');assert.equal(selected.length,1);a.busy=false;
 a.skillsUI.selectSkill=()=>{throw Error('技能已禁用');};ui.syncSlash=()=>{};await ui.fromSlash('skill:paper');assert.deepEqual(notices,['技能已禁用']);assert.equal(a.prompt.value,'/paper');
});
test('slash keyboard moves the active option and supports Tab, Enter and IME guard',()=>{
 const {ui}=fixture(0),buttons=['skill:a','skill:b'].map(command=>({dataset:{command}})),selected=[];ui.kind='slash';ui.slashActive='skill:a';ui.slashButtons=()=>buttons;ui.highlightSlash=b=>ui.slashActive=b.dataset.command;ui.fromSlash=()=>selected.push(ui.slashActive);
 const key=(key,extra={})=>{let prevented=false;ui.slashKey({key,preventDefault:()=>prevented=true,stopImmediatePropagation(){},...extra});return prevented;};
 assert.equal(key('ArrowDown'),true);assert.equal(ui.slashActive,'skill:b');key('Tab');assert.deepEqual(selected,['skill:b']);key('ArrowUp');key('Enter');assert.deepEqual(selected,['skill:b','skill:a']);
 assert.equal(key('Enter',{isComposing:true}),false);assert.equal(key('Enter',{keyCode:229}),false);key('Enter',{repeat:true});assert.equal(key('Enter',{ctrlKey:true}),false);assert.equal(selected.length,2);
});
