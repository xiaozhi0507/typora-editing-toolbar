const fs=require('node:fs'),path=require('node:path');
module.exports=function(code){
 const replace=(a,b)=>{if(!code.includes(a))throw Error('Missing document note integration: '+a.slice(0,100));code=code.replace(a,b);};
 code=code.replaceAll('笔记注释','注释');
 replace('try {this.annotations=new EditingToolbarAnnotations(this);}', 'try {this.annotations=new EditingToolbarAnnotations(this);this.documentNotes=new EditingToolbarDocumentNotes(this);}');
 replace('    _injectCSS() {',`    _activeNotePanel(){return [this.annotations,this.documentNotes].find(m=>m&&!m.panel.hidden)?.panel;}
    _editingNotePanel(){return [this.annotations,this.documentNotes].some(m=>m?.panel.contains(document.activeElement));}
    _injectCSS() {`);
 code=code.replaceAll('this.annotations?.panel.contains(document.activeElement)','this._editingNotePanel()');
 replace('(this.annotations&&!this.annotations.panel.hidden?this.annotations.panel.getBoundingClientRect().left:document.documentElement.clientWidth)','(this._activeNotePanel()?.getBoundingClientRect().left??document.documentElement.clientWidth)');
 replace('"annotation","more-menu","toolbar-settings"];','"annotation","document-note","more-menu","toolbar-settings"];');
 replace('"bg-color","annotation","fullscreen"','"bg-color","annotation","document-note","fullscreen"');
 code=code.replaceAll('annotationRevision:1,','annotationRevision:1,documentNotesRevision:1,');
 replace('        const top = topLayout === "classic"',`        if(!input.documentNotesRevision){
            for(const ids of [compact.order,classic.buttons])if(!ids.includes('document-note')){const at=ids.indexOf('annotation');ids.splice(at>=0?at+1:Math.max(0,ids.indexOf('toolbar-settings')),0,'document-note');}
        }
        const top = topLayout === "classic"`);
 replace('controls:["undo","redo","annotation","more-menu","toolbar-settings"],buttons:["undo","redo","annotation",','controls:["undo","redo","annotation","document-note","more-menu","toolbar-settings"],buttons:["undo","redo","annotation","document-note",');
 replace('        if (action === "annotation")', '        if (action === "document-note") {if(this.documentNotes)return this.documentNotes.openFromSelection();this._showToolbarNotice("笔记未能加载，请重新打开 Typora。");return;}\n        if (action === "annotation")');
 replace('if(this.annotations)return this.annotations.openFromSelection();','if(this.annotations){if(this.documentNotes?.panel.contains(document.activeElement))return this.annotations.open();return this.annotations.openFromSelection();}');
 replace('正在编辑注释，请在注释框使用 Markdown，或先点击正文。','请使用当前编辑区的工具栏，或先点击正文。');
 replace('const BUTTON_DEFINITIONS = {',`const BUTTON_DEFINITIONS = {
    "document-note":{icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h13a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z"/><path d="M8 3v18M11 8h6M11 12h6M2 7h4M2 12h4M2 17h4"/></svg>',title:'笔记'},`);
 const pos=code.lastIndexOf('(function () {');if(pos<0)throw Error('Missing toolbar boot');
 return code.slice(0,pos)+['document-note-tabs.js','document-note-manager.js'].map(f=>fs.readFileSync(path.join(__dirname,f),'utf8')).join('\n')+'\n'+code.slice(pos);
};
