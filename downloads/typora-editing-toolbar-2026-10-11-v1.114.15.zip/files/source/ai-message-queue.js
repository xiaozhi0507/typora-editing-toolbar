// Each pending message owns a captured request. Never restore it over a live draft.
class EditingToolbarAIMessageQueue {
  constructor(ai){this.ai=ai;this.items=[];this.paused=false;this.epoch=0;}
  static icon='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4v10a4 4 0 0 0 4 4h12m-4-4 4 4-4 4M8 5h10M8 9h7"/></svg>';
  mount(){
    const a=this.ai;this.root=a.node('section','et-ai-queue');this.root.hidden=true;this.root.setAttribute('aria-label','待发送消息');
    this.head=a.node('div','et-ai-queue-head');this.label=a.node('span');this.label.setAttribute('role','status');this.toggle=this.button('暂停排队',()=>this.paused?this.resume():this.pause());this.head.append(this.label,this.toggle);
    this.list=a.node('div','et-ai-queue-list');this.list.setAttribute('role','list');this.root.append(this.head,this.list);a.panel.querySelector('.et-ai-composer').before(this.root);
    this.menu=a.composerUI.makeMenu('et-ai-queue-menu','排队消息操作');this.menu.setAttribute('popover','manual');
    document.addEventListener('pointerdown',e=>{if(this.menu.matches(':popover-open')&&!this.menu.contains(e.target)&&!this.anchor?.contains(e.target))this.closeMenu();});
    this.menu.onkeydown=e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();this.closeMenu(true);}if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){e.preventDefault();const rows=[...this.menu.querySelectorAll('button')],i=rows.indexOf(document.activeElement);rows[e.key==='Home'?0:e.key==='End'?rows.length-1:(i+(e.key==='ArrowUp'?-1:1)+rows.length)%rows.length]?.focus();}};
    window.addEventListener('resize',()=>this.closeMenu());window.addEventListener('blur',()=>this.closeMenu());this.render();
  }
  button(label,fn,icon){const b=this.ai.node('button');b.type='button';b.title=label;b.setAttribute('aria-label',label);if(icon)b.innerHTML=icon;else b.textContent=label;b.onclick=()=>fn();return b;}
  snapshot(){return this.items.length?JSON.parse(JSON.stringify({items:this.items,paused:this.paused})):null;}
  restore(data){this.clear();this.items=Array.isArray(data?.items)?data.items.filter(x=>x&&typeof x.id==='string'&&typeof x.request?.question==='string'&&x.request.question.trim()&&x.file===this.ai.file()&&x.profile&&x.input?.reference).slice(0,10).map(x=>JSON.parse(JSON.stringify(x))):[];this.paused=!!this.items.length;this.reason=this.paused?'已恢复待发送消息':'';this.render();}
  clear(){clearTimeout(this.timer);this.timer=null;this.captureController?.abort();this.captureController=null;this.preparing=false;this.dispatching=null;this.epoch++;this.items=[];this.paused=false;this.reason='';this.dialog?.close();this.closeMenu();this.render();}
  suspend(reason='排队已暂停'){this.captureController?.abort();this.pause(reason);this.dialog?.close();this.closeMenu();}
  pause(reason='排队已暂停'){clearTimeout(this.timer);this.timer=null;this.paused=true;this.reason=reason;this.changed();}
  resume(){if(!this.items.length)return;this.paused=false;this.reason='';this.changed();this.schedule();}
  changed(){this.render();this.ai.composerUI.sync();if(!this.ai.conversations.flush()){this.paused=true;this.reason='保存失败，排队已暂停';this.render();}}
  remove(id){if(this.dispatching===id)return;this.items=this.items.filter(x=>x.id!==id);if(!this.items.length){this.paused=false;this.reason='';}this.closeMenu();this.changed();this.schedule();}
  started(item){this.items=this.items.filter(x=>x.id!==item.id);this.dispatching=null;this.render();}
  completed(turn,epoch){if(epoch!==this.epoch)return;if(turn?.status!=='done')this.pause('当前回复已停止，排队已暂停');else this.schedule();}
  async enqueue(){
    const a=this.ai;if(a.composerLocked()||a.settingsBusy||a.attachments.pending||a.composerUI.draft.media?.pending)return;
    if(!a.followDocument())return;const request=a.composerUI.request();if(!request.question)return a.prompt.focus();
    if(this.items.length>=10)return a.notice('最多排队 10 条消息，请等待发送或移除一条',true);
    const profile=a.profile();if(!profile)return a.notice('请先配置模型',true);
    const submittedAt=new Date().toISOString(),epoch=this.epoch,file=a.file(),base=a.promptsManager.reference(),editMode=!!a.editUI?.enabled,codeFiles=a.codeUI?.snapshot()||[],project=codeFiles.length?a.codeUI.project(codeFiles):(editMode||a.shellUI?.enabled)?a.webUI?.defaultProject():null;
    const p={...profile,documentEdit:editMode,codeFiles,webSearch:codeFiles.length?false:!!a.webUI?.enabled,project};p.shellGrant=codeFiles.length?null:a.shellUI?.capture(project,p);p.shellEnabled=!!p.shellGrant;
    if(!codeFiles.length&&!a.validateSource(null,editMode,base))return;
    const controller=this.captureController=new AbortController();this.preparing=true;a.composerUI.sync();a.updateContext();
    try{
      const input=await a.prepareInput(base,null,p,controller.signal);
      if(controller.signal.aborted||epoch!==this.epoch||file!==a.file()||a.panel.hidden)return;
      // Store only model identity/options, never provider credentials.
      const identity=Object.fromEntries(['id','model','url','protocol','fullUrl','reasoningEffort'].map(k=>[k,profile[k]]));
      const ref=r=>r?Object.fromEntries(['text','label','name','detail','images','quotes','webSearch','projectId','sourceExecution','codeFiles'].filter(k=>r[k]!==undefined).map(k=>[k,r[k]])):r;
      const item=JSON.parse(JSON.stringify({id:reqnode('crypto').randomUUID(),file,request,profile:identity,editMode,webSearch:p.webSearch,shellGrant:p.shellGrant,project:project?{id:project.id,root:project.root}:null,input:{staged:input.staged,reference:ref(input.reference),requestContext:ref(input.requestContext)},time:submittedAt}));
      ETAIClient.body(p,ETAIClient.messages(p,input.reference,[],request.question,input.requestContext));ETAIClient.endpoint(p.url,p.protocol,p.fullUrl);
      if(JSON.stringify([...this.items,item]).length>32*1024*1024)throw Error('排队资料较大，请等待前面的消息发送后再添加');
      this.items.push(item);a.composerUI.consumed();this.changed();
    }catch(e){if(!controller.signal.aborted)a.notice(e.message,true);}
    finally{if(this.captureController===controller){this.captureController=null;this.preparing=false;a.composerUI.sync();a.updateContext();this.schedule();a.prompt.focus();}}
  }
  schedule(delay=30){if(this.timer||this.paused||!this.items.length||this.ai.busy||this.preparing||this.dispatching)return;this.timer=setTimeout(()=>{this.timer=null;void this.drain();},delay);}
  async drain(){
    const a=this.ai;if(this.paused||!this.items.length||a.busy||this.preparing||this.dispatching)return;
    const item=this.items[0],epoch=this.epoch;
    if(a.panel.hidden||File.isFileLoading?.()||item.file!==a.file()||a.context?.file!==item.file){this.pause('请回到对应文档后继续排队');return;}
    if(a.settingsBusy||a.preferences?.open||a.attachments.pending||a.composerUI.draft.media?.pending||this.dialog?.open||this.menu?.matches(':popover-open')){this.schedule(200);return;}
    this.dispatching=item.id;this.render();
    try{await a.send(null,item);}catch(e){a.notice(e.message,true);}
    finally{if(epoch===this.epoch){this.dispatching=null;if(this.items.some(x=>x.id===item.id))this.pause('消息尚未发送，请检查后继续');else this.schedule();this.render();}}
  }
  render(){
    if(!this.root)return;const a=this.ai;this.root.hidden=!this.items.length;this.label.textContent=(this.paused?'排队已暂停':'待发送')+' · '+this.items.length;this.label.title=this.reason||'当前回复结束后按顺序发送';
    this.toggle.textContent=this.paused?'继续排队':'暂停';this.toggle.setAttribute('aria-label',this.paused?'继续排队':'暂停排队');this.list.replaceChildren();
    for(const [i,item]of this.items.entries()){
      const row=a.node('div','et-ai-queue-row');row.dataset.id=item.id;row.setAttribute('role','listitem');const mark=a.node('span','et-ai-queue-icon');mark.innerHTML=EditingToolbarAIMessageQueue.icon;
      const preview=item.input.requestContext?.images?.[0]||item.input.reference.images?.[0];if(preview&&/^data:image[/](png|jpeg|webp);base64,/.test(preview.data)){const img=a.node('img');img.src=preview.data;img.alt='排队图片';img.decoding='async';mark.replaceChildren(img);}
      const copy=a.node('span','et-ai-queue-copy',item.request.displayQuestion||item.request.question);copy.title=copy.textContent+'\n'+(item.input.requestContext?.label||item.input.reference.label||'自由提问');
      const del=this.button('删除排队消息 '+(i+1),()=>this.remove(item.id),a.conversations.icon('trash')),more=this.button('排队消息操作 '+(i+1),()=>this.openMenu(item,more),a.conversations.icon('more'));del.disabled=more.disabled=this.dispatching===item.id;more.setAttribute('aria-haspopup','menu');more.setAttribute('aria-expanded','false');row.append(mark,copy,del,more);this.list.append(row);
    }
    a.composerUI.draft.resize?.();a.navigation?.schedule();
  }
  openMenu(item,anchor){this.closeMenu();this.ai.composerUI.closeMenu();this.anchor=anchor;this.menu.replaceChildren();for(const [label,fn]of [['编辑消息',()=>this.edit(item)],['上移',()=>this.move(item,-1)],['下移',()=>this.move(item,1)],[this.paused?'继续排队':'暂停排队',()=>this.paused?this.resume():this.pause()]]){const b=this.button(label,()=>{this.closeMenu();fn();});b.setAttribute('role','menuitem');b.disabled=(label==='上移'&&this.items.indexOf(item)===0)||(label==='下移'&&this.items.indexOf(item)===this.items.length-1);this.menu.append(b);}this.menu.hidden=false;this.menu.showPopover();anchor.setAttribute('aria-expanded','true');const r=anchor.getBoundingClientRect(),m=this.menu.getBoundingClientRect();this.menu.style.left=Math.max(8,Math.min(innerWidth-m.width-8,r.right-m.width))+'px';this.menu.style.top=Math.max(8,r.top-m.height-6)+'px';this.menu.querySelector('button').focus();}
  closeMenu(focus=false){if(this.menu?.matches(':popover-open'))this.menu.hidePopover();if(this.menu)this.menu.hidden=true;this.anchor?.setAttribute('aria-expanded','false');if(focus)this.anchor?.focus();}
  move(item,delta){const i=this.items.indexOf(item),j=i+delta;if(i<0||j<0||j>=this.items.length||this.dispatching)return;this.items.splice(i,1);this.items.splice(j,0,item);this.changed();}
  edit(item){
    if(this.dispatching||!this.items.includes(item))return;const a=this.ai,d=this.dialog=a.node('dialog','et-ai-queue-editor');d.setAttribute('aria-label','编辑排队消息');const title=a.node('h3','','编辑消息'),input=a.node('textarea'),meta=a.node('p','',item.input.requestContext?.label||item.input.reference.label||'自由提问'),actions=a.node('div','et-ai-queue-editor-actions');input.setAttribute('aria-label','排队消息内容');input.value=item.request.question;input.rows=5;
    const save=this.button('保存消息',()=>{const text=input.value.trim();if(!text||!this.items.includes(item))return;item.request={question:text,displayQuestion:text,command:null,skills:{...item.request.skills,selected:ETAISkills.mentions(text)}};this.changed();d.close();});save.className='primary';input.oninput=()=>save.disabled=!input.value.trim();actions.append(this.button('取消',()=>d.close()),save);d.append(title,meta,input,actions);document.body.append(d);a.bindSurface(d);d.addEventListener('close',()=>{d.remove();if(this.dialog===d)this.dialog=null;this.schedule();a.prompt.focus();},{once:true});d.showModal();input.focus();
  }
}
