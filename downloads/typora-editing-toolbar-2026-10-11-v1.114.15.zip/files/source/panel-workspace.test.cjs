'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
const source=fs.readFileSync(__dirname+'/panel-workspace.js','utf8').split('// Keep module-specific')[0];
const Workspace=vm.runInNewContext(source+';EditingToolbarPanelWorkspace',{});
function fixture(lazy=false){
 const w=Object.create(Workspace.prototype),events=[],owner={panel:lazy?null:{hidden:true,classList:{contains:()=>false}},mount(){events.push('mount');this.panel={hidden:true,classList:{contains:()=>false}};},open(){events.push({mode:entry.mode,rect:{...entry.rect},slots:[...w.slots]});this.panel.hidden=false;w.opened(this);}};
 const entry={id:'ai',owner,mode:'dock',rect:{left:0,top:0,width:400,height:540}};
 Object.assign(w,{entries:new Map([['ai',entry]]),slots:['ai'],count:1,weights:[1],width:420,saved:{},owner:()=>owner,ensure:()=>owner.panel?entry:null,rect:r=>({...r}),focus:()=>events.push('focus'),layout:()=>events.push('layout'),persist:()=>events.push('persist'),hidePicker:()=>{}});
 return {w,owner,entry,events};
}
test('floating drop chooses final position before module open and does not dock or persist midway',()=>{const f=fixture();f.w.openDrop('ai',500,300,null);assert.equal(f.events[0].mode,'float');assert.equal(f.events[0].rect.left,440);assert.equal(f.events[0].rect.top,278);assert.deepEqual(f.events[0].slots,[null]);assert.equal(f.events.filter(e=>e==='layout'||e==='persist').length,0);assert.equal(f.w.openingDrop,null);});
test('first valid drop mounts lazy module once before choosing geometry',()=>{const f=fixture(true);f.w.openDrop('ai',500,300,null);f.w.openDrop('ai',520,300,null);assert.equal(f.events.filter(e=>e==='mount').length,1);assert.equal(f.owner.panel.hidden,false);});
test('snap drop sets final slots before opening without intermediate layout',()=>{const f=fixture();f.w.openDrop('ai',500,300,{count:1,index:0});assert.equal(f.events[0].mode,'dock');assert.deepEqual(f.events[0].slots,['ai']);assert.equal(f.events.includes('persist'),false);});
test('failed module open restores hidden state, placement and clears transaction',()=>{const f=fixture();f.owner.open=()=>{f.owner.panel.hidden=false;throw Error('fixture');};assert.throws(()=>f.w.openDrop('ai',500,300,null),/fixture/);assert.equal(f.owner.panel.hidden,true);assert.equal(f.entry.mode,'dock');assert.deepEqual([...f.w.slots],['ai']);assert.equal(f.w.openingDrop,null);assert.equal(f.events.at(-1),'layout');});
test('module which declines to open leaves its old placement intact',()=>{const f=fixture();f.owner.open=()=>{};f.w.openDrop('ai',500,300,null);assert.equal(f.entry.mode,'dock');assert.equal(f.owner.panel.hidden,true);assert.equal(f.w.openingDrop,null);});
test('ordinary module opens still perform normal layout and persistence',()=>{const f=fixture();f.w.opened(f.owner);assert.deepEqual(f.events,['layout','focus','persist']);});

test('moving an already open module never reopens or rebuilds its editor',()=>{const f=fixture();f.owner.panel.hidden=false;f.owner.open=()=>{throw Error('must not reopen');};f.w.openDrop('ai',500,300,null);assert.equal(f.entry.mode,'float');assert.equal(f.entry.rect.left,440);assert.deepEqual(f.events,['focus']);});
test('deferred snap changes occupancy once without an intermediate layout or persist',()=>{const f=fixture();f.owner.panel.hidden=false;f.entry.mode='float';f.w.snap('ai',1,0,true);assert.equal(f.entry.mode,'dock');assert.deepEqual(f.events,[]);assert.equal(f.w.slots[0],'ai');});
test('library participates in workspace but full mode never reserves document width',()=>{const f=fixture();f.w.toolbar={knowledgeLibrary:f.owner};assert.equal(f.w.id(f.owner),'library');f.w.owner=Workspace.prototype.owner;assert.equal(f.w.owner('library'),f.owner);f.owner.panel.hidden=false;f.entry.mode='full';assert.equal(f.w.dockWidth(),0);f.entry.mode='dock';assert.equal(f.w.dockWidth(),420);});
test('entering fullscreen releases the library dock slot without changing saved float geometry',()=>{const f=fixture();f.entry.id='library';f.w.entries=new Map([['library',f.entry]]);f.w.slots=['library'];const before={...f.entry.rect};f.w.full('library');assert.equal(f.entry.mode,'full');assert.deepEqual([...f.w.slots],[null]);assert.deepEqual(f.entry.rect,before);assert.equal(f.events.filter(e=>e==='layout').length,1);});
test('cancelling a layout restores all original modes and float bounds',()=>{const f=fixture();const saved=f.w.snapshot();f.entry.mode='float';f.entry.rect={left:900,top:22,width:300,height:250};f.w.slots=[null];f.w.restore(saved);assert.equal(f.entry.mode,'dock');assert.equal(f.entry.rect.left,0);assert.deepEqual([...f.w.slots],['ai']);});

test('snap planning previews occupancy without moving other panels',()=>{const f=fixture();f.owner.panel.hidden=false;const plan=f.w.snapPlan('library',1,0);assert.deepEqual([...plan.next],['library']);assert.deepEqual([...plan.displaced],['ai']);assert.equal(f.entry.mode,'dock');assert.deepEqual(f.w.slots,['ai']);const split=f.w.snapPlan('library',2,1);assert.deepEqual([...split.next],['ai','library']);assert.equal(split.displaced.length,0);});
test('detached panel follows original grip even if initial floating rectangle was clamped',()=>{const f=fixture();f.owner.panel.style={};f.w.bounds=()=>({left:8,top:8,right:1312,bottom:830});f.w.previewAt=()=>{};f.w.drag={active:true,entry:f.entry,base:{left:680,top:80,width:630,height:500},x:935,y:99,px:380,py:145,grabX:112,grabY:19};f.w.paint();assert.equal(f.w.drag.next.left,268);assert.equal(f.w.drag.next.top,126);assert.equal(f.owner.panel.style.transform,'translate3d(-412px,46px,0)');});

test('terminal toolbar drop uses its own floating lifecycle without occupying a right dock slot',async()=>{
 const f=fixture(),calls=[];f.w.toolbar={terminal:{openFloatingAt:async(x,y)=>calls.push([x,y])}};f.w.ensure=()=>{throw Error('terminal must not use note panel registration');};
 f.w.openDrop('terminal',520,280,null);await Promise.resolve();assert.deepEqual(calls,[[520,280]]);assert.deepEqual(f.w.slots,['ai']);assert.equal(f.entry.mode,'dock');assert.deepEqual(f.events,[]);
});
test('failed terminal opening is reported without changing existing document panels',async()=>{
 const f=fixture(),errors=[];f.w.toolbar={terminal:{openFloatingAt:async()=>{throw Error('terminal start failed');}}};f.w.reportMotionError=e=>errors.push(e.message);
 f.w.openDrop('terminal',520,280,null);await Promise.resolve();assert.deepEqual(errors,['terminal start failed']);assert.deepEqual(f.w.slots,['ai']);assert.equal(f.entry.mode,'dock');
});


test('live sidebar and dock resizing suppress queued full layouts, then release resumes scheduling',()=>{
 const frames=[];const W=vm.runInNewContext(source+';EditingToolbarPanelWorkspace',{requestAnimationFrame:fn=>{frames.push(fn);return frames.length;}});
 const w=Object.create(W.prototype);w.toolbar={sidebarMotion:{drag:null},splitView:{enabled:false}};let layouts=0;w.layout=()=>layouts++;
 for(const side of ['left','right']){w.drag=side==='right'?{active:true,divider:'width'}:null;w.toolbar.sidebarMotion.drag=side==='left'?{}:null;for(let i=0;i<50;i++)w.scheduleLayout();assert.equal(frames.length,0);}
 w.drag=null;w.toolbar.sidebarMotion.drag=null;w.scheduleLayout();w.scheduleLayout();assert.equal(frames.length,1);frames.shift()();assert.equal(layouts,1);
 w.drag={active:true,divider:'width'};w.toolbar.splitView.enabled=true;w.scheduleLayout();assert.equal(frames.length,1,'split preview retains live layout');
});
