// Explicitly registered source excerpts; normal formatting never creates a record.
class EditingToolbarManualMarks extends EditingToolbarAnnotations {
    get isManualMark(){return true;}
    _validate(data){
        super._validate(data);
        for(const n of data.notes){
            if(!n.anchor.exact||n.anchor.exact.length>200000||!Number.isInteger(n.anchor.start)||!Number.isInteger(n.anchor.end)||n.anchor.start<0||n.anchor.end<=n.anchor.start)throw Error('标注位置不完整');
            if(n.runs!==undefined&&(!Array.isArray(n.runs)||n.runs.length>20000||n.runs.some(r=>typeof r.text!=='string'||!r.styles||typeof r.styles!=='object')))throw Error('标注格式不完整');
        }return data;
    }
    _createPanel(){
        this.draftDir=this.path.join(File.option.userDataPath,'editing-toolbar-mark-drafts');this.expanded=new Set();this.expandedGroups=new Set();this.query='';this.filter='all';
        const p=document.createElement('aside');p.id='et-manual-mark-panel';p.hidden=true;p.setAttribute('aria-label','标注');
        p.innerHTML=`<div class="et-note-resize" role="separator" aria-label="调整标注面板宽度" tabindex="0"></div>
          <header><div><strong>标注</strong><span class="et-note-count"></span></div><button data-mark="close" aria-label="关闭标注面板">${this._noteIcon('close')}</button></header>
          <div class="et-panel-scroll-body" role="region" aria-label="标注内容" tabindex="0"><div class="et-mark-tools" hidden><input type="search" placeholder="搜索标注内容" aria-label="搜索标注"><div class="et-mark-filter"><label>格式 <select aria-label="按格式筛选"><option value="all">全部格式</option><option value="highlight">高亮</option><option value="color">字体颜色</option><option value="backgroundColor">背景颜色</option><option value="bold">加粗</option><option value="italic">斜体</option><option value="underline">下划线</option><option value="strike">删除线</option><option value="plain">普通摘录</option></select></label><div class="et-mark-navigation"><span class="et-mark-position" role="status" aria-live="polite" aria-atomic="true" aria-label="当前筛选结果中的位置"></span><button data-mark="prev" aria-label="上一处标注">↑</button><button data-mark="next" aria-label="下一处标注">↓</button></div></div></div>
          <div class="et-mark-list" aria-label="当前文档的标注"></div><div class="et-note-empty">选中文字，点击选区工具栏或右键菜单的「加入标注」。</div>
          </div><footer><span class="et-note-status" role="status" aria-live="polite"></span><button data-mark="undo" hidden>撤销移除</button></footer>`;
        document.body.append(p);this.panel=p;this.width=Number(localStorage.getItem('et-manual-mark-width'))||330;
        const handle=p.querySelector('.et-note-resize');
        handle.onpointerdown=e=>{if(e.button)return;e.preventDefault();this.resizing=true;this.resizeViewport=document.documentElement.clientWidth;this.resizeOffset=p.getBoundingClientRect().left-e.clientX;handle.setPointerCapture(e.pointerId);document.body.classList.add('et-note-resizing');};
        handle.onpointermove=e=>{if(this.resizing)this._width(this.resizeViewport-e.clientX-this.resizeOffset,false);};
        for(const event of ['pointerup','pointercancel','lostpointercapture'])handle.addEventListener(event,()=>this._finishResize());
        handle.onkeydown=e=>{if(['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();this._width(this.width+(e.key==='ArrowLeft'?20:-20));}};
        p.addEventListener('mousedown',e=>{this.toolbar.hide();if(e.target.closest('[data-rebind]')){this.toolbar._saveSelection();e.preventDefault();}e.stopPropagation();});
        for(const event of ['keydown','keyup','keypress','beforeinput','paste','copy','cut','drop','dragover','input','click','mouseup','contextmenu'])p.addEventListener(event,e=>e.stopPropagation());
        p.querySelector('[data-mark=close]').onclick=()=>this.close();
        p.querySelector('[data-mark=undo]').onclick=()=>this._undoRemove();
        p.querySelector('[data-mark=prev]').onclick=()=>this._step(-1);p.querySelector('[data-mark=next]').onclick=()=>this._step(1);
        p.querySelector('.et-mark-list').addEventListener('keydown',e=>{
            if(!['ArrowUp','ArrowDown'].includes(e.key)||e.altKey||e.ctrlKey||e.metaKey||e.shiftKey||e.isComposing||e.keyCode===229||!e.target.closest('.et-mark-item'))return;
            e.preventDefault();e.stopPropagation();this._step(e.key==='ArrowUp'?-1:1,true);
        });
        p.querySelector('input').oninput=e=>{this.query=e.target.value;this._cancelDelete();this._renderList();};
        p.querySelector('select').onchange=e=>{this.filter=e.target.value;this._cancelDelete();this._renderList();};
        this._layout();
    }
    _width(value,persist=true){if(!Number.isFinite(value))return;this.width=Math.round(Math.max(280,Math.min(720,value)));this._layout();if(persist)localStorage.setItem('et-manual-mark-width',this.width);}
    _layout(){if(this.toolbar.panelWorkspace?.layoutOwner(this))return;const width=Math.min(this.width,Math.max(280,document.documentElement.clientWidth-340));this.panel.style.width=width+'px';if(!this.panel.hidden)document.documentElement.style.setProperty('--et-note-width',width+'px');if(!this.resizing)this.toolbar._applyTopPlacement();}
    _finishResize(){if(!this.resizing)return;this.resizing=false;localStorage.setItem('et-manual-mark-width',this.width);document.body.classList.remove('et-note-resizing');this._layout();}
    _flushEditor(){}
    _showSelected(){}
    _updateQuote(){}
    _status(text,error=false){super._status(String(text).replace(/注释/g,'标注'),error);}
    _export(ctx){return '# 手动标注\n\n> 此文件由工具栏生成；请在「标注」中管理。\n\n'+ctx.notes.map((n,i)=>'## '+(i+1)+'. '+(n.title||'正文')+'\n\n'+n.anchor.exact.split('\n').map(t=>'> '+t).join('\n')+'\n').join('\n');}
    _switchDocument(){const previous=this.ctx;super._switchDocument();if(previous!==this.ctx){this._cancelDelete();this.removed=null;this.expanded.clear();this.expandedGroups.clear();this.query='';this.filter='all';this.panel.querySelector('input').value='';this.panel.querySelector('select').value='all';CSS.highlights?.delete('et-manual-mark-active');this._renderList();}}
    open(){this._switchDocument();if(this.panel.hidden)this.expandedGroups.clear();this.panel.hidden=false;if(!this.toolbar.panelWorkspace)document.body.classList.add('et-annotations-open');this.toolbar.hide();this._layout();this._scan();this._renderList();if(this.ctx.readonly)this._status(this.ctx.error,true);}
    close(){if(this.panel.hidden)return;this._finishResize();this._save();this.panel.hidden=true;this._cancelDelete();CSS.highlights?.delete('et-manual-mark-active');document.body.classList.remove('et-annotations-open');this.toolbar._applyTopPlacement();}
    _index(){
        const write=document.getElementById('write'),segments=[];let text='',lastBlock=null;if(!write)return{text,segments};
        const walk=document.createTreeWalker(write,4);let node;
        while(node=walk.nextNode()){
            const el=node.parentElement;if(!el||el.closest('.md-meta,.md-content,mjx-container,.MathJax,.CodeMirror,.md-fences,.md-math-block,.md-htmlblock,.md-math-after-sym,script,style,[md-inline="alert_text"]'))continue;
            const block=el.closest('p,h1,h2,h3,h4,h5,h6,td,th,li');if(!block||!write.contains(block))continue;
            const value=node.textContent.replace(/\u00a0/g,' ');if(!value)continue;if(lastBlock&&block!==lastBlock)text+='\n\n';lastBlock=block;
            segments.push({node,block,start:text.length,end:text.length+value.length});text+=value;
        }return{text,segments};
    }
    _styles(node){
        const s={};for(let e=node.parentElement;e&&e.id!=='write';e=e.parentElement){
            const tag=e.tagName,st=e.style;if(['STRONG','B'].includes(tag)||st.fontWeight==='bold'||Number(st.fontWeight)>=600)s.bold=true;
            if(['EM','I'].includes(tag)||st.fontStyle==='italic')s.italic=true;
            if(tag==='U'||st.textDecorationLine.includes('underline'))s.underline=true;
            if(['S','DEL','STRIKE'].includes(tag)||st.textDecorationLine.includes('line-through'))s.strike=true;
            if(tag==='MARK')s.highlight=true;
            if(!s.color&&st.color)s.color=st.color;
            if(!s.backgroundColor&&st.backgroundColor&&st.backgroundColor!=='transparent')s.backgroundColor=st.backgroundColor;
            if(e.matches('p,h1,h2,h3,h4,h5,h6,td,th,li'))break;
        }return s;
    }
    _rich(idx,start,end){
        const runs=[];let at=start;for(const seg of idx.segments){if(seg.end<=start||seg.start>=end)continue;const a=Math.max(start,seg.start),b=Math.min(end,seg.end);
            if(a>at)runs.push({text:idx.text.slice(at,a),styles:{}});
            const text=idx.text.slice(a,b),styles=this._styles(seg.node),last=runs.at(-1);
            if(last&&JSON.stringify(last.styles)===JSON.stringify(styles))last.text+=text;else runs.push({text,styles});at=b;
        }
        const first=idx.segments.find(s=>s.end>start),block=first?.block;let title='正文';
        if(block)for(const h of document.querySelectorAll('#write h1,#write h2,#write h3,#write h4,#write h5,#write h6')){if(h===block||h.compareDocumentPosition(block)&Node.DOCUMENT_POSITION_FOLLOWING)title=h.textContent.replace(/^#+\s*/, '').slice(0,120);else break;}
        return{runs,title};
    }
    _capture(){const anchor=super._capture();if(anchor&&anchor.exact.length>200000){this._status('请分段加入较长的摘录。',true);return null;}return anchor;}
    _occurrences(text,exact){let count=0,at=-1;if(!exact)return 0;while((at=text.indexOf(exact,at+1))>=0&&count<1001)count++;return count;}
    _anchor(text,start,end){const anchor=super._anchor(text,start,end);anchor.occurrences=this._occurrences(text,anchor.exact);return anchor;}
    addSelection(anchor){
        this._switchDocument();anchor=anchor||this._capture();if(!anchor){this.open();this._status('请先选中正文中的文字，再点击「加入标注」。');return;}
        this.open();if(this.ctx.readonly){this._status(this.ctx.error,true);return;}
        const idx=this._index();if(anchor.hash!==this._hash(idx.text)){this._status('选区已改变，请重新选择文字。',true);return;}
        this._scan();const duplicate=this.ctx.notes.find(n=>{const p=this.locations.get(n.id);return p?.start===anchor.start&&p.end===anchor.end;});
        if(duplicate){this._locateId(duplicate.id);this._status('这段文字已加入标注。');return;}
        const now=new Date().toISOString(),n={id:this._id(),anchor,original:structuredClone(anchor),markdown:'',...this._rich(idx,anchor.start,anchor.end),created:now,updated:now};
        this.ctx.notes.push(n);this.ctx.selected=n.id;this.query='';this.filter='all';this.panel.querySelector('input').value='';this.panel.querySelector('select').value='all';this._cancelDelete();this._touch();this._scan();this._renderList();this._reveal(n.id);this._status('已加入标注');
    }
    _safeResolve(anchor,text,hash){
        const p=super._resolve(anchor,text,hash);if(!p)return null;if(anchor.hash===hash)return p;
        if(anchor.occurrences>1&&anchor.occurrences!==this._occurrences(text,anchor.exact))return null;
        // After a cold reopen, a sole identical phrase may be a different occurrence.
        return (p.score||0)>=Math.min(8,(anchor.prefix||'').length+(anchor.suffix||'').length)&&((anchor.prefix||'').length+(anchor.suffix||'').length>0)?p:null;
    }
    _scan(){
        if(!this.ctx||this.savingAs||this._loading()||File.editor?.isIME)return;
        if(File.editor?.sourceView?.inSourceMode){CSS.highlights?.delete('et-manual-mark-active');return;}
        if(!this.ctx.notes.length){this.index=null;this.lastText=null;this.locations.clear();CSS.highlights?.delete('et-manual-mark-active');return;}
        const idx=this._index(),hash=this._hash(idx.text),old=this.lastText,previous=this.locations,next=new Map();let prefix=0,oe=old?.length||0,ne=idx.text.length,dirty=false,changed=false;
        if(typeof old==='string'&&old!==idx.text){while(prefix<oe&&prefix<ne&&old[prefix]===idx.text[prefix])prefix++;while(oe>prefix&&ne>prefix&&old[oe-1]===idx.text[ne-1]){oe--;ne--;}}
        for(const n of this.ctx.notes){
            const prior=previous.get(n.id);let pos=null,removed=false,live=null;
            if(prior&&old!==idx.text){const r=prior.range,a=idx.segments.find(s=>s.node===r.startContainer),b=idx.segments.find(s=>s.node===r.endContainer);
                if(a&&b){const start=a.start+r.startOffset,end=b.start+r.endOffset;if(end>start&&idx.text.slice(start,end)===n.anchor.exact)live={start,end};}
            }
            if(live)pos=live;
            else if(prior&&typeof old==='string'&&old!==idx.text){const delta=ne-oe;
                if(prior.end<=prefix)pos={start:prior.start,end:prior.end};
                else if(prior.start>=oe)pos={start:prior.start+delta,end:prior.end+delta};
                else if(prefix>=prior.start&&oe<=prior.end&&!(prefix===prior.start&&oe===prior.end))pos={start:prior.start,end:prior.end+delta};
                else removed=true;
                if(this._occurrences(old,n.anchor.exact)>1&&this._occurrences(old,n.anchor.exact)!==this._occurrences(idx.text,n.anchor.exact)){pos=null;removed=true;}
            }else if(prior&&old===idx.text)pos={start:prior.start,end:prior.end};
            if(!pos&&!removed&&(!n.pending||n.anchor.hash===hash))pos=this._safeResolve(n.anchor,idx.text,hash);
            if(pos&&pos.end>pos.start&&idx.text.slice(pos.start,pos.end).trim()){
                const range=this._range(idx,pos.start,pos.end);if(range){next.set(n.id,{...pos,range});
                    const rich=this._rich(idx,pos.start,pos.end),anchor=this._anchor(idx.text,pos.start,pos.end);
                    if(!this.ctx.readonly&&(JSON.stringify(n.anchor)!==JSON.stringify(anchor)||JSON.stringify(n.runs)!==JSON.stringify(rich.runs)||n.title!==rich.title||n.pending)){
                        n.original??=structuredClone(n.anchor);n.anchor=anchor;n.runs=rich.runs;n.title=rich.title;delete n.pending;n.updated=new Date().toISOString();dirty=true;
                    }
                }
            }
            if(!next.has(n.id)&&!this.ctx.readonly&&!n.pending){n.pending=true;dirty=true;}
            if(Boolean(prior)!==next.has(n.id))changed=true;
        }
        this.index=idx;this.locations=next;this.lastText=idx.text;
        if(dirty)this._touch();if(dirty||changed)this._renderList();
    }
    _formats(n){const keys=new Set((n.runs||[]).flatMap(r=>Object.keys(r.styles).filter(k=>r.styles[k])));return keys.size?[...keys]:['plain'];}
    _visible(){const q=this.query.toLocaleLowerCase();return (this.ctx?.notes||[]).filter(n=>(!q||(n.anchor.exact+' '+n.title).toLocaleLowerCase().includes(q))&&(this.filter==='all'||this._formats(n).includes(this.filter))).sort((a,b)=>Number(!this.locations.has(a.id))-Number(!this.locations.has(b.id))||(this.locations.get(a.id)?.start??a.anchor.start)-(this.locations.get(b.id)?.start??b.anchor.start));}
    _groups(items){
        // Use actual heading identity, not its label: two chapters may share a name.
        const headings=[...document.querySelectorAll('#write h1,#write h2,#write h3,#write h4,#write h5,#write h6')],groups=new Map();
        for(const n of items){
            const hit=this.locations.get(n.id),block=hit?.range.startContainer;let key=hit?'body':'pending',title=hit?'正文':'原文待定位';
            if(block)for(let i=0;i<headings.length;i++){const h=headings[i];if(h.contains(block)||h.compareDocumentPosition(block)&Node.DOCUMENT_POSITION_FOLLOWING){key='heading:'+(h.getAttribute('cid')||i);title=h.textContent.replace(/^#+\s*/,'').trim()||'未命名章节';}else break;}
            if(!groups.has(key))groups.set(key,{key,title,notes:[]});groups.get(key).notes.push(n);
        }return [...groups.values()];
    }
    _measureExcerpts(){
        for(const row of this.panel.querySelectorAll('.et-mark-item')){if(row.closest('[hidden]'))continue;const t=row.querySelector('.et-mark-text');row.querySelector('.et-mark-expand').hidden=!row.classList.contains('expanded')&&t.scrollHeight<=t.clientHeight+1;}
    }
    _copyId(id){
        this._cancelDelete();this._scan();const n=this.ctx?.notes.find(n=>n.id===id);if(!n)return;
        const group=this._groups([n])[0],title=this.locations.has(id)?group.title:(n.title||'正文'),root=document.createElement('div'),heading=document.createElement('h3'),body=document.createElement('div');
        heading.textContent=title;body.style.whiteSpace='pre-wrap';
        const preview=this.panel.querySelector('[data-id="'+CSS.escape(id)+'"] .et-mark-text');
        if(preview){for(const child of preview.childNodes)body.append(child.cloneNode(true));for(const mark of body.querySelectorAll('.et-mark-highlight'))mark.style.backgroundColor='#e8ce6a66';}
        else body.textContent=n.anchor.exact;
        root.append(heading,body);
        try{reqnode('electron').clipboard.write({text:title+'\n\n'+n.anchor.exact,html:root.innerHTML});this._status('已复制章节名和完整摘录');}
        catch(error){this._status('复制失败，请重试。',true);}
    }
    _renderList(){
        if(!this.ctx||this.panel.hidden)return;const list=this.panel.querySelector('.et-mark-list'),top=list.scrollTop;
        // Scans and expansion rebuild the cards; retain keyboard focus only when it was in this list.
        const active=document.activeElement,focusedId=list.contains(active)?active.closest('.et-mark-item')?.dataset.id:null;
        const focusedControl=['.et-mark-excerpt','.et-mark-expand','[data-copy]','[data-remove]','[data-rebind]'].find(s=>active?.matches(s));
        const focusedGroup=active?.matches('.et-mark-group-toggle')?active.closest('.et-mark-group').dataset.group:null;
        list.replaceChildren();
        this.panel.querySelector('.et-note-count').textContent=' · '+this.ctx.notes.length+' 条';this.panel.querySelector('.et-mark-tools').hidden=!this.ctx.notes.length;
        const items=this._visible();const empty=this.panel.querySelector('.et-note-empty');empty.hidden=!!items.length;empty.textContent=this.ctx.readonly?'标注暂时无法读取，请查看下方提示。':this.ctx.notes.length?'没有符合条件的标注。':'选中文字，点击选区工具栏或右键菜单的「加入标注」。';
        const current=items.findIndex(n=>n.id===this.ctx.selected);this.panel.querySelector('.et-mark-position').textContent=(current<0?'0':'第 '+(current+1))+' / '+items.length+' 条';
        const labels={highlight:'高亮',color:'字体颜色',backgroundColor:'背景色',bold:'加粗',italic:'斜体',underline:'下划线',strike:'删除线',plain:'普通摘录'};
        for(const group of this._groups(items)){
          const section=document.createElement('section');section.className='et-mark-group';section.dataset.group=group.key;
          const toggle=document.createElement('button');toggle.className='et-mark-group-toggle';toggle.setAttribute('aria-expanded',String(this.expandedGroups.has(group.key)));toggle.title=group.title;toggle.classList.toggle('has-active',group.notes.some(n=>n.id===this.ctx.selected));
          const chevron=document.createElement('span');chevron.className='et-mark-group-chevron';chevron.textContent='›';chevron.setAttribute('aria-hidden','true');
          const name=document.createElement('span');name.className='et-mark-group-name';name.textContent=group.title;
          const count=document.createElement('span');count.className='et-mark-group-count';count.textContent=group.notes.length+' 条';toggle.append(chevron,name,count);
          const groupItems=document.createElement('div');groupItems.className='et-mark-group-items';groupItems.id='et-mark-group-'+this._hash(group.key).slice(0,12);groupItems.hidden=!this.expandedGroups.has(group.key);toggle.setAttribute('aria-controls',groupItems.id);
          toggle.onclick=()=>{this.expandedGroups.has(group.key)?this.expandedGroups.delete(group.key):this.expandedGroups.add(group.key);this._cancelDelete();this._renderList();};
          for(const n of group.notes){
            const row=document.createElement('div');row.className='et-mark-item';row.dataset.id=n.id;row.classList.toggle('active',this.ctx.selected===n.id);row.classList.toggle('expanded',this.expanded.has(n.id));
            const head=document.createElement('div');head.className='et-mark-heading';const meta=document.createElement('span');meta.className='et-mark-meta';const title=document.createElement('span');title.className='et-mark-title';title.textContent=this.locations.has(n.id)?(n.title||'正文'):'原文待定位';title.title=title.textContent;meta.append(title);head.append(meta);
            const copy=document.createElement('button');copy.dataset.copy=n.id;copy.title='复制摘录和章节名';copy.setAttribute('aria-label',copy.title);copy.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M15 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h3"/></svg>';copy.onclick=()=>this._copyId(n.id);head.append(copy);
            const del=document.createElement('button');del.dataset.remove=n.id;del.disabled=!!this.ctx.readonly;del.title='移除标注，保留原文格式';del.setAttribute('aria-label','移除标注');del.innerHTML=this._noteIcon('close');del.onclick=()=>this._remove(n.id);head.append(del);
            const excerpt=document.createElement('button');excerpt.className='et-mark-excerpt';excerpt.setAttribute('aria-label','定位原文：'+n.anchor.exact.slice(0,70));excerpt.setAttribute('aria-keyshortcuts','ArrowUp ArrowDown');excerpt.onclick=()=>this._locateId(n.id,true);
            const text=document.createElement('span');text.className='et-mark-text';
            for(const r of n.runs?.length?n.runs:[{text:n.anchor.exact,styles:{}}]){const span=document.createElement('span');span.textContent=r.text;const s=r.styles;
                if(s.bold)span.style.fontWeight='700';if(s.italic)span.style.fontStyle='italic';if(s.underline||s.strike)span.style.textDecoration=[s.underline?'underline':'',s.strike?'line-through':''].filter(Boolean).join(' ');
                if(typeof s.color==='string'&&CSS.supports('color',s.color))span.style.color=s.color;
                if(typeof s.backgroundColor==='string'&&CSS.supports('background-color',s.backgroundColor))span.style.backgroundColor=s.backgroundColor;else if(s.highlight)span.className='et-mark-highlight';text.append(span);
            }excerpt.append(text);const bottom=document.createElement('div');bottom.className='et-mark-bottom';const tags=document.createElement('span');tags.className='et-mark-tags';
            for(const format of this._formats(n)){if(!labels[format])continue;const tag=document.createElement('small');tag.textContent=labels[format];tags.append(tag);}meta.append(tags);
            const expand=document.createElement('button');expand.className='et-mark-expand';expand.textContent=this.expanded.has(n.id)?'收起':'… 展开';expand.setAttribute('aria-expanded',String(this.expanded.has(n.id)));expand.onclick=()=>{this.expanded.has(n.id)?this.expanded.delete(n.id):this.expanded.add(n.id);this._cancelDelete();this._renderList();};bottom.append(expand);
            if(!this.locations.has(n.id)){const rebind=document.createElement('button');rebind.dataset.rebind=n.id;rebind.textContent='重新关联';rebind.disabled=!!this.ctx.readonly;rebind.onclick=()=>this._rebind(n.id);bottom.append(rebind);}
            row.append(head,excerpt,bottom);groupItems.append(row);
          }
          section.append(toggle,groupItems);list.append(section);
        }
        list.scrollTop=top;this.panel.querySelector('[data-mark=undo]').hidden=!this.removed||this.removed.key!==this.ctx.key;this.panel.querySelector('[data-mark=undo]').disabled=!!this.ctx.readonly;
        for(const b of this.panel.querySelectorAll('[data-mark=prev],[data-mark=next]'))b.disabled=!items.some(n=>this.locations.has(n.id));
        requestAnimationFrame(()=>this._measureExcerpts());
        if(this.deleting)this._paintDelete();
        if(focusedId&&focusedControl)list.querySelector('[data-id="'+CSS.escape(focusedId)+'"] '+focusedControl)?.focus({preventScroll:true});
        else if(focusedGroup)list.querySelector('[data-group="'+CSS.escape(focusedGroup)+'"] .et-mark-group-toggle')?.focus({preventScroll:true});
    }
    _reveal(id){const row=this.panel.querySelector('[data-id="'+CSS.escape(id)+'"]');if(!row)return;const group=row.closest('.et-mark-group');if(group){this.expandedGroups.add(group.dataset.group);group.querySelector('.et-mark-group-items').hidden=false;group.querySelector('.et-mark-group-toggle').setAttribute('aria-expanded','true');}this._measureExcerpts();row.scrollIntoView({block:'nearest'});}
    _locateId(id,focus=false){
        if(File.editor?.sourceView?.inSourceMode){this._status('请退出源代码模式后定位原文。');return;}
        this._cancelDelete();this._scan();const hit=this.locations.get(id);this.ctx.selected=id;this._renderList();this._reveal(id);
        if(focus)this.panel.querySelector('[data-id="'+CSS.escape(id)+'"] .et-mark-excerpt')?.focus({preventScroll:true});
        if(!hit){this._status('原文已改变或无法唯一定位；选中新原文后点击「重新关联」。',true);return;}
        this.toolbar.hide();const node=hit.range.startContainer.parentElement;node.scrollIntoView({block:'center',behavior:'smooth'});
        clearTimeout(this.flashTimer);if(CSS.highlights&&window.Highlight){CSS.highlights.set('et-manual-mark-active',new Highlight(hit.range));this.flashTimer=setTimeout(()=>CSS.highlights.delete('et-manual-mark-active'),2000);}
        this._status('已定位原文');
    }
    _step(direction,focus=false){const items=this._visible().filter(n=>this.locations.has(n.id));if(!items.length)return;const i=items.findIndex(n=>n.id===this.ctx.selected),next=i<0?(direction<0?items.length-1:0):(i+direction+items.length)%items.length;this._locateId(items[next].id,focus);}
    _cancelDelete(){clearTimeout(this.deleteTimer);this.deleting=null;this.panel?.querySelectorAll('[data-remove]').forEach(b=>{b.classList.remove('confirm');b.innerHTML=this._noteIcon('close');b.setAttribute('aria-label','移除标注');});}
    _paintDelete(){const b=this.panel.querySelector('[data-remove="'+CSS.escape(this.deleting)+'"]');if(b){b.classList.add('confirm');b.innerHTML=this._noteIcon('check');b.setAttribute('aria-label','确认移除标注');}}
    _remove(id){if(this.ctx.readonly)return;if(this.deleting!==id){this._cancelDelete();this.deleting=id;this._paintDelete();this.deleteTimer=setTimeout(()=>this._cancelDelete(),10000);return;}
        const note=this.ctx.notes.find(n=>n.id===id);if(!note)return;this.removed={key:this.ctx.key,note:structuredClone(note)};this.ctx.notes=this.ctx.notes.filter(n=>n.id!==id);this.locations.delete(id);if(this.ctx.selected===id)this.ctx.selected=null;this._cancelDelete();this._touch();this._renderList();this._save();this._status('已移除标注，原文和格式保留。');
    }
    _undoRemove(){if(this.ctx.readonly||this.removed?.key!==this.ctx.key)return;const n=this.removed.note;if(!this.ctx.notes.some(m=>m.id===n.id))this.ctx.notes.push(n);this.ctx.selected=n.id;this.removed=null;this._touch();this._scan();this._renderList();this._save();}
    _rebind(id){const anchor=this._capture(),n=this.ctx.notes.find(n=>n.id===id);if(!anchor||!n||this.ctx.readonly){this._status('请先选中新原文，再点击「重新关联」。');return;}n.anchor=anchor;delete n.pending;this.locations.delete(id);this._touch();this._scan();this.ctx.selected=id;this._renderList();this._status('已重新关联原文');}
    _mergeNotes(base,local,remote){
        const b=new Map(base.map(n=>[n.id,n])),l=new Map(local.map(n=>[n.id,n])),r=new Map(remote.map(n=>[n.id,n])),out=[];
        const same=(a,c)=>JSON.stringify(a)===JSON.stringify(c);for(const id of new Set([...l.keys(),...r.keys(),...b.keys()])){const before=b.get(id),left=l.get(id),right=r.get(id);
            if(same(left,right)||same(right,before)){if(left)out.push(left);}else if(same(left,before)){if(right)out.push(right);}else if(!left){if(right)out.push(right);}else if(!right)out.push(left);else{out.push(left);if(!same(left.anchor,right.anchor)||!same(left.runs,right.runs))out.push({...right,id:this._id()});}
        }return out;
    }
    _bind(){
        const write=document.getElementById('write');const schedule=()=>{clearTimeout(this.scanTimer);this.scanTimer=setTimeout(()=>{this._switchDocument();this._scan();},220);};
        this.observer=new MutationObserver(schedule);this.observer.observe(write,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['style']});
        this.poll=setInterval(()=>{this._switchDocument();if(this.ctx?.dirty&&Date.now()-(this.lastRetry||0)>3000){this.lastRetry=Date.now();this._save();}},700);
        window.addEventListener('beforeunload',()=>this._save());window.addEventListener('blur',()=>{this._finishResize();this._save();});window.addEventListener('resize',()=>this._layout());
        document.addEventListener('pointerdown',e=>{if(this.deleting&&e.target.closest?.('[data-remove]')?.dataset.remove!==this.deleting)this._cancelDelete();},true);
        const original=File.saveAsUseNode,manager=this;const saveAs=async function(...args){const previous=manager.ctx;manager.savingAs=true;try{const result=await original.apply(this,args);if(!(result instanceof Error))manager._afterSaveAs(previous);else if(previous)manager._draft(previous);return result;}finally{manager.savingAs=false;manager._switchDocument();manager._scan();manager._renderList();}};
        File.saveAsUseNode=saveAs;if(File.FileSave?.saveAsUseNode===original)File.FileSave.saveAsUseNode=saveAs;
        const menu=document.getElementById('context-menu');if(menu){
            const li=document.createElement('li');li.className='et-mark-context';li.hidden=true;const b=document.createElement('a');b.setAttribute('role','menuitem');b.textContent='加入标注';li.append(b);menu.prepend(li);
            li.addEventListener('mousedown',e=>{e.preventDefault();e.stopPropagation();});li.addEventListener('click',e=>{e.preventDefault();e.stopImmediatePropagation();menu.classList.remove('show');if(this.contextAnchor&&this.contextKey===this._key())this.addSelection(this.contextAnchor);});
            document.addEventListener('contextmenu',e=>{this.contextAnchor=null;li.hidden=true;if(!write.contains(e.target))return;const sel=getSelection(),r=this.toolbar._resolveRange(sel);if(!r||r.collapsed||!this.toolbar._selectionInEditor(r))return;this.contextAnchor=this._capture();this.contextKey=this._key();li.hidden=!this.contextAnchor;},true);
        }
    }
}

