'use strict';
const Store=require('./feature-module-store.cjs'),Packages=require('./ai-plugin-packages.cjs'),runner=require('./toolbar-update-runner.cjs');
const repository='https://github.com/xiaozhi0507/typora-editing-toolbar';
class ToolbarUpdater {
 constructor(req,root,{fetch,currentVersion=Store.hostVersion,typoraDir,spawn}={}){this.req=req;this.path=req('path');this.fs=req('fs').promises;this.crypto=req('crypto');this.Buffer=req('buffer').Buffer;this.root=this.path.resolve(root);this.currentVersion=currentVersion;this.typoraDir=typoraDir||this.path.dirname(req('process').resourcesPath||'');this.transport=new Store(req,this.root);this.fetch=fetch||this.transport.download.bind(this.transport);this.packages=new Packages(req,{});this.spawn=spawn||req('child_process').spawn;}
 static repository=repository;
 static releasesURL='https://api.github.com/repos/xiaozhi0507/typora-editing-toolbar/releases?per_page=100';
 static currentNotes="移除独立拖柄和固定按钮，直接拖动工具条空白处即可浮动。\n靠近顶部松开后吸附固定；保留 Esc 取消和位置保存。";
 static summary(value){const source=String(value||'').replace(/\r/g,'');const section=source.match(/(?:^|\n)## 更新内容\n([\s\S]*?)(?=\n## |$)/);return (section?section[1]:source).split(/\n\s*\n/).filter(p=>!/(?:SHA-?256|校验|\d+\s*项.*测试|install\.cmd|主包与 AI 模块独立|最低工具栏|本次未覆盖)/i.test(p)).flatMap(p=>p.split('\n')).map(s=>s.replace(/^\s*(?:[-*#]+|\d+\.)\s*/,'').trim()).filter(Boolean).slice(0,6).map(s=>s.slice(0,220)).join('\n');}
 static notes(state){const latest=state.latest;if(latest&&Store.compare(latest.version,state.currentVersion)>=0)return {version:latest.version,text:this.summary(latest.notes)};return {version:state.currentVersion,text:this.currentNotes};}
 hash(bytes){return this.crypto.createHash('sha256').update(bytes).digest('hex');}
 static release(row){if(!row||row.draft||row.prerelease||!/^toolbar-v\d+\.\d+\.\d+$/.test(row.tag_name))return null;const version=row.tag_name.slice(9);Store.compare(version,version);const matches=(row.assets||[]).filter(a=>new RegExp('^typora-editing-toolbar-\\d{4}-\\d{2}-\\d{2}-v'+version.replaceAll('.','\\.')+'\\.zip$').test(a.name));if(matches.length!==1)return null;const a=matches[0],url=repository+'/releases/download/'+row.tag_name+'/'+a.name;if(a.browser_download_url!==url||!Number.isSafeInteger(a.size)||a.size<1||a.size>100*1024**2)return null;const digest=/^sha256:([a-f0-9]{64})$/i.exec(a.digest||'')?.[1]?.toLowerCase();const checksum=(row.assets||[]).find(r=>r.name===a.name+'.sha256'&&r.browser_download_url===url+'.sha256');if(!digest&&!checksum)return null;return {version,name:a.name,url,size:a.size,sha256:digest||'',checksumURL:checksum?url+'.sha256':'',page:repository+'/releases/tag/'+row.tag_name,notes:String(row.body||'').slice(0,5000)};}
 validateRelease(r){if(!r)return null;const tag='toolbar-v'+r.version,row=ToolbarUpdater.release({tag_name:tag,assets:[{name:r.name,size:r.size,browser_download_url:r.url,digest:'sha256:'+r.sha256}],body:r.notes});if(!row)throw Error('更新信息无效，请重新检查');return row;}
 owned(key){if(!/^[a-f0-9-]{36}$/.test(key))throw Error('更新任务目录无效');return this.path.join(this.root,'jobs',key);}
 async read(name,fallback=null){try{return JSON.parse((await this.fs.readFile(this.path.join(this.root,name),'utf8')).replace(/^\uFEFF/,''));}catch(e){if(e.code==='ENOENT')return fallback;throw Error('更新记录无法读取，原文件已保留');}}
 async write(name,value){await this.transport.write(this.path.join(this.root,name),JSON.stringify(value,null,2));}
 async lock(fn){await this.fs.mkdir(this.root,{recursive:true});const file=this.path.join(this.root,'update.lock');let handle;for(let attempt=0;attempt<2;attempt++){try{handle=await this.fs.open(file,'wx');break;}catch(e){if(e.code!=='EEXIST')throw e;const owner=await this.read('update.lock');let dead=false;try{this.req('process').kill(owner.pid,0);}catch(err){dead=err.code==='ESRCH';}if(attempt||!dead)throw Error('其他窗口正在处理工具栏更新');await this.fs.unlink(file);}}try{await handle.writeFile(JSON.stringify({pid:this.req('process').pid}));return await fn();}finally{await handle.close();await this.fs.unlink(file).catch(()=>{});}}
 async state(){const s=await this.read('state.json',{});if(s.latest)s.latest=this.validateRelease(s.latest);let task=null;if(s.stage&&Store.compare(s.stage.version,this.currentVersion)<=0)s.stage=null;if(s.stage){const dir=this.owned(s.stage.key);try{task=JSON.parse((await this.fs.readFile(this.path.join(dir,'status.json'),'utf8')).replace(/^\uFEFF/,''));if(['queued','waiting','installing'].includes(task.state)){try{if(task.state==='queued'){if(Date.now()-Date.parse(task.time)>30000)task={...task,state:'failed',message:'安装任务未能启动，请重试'};}else this.req('process').kill(task.pid,0);}catch(e){if(e.code==='ESRCH')task={...task,state:'failed',message:'更新任务已中断，请重新安排安装'};}}}catch(e){if(e.code!=='ENOENT')throw e;}}return {...s,task,currentVersion:this.currentVersion,available:!!s.latest&&Store.compare(s.latest.version,this.currentVersion)>0};}
 async check(){if(this.checking)return this.checking;this.checking=this.lock(async()=>{const s=await this.read('state.json',{});try{const data=JSON.parse((await this.fetch(ToolbarUpdater.releasesURL,{limit:4*1024**2})).toString('utf8'));if(!Array.isArray(data))throw Error('GitHub 版本信息无效');const latest=data.map(ToolbarUpdater.release).filter(Boolean).sort((a,b)=>Store.compare(b.version,a.version))[0];if(!latest)throw Error('尚未发布可校验的工具栏安装包');if(!latest.sha256){const sum=(await this.fetch(latest.checksumURL,{limit:4096})).toString('utf8').trim();const match=/^([a-f0-9]{64})\s+\*?([^\r\n]+)$/i.exec(sum);if(!match||match[2]!==latest.name)throw Error('版本校验文件无效');latest.sha256=match[1].toLowerCase();}await this.write('state.json',{...s,latest,checkedAt:new Date().toISOString(),error:''});}catch(e){await this.write('state.json',{...s,error:e.message});}return this.state();}).finally(()=>{this.checking=null;});return this.checking;}
 verifyFiles(files){const raw=files.get('files/metadata/package-manifest.json');if(!raw||raw.length>2*1024**2)throw Error('安装包缺少有效清单');const m=JSON.parse(raw.toString('utf8').replace(/^\uFEFF/,''));if(m.name!=='Typora Editing Toolbar'||m.platform!=='Windows'||!Array.isArray(m.files)||m.files.length!==files.size-1)throw Error('不是完整的 Windows 工具栏安装包');const seen=new Set();for(const row of m.files){const name=Packages.safe(row.path);if(name!==row.path||seen.has(name)||name==='files/metadata/package-manifest.json'||!(/^[a-f0-9]{64}$/i.test(row.sha256)))throw Error('安装包清单路径无效');seen.add(name);const bytes=files.get(name);if(!bytes||bytes.length!==row.bytes||this.hash(bytes)!==row.sha256.toLowerCase())throw Error('安装包文件校验失败：'+name);}for(const name of ['install.cmd','files/scripts/install-typora-toolbar.ps1','files/plugin/editing-toolbar.js','files/plugin/editing-toolbar.css'])if(!seen.has(name))throw Error('安装包缺少必要文件：'+name);return [...files].map(([path,bytes])=>({path,sha256:this.hash(bytes)}));}
 async prepare(){return this.lock(async()=>{const s=await this.state();if(!s.available)throw Error('没有比当前版本更新的工具栏');if(['queued','waiting','installing'].includes(s.task?.state))throw Error('请先取消已安排的安装');const release=this.validateRelease(s.latest),bytes=await this.fetch(release.url,{limit:100*1024**2});if(bytes.length!==release.size||this.hash(bytes)!==release.sha256)throw Error('下载包 SHA-256 校验失败，未安装');const key=this.crypto.randomUUID(),dir=this.owned(key);await this.fs.mkdir(dir,{recursive:true});const zip=this.path.join(dir,'release.zip');await this.fs.writeFile(zip,bytes,{flag:'wx'});const {files}=await this.packages.read(zip),manifest=this.verifyFiles(files);for(const [name,data]of files){const file=this.path.join(dir,'package',name);await this.fs.mkdir(this.path.dirname(file),{recursive:true});await this.fs.writeFile(file,data,{flag:'wx'});}const stage={key,version:release.version,sha256:release.sha256,files:manifest};await this.write('state.json',{...await this.read('state.json',{}),stage,error:''});return this.state();});}
 async verifyStage(stage){const dir=this.owned(stage.key),zip=this.path.join(dir,'release.zip');if(this.hash(await this.fs.readFile(zip))!==stage.sha256)throw Error('下载包已变化，请重新下载');const {files}=await this.packages.read(zip);const manifest=this.verifyFiles(files);for(const row of manifest){const file=this.path.join(dir,'package',row.path),real=await this.fs.realpath(file),base=await this.fs.realpath(this.path.join(dir,'package'));if(!real.startsWith(base+this.path.sep)||this.hash(await this.fs.readFile(file))!==row.sha256)throw Error('待安装文件已变化，请重新下载');}return {dir,files:manifest};}
 async waitForRunner(dir,child,attempt,timeout=15000){
  let launchError,exitCode;
  child.once('error',error=>{launchError=error;});child.once('exit',code=>{exitCode=code;});
  const deadline=Date.now()+timeout;
  while(Date.now()<deadline){
   if(launchError)throw launchError;
   if(exitCode!==undefined&&exitCode!==0)throw Error('安装启动器异常退出，请重试（详见 launch.log）');
   const task=JSON.parse((await this.fs.readFile(this.path.join(dir,'status.json'),'utf8')).replace(/^\uFEFF/,''));
   if(task.attempt===attempt){
    if(['failed','canceled','expired'].includes(task.state))throw Error(task.message||'安装任务未能启动，请重试');
    if(exitCode===0&&['waiting','installing','complete'].includes(task.state)&&Number.isInteger(task.pid)&&task.pid!==this.req('process').pid)return;
   }
   await new Promise(resolve=>setTimeout(resolve,100));
  }
  throw Error('安装任务启动超时，已取消；Typora 将保持打开，请重试');
 }
 async queue(){return this.lock(async()=>{
  if(this.req('process').platform!=='win32')throw Error('当前更新安装仅支持 Windows');
  const s=await this.state();if(!s.stage||Store.compare(s.stage.version,this.currentVersion)<=0)throw Error('请先下载新版工具栏');
  if(['queued','waiting','installing'].includes(s.task?.state))throw Error('已经安排安装');
  const {dir,files}=await this.verifyStage(s.stage),typoraDir=await this.fs.realpath(this.typoraDir);
  for(const f of ['Typora.exe','resources/window.html'])if(!(await this.fs.stat(this.path.join(typoraDir,f))).isFile())throw Error('无法确认 Typora 安装位置');
  await this.fs.unlink(this.path.join(dir,'cancel')).catch(e=>{if(e.code!=='ENOENT')throw e;});
  const attempt=this.crypto.randomUUID(),job={version:s.stage.version,typoraDir,files,attempt};
  await this.fs.writeFile(this.path.join(dir,'job.json'),JSON.stringify(job,null,2));
  await this.fs.writeFile(this.path.join(dir,'runner.ps1'),'\uFEFF'+runner,'utf8');
  const shell=this.path.join(this.req('process').env.SystemRoot||'C:\\Windows','System32/WindowsPowerShell/v1.0/powershell.exe');
  const status={state:'queued',pid:this.req('process').pid,version:s.stage.version,attempt,time:new Date().toISOString()};
  await this.fs.writeFile(this.path.join(dir,'status.json'),JSON.stringify(status));
  const env={...this.req('process').env};for(const key of Object.keys(env))if(key.toLowerCase()==='psmodulepath')delete env[key];
  const quote=s=>"'"+s.replaceAll("'","''")+"'",encoded=this.Buffer.from('& '+quote(this.path.join(dir,'runner.ps1'))+' -Job '+quote(this.path.join(dir,'job.json'))+' -Attempt '+quote(attempt),'utf16le').toString('base64');
  const launch='try { Start-Process -FilePath '+quote(shell)+' -WindowStyle Hidden -ArgumentList '+quote('-NoProfile -ExecutionPolicy Bypass -EncodedCommand '+encoded)+' -ErrorAction Stop } catch { $_ | Out-String | Set-Content -LiteralPath '+quote(this.path.join(dir,'launch.log'))+' -Encoding UTF8; exit 1 }';
  let child;
  try{
   child=this.spawn(shell,['-NoProfile','-NonInteractive','-EncodedCommand',this.Buffer.from(launch,'utf16le').toString('base64')],{windowsHide:true,stdio:'ignore',env});
   // A spawn event only confirms the launcher exists. Typora must stay alive
   // until the independent installer acknowledges startup and the launcher exits.
   await this.waitForRunner(dir,child,attempt);child.unref();
  }catch(e){
   await this.fs.writeFile(this.path.join(dir,'cancel'),'cancel');child?.kill?.();
   await this.fs.writeFile(this.path.join(dir,'status.json'),JSON.stringify({...status,state:'failed',message:'安装任务未能启动：'+e.message}));throw e;
  }
  return {version:s.stage.version,queued:true};
 });}
 async cancel(){return this.lock(async()=>{const s=await this.state();if(s.task?.state==='installing')throw Error('正在安装，请等待完成');if(s.stage)await this.fs.writeFile(this.path.join(this.owned(s.stage.key),'cancel'),'cancel');return {canceled:true};});}
}
module.exports=ToolbarUpdater;
