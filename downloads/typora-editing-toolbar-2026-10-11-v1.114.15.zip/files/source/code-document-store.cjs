'use strict';
// Text files have their own buffer and never pass through Typora's Markdown serializer.
const languages={py:'python',pyw:'python',r:'r',rmd:'markdown',m:'matlab',jl:'julia',html:'html',htm:'html',css:'css',scss:'scss',less:'less',js:'javascript',mjs:'javascript',cjs:'javascript',jsx:'javascript',ts:'typescript',tsx:'typescript',json:'json',jsonc:'json',yaml:'yaml',yml:'yaml',xml:'xml',svg:'xml',c:'c',h:'c',cpp:'cpp',hpp:'cpp',cc:'cpp',cs:'csharp',java:'java',go:'go',rs:'rust',sql:'sql',sh:'shell',bash:'shell',ps1:'powershell',bat:'bat',cmd:'bat',ini:'ini',toml:'ini',tex:'latex',txt:'plaintext',log:'plaintext',csv:'plaintext',tsv:'plaintext',gitignore:'plaintext',env:'ini'};
function language(file){const name=String(file).split(/[\\/]/).pop().toLowerCase();return languages[name.split('.').pop()]||(['dockerfile','makefile','license','readme'].includes(name)?'plaintext':null);}
class CodeDocumentStore {
 constructor(req=require){this.req=req;this.fs=req('fs');this.path=req('path');this.Buffer=req('buffer').Buffer;}
 read(file){
  const {fs,path}=this;if(!path.isAbsolute(file)||!language(file))throw Error('暂不支持此代码文件类型');
  const real=fs.realpathSync(file),stat=fs.statSync(real);if(!stat.isFile()||stat.size>8*1024*1024)throw Error('请打开 8 MiB 以内的文本文件');const base=fs.readFileSync(real);
  let encoding='utf-8',bom=0;if(base[0]===255&&base[1]===254){encoding='utf-16le';bom=2;}else if(base[0]===254&&base[1]===255){encoding='utf-16be';bom=2;}else if(base[0]===239&&base[1]===187&&base[2]===191)bom=3;
  let text;try{text=new(this.req('util').TextDecoder)(encoding,{fatal:true,ignoreBOM:true}).decode(base.subarray(bom));}catch{throw Error('无法无损读取此编码，请先转换为 UTF-8 或带 BOM 的 UTF-16');}if(text.includes('\0'))throw Error('此文件包含二进制内容，不能作为代码编辑');
  return {file:real,base,text:text.replace(/\r\n?/g,'\n'),encoding,bom,eol:text.includes('\r\n')?'\r\n':text.includes('\r')?'\r':'\n',mode:stat.mode};
 }
 bytes(record,text){let value=text.replace(/\r?\n/g,record.eol),body=this.Buffer.from(value,record.encoding==='utf-8'?'utf8':'utf16le');if(record.encoding==='utf-16be')body.swap16();const prefix=record.bom?this.Buffer.from(record.encoding==='utf-8'?[239,187,191]:record.encoding==='utf-16le'?[255,254]:[254,255]):this.Buffer.alloc(0);return this.Buffer.concat([prefix,body]);}
 unchanged(record){try{return this.fs.realpathSync(record.file)===record.file&&this.fs.readFileSync(record.file).equals(record.base);}catch{return false;}}
 save(record,text){
  const {fs,path}=this;if(!this.unchanged(record))throw Error('文件已在其它位置修改或移动。草稿已保留，请另存为或重新载入。');
  if(text===record.text)return record;const bytes=this.bytes(record,text);if(bytes.length>8*1024*1024)throw Error('内容超过 8 MiB，未保存');
  const tmp=path.join(path.dirname(record.file),'.'+path.basename(record.file)+'.et-code-'+this.req('crypto').randomUUID()+'.tmp');
  try{fs.writeFileSync(tmp,bytes,{flag:'wx',mode:record.mode});if(!this.unchanged(record))throw Error('文件在保存前发生变化，未覆盖');fs.renameSync(tmp,record.file);}finally{if(fs.existsSync(tmp))fs.unlinkSync(tmp);}return {...record,text,base:bytes};
 }
 saveAs(record,file,text){if(!this.path.isAbsolute(file)||!language(file))throw Error('请保留受支持的代码或文本扩展名');const bytes=this.bytes(record,text);if(bytes.length>8*1024*1024)throw Error('内容超过 8 MiB');try{this.fs.writeFileSync(file,bytes,{flag:'wx'});}catch(e){if(e.code==='EEXIST')throw Error('目标文件已存在，请选择新文件名');throw e;}return this.read(file);}
}
module.exports={CodeDocumentStore,language};
