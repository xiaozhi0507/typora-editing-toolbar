const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const {JSDOM}=require('jsdom'),Execution=require('./ai-execution.cjs');
function fixture(status='running'){
 const window=new JSDOM('<body><div id="answer"></div></body>').window,document=window.document;
 const UI=vm.runInNewContext(fs.readFileSync(__dirname+'/ai-execution.js','utf8')+';EditingToolbarAIExecution',{ETAIExecution:Execution,EditingToolbarAITiming:{elapsed:()=>1,format:()=>''}});
 const ai={node(tag,cls,text){const n=document.createElement(tag);n.className=cls||'';n.textContent=text||'';return n;}};
 const turn={status,execution:[{id:'reason',type:'reasoning',kind:'summary',status:'running',text:'检查代码'}]};
 const ui=new UI(ai,turn,document.querySelector('#answer'));ui.update();return {window,document,turn,ui};
}
test('live reasoning opens automatically but later updates respect manual collapse',()=>{
 const f=fixture(),row=f.ui.rows.get('reason');assert.equal(row.root.open,true);
 row.root.querySelector('summary').click();assert.equal(row.root.open,false);
 f.turn.execution[0].text+='，核对输出';f.ui.update();assert.equal(row.root.open,false);
 f.turn.execution.push({id:'reason2',type:'reasoning',kind:'summary',status:'running',text:'下一步'});f.ui.update();assert.equal(f.ui.rows.get('reason2').root.open,true);
 f.turn.status='done';f.ui.update();assert.equal(f.ui.root.open,false);f.window.close();
});

test('failed turns disclose the cause outside collapsed execution details, as plain text',()=>{
 const f=fixture('error');f.turn.detail='请求失败：ECONNRESET <img src=x onerror=bad()> token=private';f.ui.update();assert.equal(f.ui.root.open,false);assert.equal(f.ui.failureNode.hidden,false);assert.equal(f.ui.failureNode.querySelector('img'),null);assert.match(f.ui.failureNode.textContent,/ECONNRESET/);assert.equal(f.ui.failureNode.parentElement,f.ui.root.parentElement);
 f.turn.status='running';f.ui.update();assert.equal(f.ui.failureNode.hidden,true);f.turn.status='done';f.ui.update();assert.equal(f.ui.failureNode.hidden,true);f.window.close();
});
test('long command display is labelled and operation title uses the description',()=>{
 const f=fixture('error');f.turn.execution=[{id:'long',type:'tool',name:'run_shell_command',status:'failed',command:'head ... tail',commandChars:42060,commandTruncated:true,description:'检查绘图数据',startedAt:1,endedAt:2,result:'exit 1',exitCode:1}];f.ui.update();assert.match(f.ui.rows.get('long').label.textContent,/检查绘图数据/);assert.match(f.ui.rows.get('long').content.textContent,/42060.*完整内容/);f.window.close();
});
test('history stays collapsed and repeated output refreshes preserve existing reasoning nodes and selections',()=>{
 const f=fixture('done'),row=f.ui.rows.get('reason'),text=row.textNode;assert.equal(row.root.open,false);
 const range=f.document.createRange();range.selectNodeContents(text);f.window.getSelection().addRange(range);
 for(let i=0;i<10;i++)f.ui.update();assert.equal(row.textNode,text);assert.equal(f.window.getSelection().toString(),'检查代码');
 f.turn.execution[0].text='检查代码完成';f.ui.update();assert.equal(row.content.firstChild,text);assert.equal(text.textContent,'检查代码完成');f.window.close();
});
test('sanitization only scans changed fields but rechecks when sanitizer changes',()=>{
 const turn={execution:Array.from({length:100},(_,i)=>({id:String(i),text:'safe'.repeat(1000),output:'secret'}))};let calls=0;
 const options={sanitize:text=>{calls++;return text.replaceAll('secret','hidden')}};Execution.update(turn,options);assert.equal(calls,200);
 for(let i=0;i<100;i++)Execution.update(turn,options);assert.equal(calls,200);
 turn.execution[99].output='secret updated';Execution.update(turn,options);assert.equal(calls,201);assert.equal(turn.execution[99].output,'hidden updated');
 Execution.update(turn,{sanitize:text=>text.replaceAll('hidden','protected')});assert.equal(turn.execution[0].output,'protected');
});
