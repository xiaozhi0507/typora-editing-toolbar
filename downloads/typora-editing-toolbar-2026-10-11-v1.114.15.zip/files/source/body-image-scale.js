// Persist whole-document image sizing through one native, undoable transaction.
class EditingToolbarImageScale {
 constructor(toolbar){
  this.toolbar=toolbar;this.levels=[25,50,75,100,125,150,200];
  const menu=document.getElementById('context-menu');if(!menu)return;this.menu=menu;
  const parent=document.createElement('li');this.parent=parent;
  parent.className='et-image-scale-context has-extra-menu hide';parent.dataset.key='et-image-scale';
  parent.innerHTML='<a role="menuitem" aria-haspopup="menu" aria-expanded="false" aria-controls="et-image-scale-menu"><span>统一调整图片大小</span><i class="fa fa-caret-right"></i></a>';
  const center=menu.querySelector('.et-center-context');if(center)center.after(parent);else menu.prepend(parent);
  const submenu=document.createElement('ul');this.submenu=submenu;
  submenu.id='et-image-scale-menu';submenu.className='dropdown-menu context-menu ext-context-menu';submenu.setAttribute('role','menu');
  for(const level of this.levels){
   const item=document.createElement('li');item.dataset.key='et-image-scale-'+level;item.dataset.imageScale=level;
   const link=document.createElement('a');link.setAttribute('role','menuitemradio');link.setAttribute('aria-checked','false');link.title='将全文图片设为原始尺寸的 '+level+'%';
   link.innerHTML='<span class="et-image-scale-check" aria-hidden="true"></span><span>'+level+'%</span>'+(level===100?'<span class="et-image-scale-hint">原始大小</span>':'');
   item.append(link);submenu.append(item);
  }
  document.body.append(submenu);
  const stop=e=>{e.preventDefault();e.stopPropagation();};parent.addEventListener('mousedown',stop);submenu.addEventListener('mousedown',stop);
  $(menu).on('mouseenter.etImageScale','li',e=>{if(e.currentTarget.parentElement===menu){if(e.currentTarget===parent)this.open();else this.close();}});
  $(parent).on('click.etImageScale',e=>{stop(e);this.open(true);});
  $(submenu).on('click.etImageScale','[data-image-scale]',e=>{stop(e);const level=Number(e.currentTarget.dataset.imageScale);File.editor.contextMenu.hide();this.close();if(this.contextFile===(File.bundle?.filePath||'')&&this.enabled())this.run(level);});
  document.addEventListener('contextmenu',e=>{
   this.close();this.contextFile=File.bundle?.filePath||'';
   parent.classList.toggle('hide',!document.getElementById('write')?.contains(e.target));
   this.updateAvailability();
  },true);
  new MutationObserver(()=>{if(!menu.classList.contains('show')||!parent.classList.contains('active'))this.close();}).observe(menu,{subtree:true,attributes:true,attributeFilter:['class']});
  new MutationObserver(()=>parent.firstElementChild.setAttribute('aria-expanded',String(submenu.classList.contains('show')))).observe(submenu,{attributes:true,attributeFilter:['class']});
 }
 unavailableReason(){
  if(this.toolbar.readingMode?.protected)return '保护模式下不可调整图片，请切换为编辑模式。';
  if(File.editor.sourceView?.inSourceMode)return '请退出源代码模式后调整图片。';
  if(File.isLocked||File.bundle?.isLocked||File.isReadonlyMode)return '文档已锁定或只读，无法调整图片。';
  if(File.isFileLoading?.())return '文档正在加载，请稍后重试。';
  if(this.toolbar.imageResizeState)return '请先完成当前图片的拖动缩放。';
  return this.toolbar.centerCaptions.enabled()?'':'当前文档暂不可调整图片，请稍后重试。';
 }
 // Ordinary reading mode changes presentation; protected mode blocks document edits.
 enabled(){return !this.unavailableReason();}
 updateAvailability(){
  const reason=this.unavailableReason()||(this.images().length?'':'正文中没有可调整的图片。');
  this.parent.classList.toggle('disabled',!!reason);
  this.parent.firstElementChild.setAttribute('aria-disabled',String(!!reason));
  this.parent.title=this.parent.firstElementChild.title=reason||'按原始尺寸统一调整全文图片，可用 Ctrl+Z 撤销。';
  return reason;
 }
 images(){return [...document.querySelectorAll('#write .md-image')].filter(n=>n.querySelector(':scope>img')&&!n.closest('pre,.md-fences,.md-htmlblock,.md-diagram-panel'));}
 open(notify=false){
  if(!this.menu.classList.contains('show')||this.contextFile!==(File.bundle?.filePath||''))return;
  const reason=this.updateAvailability();if(reason){if(notify)this.toolbar._showToolbarNotice(reason);return;}
  const images=this.images();
  const current=images.map(n=>{const img=n.querySelector(':scope>img');return img.hasAttribute('width')||img.hasAttribute('height')||img.style.width||img.style.height&&img.style.height!=='auto'?null:Math.round((parseFloat(img.style.zoom)||1)*(img.style.zoom.endsWith('%')?1:100));});
  const uniform=current.every(n=>n===current[0])?current[0]:null;
  for(const item of this.submenu.children){const checked=Number(item.dataset.imageScale)===uniform;item.firstElementChild.setAttribute('aria-checked',String(checked));item.querySelector('.et-image-scale-check').textContent=checked?'✓':'';}
  this.parent.classList.add('active');this.submenu.classList.add('show');const rect=this.parent.getBoundingClientRect(),box=this.submenu.getBoundingClientRect(),gap=4;
  const left=rect.right+box.width+gap<=innerWidth?rect.right+gap:rect.left-box.width-gap;
  this.submenu.style.left=Math.max(gap,Math.min(left,innerWidth-box.width-gap))+'px';this.submenu.style.top=Math.max(gap,Math.min(rect.top,innerHeight-box.height-gap))+'px';
 }
 close(){this.submenu.classList.remove('show');this.submenu.querySelectorAll('.active').forEach(n=>n.classList.remove('active'));}
 imageMarkup(wrapper,level){
  const original=wrapper.rawText(true),rendered=wrapper.querySelector(':scope>img');let image;
  if(wrapper.getAttribute('md-inline')==='imgtag'){
   const template=document.createElement('template');template.innerHTML=original;image=template.content.firstElementChild;
   if(image?.tagName!=='IMG'||template.content.children.length!==1)throw Error('图片源码正在更新');
  }else{
   if(level===100)return original;
   image=document.createElement('img');image.setAttribute('src',wrapper.getAttribute('data-src')||rendered.getAttribute('src'));
   for(const attr of ['alt','title'])if(rendered.hasAttribute(attr))image.setAttribute(attr,rendered.getAttribute(attr));
  }
  // Use absolute zoom, clearing previous manual dimensions to avoid cumulative scaling.
  image.removeAttribute('width');image.removeAttribute('height');
  for(const key of ['width','height','min-width','min-height','max-width','max-height','zoom'])image.style.removeProperty(key);
  if(level!==100)image.style.zoom=level+'%';
  if(!image.getAttribute('style')?.trim())image.removeAttribute('style');
  return image.outerHTML;
 }
 blockChange(block,images,level){
  const raw=n=>n.nodeType===1&&typeof n.rawText==='function'?n.rawText(true):n.textContent||'',source=raw(block),edits=[];
  for(const image of images){let start=0;for(let n=image;n!==block;n=n.parentNode){if(!n?.parentNode)throw Error('图片段落正在更新');for(let p=n.previousSibling;p;p=p.previousSibling)start+=raw(p).length;}
   const original=raw(image),text=this.imageMarkup(image,level);if(source.slice(start,start+original.length)!==original)throw Error('图片源码正在更新');
   if(text!==original)edits.push({start,end:start+original.length,text});
  }
  edits.sort((a,b)=>a.start-b.start);let text='',position=0;
  for(const edit of edits){if(edit.start<position)throw Error('图片选区重叠');text+=source.slice(position,edit.start)+edit.text;position=edit.end;}text+=source.slice(position);
  return {text,count:edits.length,mapOffset:offset=>{let delta=0;for(const edit of edits){if(offset<edit.start)break;if(offset<=edit.end)return edit.start+delta+Math.min(offset-edit.start,edit.text.length);delta+=edit.text.length-(edit.end-edit.start);}return offset+delta;}};
 }
 transform(json,changes){
  const change=changes.get(json.id);if(change)json.content.text=change.text;
  if(json.content.type==='table')delete json.content.userText;
  json.children=(json.children||[]).map(child=>this.transform(child,changes));return json;
 }
 run(level){
  if(!this.levels.includes(level))return;
  const reason=this.unavailableReason();if(reason){this.toolbar._showToolbarNotice(reason);return;}
  const editor=File.editor,notice=text=>this.toolbar._showToolbarNotice(text),images=this.images(),groups=new Map(),changes=new Map(),roots=new Map();
  editor.undo.endSnap(true);this.toolbar.tableColumns.finish(true);this.toolbar.readingPosition?.cancelRestore();
  try{
   for(const image of images){const block=image.closest('p[cid],h1[cid],h2[cid],h3[cid],h4[cid],h5[cid],h6[cid],.td-span[cid]');if(!block)throw Error('当前图片类型暂不支持批量调整');if(!groups.has(block))groups.set(block,[]);groups.get(block).push(image);}
   for(const [block,items] of groups){
    const node=editor.getNode(block.getAttribute('cid'));if(!node||block.rawText(true)!==node.get('text'))throw Error('段落正在更新，请稍后重试');
    const change=this.blockChange(block,items,level);if(!change.count)continue;changes.set(node.cid,change);
    let root=node;while(['table_row','table'].includes(root.get('parent')?.get('type')))root=root.get('parent');roots.set(root.cid,root);
   }
  }catch(error){notice('图片大小未改变：'+error.message+'。');return;}
  if(!changes.size){notice(images.length?'全文图片已是 '+level+'%。':'正文中没有可调整的图片。');return;}
  const cursor=editor.selection.buildUndo(),command={undo:cursor?[cursor]:[],redo:[]},scroll=document.querySelector('content'),top=scroll?.scrollTop;
  this.toolbar._hideImageResizeHandle();this.toolbar.citationPreview?.hide();editor.brush.pause(true);
  try{
   for(const root of roots.values()){
    const json=this.transform(JSON.parse(JSON.stringify(root.storeToJson())),changes),redo={type:'replace',id:root.cid,json};
    command.undo.push(editor.undo.buildReplaceUndo(root));editor.undo.exeCommand(redo);command.redo.push(redo);
   }
   if(cursor){const mapped={...cursor};for(const [field,id] of [['start',cursor.startId||cursor.id],['end',cursor.endId||cursor.id]])if(changes.has(id)&&Number.isFinite(mapped[field]))mapped[field]=changes.get(id).mapOffset(mapped[field]);editor.undo.exeCommand(mapped);command.redo.push(mapped);}
   editor.undo.register(command);editor.refresh();this.toolbar.tableColumns.scan();if(scroll)scroll.scrollTop=top;
   notice('已将全文 '+images.length+' 张图片设为 '+level+'%，可按 Ctrl+Z 撤销。');
  }catch(error){for(const undo of command.undo.slice().reverse())editor.undo.exeCommand(undo);editor.refresh();notice('图片缩放未完成，已恢复原文。');console.error('[EditingToolbar] Batch image scale rolled back',error);}
  finally{editor.brush.resume();}
 }
}
