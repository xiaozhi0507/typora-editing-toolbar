import {escapeAttr} from './annotation-live-formats.js';
export const cardTitles={note:'提醒内容',tip:'建议内容',important:'重要内容',warning:'警告内容',caution:'注意内容'};
export const safeLink=value=>/^(https?:\/\/|mailto:|#|zotero:\/\/(?:open-pdf|select)\/)/i.test(value||'')&&!/[\s<>"\u0000-\u001f]/.test(value);
export const layoutAttrs={alignment:{default:null},indent:{default:0}};
export function blockDOM(tag,node){const style=(node.attrs.alignment?'text-align:'+node.attrs.alignment+';':'')+(node.attrs.indent?'padding-left:'+node.attrs.indent*2+'em;':'');return style?[tag,{style},0]:[tag,0];}
export const extraNodes={
 note_card:{group:'block',content:'block+',attrs:{variant:{default:'note'}},toDOM:n=>['section',{'class':'note-card note-card-'+n.attrs.variant},['div',{'class':'note-card-caption',contenteditable:'false'},cardTitles[n.attrs.variant]||'笔记'],['div',{'class':'note-card-body'},0]]},
 note_footnote:{inline:true,group:'inline',atom:true,attrs:{id:{default:'1'},text:{default:''}},toDOM:n=>['sup',{'class':'note-footnote','data-footnote':n.attrs.id,title:n.attrs.text,contenteditable:'false'},'['+n.attrs.id+']']},
 note_video:{group:'block',atom:true,attrs:{src:{default:''}},toDOM:n=>['div',{'class':'note-video'},n.attrs.src]}
};
// Canonical wrappers carry only the plugin's layout/card attributes, never arbitrary HTML.
export function installStructureRules(md){
 md.core.ruler.before('block','note_definitions',state=>{
  const defs=state.env.noteDefinitions={footnotes:{},refs:{}};let fence=null;
  for(const line of state.src.split('\n')){const f=/^\s*(`{3,}|~{3,})/.exec(line);if(f){if(!fence)fence=f[1][0];else if(fence===f[1][0])fence=null;continue;}if(fence)continue;
   let m=/^\[\^([\w-]+)\]:\s*(.*)$/.exec(line);if(m)defs.footnotes[m[1]]=m[2];
   m=/^\[([\w-]+)\]:\s*(\S+)(?:\s+"([^"]*)")?\s*$/.exec(line);if(m&&safeLink(m[2]))defs.refs[m[1]]={href:m[2],title:m[3]||null};
  }
 });
 md.block.ruler.before('html_block','note_wrappers',(state,start,end,silent)=>{
  const line=state.src.slice(state.bMarks[start]+state.tShift[start],state.eMarks[start]).trim();
  const foot=/^\[\^([\w-]+)\]:\s*(.*)$/.exec(line);if(foot){state.line=start+1;return true;}
  const video=/^<video controls src="(assets\/[a-f0-9]{32}\.(?:mp4|webm|ogg|mov|m4v))"><\/video>$/.exec(line);
  if(video){if(!silent){const t=state.push('note_video','video',0);t.meta={src:video[1]};}state.line=start+1;return true;}
  const open=/^<div data-note-(card|layout)="([^"]+)">$/.exec(line);if(!open)return false;
  const card=open[1]==='card';if(card&&!cardTitles[open[2]])return false;
  const layout=!card&&/^(left|center|right|justify|auto):(\d{1,2})$/.exec(open[2]);if(!card&&(!layout||+layout[2]>12))return false;
  let depth=1,last=start;while(++last<end){const row=state.src.slice(state.bMarks[last],state.eMarks[last]).trim();if(/^<div data-note-(?:card|layout)=/.test(row))depth++;if(row==='</div>'&&!--depth)break;}
  if(depth)return false;if(silent)return true;
  if(card){const t=state.push('note_card_open','section',1);t.meta={variant:open[2]};}
  const begin=state.tokens.length,oldParent=state.parentType;state.parentType='blockquote';state.md.block.tokenize(state,start+1,last);state.parentType=oldParent;
  if(card)state.push('note_card_close','section',-1);else for(const t of state.tokens.slice(begin))if(t.type==='paragraph_open'||t.type==='heading_open'){t.attrSet('note-align',layout[1]==='auto'?'':layout[1]);t.attrSet('note-indent',layout[2]);}
  state.line=last+1;return true;
 },{alt:['paragraph','reference','blockquote','list']});
 md.inline.ruler.before('link','note_refs',(state,silent)=>{
  const source=state.src.slice(state.pos),defs=state.env.noteDefinitions||{},foot=/^\[\^([\w-]+)\]/.exec(source);
  if(foot){if(!silent){const t=state.push('note_footnote','sup',0);t.meta={id:foot[1],text:defs.footnotes?.[foot[1]]||''};}state.pos+=foot[0].length;return true;}
  const ref=/^\[([^\]\n]+)\]\[([\w-]+)\]/.exec(source),d=ref&&defs.refs?.[ref[2]];if(!d)return false;
  if(!silent){const a=state.push('link_open','a',1);a.attrs=[['href',d.href],['title',d.title],['note-ref',ref[2]]];const t=state.push('text','',0);t.content=ref[1];state.push('link_close','a',-1);}state.pos+=ref[0].length;return true;
 });
 md.core.ruler.after('inline','note_tasks',state=>{const stack=[],lists=[];for(const t of state.tokens){if(t.type==='bullet_list_open'||t.type==='ordered_list_open')lists.push(t);else if(t.type==='bullet_list_close'||t.type==='ordered_list_close')lists.pop();if(t.type==='list_item_open')stack.push(t);else if(t.type==='list_item_close')stack.pop();else if(t.type==='inline'&&stack.length){const m=/^\[([ xX])\]\s+/.exec(t.content);if(m){lists.at(-1)?.attrSet('note-task','true');stack.at(-1).attrSet('note-checked',m[1].trim()?'true':'false');t.content=t.content.slice(m[0].length);if(t.children?.[0]?.type==='text')t.children[0].content=t.children[0].content.slice(m[0].length);}}}});
}
export const structureTokens={note_card:{block:'note_card',getAttrs:t=>t.meta},note_footnote:{node:'note_footnote',getAttrs:t=>t.meta},note_video:{node:'note_video',getAttrs:t=>t.meta},
 paragraph:{block:'paragraph',getAttrs:t=>({alignment:t.attrGet('note-align')||null,indent:+t.attrGet('note-indent')||0})},
 heading:{block:'heading',getAttrs:t=>({level:+t.tag.slice(1),alignment:t.attrGet('note-align')||null,indent:+t.attrGet('note-indent')||0})},
 bullet_list:{block:'bullet_list',getAttrs:t=>({task:t.attrGet('note-task')==='true'})},
 list_item:{block:'list_item',getAttrs:t=>({checked:t.attrGet('note-checked')===null?null:t.attrGet('note-checked')==='true'})},
 link:{mark:'link',getAttrs:t=>({href:t.attrGet('href'),title:t.attrGet('title')||null,ref:t.attrGet('note-ref')||null})}
};
export function structureSerializers(original){
 const nodes={
  note_card:(s,n)=>{s.write('<div data-note-card="'+n.attrs.variant+'">\n\n');s.renderContent(n);s.ensureNewLine();s.write('\n</div>');s.closeBlock(n);},
  note_footnote:(s,n)=>s.write('[^'+n.attrs.id+']'),
  note_video:(s,n)=>{s.write('<video controls src="'+escapeAttr(n.attrs.src)+'"></video>');s.closeBlock(n);},
  list_item:(s,n)=>{if(n.attrs.checked!==null)s.write(n.attrs.checked?'[x] ':'[ ] ');s.renderContent(n);}
 };
 for(const type of ['paragraph','heading'])nodes[type]=(s,n)=>{const wrap=n.attrs.alignment||n.attrs.indent;if(wrap)s.write('<div data-note-layout="'+(n.attrs.alignment||'auto')+':'+n.attrs.indent+'">\n\n');original.nodes[type](s,n);if(wrap){s.ensureNewLine();s.write('\n</div>');s.closeBlock(n);}};
 return nodes;
}
export function appendDefinitions(doc,text){const footnotes=new Map(),refs=new Map();doc.descendants(n=>{if(n.type.name==='note_footnote')footnotes.set(n.attrs.id,n.attrs.text);for(const m of n.marks)if(m.type.name==='link'&&m.attrs.ref)refs.set(m.attrs.ref,m.attrs);});
 for(const [id,value] of footnotes)text+='\n\n[^'+id+']: '+value.replace(/\r?\n/g,' ');
 for(const [id,a] of refs)text+='\n\n['+id+']: '+a.href+(a.title?' "'+a.title.replace(/"/g,'')+'"':'');return text;
}
