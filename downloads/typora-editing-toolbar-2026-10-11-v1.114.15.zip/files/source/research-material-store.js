// Folder-scoped material storage. Notes and annotations keep their own stores.
class EditingToolbarMaterialStore extends EditingToolbarAnnotations {
    _scope(){
        const file=File.bundle?.filePath;let folder=file?this.path.dirname(file):File.getMountFolder?.();
        if(folder&&this.path.isAbsolute(folder))folder=this.path.resolve(folder);else folder=null;
        return {key:folder?'folder:'+folder.toLowerCase():'untitled:'+File.bundle?.untitledId,folder,file:file||null};
    }
    _key(){return this._scope().key;}
    _docKey(){return File.bundle?.filePath||'untitled:'+File.bundle?.untitledId;}
    _findOwner(folder){
        if(!folder||!this._storageDirectoryExists(folder))return null;
        const names=this.fs.readdirSync(folder,{withFileTypes:true}).filter(e=>e.isDirectory()&&!e.isSymbolicLink()&&e.name.endsWith('.资料')).map(e=>e.name).sort();
        const dirs=names.map(name=>this.path.join(folder,name,'素材暂存盘')).filter(dir=>this._storageDirectoryExists(dir));return dirs.find(dir=>this.fs.existsSync(this.path.join(dir,'index.json')))||dirs[0]||null;
    }
    _candidate(folder,ownerFile){return ownerFile&&this.path.dirname(ownerFile)===folder?ownerFile+'.资料'+this.path.sep+'素材暂存盘':this.path.join(this.draftDir,this._hash('folder:'+folder.toLowerCase())+'.assets');}
    _dir(folder,ownerFile){const owner=this._findOwner(folder);if(owner)return owner;const legacy=this.path.join(folder,'素材暂存盘');if(this.fs.existsSync(this.path.join(legacy,'index.json')))return legacy;return this._candidate(folder,ownerFile||File.bundle?.filePath);}
    _managed(ctx){return !!ctx.folder&&this.path.dirname(this.path.dirname(ctx.dir))===ctx.folder&&this.path.basename(this.path.dirname(ctx.dir)).endsWith('.资料');}
    _prepareStorage(folder,dir){if(folder){this._storageDirectoryExists(folder);if(dir){if(this.path.dirname(dir)!==folder)this._storageDirectoryExists(this.path.dirname(dir));this._storageDirectoryExists(dir);}}}
    _hasMaterial(ctx){return ctx.notes.some(n=>!n.archived);}
    _defaultTabs(){return [{id:'default',title:'默认'}];}
    _validate(data){
        if(![1,2].includes(data?.version))throw Error('不支持的素材版本');
        super._validate({...data,version:1});
        if(data.notes.some(n=>!['text','image','math'].includes(n.kind)))throw Error('素材记录不完整');
        if(data.version===2){
            if(data.scope!=='folder'||!Array.isArray(data.tabs)||!data.tabs.length||data.tabs.length>100||!Array.isArray(data.imports)||data.imports.some(x=>typeof x!=='string'))throw Error('素材标签记录不完整');
            const ids=new Set();for(const t of data.tabs){if(typeof t.id!=='string'||ids.has(t.id)||typeof t.title!=='string'||!t.title.trim())throw Error('素材标签无效');ids.add(t.id);}
            if(!ids.has('default'))throw Error('默认标签缺失');
        }
        return data;
    }
    _data(ctx){return {version:2,scope:'folder',documentId:ctx.documentId,updated:new Date().toISOString(),notes:ctx.notes,tabs:ctx.tabs,imports:ctx.imports};}
    _load(scope){
        const {key,folder}=scope,ownerFile=scope.file||(File.bundle?.filePath&&this.path.dirname(File.bundle.filePath)===folder?File.bundle.filePath:null),dir=folder?this._dir(folder,ownerFile):this.path.join(this.draftDir,this._hash(key)+'.assets');
        const ctx={key,folder,file:folder,ownerFile,dir,notes:[],tabs:this._defaultTabs(),imports:[],documentId:this._id(),base:'',dirty:false,readonly:false};
        try{
            this._prepareStorage(folder,dir);ctx.base=folder?this._read(this.path.join(dir,'index.json')):'';
            if(ctx.base){const data=this._validate(JSON.parse(ctx.base));Object.assign(ctx,{notes:data.notes,tabs:data.tabs||this._defaultTabs(),imports:data.imports||[],documentId:data.documentId||ctx.documentId});}
            const draft=this._read(this._draftFile(ctx));if(draft){const d=this._validate(JSON.parse(draft));if(d.dir&&d.dir!==ctx.dir)this._copyAssets(d.dir,ctx.dir,d.notes);if(d.baseHash===this._hash(ctx.base)){ctx.notes=d.notes;ctx.tabs=d.tabs||this._defaultTabs();ctx.imports=d.imports||[];}else this._mergeData(ctx,d.baseData||{notes:d.baseNotes||[]},d,ctx);ctx.dirty=true;}
        }catch(e){ctx.readonly=true;ctx.error='无法读取素材：'+e.message;}
        if(folder&&!this._managed(ctx)&&this._hasMaterial(ctx)&&ownerFile)ctx.dirty=true;ctx.stamp=this._stamp(ctx);return ctx;
    }
    _stamp(ctx){try{const s=this.fs.statSync(this.path.join(ctx.dir,'index.json'));return s.mtimeMs+':'+s.size;}catch{return '';}}
    _mergeRecords(base=[],local=[],remote=[]){
        const b=new Map(base.map(n=>[n.id,n])),l=new Map(local.map(n=>[n.id,n])),r=new Map(remote.map(n=>[n.id,n])),out=[];const same=(x,y)=>JSON.stringify(x)===JSON.stringify(y);
        for(const id of new Set([...l.keys(),...r.keys()])){const a=l.get(id),c=r.get(id),old=b.get(id);if(same(a,c)||same(c,old)){if(a)out.push(a);}else if(same(a,old)){if(c)out.push(c);}else if(a&&c){if(a.archived||c.archived)out.push({...c,...a,archived:true});else{out.push(a);if(a.markdown!==undefined&&a.markdown!==c.markdown)out.push({...c,id:this._id()});}}else out.push(a||c);}
        return out;
    }
    _mergeData(ctx,base,local,remote){ctx.notes=this._mergeRecords(base.notes,local.notes,remote.notes);ctx.tabs=this._mergeRecords(base.tabs,local.tabs||this._defaultTabs(),remote.tabs||this._defaultTabs());ctx.imports=[...new Set([...(local.imports||[]),...(remote.imports||[])])];}
    _draft(ctx){try{this._atomic(this._draftFile(ctx),JSON.stringify({...this._data(ctx),key:ctx.key,dir:ctx.dir,baseHash:this._hash(ctx.base),baseData:ctx.base?JSON.parse(ctx.base):{notes:[],tabs:this._defaultTabs(),imports:[]}},null,2));return true;}catch(e){this._status('素材草稿保存失败：'+e.message,true);return false;}}
    _touch(){if(!this.ctx||this.ctx.readonly)return;this.ctx.dirty=true;this._draft(this.ctx);clearTimeout(this.saveTimer);const ctx=this.ctx;this.saveTimer=setTimeout(()=>this._save(ctx),350);}
    _save(ctx=this.ctx){
        if(!ctx||!ctx.dirty||ctx.readonly)return !ctx?.readonly;if(!ctx.folder)return this._draft(ctx);
        let owner=this._findOwner(ctx.folder);if(!owner&&!this._hasMaterial(ctx))return this._draft(ctx);
        if(!owner&&!ctx.ownerFile)return this._draft(ctx);
        const lock=this.path.join(ctx.folder,'.editing-toolbar-materials.lock');let fd;
        try{
            this._prepareStorage(ctx.folder);
            if(this.fs.existsSync(lock)){let alive=true;try{reqnode('process').kill(JSON.parse(this._read(lock)).pid,0);}catch(e){alive=e.code!=='ESRCH';}if(!alive&&Date.now()-this.fs.statSync(lock).mtimeMs>30000)this.fs.unlinkSync(lock);}
            fd=this.fs.openSync(lock,'wx');this.fs.writeFileSync(fd,JSON.stringify({pid:reqnode('process').pid}));
            owner=this._findOwner(ctx.folder)||this._candidate(ctx.folder,ctx.ownerFile);this._prepareStorage(ctx.folder,owner);
            const moved=ctx.dir!==owner,index=this.path.join(owner,'index.json'),disk=this._read(index);
            if(this.fs.existsSync(index+'.lock'))throw Error('素材仍在其他窗口保存，请稍后重试');
            if(disk)this._validate(JSON.parse(disk));
            if(moved){this._copyAssets(ctx.dir,owner,ctx.notes);ctx.dir=owner;ctx.base='';}
            const merged=disk!==ctx.base;if(merged){const remote=disk?this._validate(JSON.parse(disk)):{notes:[],tabs:this._defaultTabs(),imports:[]};this._mergeData(ctx,ctx.base?JSON.parse(ctx.base):{notes:[],tabs:this._defaultTabs(),imports:[]},ctx,remote);}
            const text=JSON.stringify(this._data(ctx),null,2);if(disk)this._atomic(this.path.join(ctx.dir,'index.previous.json'),disk);this._atomic(index,text);ctx.base=text;ctx.dirty=false;ctx.stamp=this._stamp(ctx);ctx.error='';
            try{this._atomic(this.path.join(ctx.dir,'素材.md'),this._export(ctx));if(this.fs.existsSync(this._draftFile(ctx)))this.fs.unlinkSync(this._draftFile(ctx));}catch(e){this._status('素材已保存，副本更新失败：'+e.message,true);}
            if(ctx===this.ctx&&merged)this._renderList();return true;
        }catch(e){ctx.error=e.message;this._draft(ctx);this._status('素材保存未完成：'+e.message,true);return false;}
        finally{if(fd!==undefined){this.fs.closeSync(fd);try{this.fs.unlinkSync(lock);}catch{}}}
    }
    _syncDisk(){
        const ctx=this.ctx;if(!ctx?.folder||ctx.readonly)return;const owner=this._findOwner(ctx.folder);if(owner&&owner!==ctx.dir){ctx.dirty=true;this._save(ctx);return;}if(ctx.dirty||this._stamp(ctx)===ctx.stamp)return;
        try{const text=this._read(this.path.join(ctx.dir,'index.json'));if(!text)return;const d=this._validate(JSON.parse(text));ctx.notes=d.notes;ctx.tabs=d.tabs||this._defaultTabs();ctx.imports=d.imports||[];ctx.base=text;ctx.stamp=this._stamp(ctx);this._renderList();}catch(e){ctx.readonly=true;this._status('素材文件异常，已停止写入：'+e.message,true);this._renderList();}
    }
    _switchDocument(){
        if(this.savingAs||this._loading())return;const scope=this._scope(),doc=this._docKey();
        if(this.ctx?.key!==scope.key){const old=this.ctx;if(old)this._save(old);this.ctx=this.contexts.get(scope.key)||this._load(scope);this.contexts.set(scope.key,this.ctx);this.picked.clear();this.undoBatch=null;this.activeTab=localStorage.getItem('et-material-tab:'+this._hash(scope.key))||'default';this._closePopover();if(old&&!old.folder&&scope.folder)this._migrateDraft(old);this._renderList();if(this.ctx.error)this._status(this.ctx.error,true);}
        if(scope.file&&(!this.ctx.ownerFile||(!this._hasMaterial(this.ctx)&&!this._findOwner(scope.folder)))){this.ctx.ownerFile=scope.file;if(!this.ctx.base)this.ctx.dir=this._candidate(scope.folder,scope.file);}
        if(this.lastDocument!==doc){this.lastDocument=doc;this._importLegacy(File.bundle?.filePath);}
    }
    _migrateDraft(previous){
        const ctx=this.ctx;if(ctx.readonly||(!previous.notes.length&&previous.tabs.length===1&&!previous.imports.length))return;const token='draft:'+this._hash(previous.key);if(ctx.imports.includes(token))return;
        try{this._copyAssets(previous.dir,ctx.dir,previous.notes);this._mergeData(ctx,{notes:[],tabs:this._defaultTabs(),imports:[]},ctx,previous);ctx.imports.push(token);ctx.dirty=true;if(this._save(ctx)&&this.fs.existsSync(this._draftFile(previous)))this.fs.unlinkSync(this._draftFile(previous));}catch(e){this._status('草稿素材迁移未完成，原内容已保留：'+e.message,true);}
    }
    _importLegacy(file){
        if(!file||this.ctx.readonly)return;const ctx=this.ctx,dir=this.path.join(this.path.dirname(file),this.path.basename(file)+'.资料','素材'),index=this.path.join(dir,'index.json');
        try{let data=this._read(index);if(!data)return;data=this._validate(JSON.parse(data));let changed=false;
            for(const old of data.notes){const token=this._hash(dir.toLowerCase()+'|'+old.id);if(ctx.imports.includes(token))continue;if(old.archived){ctx.imports.push(token);changed=true;continue;}this._copyAssets(dir,ctx.dir,[old]);const existing=ctx.notes.find(n=>n.id===old.id);if(!existing||existing.markdown!==old.markdown)ctx.notes.push({...structuredClone(old),id:existing?this._id():old.id,tabId:'default'});ctx.imports.push(token);changed=true;}
            if(changed){ctx.dirty=true;this._save(ctx);this._renderList();}
        }catch(e){this._status('旧素材未导入，原文件保留：'+e.message,true);}
    }
    _afterSaveAs(previous){this.savingAs=false;this._switchDocument();}
    _export(ctx){return '# 素材暂存盘\n\n'+ctx.tabs.map(t=>'## '+t.title+'\n\n'+ctx.notes.filter(n=>!n.archived&&(n.tabId||'default')===t.id).map(n=>n.markdown).join('\n\n---\n\n')).join('\n\n');}
}
