'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path').win32,{JSDOM}=require('jsdom');
function fixture(t){
 const dom=new JSDOM('<main></main>');t.after(()=>dom.window.close());const document=dom.window.document;
 const scope={document,CSS:{escape:s=>s},setTimeout,clearTimeout};
 const P=vm.runInNewContext(fs.readFileSync(__dirname+'/document-projects.js','utf8')+';EditingToolbarProjects',scope);
 const p=Object.create(P.prototype),project={id:'p',root:'C:\\project',name:'Project',fileOrder:{},expandedFolders:[]},reads=[];
 const node=(tag,cls='',text='')=>{const el=document.createElement(tag);el.className=cls;el.textContent=text;return el;};
 p.tabs={path,toolbar:{},node,key:s=>s.toLowerCase(),bindSort(){},rowState:{pinned:new Set(),favorites:new Set()},fileRow({path:filename,name}){const el=node('div','et-project-file-row',name);el.dataset.path=filename;return el;}};
 p.bindFileMove=()=>{};p.bindFolderDrop=()=>{};p.rememberFolder=()=>{};p.read=()=>{};p.save=()=>{};p.items=[project];
 const host=document.querySelector('main');p.fileViews=new Map([['p',{root:project.root,files:host,ready:true}]]);
 const entry=(relative,directory=false)=>({relative,directory,name:path.basename(relative),path:path.join(project.root,relative)});
 p.core={list:async(_p,relative)=>{reads.push(relative);return relative?[entry(relative+'/a.py')]:[entry('src',true),entry('data',true),entry('main.py')];}};
 return {p,project,host,reads,entry};
}
test('targeted refresh preserves unrelated expanded folder nodes and only reads affected directories',async t=>{
 const f=fixture(t);await f.p.list(f.project,f.host);const src=f.host.querySelector('[data-project-directory="src"]'),data=f.host.querySelector('[data-project-directory="data"]');
 src.open=true;await f.p.list(f.project,src.lastElementChild,'src');src.dataset.loaded='true';const retained=src.lastElementChild.firstElementChild;f.reads.length=0;
 await f.p.refreshFolders(f.project,['','data','data']);assert.deepEqual(f.reads,['','data']);assert.equal(f.host.firstElementChild,src);assert.equal(f.host.children[1],data);assert.equal(src.lastElementChild.firstElementChild,retained);assert.equal(src.open,true);
});
test('slower directory response cannot overwrite a newer refresh',async t=>{
 const f=fixture(t),pending=[];f.p.core.list=()=>new Promise(resolve=>pending.push(resolve));const first=f.p.list(f.project,f.host),second=f.p.list(f.project,f.host);
 pending[1]([f.entry('new.py')]);await second;pending[0]([f.entry('old.py')]);await first;assert.equal(f.host.textContent,'new.py');
});
test('a stale directory error cannot append an error to a successfully refreshed folder',async t=>{
 const f=fixture(t),pending=[];f.p.core.list=()=>new Promise((resolve,reject)=>pending.push({resolve,reject}));const first=f.p.list(f.project,f.host),second=f.p.list(f.project,f.host);
 pending[1].resolve([f.entry('new.py')]);await second;pending[0].reject(Error('old error'));await first;assert.equal(f.host.textContent,'new.py');
});
test('busy state and opened tabs do not invalidate a project file listing',t=>{
 const f=fixture(t),before=f.p.fileViewSignature(f.project);f.p.tabs.busy=true;f.p.tabs.rowState.opened=new Set(['C:/project/main.py']);assert.equal(f.p.fileViewSignature(f.project),before);
 f.p.tabs.rowState.favorites.add('C:/project/main.py');f.p.tabs.rowState.dirty=true;f.p.tabs.current='C:/project/other.md';f.p.tabs.pending={path:'C:/project/next.md'};assert.equal(f.p.fileViewSignature(f.project),before);
 f.project.outputFolder='results';assert.notEqual(f.p.fileViewSignature(f.project),before);
});
test('successive manual reorder uses the latest order and reuses rows without directory IO',async t=>{
 const f=fixture(t),keys=['a.py','b.py','c.py','d.py'];f.p.core.list=async()=>keys.map(k=>f.entry(k));await f.p.list(f.project,f.host);const rows=[...f.host.children];let reads=0;f.p.core.list=async()=>{reads++;return [];};
 f.p.moveFile('p','',keys,'d.py','a.py');f.p.moveFile('p','',keys,'c.py','b.py');assert.deepEqual([...f.project.fileOrder['']],['d.py','a.py','c.py','b.py']);assert.deepEqual([...f.host.children],[rows[3],rows[0],rows[2],rows[1]]);assert.equal(reads,0);
});
test('batch relocation updates all collections once and relocates each live editor model',()=>{
 const T=vm.runInNewContext(fs.readFileSync(__dirname+'/document-tabs.js','utf8')+';EditingToolbarDocumentTabs',{}),tabs=Object.create(T.prototype),moved=[],db={tabs:[{path:'a.py'},{path:'b.py'}],favorites:[{path:'b.py'}],pinned:[{path:'keep.py'}]};let changes=0,refreshes=0;
 Object.assign(tabs,{key:s=>s,supported:()=>false,toolbar:{codeEditor:{supported:()=>true,relocate:(...args)=>moved.push(args)}},change:fn=>{changes++;fn(db);},refreshModified:()=>{refreshes++;}});
 tabs.replacePaths([{from:'a.py',to:'src/a.py'},{from:'b.py',to:'src/b.py'}]);assert.equal(changes,1);assert.equal(refreshes,1);assert.deepEqual(moved,[['a.py','src/a.py'],['b.py','src/b.py']]);assert.deepEqual(db.tabs.map(x=>x.path),['src/a.py','src/b.py']);assert.equal(db.favorites[0].path,'src/b.py');assert.equal(db.pinned[0].path,'keep.py');
});
test('sidebar hidden geometry ignores transformed and stale native coordinates',()=>{
 let shown=false;const source=fs.readFileSync(__dirname+'/panel-workspace.js','utf8').split('// Keep module-specific')[0];
 const W=vm.runInNewContext(source+';EditingToolbarPanelWorkspace',{innerWidth:1000,File:{editor:{library:{isSidebarShown:()=>shown}}},document:{getElementById:()=>({getBoundingClientRect:()=>({width:270,right:-29730})})}});
 const w=Object.create(W.prototype);assert.equal(w.documentLeft(),0);shown=true;assert.equal(w.documentLeft(),270);shown=false;assert.equal(w.documentLeft(),0);
});
