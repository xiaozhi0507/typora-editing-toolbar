// Website conversations use their own transport and identity, never API effort normalization.
class EditingToolbarAIWebChat {
  static id='builtin-chatgpt-web';
  static labels={Instant:'即时',Medium:'中',High:'高','Extra High':'极高'};
  static extensions=['md','markdown','mdown','txt','pdf','docx','csv','json','png','jpg','jpeg','webp'];
  constructor(ai){this.ai=ai;this.browser=new EditingToolbarWebChatBrowser(ai);this.projects=new EditingToolbarAIWebProjects(this);this.translation=new EditingToolbarAIWebTranslation(this);this.profile={id:EditingToolbarAIWebChat.id,model:'chatgpt-web',modelLabel:'GPT 网页',name:'GPT 网页',authType:'chatgpt-web'};}
  active(){return this.ai.profile()?.authType==='chatgpt-web';}
  label(){const mode=this.ai.config.webChat?.mode;return EditingToolbarAIWebChat.labels[mode]||mode||'待连接';}
  confirm(snapshot){if(!snapshot?.mode)return;const previous=this.ai.config.webChat;if(previous?.mode===snapshot.mode&&(previous.version||'')===(snapshot.version||''))return;this.ai.config.webChat={...this.ai.config.webChat,mode:snapshot.mode,version:snapshot.version||''};localStorage.setItem(this.ai.configKey,JSON.stringify(this.ai.config));this.refreshUI();}
  refreshUI(){const a=this.ai;if(!a.composerUI?.modelMenu)return;if(a.composerUI.menu===a.composerUI.modelMenu)a.composerUI.refreshModels();else a.composerUI.syncModelButton();a.composerUI.sync();if(this.browser.message)this.browser.message.textContent=this.browser.status;}
  openSettings(){this.ai.composerUI.closeMenu();this.browser.show();}
  loadOptions(menu){
    if(menu._webOptionsRequested||Date.now()-(menu._webOptionsReadAt||0)<1000)return;menu._webOptionsRequested=true;
    void (async()=>{try{for(let attempt=0;attempt<3;attempt++){try{await this.browser.options();return;}catch(e){if(attempt<2&&menu.isConnected&&!this.ai.busy&&/尚未|仍在|未提供可识别|操作超时/.test(e.message)){await new Promise(r=>setTimeout(r,1500));}else{this.ai.notice(e.message,true);return;}}}}finally{menu._webOptionsRequested=false;menu._webOptionsReadAt=Date.now();}})();
  }
  renderVersions(parent,{onModel}){
    const a=this.ai,b=this.browser,rows=b.capabilities.versions.filter(row=>! /^(?:GPT[- ]?)?5\.5(?:$|[ -])/i.test(row.label));
    for(const row of rows){
      const choice=a.node('button','et-ai-model-option');choice.type='button';choice.dataset.webVersion=row.label;choice.setAttribute('role','menuitemradio');choice.setAttribute('aria-checked',String(this.active()&&a.config.webChat?.version===row.label));choice.disabled=row.disabled||b.switching||!!b.refreshJob||a.busy;
      const check=a.node('span','et-ai-menu-check');check.innerHTML='<svg viewBox="0 0 20 20" aria-hidden="true"><path d="m4 10 4 4 8-9"/></svg>';choice.append(a.node('span','et-ai-model-option-name',row.label),check);choice.title=row.label+(row.disabled?' · 当前网页不可用':'');choice.onclick=()=>onModel({...this.profile,webVersion:row.label});parent.append(choice);
    }
    if(!rows.length){const note=a.node('div','et-ai-model-status',b.refreshJob?'正在读取网页版本…':b.status);note.setAttribute('role','status');parent.append(note);const open=a.node('button','et-ai-model-option','打开 GPT 网页');open.type='button';open.setAttribute('role','menuitem');open.onclick=()=>this.openSettings();parent.append(open);}
  }
  statusLabel(){const b=this.browser;return b.switching?'切换中':b.refreshJob||b.status==='正在读取网页选项…'?'同步中':b.blocked==='challenge'?'待验证':['login','google'].includes(b.blocked)?'待登录':b.status==='已连接'?'已连接':b.status==='尚未连接'?'未连接':'待检查';}
  renderPicker(parent,{onView}){
    const a=this.ai,b=this.browser,root=a.node('div','et-ai-effort et-ai-web-chat-picker'),head=a.node('div','et-ai-effort-head et-ai-effort-head-status'),back=a.node('button','et-ai-effort-model');back.type='button';back.setAttribute('aria-label','选择模型');back.onclick=()=>onView('models');
    const value=a.node('span','et-ai-effort-value',b.switching?'切换中…':this.label()),model=a.node('span','et-ai-effort-model-row');value.setAttribute('aria-live','polite');model.append(a.node('span','',a.config.webChat?.version||'GPT 网页'));model.insertAdjacentHTML('beforeend','<svg viewBox="0 0 16 16" aria-hidden="true"><path d="m6 4 4 4-4 4"/></svg>');back.append(value,model);head.append(back);
    const label=this.statusLabel(),status=a.node('span','et-ai-web-chat-state',label);status.setAttribute('role','status');status.dataset.state=label==='已连接'?'ready':['同步中','切换中'].includes(label)?'loading':['待验证','待登录','待检查'].includes(label)?'attention':'idle';status.title=b.status;
    const settings=a.node('button','et-ai-effort-reset et-ai-web-chat-settings');settings.type='button';settings.title='查看 GPT 网页';settings.setAttribute('aria-label','GPT 网页设置');settings.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6h9m4 0h3M4 12h3m4 0h9M4 18h10m4 0h2"/><circle cx="15" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="16" cy="18" r="2"/></svg>';settings.onclick=()=>this.openSettings();head.append(status,settings);root.append(head);parent.append(root);
    const rows=b.capabilities.modes;
    if(rows.length){const slider=a.node('div','et-ai-effort-slider'),rail=a.node('div','et-ai-effort-rail'),dots=a.node('div','et-ai-effort-dots'),input=a.node('input','et-ai-effort-range');input.type='range';input.min='0';input.max=String(rows.length-1);input.step='1';input.value=String(Math.max(0,rows.findIndex(r=>r.label===a.config.webChat?.mode)));input.disabled=b.switching||!!b.refreshJob||a.busy;input.setAttribute('aria-label','GPT 网页思考强度');
      rows.forEach((r,i)=>{const dot=a.node('span');dot.style.left=(rows.length===1?50:i/(rows.length-1)*100)+'%';dots.append(dot);});rail.append(dots);slider.append(rail,input);root.append(slider);
      const preview=()=>{const row=rows[Number(input.value)],label=EditingToolbarAIWebChat.labels[row.label]||row.label;value.textContent=label;input.setAttribute('aria-valuetext',row.label);slider.style.setProperty('--effort-ratio',rows.length===1?.5:Number(input.value)/(rows.length-1));slider.dataset.maximum=String(rows.length>1&&Number(input.value)===rows.length-1);};input.oninput=preview;input.onchange=()=>void b.select('mode',rows[Number(input.value)]).catch(e=>a.notice(e.message,true));preview();
    }
    return root;
  }
  async describeFile(file,location='本机文件'){
    const fs=reqnode('fs').promises,path=reqnode('path'),real=await fs.realpath(file),s=await fs.stat(real),name=path.basename(real),ext=path.extname(real).slice(1).toLowerCase();
    if(!EditingToolbarAIWebChat.extensions.includes(ext))throw Error(name+'：不支持的网页附件格式');if(!s.isFile()||s.size>20*1024*1024)throw Error(name+'：请选择不超过 20 MB 的文件');
    return {id:real.toLowerCase(),path:real,name,location,kind:'webfile',bytes:s.size,mime:({md:'text/markdown',markdown:'text/markdown',mdown:'text/markdown',txt:'text/plain',pdf:'application/pdf',docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',csv:'text/csv',json:'application/json',png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',webp:'image/webp'})[ext]};
  }
  async input(request,signal){
    const a=this.ai,Buffer=reqnode('buffer').Buffer,files=[],names=new Set();let total=0;
    const add=(name,type,bytes)=>{name=String(name||'document.md').replace(/[<>:"/\\|?*\r\n]/g,'_');let unique=name,n=1;while(names.has(unique))unique=(n++)+'-'+name;names.add(unique);total+=bytes.length;if(bytes.length>20*1024*1024||total>40*1024*1024)throw Error('本次网页附件超过插件的 40 MB 总量限制或单文件 20 MB 限制');files.push({name:unique,type,base64:bytes.toString('base64')});};
    const base=a.promptsManager.reference(),parts=[];
    if(a.scope.value==='document')add(reqnode('path').basename(a.file()).replace(/^untitled:.*/, '当前文档.md'),'text/markdown',Buffer.from(a.source(),'utf8'));
    else if(base.text)parts.push('以下为所选资料：\n'+base.text);
    if(a.scope.value!=='none'&&!base.text&&!base.image&&a.scope.value!=='document'&&!a.attachments.selected.length)throw Error('当前资料范围没有内容，请重新选择');
    const quotes=a.composerUI.draft.quotes.reference();if(quotes)parts.push(quotes);
    const images=[...(base.image?[base.image]:[]),...(a.composerUI.draft.media?.snapshot()||[])];
    for(const entry of a.attachments.selected){
      if(signal.aborted)throw Object.assign(Error('已停止读取文档'),{name:'AbortError'});
      if(entry.webpage){const loaded=await a.attachments.webLoad(entry,{forRequest:true,profile:{webSearch:false},signal});add(entry.name+'.md','text/markdown',Buffer.from(loaded.text));continue;}
      if(entry.path&&a.attachments.io.key(entry.path)===a.attachments.io.key(a.file())){if(a.scope.value!=='document')add(entry.name,'text/markdown',Buffer.from(a.source()));continue;}
      if(entry.kind==='webfile'){const file=await this.describeFile(entry.path,entry.location),handle=await reqnode('fs').promises.open(file.path,'r');try{const s=await handle.stat();if(s.size>20*1024*1024)throw Error('附件已变大，请重新选择');const bytes=Buffer.alloc(s.size);let offset=0;while(offset<bytes.length){const {bytesRead}=await handle.read(bytes,offset,bytes.length-offset,offset);if(!bytesRead)throw Error('附件读取期间发生变化');offset+=bytesRead;}add(file.name,file.mime,bytes);}finally{await handle.close();}}
      else{const loaded=await a.attachments.load(entry);if(loaded.kind==='image')images.push(loaded);else add(entry.name,'text/markdown',Buffer.from(loaded.text));}
    }
    for(const img of images){const m=String(img.data||'').match(/^data:(image\/[\w.+-]+);base64,(.+)$/);if(!m)throw Error('所选图片没有可上传的文件内容');add(img.name||'图片.png',m[1],Buffer.from(m[2],'base64'));}
    if(files.length>20)throw Error('一次最多上传 20 个文件');
    const skillNames=[...new Set(request.skills?.selected||[])];if(skillNames.length){await a.skillsUI.init();for(const name of skillNames){const skill=await a.skillsUI.store.load(name);parts.push('本次选择的技能说明（用户要求优先；本地脚本不可执行）：\n'+skill.body);}}
    parts.push(request.question);const text=parts.join('\n\n');if(text.length>100000)throw Error('本次消息过长，请将全文作为附件发送或缩小资料范围');
    return {text,files};
  }
  async send(retry,prepared=null){
    const a=this.ai,b=this.browser;if(a.busy||a.settingsBusy||a.attachments.pending||a.composerUI.draft.media?.pending||b.switching||b.refreshJob)return;
    if(!retry&&!prepared&&this.translation.draft)return this.translation.sendDraft();
    if(retry?.webChat?.submitted){b.show();a.notice('这条消息可能已提交，请在网页确认；不会重复发送',true);return;}
    if(!a.followDocument()||(retry&&a.turns.at(-1)!==retry))return;const request=prepared?.request||(retry?{question:retry.question,displayQuestion:retry.displayQuestion,command:retry.command}:a.composerUI.request());if(!request.question)return;
    const context=a.context,controller=a.controller=new AbortController();this.running=true;a.requestSource={context,controller,ready:false};a.busyState(true);let turn;
    try{
      if(!a.config.webChat?.mode)throw Error('请先在模型菜单同步网页选项，再发送消息');
      // Capture bytes before clearing the draft. Retries and restored history
      // must keep this message's attachments, not re-read a different document.
      if(retry&&!retry.webChat?.input)throw Error('旧消息没有附件快照，请重新添加原附件后发送');
      const projectTarget=retry?retry.webChat.projectTarget:prepared?.target||this.projects.target();
      const input=prepared?.input||(retry?retry.webChat.input:await this.input(request,controller.signal));if(a.file()!==context.file||controller.signal.aborted)throw Error('文档已切换或发送已取消');
      const previous=[...a.turns].reverse().find(t=>t.webChat?.url&&!t.webChat.projectTarget&&/^https:\/\/chatgpt\.com\/c\//.test(t.webChat.url));
      turn={id:reqnode('crypto').randomUUID(),question:request.question,displayQuestion:request.displayQuestion,command:request.command,answer:'',status:'running',file:context.file,source:retry?.source??a.source(),selected:context.selected,requestContext:retry?.requestContext||{quotes:a.composerUI.draft.quotes.snapshot?.()||[]},model:'GPT 网页 · '+this.label(),reference:retry?.reference??a.scope.value,editMode:false,time:retry?.time||new Date().toISOString(),webChat:{submitted:false,mode:a.config.webChat.mode,version:a.config.webChat.version,input}};
      Object.assign(turn.webChat,{projectTarget,translationJob:prepared?.job?.id||retry?.webChat.translationJob});
      if(retry){a.turns.pop();retry.article.remove();}a.turns.push(turn);EditingToolbarAITiming.begin(turn);a.mountTurn(turn);if(!retry&&(!prepared||prepared.fromDraft))a.composerUI.consumed();a.conversations.flush();
      const result=await b.request({...input,id:turn.id,conversation:retry?.webChat.url||previous?.webChat.url,projectTarget,expected:{...a.config.webChat},signal:controller.signal,...this.replyCallbacks(turn)});
      turn.answer=result.text;turn.status='done';turn.detail='完成';turn.webChat.url=result.url;this.translation.bind(turn);
    }catch(e){if(turn){turn.status=e.name==='AbortError'?'stopped':'error';turn.detail=e.message;if(e.webSubmitted)turn.webChat.submitted=true;}a.notice(e.message,e.name!=='AbortError',!!turn);if(!turn)b.show();}
    finally{this.running=false;a.controller=null;a.requestSource=null;if(turn){ETAIExecution.finish(turn);EditingToolbarAITiming.finish(turn);a.renderTurn(turn);a.conversations.flush();}a.busyState(false);this.refreshUI();}
  }
  replyCallbacks(turn){
    const a=this.ai,activityCache=new Map(),changed=()=>{a.scheduleRender(turn);a.conversations.schedule();};
    return {onTiming:timing=>{turn.webChat.timings={...(turn.webChat.timings?.startedAt===timing.startedAt?turn.webChat.timings:{}),...timing};},onProgress:text=>{turn.detail=text;ETAIExecution.put(turn,{id:'web-progress',type:'progress',status:'running',text,startedAt:Date.now()});changed();},
      onActivity:(rows,busy)=>{let updated=false;for(const [i,row] of rows.entries()){const old=turn.execution?.find(e=>e.id===row.id),status=busy&&i===rows.length-1?'running':'success',kind=row.kind==='commentary'?'web-commentary':row.kind==='step'?'web-step':'web-visible',cached=activityCache.get(row.id),text=row.html?(cached?.html===row.html?cached.text:ETAIWebChatFormat.markdown(row.html)):row.text;if(row.html)activityCache.set(row.id,{html:row.html,text});if(old?.text===text&&old.status===status&&old.kind===kind&&old.name===row.name)continue;ETAIExecution.put(turn,{id:row.id,type:'progress',kind,name:row.name,text,status});updated=true;}if(updated)changed();},
      onText:text=>{turn.answer=text;changed();},onBinding:binding=>{Object.assign(turn.webChat,binding);this.projects.bind(turn.webChat.projectTarget,binding);this.translation.bind(turn);a.conversations.flush();}};
  }
  canResume(turn){return !!(turn?.webChat?.submitted&&turn.webChat.url&&turn.webChat.input?.text&&['error','stopped'].includes(turn.status));}
  resumePending(){
    const a=this.ai,turn=a.turns.at(-1);if(a.busy||a.panel?.hidden||!this.active()||!this.canResume(turn)||turn.status==='stopped'&&!/上次生成被中断/.test(turn.detail||''))return;
    this.resumedIds ||=new Set();if(this.resumedIds.has(turn.id))return;this.resumedIds.add(turn.id);void this.resume(turn);
  }
  async resume(turn){
    const a=this.ai,b=this.browser;if(a.busy||b.switching||b.refreshJob||!this.canResume(turn)||!a.turns.includes(turn))return;
    const controller=a.controller=new AbortController();this.running=true;a.requestSource={context:a.context,controller,ready:false};turn.status='running';turn.detail='正在恢复网页回答';EditingToolbarAITiming.begin(turn,{resume:true});a.busyState(true);a.renderTurn(turn);
    try{const result=await b.resumeReply(turn.webChat,{signal:controller.signal,...this.replyCallbacks(turn)});turn.answer=result.text;turn.status='done';turn.detail='完成';turn.webChat.url=result.url;this.translation.bind(turn);}
    catch(e){turn.status=e.name==='AbortError'?'stopped':'error';turn.detail=e.name==='AbortError'?'已停止本地接收，原消息不会重新发送':e.message;}
    finally{this.running=false;a.controller=null;a.requestSource=null;ETAIExecution.finish(turn);EditingToolbarAITiming.finish(turn);a.renderTurn(turn);a.conversations.flush();a.busyState(false);this.refreshUI();}
  }
  renderRecovery(turn){
    if(!turn.webChat)return;
    if(!turn.webRecovery){const b=this.ai.node('button','et-ai-web-chat-recover','继续接收网页回答');b.type='button';b.title='读取这条消息对应的网页回答，不会重新发送消息或附件';b.onclick=()=>void this.resume(turn);turn.webErrorNode.after(b);turn.webRecovery=b;}
    turn.webRecovery.hidden=!this.canResume(turn);turn.webRecovery.disabled=!!this.ai.busy;
  }
  previewOptions(turn){
    const base=this.ai.referencesUI.options(turn),translation=this.translation;
    return {...base,decorateLink:(node,url)=>translation.link(node,url,turn)||base.decorateLink?.(node,url),afterRender:host=>{base.afterRender?.(host);translation.decorateAnswer(turn,host);const timing=turn.webChat.timings;if(turn.answer&&timing&&timing.firstRenderedMs===undefined)timing.firstRenderedMs=Date.now()-timing.startedAt;}};
  }
  decorate(turn){
    if(!turn.webChat||turn.actions.querySelector('[data-web-chat-open]'))return;const a=this.ai,b=a.conversations.button('查看 GPT 网页','chat',async()=>{if(a.busy&&!this.running)throw Error('请等待当前任务完成');if(!this.running&&turn.webChat.url)await this.browser.conversation(turn.webChat.url);this.browser.show();});b.dataset.webChatOpen='true';turn.actions.append(b);

  }
}
