'use strict';
const fs=require('node:fs'),path=require('node:path'),esbuild=require('esbuild');
module.exports=()=>{
 const read=f=>fs.readFileSync(path.join(__dirname,f),'utf8');
 const core=[['ETTerminalSession','terminal-session.cjs'],['ETTerminalCommand','terminal-command.cjs'],['ETTerminalTranscript','terminal-transcript.cjs'],['ETCodeStore','code-document-store.cjs'],['ETCodeSchemes','code-color-schemes.cjs'],['ETNotebookKernel','notebook-kernel.cjs']].map(([name,file])=>'const '+name+'=(()=>{const module={exports:{}};'+read(file)+';return module.exports;})();').join('\n');
 const vendor=esbuild.buildSync({entryPoints:[path.join(__dirname,'terminal-vendor.js')],bundle:true,format:'iife',globalName:'ETTerminalVendor',minify:true,write:false,legalComments:'inline'}).outputFiles[0].text;
 const python=esbuild.buildSync({entryPoints:[path.join(__dirname,'python-environments.cjs')],bundle:true,platform:'browser',format:'iife',globalName:'ETPythonManager',write:false}).outputFiles[0].text;
 return core+'\n'+python+'\n'+read('ai-python-settings.js')+'\nconst ET_TERMINAL_VENDOR='+JSON.stringify(vendor)+';\nconst ET_TERMINAL_CSS='+JSON.stringify(read('node_modules/@xterm/xterm/css/xterm.css'))+';\n'+['document-projects.js','terminal-panel.js','code-editor.js','code-editor-style.js','code-editor-review.js','notebook-editor.js','notebook-integration.js','ai-workspace-lifecycle.js'].map(read).join('\n');
};
