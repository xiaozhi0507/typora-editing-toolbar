// This surface never creates a conversation store or writes transcripts/drafts.
class EditingToolbarAITemporary {
  constructor(ai) {this.ai=ai;this.turns=[];this.generation=0;window.addEventListener('unload',()=>this.close());}
  node(tag,cls,text) {return this.ai.node(tag,cls,text);}
  button(label,icon,fn) {return this.ai.conversations.button(label,icon,fn);}
  error(e) {this.status.textContent=e.message;this.status.hidden=false;}
  mount() {
    const d=this.dialog=this.node('dialog','et-ai-temporary');d.setAttribute('aria-label','临时聊天');
    const head=this.node('div','et-ai-temporary-head');head.append(this.node('h2','','临时聊天'),this.node('small','','关闭后不保留'));
    this.closeButton=this.button('关闭临时聊天','close',()=>this.close());head.append(this.closeButton);
    this.messages=this.node('div','et-ai-temp-messages');this.messages.setAttribute('aria-label','临时聊天内容');this.following=true;this.messages.addEventListener('wheel',e=>{if(e.deltaY<0)this.following=false;},{passive:true});this.messages.addEventListener('scroll',()=>{const m=this.messages;if(m.scrollHeight-m.scrollTop-m.clientHeight<8)this.following=true;else if(this.lastHeight===m.scrollHeight)this.following=false;this.lastHeight=m.scrollHeight;},{passive:true});this.messages.addEventListener('keydown',e=>{if(['ArrowUp','PageUp','Home'].includes(e.key))this.following=false;});this.empty=this.node('div','et-ai-temp-empty');this.empty.innerHTML=EditingToolbarAIQuotes.icon;this.empty.append(this.node('strong','','就这段文字聊一聊'),this.node('span','','聊天内容不会保存到历史记录'));this.messages.append(this.empty);
    this.composer=this.node('div','et-ai-temp-composer');this.prompt=this.node('textarea');this.prompt.rows=1;this.prompt.placeholder='问点什么…';this.prompt.setAttribute('aria-label','临时聊天问题');this.composer.append(this.prompt);
    this.quotes=new EditingToolbarAIQuotes(this,()=>this.sync());this.quotes.mount(this.prompt);this.media=new EditingToolbarAIInputMedia(this.ai,()=>{this.status.hidden=true;this.sync();},this);this.media.mount(this.prompt);
    const controls=this.node('div','et-ai-temp-controls');this.model=this.button('临时聊天模型',null,()=>this.openModels());this.model.className='et-ai-temp-model';this.model.setAttribute('aria-haspopup','dialog');this.model.setAttribute('aria-expanded','false');
    this.sendButton=this.button('发送临时问题',null,()=>this.send());this.sendButton.className='et-ai-temp-send';this.sendButton.innerHTML=EditingToolbarAIComposer.arrow;
    this.stopButton=this.button('停止临时回答',null,()=>this.controller?.abort());this.stopButton.innerHTML='<svg viewBox="0 0 24 24"><rect x="7" y="7" width="10" height="10" rx="2"/></svg>';this.stopButton.className='et-ai-temp-stop';this.stopButton.hidden=true;
    this.shellButton=this.node('button','et-ai-temp-shell');this.shellButton.type='button';this.shellButton.innerHTML=this.ai.shellUI.icon();this.shellButton.onclick=()=>this.ai.shellUI.toggle('temporary');controls.append(this.shellButton,this.model,this.sendButton,this.stopButton);this.composer.append(controls);this.status=this.node('div','et-ai-temp-status');this.status.hidden=true;this.status.setAttribute('role','status');d.append(head,this.messages,this.status,this.composer);document.body.append(d);
    this.modelMenu=this.node('div','et-ai-temp-model-menu');this.modelMenu.setAttribute('popover','manual');this.modelMenu.setAttribute('role','dialog');this.modelMenu.setAttribute('aria-label','临时聊天模型');document.body.append(this.modelMenu);
    this.prompt.oninput=()=>{this.status.hidden=true;this.sync();};EditingToolbarAIComposer.bindPromptKeys(this.prompt,()=>this.send());
    for(const type of ['mousedown','mouseup','keydown','keyup','input','paste','copy','cut','drop'])d.addEventListener(type,e=>{this.ai.toolbar.hide();e.stopPropagation();});
    d.addEventListener('cancel',e=>{e.preventDefault();this.close();});d.addEventListener('keydown',e=>{if(e.key==='Escape'&&!this.motion.drag){e.preventDefault();if(this.modelMenu.matches(':popover-open'))this.closeModels();else this.close();}});
    this.motion=new EditingToolbarAIConversationMotion(this,head);this.motion.state=()=>this.geometry||{width:460,height:530};this.motion.save=g=>{this.geometry=g;};this.motion.mount();
    document.addEventListener('pointerdown',e=>{if(!this.modelMenu.contains(e.target)&&!this.model.contains(e.target))this.closeModels();},true);
    window.addEventListener('resize',()=>{this.closeModels();this.sync();});window.addEventListener('blur',()=>this.closeModels());
    this.modelMenu.addEventListener('focusout',e=>{if(e.relatedTarget&&!this.modelMenu.contains(e.relatedTarget)&&!this.model.contains(e.relatedTarget))this.closeModels();});
    this.modelMenu.onkeydown=e=>EditingToolbarAIEffort.keydown(e,this.modelMenu,{onBack:this.profile()?()=>this.showModelView('effort'):null,onClose:()=>{this.closeModels();this.model.focus();}});
  }
  profile() {const p=this.profileId?this.ai.config.profiles.find(p=>p.id===this.profileId):this.ai.profile();if(!p||p.authType==='chatgpt-web')return null;const model=p.model,key=p.id+'\0'+model;return {...p,model,...(model!==p.model?{modelLabel:model}:{}),...(this.efforts?.has(key)?{reasoningEffort:this.efforts.get(key)}:{})};}
  open(item) {
    if(!this.dialog)this.mount();if(!this.dialog.open){this.file=item?.file||this.ai.file();const selected=this.ai.profile()?.authType==='chatgpt-web'?this.ai.config.profiles[0]:this.ai.profile();this.profileId=selected?.id;this.modelId=selected?.model;this.efforts=new Map(this.ai.modelProfiles().filter(p=>p.authType!=='chatgpt-web').map(p=>[p.id+'\0'+p.model,ETAIClient.effortValue(p)]));this.dialog.show();this.motion.layout();}
    if(item)this.quotes.add(item);this.sync();this.prompt.focus();
  }
  close() {
    if(!this.dialog)return;this.generation++;this.controller?.abort();this.controller=null;this.busy=false;this.closeModels();this.motion.finish(true);this.quotes.clear();this.media.clear();this.prompt.value='';for(const turn of this.turns){clearTimeout(turn.timer);EditingToolbarAITiming.finish(turn);}this.turns=[];this.efforts?.clear();this.messages.replaceChildren(this.empty);this.empty.hidden=false;this.status.textContent='';this.status.hidden=true;this.dialog.close();this.ai.shellUI.closeTemporary();this.sync();
  }
  sync() {
    if(!this.dialog)return;this.ai.shellUI.sync();this.quotes.sync();this.media.sync();this.prompt.disabled=!!this.busy;this.model.disabled=!!this.busy;this.sendButton.hidden=!!this.busy;this.stopButton.hidden=!this.busy;this.sendButton.disabled=this.busy||this.media.pending||!this.prompt.value.trim();
    this.model.replaceChildren(this.node('span','',EditingToolbarAIEffort.modelName(this.profile())));const effort=EditingToolbarAIEffort.label(this.profile()||{});if(effort)this.model.append(this.node('span','et-ai-model-effort',effort));this.model.insertAdjacentHTML('beforeend',EditingToolbarAIComposer.chevron);
    cancelAnimationFrame(this.resizeFrame);this.resizeFrame=requestAnimationFrame(()=>this.resizeComposer());
  }
  resizeComposer() {
    if(!this.dialog.open)return;
    const height=this.dialog.clientHeight,tray=this.media.tray,box=this.composer,spacing=getComputedStyle(box),list=getComputedStyle(this.messages);
    const gap=(parseFloat(spacing.marginTop)||0)+(parseFloat(spacing.marginBottom)||0)+(parseFloat(list.paddingTop)||0)+(parseFloat(list.paddingBottom)||0);
    const available=height-this.dialog.querySelector('.et-ai-temporary-head').getBoundingClientRect().height-this.status.getBoundingClientRect().height-gap-Math.min(100,Math.max(0,height-330));
    this.prompt.style.height='34px';tray.style.maxHeight=(height>=440?186:88)+'px';
    if(!tray.hidden){const room=available-box.getBoundingClientRect().height+tray.getBoundingClientRect().height;tray.style.maxHeight=Math.max(0,Math.min(height>=440?186:88,room))+'px';}
    const promptRoom=Math.max(34,Math.min(130,34+available-box.getBoundingClientRect().height));this.prompt.style.height=Math.min(Math.max(34,this.prompt.scrollHeight),promptRoom)+'px';
  }
  openModels() {
    if(this.modelMenu.matches(':popover-open'))return this.closeModels();
    this.modelView='effort';this.renderModels();this.modelMenu.showPopover();this.model.setAttribute('aria-expanded','true');this.ai.chatgptUI.schedulePickerModels();
    EditingToolbarAIEffort.position(this.modelMenu,this.model);EditingToolbarAIEffort.focus(this.modelMenu);
  }
  renderModels(){
    EditingToolbarAIEffort.render(this.ai,this.modelMenu,{profiles:this.ai.modelProfiles().filter(p=>p.authType!=='chatgpt-web'),profile:this.profile(),view:this.modelView||'effort',
      onView:view=>this.showModelView(view),
      onModel:p=>{this.profileId=p.id;this.modelId=p.model;this.sync();this.showModelView('effort');},
      onChange:effort=>{const p=this.profile();if(!p)return;this.efforts.set(p.id+'\0'+p.model,effort);this.sync();}
    });
    if(this.modelMenu.matches(':popover-open'))EditingToolbarAIEffort.position(this.modelMenu,this.model);
  }
  showModelView(view){this.modelView=view;this.renderModels();EditingToolbarAIEffort.focus(this.modelMenu);}
  closeModels() {if(this.modelMenu?.matches(':popover-open'))this.modelMenu.hidePopover();this.model?.setAttribute('aria-expanded','false');}
  render(turn) {
    if(!turn.article.isConnected)return;EditingToolbarAITiming.update(turn);
    const m=this.ai.toolbar.annotations;
    turn.executionUI?.update();turn.reasoningUI?.update();turn.answerNode.hidden=!!turn.execution?.length&&!turn.answer&&turn.status==='running';
    const previewText=turn.answer||(turn.status==='running'?'正在思考…':ETAIExecution.emptyAnswer(turn));if(!turn.answerNode.hidden&&(turn.previewText!==previewText||turn.previewStatus!==turn.status)){turn.previewText=previewText;turn.previewStatus=turn.status;const serial=turn.serial=(turn.serial||0)+1;
    try{m._ensureRenderer().renderPreview(turn.answerNode,previewText,{...this.ai.referencesUI.options(turn,this.turns,this.context?.file),isCurrent:()=>turn.article.isConnected&&turn.serial===serial,renderMath:(tex,display)=>m._renderMath(tex,display),openLink:url=>{if(/^https?:\/\//i.test(url))reqnode('electron').shell.openExternal(url);}});}catch{turn.answerNode.textContent=turn.answer;}}
    this.followLatest();
  }
  followLatest(){if(this.following){this.messages.scrollTop=this.messages.scrollHeight;this.lastHeight=this.messages.scrollHeight;}}
  async send() {
    const question=this.prompt.value.trim();if(this.busy||this.media.pending||!question)return;const selected=this.profile();if(!selected){this.error(Error('请先在 AI 助手顶部设置中配置模型'));return;}
    const project=this.ai.webUI.defaultProject(),profile={...selected,documentEdit:false,webSearch:false,shellScope:'temporary',project};profile.shellGrant=this.ai.shellUI.capture(project,profile);profile.shellEnabled=!!profile.shellGrant;if(!profile.shellEnabled)profile.project=null;
    const submittedAt=new Date().toISOString(),generation=this.generation,quotes=this.quotes.snapshot(),images=this.media.snapshot(),reference=quotes.length||images.length?{text:this.quotes.reference(),label:'临时聊天资料',quotes,images}:undefined;
    let turn;
    try{
      await this.ai.skillsUI?.configure(profile,{selected:ETAISkills.mentions(question)});
      const messages=ETAIClient.messages(profile,{text:'',label:''},this.turns,question,reference);
      ETAIClient.body(profile,messages);ETAIClient.endpoint(profile.url,profile.protocol,profile.fullUrl);this.busy=true;this.closeModels();this.status.hidden=true;this.controller=new AbortController();this.sync();const key=await this.ai.keyFor(profile);if(generation!==this.generation)return;
      this.following=true;turn={question,time:submittedAt,answer:'',status:'running',model:profile.model,file:this.file,requestContext:reference};EditingToolbarAITiming.begin(turn);this.turns.push(turn);this.empty.hidden=true;turn.article=this.node('article','et-ai-temp-turn');EditingToolbarAIQuotes.renderSent(this,turn.article,turn);this.media.renderSent(turn.article,turn);turn.article.append(this.node('div','et-ai-temp-question',question),this.ai.conversations.questionFooter(turn));turn.meta=this.node('small','et-ai-answer-meta');turn.answerNode=this.node('div','et-ai-answer');turn.article.append(turn.meta,turn.answerNode);this.messages.append(turn.article);turn.executionUI=new EditingToolbarAIExecution(this.ai,turn,turn.answerNode);turn.reasoningUI=new EditingToolbarAIReasoning(this.ai,turn,turn.answerNode);this.prompt.value='';this.quotes.clear();this.media.clear();this.sync();EditingToolbarAITiming.watch(turn);this.render(turn);
      const changed=()=>{if(!turn.timer)turn.timer=setTimeout(()=>{turn.timer=null;if(generation===this.generation)this.render(turn);},100);};
      const options={temporary:true,signal:this.controller.signal,execution:turn,onExecution:()=>{if(generation===this.generation){changed();}},sanitize:this.ai.shellUI.sanitizer(key),shellKey:key};
      const result=(profile.shellEnabled||profile.skillsEnabled)?await this.ai.editUI.run(profile,key,messages,options,turn):await this.ai.request(profile,key,messages,options);
      if(generation!==this.generation)return;turn.answer=result.text;turn.status='done';
    }catch(e){if(generation!==this.generation)return;if(turn)turn.status=e.name==='AbortError'?'stopped':'error';if(e.name!=='AbortError')this.error(e);}
    finally{if(turn){ETAIExecution.finish(turn);EditingToolbarAITiming.finish(turn);}if(generation===this.generation){this.busy=false;this.controller=null;if(turn){clearTimeout(turn.timer);this.render(turn);}this.sync();}}
  }
}
