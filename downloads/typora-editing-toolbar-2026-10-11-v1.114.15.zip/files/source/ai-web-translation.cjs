'use strict';
class WebTranslation {
  static skill='文献PDF转markdown skill.md';
  constructor(store,managed,zip){this.store=store;this.managed=managed;this.zip=zip;this.io=store.io;this.path=store.path;this.root=this.path.join(store.root,'web-translations');}
  hash(data){return this.store.crypto.createHash('sha256').update(data).digest('hex');}
  check(signal){if(signal?.aborted)throw Object.assign(Error('已停止全文翻译'),{name:'AbortError'});}
  folder(id){if(!/^[a-f0-9-]{36}$/.test(id))throw Error('翻译任务标识无效');return this.path.join(this.root,id);}
  async save(job){const folder=this.folder(job.id);await this.io.mkdir(folder,{recursive:true});const file=this.path.join(folder,'job.json'),tmp=file+'.tmp';await this.io.writeFile(tmp,JSON.stringify(job,null,2));await this.io.rename(tmp,file);}
  async read(id){return JSON.parse(await this.io.readFile(this.path.join(this.folder(id),'job.json'),'utf8'));}
  async jobs(){let dirs;try{dirs=await this.io.readdir(this.root,{withFileTypes:true});}catch(e){if(e.code==='ENOENT')return [];throw e;}const jobs=[];for(const d of dirs)if(d.isDirectory()&&/^[a-f0-9-]{36}$/.test(d.name)){try{jobs.push(await this.read(d.name));}catch{}}return jobs;}
  safeName(name){if(typeof name!=='string'||!name||name.length>500||/[\\:\x00-\x1f]/.test(name)||name.startsWith('/')||name.split('/').some(p=>!p||p==='.'||p==='..'||/[. ]$/.test(p)||/^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(p)))throw Error('压缩包包含不安全的文件路径');return name;}
  async candidate(file,source,selectedId,translation){
    if(!selectedId)return translation.locate(this.store,file,source);
    const snapshot=await this.store.read(),item=snapshot?.data.items.find(i=>i.id===selectedId&&!i.deleted);if(!item||!['paper','thesis'].includes(item.type))throw Error('请选择知识库中的英文论文条目');
    const refs=(item.files||[]).filter(f=>f.linkType!=='url'&&!f.webTranslationId&&!/中文|译稿|翻译/.test(f.name));refs.sort((a,b)=>Number(b.id===item.defaultFile)-Number(a.id===item.defaultFile));
    for(const ref of refs.filter(f=>/\.(md|markdown|mdown)$/i.test(f.path))){const target=this.store.resolveFile(ref),s=await this.managed.regular(target);if(s.size>16*1024*1024)continue;const text=this.path.resolve(target).toLowerCase()===this.path.resolve(file).toLowerCase()?source:await this.io.readFile(target,'utf8');if(translation.english(text))return {item,ref,libraryId:snapshot.data.libraryId,file:target,source:text};}
    const ref=refs.find(f=>/\.pdf$/i.test(f.path));if(!ref)throw Error('选中条目没有英文 Markdown 或原始 PDF 附件');return {item,ref,libraryId:snapshot.data.libraryId,file:this.store.resolveFile(ref),source:null};
  }
  async prepare(candidate,target,{signal}={}){
    this.check(signal);if(!target?.enabled||!target.project?.url)throw Error('请先在项目模式中选择项目和聊天');
    const source=await this.io.readFile(candidate.file);if(typeof candidate.source==='string'&&source.toString('utf8').replace(/\r\n?/g,'\n')!==candidate.source.replace(/\r\n?/g,'\n'))throw Error('英文原稿有未保存修改，请先保存');
    const plan=await this.managed.plan(candidate.ref,{signal,includeNotes:false}),files=Object.create(null),manifest=[];let total=0;
    const add=async(file,name)=>{this.check(signal);this.safeName(name);await this.managed.regular(file);const bytes=await this.io.readFile(file);total+=bytes.length;if(total>40*1024*1024||manifest.length>=1000)throw Error('本次文献资源超过 40 MB 或 1000 个文件，请拆分后处理');if(files[name])throw Error('文献包文件名重复');files[name]=new Uint8Array(bytes);manifest.push({path:name,sha256:this.hash(bytes),bytes:bytes.length});};
    for(const f of plan.files){const st=await this.io.stat(f.file);if(st.size!==f.bytes||st.mtimeMs!==f.mtime)throw Error('打包时文献资源发生变化');await add(f.file,'source/'+this.path.relative(plan.base,f.file).replaceAll('\\','/'));}
    // Include explicit original attachments and their relative resources, never private note sidecars or previous translations.
    const included=new Set(plan.files.map(f=>this.path.resolve(f.file).toLowerCase()));
    for(const ref of candidate.item.files||[])if(ref.linkType!=='url'&&!ref.webTranslationId&&!/中文|译稿|翻译/.test(ref.name)&&/\.(pdf|md|markdown|mdown|txt|csv|json|png|jpe?g|webp|gif)$/i.test(ref.path)){
      const file=this.store.resolveFile(ref);if(included.has(this.path.resolve(file).toLowerCase()))continue;const extra=await this.managed.plan(ref,{signal,includeNotes:false});for(const f of extra.files){await add(f.file,'attachments/'+ref.id+'/'+this.path.relative(extra.base,f.file).replaceAll('\\','/'));included.add(this.path.resolve(f.file).toLowerCase());}
    }
    const id=this.store.crypto.randomUUID(),job={version:1,id,created:new Date().toISOString(),state:'prepared',libraryId:candidate.libraryId,itemId:candidate.item.id,refId:candidate.ref.id,refPath:candidate.ref.path,title:candidate.item.title,source:candidate.file,sourceSha256:this.hash(source),target,main:'source/'+this.path.relative(plan.base,candidate.file).replaceAll('\\','/'),files:manifest,resultName:'translation-'+id+'.zip'};
    files['translation-request.json']=new TextEncoder().encode(JSON.stringify({taskId:id,main:job.main,sourceSha256:job.sourceSha256,skill:WebTranslation.skill,files:manifest},null,2));
    const bytes=this.zip.zipSync(files,{level:1});if(bytes.length>20*1024*1024)throw Error('打包后超过网页单附件 20 MB 限制，请拆分文献');
    await this.save(job);await this.io.writeFile(this.path.join(this.folder(id),'source.zip'),bytes,{flag:'wx'});
    return {job,input:{text:this.prompt(job),files:[{name:'source-'+id+'.zip',type:'application/zip',base64:this.store.fs.readFileSync(this.path.join(this.folder(id),'source.zip')).toString('base64')}]}};
  }
  prompt(job){
    const pdfs=job.files.filter(f=>/\.pdf$/i.test(f.path)),images=job.files.filter(f=>/\.(png|jpe?g|webp|gif|svg)$/i.test(f.path));
    const sourceInfo=pdfs.length?'包内含 '+pdfs.length+' 份 PDF：'+pdfs.map(f=>f.path).join('、')+'。':'本包没有原始 PDF。请以包内英文 Markdown 为翻译依据，并在译稿中简要注明未进行原 PDF 逐页复核；不要为寻找缺失 PDF 反复搜索网页或空间。';
    return '请调用当前空间已上传的《'+WebTranslation.skill+'》，完整翻译附件中的英文文献，不要再次索取或上传技能文件。读取技能并解压一次，按 translation-request.json 核对输入；若无法访问技能、解压或生成 ZIP，请说明限制并停止。\n\n主文档：'+job.main+'。'+sourceInfo+' 包内含 '+images.length+' 张原图；其余附件以清单为准。完整翻译正文、图表说明和附录，保留参考文献、可编辑 LaTeX、可编辑三线表（顶线、表头底线、底线，无竖线和逐行网格）、链接及原图，不得以摘要代替全文。保持资源相对路径。已有 Markdown 时直接使用，不重复 OCR；技能要求的外部信息只作必要的定向核对，找不到即注明，不扩展成文献调研。\n\n中文主文件命名为 中文翻译.md，集中完成章节、公式、表格、图片及相对链接检查后再打包一次；引用索引的路径与行号按最终译稿生成；documents[0].table_style 和每个 kind=table 目标的 table_style 均设为 three-line，包含补充材料中的表格。生成 '+job.resultName+'，含中文主文件、资源和 translation-result.json：{"taskId":"'+job.id+'","sourceSha256":"'+job.sourceSha256+'","markdown":"中文翻译.md","complete":true}。仅全文完成才标记 complete:true。最后用简短说明和 Markdown 超链接提供 ZIP 下载，不在聊天中重复整篇译文。';
  }
  // Validate the central directory BEFORE allocating decompressed entry buffers.
  inspect(bytes){
    const b=bytes;if(b.length>60*1024*1024)throw Error('下载包超过 60 MB');let end=-1;for(let i=b.length-22;i>=Math.max(0,b.length-65557);i--)if(b.readUInt32LE(i)===0x06054b50&&i+22+b.readUInt16LE(i+20)===b.length){end=i;break;}
    if(end<0||b.readUInt16LE(end+4)||b.readUInt16LE(end+6))throw Error('不支持的 ZIP 格式');
    const count=b.readUInt16LE(end+10),size=b.readUInt32LE(end+12),offset=b.readUInt32LE(end+16);if(count!==b.readUInt16LE(end+8)||!count||count>1500||offset+size!==end)throw Error('压缩包目录异常或文件过多');
    let at=offset,total=0;const entries=[],seen=new Set();for(let n=0;n<count;n++){
      if(at+46>end||b.readUInt32LE(at)!==0x02014b50)throw Error('压缩包目录损坏');const flags=b.readUInt16LE(at+8),method=b.readUInt16LE(at+10),compressed=b.readUInt32LE(at+20),length=b.readUInt32LE(at+24),nl=b.readUInt16LE(at+28),xl=b.readUInt16LE(at+30),cl=b.readUInt16LE(at+32),local=b.readUInt32LE(at+42),attrs=b.readUInt32LE(at+38),next=at+46+nl+xl+cl;
      if(next>end||flags&1||![0,8].includes(method)||(attrs>>>16&0xf000)===0xa000||local>=offset)throw Error('不支持加密、链接或异常 ZIP 条目');
      // Some Unix ZIP writers store UTF-8 names without setting bit 11. Decode once,
      // strictly, and use these same validated names for extraction and receipts.
      const rawName=b.subarray(at+46,at+46+nl);let name;try{name=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(rawName);}catch{throw Error('ZIP 文件名编码不受支持，请使用 UTF-8 重新打包');}
      const directory=name.endsWith('/');this.safeName(directory?name.slice(0,-1):name);const key=name.toLowerCase();if(seen.has(key))throw Error('压缩包文件名重复');seen.add(key);
      total+=length;if(length>40*1024*1024||total>120*1024*1024||length>Math.max(1024*1024,compressed*500))throw Error('解压后大小或压缩比例异常');
      if(local+30>offset||b.readUInt32LE(local)!==0x04034b50||b.readUInt16LE(local+8)!==method||b.readUInt16LE(local+6)!==flags)throw Error('ZIP 本地目录不一致');
      const ln=b.readUInt16LE(local+26),lx=b.readUInt16LE(local+28),dataOffset=local+30+ln+lx;if(!b.subarray(local+30,local+30+ln).equals(rawName)||dataOffset+compressed>offset)throw Error('ZIP 文件路径或长度不一致');
      entries.push({name,length,directory,crc:b.readUInt32LE(at+16),method,compressed,dataOffset});at=next;
    }if(at!==end)throw Error('ZIP 目录长度不一致');return entries;
  }
  crc(bytes){let c=0xffffffff;for(const n of bytes){c^=n;for(let i=0;i<8;i++)c=(c>>>1)^((c&1)?0xedb88320:0);}return (c^0xffffffff)>>>0;}
  unpack(bytes){
    const entries=this.inspect(bytes),unpacked=Object.create(null);
    for(const e of entries){
      const packed=bytes.subarray(e.dataOffset,e.dataOffset+e.compressed);let data;
      try{data=e.method===0?new Uint8Array(packed):this.zip.inflateSync(packed,{out:new Uint8Array(e.length)});}catch{throw Error('ZIP 数据损坏，无法解压：'+e.name);}
      if(data.length!==e.length||this.crc(data)!==e.crc)throw Error('ZIP 内容校验失败：'+e.name);
      unpacked[e.name]=data;
    }
    return {entries,unpacked};
  }
  async cachedDownload(job,excluded=new Set()){
    const folder=this.folder(job.id);let names;try{names=await this.io.readdir(folder);}catch(e){if(e.code==='ENOENT')return null;throw e;}
    const candidates=[];for(const name of names){if(!/^download-[a-f0-9-]{36}\.zip$/.test(name))continue;const file=this.path.join(folder,name);if(excluded.has(file))continue;try{const st=await this.managed.regular(file);if(st.isFile()&&st.size>0&&st.size<=60*1024*1024)candidates.push({file,mtime:st.mtimeMs});}catch{}}
    return candidates.sort((a,b)=>b.mtime-a.mtime)[0]?.file||null;
  }

  static contentIdentity(text){return String(text).replace(/\r\n?/g,'\n').replace(/<img\b[^>]*>/gi,tag=>tag.replace(/\s+style\s*=\s*(["'])(.*?)\1/gi,(_attr,quote,css)=>{const rest=css.split(';').map(x=>x.trim()).filter(x=>x&&!/^(width|height|zoom)\s*:/i.test(x)).join(';');return rest?' style='+quote+rest+quote:'';}));}
  async validateSource(job){
    const current=await this.io.readFile(job.source);if(this.hash(current)===job.sourceSha256)return;
    if(/\.(md|markdown|mdown)$/i.test(job.source)){
      try{const packed=await this.io.readFile(this.path.join(this.folder(job.id),'source.zip')),original=this.unpack(packed).unpacked[job.main];if(original&&this.hash(original)===job.sourceSha256&&WebTranslation.contentIdentity(current.toString('utf8'))===WebTranslation.contentIdentity(new TextDecoder().decode(original)))return;}catch{}
    }
    throw Error('英文原稿已改变，下载包保留，请核对后重新翻译');
  }
  async import(job,file){
    const snapshot=await this.store.read();if(snapshot?.data.libraryId!==job.libraryId)throw Error('翻译任务与当前知识库不匹配');
    const item=snapshot.data.items.find(i=>i.id===job.itemId);if(!item?.files.some(f=>f.id===job.refId&&f.path===job.refPath))throw Error('原文献条目或附件已变更，未归档');
    const existing=item.files.find(f=>f.webTranslationId===job.id);if(existing){const output=this.store.resolveFile(existing);Object.assign(job,{state:'imported',output});await this.save(job);return {ref:existing,file:output,duplicate:true};}
    await this.validateSource(job);
    await this.managed.regular(file);const st=await this.io.stat(file);if(!st.isFile()||st.size>60*1024*1024)throw Error('请选择不超过 60 MB 的 ZIP 文件');const bytes=await this.io.readFile(file),{entries,unpacked}=this.unpack(bytes);
    for(const e of entries){if(e.directory)continue;if(!/\.(?:md|markdown|mdown|png|jpe?g|webp|gif|svg|json|pdf)$/i.test(e.name))throw Error('译稿包含非文献文件：'+e.name);}
    const receipts=entries.filter(e=>/(^|\/)translation-result\.json$/.test(e.name));if(receipts.length!==1)throw Error('译稿包缺少唯一的 translation-result.json，请让网页按原要求补全后下载');
    const receipt=JSON.parse(new TextDecoder().decode(unpacked[receipts[0].name]));if(receipt.taskId!==job.id||receipt.sourceSha256!==job.sourceSha256||receipt.complete!==true)throw Error('下载包任务不匹配或全文尚未完成');
    const base=this.path.posix.dirname(receipts[0].name),main=this.path.posix.join(base,this.safeName(receipt.markdown));if(!/\.(md|markdown|mdown)$/i.test(main)||!unpacked[main])throw Error('下载包缺少声明的中文 Markdown');
    const markdown=new TextDecoder('utf-8',{fatal:true}).decode(unpacked[main]);if(!/[\u3400-\u9fff]{2}/.test(markdown)||markdown.trim().length<40)throw Error('下载包未包含有效的中文译稿');
    const outputImageHashes=new Set(entries.filter(e=>/\.(png|jpe?g|webp|gif|svg)$/i.test(e.name)).map(e=>this.hash(unpacked[e.name])));
    if(job.files.some(f=>f.path.startsWith('source/')&&/\.(png|jpe?g|webp|gif|svg)$/i.test(f.path)&&!outputImageHashes.has(f.sha256)))throw Error('译稿包缺少原始图片或图片被改动，请让网页保留原图后重新打包');
    let mainIndexDocument;
    for(const e of entries.filter(e=>/(^|\/)xref-index\.json$/.test(e.name))){const index=JSON.parse(new TextDecoder().decode(unpacked[e.name]));if(index.schema!=='xref-sidecar-v2'||index.path_base!=='markdown-directory'||!Array.isArray(index.documents))throw Error('译稿引用索引格式不受支持');for(const doc of index.documents){const prefix=e.name.includes('/_xref/')?e.name.split('/_xref/')[0]:'',docPath=this.path.posix.join(prefix,this.safeName(doc.markdown));if(!unpacked[docPath])throw Error('译稿索引指向不存在的文档');const content=new TextDecoder().decode(unpacked[docPath]).replace(/\r\n?/g,'\n'),lines=content.split('\n');for(const t of doc.targets||[]){if(!t.content)continue;const start=Number(t.start_line),end=Number(t.end_line);if(!Number.isInteger(start)||!Number.isInteger(end)||start<1||end<start||end>lines.length||lines.slice(start-1,end).join('\n').trim()!==String(t.content).replace(/\r\n?/g,'\n').trim())throw Error('译稿引用索引与正文位置不匹配，请让网页重新生成索引');}doc.sha256=this.hash(unpacked[docPath]);if(docPath===main){doc.table_style='three-line';for(const target of doc.targets||[])if(target.kind==='table')target.table_style='three-line';mainIndexDocument=doc;}}unpacked[e.name]=new TextEncoder().encode(JSON.stringify(index,null,2));}
    // The style is an explicit preference for this translated document, not a global theme change.
    const indexName=this.path.posix.join(this.path.posix.dirname(main),'_xref',this.path.posix.basename(main).replace(/\.(md|markdown|mdown)$/i,''),'xref-index.json');
    if(!unpacked[indexName]){const doc=mainIndexDocument||{markdown:this.path.posix.basename(main),sha256:this.hash(unpacked[main]),table_style:'three-line',targets:[]};unpacked[indexName]=new TextEncoder().encode(JSON.stringify({schema:'xref-sidecar-v2',path_base:'markdown-directory',documents:[doc]},null,2));entries.push({name:indexName,directory:false});}
    else {const styled=JSON.parse(new TextDecoder().decode(unpacked[indexName])).documents?.find(d=>d.markdown===this.path.posix.basename(main));if(styled?.table_style!=='three-line')throw Error('译稿主文档索引不匹配，未归档');}
    const key=this.store.crypto.randomBytes(4).toString('hex').toUpperCase(),folder=this.path.join(this.managed.storage,key);await this.io.mkdir(this.managed.storage,{recursive:true});await this.managed.regular(this.managed.storage);await this.io.mkdir(folder);let committed=false;
    try{
      const manifest=[];for(const e of entries){if(e.directory||e.name===receipts[0].name)continue;const target=this.path.join(folder,e.name);if(!this.managed.inside(folder,target))throw Error('资源路径越界');await this.io.mkdir(this.path.dirname(target),{recursive:true});await this.io.writeFile(target,unpacked[e.name],{flag:'wx'});manifest.push({path:e.name,bytes:unpacked[e.name].length,sha256:this.hash(unpacked[e.name])});}
      const target=this.path.join(folder,main),ref={...this.store.fileRef(target,'markdown'),managed:true,name:'中文翻译.md',storageKey:key,sourcePath:job.source,webTranslationId:job.id};
      await this.managed.plan(ref,{includeNotes:false}); // All local resource links must resolve; no stale source line offsets are reused.
      await this.io.writeFile(this.path.join(folder,'.managed.json'),JSON.stringify({version:1,source:job.source,translation:{job:job.id,skill:WebTranslation.skill},files:manifest},null,2),{flag:'wx'});
      await this.validateSource(job);
      const before=await this.store.read(),next=JSON.parse(JSON.stringify(before.data)),parent=next.items.find(i=>i.id===job.itemId);if(!parent)throw Error('原条目已删除');parent.files.push(ref);
      await this.store.commit(before.data,next,live=>{const p=live.items.find(i=>i.id===job.itemId);if(live.libraryId!==job.libraryId||!p?.files.some(f=>f.id===job.refId&&f.path===job.refPath)||p.files.some(f=>f.webTranslationId===job.id))throw Error('原条目已改变或任务已归档');});committed=true;
      Object.assign(job,{state:'imported',output:target,download:file,imported:new Date().toISOString()});await this.save(job);return {file:target,ref};
    }finally{if(!committed)await this.managed.removeFolder(folder).catch(()=>{});}
  }
}
module.exports=WebTranslation;
