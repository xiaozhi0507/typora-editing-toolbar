const {test}=require('node:test'),assert=require('node:assert/strict');
const Edit=require('./ai-document-edit.cjs'),Client=require('./ai-client.cjs');
test('document image tags retain zoom, dimensions, local paths and centering',()=>{
  for(const html of [
    '<img src="assets/ch06-fig01.png" alt="图 6-1" style="zoom:150%;" />',
    '<p align="center"><img src="./图片/图 1.png" width="240" height="180px"></p>',
    '<img\n src="assets/a.png"\n style="width:150%;max-width:100%;height:auto;display:block;margin:0 auto"\n />',
    '<div style="text-align: center"><img src="file:///C:/books/a.png" style="zoom:1.5"></div>',
    '<img src="D:\\books\\a.png" alt="a &quot;quote&quot; &lt;tag&gt;" />',
    '<img src="https://example.com/a.png?a=1&amp;b=2" style="zoom:150%">'
  ])assert.equal(Edit.markdown(html),html);
});
test('safe formatting and unrelated markdown survive a document edit',()=>{
  const text='# 文档\n\n文字<sup>①</sup>和 H<sub>2</sub>O。\n\n![图](assets/a.png)\n\n<p><strong>重点</strong><br><em>内容</em></p>\n';
  assert.equal(Edit.apply(text,{summary:'改图',edits:[{old_text:'![图](assets/a.png)',new_text:'<img src="assets/a.png" style="zoom:150%;" />'}]},Edit.markdown),text.replace('![图](assets/a.png)','<img src="assets/a.png" style="zoom:150%;" />'));
});
test('code fences, inline code and math remain unchanged',()=>{
  const snippets=['```html\n<img src="x" onerror="alert(1)">\n```','~~~~html\n<script>x</script>\n~~~~','`<img src="x">`','``code ` <script>x</script>``','$$\nx<y,\quad \\lim_{h\\to0} h\n$$','$x<y$','\\(x<y\\)','\\[x<y\\]'];
  for(const text of snippets)assert.equal(Edit.markdown(text),text);
});
test('handlers, executable tags, protocol obfuscation and active styles stay inert',()=>{
  for(const html of [
    '<script\nsrc="x.js"></script>','<svg onload="alert(1)"></svg>','<iframe src="x"></iframe>',
    '<img src="a.png" onerror="alert(1)">','<img src="javascript:alert(1)">','<img src="java&#x73;cript&colon;alert(1)">',
    '<img src="jav&#9;ascript:alert(1)">','<img src="data:image/svg+xml;base64,ABC">','<img src="//example.com/a.png">',
    '<img src="a.png" style="background:url(https://example.com)">','<img src="a.png" style="width:expression(alert(1))">',
    '<img src="a.png" style="z\\6f om:150%">','<img src="a.png" src="b.png">','<img src="a.png" srcset="b.png 2x">'
  ])assert.ok(!Edit.markdown(html).includes('<'),html);
});
test('malformed markup cannot expose nested HTML and escaped backticks are not code',()=>{
  for(const html of ['<img src="bad<script>" onerror="x">','<img src="a.png" <script>x</script>','<img src="x onerror=oops','\\`<script>x</script>\\`','```bad`info\n<script>x</script>'])assert.ok(!Edit.markdown(html).includes('<script'),html);
});
test('ordinary answer insertion still escapes HTML; edit mode alone permits images',()=>{
  const html='<img src="assets/a.png" style="zoom:150%;" />';assert.equal(Edit.markdown(html),html);assert.equal(Client.insertableMarkdown(html),'&lt;img src="assets/a.png" style="zoom:150%;" />');
});
test('escaped historical markup only changes when explicitly replaced',()=>{
  const before='&lt;img src="assets/a.png" style="zoom:150%;" />',after='<img src="assets/a.png" style="zoom:150%;" />';
  assert.equal(Edit.markdown(before),before);assert.equal(Edit.apply(before,{summary:'修复图片',edits:[{old_text:before,new_text:after}]},Edit.markdown),after);
});
