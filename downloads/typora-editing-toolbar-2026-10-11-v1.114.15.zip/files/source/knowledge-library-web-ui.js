// Webpage bookmarks share the library save queue. Existing captured resources stay intact.
let webDraft=null;
function webInfoMarkup(i){return '<dl class="kb-info-fields kb-web-info"><dt>条目类型</dt><dd><span class="kb-web-value">网页</span></dd><dt>网址</dt><dd><div class="kb-web-value"><button type="button" data-web-action="open" data-web-id="'+escape(i.id)+'" title="'+escape(i.url)+'">'+escape(i.url)+'</button></div></dd><dt>访问时间</dt><dd><span class="kb-web-value">'+escape(i.accessDate?fullDate(i.accessDate):'')+'</span></dd></dl>';}
function webHeading(i){return '<div class="kb-web-actions"><button type="button" class="kb-outline" data-web-action="open" data-web-id="'+escape(i.id)+'">'+icon('globe')+'打开原网页</button>'+(i.deleted?'':'<button type="button" class="kb-outline" data-web-action="edit" data-web-id="'+escape(i.id)+'">'+icon('pencil')+'编辑网页信息</button>')+'</div>';}
function webPull(){if(!webDraft)return;const form=q('[data-form]');for(const field of ['url','title','category']){const e=form.elements.namedItem(field);if(e)webDraft[field]=e.value;}}
function webRender(){
  const d=webDraft;if(!d)return;const form=q('[data-form]');form.classList.add('is-web-dialog');
  form.innerHTML='<header data-dialog-move><h3 id="kb-modal-title">'+(d.id?'编辑网页':'添加网页')+'</h3><button type="button" data-do="cancel" aria-label="关闭" '+(d.busy?'disabled':'')+'>'+icon('x')+'</button></header><div class="kb-web-dialog-body"><label>网址<div class="kb-web-url-input">'+icon('globe')+'<input name="url" type="url" required maxlength="4096" autocomplete="off" placeholder="粘贴网址，或拖入浏览器链接" value="'+escape(d.url)+'" '+(d.lockURL?'readonly':'')+'></div></label><label>标题<input name="title" required maxlength="1000" placeholder="输入网页标题" value="'+escape(d.title)+'"></label><label>分类<div class="kb-web-select"><select name="category"><option value="">未分类</option>'+orderedCollections().map(c=>'<option value="'+escape(c.id)+'" '+(d.category===c.id?'selected':'')+'>'+escape(collectionPath(c.id))+'</option>').join('')+'</select>'+icon('chevron-down')+'</div></label>'+(d.duplicate?'<div class="kb-web-warning" role="status">这个网址已存在于知识库<button type="button" class="kb-outline" data-web-action="existing">打开已有条目</button></div>':d.error?'<div role="alert" class="kb-web-warning">'+escape(d.error)+'</div>':'')+'</div><footer><button type="button" class="kb-outline" data-do="cancel" '+(d.busy?'disabled':'')+'>取消</button><button type="button" class="kb-primary" data-web-action="save" '+(d.busy?'disabled':'')+'>'+(d.busy?'保存中…':'保存')+'</button></footer>';
  form.querySelectorAll('input,select').forEach(e=>e.disabled=!!d.busy);updateIcons();
}
async function openWebDialog(id=''){
  if(!await flush())return;closeCollectionMenu();newTypeMenu=false;previousFocus=document.activeElement;modal='webpage';const i=byID(id);
  webDraft={id:i?.id,url:i?.url||'',title:i?.title||'',category:i?.collections?.[0]||(state.view.startsWith('collection:')?state.view.slice(11):''),lockURL:!!i?.webpage?.currentFile};
  q('[data-shade]').hidden=false;webRender();q('[data-form] [name="'+(i?'title':'url')+'"]')?.focus();
}
async function webSave(){
  const d=webDraft;if(!d||d.busy)return;webPull();d.error='';d.duplicate=null;
  try{d.url=bridge.urlRef(d.url).path;}catch(e){d.error=e.message;webRender();q('[data-form] [name=url]')?.focus();return;}
  const duplicate=items.find(i=>{if(i.deleted||i.id===d.id||!i.url)return false;try{return bridge.urlRef(i.url).path===d.url;}catch{return false;}});
  if(duplicate){d.duplicate=duplicate.id;webRender();q('[data-web-action=existing]')?.focus();return;}
  if(!d.title.trim()){d.error='请填写网页标题';webRender();q('[data-form] [name=title]')?.focus();return;}
  d.busy=true;webRender();
  try{
    if(!await flush())throw Error('知识库其他修改尚未保存');
    const existing=byID(d.id);
    // Only submit fields exposed by this form; do not clear existing metadata, notes or resources.
    const result=await bridge.webSave(clone(base),{id:d.id,url:d.url,title:d.title.trim(),collections:d.category?[...new Set([d.category,...(existing?.collections||[]).slice(1)])]:[]});
    d.busy=false;if(webDraft!==d)return;closeModal();state.selected=result.id;state.checked=[];state.detailCollapsed=false;state.sections.info=true;
    const saved=result.data.items.find(i=>i.id===result.id);if(!scope(saved))state.view=d.category?'collection:'+d.category:'all';state.query='';clearItemFilters();state.activeSection='info';
    loadLibrary(result.data,{state,design});notify('网页链接已保存');
  }catch(e){if(webDraft!==d)return;d.busy=false;d.error=e.message;d.duplicate=e.itemId||null;webRender();}
}
root.addEventListener('click',event=>{
  const button=event.target.closest('[data-web-action]');if(!button)return;event.preventDefault();event.stopImmediatePropagation();
  const action=button.dataset.webAction,id=button.dataset.webId,item=byID(id);
  run(async()=>{
    if(action==='open'){closeCollectionMenu();return bridge.openResourceURL(item.url);}
    if(action==='edit')return openWebDialog(id);
    if(action==='save')return webSave();
    if(action==='existing'){const existing=webDraft.duplicate;closeModal();state.selected=existing;state.checked=[];state.view='all';state.query='';state.detailCollapsed=false;render();return;}
  });
},true);
for(const name of ['dragenter','dragover','drop'])root.addEventListener(name,event=>{
  if(modal!=='webpage'||!event.target.closest('[data-form]'))return;event.preventDefault();event.stopImmediatePropagation();
  if(name==='drop'&&!webDraft.busy&&!webDraft.lockURL){
    const text=(event.dataTransfer?.getData('text/uri-list')||event.dataTransfer?.getData('text/plain')||'').split(/\r?\n/).find(line=>line.trim()&&!line.startsWith('#'));webPull();
    try{webDraft.url=bridge.urlRef(text).path;webDraft.error='';webDraft.duplicate=null;webRender();q('[data-form] [name=title]')?.focus();}catch(e){webDraft.error=e.message;webRender();}
  }
},true);
