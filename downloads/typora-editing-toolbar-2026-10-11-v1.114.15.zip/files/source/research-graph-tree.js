// A stable outline uses document order, not force-directed coordinates.
export function layoutHeadingTree(nodes,options){
 const root=nodes.find(n=>n.current);if(!root)return;
 const headings=nodes.filter(n=>n.kind==='heading').sort((a,b)=>a.headingOrder-b.headingOrder),byId=new Map(nodes.map(n=>[n.id,n]));
 const row=Math.max(36,22+options.nodeSize*10),indent=Math.max(32,18+options.nodeSize*12);
 const place=(n,x,y)=>Object.assign(n,{x,y,fx:x,fy:y,vx:0,vy:0,depthUnit:0});
 root.outlineLevel=0;place(root,0,0);let y=0;
 for(const n of headings){const parent=byId.get(n.parentId)||root;n.outlineLevel=(parent.outlineLevel||0)+1;y+=row+(n.headingLevel===1?10:0);place(n,n.outlineLevel*indent,y);}
 const others=nodes.filter(n=>n!==root&&n.kind!=='heading'),rows=Math.max(1,Math.floor(Math.max(y,200)/58));
 others.forEach((n,i)=>place(n,-190-180*Math.floor(i/rows),42+(i%rows)*58));
}
