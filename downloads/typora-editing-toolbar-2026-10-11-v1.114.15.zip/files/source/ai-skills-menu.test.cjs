const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {JSDOM}=require('jsdom'),source=fs.readFileSync(path.join(__dirname,'ai-skills.js'),'utf8');
const tick=()=>new Promise(r=>setImmediate(r));
function setup(t){
 const dom=new JSDOM('<body><div id="back"><section id="prefs"><div id="panel"><div id="list"></div></div></section></div></body>',{runScripts:'outside-only'}),w=dom.window;t.after(()=>dom.window.close());
 const calls={opens:[],exports:[],notices:[],dialogs:[]};let picker=async()=>({canceled:true,filePaths:[]});
 w.reqnode=name=>name==='electron'?{shell:{openPath:async p=>{calls.opens.push(p);return '';}}}:require(name);w.JSBridge={invoke:async(method,args)=>{calls.dialogs.push({method,args});return picker();}};
 const Cls=vm.runInContext(source+'\nEditingToolbarAISkills',dom.getInternalVMContext()),node=(tag,cls,text)=>{const n=w.document.createElement(tag);if(cls)n.className=cls;if(text)n.textContent=text;return n;};
 const ai={node,notice:(...args)=>calls.notices.push(args),preferences:w.document.querySelector('#prefs'),preferencesBackdrop:w.document.querySelector('#back')};
 const ui=new Cls(ai);Object.assign(ui,{panel:w.document.querySelector('#panel'),list:w.document.querySelector('#list'),scroll:{scrollTop:0},search:{value:''},count:node('span'),status:node('p')});ui.panel.append(ui.status);
 ui.items=[{id:'a',name:'first',root:'C:/skill-a',displayName:'第一技能',enabled:true},{id:'b',name:'second',root:'C:/skill-b',enabled:true}];
 ui.store={location:async id=>ui.items.find(s=>s.id===id),exportZip:async(...args)=>{calls.exports.push(args);return {path:'C:/out/first.zip',files:3};}};ui.render();
 return {w,ui,calls,picker:fn=>picker=fn,row:i=>ui.list.children[i],rightClick:i=>ui.list.children[i].dispatchEvent(new w.MouseEvent('contextmenu',{bubbles:true,cancelable:true,clientX:60,clientY:80}))};
}
test('card context menu opens correct skill, switches cards and restores keyboard focus on Escape',async t=>{
 const f=setup(t);f.rightClick(0);assert.deepEqual([...f.ui.menu.children].map(n=>n.textContent),['查看目录','一键打包…']);f.rightClick(1);assert.equal(f.w.document.querySelectorAll('[role=menu]').length,1);f.ui.menu.children[0].click();await tick();assert.deepEqual(f.calls.opens,['C:/skill-b']);assert.equal(f.ui.menu,null);
 f.row(0).dispatchEvent(new f.w.KeyboardEvent('keydown',{key:'F10',shiftKey:true,bubbles:true,cancelable:true}));assert(f.ui.menu);f.ui.menu.children[0].dispatchEvent(new f.w.KeyboardEvent('keydown',{key:'ArrowDown',bubbles:true,cancelable:true}));assert.equal(f.w.document.activeElement.textContent,'一键打包…');f.ui.menu.dispatchEvent(new f.w.KeyboardEvent('keydown',{key:'Escape',bubbles:true,cancelable:true}));assert.equal(f.ui.menu,null);assert.equal(f.w.document.activeElement,f.row(0));
});
test('outside click, settings close and tab change remove menu and expanded state',async t=>{
 const f=setup(t);f.rightClick(0);f.w.document.body.dispatchEvent(new f.w.Event('pointerdown',{bubbles:true}));assert.equal(f.ui.menu,null);assert.equal(f.row(0).getAttribute('aria-expanded'),'false');
 f.rightClick(0);f.ui.panel.hidden=true;await tick();assert.equal(f.ui.menu,null);f.ui.panel.hidden=false;f.rightClick(1);f.ui.ai.preferencesBackdrop.hidden=true;await tick();assert.equal(f.ui.menu,null);
});
test('folder picker cancel writes nothing; export forwards selected folder without a success notification',async t=>{
 const f=setup(t);await f.ui.packageSkill(f.ui.items[0]);assert.deepEqual(f.calls.exports,[]);assert.equal(f.calls.dialogs[0].method,'dialog.showOpenDialog');assert(f.calls.dialogs[0].args.properties.includes('openDirectory'));assert(!f.row(0).hasAttribute('aria-busy'));
 f.picker(async()=>({filePaths:['C:/chosen folder']}));await f.ui.packageSkill(f.ui.items[0]);assert.deepEqual(f.calls.exports,[['a','C:/chosen folder']]);assert.equal(f.ui.status.textContent,'');assert.equal(f.ui.status.title,'');assert.equal(f.ui.status.hidden,true);assert.equal(f.calls.notices.length,0);
});
test('repeated export while picker is open is ignored and failures clear busy state',async t=>{
 const f=setup(t);let resolve;f.picker(()=>new Promise(r=>resolve=r));const pending=f.ui.packageSkill(f.ui.items[0]);await f.ui.packageSkill(f.ui.items[0]);assert.equal(f.calls.dialogs.length,1);assert.equal(f.row(0).getAttribute('aria-busy'),'true');resolve({canceled:true});await pending;
 f.picker(async()=>({filePaths:['C:/out']}));f.ui.store.exportZip=async()=>{throw Error('disk error');};await assert.rejects(f.ui.packageSkill(f.ui.items[0]),/disk error/);assert.equal(f.ui.exporting.size,0);assert(!f.row(0).hasAttribute('aria-busy'));
});
