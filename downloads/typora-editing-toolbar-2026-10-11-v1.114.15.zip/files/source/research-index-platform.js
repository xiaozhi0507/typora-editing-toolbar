// File I/O stays asynchronous in Typora; Markdown/YAML parsing and link indexing
// run in a standard Web Worker (Node worker_threads is disabled in Typora).
let sequence=0;const waiting=new Map(),listeners=[];
self.onmessage=({data})=>{if(data.fsReply){const entry=waiting.get(data.fsReply);if(!entry)return;waiting.delete(data.fsReply);data.error?entry.reject(Object.assign(Error(data.error.message),{code:data.error.code})):entry.resolve(data.value);}else for(const fn of listeners)fn(data);};
export const parentPort={on:(type,fn)=>listeners.push(fn),postMessage:value=>self.postMessage(value)};
const call=(method,args)=>new Promise((resolve,reject)=>{const id=++sequence;waiting.set(id,{resolve,reject});self.postMessage({fsRequest:id,method,args});});
export const fs={promises:{
 readdir:async name=>(await call('readdir',[name])).map(e=>({...e,isSymbolicLink:()=>e.link,isDirectory:()=>e.directory,isFile:()=>e.file})),
 stat:async name=>{const s=await call('stat',[name]);return{...s,isFile:()=>s.file};},
 readFile:name=>call('readFile',[name])
}};
const slash=p=>String(p).replace(/\\/g,'/');
const normalize=p=>{p=slash(p);const prefix=p.startsWith('//')?'//':p.startsWith('/')?'/':'';const parts=[];for(const part of p.split('/')){if(!part||part==='.')continue;if(part==='..'&&parts.length&&parts.at(-1)!=='..'&&!/^[a-z]:$/i.test(parts.at(-1)))parts.pop();else if(part!=='..'||!prefix)parts.push(part);}return prefix+parts.join('/');};
export const path={
 isAbsolute:p=>/^(?:[a-z]:[\\/]|[\\/])/i.test(p),
 resolve:(...parts)=>{let out='';for(const part of parts){if(path.isAbsolute(part))out=part;else out+='/'+part;}return normalize(out);},
 join:(...parts)=>normalize(parts.join('/')),
 basename:(p,ext='')=>{const n=slash(p).split('/').pop();return ext&&n.endsWith(ext)?n.slice(0,-ext.length):n;},
 dirname:p=>slash(p).replace(/\/[^/]*$/,'')||'/',
 extname:p=>{const n=path.basename(p),at=n.lastIndexOf('.');return at>0?n.slice(at):'';},
 relative:(from,to)=>{const a=normalize(from).split('/'),b=normalize(to).split('/');if(a[0].toLowerCase()!==b[0].toLowerCase())return normalize(to);let i=0;while(i<Math.min(a.length,b.length)&&a[i].toLowerCase()===b[i].toLowerCase())i++;return [...a.slice(i).map(()=>'..'),...b.slice(i)].join('/');}
};
export const fileURLToPath=value=>{const u=new URL(value);if(u.protocol!=='file:')throw Error('Not a local file');const p=decodeURIComponent(u.pathname);return u.hostname?'//'+u.hostname+p:/^\/[a-z]:/i.test(p)?p.slice(1):p;};
