'use strict';
const CNKI=typeof ETKnowledgeCNKI!=='undefined'?ETKnowledgeCNKI:require('./knowledge-library-cnki.cjs');
const BookMetrics=typeof ETKnowledgeBookMetrics!=='undefined'?ETKnowledgeBookMetrics:require('./knowledge-library-book-metrics.cjs');
// Independent public-API adapter. No Zotero Pro code, source documents or indexes are modified.
class KnowledgeLibraryMetrics {
  static impactFields={sciif:'影响因子',sciif5:'五年影响因子','复合影响因子':'复合影响因子','综合影响因子':'综合影响因子'};
  static selectImpact(settings,field) {
    if(!Object.hasOwn(this.impactFields,field))throw Error('不支持的影响因子类型');
    const parts=value=>String(value||'').split(/[,，]/).map(s=>s.trim()).filter(Boolean);
    const fields=parts(settings.fields),hasImpact=fields.some(key=>Object.hasOwn(this.impactFields,key));
    const nextFields=fields.map(key=>Object.hasOwn(this.impactFields,key)?field:key);
    if(!hasImpact)nextFields.unshift(field);
    const sortBy=parts(settings.sortBy).map(token=>{const reverse=token.startsWith('-'),key=reverse?token.slice(1):token;return Object.hasOwn(this.impactFields,key)?(reverse?'-':'')+field:token;});
    return {impactField:field,fields:[...new Set(nextFields)].join(', '),sortBy:[...new Set(sortBy)].join(', ')};
  }
  static citationFields=['Total(CNKI)','Download','Total(DOI)','Highly Influential','Background','Methods','Results'];
  static defaults = { automatic:true, fields:'sciif, sci, sciBase, ssci, pku, cscd, ajg, utd24, eii', aliases:'', impactField:'sciif', rankColors:'#ffe2dd, #e8deee, #dbeddb, #fadec9, #e9e8e7', map:'SCI=, SCIIF=IF, SCIIF(5)=IF(5), SCI基础版=中科院, 北大中文核心=北核', defaultColor:'#86dad1', textColor:'auto', sortBy:'sci, -sciif', opacity:1, margin:3, padding:5, citationFields:'Total(CNKI), Download, Total(DOI), Highly Influential, Background, Methods, Results', citationMap:'Total(CNKI)=CNKI, Download=Download, Total(DOI)=Total, Highly Influential=HI', citationColors:'#ffe2dd, #e8deee, #dbeddb, #fadec9, #e9e8e7', citationTextColor:'auto', citationSortBy:'Total(DOI), Total(CNKI)', citationOpacity:1, citationMargin:3, citationPadding:5 };
  constructor(store, options = {}) {
    this.store=store;this.require=options.requireNode||require;this.settings=options.settings||(()=>KnowledgeLibraryMetrics.defaults);
    this.requestOverride=options.request;this.browserFetch=options.fetch;this.cnkiRequest=options.cnkiRequest;this.parseHTML=options.parseHTML;this.now=options.now||Date.now;this.delay=options.delay||(ms=>new Promise(r=>setTimeout(r,ms)));
    this.lookupISBN=options.lookupISBN;
    this.cacheFile=store.path.join(store.root,'metrics-cache.json');this.cache={};this.inflight=new Map();this.failures=new Map();this.rounds=new Map();this.tail=Promise.resolve();this.stopped=false;
    this.requestTail=Promise.resolve();this.nextRequest=0;this.serviceNextRequest=new Map();this.serviceFailures=new Map();this.serviceRateLimits=new Map();
    this.ready=store.readOptional(this.cacheFile).then(raw=>{try{const data=JSON.parse(raw);if(data?.version===1&&data.entries&&typeof data.entries==='object')this.cache=data.entries;}catch(_){/* A damaged cache is replaceable, the library is independent. */}});
  }
  static doi(value) { const d=String(value||'').trim().replace(/^https?:\/\/(?:dx\.)?doi\.org\//i,'').replace(/^doi:\s*/i,'');return /^10\.\d{4,9}\/\S+$/i.test(d)?d.toLowerCase():''; }
  static cnki(value){try{const u=new URL(value);if(!/(^|\.)cnki\.(net|com\.cn)$/i.test(u.hostname))return '';const q=Object.fromEntries([...u.searchParams].map(([k,v])=>[k.toLowerCase(),v]));return q.filename?'cnki:'+q.filename.toUpperCase():'';}catch(_){return '';}}
  static eligible(item) { return !!item&&['paper','thesis','book'].includes(item.type); }
  static identity(item) { const paper=item.type==='paper',book=item.type==='book',scholarly=this.eligible(item);return {journal:paper?String(item.publicationTitle||item.conference||'').trim():'',doi:scholarly&&!book?this.doi(item.doi||item.url):'',cnki:scholarly?this.cnki(item.url):'',...(book?{isbn:BookMetrics.isbn(item.isbn)}:{})}; }
  static citationIdentity(item){if(!this.eligible(item))return '';const id=this.identity(item);return id.isbn?'isbn:'+id.isbn:id.doi?'doi:'+id.doi:id.cnki||(CNKI.eligible(item)?'cnki-query:'+CNKI.key(item):'');}
  static validCount(v){return (typeof v==='number'||typeof v==='string'&&/^\d+$/.test(v.trim()))&&Number.isSafeInteger(Number(v))&&Number(v)>=0;}
  static citationsConnected(settings={}){return typeof settings.semanticKey==='string'?!!settings.semanticKey.trim():settings.hasSemanticKey===true;}
  static citationValues(record){
    const fields={};for(const key of this.citationFields){const entry=record?.fields?.[key];if(entry&&this.validCount(entry.value))fields[key]={...entry,value:Number(entry.value)};}
    if(!fields['Total(DOI)']&&this.validCount(record?.count))fields['Total(DOI)']={value:Number(record.count),source:record.source||'Crossref',updatedAt:record.updatedAt};
    return fields;
  }
  static aliases(name,setting) {
    const groups=String(setting||'').split(/[\n;；]/).map(s=>s.split('=').map(v=>v.trim()).filter(Boolean));
    const group=groups.find(g=>g.some(n=>n.toLowerCase()===name.toLowerCase()));return [...new Set(group||[name])].slice(0,8);
  }
  static parseRanks(response) {
    const object=v=>v&&typeof v==='object'&&!Array.isArray(v);
    if(!object(response)||response.code!==undefined&&response.code!==200||!object(response.data)||!object(response.data.officialRank)&&!object(response.data.customRank))throw Error('easyScholar 未返回有效数据，请检查 API Key 或查询额度');
    if(response.data.officialRank?.all!=null&&!object(response.data.officialRank.all))throw Error('easyScholar 排名数据格式无效');
    const ranks={},safe=k=>!['__proto__','constructor','prototype'].includes(k);
    for(const [key,value] of Object.entries(response.data.officialRank?.all||{}))if(safe(key)&&(typeof value==='string'&&value.trim()||typeof value==='number'&&Number.isFinite(value)))ranks[key]=String(value);
    const custom=response.data.customRank;
    for(const entry of Array.isArray(custom?.rank)?custom.rank:[]) {
      const match=typeof entry==='string'&&entry.match(/^(.+)&&&([1-5])$/);if(!match)continue;
      const info=custom.rankInfo?.find?.(i=>String(i.uuid)===match[1]),field=info?.abbName?.trim();if(!field||!safe(field))continue;
      const text=info[['oneRankText','twoRankText','threeRankText','fourRankText','fiveRankText'][Number(match[2])-1]];
      ranks[field]=String(text||field)+'[rank='+match[2]+']';
    }
    return ranks;
  }
  static impact(ranks,field='sciif') { const value=String(ranks?.[field]??'').trim(),number=Number(value);return /^\d+(?:\.\d+)?$/.test(value)&&Number.isFinite(number)?number:null; }
  // Merge only fields returned by the service. Absence is not a request to erase a stored metric.
  static mergeRecord(old,value) {
    if(!old)return value;
    if(value.ranks){const ranks=Object.fromEntries(Object.entries(value.ranks).filter(([,v])=>v!=null&&String(v).trim()!==''));return {...value,ranks:{...old.ranks,...ranks},updatedAt:Object.keys(ranks).length?value.updatedAt:old.updatedAt,retainedFields:[...new Set([...(value.retainedFields||[]),...Object.keys(old.ranks||{}).filter(k=>!Object.hasOwn(ranks,k))])]};}
    if(value.fields||old.fields){
      const previous=this.citationValues(old),incoming=this.citationValues(value);
      if(old.book?.paperId&&value.book?.paperId&&old.book.paperId!==value.book.paperId)for(const key of Object.keys(previous))if(previous[key].source==='Semantic Scholar')delete previous[key];
      const fields={...previous};
      for(const [key,entry]of Object.entries(incoming)){
        const prior=previous[key];
        // Crossref is a fallback, never a replacement for an existing Semantic Scholar total.
        if(key==='Total(DOI)'&&entry.source==='Crossref'&&prior&&prior.source!=='Crossref')continue;
        if(entry.snapshot&&prior?.updatedAt>entry.updatedAt)continue;
        fields[key]=entry;
      }
      const total=fields['Total(DOI)'];return {...old,...value,fields,count:total?.value??null,source:total?.source||value.source||old.source,updatedAt:Math.max(old.updatedAt||0,value.updatedAt||0),retainedFields:Object.keys(previous).filter(k=>!incoming[k])};
    }
    if(value.count==null&&old.count!=null)return {...old,checkedAt:value.checkedAt,warning:value.warning||'本次未返回被引数，保留原值'};
    return value;
  }
  static color(value,fallback='#e8deee'){return /^#[0-9a-f]{6}$/i.test(String(value||''))?value:fallback;}
  static citationColor(field,setting){
    const colors=String(setting||'').split(',').map(v=>v.trim()).filter(v=>/^#[a-f0-9]{6}$/i.test(v)),index=({'Total(CNKI)':0,Download:1,'Total(DOI)':0,'Highly Influential':1,Background:2,Methods:3,Results:4})[field]??0;
    return colors[index%colors.length]||'#ffe2dd';
  }
  static appearance(settings,citations=false) {
    const s={...this.defaults,...settings},key=name=>citations?'citation'+name[0].toUpperCase()+name.slice(1):name;
    const number=(name,min,max)=>Math.max(min,Math.min(max,Number.isFinite(Number(s[key(name)]))?Number(s[key(name)]):this.defaults[key(name)]));
    return {textColor:s[key('textColor')]==='auto'?'auto':this.color(s[key('textColor')],'#493d4f'),opacity:number('opacity',0.1,1),margin:number('margin',0,12),padding:number('padding',0,16)};
  }
  static badgeStyle(color,appearance) {
    const bg=this.color(color),rgb=bg.slice(1).match(/../g).map(v=>parseInt(v,16));
    // Style's automatic label colour preserves the background hue/saturation at 40% lightness.
    const [r,g,b]=rgb.map(v=>v/255),max=Math.max(r,g,b),min=Math.min(r,g,b),delta=max-min,l=(max+min)/2;
    const saturation=delta?delta/(1-Math.abs(2*l-1)):0;
    const hue=delta?60*((max===r?(g-b)/delta+(g<b?6:0):max===g?(b-r)/delta+2:(r-g)/delta+4)):0;
    const text=appearance.textColor==='auto'?`hsl(${hue.toFixed(2)} ${Math.round(saturation*100)}% 40%)`:appearance.textColor;
    return `--metric-bg:rgba(${rgb.join(',')},${appearance.opacity});--metric-text:${text};--metric-margin:${appearance.margin}px;--metric-padding:${appearance.padding}px`;
  }
  static mapped(input,setting) {
    let text=String(input);
    // Ignore separators inside /patterns/ (including commas in quantifiers).
    const rules=[];let part='',pattern=false,escaped=false;
    for(const char of String(setting||'')){if(char==='/'&&!escaped&&(pattern||!part.trim()))pattern=!pattern;if(!pattern&&/[,;；，]/.test(char)){rules.push(part);part='';}else part+=char;escaped=char==='\\'&&!escaped;}
    rules.push(part);
    for(const rule of rules){const match=rule.trim().match(/^\/(.*)\/([gimsu]*)\s*=\s*(.*)$/);if(match&&match[1].length<150){try{text=text.replace(new RegExp(match[1],match[2]),match[3]);}catch(_){}}else{const at=rule.indexOf('=');if(at<0)continue;const from=rule.slice(0,at).trim(),to=rule.slice(at+1).trim();if(from&&text===from)text=to;}}
    return text;
  }
  static compareJournal(a,b,settings,direction=1) {
    const ranks=item=>item.type==='paper'&&item.metrics?.publication?.query===this.identity(item).journal?item.metrics.publication.ranks||{}:{};
    const ar=ranks(a),br=ranks(b);
    for(const field of String(settings.sortBy||'').split(/[,，]/).map(s=>s.trim()).filter(Boolean)){
      const reverse=field.startsWith('-'),key=reverse?field.slice(1):field;
      if(Object.hasOwn(this.impactFields,key)){
        const av=this.impact(ar,key),bv=this.impact(br,key);
        if((av===null)!==(bv===null))return av===null?1:-1;if(av===null)continue;
        if(av!==bv)return (av-bv)*(reverse?-1:1)*direction;continue;
      }
      const av=ar[key],bv=br[key];
      const missing=v=>v==null||String(v).trim()==='';if(missing(av)!==missing(bv))return missing(av)?1:-1;if(missing(av))continue;
      const rank=v=>String(v).match(/\[rank=([1-5])\]/)?.[1]||String(v).match(/Q([1-4])|([1-4])区/i)?.slice(1).find(Boolean)||v;
      const result=String(rank(av)).localeCompare(String(rank(bv)),'zh-CN',{numeric:true});if(result)return (reverse?-result:result)*direction;
    }
    return 0;
  }
  static view(item,settings) {
    if(!this.eligible(item))return {badges:[],impact:null,impactLabel:'影响因子',count:null,citationValues:{},citationBadges:[],publicationTip:'',citationTip:'',legacyJournal:''};
    settings={...this.defaults,...settings};
    const identity=this.identity(item),publication=item.type==='paper'&&item.metrics?.publication?.query===identity.journal?item.metrics.publication:null,record=item.metrics?.citations,citations=record&&(record.identity?record.identity===this.citationIdentity(item):identity.doi&&record.doi===identity.doi)?record:null;
    const time=record=>record?'来源：'+(record.source||'已有数据')+(Number.isFinite(record.updatedAt)?' · 更新：'+new Date(record.updatedAt).toLocaleString('zh-CN'):'')+(record.warning?' · '+record.warning:'')+(record.retainedFields?.length?' · 本次缺失字段保留原值：'+record.retainedFields.join(', '):''):'';
    const connected=this.citationsConnected(settings),fields=connected?this.citationValues(citations):{},appearance=this.appearance(settings,true);
    for(const key of ['Total(CNKI)','Download'])if(fields[key]?.match&&fields[key].match!==CNKI.key(item))delete fields[key];
    if(connected&&!citations&&this.validCount(item.citationCount)&&!record)fields['Total(DOI)']={value:Number(item.citationCount),source:'已有被引数'};
    const citationBadges=[...new Set(String(settings.citationFields).split(/[,，]/).map(s=>s.trim()))].flatMap(key=>{const field=fields[key];if(!field)return [];const label=this.mapped(key,settings.citationMap);return [{field:key,value:field.value,text:[label,field.value].filter(v=>v!=='').join(' '),style:this.badgeStyle(this.citationColor(key,settings.citationColors),appearance),tip:time(field)+(field.snapshot?' · 本机 Zotero 缓存':'')+(field.note?' · '+field.note:'')}];});
    return {badges:publication?this.badges(publication.ranks,settings):[],impact:publication?this.impact(publication.ranks,settings.impactField):null,impactLabel:this.impactFields[settings.impactField]||'影响因子',count:fields['Total(DOI)']?.value??fields['Total(CNKI)']?.value??null,citationValues:fields,citationBadges,publicationTip:time(publication),citationTip:connected?time(citations):'',legacyJournal:item.type==='paper'?item.journalTag||'':''};
  }
  static compareCitations(a,b,settings,direction=1){
    const av=this.view(a,settings).citationValues,bv=this.view(b,settings).citationValues;
    for(const part of String(settings.citationSortBy||'').split(/[,，]/).map(v=>v.trim()).filter(Boolean)){
      const reverse=part.startsWith('-'),key=reverse?part.slice(1):part,x=av[key]?.value,y=bv[key]?.value;
      if((x==null)!==(y==null))return x==null?1:-1;if(x==null)continue;
      if(x!==y)return (x-y)*(reverse?-1:1)*direction;
    }return 0;
  }
  static badges(ranks,settings) {
    const colors=String(settings.rankColors).split(',').map(s=>s.trim()).filter(s=>/^#[0-9a-f]{6}$/i.test(s));
    const labels={sci:'SCI',sciif:'SCIIF',sciif5:'SCIIF(5)',sciBase:'SCI基础版',sciUp:'SCI升级版',ssci:'SSCI',pku:'北大中文核心',cscd:'CSCD',eii:'EI',ajg:'AJG',utd24:'UTD24',cssci:'CSSCI'};
    const mapped=input=>this.mapped(input,settings.map),appearance=this.appearance(settings);
    return [...new Set(String(settings.fields).split(/[,，]/).map(s=>s.trim()).filter(Boolean))].flatMap(field=>{
      if(ranks?.[field]==null||ranks[field]==='')return [];
      if(Object.hasOwn(this.impactFields,field)&&this.impact(ranks,field)===null)return [];
      const raw=String(ranks[field]).slice(0,512),value=raw.replace(/\[rank=\d\]/g,''),custom=raw.match(/\[rank=([1-5])\]/),quartile=value.match(/(?:Q([1-4])|([1-4])区)/i);
      const number=this.impact(ranks,field);let rank=custom?Number(custom[1]):quartile?Number(quartile[1]||quartile[2]):number!==null&&/if/i.test(field)?number>=10?1:number>=4?2:number>=2?3:number>=1?4:5:0;
      if(field==='eii')rank=2;
      let label=mapped(labels[field]||field);
      const bare=['pku','eii','utd24'].includes(field)||value.toLowerCase()===label.toLowerCase();
      const color=colors[rank-1]||this.color(settings.defaultColor,this.defaults.defaultColor);
      return [{field,text:custom?mapped(value):[label,bare?'':mapped(value)].filter(Boolean).join(' '),color,rank,style:this.badgeStyle(color,appearance)}];
    });
  }
  async semanticCitations(doi,force){
    return this.cached('s2:'+doi,async()=>{
      const endpoint='https://api.semanticscholar.org/graph/v1/paper/DOI:'+encodeURIComponent(doi),paper=await this.request(endpoint+'?fields=externalIds,citationCount,influentialCitationCount');
      if(KnowledgeLibraryMetrics.doi(paper?.externalIds?.DOI)!==doi)throw Error('Semantic Scholar DOI 不匹配，未采用返回结果');
      return this.semanticRecord(endpoint,paper);
    },force);
  }
  async bookCitations(isbn,force){
    return this.cached('s2:isbn:'+isbn,async()=>{
      const {book,paper}=await BookMetrics.lookup(isbn,{lookupISBN:this.lookupISBN,request:url=>this.request(url),stopped:()=>this.stopped});
      const endpoint='https://api.semanticscholar.org/graph/v1/paper/'+paper.paperId;
      const record=await this.semanticRecord(endpoint,paper);
      const note='ISBN '+isbn+' → 书目匹配：'+book.title+'（'+book.year+'）；统计对应 Semantic Scholar 书籍条目，并非按 ISBN 单独计数';
      for(const field of Object.values(record.fields)){field.note=[note,field.note].filter(Boolean).join('；');field.url='https://www.semanticscholar.org/paper/'+paper.paperId;}
      return {...record,book:{...book,paperId:paper.paperId}};
    },force);
  }
  async semanticRecord(endpoint,paper){
      const fields={},entry=value=>({value,source:'Semantic Scholar',updatedAt:this.now()});
      if(KnowledgeLibraryMetrics.validCount(paper.citationCount))fields['Total(DOI)']=entry(Number(paper.citationCount));
      if(KnowledgeLibraryMetrics.validCount(paper.influentialCitationCount))fields['Highly Influential']=entry(Number(paper.influentialCitationCount));
      let warning='';
      try{
        const totals={Background:0,Methods:0,Results:0},seen=new Map();let offset=0,complete=false;
        // Publish intent totals only after all pages; never turn a truncated scan into a total.
        for(let page=0;page<20;page++){
          if(this.stopped)throw Error('已停止指标查询');
          // Request a paper field explicitly: an edge-only fields=intents response
          // can omit citingPaper entirely, making identity-based deduplication impossible.
          const result=await this.request(endpoint+'/citations?fields=paperId,intents&limit=1000&offset='+offset);
          if(!Array.isArray(result?.data))throw Error('Semantic Scholar 引用用途数据无效');
          for(const citation of result.data){const id=citation?.citingPaper?.paperId;if(!id||!Array.isArray(citation.intents))throw Error('Semantic Scholar 引用用途数据不完整');const intents=seen.get(id)||new Set();
            for(const raw of citation.intents){const key=({background:'Background',methodology:'Methods',method:'Methods',result:'Results',resultcomparison:'Results'})[String(raw).toLowerCase()];if(!key)throw Error('Semantic Scholar 返回未知引用用途，保留原值');intents.add(key);}seen.set(id,intents);
          }
          if(result.next==null){complete=true;break;}if(!Number.isSafeInteger(result.next)||result.next<=offset)throw Error('Semantic Scholar 分页无效');offset=result.next;
        }
        if(!complete)throw Error('引用用途超过单轮 20000 条上限，保留原值');
        for(const intents of seen.values())for(const key of intents)totals[key]++;
        for(const [key,value]of Object.entries(totals))fields[key]={...entry(value),note:'引用论文用途分类，按论文去重；未分类引用不计入'};
      }catch(e){warning=e.message;}
      if(!Object.keys(fields).length)throw Error('Semantic Scholar 未返回有效统计');
      return {fields,source:'Semantic Scholar',warning};
  }
  async cnkiCitations(item,force,verify){
    const key='cnki:'+CNKI.key(item),read=()=>this.cached(key,async()=>{try{return await CNKI.lookup(item,{request:(url,options)=>this.request(url,options),parseHTML:this.parseHTML,now:this.now});}catch(e){if(e.code==='CNKI_VERIFY')this.cnkiVerificationRequired=true;throw e;}},force);
    let result,error;try{result=await read();}catch(e){error=e;}
    // Wait outside both serial queues. A cached failure/retained old count also needs verification.
    if(this.failures.get(key)?.code==='CNKI_VERIFY'&&verify&&!this.stopped&&await verify()&&!this.stopped){
      this.cnkiVerificationRequired=false;
      for(const [failedKey,failure]of this.failures)if(failedKey.startsWith('cnki:')&&failure.code==='CNKI_VERIFY')this.failures.delete(failedKey);
      return read(); // One retry only; a repeated challenge must not loop or reopen the window.
    }
    if(error)throw error;return result;
  }
  request(url,options={}) {
    // Queue actual HTTP requests as well as item jobs. Pagination and concurrent callers
    // share this queue; the next request waits for the previous body to finish reading.
    const job=this.requestTail.then(async()=>{
      const parsed=new URL(url);if(parsed.protocol!=='https:'||parsed.username||parsed.password||parsed.port||!['www.easyscholar.cc','api.crossref.org','api.semanticscholar.org','kns.cnki.net'].includes(parsed.hostname))throw Error('不支持的指标来源');
      if(parsed.hostname==='kns.cnki.net'&&(parsed.href!==CNKI.endpoint||options.method!=='POST'))throw Error('不支持的知网请求');
      const host=parsed.hostname,service=({'www.easyscholar.cc':'easyScholar','api.crossref.org':'Crossref','api.semanticscholar.org':'Semantic Scholar','kns.cnki.net':'中国知网'})[host];
      const check=()=>{
        if(this.stopped)throw Error('已停止指标查询');
        if(host!=='www.easyscholar.cc'&&!String(this.settings().semanticKey||'').trim())throw Error('请先在“被引数”列设置中填写 Semantic Scholar API Key');
        if(host==='kns.cnki.net'&&this.cnkiVerificationRequired)throw Object.assign(Error('知网需要安全验证，请在“被引数”的列设置中打开“知网验证”，完成后重试'),{code:'CNKI_VERIFY'});
        const retryAt=this.serviceFailures.get(host);
        if(retryAt>this.now()){const e=Error(service+' 冷却中；'+this.retryMessage(retryAt));e.status=429;e.retryAt=retryAt;throw e;}
      };
      check();
      await this.delay(Math.max(0,this.nextRequest-this.now(),(this.serviceNextRequest.get(host)||0)-this.now()));
      check(); // The library may have closed or the service entered cooldown while waiting.
      try{
        const result=await this.requestOnce(parsed,service,options);
        this.serviceFailures.delete(host);this.serviceRateLimits.delete(host);
        return result;
      }
      finally{
        const completed=this.now();this.nextRequest=completed+1200;
        this.serviceNextRequest.set(host,completed+(['api.semanticscholar.org','kns.cnki.net'].includes(host)?5000:1200));
      }
    });
    this.requestTail=job.catch(()=>{});return job;
  }
  async requestOnce(parsed,service,options={}) {
    if(this.requestOverride)return this.requestOverride(parsed.href,options);
    if(parsed.hostname==='kns.cnki.net'){
      if(!this.cnkiRequest||!this.parseHTML)throw Error('知网查询环境未就绪');
      try{return await this.cnkiRequest(parsed.href,options);}catch(e){if(e.status===429)throw this.responseError(parsed.hostname,service,e.status,e.retryAfter);throw e;}
    }
    const headers={Accept:'application/json','User-Agent':'TyporaKnowledgeLibrary/1.11 (local literature manager)'};
    if(parsed.hostname==='api.semanticscholar.org'&&this.settings().semanticKey)headers['x-api-key']=this.settings().semanticKey;
    // Use the host browser's normal network configuration (including system proxy/PAC).
    // A failed browser request must not silently switch routes and retry a rate-limited service.
    if(parsed.hostname==='api.semanticscholar.org'&&this.browserFetch){
      delete headers['User-Agent'];
      const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);let reader;
      try{
        const response=await this.browserFetch(parsed.href,{method:'GET',headers,credentials:'omit',redirect:'error',referrerPolicy:'no-referrer',signal:controller.signal});
        if(response.status!==200){await response.body?.cancel();throw this.responseError(parsed.hostname,service,response.status,response.headers.get('Retry-After'));}
        const chunks=[];let size=0;reader=response.body.getReader();
        for(;;){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>2*1024*1024){await reader.cancel();throw Error('指标响应过大');}chunks.push(this.require('buffer').Buffer.from(value));}
        try{return JSON.parse(this.require('buffer').Buffer.concat(chunks).toString('utf8'));}catch(_){throw Error('指标服务响应格式无效');}
      }catch(error){
        if(error.status||['指标响应过大','指标服务响应格式无效'].includes(error.message))throw error;
        throw Error(service+' 浏览器网络连接失败或超时，请检查 Typora 网络设置；已有指标保留');
      }finally{clearTimeout(timer);reader?.releaseLock();}
    }
    return new Promise((resolve,reject)=>{
      const req=this.require('https').get(parsed,{headers},res=>{
        if(res.statusCode!==200){res.destroy();reject(this.responseError(parsed.hostname,service,res.statusCode,res.headers['retry-after']));return;}
        let size=0;const chunks=[];res.on('data',chunk=>{size+=chunk.length;if(size>2*1024*1024){req.destroy();reject(Error('指标响应过大'));}else chunks.push(chunk);});res.on('error',()=>reject(Error('指标服务连接中断')));res.on('end',()=>{try{resolve(JSON.parse(this.require('buffer').Buffer.concat(chunks).toString('utf8')));}catch(_){reject(Error('指标服务响应格式无效'));}});
      });
      const timer=setTimeout(()=>req.destroy(Error('指标服务请求超时')),15000);req.on('close',()=>clearTimeout(timer));req.on('error',()=>reject(Error(service+' 连接失败或超时，请稍后重试')));
    });
  }
  retryMessage(retryAt){return '本地暂停至 '+new Date(retryAt).toLocaleString('zh-CN',{hour12:false})+'，之后可手动重试；已有指标保留';}
  responseError(host,service,status,retryAfter){
    const retry=String(retryAfter||'').trim(),retryMs=/^\d+$/.test(retry)?Number(retry)*1000:Date.parse(retry)-this.now();
    const validRetry=retryMs>=0&&Number.isFinite(retryMs)&&Number.isFinite(new Date(this.now()+retryMs).getTime());
    if(host==='api.semanticscholar.org'&&status===429){
      // Only a real 429 advances backoff. Skipped/queued requests retain the deadline.
      const attempt=Math.min(5,(this.serviceRateLimits.get(host)||0)+1);
      this.serviceRateLimits.set(host,attempt);
      const wait=validRetry?Math.max(5000,retryMs):Math.min(300000,30000*2**(attempt-1));
      this.serviceFailures.set(host,Math.max(this.serviceFailures.get(host)||0,this.now()+wait));
    }else if([403,429].includes(status))this.serviceFailures.set(host,this.now()+Math.max(3600000,validRetry?retryMs:0));
    const reason=status===429?'请求过于频繁（HTTP 429）':status===401||status===403?'访问受限，请检查该服务 API Key（HTTP '+status+'）':'返回 HTTP '+status;
    const retryAt=[403,429].includes(status)?this.serviceFailures.get(host):undefined;
    const error=Error(service+' '+reason+(retryAt?'；'+this.retryMessage(retryAt):''));error.status=status;if(retryAt)error.retryAt=retryAt;return error;
  }
  async cached(key,fetcher,force=false) {
    await this.ready;if(this.stopped)throw Error('已停止指标查询');
    const old=this.cache[key],fresh=old&&this.now()-(old.checkedAt||old.updatedAt)<7*86400000;
    if(!force&&fresh||typeof force==='number'&&old&&(old.checkedAt||old.updatedAt)>=force||typeof force==='string'&&old&&this.rounds.get(key)===force)return old;
    const failure=this.failures.get(key);if(failure&&this.now()<failure.until){if(old)return {...old,warning:failure.message};const error=Error(failure.message);error.status=failure.status;error.code=failure.code;error.retryAt=failure.until;throw error;}
    if(this.inflight.has(key))return this.inflight.get(key);
    const job=this.tail.catch(()=>{}).then(async()=>{
      if(this.stopped)throw Error('已停止指标查询');
      try {const value=await fetcher(),entry=KnowledgeLibraryMetrics.mergeRecord(old,{...value,updatedAt:this.now(),checkedAt:this.now()});this.cache[key]=entry;if(typeof force==='string')this.rounds.set(key,force);
        await this.store.locked(async()=>{let disk={};try{disk=JSON.parse(await this.store.readOptional(this.cacheFile))?.entries||{};}catch(_){}await this.store.atomic(this.cacheFile,JSON.stringify({version:1,entries:{...disk,...this.cache}}));});
        this.failures.delete(key);return entry;
      }catch(error){const message=String(error.message).slice(0,180);
        // A skipped request inherits the service deadline; visiting another DOI or
        // clicking refresh near its end must not extend it, even if it just expired.
        const until=Number.isFinite(error.retryAt)?error.retryAt:this.now()+(error.status===429&&key.startsWith('s2:')?30000:error.status===429||error.status===403?3600000:600000);
        this.failures.set(key,{until,message,status:error.status,code:error.code});if(old)return {...old,warning:message};throw error;}
    }).finally(()=>this.inflight.delete(key));this.inflight.set(key,job);this.tail=job;return job;
  }
  async readItems(items,{force=false,startedAt=0,round='',verifyCNKI}={}) {
    const settings=this.settings(),records=[],warnings=[],journals=new Map(),dois=new Map();
    for(const item of items) {
      if(this.stopped)break;if(item.deleted||!KnowledgeLibraryMetrics.eligible(item))continue;
      const identity=KnowledgeLibraryMetrics.identity(item),record={id:item.id,...identity};
      if(identity.journal&&settings.secretKey) {
        const names=KnowledgeLibraryMetrics.aliases(identity.journal,settings.aliases),key=JSON.stringify(['journal',...names.map(n=>n.toLowerCase())]);
        try {
          if(!journals.has(key))journals.set(key,this.cached(key,async()=>{const ranks={};for(const name of names){const response=await this.request('https://www.easyscholar.cc/open/getPublicationRank?secretKey='+encodeURIComponent(settings.secretKey)+'&publicationName='+encodeURIComponent(name));const found=KnowledgeLibraryMetrics.parseRanks(response);for(const [field,value]of Object.entries(found))if(!Object.hasOwn(ranks,field))ranks[field]=value;}return {ranks,source:'easyScholar'};},force?(round||startedAt||true):false));
          record.publication=await journals.get(key);if(record.publication.warning)warnings.push(record.publication.warning);
        }catch(e){warnings.push(e.message);}
      }else if(identity.journal&&force)warnings.push('期刊指标需要 easyScholar API Key，请打开“期刊标签”的列设置');
      // Do not query public fallbacks or read citation caches before local API setup.
      if(!String(this.settings().semanticKey||'').trim()){
        if(force)warnings.push('请先在“被引数”列设置中填写 Semantic Scholar API Key');
        if(record.publication)records.push(record);
        continue;
      }
      if(identity.doi) {
        try {
          if(!dois.has(identity.doi))dois.set(identity.doi,this.cached('doi:'+identity.doi,async()=>{
            let response;try{response=await this.request('https://api.crossref.org/works/'+encodeURIComponent(identity.doi));}catch(e){if(e.status===404)return {count:null,source:'Crossref'};throw e;}
            const work=response?.message;if(KnowledgeLibraryMetrics.doi(work?.DOI)!==identity.doi)throw Error('Crossref DOI 不匹配，未采用返回结果');
            const count=work['is-referenced-by-count'];if(!Number.isSafeInteger(count)||count<0)throw Error('Crossref 未返回有效被引数');return {count,source:'Crossref'};
          },force?(round||startedAt||true):false));
          record.citations=await dois.get(identity.doi);if(record.citations.warning)warnings.push(record.citations.warning);
        }catch(e){warnings.push(e.message);}
      }
      const citationID=KnowledgeLibraryMetrics.citationIdentity(item);
      if(CNKI.eligible(item)){try{const cnki=await this.cnkiCitations(item,force?(round||startedAt||true):false,verifyCNKI);record.citations=KnowledgeLibraryMetrics.mergeRecord(record.citations,cnki);if(cnki.warning)warnings.push(cnki.warning);}catch(e){warnings.push(e.message);}}
      if(identity.doi){try{const semantic=await this.semanticCitations(identity.doi,force?(round||startedAt||true):false);record.citations=KnowledgeLibraryMetrics.mergeRecord(record.citations,semantic);if(semantic.warning)warnings.push(semantic.warning);}catch(e){warnings.push(e.status===404?'Semantic Scholar 尚未收录此 DOI，HI 和引用用途暂无数据':e.message);}}
      if(item.type==='book'){
        if(identity.isbn){try{const semantic=await this.bookCitations(identity.isbn,force?(round||startedAt||true):false);record.citations=KnowledgeLibraryMetrics.mergeRecord(record.citations,semantic);if(semantic.warning)warnings.push(semantic.warning);}catch(e){warnings.push(e.message);}}
        else warnings.push('书籍需要有效 ISBN（10 或 13 位）才能查询 Semantic Scholar；请在书籍信息中填写');
      }
      if(record.citations)record.citations={...record.citations,identity:citationID};
      records.push(record);
    }
    return {records,warnings:[...new Set(warnings)]};
  }
}
module.exports=KnowledgeLibraryMetrics;
