// Per-question images are shared by formal and temporary chats, independent of frozen references.
class EditingToolbarAIInputMedia {
  constructor(ai,changed,temporary=null){this.ai=ai;this.changed=changed;this.temporary=temporary;this.items=[];this.job=0;}
  static dragType='application/x-et-chat-image';
  locked(){return this.temporary?!!this.temporary.busy:!!(this.ai.composerLocked?.()??this.ai.busy);}
  notice(message){if(this.temporary)this.temporary.error(Error(message));else this.ai.notice(message,true);}
  syncOwner(){if(this.temporary)this.temporary.sync();else this.ai.composerUI.sync();}
  startDrag(dt,item){
    if(!dt||!item?.data)return false;
    const {name,data,width,height}=item,token=crypto.randomUUID();
    // Only the gesture token enters native drag data; image bytes stay in this window.
    EditingToolbarAIInputMedia.drag={owner:this,token,image:{name,data,width,height}};
    dt.clearData();dt.setData(EditingToolbarAIInputMedia.dragType,token);dt.effectAllowed='copy';return true;
  }
  bindDrag(node,getImage){node.draggable=true;node.addEventListener('dragstart',e=>{if(!this.startDrag(e.dataTransfer,getImage()))return e.preventDefault();e.stopPropagation();});node.addEventListener('dragend',()=>{if(EditingToolbarAIInputMedia.drag?.owner===this)EditingToolbarAIInputMedia.drag=null;});}

  mount(before){
    const a=this.ai;this.tray=a.node('div','et-ai-input-images');this.tray.setAttribute('aria-label','待发送图片');before.before(this.tray);
    this.surface=this.temporary?.composer||a.panel.querySelector('.et-ai-composer');this.hint=a.node('div','et-ai-drop-hint',this.temporary?'添加到临时聊天':'添加到对话');this.surface.append(this.hint);
    if(!this.temporary){document.addEventListener('pointerdown',e=>{const img=this.sourceImage(e.target);if(e.button===0&&img&&!a.panel.hidden&&!this.locked()&&!this.pending){this.bodyCandidate=this.bodyPacket(img);this.prepareBody(this.bodyCandidate);}},true);
    for(const type of ['pointerup','pointercancel'])document.addEventListener(type,()=>{this.bodyCandidate=null;},true);
    document.addEventListener('dragstart',e=>{const img=this.sourceImage(e.target);if(img&&e.dataTransfer){this.bodyDrag=this.bodyPacket(img);this.bodyCandidate=null;this.prepareBody(this.bodyDrag);if(img.closest('.et-notebook'))e.dataTransfer.clearData();e.dataTransfer.setData('application/x-et-document-image','1');e.dataTransfer.effectAllowed='copy';e.stopPropagation();}},true);}
    document.addEventListener('dragend',()=>{EditingToolbarAIInputMedia.drag=null;this.bodyCandidate=this.bodyDrag=null;this.surface.classList.remove('et-ai-drag-over');},true);
    const zone=this.temporary?this.surface:a.panel;
    for(const type of ['dragenter','dragover'])zone.addEventListener(type,e=>{if(!this.acceptsDrop(e))return;e.preventDefault();e.stopPropagation();e.dataTransfer.dropEffect=this.locked()||this.pending?'none':'copy';this.surface.classList.toggle('et-ai-drag-over',!this.locked()&&!this.pending);},true);
    zone.addEventListener('dragleave',e=>{if(!zone.contains(e.relatedTarget))this.surface.classList.remove('et-ai-drag-over');},true);
    zone.addEventListener('drop',e=>{if(!this.acceptsDrop(e))return;e.preventDefault();e.stopImmediatePropagation();this.surface.classList.remove('et-ai-drag-over');void this.receive(e.dataTransfer);},true);
    this.surface.addEventListener('paste',e=>{const files=[...(e.clipboardData?.files||[])].filter(f=>f.type.startsWith('image/'));if(!files.length)return;e.preventDefault();e.stopImmediatePropagation();void this.receiveFiles(files);},true);
    this.sync();
  }
  sourceImage(target){return target.closest?.('#write img,.et-nb-output-image');}
  acceptsDrop(event){if([...event.dataTransfer?.types||[]].some(t=>['application/x-et-code-file','application/x-et-project-files'].includes(t)))return false;return this.accepts(event.dataTransfer)&&(this.surface.contains(event.target)||[...event.dataTransfer.types].some(t=>[EditingToolbarAIInputMedia.dragType,'application/x-et-document-image','application/x-et-document-tab'].includes(t)));}
  accepts(dt){return !!dt&&[...dt.types].some(t=>[EditingToolbarAIInputMedia.dragType,'application/x-et-document-tab','Files','application/x-et-materials','application/x-et-document-image','text/plain','text/html','text/uri-list'].includes(t));}
  snapshot(){return this.items.map(({id,name,data,width,height})=>({id,name,data,width,height}));}
  restore(items){this.cancel();this.items=Array.isArray(items)?items.filter(x=>typeof x.data==='string'&&/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(x.data)&&x.data.length<7*1024*1024).slice(0,4).map(x=>({...x,id:x.id||crypto.randomUUID()})):[];this.sync();}
  cancel(){if(EditingToolbarAIInputMedia.drag?.owner===this)EditingToolbarAIInputMedia.drag=null;this.job++;this.pending=false;this.pendingPreview=null;this.bodyCandidate=this.bodyDrag=null;this.surface?.classList.remove('et-ai-drag-over');this.dialog?.close();this.sync();}
  clear(){this.cancel();this.items=[];this.sync();}
  sync(){
    if(!this.tray)return;this.tray.hidden=!this.items.length&&!this.pending;this.cards ||= new Map();
    const ids=new Set(this.items.map(item=>item.id));for(const [id,ui]of this.cards)if(!ids.has(id)){ui.card.remove();this.cards.delete(id);}
    for(const [index,item]of this.items.entries()){
      let ui=this.cards.get(item.id);
      if(!ui){const card=this.ai.node('div','et-ai-input-image'),b=this.ai.node('button','et-ai-input-image-preview'),img=this.ai.node('img'),remove=this.ai.node('button','et-ai-input-image-remove','×');
        b.type=remove.type='button';img.decoding='async';img.draggable=false;b.append(img);card.append(b,remove);ui={card,b,img,remove};this.cards.set(item.id,ui);
        this.bindDrag(b,()=>ui.item);b.onclick=()=>this.preview(ui.item);remove.onclick=()=>{this.items=this.items.filter(x=>x.id!==ui.item.id);this.changed();};
      }
      if(ui.item?.data!==item.data)ui.img.src=item.data;
      if(ui.item?.name!==item.name){ui.b.setAttribute('aria-label','预览待发送图片 '+item.name);ui.b.title=item.name+'（可拖入其他聊天）';ui.img.alt=item.name;ui.remove.setAttribute('aria-label','移除图片 '+item.name);}
      ui.item=item;ui.remove.disabled=this.locked()||this.pending;
      if(this.tray.children[index]!==ui.card)this.tray.insertBefore(ui.card,this.tray.children[index]||null);
    }
    if(this.pending){
      if(!this.loadingCard){const card=this.ai.node('div','et-ai-input-image et-ai-image-loading');card.setAttribute('role','status');card.setAttribute('aria-label','正在读取图片');card.append(this.ai.node('span','','读取中…'));this.loadingCard=card;this.tray.append(card);}
      if(this.loadingPreview!==this.pendingPreview){this.loadingCard.querySelector('img')?.remove();if(this.pendingPreview){const img=this.ai.node('img');img.src=this.pendingPreview;img.alt='';img.decoding='async';this.loadingCard.prepend(img);}this.loadingPreview=this.pendingPreview;}
    }else{this.loadingCard?.remove();this.loadingCard=null;this.loadingPreview=null;}
  }
  static sentImages(turn,reference){
    const uploaded=(turn.webChat?.input?.files||[]).filter(f=>/^image\/(png|jpeg|webp)$/.test(f.type)&&typeof f.base64==='string').map(f=>({name:f.name,data:'data:'+f.type+';base64,'+f.base64}));
    const rows=[...(reference?.images||(reference?.image?[reference.image]:[])),...(turn.requestContext?.images||[]),...uploaded],seen=new Set();
    return rows.filter(i=>{if(!i||typeof i.data!=='string'||i.data.length>7*1024*1024||!/^data:image\/(png|jpeg|webp);base64,/.test(i.data)||seen.has(i.data))return false;seen.add(i.data);return true;}).slice(0,4);
  }
  renderSent(article,turn,reference=null){
    const items=EditingToolbarAIInputMedia.sentImages(turn,reference);if(!items.length)return;
    const gallery=this.ai.node('div','et-ai-sent-images');gallery.setAttribute('aria-label','已发送的图片');
    for(const [index,item]of items.entries()){const name=item.name||'图片 '+(index+1),b=this.ai.node('button','et-ai-sent-image'),img=this.ai.node('img');b.type='button';b.title=name;b.setAttribute('aria-label','查看图片 '+name);img.src=item.data;img.alt=name;img.decoding='async';img.draggable=false;b.append(img);this.bindDrag(b,()=>({...item,name}));b.onclick=()=>this.preview({...item,name});gallery.append(b);}
    article.append(gallery);
  }
  preview(item){this.dialog?.remove();const d=this.dialog=this.ai.node('dialog','et-ai-input-image-dialog'),img=this.ai.node('img'),close=this.ai.node('button','','×');d.setAttribute('aria-label','图片预览');img.src=item.data;img.alt=item.name;close.type='button';close.setAttribute('aria-label','关闭图片预览');close.onclick=()=>d.close();d.append(img,close);document.body.append(d);d.addEventListener('close',()=>{d.remove();if(this.dialog===d)this.dialog=null;},{once:true});d.showModal();close.focus();}
  async decode(data,name){
    if(!/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(data)||data.length>Math.ceil(5*1024*1024/3)*4+64)throw Error(name+'：请选择 5 MB 以内的 PNG、JPG 或 WebP 图片');
    const image=new Image();image.src=data;try{await image.decode();}catch{throw Error(name+'：图片无法读取');}if(image.naturalWidth>12000||image.naturalHeight>12000)throw Error(name+'：图片尺寸过大');
    return{id:reqnode('crypto').createHash('sha256').update(data).digest('hex'),name,data,width:image.naturalWidth,height:image.naturalHeight};
  }
  async fileImage(file){if(file.size>5*1024*1024)throw Error(file.name+'：图片超过 5 MB');const bytes=reqnode('buffer').Buffer.from(await file.arrayBuffer());const mime=bytes.subarray(0,8).equals(reqnode('buffer').Buffer.from([137,80,78,71,13,10,26,10]))?'image/png':bytes[0]===255&&bytes[1]===216?'image/jpeg':bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP'?'image/webp':'';return this.decode('data:'+mime+';base64,'+bytes.toString('base64'),file.name||'图片');}
  async imageSource(src,file,img=null,root=''){
    const name=img?.getAttribute('alt')||String(src).split(/[\\/]/).at(-1)?.slice(0,120)||'图片';
    if(/^data:image\/(?:png|jpeg|webp);base64,/i.test(src))return this.decode(src,name);
    const entry=this.ai.imagesUI.scanner.resolve({src,label:name},file,root);
    if(!entry.error){const descriptor=await this.ai.attachments.io.describe(entry.path,'拖入图片'),loaded=await this.ai.attachments.io.read(descriptor);return this.decode(loaded.data,loaded.name);}
    // A rendered remote/embedded image can be copied without re-fetching its URL.
    if(img?.complete&&img.naturalWidth&&img.naturalWidth<=12000&&img.naturalHeight<=12000){try{return await this.renderedImage(img,name);}catch{}}
    throw Error(entry.error||'图片无法读取，请先保存到本机');
  }
  async renderedImage(img,name){
    // SVG/remote previews become a bounded raster only for the chat attachment.
    // Async encoding avoids blocking pointer movement on a large scientific plot.
    const scale=Math.min(1,4096/Math.max(img.naturalWidth,img.naturalHeight)),canvas=document.createElement('canvas');
    canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));
    try{canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(Error('图片转换失败')),'image/png'));return await this.fileImage({name:name.replace(/\.svg$/i,'.png'),size:blob.size,arrayBuffer:()=>blob.arrayBuffer()});}
    finally{canvas.width=canvas.height=1;}
  }
  bodyPacket(img){
    const src=img.currentSrc||img.getAttribute('src'),file=this.ai.file(),candidate=this.bodyCandidate;
    return candidate?.img===img&&candidate.src===src&&candidate.file===file?candidate:{img,src,file};
  }
  prepareBody(body){
    if(body.prepared)return body.prepared;
    // Start local IO while the pointer is moving. Typora's rendered absolute URL
    // already includes its image root, so a normal drop need not serialize Markdown.
    body.prepared=Promise.resolve().then(async()=>{const src=body.src||body.image;let root='';
      if(!/^(?:file:|data:|https?:|[a-z]:[\\/])/i.test(src)){let fallback='';try{fallback=File.editor.localSettingBridge?.getSetting('typora-root-url')||'';}catch{}root=this.ai.imagesUI.scanner.root(this.ai.source(),fallback);}
      return {image:await this.imageSource(src,body.file,body.img,root)};
    }).catch(error=>({error}));return body.prepared;
  }
  async commit(load,preview=null){
    const a=this.ai,t=this.temporary;if(this.locked()||this.pending)return this.notice('请等待当前操作完成后再添加资料');if(t?!t.dialog.open:!a.followDocument())return;
    const job=++this.job,context=t?t.generation:a.context,file=t?t.file:a.file();this.pending=true;this.pendingPreview=preview;this.sync();this.syncOwner();
    const current=()=>job===this.job&&!this.locked()&&(t?t.dialog.open&&context===t.generation&&file===t.file:context===a.context&&file===a.file()&&!a.panel.hidden&&!File.isFileLoading?.());
    try{const {images=[],quotes=[]}=await load();if(!current())return;
      const next=new Map(this.items.map(x=>[x.data,x]));for(const img of images)if(!next.has(img.data))next.set(img.data,img);
      const baseImages=t?0:a.attachments.frozen?.images?.length??(a.attachments.selected.filter(f=>f.kind==='image').length+(a.context.image?1:0));if(next.size+baseImages>4)throw Error('一次最多添加 4 张图片，请先移除一张');
      const q=t?t.quotes:a.composerUI.draft.quotes,unique=quotes.filter((x,i)=>!q.items.some(v=>v.text===x.text&&v.file===x.file)&&quotes.findIndex(v=>v.text===x.text&&v.file===x.file)===i);
      if(q.items.length+unique.length>20||[...q.items,...unique].reduce((n,x)=>n+x.text.length,0)>100000)throw Error('引用过多，请减少到 20 段、10 万字符以内');
      this.items=[...next.values()];this.pending=false;this.pendingPreview=null;for(const item of unique)q.add(item);this.changed();(t?.prompt||a.prompt).focus();
    }catch(e){if(current())this.notice(e.message);}finally{if(job===this.job){this.pending=false;this.pendingPreview=null;this.sync();this.syncOwner();}}
  }
  receiveFiles(files){return this.commit(async()=>({images:await Promise.all(files.map(f=>this.fileImage(f)))}));}
  receive(dt){
    // Snapshot protected drag data before the asynchronous reads begin.
    const a=this.ai,types=[...dt.types];
    if(types.includes('application/x-et-document-tab')){
      const file=dt.getData('application/x-et-document-tab'),tabs=a.toolbar.documentTabs;
      if(!file||!reqnode('path').isAbsolute(file)||!tabs?.supported(file))return this.notice('请拖入已保存的 Markdown 文档');
      if(this.temporary)return this.notice('请将文档拖入主对话的 AI 阅读助手');
      if(this.locked()||a.attachments.pending||a.attachments.locked())return this.notice('当前资料已锁定，请在新对话中添加文档');
      return a.attachments.add([{path:file,location:'标签页'}]);
    }
    if(types.includes(EditingToolbarAIInputMedia.dragType)){
      const transfer=EditingToolbarAIInputMedia.drag;if(!transfer||dt.getData(EditingToolbarAIInputMedia.dragType)!==transfer.token)return this.notice('图片拖放已失效，请重新拖动');
      const image={...transfer.image};return this.commit(async()=>({images:[await this.decode(image.data,image.name||'图片')]}),image.data);
    }
    const materials=a.toolbar.researchMaterials,own=materials?.materialDrag(dt),body=this.bodyDrag||a.composerUI.draft.media?.bodyDrag||materials?.inboundDrag;
    const session=own?{file:a.file(),dir:own.ctx.dir,items:own.items.map(x=>({...x}))}:null;
    if(session)return this.commit(async()=>{const images=[],quotes=[];for(const item of session.items){if(/video/i.test(item.kind)||/<video\b/i.test(item.markdown))throw Error('暂不支持视频素材，请拖入文字、公式或图片');
      const refs=a.imagesUI.scanner.references(item.markdown,EditingToolbarAIImages.htmlImages);for(const ref of refs)images.push(await this.imageSource(ref.src,reqnode('path').join(session.dir,'material.md')));
      if(item.kind!=='image'&&item.markdown.trim())quotes.push({text:item.markdown,file:session.file,source:'素材 · '+item.title});}
      return{images,quotes};});
    if(types.includes('application/x-et-materials'))return this.notice('素材拖放已失效，请重新拖动');
    if(types.includes('application/x-et-document-image')){
      if(!body||body.file!==a.file())return this.notice('文档已切换，请重新拖动图片');
      const prepared=this.prepareBody(body);return this.commit(async()=>{const result=await prepared;if(result.error)throw result.error;return{images:[result.image]};},body.img?.currentSrc||null);
    }
    // Native file payloads may materialize a temporary image on Windows. An
    // internal document/material drag already has its source; never request them.
    const files=[...dt.files];if(files.length)return this.receiveFiles(files);
    const text=dt.getData('text/plain'),html=dt.getData('text/html'),uri=dt.getData('text/uri-list').split(/\r?\n/).find(x=>x&&!x.startsWith('#')); 
    const image=EditingToolbarAIImages.htmlImages(html)[0];if(image||uri&&/^file:/i.test(uri))return this.commit(async()=>({images:[await this.imageSource(image?.src||uri,a.file())]}));
    if(text.trim())return this.commit(async()=>({quotes:[{text:text.trim(),file:a.file(),source:'拖入文字'}]}));
  }
}
