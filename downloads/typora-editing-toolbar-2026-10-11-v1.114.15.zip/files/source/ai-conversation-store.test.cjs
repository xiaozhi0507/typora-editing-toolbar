const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const Store=require('./ai-conversation-store.cjs');
function fixture(t){
  const base=path.join(os.homedir(),'Downloads','codex-temp');fs.mkdirSync(base,{recursive:true});
  const directory=fs.mkdtempSync(path.join(base,'ai-conversation-test-')),store=new Store(require,directory);
  t.after(()=>{const target=path.resolve(directory);if(!target.startsWith(path.resolve(base)+path.sep))throw Error('Unsafe test cleanup');fs.rmSync(target,{recursive:true,force:true});});
  return store;
}
const record=s=>({id:s.id(),title:'阅读笔记',file:'C:/books/chapter.md',turns:[{question:'解释原文',answer:'回答',status:'done'}],draft:''});
test('reference text and image bytes survive updates, clear removes the snapshot',t=>{
  const s=fixture(t),snapshot={reference:{text:'原始文档',images:[{data:'data:image/png;base64,dGVzdA=='}]}};
  const first=s.write(record(s),null,snapshot),renamed=s.write({...first,title:'新名称'},first.revision);
  assert.deepEqual(s.context(renamed),snapshot);assert.equal(renamed.contextFile,first.contextFile);
  const cleared=s.write({...renamed,turns:[]},renamed.revision,null);assert.equal(s.context(cleared),null);assert.equal(fs.existsSync(path.join(s.folder(first.id),first.contextFile)),false);
});
test('concurrent revisions and tombstones prevent lost writes and resurrection',async t=>{
  const s=fixture(t),first=s.write(record(s),null),newer=s.write({...first,title:'其他窗口'},first.revision);
  assert.throws(()=>s.write({...first,title:'过时修改'},first.revision),{code:'CHAT_CONFLICT'});assert.equal(s.read(first.id).title,'其他窗口');
  s.remove(newer);assert.equal((await s.list()).records.length,0);assert.throws(()=>s.write(first,first.revision),{code:'CHAT_CONFLICT'});
});
test('corrupt records are reported and never overwritten',async t=>{
  const s=fixture(t),r=record(s);fs.mkdirSync(s.folder(r.id));const file=path.join(s.folder(r.id),'state.json');fs.writeFileSync(file,'broken');
  assert.equal((await s.list()).errors,1);assert.throws(()=>s.write(r,null));assert.equal(fs.readFileSync(file,'utf8'),'broken');
});
test('active locks fail safely and invalid IDs cannot escape the storage folder',t=>{
  const s=fixture(t),r=s.write(record(s),null),lock=path.join(s.folder(r.id),'write.lock');fs.writeFileSync(lock,'');
  assert.throws(()=>s.write({...r,title:'blocked'},r.revision),/另一个窗口/);assert.equal(s.read(r.id).title,'阅读笔记');assert.throws(()=>s.folder('../../escape'));
});
test('legacy turn IDs are stable across list/read and independent favorite snapshots survive source deletion',async t=>{
  const s=fixture(t),r=record(s);fs.mkdirSync(s.folder(r.id));s.atomic(path.join(s.folder(r.id),'state.json'),{...r,version:1,revision:s.id()});
  const read=s.read(r.id),listed=(await s.list()).records[0];assert.equal(read.turns[0].id,listed.turns[0].id);assert.equal(s.read(r.id).turns[0].id,read.turns[0].id);
  const favorites=new Store(require,path.join(s.directory,'favorites')),id=s.stableId('answer:'+read.turns[0].id);
  const favorite=favorites.write({...read,id,kind:'favorite',originId:read.id},null,null);s.remove(read);
  assert.equal((await s.list()).records.length,0);assert.equal((await favorites.list()).records.length,1);assert.equal(favorites.read(id).turns[0].answer,'回答');
  favorites.remove(favorite);assert.equal((await favorites.list()).records.length,0);
});
