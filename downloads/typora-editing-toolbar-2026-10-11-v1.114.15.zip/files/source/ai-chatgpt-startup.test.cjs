'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{EventEmitter}=require('node:events'),{JSDOM}=require('jsdom');
const source=fs.readFileSync(path.join(__dirname,'ai-chatgpt.js'),'utf8')+'\nEditingToolbarAIChatGPT;';
const tick=()=>new Promise(r=>setImmediate(r));
function setup(t,{versions={},found=[],env={},openExternal=async()=>{},probe}={}){
 const dom=new JSDOM('<div id="et-ai-preferences"><nav></nav><p id="status"></p></div>',{runScripts:'outside-only'}),w=dom.window;t.after(()=>w.close());
 const calls={exec:[],spawn:[],urls:[],writes:[]};let child;
 const cp={execFile(file,args,options,done){calls.exec.push({file,args,options});setImmediate(()=>{if(probe)return probe(file,args,done);done(null,args[0]==='node.exe'?found.join('\r\n'):(versions[file]||''));});},spawn(file,args,options){calls.spawn.push({file,args,options});child=new EventEmitter();child.stdout=new EventEmitter();child.stdout.setEncoding=()=>{};child.stderr={resume(){}};child.stdin=new EventEmitter();child.stdin.end=()=>{};child.stdin.write=text=>{const m=JSON.parse(text);calls.writes.push(m);if(m.method==='list')setImmediate(()=>child.stdout.emit('data',JSON.stringify({id:m.id,result:[]})+'\n'));};child.kill=()=>{};return child;}};
 w.reqnode=n=>n==='child_process'?cp:n==='path'?path.win32:n==='fs'?{existsSync:file=>file.endsWith('chatgpt.cjs')||Object.hasOwn(versions,file)}:n==='process'?{resourcesPath:'C:\\Typora\\resources',env:{SystemRoot:'C:\\Windows',...env}}:n==='electron'?{shell:{openExternal:async url=>{calls.urls.push(url);return openExternal(url);}}}:require(n);
 w.File={option:{userDataPath:'C:\\TestData'}};
 const UI=vm.runInContext(source,dom.getInternalVMContext()),ai={nav:w.document.querySelector('nav'),preferencesStatus:w.document.querySelector('#status'),node(tag,cls='',text=''){const e=w.document.createElement(tag);e.className=cls;e.textContent=text;return e;},profile:()=>null};ai.nav.append(ai.node('button','','模型'));
 const ui=new UI(ai);ui.mount();t.after(()=>ui.shutdown());return{ui,w,calls,child:()=>child,versions};
}
test('missing Node exposes official download and retry without freezing or launching a browser automatically',async t=>{
 const f=setup(t),job=f.ui.open();assert(f.ui.busy);assert.match(f.ui.message.textContent,/正在检测/);assert.equal(f.calls.spawn.length,0);await job;
 assert(!f.ui.busy);assert(!f.ui.nodeHelp.hidden);assert.match(f.ui.message.textContent,/Node.js 18\+/);assert.equal(f.calls.urls.length,0);assert(!f.ui.recheck.disabled);
 await f.ui.downloadNode();assert.deepEqual(f.calls.urls,['https://nodejs.org/en/download']);assert(f.ui.downloadAddress.hidden);assert.match(f.ui.message.textContent,/LTS/);
});
test('download failure exposes a selected copyable official URL and leaves the retry button usable',async t=>{
 const f=setup(t,{openExternal:async()=>{throw Error('browser unavailable');}});await f.ui.open();await f.ui.downloadNode();assert(!f.ui.downloadAddress.hidden);assert(f.ui.downloadAddress.readOnly);assert.equal(f.ui.downloadAddress.value,'https://nodejs.org/en/download');assert.equal(f.ui.downloadAddress.selectionEnd,f.ui.downloadAddress.value.length);assert(!f.ui.download.disabled);assert.match(f.ui.message.textContent,/复制/);
});
test('too-old or invalid Node output is rejected and a later compatible PATH candidate is selected',async t=>{
 const f=setup(t,{found:['C:\\old\\node.exe','C:\\bad\\node.exe','D:\\Node\\node.exe'],versions:{'C:\\old\\node.exe':'16.20.2','C:\\bad\\node.exe':'99 garbage','D:\\Node\\node.exe':'22.20.0'}});await f.ui.open();assert(!f.ui.nodeMissing);assert(f.ui.nodeHelp.hidden);assert.equal(f.calls.spawn[0].file,'D:\\Node\\node.exe');assert.equal(f.ui.message.textContent,'');
});
test('a standard Node install is detected after installation without restarting a stale-PATH Typora',async t=>{
 const versions={},f=setup(t,{versions,env:{ProgramFiles:'C:\\Program Files'}});await f.ui.open();assert(f.ui.nodeMissing);versions['C:\\Program Files\\nodejs\\node.exe']='24.0.0';await f.ui.open();assert(!f.ui.nodeMissing);assert(f.ui.nodeHelp.hidden);assert.equal(f.calls.spawn.length,1);assert.equal(f.calls.spawn[0].file,'C:\\Program Files\\nodejs\\node.exe');
});
test('concurrent startup callers share detection and remove Electron/Node injected flags',async t=>{
 const f=setup(t,{found:['D:\\Node\\node.exe'],versions:{'D:\\Node\\node.exe':'22.0.0'},env:{ELECTRON_RUN_AS_NODE:'1',NODE_OPTIONS:'--inspect',NODE_PATH:'private'}});await Promise.all([f.ui.call('list'),f.ui.call('list')]);assert.equal(f.calls.spawn.length,1);assert.equal(f.calls.exec.filter(c=>c.args[0]==='node.exe').length,1);for(const c of [...f.calls.exec,...f.calls.spawn])for(const key of ['ELECTRON_RUN_AS_NODE','NODE_OPTIONS','NODE_PATH'])assert.equal(c.options.env[key],undefined);
});
test('cancel during detection never sends a sign-in request or opens the browser',async t=>{
 const f=setup(t),job=f.ui.signIn();f.ui.controller.abort();await job;assert.equal(f.calls.spawn.length,0);assert.equal(f.calls.writes.length,0);assert.equal(f.calls.urls.length,0);assert(!f.ui.busy);assert(!f.ui.signingIn);assert.equal(f.ui.message.textContent,'');
});
test('shutdown during detection does not resurrect a helper process',async t=>{
 let release;const f=setup(t,{found:[],probe:(_file,_args,done)=>{release=done;}}),job=f.ui.call('list');await tick();f.ui.shutdown();release(null,'');await assert.rejects(job);assert.equal(f.calls.spawn.length,0);
});
test('login browser failure remains visible and offers a retry for the same pending authorization',async t=>{
 let fail=true;const f=setup(t,{openExternal:async()=>{if(fail)throw Error('no browser');}});f.ui.signingIn=true;await f.ui.authorize('https://auth.openai.com/api/accounts/authorize?state=test','login-id');assert(!f.ui.browserLogin.hidden);assert.match(f.ui.message.textContent,/无法打开浏览器/);fail=false;await f.ui.browserLogin.onclick();assert.equal(f.calls.urls.length,2);assert.match(f.ui.message.textContent,/请在浏览器/);
});
test('authorization rejects unexpected hosts, credentials and token hints before opening anything',async t=>{
 const f=setup(t);for(const url of ['https://example.com/api/accounts/authorize','https://auth.openai.com/other','https://user:password@auth.openai.com/api/accounts/authorize','https://auth.openai.com/api/accounts/authorize?id_token_hint=secret'])await assert.rejects(f.ui.authorize(url,'id'),/登录地址无效/);assert.equal(f.calls.urls.length,0);
});
