class EditingToolbarAIConversations {
  constructor(ai) {
    this.ai=ai;
    this.record=null;this.snapshotSaved=false;this.serial=0;
    window.addEventListener('beforeunload',()=>this.flush());window.addEventListener('unload',()=>this.flush());
  }
  node(tag,cls,text) {return this.ai.node(tag,cls,text);}
  icon(name) {
    // Copy and star preserve the Codex SVG geometry; note follows its page-and-pencil silhouette.
    const answerIcons={"copy":"<svg class=\"et-ai-solid-icon\" viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M12.7587 2H16.2413C17.0463 1.99999 17.7106 1.99998 18.2518 2.04419C18.8139 2.09012 19.3306 2.18868 19.816 2.43597C20.5686 2.81947 21.1805 3.43139 21.564 4.18404C21.8113 4.66937 21.9099 5.18608 21.9558 5.74817C22 6.28936 22 6.95372 22 7.75868V11.2413C22 12.0463 22 12.7106 21.9558 13.2518C21.9099 13.8139 21.8113 14.3306 21.564 14.816C21.1805 15.5686 20.5686 16.1805 19.816 16.564C19.3306 16.8113 18.8139 16.9099 18.2518 16.9558C17.8906 16.9853 17.4745 16.9951 16.9984 16.9984C16.9951 17.4745 16.9853 17.8906 16.9558 18.2518C16.9099 18.8139 16.8113 19.3306 16.564 19.816C16.1805 20.5686 15.5686 21.1805 14.816 21.564C14.3306 21.8113 13.8139 21.9099 13.2518 21.9558C12.7106 22 12.0463 22 11.2413 22H7.75868C6.95372 22 6.28936 22 5.74818 21.9558C5.18608 21.9099 4.66937 21.8113 4.18404 21.564C3.43139 21.1805 2.81947 20.5686 2.43597 19.816C2.18868 19.3306 2.09012 18.8139 2.04419 18.2518C1.99998 17.7106 1.99999 17.0463 2 16.2413V12.7587C1.99999 11.9537 1.99998 11.2894 2.04419 10.7482C2.09012 10.1861 2.18868 9.66937 2.43597 9.18404C2.81947 8.43139 3.43139 7.81947 4.18404 7.43598C4.66937 7.18868 5.18608 7.09012 5.74817 7.04419C6.10939 7.01468 6.52548 7.00487 7.00162 7.00162C7.00487 6.52548 7.01468 6.10939 7.04419 5.74817C7.09012 5.18608 7.18868 4.66937 7.43598 4.18404C7.81947 3.43139 8.43139 2.81947 9.18404 2.43597C9.66937 2.18868 10.1861 2.09012 10.7482 2.04419C11.2894 1.99998 11.9537 1.99999 12.7587 2ZM9.00176 7L11.2413 7C12.0463 6.99999 12.7106 6.99998 13.2518 7.04419C13.8139 7.09012 14.3306 7.18868 14.816 7.43598C15.5686 7.81947 16.1805 8.43139 16.564 9.18404C16.8113 9.66937 16.9099 10.1861 16.9558 10.7482C17 11.2894 17 11.9537 17 12.7587V14.9982C17.4455 14.9951 17.7954 14.9864 18.089 14.9624C18.5274 14.9266 18.7516 14.8617 18.908 14.782C19.2843 14.5903 19.5903 14.2843 19.782 13.908C19.8617 13.7516 19.9266 13.5274 19.9624 13.089C19.9992 12.6389 20 12.0566 20 11.2V7.8C20 6.94342 19.9992 6.36113 19.9624 5.91104C19.9266 5.47262 19.8617 5.24842 19.782 5.09202C19.5903 4.7157 19.2843 4.40973 18.908 4.21799C18.7516 4.1383 18.5274 4.07337 18.089 4.03755C17.6389 4.00078 17.0566 4 16.2 4H12.8C11.9434 4 11.3611 4.00078 10.911 4.03755C10.4726 4.07337 10.2484 4.1383 10.092 4.21799C9.7157 4.40973 9.40973 4.7157 9.21799 5.09202C9.1383 5.24842 9.07337 5.47262 9.03755 5.91104C9.01357 6.20463 9.00489 6.55447 9.00176 7ZM5.91104 9.03755C5.47262 9.07337 5.24842 9.1383 5.09202 9.21799C4.7157 9.40973 4.40973 9.7157 4.21799 10.092C4.1383 10.2484 4.07337 10.4726 4.03755 10.911C4.00078 11.3611 4 11.9434 4 12.8V16.2C4 17.0566 4.00078 17.6389 4.03755 18.089C4.07337 18.5274 4.1383 18.7516 4.21799 18.908C4.40973 19.2843 4.7157 19.5903 5.09202 19.782C5.24842 19.8617 5.47262 19.9266 5.91104 19.9624C6.36113 19.9992 6.94342 20 7.8 20H11.2C12.0566 20 12.6389 19.9992 13.089 19.9624C13.5274 19.9266 13.7516 19.8617 13.908 19.782C14.2843 19.5903 14.5903 19.2843 14.782 18.908C14.8617 18.7516 14.9266 18.5274 14.9624 18.089C14.9992 17.6389 15 17.0566 15 16.2V12.8C15 11.9434 14.9992 11.3611 14.9624 10.911C14.9266 10.4726 14.8617 10.2484 14.782 10.092C14.5903 9.7157 14.2843 9.40973 13.908 9.21799C13.7516 9.1383 13.5274 9.07337 13.089 9.03755C12.6389 9.00078 12.0566 9 11.2 9H7.8C6.94342 9 6.36113 9.00078 5.91104 9.03755Z\"/></svg>","note":"<svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M10 20H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3h10a3 3 0 0 1 3 3v4M7 3v17m6.1-3.7 4.7-4.7a1.6 1.6 0 0 1 2.3 2.3l-4.7 4.7-3.1.8.8-3.1Zm3.8-3.8 2.3 2.3\"/></svg>","star":"<svg class=\"et-ai-solid-icon\" viewBox=\"0 0 20 20\" aria-hidden=\"true\"><path d=\"M10.155 1.25293C10.3063 1.2741 10.452 1.32704 10.5827 1.4082C10.7135 1.48938 10.8257 1.59644 10.9118 1.72266L10.989 1.85449L12.9519 5.83203C13.0346 5.99946 13.1573 6.14405 13.3083 6.25391C13.4593 6.36369 13.6344 6.43572 13.8191 6.46289L18.2097 7.10547C18.3622 7.12756 18.5069 7.18132 18.6364 7.2627L18.7605 7.35254L18.8698 7.45898C18.972 7.57277 19.0497 7.70704 19.0974 7.85352C19.1609 8.04881 19.169 8.25861 19.1198 8.45801C19.0829 8.60756 19.0152 8.74726 18.9216 8.86816L18.8191 8.98242L15.6443 12.0742C15.5103 12.2048 15.4101 12.3661 15.3523 12.5439C15.2944 12.7218 15.2807 12.9113 15.3122 13.0957L16.0603 17.4609C16.096 17.6639 16.075 17.8733 15.9978 18.0645C15.9205 18.2556 15.7905 18.4208 15.6237 18.542C15.4568 18.6632 15.2592 18.7357 15.0534 18.75C14.8486 18.7642 14.6441 18.7201 14.4626 18.624L10.5378 16.5615C10.3725 16.4748 10.1884 16.4287 10.0017 16.4287C9.81504 16.4288 9.6308 16.4738 9.46554 16.5605L9.46652 16.5615L5.54269 18.623C5.3608 18.7193 5.15616 18.7636 4.95089 18.749C4.74545 18.7344 4.54813 18.6622 4.38156 18.541C4.21504 18.4199 4.08569 18.2544 4.00851 18.0635C3.93176 17.8734 3.90914 17.6658 3.94406 17.4639L4.69308 13.0957C4.72467 12.9113 4.71089 12.7218 4.65304 12.5439C4.60961 12.4105 4.54232 12.2865 4.4548 12.1777L4.36105 12.0742L1.1882 8.98438C1.03999 8.84119 0.934373 8.65991 0.884489 8.45996C0.834601 8.25997 0.841377 8.04957 0.904996 7.85352L0.962614 7.71094C1.02987 7.57306 1.12554 7.44999 1.24386 7.35059L1.36886 7.26074C1.49799 7.18001 1.64284 7.12644 1.79464 7.10449L6.18527 6.46289L6.32199 6.43457C6.45645 6.39801 6.5836 6.33718 6.69699 6.25488C6.84822 6.14504 6.97064 5.99961 7.05343 5.83203L9.01632 1.85547C9.10726 1.67191 9.2476 1.51631 9.4216 1.4082C9.59587 1.30001 9.79753 1.24219 10.0027 1.24219L10.155 1.25293ZM4.93527 17.4746H4.93722L4.94113 17.4717C4.93917 17.4726 4.9372 17.4736 4.93527 17.4746ZM8.21945 6.40723C8.04338 6.76359 7.78322 7.07302 7.46164 7.30664C7.18022 7.51105 6.85868 7.653 6.51925 7.72363L6.37277 7.74902L2.38058 8.33203L5.26828 11.1426C5.55324 11.4202 5.76635 11.7642 5.88937 12.1426C6.01234 12.5209 6.04155 12.9233 5.97433 13.3154L5.29269 17.2871L8.86105 15.4102C9.21277 15.2255 9.60442 15.129 10.0017 15.1289C10.3989 15.1289 10.7906 15.2256 11.1423 15.4102L14.7116 17.2871L14.03 13.3145C13.963 12.9224 13.9929 12.5198 14.1159 12.1416C14.239 11.7635 14.4522 11.4211 14.737 11.1436L17.6218 8.33301L13.6306 7.74902C13.2377 7.69134 12.8648 7.53918 12.5437 7.30566C12.2226 7.07213 11.9628 6.76414 11.7868 6.4082L10.0017 2.79297L8.21945 6.40723Z\"/></svg>"};
    if(answerIcons[name])return answerIcons[name];
    const paths={copy:'M9 9h12v12H9zM15 9V3H3v12h6',star:'m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9z',retry:'M20 7v5h-5M4 17v-5h5M6 7a7 7 0 0 1 12-1l2 6M4 12l2 6a7 7 0 0 0 12-1',more:'M5 12h.01M12 12h.01M19 12h.01',chat:'M4 4h16v12H9l-5 4z',search:'M16 16l5 5M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0',edit:'m4 15 11-11 5 5L9 20H4zM13 6l5 5',trash:'M3 6h18M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7M14 10v7',note:'M5 3h14v18H5zM3 7h4M3 12h4M3 17h4M10 8h5M10 12h5',clear:'m3 14 10-11 8 8-10 10H8zM8 9l8 8M11 21h10',history:'M3 4v6h6M3 10a9 9 0 1 1 1 8M12 7v6l4 2',font:'M4 20 12 3l8 17M7 14h10',close:'m6 6 12 12M6 18 18 6',export:'M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5',play:'m8 4 12 8-12 8z',up:'m6 14 6-6 6 6',down:'m6 10 6 6 6-6',check:'m4 12 5 5L20 6'};
    if(name==='more')return '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="5" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.4" fill="currentColor" stroke="none"/></svg>';
    return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="'+paths[name]+'"/></svg>';
  }
  button(label,icon,fn,cls='') {const b=this.node('button',cls);b.type='button';b.title=label;b.setAttribute('aria-label',label);if(icon)b.innerHTML=this.icon(icon);if(!icon||cls.includes('labelled'))b.append(this.node('span','',label));b.onclick=()=>Promise.resolve().then(fn).catch(e=>this.error(e));return b;}
  error(e) {this.ai.notice(e.message,true);if(this.dialog?.open){this.managerStatus.textContent=e.message;this.managerStatus.dataset.error='true';}}
  key(file) {return String(file||'').replace(/\\/g,'/').toLowerCase();}
  title() {return this.record?.title||'新对话';}
  storage() {
    const path=reqnode('path'),root=this.ai.toolbar.knowledgeLibrary.rootPath,directory=path.join(root,'sessions');this.stores ||= new Map();
    const key=this.key(path.resolve(directory));if(!this.stores.has(key))this.stores.set(key,new ETAISessionStore(reqnode,directory,{legacy:this.legacyStore}));return this.stores.get(key);
  }
  recordStore(record) {return this.owners?.get(record)||(record?.id===this.record?.id?this.store:this.browseStore||this.store);}
  mount() {
    this.legacyStore=new ETAIConversationStore(reqnode,reqnode('path').join(File.option.userDataPath,'editing-toolbar-ai-conversations'));this.owners=new WeakMap();this.store=this.storage();
    this.library=new EditingToolbarAIAnswerLibrary(this);this.library.load().catch(e=>this.error(e));
    const a=this.ai;this.more=this.button('对话菜单','more',()=>this.toggleMenu());this.more.setAttribute('aria-haspopup','menu');this.more.setAttribute('aria-expanded','false');a.panel.querySelector('[data-ai="settings"]').before(this.more);
    this.searchBar=this.node('div','et-ai-chat-search');this.searchBar.hidden=true;this.searchInput=this.node('input');this.searchInput.type='search';this.searchInput.placeholder='搜索当前对话';this.searchInput.setAttribute('aria-label','搜索当前对话');this.searchCount=this.node('small');this.searchCount.setAttribute('aria-live','polite');this.searchBar.append(this.searchInput,this.searchCount,this.button('上一个结果','up',()=>this.search(-1)),this.button('下一个结果','down',()=>this.search(1)),this.button('关闭对话搜索','close',()=>this.closeSearch()));a.messages.before(this.searchBar);
    this.searchInput.oninput=()=>this.search();this.searchInput.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();this.search(e.shiftKey?-1:1);}if(e.key==='Escape'){e.preventDefault();this.closeSearch();}};
    this.popup=this.node('div','et-ai-session-popup');this.popup.setAttribute('popover','manual');a.panel.append(this.popup);
    this.historyButton=this.button('历史提问','history',()=>this.openHistory());this.historyButton.className='et-ai-history-trigger';a.composerUI.bar.append(this.historyButton);
    this.historyButton.setAttribute('aria-haspopup','dialog');this.historyButton.setAttribute('aria-expanded','false');
    this.historyButton.hidden=a.config.showHistory===false;
    a.prompt.addEventListener('input',()=>this.schedule());
    document.addEventListener('pointerdown',e=>{if(this.popup.matches(':popover-open')&&!this.popup.contains(e.target)&&!this.more.contains(e.target)&&!this.historyButton.contains(e.target))this.closePopup();});
    this.popup.onkeydown=e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();this.closePopup(true);}if(this.popup.dataset.kind==='menu'&&['ArrowDown','ArrowUp','Home','End'].includes(e.key)){e.preventDefault();const b=[...this.popup.querySelectorAll('button:not(:disabled)')],i=b.indexOf(document.activeElement);b[e.key==='Home'?0:e.key==='End'?b.length-1:(i+(e.key==='ArrowUp'?-1:1)+b.length)%b.length]?.focus();}};
    window.addEventListener('resize',()=>this.closePopup());window.addEventListener('blur',()=>this.closePopup());
    this.applyFont();
  }
  questionFooter(turn) {
    const footer=this.node('div','et-ai-question-footer'),time=this.node('time','et-ai-question-time'),stamp=EditingToolbarAITiming.questionTime(turn.time);
    if(stamp){time.dateTime=stamp.dateTime;time.textContent=stamp.label;time.title='提问时间：'+stamp.full;time.setAttribute('aria-label',time.title);}else time.hidden=true;
    let timer;const reset=()=>{clearTimeout(timer);button.innerHTML=this.icon('copy');button.title='复制提问';button.setAttribute('aria-label','复制提问');delete button.dataset.copied;};
    const button=this.button('复制提问','copy',()=>{
      reset();reqnode('electron').clipboard.writeText(turn.displayQuestion??turn.question??'');
      button.innerHTML=this.icon('check');button.title='已复制提问';button.setAttribute('aria-label','已复制提问');button.dataset.copied='true';timer=setTimeout(reset,2000);
    },'et-ai-question-copy');
    footer.append(time,button);return footer;
  }
  refreshQuestionTimes() {
    const now=new Date(),day=now.toDateString()+' '+now.getTimezoneOffset();if(day===this.questionDay)return;this.questionDay=day;
    for(const root of [this.ai.panel,this.dialog,this.ai.selectionUI?.temporary?.dialog])for(const node of root?.querySelectorAll('.et-ai-question-time[datetime]')||[]){
      const stamp=EditingToolbarAITiming.questionTime(node.dateTime,now);if(!stamp)continue;
      node.textContent=stamp.label;node.title='提问时间：'+stamp.full;node.setAttribute('aria-label',node.title);
    }
  }
  snapshot() {
    const a=this.ai,c=a.context||{},r=a.attachments.frozen,images=r?.images||(r?.image?[r.image]:[]);
    const attachments=a.attachments.selected.map(f=>{const data=a.attachments.frozenFiles?.get(f.id);return {...f,text:data?.kind==='text'?data.text:undefined,imageIndex:data?.kind==='image'?images.findIndex(i=>i.data===data.data):-1};});
    return {attachments,context:{file:c.file,markdown:c.markdown||'',selected:c.selected||'',label:c.label||'',sections:c.sections||[],sectionId:c.sectionId,sectionIds:c.sectionIds,notes:c.notes||[],noteId:c.noteId},scope:a.scope.value,reference:r?{text:r.text||'',label:r.label||'',name:r.name||'',detail:r.detail||'',images:images.map(i=>({data:i.data,name:i.name,width:i.width,height:i.height}))}:null};
  }
  data() {
    const a=this.ai,first=a.turns[0],now=new Date().toISOString();
    return {...(this.record||{id:this.store.id(),created:now,title:(first?.displayQuestion||first?.question||'新对话').replace(/\s+/g,' ').slice(0,60)}),file:a.context?.file||a.file(),draft:a.composerUI.draft.text(),draftComposer:a.composerUI.snapshot(),draftCodeFiles:a.codeUI?.snapshot()||[],contextState:a.contextUI?.snapshot()||null,
      turns:a.turns.map(t=>Object.fromEntries(['id','webChat','question','displayQuestion','command','answer','reasoning','reasoningKind','status','model','reference','requestContext','editMode','time','elapsedMs','detail','applied','execution'].map(k=>[k,k==='elapsedMs'?EditingToolbarAITiming.elapsed(t):k==='execution'?ETAIExecution.snapshot(t.execution):t[k]])))};
  }
  schedule() {if(!this.saveTimer)this.saveTimer=setTimeout(()=>this.flush(),700);}
  flush(forceDraft=false) {
    clearTimeout(this.saveTimer);this.saveTimer=null;if(!this.ai.panel||(!forceDraft&&!this.record&&!this.ai.turns.length))return true;
    if(!this.record)this.store=this.storage();
    try{const input=this.data();if(this.record&&!this.saveError&&this.snapshotSaved&&input.title===this.record.title&&input.file===this.record.file&&input.draft===this.record.draft&&JSON.stringify(input.draftComposer)===JSON.stringify(this.record.draftComposer)&&JSON.stringify(input.draftCodeFiles||[])===JSON.stringify(this.record.draftCodeFiles||[])&&JSON.stringify(input.contextState||null)===JSON.stringify(this.record.contextState||null)&&JSON.stringify(input.turns)===JSON.stringify(this.record.turns))return true;let saved;
      try{saved=this.store.write(input,this.record?.revision,this.snapshotSaved?undefined:this.snapshot());}
      catch(e){if(e.code!=='CHAT_CONFLICT')throw e;input.id=this.store.id();input.title+=' · 恢复副本';delete input.revision;saved=this.store.write(input,null,this.snapshot());this.ai.toolbar._showToolbarNotice('另一个窗口已修改原会话，本窗口内容已保存为恢复副本');}
      this.record=saved;this.snapshotSaved=!!saved.contextFile;this.saveError=false;return true;
    }catch(e){this.saveError=true;this.error(Error('会话未保存：'+e.message));return false;}
  }
  beforeNew() {if(!this.flush())return false;this.record=null;this.store=this.storage();this.library.load().catch(e=>this.error(e));this.snapshotSaved=false;this.closeSearch();this.closePopup();return true;}
  showPopup(kind,anchor) {
    this.closePopup();this.ai.composerUI.closeMenu();this.popup.replaceChildren();this.popup.dataset.kind=kind;this.popup.setAttribute('role',kind==='menu'?'menu':'dialog');this.popup.setAttribute('aria-label',kind==='menu'?'对话菜单':'历史提问');this.anchor=anchor;this.popup.showPopover();this.more.setAttribute('aria-expanded',String(kind==='menu'));this.historyButton.setAttribute('aria-expanded',String(kind==='history'));this.positionPopup();
  }
  positionPopup() {
    const r=this.anchor.getBoundingClientRect(),history=this.popup.dataset.kind==='history',above=history&&(r.top>=200||r.top>innerHeight-r.bottom);
    const width=history?Math.min(380,this.ai.panel.getBoundingClientRect().width-24):252,space=history?(above?r.top-18:innerHeight-r.bottom-18):innerHeight-24;
    this.popup.style.width=Math.min(width,innerWidth-20)+'px';this.popup.style.maxHeight=Math.max(100,space)+'px';
    const h=this.popup.getBoundingClientRect().height,w=this.popup.getBoundingClientRect().width;this.popup.style.left=Math.max(10,Math.min(r.right-w,innerWidth-w-10))+'px';this.popup.style.top=Math.max(10,Math.min(above?r.top-h-8:r.bottom+8,innerHeight-h-10))+'px';
  }
  closePopup(focus=false) {if(this.popup?.matches(':popover-open'))this.popup.hidePopover();this.more?.setAttribute('aria-expanded','false');this.historyButton?.setAttribute('aria-expanded','false');if(focus)this.anchor?.focus();this.serial++;}
  toggleMenu() {
    if(this.popup.matches(':popover-open')&&this.popup.dataset.kind==='menu'){this.closePopup();return;}
    this.showPopup('menu',this.more);const a=this.ai,p=this.popup;
    const section=text=>p.append(this.node('small','et-ai-menu-section',text));
    const row=(label,icon,fn,disabled=false)=>{const b=this.button(label,icon,()=>{this.closePopup();return fn();},'et-ai-session-row labelled');b.setAttribute('role','menuitem');b.disabled=disabled;p.append(b);return b;};
    section('对话');row('管理侧边栏对话…','chat',()=>this.openManager());row('收藏的回答','star',()=>this.openManager('favorites'));row('搜索当前对话','search',()=>this.openSearch());row('修改名称','edit',()=>this.rename(this.record),!this.record||a.busy);row('删除对话','trash',()=>this.deleteRecord(this.record),!this.record||a.busy);
    section('保存');row('保存会话到笔记','note',()=>this.saveNote(),!a.turns.length||a.busy);row('清空对话','clear',()=>this.clear(),!a.turns.length||a.busy);
    section('显示');const history=row('历史提问','history',()=>{a.config.showHistory=a.config.showHistory===false;a.persist();this.historyButton.hidden=a.config.showHistory===false;if(a.config.showHistory)this.openHistory();});history.setAttribute('role','menuitemcheckbox');history.setAttribute('aria-checked',String(a.config.showHistory!==false));if(a.config.showHistory!==false)history.insertAdjacentHTML('beforeend',this.icon('check'));
    const font=this.node('div','et-ai-font-controls');font.innerHTML=this.icon('font');font.append(this.node('span','','字体大小'));
    const stepper=this.node('div','et-ai-font-stepper');stepper.setAttribute('role','group');stepper.setAttribute('aria-label','调节对话字号');
    const output=this.node('output');output.setAttribute('aria-live','polite');
    const update=()=>{const size=Math.min(24,Math.max(10,Number(a.config.chatFontSize)||13));output.textContent=String(size);stepper.children[0].disabled=size===10;stepper.children[2].disabled=size===24;stepper.children[1].title='当前 '+size+' px · 点击恢复默认 13 px';};
    for(const [label,text,delta] of [['减小字号','−',-1],['重置字号','',0],['增大字号','+',1]]){const b=this.button(label,null,()=>{a.config.chatFontSize=delta?Math.min(24,Math.max(10,(Number(a.config.chatFontSize)||13)+delta)):13;a.persist();this.applyFont();update();});if(delta)b.textContent=text;else{b.classList.add('et-ai-font-reset');b.replaceChildren(output);}stepper.append(b);}
    update();font.append(stepper);p.append(font);this.positionPopup();p.querySelector('button').focus();
  }
  applyFont() {const size=Math.min(24,Math.max(10,Number(this.ai.config.chatFontSize)||13));this.ai.panel?.style.setProperty('--ai-chat-font',size+'px');this.dialog?.style.setProperty('--ai-chat-font',size+'px');}
  openSearch() {this.searchBar.hidden=false;this.searchInput.focus();this.search();}
  closeSearch() {if(!this.searchBar)return;this.searchBar.hidden=true;this.searchInput.value='';for(const t of this.ai.turns)t.article?.classList.remove('et-ai-search-hit');}
  search(step=0) {
    const query=this.searchInput.value.trim().toLocaleLowerCase(),matches=this.ai.turns.filter(t=>query&&((t.displayQuestion||t.question)+'\n'+t.answer).toLocaleLowerCase().includes(query));
    this.matchAt=step?(this.matchAt+step+matches.length)%matches.length:0;this.searchCount.textContent=query?(matches.length?(this.matchAt+1)+' / '+matches.length+' 条':'无结果'):'';
    for(const t of this.ai.turns)t.article.classList.toggle('et-ai-search-hit',t===matches[this.matchAt]);
    const hit=matches[this.matchAt];if(hit)this.ai.navigation?.reveal(hit);
  }
  jumpToTurn(turn) {this.closePopup();return this.ai.navigation?.reveal(turn);}
  async openHistory() {
    if(this.popup.matches(':popover-open')&&this.popup.dataset.kind==='history'){this.closePopup();return;}
    this.showPopup('history',this.historyButton);const p=this.popup;
    const top=this.node('div','et-ai-history-heading'),heading=this.node('div'),count=this.node('small','et-ai-history-count');count.setAttribute('aria-live','polite');heading.append(this.node('strong','','历史提问'),count);top.append(heading,this.button('关闭历史提问','close',()=>this.closePopup(true)));p.append(top);
    const tools=this.node('div','et-ai-history-tools'),input=this.node('input');tools.innerHTML=this.icon('search');input.type='search';input.placeholder='搜索提问';input.setAttribute('aria-label','搜索当前对话的提问');tools.append(input);p.append(tools);
    const list=this.node('div','et-ai-history-list');list.setAttribute('role','list');list.setAttribute('aria-label','当前对话的提问');p.append(list);
    const history=[...this.ai.turns].reverse(),current=this.ai.navigation?.current();
    const render=()=>{list.replaceChildren();const q=input.value.trim().toLowerCase(),rows=history.filter(t=>((t.displayQuestion||'')+t.question).toLowerCase().includes(q));count.textContent=q?rows.length+' / '+history.length:history.length+' 条';
      for(const t of rows){
        const title=t.displayQuestion||t.question,b=this.button('跳转到：'+title,null,()=>this.jumpToTurn(t),'et-ai-history-item'),row=this.node('div');row.setAttribute('role','listitem');
        const body=this.node('span','et-ai-history-copy'),label=this.node('span','et-ai-history-title',title),meta=this.node('small','',this.date(t.time));
        if(t===current){b.setAttribute('aria-current','true');meta.append(this.node('span','et-ai-history-current','正在查看'));}
        body.append(label,meta);b.innerHTML=this.icon('chat');b.append(body);const arrow=this.node('span','et-ai-history-jump');arrow.innerHTML=this.icon('down');arrow.setAttribute('aria-hidden','true');b.append(arrow);row.append(b);list.append(row);
      }
      if(!rows.length&&q)list.append(this.node('p','et-ai-dialog-empty','没有匹配的提问'));list.hidden=!list.childElementCount;list.scrollTop=0;this.positionPopup();};
    input.oninput=render;input.onkeydown=e=>{if(['ArrowDown','ArrowUp'].includes(e.key)){e.preventDefault();const buttons=list.querySelectorAll('button');(e.key==='ArrowDown'?buttons[0]:buttons[buttons.length-1])?.focus();}else if(e.key==='Enter'){e.preventDefault();list.querySelector('button')?.click();}};
    list.onkeydown=e=>{if(!['ArrowDown','ArrowUp','Home','End'].includes(e.key))return;e.preventDefault();const buttons=[...list.querySelectorAll('button')],i=buttons.indexOf(document.activeElement),at=e.key==='Home'?0:e.key==='End'?buttons.length-1:Math.min(buttons.length-1,Math.max(0,i+(e.key==='ArrowUp'?-1:1)));buttons[at]?.focus();};
    render();input.focus({preventScroll:true});
  }
  fileName(file) {return !file||file.startsWith('untitled:')?'未命名文档':reqnode('path').basename(file);}
  date(time) {return time?new Date(time).toLocaleString('zh-CN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}):'';}
  async ask(title,description,initial,options={}) {
    if(this.confirm?.open)return null;
    const previous=document.activeElement,d=this.node('dialog','et-ai-chat-confirm et-ai-confirm-dialog');d.tabIndex=-1;d.dataset.danger=String(!!options.danger);d.setAttribute('aria-label',title);
    const head=this.node('div','et-ai-confirm-heading'),badge=this.node('span','et-ai-confirm-icon');badge.innerHTML=this.icon(options.danger?'trash':'edit');badge.setAttribute('aria-hidden','true');
    const close=this.button('关闭', 'close',()=>finish(null),'et-ai-confirm-close');head.append(badge,this.node('h3','',title),close);d.append(head);
    if(options.subjects?.length){
      d.dataset.batch='true';const subject=this.node('div','et-ai-confirm-subject'),list=this.node('ul','et-ai-confirm-subject-list');subject.append(this.node('small','','已选 '+options.subjects.length+' 个对话'));
      for(const title of options.subjects){const row=this.node('li','',title);row.title=title;list.append(row);}subject.append(list);d.append(subject);
    }else if(options.subject){const subject=this.node('div','et-ai-confirm-subject');subject.append(this.node('small','','对话'),this.node('strong','',options.subject));subject.title=options.subject;d.append(subject);}
    const copy=this.node('div','et-ai-confirm-copy');copy.id='et-ai-confirm-description';copy.append(this.node('p','',description));if(options.note)copy.append(this.node('p','et-ai-confirm-note',options.note));d.append(copy);d.setAttribute('aria-describedby',copy.id);
    let input;if(initial!==undefined){input=this.node('input');input.value=initial;input.maxLength=100;input.setAttribute('aria-label','对话名称');d.append(input);}
    const actions=this.node('div','et-ai-dialog-actions');d.append(actions);document.body.append(d);this.ai.bindSurface(d);this.confirm=d;
    let finish;return new Promise(resolve=>{
      let finished=false;finish=value=>{if(finished)return;finished=true;d.close();d.remove();if(this.confirm===d)this.confirm=null;if(previous?.isConnected)previous.focus({preventScroll:true});resolve(value);};
      const accept=()=>{if(input&&!input.value.trim())return input.focus();finish(input?input.value.trim():true);};
      actions.append(this.button('取消',null,()=>finish(null)),this.button(options.confirmLabel||(input?'保存':'确认'),null,accept,options.danger?'et-ai-danger':'et-ai-primary'));
      d.addEventListener('cancel',e=>{e.preventDefault();finish(null);});d.addEventListener('close',()=>finish(null));
      // Native button activation respects focus: Enter on Cancel must not delete.
      d.onkeydown=e=>{if(e.target===input&&e.key==='Enter'&&!e.isComposing&&e.keyCode!==229){e.preventDefault();accept();}};
      d.showModal();if(input){input.focus();input.select();}else d.focus({preventScroll:true});
    });
  }
  async rename(record) {
    if(!record||this.ai.busy)return;const title=await this.ask('修改名称','为这次阅读对话起一个便于查找的名称。',record.title);if(!title)return;
    const store=this.recordStore(record);if(this.record?.id===record.id&&store===this.store){if(!this.flush())return;this.record=store.write({...this.record,title},this.record.revision);}else store.write({...record,title},record.revision);
    if(this.dialog?.open)await this.loadManager(record.id);
  }
  async deleteRecord(record) {return this.deleteRecords(record?[record]:[]);}
  async deleteRecords(records) {
    if(this.ai.busy||this.managerDeleting)return;
    // Freeze the confirmed records and their stores, not a later selection or filter.
    const seen=new Map(),targets=[];
    for(const record of records){if(!record||record.kind==='favorite'||record.deleted)continue;const store=this.recordStore(record);if(!seen.has(store))seen.set(store,new Set());if(seen.get(store).has(record.id))continue;seen.get(store).add(record.id);targets.push({record,store});}
    if(!targets.length)return;this.managerDeleting=true;
    try{
      const count=targets.length,multiple=count>1;
      const accepted=await this.ask(multiple?'删除这 '+count+' 个对话？':'删除这次对话？','对话内容和资料快照将被永久删除。',undefined,{danger:true,confirmLabel:multiple?'删除 '+count+' 个对话':'删除对话',...(multiple?{subjects:targets.map(t=>t.record.title)}:{subject:targets[0].record.title}),note:'已保存的笔记和收藏会保留。'});
      if(!accepted||this.ai.busy)return;
      if(File.isFileLoading?.()){this.error(Error('文档正在加载，请稍后重试删除'));return;}
      if(targets.some(t=>this.record?.id===t.record.id&&this.store===t.store)&&!this.flush())return;
      const failed=[],removed=[];
      for(const target of targets){
        const current=this.record?.id===target.record.id&&this.store===target.store,record=current?this.record:target.record;
        try{target.store.remove(record);removed.push(record.id);if(current){this.record=null;this.snapshotSaved=false;this.ai.newConversation(true);this.store=this.storage();}}
        catch(error){failed.push({...target,error});}
      }
      if(this.dialog?.open){
        await this.loadManager(failed[0]?.record.id);
        if(failed.length){const ids=new Set(failed.map(t=>t.record.id));this.selection=new Set(this.visible.filter(r=>ids.has(r.id)).map(r=>r.id));this.selected=[...this.selection][0]||null;this.focusId=this.selected;this.selectionAnchor=this.selected;this.syncManagerSelection();}
        this.managerStatus.textContent=(removed.length?'已删除 '+removed.length+' 个对话':'未删除对话')+(failed.length?'；'+failed.length+' 个未删除：'+failed.map(t=>t.record.title+'（'+t.error.message+'）').join('；'):'');this.managerStatus.dataset.error=String(!!failed.length);
        (this.list.querySelector('[tabindex="0"]')||this.managerSearch).focus({preventScroll:true});
      }else if(failed.length)this.error(Error(failed.map(t=>t.record.title+'：'+t.error.message).join('；')));
      return {removed,failed};
    }finally{this.managerDeleting=false;if(this.dialog?.open)for(const b of this.previewActions.querySelectorAll('button'))b.disabled=!!this.ai.busy;}
  }
  async clear() {
    if(this.ai.busy||!this.ai.turns.length)return;if(!await this.ask('清空这次对话？','将删除全部问答，保留对话名称。',undefined,{danger:true,confirmLabel:'清空对话',subject:this.record?.title,note:'已保存的笔记和收藏会保留。'}))return;
    if(!this.flush())return;const context=this.ai.context,saved=this.store.write({...this.record,turns:[],contextState:null,draft:'',draftComposer:null},this.record.revision,null);this.record=null;this.ai.newConversation(true);this.ai.context={...context,range:null};this.record=saved;this.snapshotSaved=false;this.ai.updateContext();this.ai.checkDocument();
  }
  transcript(record) {
    return '# '+record.title+'\n\n> 文档：'+this.fileName(record.file)+'\n\n'+record.turns.map((t,i)=>'## '+(i+1)+'. 提问\n\n'+(t.displayQuestion||t.question)+'\n\n### 回答\n\n'+t.answer+(t.status==='done'?'':'\n\n> 回答未完整生成。')+'\n\n> 模型：'+t.model+' · '+this.date(t.time)+(EditingToolbarAITiming.elapsed(t)!==undefined?' · '+EditingToolbarAITiming.label({...t,status:t.status==='running'?'stopped':t.status}):'')).join('\n\n---\n\n');
  }
  async saveNote() {
    const a=this.ai;if(a.busy||!a.turns.length)return;if(a.context.file!==a.file()||File.isFileLoading?.())throw Error('请回到这次会话对应的文档后再保存笔记');if(!this.flush())return;
    const m=a.toolbar.documentNotes;m._switchDocument();if(!m.ctx||m.ctx.readonly)throw Error('当前文档的笔记暂时无法写入');m._flushEditor();if(!m._save())throw Error('原笔记尚未保存，请先处理笔记保存提示');
    const n=m._blankNote('AI · '+this.title());n.markdown=ETAIClient.insertableMarkdown(this.transcript(this.record));m.ctx.notes.push(n);m.ctx.virgin=false;const ui=m._ui();ui.opened.push(n.id);ui.active=n.id;m.ctx.selected=n.id;m._touch();if(!m._save())throw Error('会话笔记保留为草稿，请检查笔记保存提示');m._saveUI();m.open();m._renderList();m._showSelected();m.tabs.reveal(n.id);a.toolbar._showToolbarNotice('完整会话已保存为当前文档的新笔记');
  }
  mountManager() {
    const d=this.node('dialog','et-ai-conversation-manager');d.setAttribute('aria-label','侧边栏对话');this.dialog=d;
    const head=this.node('div','et-ai-manager-header'),heading=this.node('div');heading.append(this.node('h2','','侧边栏对话'));this.total=this.node('small');heading.append(this.total);this.managerSearch=this.node('input');this.managerSearch.type='search';this.managerSearch.placeholder='搜索文档、对话或消息…';this.managerSearch.setAttribute('aria-label','搜索文档、对话或消息');head.append(heading,this.managerSearch,this.button('关闭对话管理','close',()=>d.close()));d.append(head);
    const body=this.node('div','et-ai-manager-body'),aside=this.node('aside','et-ai-manager-aside'),tabs=this.node('div','et-ai-manager-tabs');tabs.setAttribute('role','tablist');this.filter='current';
    for(const [value,label] of [['current','当前文档'],['all','全部文档'],['favorites','收藏']]){const b=this.button(label,null,()=>{this.filter=value;this.renderManager();});b.dataset.filter=value;b.setAttribute('role','tab');tabs.append(b);}this.tabs=tabs;this.list=this.node('div','et-ai-conversation-list');this.list.setAttribute('aria-label','会话列表');this.list.setAttribute('role','listbox');this.list.tabIndex=-1;this.list.onkeydown=e=>this.managerSelectionKey(e);this.list.addEventListener('mousedown',e=>{if(e.shiftKey)e.preventDefault();});
    this.selectionInfo=this.node('div','et-ai-manager-selection-info');this.selectionInfo.setAttribute('aria-live','polite');aside.append(tabs,this.selectionInfo,this.list);
    const main=this.node('section','et-ai-manager-main');this.previewHead=this.node('div','et-ai-preview-header');this.previewTitle=this.node('strong');this.previewActions=this.node('div','et-ai-preview-actions');this.previewHead.append(this.previewTitle,this.previewActions);this.preview=this.node('div','et-ai-conversation-preview');main.append(this.previewHead,this.preview);body.append(aside,main);d.append(body);this.managerStatus=this.node('footer','et-ai-manager-status');this.managerStatus.setAttribute('role','status');d.append(this.managerStatus);
    this.managerSearch.oninput=()=>{clearTimeout(this.filterTimer);this.filterTimer=setTimeout(()=>this.renderManager(),120);};d.addEventListener('close',()=>{this.managerLoad=(this.managerLoad||0)+1;this.more.focus();});this.ai.bindSurface(d);document.body.append(d);this.applyFont();this.managerMotion=new EditingToolbarAIConversationMotion(this,head);this.managerMotion.mount();
  }
  async openManager(filter='current') {this.closePopup();if(!this.flush())return;if(!this.dialog)this.mountManager();if(!this.dialog.open)this.dialog.showModal();this.managerMotion.layout();this.filter=filter;this.managerSearch.value='';await this.loadManager(this.record?.id);this.managerSearch.focus();}
  async loadManager(selected) {
    const token=this.managerLoad=(this.managerLoad||0)+1,store=this.storage();this.browseStore=store;this.managerStatus.textContent='正在读取会话…';this.managerStatus.dataset.error='false';const [{records,errors},favorites]=await Promise.all([store.list(),this.library.load()]);if(token!==this.managerLoad)return;for(const record of records)this.owners.set(record,store);this.records=records;this.selected=selected||null;this.selection=null;this.selectionView=null;this.total.textContent=records.length+' 个对话 · '+favorites.records.length+' 条收藏';this.managerStatus.textContent=(errors||favorites.errors)?'部分会话或收藏无法读取，原文件已保留。':'';this.renderManager();
  }
  renderManager() {
    const query=this.managerSearch.value.trim().toLocaleLowerCase();this.total.textContent=(this.records||[]).length+' 个对话 · '+this.library.items.size+' 条收藏';this.visible=(this.filter==='favorites'?[...this.library.items.values()].sort((a,b)=>String(b.updated).localeCompare(String(a.updated))):(this.records||[])).filter(r=>(this.filter!=='current'||this.key(r.file)===this.key(this.ai.file()))&&(!query||[r.title,r.file,...r.turns.flatMap(t=>[t.displayQuestion,t.question,t.answer])].join('\n').toLocaleLowerCase().includes(query)));
    for(const b of this.tabs.children)b.setAttribute('aria-selected',String(b.dataset.filter===this.filter));this.reconcileSelection(this.filter+'\0'+query);
    this.list.replaceChildren();for(const r of this.visible){const b=this.button(r.title,null,()=>{},'et-ai-conversation-item');b.dataset.id=r.id;b.setAttribute('role','option');b.onclick=e=>this.selectRecord(r.id,e);const meta=this.node('span','et-ai-conversation-meta');meta.append(this.node('span','',this.fileName(r.file)),this.node('small','',this.date(r.updated)));b.replaceChildren(this.node('strong','',r.title),meta);b.title=r.title+'\n'+r.file+'\n'+(r.kind==='favorite'?'已收藏':r.turns.length+' 轮对话')+' · '+this.date(r.updated);this.list.append(b);}if(!this.visible.length&&(query||this.filter==='favorites'))this.list.append(this.node('p','et-ai-dialog-empty',query?'没有找到匹配的内容':'暂无收藏，点击回答下方的星标即可保存'));
    this.syncManagerSelection();
  }
  selectedRecords() {return (this.visible||[]).filter(r=>this.selection?.has(r.id));}
  reconcileSelection(view) {
    if(!this.selection||this.selectionView!==view){
      const id=this.selectionView==null&&this.visible.some(r=>r.id===this.selected)?this.selected:this.visible[0]?.id;
      this.selection=new Set(id?[id]:[]);this.selected=this.focusId=this.selectionAnchor=id||null;
    }else{
      const ids=new Set(this.visible.map(r=>r.id));this.selection=new Set([...this.selection].filter(id=>ids.has(id)));
      if(!this.selection.has(this.selected))this.selected=[...this.selection][0]||null;
      if(!ids.has(this.focusId))this.focusId=this.selected||this.visible[0]?.id||null;
      if(!ids.has(this.selectionAnchor))this.selectionAnchor=this.focusId;
    }
    this.selectionView=view;
  }
  selectRecord(id,event={}) {
    if(this.managerDeleting||!this.visible.some(r=>r.id===id))return;
    const multi=this.filter!=='favorites',toggle=multi&&(event.ctrlKey||event.metaKey),range=multi&&event.shiftKey;
    if(range){
      const ids=this.visible.map(r=>r.id);let anchor=ids.indexOf(this.selectionAnchor);if(anchor<0){this.selectionAnchor=id;anchor=ids.indexOf(id);}const at=ids.indexOf(id),span=ids.slice(Math.min(anchor,at),Math.max(anchor,at)+1);
      this.selection=new Set([...(toggle?this.selection:[]),...span]);
    }else if(toggle){if(this.selection.has(id))this.selection.delete(id);else this.selection.add(id);this.selectionAnchor=id;}
    else{this.selection=new Set([id]);this.selectionAnchor=id;}
    this.focusId=id;this.selected=this.selection.has(id)?id:[...this.selection].at(-1)||null;this.syncManagerSelection();
    [...this.list.children].find(b=>b.dataset.id===id)?.focus({preventScroll:true});
  }
  syncManagerSelection() {
    const rows=this.selectedRecords(),multi=rows.length>1;this.list.setAttribute('aria-multiselectable',String(this.filter!=='favorites'));this.list.dataset.multiple=String(multi);
    for(const b of this.list.querySelectorAll('[data-id]')){b.setAttribute('aria-selected',String(this.selection.has(b.dataset.id)));b.tabIndex=b.dataset.id===this.focusId?0:-1;}
    this.selectionInfo.hidden=this.filter==='favorites'||!multi;this.selectionInfo.textContent=multi?'已选 '+rows.length+' 个对话':'';
    this.renderPreview();
  }
  managerSelectionKey(e) {
    const row=e.target.closest('[data-id]');if(!row||this.managerDeleting||e.isComposing)return;
    const ids=this.visible.map(r=>r.id),at=ids.indexOf(row.dataset.id),modified=e.ctrlKey||e.metaKey;
    if(modified&&e.key.toLowerCase()==='a'&&this.filter!=='favorites'){e.preventDefault();this.selection=new Set(ids);this.selected=this.focusId=row.dataset.id;this.selectionAnchor=row.dataset.id;this.syncManagerSelection();return;}
    if(e.key==='Delete'&&this.filter!=='favorites'){e.preventDefault();this.deleteRecords(this.selectedRecords()).catch(error=>this.error(error));return;}
    if(e.key===' '){e.preventDefault();this.selectRecord(row.dataset.id,{ctrlKey:this.filter!=='favorites',shiftKey:e.shiftKey});return;}
    if(!['ArrowDown','ArrowUp','Home','End'].includes(e.key))return;e.preventDefault();const next=ids[e.key==='Home'?0:e.key==='End'?ids.length-1:Math.max(0,Math.min(ids.length-1,at+(e.key==='ArrowDown'?1:-1)))];
    if(modified&&!e.shiftKey){this.focusId=next;this.syncManagerSelection();}else this.selectRecord(next,e);
    const button=[...this.list.children].find(b=>b.dataset.id===next);button?.focus({preventScroll:true});button?.scrollIntoView({block:'nearest'});
  }
  renderPreview() {
    const chosen=this.selectedRecords(),record=chosen.find(r=>r.id===this.selected)||chosen[0];this.previewTitle.textContent=record?.title||(this.filter==='favorites'?'收藏的回答':'未选择对话');this.previewActions.replaceChildren();this.preview.replaceChildren();
    if(chosen.length>1){
      this.previewTitle.textContent='已选择 '+chosen.length+' 个对话';
      const remove=this.button('删除所选对话','trash',()=>this.deleteRecords(this.selectedRecords()),'labelled et-ai-batch-delete');remove.disabled=!!this.ai.busy||!!this.managerDeleting;
      this.previewActions.append(remove,this.button('取消多选','close',()=>this.selectRecord(this.selected||chosen[0].id)));
      const list=this.node('div','et-ai-batch-preview');for(const r of chosen){const row=this.node('div','et-ai-batch-preview-row');row.append(this.node('strong','',r.title),this.node('small','',this.fileName(r.file)));list.append(row);}this.preview.append(list);return;
    }
    if(!record){if(this.filter==='favorites')this.preview.append(this.node('div','et-ai-dialog-empty','将值得保留的回答收集在这里。'));return;}
    const same=this.key(record.file)===this.key(this.ai.file());for(const [label,icon,fn,cls] of (record.kind==='favorite'?[['导出收藏','export',()=>this.export(record),''],['移出收藏','trash',()=>this.library.toggle(record.turns[0],record),'']]:[[same?'继续对话':'打开文档并继续','play',()=>this.resume(record),'labelled et-ai-primary'],['修改名称','edit',()=>this.rename(record),''],['导出会话','export',()=>this.export(record),''],['删除对话','trash',()=>this.deleteRecord(record),'']])){const b=this.button(label,icon,fn,cls);b.disabled=!!this.ai.busy||!!this.managerDeleting;this.previewActions.append(b);}
    const serial=this.previewSerial=(this.previewSerial||0)+1;if(!record.turns.length)this.preview.append(this.node('p','et-ai-dialog-empty','这次对话已清空，可以继续提问。'));
    let reference;try{if(record.kind!=='favorite')reference=this.recordStore(record).context(record)?.reference;}catch{this.managerStatus.textContent='阅读资料快照无法读取，仍可查看已保存的提问与回答。';}
    for(const t of record.turns){const article=this.node('article','et-ai-preview-turn'),question=this.node('div','et-ai-question',t.displayQuestion||t.question),meta=this.node('small','et-ai-answer-meta',t.model+' · '+this.date(t.time)+(EditingToolbarAITiming.elapsed(t)!==undefined?' · '+EditingToolbarAITiming.label({...t,status:t.status==='running'?'stopped':t.status}):'')),answer=this.node('div','et-ai-answer');EditingToolbarAIQuotes.renderSent(this.ai,article,t);this.ai.composerUI.draft.media.renderSent(article,t,record.turns[0]===t?reference:null);ETRichComposer.renderMessage(question,t.displayQuestion||t.question,url=>this.ai.openComposerLink(url));article.append(question,this.questionFooter(t),meta,answer);this.preview.append(article);new EditingToolbarAIExecution(this.ai,{...t,status:t.status==='running'?'stopped':t.status},answer).update();new EditingToolbarAIReasoning(this.ai,t,answer).update();const m=this.ai.toolbar.annotations;try{m._ensureRenderer().renderPreview(answer,t.answer||'（未返回回答）',{...this.ai.referencesUI.options(t,record.turns,record.file),minHeadingLevel:t.webChat?2:1,isCurrent:()=>this.previewSerial===serial&&answer.isConnected,renderMath:(tex,display)=>m._renderMath(tex,display),openLink:url=>{if(/^https?:\/\//i.test(url))reqnode('electron').shell.openExternal(url);}});}catch{answer.textContent=t.answer;}const resultAnchor=this.node('span');resultAnchor.hidden=true;article.append(resultAnchor);this.ai.webUI?.render({...t,actions:resultAnchor});}
    this.preview.scrollTop=0;
  }
  async resume(record) {
    if(this.ai.busy)return;if(!this.flush())return;
    // Re-read before resume, so a stale manager cannot resurrect a deleted session.
    const store=this.recordStore(record);record=store.read(record.id);this.owners.set(record,store);if(record.deleted)throw Error('这次对话已被删除，请重新打开会话管理');const snapshot=store.context(record);
    if(this.key(record.file)!==this.key(this.ai.file())){
      if(!record.file||record.file.startsWith('untitled:'))throw Error('未命名文档无法重新打开，请先打开对应文档');if(!reqnode('fs').existsSync(record.file))throw Error('原 Markdown 文件已移动或删除，请先找回文件');
      this.managerStatus.textContent='正在打开文档；如有未保存修改，请在 Typora 提示中处理。';
      File.editor.library.openFile(record.file,()=>setTimeout(()=>{if(this.key(record.file)===this.key(this.ai.file()))this.restore(record,snapshot);},0));return;
    }
    this.restore(record,snapshot);
  }
  restore(record,snapshot) {
    const a=this.ai;if(a.busy||File.isFileLoading?.()||this.key(record.file)!==this.key(a.file()))return;
    a.newConversation(true);this.closeSearch();this.closePopup();this.store=this.recordStore(record);this.record=record;this.snapshotSaved=!!snapshot;
    if(snapshot){a.context={...snapshot.context,file:a.file(),range:null};a.scope.value=snapshot.scope||'none';if(snapshot.reference){const files=snapshot.attachments?.length?snapshot.attachments:(snapshot.reference.images||[]).map((img,i)=>({id:'saved-image-'+i,name:img.name||'图片 '+(i+1),location:'已保存资料',path:'',kind:'image',imageIndex:i}));a.attachments.selected=files.map(({text,imageIndex,...f})=>f);a.attachments.freeze({...snapshot.reference,loaded:new Map(files.map(f=>[f.id,{...f,...(f.kind==='image'?snapshot.reference.images[f.imageIndex]:{text:f.text})}]))});}}
    a.turns=JSON.parse(JSON.stringify(record.turns)).map(t=>({...t,file:a.file(),source:snapshot?.context.markdown,selected:'',range:null,status:t.status==='running'?'stopped':t.status,detail:t.status==='running'?'上次生成被中断，可重试':t.detail}));
    if(a.turns.some(t=>t.webChat)&&a.webChat){a.config.active=a.webChat.profile.id;a.rememberModel(a.webChat.profile);a.editUI.enabled=false;const last=[...a.turns].reverse().find(t=>t.webChat)?.webChat,target=last?.projectTarget;a.webChat.projects?.save(target?{...target,...(last.url?{chat:{url:last.url,name:target.chat?.name||'当前聊天'}}:{})}:{enabled:false});}
    a.contextUI?.restore(record.contextState);
    a.codeUI?.restore(record.draftCodeFiles);for(const t of a.turns)a.mountTurn(t);a.composerUI.restore(record.draftComposer,record.draft||'');a.promptsManager.renderContextTools();a.updateContext();a.composerUI.sync();a.checkDocument();this.dialog?.close();a.prompt.focus();a.webChat?.resumePending?.();
  }
  async export(record) {
    const options=await this.exportOptions(record);if(!options)return;
    const snapshot=options.context?this.recordStore(record).context(record):null,text=ETAIPortableConversation.serialize(record,options.format,snapshot);
    const result=await JSBridge.invoke('dialog.showSaveDialog',{title:'导出 AI 对话',defaultPath:record.title.replace(/[<>:"/\\|?*]/g,'_').slice(0,60)+'.'+options.format,filters:[{name:options.format==='md'?'Markdown':options.format.toUpperCase(),extensions:[options.format]}]});const file=typeof result==='string'?result:result?.filePath;if(!file||result?.canceled)return;await reqnode('fs').promises.writeFile(file,text,'utf8');this.managerStatus.textContent='已导出：'+file;
  }
  async exportOptions(record) {
    const d=this.node('dialog','et-ai-chat-confirm et-ai-export-dialog');d.setAttribute('aria-label','导出格式');d.append(this.node('h3','','导出对话'),this.node('p','','Markdown 适合阅读或交给其他模型；JSON / JSONL 保留提问与回答的角色，方便其他工具处理。'));
    const label=this.node('label','et-ai-export-format','文件格式'),select=this.node('select');select.setAttribute('aria-label','文件格式');for(const [value,text] of [['md','Markdown (.md)'],['json','JSON (.json)'],['jsonl','JSON Lines (.jsonl)']])select.append(new Option(text,value));label.append(select);d.append(label);
    const contextLabel=this.node('label','et-ai-export-context'),check=this.node('input');check.type='checkbox';check.disabled=!record.contextFile||record.kind==='favorite';contextLabel.append(check,this.node('span','','附带阅读资料文字'));d.append(contextLabel,this.node('small','et-ai-export-hint','图片原件需另行提供。'));
    const actions=this.node('div','et-ai-dialog-actions');d.append(actions);document.body.append(d);this.ai.bindSurface(d);this.confirm=d;
    return new Promise(resolve=>{const finish=value=>{d.close();d.remove();this.confirm=null;resolve(value);};actions.append(this.button('取消',null,()=>finish(null)),this.button('选择保存位置',null,()=>finish({format:select.value,context:check.checked}),'et-ai-primary'));d.addEventListener('cancel',e=>{e.preventDefault();finish(null);});d.showModal();select.focus();});
  }
}
