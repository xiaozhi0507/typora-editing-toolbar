// Factory color seeds from installed Codex 26.924.2738.0. All 29 families; no font settings.
const ET_CODEX_THEME_PRESETS = {
  "chatgpt": {
    "name": "ChatGPT",
    "group": "chatgpt",
    "variants": {
      "light": {
        "surface": "#fcfcfc",
        "ink": "#0d0d0d",
        "accent": "#3a83f7",
        "contrast": 45
      },
      "dark": {
        "surface": "#000000",
        "ink": "#ededed",
        "accent": "#3a83f7",
        "contrast": 60
      }
    }
  },
  "absolutely": {
    "name": "Absolutely",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#2d2d2b",
        "ink": "#f9f9f7",
        "accent": "#cc7d5e",
        "contrast": 60
      },
      "light": {
        "surface": "#f9f9f7",
        "ink": "#2d2d2b",
        "accent": "#cc7d5e",
        "contrast": 45
      }
    }
  },
  "ayu": {
    "name": "Ayu",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#10141c",
        "ink": "#bfbdb6",
        "accent": "#e6b450",
        "contrast": 60
      }
    }
  },
  "catppuccin": {
    "name": "Catppuccin",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#1e1e2e",
        "ink": "#cdd6f4",
        "accent": "#cba6f7",
        "contrast": 60
      },
      "light": {
        "surface": "#eff1f5",
        "ink": "#4c4f69",
        "accent": "#8839ef",
        "contrast": 45
      }
    }
  },
  "codex": {
    "name": "Codex",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#111111",
        "ink": "#fcfcfc",
        "accent": "#0169cc",
        "contrast": 60
      },
      "light": {
        "surface": "#ffffff",
        "ink": "#0d0d0d",
        "accent": "#0169cc",
        "contrast": 45
      }
    }
  },
  "dracula": {
    "name": "Dracula",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#282a36",
        "ink": "#f8f8f2",
        "accent": "#ff79c6",
        "contrast": 60
      }
    }
  },
  "everforest": {
    "name": "Everforest",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#2d353b",
        "ink": "#d3c6aa",
        "accent": "#a7c080",
        "contrast": 60
      },
      "light": {
        "surface": "#fdf6e3",
        "ink": "#5c6a72",
        "accent": "#93b259",
        "contrast": 45
      }
    }
  },
  "github": {
    "name": "GitHub",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#0d1117",
        "ink": "#e6edf3",
        "accent": "#1f6feb",
        "contrast": 60
      },
      "light": {
        "surface": "#ffffff",
        "ink": "#1f2328",
        "accent": "#0969da",
        "contrast": 45
      }
    }
  },
  "gruvbox": {
    "name": "Gruvbox",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#282828",
        "ink": "#ebdbb2",
        "accent": "#458588",
        "contrast": 60
      },
      "light": {
        "surface": "#fbf1c7",
        "ink": "#3c3836",
        "accent": "#458588",
        "contrast": 45
      }
    }
  },
  "linear": {
    "name": "Linear",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#0f0f11",
        "ink": "#e3e4e6",
        "accent": "#606acc",
        "contrast": 60
      },
      "light": {
        "surface": "#fcfcfd",
        "ink": "#1b1b1b",
        "accent": "#5e6ad2",
        "contrast": 45
      }
    }
  },
  "lobster": {
    "name": "Lobster",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#111827",
        "ink": "#e4e4e7",
        "accent": "#ff5c5c",
        "contrast": 60
      }
    }
  },
  "material": {
    "name": "Material",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#212121",
        "ink": "#eeffff",
        "accent": "#80cbc4",
        "contrast": 60
      }
    }
  },
  "matrix": {
    "name": "Matrix",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#040805",
        "ink": "#b8ffca",
        "accent": "#1eff5a",
        "contrast": 60
      }
    }
  },
  "monokai": {
    "name": "Monokai",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#272822",
        "ink": "#f8f8f2",
        "accent": "#99947c",
        "contrast": 60
      }
    }
  },
  "night-owl": {
    "name": "Night Owl",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#011627",
        "ink": "#d6deeb",
        "accent": "#44596b",
        "contrast": 60
      }
    }
  },
  "nord": {
    "name": "Nord",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#2e3440",
        "ink": "#d8dee9",
        "accent": "#88c0d0",
        "contrast": 60
      }
    }
  },
  "notion": {
    "name": "Notion",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#191919",
        "ink": "#d9d9d8",
        "accent": "#3183d8",
        "contrast": 60
      },
      "light": {
        "surface": "#ffffff",
        "ink": "#37352f",
        "accent": "#3183d8",
        "contrast": 45
      }
    }
  },
  "og": {
    "name": "OG",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#343541",
        "ink": "#d1d5db",
        "accent": "#10a37f",
        "contrast": 60
      }
    }
  },
  "one": {
    "name": "One",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#282c34",
        "ink": "#abb2bf",
        "accent": "#4d78cc",
        "contrast": 60
      },
      "light": {
        "surface": "#fafafa",
        "ink": "#383a42",
        "accent": "#526fff",
        "contrast": 45
      }
    }
  },
  "oscurange": {
    "name": "Oscurange",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#0b0b0f",
        "ink": "#e6e6e6",
        "accent": "#f9b98c",
        "contrast": 60
      }
    }
  },
  "proof": {
    "name": "Proof",
    "group": "codex",
    "variants": {
      "light": {
        "surface": "#f5f3ed",
        "ink": "#2f312d",
        "accent": "#3d755d",
        "contrast": 45
      }
    }
  },
  "raycast": {
    "name": "Raycast",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#101010",
        "ink": "#fefefe",
        "accent": "#ff6363",
        "contrast": 60
      },
      "light": {
        "surface": "#ffffff",
        "ink": "#030303",
        "accent": "#ff6363",
        "contrast": 45
      }
    }
  },
  "rose-pine": {
    "name": "Rose Pine",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#232136",
        "ink": "#e0def4",
        "accent": "#ea9a97",
        "contrast": 60
      },
      "light": {
        "surface": "#faf4ed",
        "ink": "#575279",
        "accent": "#d7827e",
        "contrast": 45
      }
    }
  },
  "sentry": {
    "name": "Sentry",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#2d2935",
        "ink": "#e6dff9",
        "accent": "#7055f6",
        "contrast": 60
      }
    }
  },
  "solarized": {
    "name": "Solarized",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#002b36",
        "ink": "#839496",
        "accent": "#d30102",
        "contrast": 60
      },
      "light": {
        "surface": "#fdf6e3",
        "ink": "#657b83",
        "accent": "#b58900",
        "contrast": 45
      }
    }
  },
  "temple": {
    "name": "Temple",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#02120c",
        "ink": "#c7e6da",
        "accent": "#e4f222",
        "contrast": 60
      }
    }
  },
  "tokyo-night": {
    "name": "Tokyo Night",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#1a1b26",
        "ink": "#a9b1d6",
        "accent": "#3d59a1",
        "contrast": 60
      }
    }
  },
  "vercel": {
    "name": "Vercel",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#000000",
        "ink": "#ededed",
        "accent": "#006efe",
        "contrast": 50
      },
      "light": {
        "surface": "#ffffff",
        "ink": "#171717",
        "accent": "#006aff",
        "contrast": 40
      }
    }
  },
  "vscode-plus": {
    "name": "VS Code Plus",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#1e1e1e",
        "ink": "#d4d4d4",
        "accent": "#007acc",
        "contrast": 60
      },
      "light": {
        "surface": "#ffffff",
        "ink": "#000000",
        "accent": "#007acc",
        "contrast": 45
      }
    }
  },
  "xcode": {
    "name": "Xcode",
    "group": "codex",
    "variants": {
      "dark": {
        "surface": "#1f1f24",
        "ink": "#ffffff",
        "accent": "#5482ff",
        "contrast": 60
      },
      "light": {
        "surface": "#ffffff",
        "ink": "#000000",
        "accent": "#0e0eff",
        "contrast": 45
      }
    }
  }
};
