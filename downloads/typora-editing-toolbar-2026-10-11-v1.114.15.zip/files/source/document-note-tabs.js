class DocumentNoteTabs {
    constructor(manager){
        this.m=manager;this.root=document.createElement('div');this.root.className='et-document-tabs';
        this.root.innerHTML='<div class="et-document-tab-strip" role="tablist" aria-label="笔记标签"></div><button class="et-document-tab-summary" hidden></button><div class="et-document-tab-actions"><button data-tabs="add" aria-label="新建笔记" title="新建笔记">＋</button><button data-tabs="all" aria-label="全部笔记" title="全部笔记" aria-expanded="false"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M5 3h11v14H5zM2 6v11a2 2 0 0 0 2 2M8 7h5M8 10h5M8 13h3"/></svg></button><button data-tabs="collapse" aria-label="折叠标签栏" title="折叠标签栏">−</button></div>';
        manager.panel.querySelector('.et-note-empty').before(this.root);this.strip=this.root.querySelector('.et-document-tab-strip');this.summary=this.root.querySelector('.et-document-tab-summary');
        this.popup=document.createElement('div');this.popup.className='et-document-tab-menu';this.popup.hidden=true;manager.panel.append(this.popup);
        this.root.querySelector('[data-tabs=add]').onclick=()=>{this.dismiss();manager.newNote();};
        this.root.querySelector('[data-tabs=all]').onclick=()=>this.popup.hidden?this.all():this.dismiss();
        this.root.querySelector('[data-tabs=collapse]').onclick=()=>this.collapse();this.summary.onclick=()=>this.collapse(false);
        this.strip.addEventListener('wheel',e=>{if(this.strip.scrollWidth>this.strip.clientWidth){this.strip.scrollLeft+=Math.abs(e.deltaX)>Math.abs(e.deltaY)?e.deltaX:e.deltaY;e.preventDefault();}},{passive:false});
        manager.panel.addEventListener('mousedown',e=>{if(e.target===this.inline?.input)return;if(!this.popup.contains(e.target)&&!e.target.closest('[data-tabs=all]'))this.dismiss();});
        this.heldWidths=new Set();
        const releaseWidths=()=>{this.pointerDown=false;setTimeout(()=>{for(const wrap of this.heldWidths){wrap.style.width='';wrap.style.flexBasis='';}this.heldWidths.clear();},0);};
        for(const doc of [document,manager.frame.contentDocument]){doc.addEventListener('pointerdown',()=>{this.pointerDown=true;},true);for(const type of ['pointerup','pointercancel'])doc.addEventListener(type,releaseWidths,true);}
        window.addEventListener('blur',releaseWidths);
        for(const type of ['pointerdown','focusin'])document.addEventListener(type,e=>{if(!manager.panel.contains(e.target))this.dismiss();},true);
        // Events in the editor's iframe do not bubble into the side panel.
        for(const type of ['pointerdown','focusin'])manager.frame.contentDocument.addEventListener(type,()=>this.dismiss(),true);
        this.popup.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();this.dismiss();this.root.querySelector('[data-tabs=all]').focus();}if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)&&e.target.tagName!=='INPUT'){e.preventDefault();const buttons=[...this.popup.querySelectorAll('button:not(:disabled)')],i=buttons.indexOf(document.activeElement),next=e.key==='Home'?0:e.key==='End'?buttons.length-1:(i+(e.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length;buttons[next]?.focus();}});
    }
    button(label,fn){const b=document.createElement('button');b.type='button';b.textContent=label;b.onclick=fn;this.popup.append(b);return b;}
    dismiss(){this.finishRename();this.cancelDelete();this.popup.hidden=true;this.popup.replaceChildren();this.root.querySelector('[data-tabs=all]').setAttribute('aria-expanded','false');}
    cancelDelete(){clearTimeout(this.deleteTimer);this.deleting=null;this.popup.querySelectorAll('[data-note-remove]').forEach(b=>{b.innerHTML=this.m._noteIcon('close');b.classList.remove('confirm');b.title='删除笔记';b.setAttribute('aria-label','删除笔记 '+b.dataset.title);});}
    deleteFromList(id){
        const m=this.m,n=m.ctx.notes.find(n=>n.id===id);if(!n||m.ctx.readonly)return;
        if(this.deleting!==id){this.cancelDelete();this.deleting=id;const b=[...this.popup.querySelectorAll('[data-note-remove]')].find(b=>b.dataset.noteRemove===id);if(!b)return;b.innerHTML=m._noteIcon('check');b.classList.add('confirm');b.title='再次点击确认删除';b.setAttribute('aria-label','确认删除笔记 '+n.title);this.deleteTimer=setTimeout(()=>this.cancelDelete(),10000);return;}
        const scroll=this.popup.scrollTop;m.deleteNote(id);this.all();this.popup.scrollTop=scroll;
    }
    inlineRename(id){
        const m=this.m,n=m.ctx.notes.find(n=>n.id===id);if(!n||m.ctx.readonly)return;this.dismiss();
        const wrap=[...this.strip.children].find(e=>e.dataset.id===id),tab=wrap?.querySelector('[role=tab]');if(!tab)return;
        const input=document.createElement('input');input.type='text';input.className='et-document-tab-name';input.maxLength=100;input.value=n.title||'';input.setAttribute('aria-label','笔记名称');
        this.inline={id,ctx:m.ctx,wrap,tab,input};wrap.draggable=false;wrap.classList.add('renaming');tab.hidden=true;tab.before(input);
        for(const type of ['mousedown','click','dblclick','contextmenu'])input.addEventListener(type,e=>e.stopPropagation());
        input.addEventListener('keydown',e=>{e.stopPropagation();if(e.isComposing||e.keyCode===229)return;if(e.key==='Enter'||e.key==='Escape'){e.preventDefault();this.finishRename(e.key==='Enter');this.strip.querySelector('[aria-selected=true]')?.focus();}});
        input.addEventListener('blur',()=>this.finishRename());input.focus();input.select();
    }
    finishRename(commit=true){
        const edit=this.inline;if(!edit)return;this.inline=null;const title=edit.input.value;
        // Changing the label width during mousedown must not move the clicked neighbour.
        if(this.pointerDown){edit.wrap.style.width=edit.wrap.style.flexBasis=edit.wrap.getBoundingClientRect().width+'px';this.heldWidths.add(edit.wrap);}
        edit.input.remove();edit.tab.hidden=false;edit.wrap.classList.remove('renaming');edit.wrap.draggable=!this.m.ctx?.readonly;
        if(commit&&this.m.ctx===edit.ctx&&title.trim())this.m.renameNote(edit.id,title);
    }
    reveal(id){const item=[...this.strip.children].find(e=>e.dataset.id===id);if(!item)return;const r=item.getBoundingClientRect(),s=this.strip.getBoundingClientRect();if(r.left<s.left)this.strip.scrollLeft+=r.left-s.left;else if(r.right>s.right)this.strip.scrollLeft+=r.right-s.right;}
    collapse(value){const u=this.m._ui();u.collapsed=value??!u.collapsed;this.m._rememberPage();this.m._saveUI();this.render();}
    render(){
        const m=this.m,u=m._ui();if(!u)return;const signature=JSON.stringify([m.ctx.key,m.ctx.notes.map(n=>[n.id,n.title]),u.opened,u.active,u.collapsed,Boolean(m.ctx.readonly)]);if(signature===this.signature)return;this.signature=signature;
        const structure=JSON.stringify([m.ctx.key,m.ctx.notes.map(n=>n.id),u.opened,u.active,u.collapsed,Boolean(m.ctx.readonly)]);
        // Keep click targets alive when a rename is committed by clicking another control.
        if(structure===this.structure){for(const wrap of this.strip.children){const n=m.ctx.notes.find(n=>n.id===wrap.dataset.id),tab=wrap.querySelector('[role=tab]');tab.textContent=tab.title=n.title||'未命名笔记';wrap.querySelector('.et-document-tab-close').setAttribute('aria-label','关闭标签 '+tab.title);}this.summary.textContent=(m._selected()?.title||'笔记')+' · '+m.ctx.notes.length+' 篇';return;}this.structure=structure;this.finishRename();
        const scroll=this.strip.scrollLeft;this.strip.replaceChildren();this.strip.hidden=u.collapsed;this.summary.hidden=!u.collapsed;this.summary.textContent=(m._selected()?.title||'笔记')+' · '+m.ctx.notes.length+' 篇';this.summary.title='展开标签栏';
        const collapse=this.root.querySelector('[data-tabs=collapse]');collapse.textContent=u.collapsed?'⌄':'−';collapse.title=u.collapsed?'展开标签栏':'折叠标签栏';collapse.setAttribute('aria-label',collapse.title);collapse.setAttribute('aria-expanded',String(!u.collapsed));this.root.querySelector('[data-tabs=add]').disabled=Boolean(m.ctx.readonly);
        for(const note of m.ctx.notes.filter(n=>u.opened.includes(n.id))){
            const wrap=document.createElement('div');wrap.className='et-document-tab';wrap.dataset.id=note.id;wrap.draggable=!m.ctx.readonly;wrap.classList.toggle('active',note.id===u.active);
            const tab=document.createElement('button');tab.type='button';tab.className='et-document-tab-label';tab.setAttribute('role','tab');tab.setAttribute('aria-selected',String(note.id===u.active));tab.tabIndex=note.id===u.active?0:-1;tab.title=note.title||'未命名笔记';tab.textContent=tab.title;tab.onclick=()=>m.selectNote(note.id);tab.ondblclick=()=>this.inlineRename(note.id);
            const close=document.createElement('button');close.type='button';close.className='et-document-tab-close';close.textContent='×';close.title='关闭标签';close.setAttribute('aria-label','关闭标签 '+tab.title);close.onclick=()=>m.closeTab(note.id);
            wrap.addEventListener('contextmenu',e=>{e.preventDefault();this.menu(note.id);});wrap.addEventListener('auxclick',e=>{if(e.button===1){e.preventDefault();m.closeTab(note.id);}});
            tab.addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();const notes=m.ctx.notes.filter(n=>u.opened.includes(n.id)),i=notes.findIndex(n=>n.id===note.id),at=e.key==='Home'?0:e.key==='End'?notes.length-1:Math.max(0,Math.min(notes.length-1,i+(e.key==='ArrowLeft'?-1:1)));if(e.altKey&&!m.ctx.readonly)m.moveNote(note.id,notes[at].id,at>i);else m.selectNote(notes[at].id);this.strip.querySelector('[aria-selected=true]')?.focus();});
            wrap.addEventListener('dragstart',e=>{if(m.ctx.readonly)return e.preventDefault();m._flushEditor();this.dragged=note.id;e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',note.id);wrap.classList.add('dragging');});
            wrap.addEventListener('dragover',e=>{if(!this.dragged)return;e.preventDefault();const after=e.clientX>wrap.getBoundingClientRect().left+wrap.offsetWidth/2;this.clearDrop();wrap.classList.add(after?'drop-after':'drop-before');const r=this.strip.getBoundingClientRect();if(e.clientX<r.left+24)this.strip.scrollLeft-=18;else if(e.clientX>r.right-24)this.strip.scrollLeft+=18;});
            wrap.addEventListener('drop',e=>{if(!this.dragged)return;e.preventDefault();const id=this.dragged;this.dragged=null;const after=e.clientX>wrap.getBoundingClientRect().left+wrap.offsetWidth/2;this.clearDrop();m.moveNote(id,note.id,after);});wrap.addEventListener('dragend',()=>{this.dragged=null;this.clearDrop();});
            wrap.append(tab,close);this.strip.append(wrap);
        }
        this.strip.scrollLeft=scroll;
    }
    clearDrop(){this.strip.querySelectorAll('.drop-before,.drop-after,.dragging').forEach(e=>e.classList.remove('drop-before','drop-after','dragging'));}
    show(label){this.dismiss();this.popup.hidden=false;this.popup.setAttribute('role','dialog');this.popup.setAttribute('aria-label',label);this.popup.style.top=(this.root.offsetTop+this.root.offsetHeight+6)+'px';this.popup.style.maxHeight=Math.max(80,this.m.panel.clientHeight-this.root.offsetTop-this.root.offsetHeight-28)+'px';}
    all(){this.show('全部笔记');this.root.querySelector('[data-tabs=all]').setAttribute('aria-expanded','true');const title=document.createElement('strong');title.textContent='全部笔记 · '+this.m.ctx.notes.length+' 篇';this.popup.append(title);if(!this.m.ctx.notes.length){const p=document.createElement('p');p.textContent='还没有笔记';this.popup.append(p);}for(const n of this.m.ctx.notes){
        const row=document.createElement('div');row.className='et-document-note-row';row.dataset.noteRow=n.id;
        const b=document.createElement('button');b.type='button';b.className='et-document-note-open';b.textContent=(this.m._ui().opened.includes(n.id)?'✓ ':'')+(n.title||'未命名笔记');b.onclick=()=>this.m.selectNote(n.id);b.dataset.openNote=n.id;b.title=n.title;
        const del=document.createElement('button');del.type='button';del.className='et-document-note-delete';del.dataset.noteRemove=n.id;del.dataset.title=n.title||'未命名笔记';del.innerHTML=this.m._noteIcon('close');del.title='删除笔记';del.setAttribute('aria-label','删除笔记 '+del.dataset.title);del.disabled=Boolean(this.m.ctx.readonly);del.onclick=e=>{e.stopPropagation();this.deleteFromList(n.id);};
        row.oncontextmenu=e=>{e.preventDefault();this.menu(n.id);};row.append(b,del);this.popup.append(row);
    }}
    menu(id){const m=this.m,n=m.ctx.notes.find(n=>n.id===id);if(!n)return;this.show('笔记标签菜单');this.button('重命名',()=>this.rename(id)).disabled=Boolean(m.ctx.readonly);this.button('关闭标签',()=>m.closeTab(id));this.button('关闭其他标签',()=>{for(const other of [...m._ui().opened])if(other!==id)m.closeTab(other);m.selectNote(id);});const del=this.button('删除笔记…',()=>this.confirmDelete(id));del.className='danger';del.disabled=Boolean(m.ctx.readonly);}
    rename(id){const m=this.m,n=m.ctx.notes.find(n=>n.id===id);if(!n||m.ctx.readonly)return;this.show('重命名笔记');const label=document.createElement('label');label.textContent='笔记名称';const input=document.createElement('input');input.type='text';input.maxLength=100;input.value=n.title||'';input.setAttribute('aria-label','笔记名称');label.append(input);this.popup.append(label);const commit=()=>{if(m.renameNote(id,input.value)){this.dismiss();this.reveal(id);}else input.setCustomValidity('请输入笔记名称');};this.button('保存名称',commit);this.button('取消',()=>this.dismiss());input.oninput=()=>input.setCustomValidity('');input.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();commit();}};input.focus();input.select();}
    confirmDelete(id){const m=this.m,n=m.ctx.notes.find(n=>n.id===id);if(!n||m.ctx.readonly)return;this.show('删除笔记');const p=document.createElement('p');p.textContent='删除笔记「'+(n.title||'未命名笔记')+'」？内容将被移除。只想暂时收起，请使用“关闭标签”。';this.popup.append(p);this.button('取消',()=>this.dismiss());const del=this.button('确认删除',()=>m.deleteNote(id));del.className='danger';}
}
