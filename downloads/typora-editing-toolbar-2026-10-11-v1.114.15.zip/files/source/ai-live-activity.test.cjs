
'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),http=require('node:http'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{EventEmitter}=require('node:events');
const Execution=require('./ai-execution.cjs'),Client=require('./ai-client.cjs'),Shell=require('./ai-shell.cjs');
test('partial parameters expose only complete top-level scalar fields and no file bodies',()=>{
 const call={id:'f',name:'create_project_file',arguments:'{"path":"中文 空格/demo.py","content":"private body'};const t={};
 const row=Execution.prepare(t,1,call);assert.equal(row.status,'preparing');assert.equal(row.phase,'arguments');assert.equal(row.parameters,'中文 空格/demo.py');assert.ok(!JSON.stringify(row).includes('private'));
 assert.equal(Execution.callArguments({arguments:'{"nested":{"path":"wrong"},"path":"right","content":"abc'}).value.path,'right');
 assert.equal(Execution.callArguments({arguments:'{"path":"C:\\\\中文\\\\a.py","x":'}).value.path,'C:\\中文\\a.py');
});
test('repeated snapshots never regress running/completed tools and duplicate calls execute once',async()=>{
 const t={executionRound:1},c={id:'one',name:'create_project_file',arguments:'{"path":"a.py","content":"x"}'};let count=0,finish;const gate=new Promise(r=>finish=r),events=[];
 const work=()=>{count++;return gate;},options={onExecution:()=>events.push(t.execution[0].status)};
 const p=Execution.tool(t,c,work,options);Execution.prepare(t,1,c);assert.equal(t.execution[0].status,'running');const p2=Execution.tool(t,c,work,options);assert.equal(p,p2);finish({created:true,path:'a.py'});await p;
 Execution.prepare(t,1,c);await Execution.tool(t,c,work,options);assert.equal(count,1);assert.equal(t.execution.length,1);assert.equal(t.execution[0].status,'success');assert.deepEqual(events,['preparing','running','success']);
});
test('SSE preparation appears before response completion; arguments.done reconciles without item.done',async t=>{
 let release;const gate=new Promise(r=>release=r);let finished=false;const s=http.createServer(async(q,r)=>{q.resume();r.writeHead(200,{'content-type':'text/event-stream'});const emit=x=>r.write('data: '+JSON.stringify(x)+'\n\n');
 emit({type:'response.output_item.added',item:{id:'i',call_id:'c',type:'function_call',name:'web_search',arguments:''}});
 emit({type:'response.function_call_arguments.delta',item_id:'i',delta:'{"query":"真实查询",'});
 await gate;emit({type:'response.function_call_arguments.done',item_id:'i',arguments:'{"query":"真实查询"}'});emit({type:'response.completed',response:{status:'completed',output:[]}});r.end();
 });await new Promise(r=>s.listen(0,'127.0.0.1',r));t.after(()=>{release();s.closeAllConnections();s.close();});
 const turn={};let observed;const visible=new Promise(r=>observed=r);
 const job=Execution.request(turn,c=>new Client(require).request({model:'mock',protocol:'openai-responses',webSearch:true,url:'http://127.0.0.1:'+s.address().port},'',[],c),{onExecution:()=>{if(turn.execution?.some(e=>e.parameters==='真实查询'))observed();}}).then(r=>{finished=true;return r;});
 await visible;assert.equal(finished,false);const e=turn.execution.find(e=>e.type==='tool');assert.equal(e.status,'preparing');assert.equal(e.startedAt,undefined);release();const result=await job;assert.equal(result.toolCalls[0].arguments,'{"query":"真实查询"}');assert.equal(e.phase,'queued');assert.equal(turn.execution.filter(e=>e.type==='tool').length,1);
});
test('ChatGPT worker immediately forwards ordered execution events without 80ms coalescing',async()=>{
 const stdin=new EventEmitter(),sent=[];stdin.setEncoding=()=>{};let finish;const gate=new Promise(r=>finish=r);
 class Service{async request(p,m,c){c.onEvent({id:'a',type:'message',text:'先检查',phase:'commentary'});c.onEvent({id:'b',type:'tool',callId:'b',name:'web_search',arguments:''});c.onEvent({id:'b',type:'tool',callId:'b',name:'web_search',arguments:'{"query":"x"}'});await gate;return {text:'完成'};}}
 vm.runInNewContext(fs.readFileSync(path.join(__dirname,'ai-chatgpt-worker.cjs'),'utf8'),{require:()=>({ChatGPTService:Service,publicError:e=>e.message}),process:{argv:['','','unused'],stdin,stdout:{write:s=>sent.push(JSON.parse(s))}},Buffer,AbortController,setTimeout,clearTimeout});
 stdin.emit('data',JSON.stringify({id:'req',method:'request'})+'\n');await Promise.resolve();await Promise.resolve();assert.equal(sent.length,3);assert.deepEqual(sent.map(e=>e.data.id),['a','b','b']);assert.ok(sent.every(e=>e.event==='execution'));finish();await gate;
});
test('partial shell output is available without a newline and known fragmented secrets stay hidden',()=>{
 assert.equal(Shell.liveText('real partial output'), 'real partial output');
 assert.ok(!Shell.liveText('value=sensit',['sensitive-key']).includes('sensit'));
 assert.ok(!Shell.liveText('Authorization: Bea').includes('Bea'));
 assert.ok(!Shell.liveText('sk-partial').includes('partial'));
});

test('interrupted history is cancelled without fabricating a command end timestamp',()=>{const row=Execution.snapshot([{id:'c',type:'tool',status:'running',startedAt:100,elapsedMs:20}],{interrupted:true})[0];assert.equal(row.status,'cancelled');assert.equal(row.endedAt,undefined);assert.equal(row.elapsedMs,20);assert.match(row.result,/结束时间未知/);});
