const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),vm=require('node:vm'),net=require('node:net'),crypto=require('node:crypto'),cp=require('node:child_process');
const scratch=path.join(os.homedir(),'Downloads','codex-temp','direct-open-tests');fs.mkdirSync(scratch,{recursive:true});
const source=fs.readFileSync(require.resolve('./document-open-pipe.js'),'utf8');
async function fixture(t,profile){
  profile??=fs.mkdtempSync(path.join(scratch,'profile-'));const A=path.join(profile,'A.md'),B=path.join(profile,'第二章 空格.md');fs.writeFileSync(A,'original A');fs.writeFileSync(B,'original B');
  const state={file:A,opened:[],loading:false,activeText:'unsaved A'};
  const manager={tabs:[{path:A}],supported:p=>typeof p==='string'&&path.isAbsolute(p)&&/\.md$/i.test(p),change(fn){fn({tabs:this.tabs});this.tabs=this.tabs.filter((x,i,a)=>a.findIndex(y=>y.path===x.path)===i);},setFilter(f){state.filter=f;}};
  const router={manager,id:crypto.randomUUID(),focused:1,queue:[],loading:()=>state.loading,drain(){while(this.queue.length)state.opened.push(this.queue.shift().file);}};
  const box={reqnode:require,File:{option:{userDataPath:profile},bundle:{get filePath(){return state.file;}}}};vm.createContext(box);vm.runInContext(source+';globalThis.Pipe=EditingToolbarDocumentOpenPipe',box);
  const pipe=new box.Pipe(router);await new Promise((resolve,reject)=>{pipe.server.once('listening',resolve);pipe.server.once('error',reject);});t.after(()=>pipe.dispose());return{pipe,router,manager,state,profile,A,B};
}
function send(pipe,parts){return new Promise((resolve,reject)=>{const socket=net.connect('\\\\.\\pipe\\'+pipe.name);let result='';socket.setEncoding('utf8');socket.on('error',reject);socket.on('data',s=>result+=s);socket.on('end',()=>resolve(result?JSON.parse(result):null));socket.on('connect',()=>{for(const part of parts)socket.write(part);});});}
test('fragmented Unicode request is retained before acknowledgement and leaves old unsaved text intact',async t=>{const f=await fixture(t),request=JSON.stringify({version:1,file:f.B})+'\n';const result=await send(f.pipe,[request.slice(0,17),request.slice(17)]);assert.equal(result.accepted,true);assert.deepEqual(f.manager.tabs.map(t=>t.path),[f.A,f.B]);assert.deepEqual(f.state.opened,[f.B]);assert.equal(f.state.activeText,'unsaved A');assert.equal(f.state.file,f.A);});
test('duplicate files do not add duplicate tabs',async t=>{const f=await fixture(t);for(let i=0;i<2;i++)assert.equal((await send(f.pipe,[JSON.stringify({version:1,file:f.B})+'\n'])).accepted,true);assert.equal(f.manager.tabs.length,2);});
test('missing, relative and unsupported paths are rejected without adding a tab',async t=>{const f=await fixture(t);for(const file of ['relative.md',path.join(f.profile,'missing.md'),path.join(f.profile,'image.png')]){const r=await send(f.pipe,[JSON.stringify({version:1,file})+'\n']);assert.equal(r.accepted,false);}assert.equal(f.manager.tabs.length,1);assert.equal(f.state.opened.length,0);});
test('malformed and wrong-version messages cannot navigate the document',async t=>{const f=await fixture(t);assert.equal((await send(f.pipe,['{invalid}\n'])).accepted,false);assert.equal((await send(f.pipe,[JSON.stringify({version:2,file:f.B})+'\n'])).accepted,false);assert.equal(f.state.opened.length,0);});
test('window metadata tracks availability, focus and path; dispose removes only its own record',async t=>{const f=await fixture(t),g=await fixture(t,f.profile);f.state.loading=true;f.router.focused=50;f.pipe.publish();const data=JSON.parse(fs.readFileSync(f.pipe.meta,'utf8'));assert.equal(data.ready,false);assert.equal(data.focused,50);f.pipe.dispose();assert.equal(fs.existsSync(f.pipe.meta),false);assert.equal(fs.existsSync(g.pipe.meta),true);});
test('GUI launcher reaches live pipes without starting Typora; supports ordering and multiple files',async t=>{
  const f=await fixture(t),g=await fixture(t,f.profile),install=fs.mkdtempSync(path.join(scratch,'launcher-'));fs.mkdirSync(path.join(install,'resources'));
  const launcher=path.join(install,'resources','editing-toolbar.open.exe');fs.copyFileSync(path.join(__dirname,'../plugin/editing-toolbar.open.exe'),launcher);
  const log=path.join(install,'native-launch.log'),stub=path.join(install,'stub.cs');fs.writeFileSync(stub,'using System;using System.IO;class App{static void Main(string[] args){File.AppendAllLines(Environment.GetEnvironmentVariable("ET_OPEN_TEST_LOG"),args);}}');
  cp.execFileSync('C:/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe',['/nologo','/target:winexe','/out:'+path.join(install,'Typora.exe'),stub],{windowsHide:true});
  const run=args=>new Promise((resolve,reject)=>cp.execFile(launcher,['--et-profile',f.profile,...args],{windowsHide:true,env:{...process.env,ET_OPEN_TEST_LOG:log}},e=>e?reject(e):resolve()));
  g.router.focused=100;g.state.file=g.B;g.pipe.publish();f.router.focused=1;f.pipe.publish();
  await run([f.A]);assert.deepEqual(f.state.opened,[f.A]);assert.equal(g.state.opened.length,0);
  // Loading is not a disconnected window: retain and queue instead of launching
  // another Typora process after the readiness timeout.
  f.state.loading=true;g.state.loading=true;f.pipe.publish();g.pipe.publish();
  await run([f.A]);assert.deepEqual(f.state.opened,[f.A,f.A]);assert.equal(fs.existsSync(log),false);
  f.state.loading=false;g.state.loading=false;f.pipe.publish();g.pipe.publish();
  fs.writeFileSync(path.join(f.pipe.dir,'corrupt.json'),'{bad JSON');fs.writeFileSync(path.join(f.pipe.dir,'stale.json'),JSON.stringify({version:1,pid:process.pid,ready:true,pipe:f.pipe.prefix+crypto.randomUUID(),file:'',tabs:[],focused:999}));
  const C=path.join(f.profile,'C.md');fs.writeFileSync(C,'C');await run([f.B,C]);assert.deepEqual(g.state.opened,[f.B,C]);assert.equal(fs.existsSync(log),false);
  await run([path.join(f.profile,'missing.md')]);assert.match(fs.readFileSync(log,'utf8'),/missing\.md/);
  fs.unlinkSync(log);f.pipe.dispose();g.pipe.dispose();await run([C]);assert.match(fs.readFileSync(log,'utf8'),/C\.md/);
});

test('another Typora profile cannot delay a cold Markdown open by eight seconds',{skip:process.platform!=='win32'},async t=>{
  const install=fs.mkdtempSync(path.join(scratch,'cold-launch-')),profile=path.join(install,'target-profile');
  fs.mkdirSync(path.join(install,'resources'));fs.mkdirSync(profile);
  const launcher=path.join(install,'resources','editing-toolbar.open.exe'),log=path.join(install,'native-launch.log'),hold=path.join(install,'other-profile.ready'),stub=path.join(install,'stub.cs');
  fs.copyFileSync(path.join(__dirname,'../plugin/editing-toolbar.open.exe'),launcher);
  fs.writeFileSync(stub,'using System;using System.IO;using System.Threading;class App{static void Main(string[] args){if(args.Length>0&&args[0]=="--hold"){File.WriteAllText(args[1],"ready");Thread.Sleep(30000);return;}File.AppendAllLines(Environment.GetEnvironmentVariable("ET_OPEN_TEST_LOG"),args);}}');
  cp.execFileSync('C:/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe',['/nologo','/target:winexe','/out:'+path.join(install,'Typora.exe'),stub],{windowsHide:true});
  const other=cp.spawn(path.join(install,'Typora.exe'),['--hold',hold],{windowsHide:true,stdio:'ignore'});t.after(()=>other.kill());
  for(let i=0;i<100&&!fs.existsSync(hold);i++)await new Promise(r=>setTimeout(r,20));
  assert.equal(fs.existsSync(hold),true,'independent Typora process is running');
  const file=path.join(profile,'中文 空格.md');fs.writeFileSync(file,'# unchanged');
  for(let i=0;i<2;i++){
    const start=performance.now();
    await new Promise((resolve,reject)=>cp.execFile(launcher,['--et-profile',profile,file],{windowsHide:true,env:{...process.env,ET_OPEN_TEST_LOG:log}},e=>e?reject(e):resolve()));
    assert.ok(performance.now()-start<2500,'fallback must not wait for a different profile');
  }
  assert.equal(fs.readFileSync(log,'utf8').split(file).length-1,2);
  assert.equal(fs.readFileSync(file,'utf8'),'# unchanged');
});
