const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
export function depthUnit(id){let h=2166136261;for(const c of id)h=Math.imul(h^c.charCodeAt(0),16777619);h=Math.imul(h^(h>>>16),2246822507);return((h>>>0)/4294967296-.5)*1.6;}
export function makeScene(nodes,yaw,pitch){
 let left=Infinity,right=-Infinity,top=Infinity,bottom=-Infinity;
 for(const n of nodes)if(Number.isFinite(n.x+n.y)){left=Math.min(left,n.x);right=Math.max(right,n.x);top=Math.min(top,n.y);bottom=Math.max(bottom,n.y);}
 if(!Number.isFinite(left))left=right=top=bottom=0;
 const cy=Math.cos(yaw),sy=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch),span=Math.max(140,Math.hypot(right-left,bottom-top)/2);
 return{cx:(left+right)/2,cy:(top+bottom)/2,span,depth:span*.35,focal:span*6,m:[cy,0,sy,sp*sy,cp,-sp*cy,-cp*sy,sp,cp*cy]};
}
export function projectNode(n,scene){
 const x=n.x-scene.cx,y=n.y-scene.cy,z=n.depthUnit*scene.depth,m=scene.m;
 const rx=m[0]*x+m[1]*y+m[2]*z,ry=m[3]*x+m[4]*y+m[5]*z,rz=m[6]*x+m[7]*y+m[8]*z,k=scene.focal/Math.max(scene.focal*.35,scene.focal-rz);
 return{x:rx*k,y:ry*k,z:rz,k,r:n.radius*k,opacity:clamp(.9+rz/scene.span*.12,.65,1),worldZ:z};
}
// Drag along the camera-facing plane; invert the same rotation used for drawing.
export function unprojectPoint(point,scene,z){
 const k=(scene.focal-z)/scene.focal,x=point.x*k,y=point.y*k,m=scene.m;
 return{x:m[0]*x+m[3]*y+m[6]*z+scene.cx,y:m[1]*x+m[4]*y+m[7]*z+scene.cy,z:m[2]*x+m[5]*y+m[8]*z};
}
export function edgeOpacity(length,reference,strength,depth=1,focused=false,active=false,dense=false){
 const amount=clamp(Number(strength)||0,0,1),distance=1/(1+Math.pow(length/Math.max(40,reference*1.8),1.5));
 const fade=1-amount+amount*(.14+.86*distance);
 // Hovering explicitly requests the relationship, so do not fade it out.
 return focused?(active?.76:.025*fade):(dense?.2:.36)*fade*depth;
}
