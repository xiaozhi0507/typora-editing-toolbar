'use strict';
module.exports=String.raw`param([Parameter(Mandatory=$true)][string]$Job,[Parameter(Mandatory=$true)][string]$Attempt)
$ErrorActionPreference='Stop'
$j=Get-Content -LiteralPath $Job -Raw -Encoding UTF8 | ConvertFrom-Json
$dir=Split-Path -Parent $Job
$status=Join-Path $dir 'status.json'
$cancel=Join-Path $dir 'cancel'
if($j.attempt -ne $Attempt){exit 0}
function Test-CurrentAttempt {
    return ((Get-Content -LiteralPath $status -Raw -Encoding UTF8 | ConvertFrom-Json).attempt -eq $Attempt)
}
function Report([string]$State,[string]$Message='') {
    if(-not (Test-CurrentAttempt)){exit 0}
    $value=@{state=$State;message=$Message;pid=$PID;version=$j.version;attempt=$Attempt;time=(Get-Date -Format o)} | ConvertTo-Json
    [IO.File]::WriteAllText($status+'.tmp',$value,[Text.UTF8Encoding]::new($false))
    Move-Item -LiteralPath ($status+'.tmp') -Destination $status -Force
}
try {
    Report 'waiting'
    $deadline=[DateTime]::UtcNow.AddMinutes(30)
    $exe=[IO.Path]::GetFullPath((Join-Path $j.typoraDir 'Typora.exe'))
    while($true) {
        if(-not (Test-CurrentAttempt)){exit 0}
        if(Test-Path -LiteralPath $cancel){Report 'canceled';exit 0}
        if([DateTime]::UtcNow -gt $deadline){Report 'expired';exit 0}
        $running=$false
        foreach($p in @(Get-Process -Name Typora -ErrorAction SilentlyContinue)) {
            try {$pPath=$p.Path} catch {$pPath=$null}
            if(-not $pPath -or $pPath -eq $exe){$running=$true;break}
        }
        if(-not $running){break}
        Start-Sleep -Seconds 2
    }
    if(Test-Path -LiteralPath $cancel){Report 'canceled';exit 0}
    Report 'installing'
    $base=[IO.Path]::GetFullPath((Join-Path $dir 'package')).TrimEnd('\')+'\'
    foreach($entry in $j.files){
        $file=[IO.Path]::GetFullPath((Join-Path $base $entry.path))
        if(-not $file.StartsWith($base,[StringComparison]::OrdinalIgnoreCase)){throw 'Package path is outside staging directory'}
        if((Get-Item -LiteralPath $file).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Package contains a link'}
        if((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256){throw 'Package changed after verification'}
    }
    $installer=Join-Path $base 'files\scripts\install-typora-toolbar.ps1'
    $escapedInstaller="'"+$installer.Replace("'","''")+"'"
    $escapedTarget="'"+([string]$j.typoraDir).Replace("'","''")+"'"
    $log=Join-Path $dir 'install.log'
    $escapedLog="'"+$log.Replace("'","''")+"'"
    $command='$global:LASTEXITCODE=0; & '+$escapedInstaller+' -TyporaDir '+$escapedTarget+' -SkipFileAssociation *> '+$escapedLog+'; exit $LASTEXITCODE'
    $encoded=[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($command))
    $shell=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $child=Start-Process -FilePath $shell -WindowStyle Hidden -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -EncodedCommand '+$encoded) -Wait -PassThru
    if($child.ExitCode -ne 0){throw ('Installer exit code '+$child.ExitCode+'; see install.log')}
    foreach($entry in $j.files){
        if(([string]$entry.path).StartsWith('files/plugin/')){
            $relative=([string]$entry.path).Substring(13)
            if($relative.Contains('/')){throw 'Unexpected runtime subfolder'}
            $target=Join-Path (Join-Path $j.typoraDir 'resources') $relative
            if((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256){throw 'Installed file verification failed'}
        }
    }
    Report 'complete'
    # Reopen only after the installer and every installed runtime hash passed.
    # If the user has already reopened this installation, leave that instance alone.
    try {
        $running=$false
        foreach($p in @(Get-Process -Name Typora -ErrorAction SilentlyContinue)) {
            try {$pPath=$p.Path} catch {$pPath=$null}
            if(-not $pPath -or $pPath -eq $exe){$running=$true;break}
        }
        if(-not $running){Start-Process -FilePath $exe -WorkingDirectory $j.typoraDir -ErrorAction Stop | Out-Null}
    } catch {Report 'complete' '安装已完成，请手动打开 Typora'}
} catch {Report 'failed' $_.Exception.Message;exit 1}
`;
