class EditingToolbarParagraphSpacing {
 constructor(toolbar){
  this.toolbar=toolbar;this.state=ETParagraphSpacing.read(null);
  try{this.state=ETParagraphSpacing.read(localStorage.getItem(ETParagraphSpacing.key));}catch{}
  this.apply();
  window.addEventListener('storage',event=>{if(event.key===ETParagraphSpacing.key||event.key===null){this.state=ETParagraphSpacing.read(event.newValue);this.apply();this.refresh();}});
 }
 apply(){
  this.style=document.getElementById('et-paragraph-spacing-style')||document.createElement('style');
  this.style.id='et-paragraph-spacing-style';this.style.textContent=ETParagraphSpacing.css(this.state);
  if(!this.style.isConnected)document.head.append(this.style);
 }
 save(){try{localStorage.setItem(ETParagraphSpacing.key,JSON.stringify(this.state));}catch{this.toolbar._showToolbarNotice('间距已应用，但暂时无法保存设置。');}}
 set(name,input){const n=ETParagraphSpacing.value(name,input);if(n===null)return;this.toolbar._markPopoverInteraction?.();this.state[name]=n;this.apply();this.save();this.refresh(name);}
 defaults(){
  const p=document.querySelector('#write > p')||document.querySelector('#write p');if(!p)return {line:1.6,paragraph:.8};
  const style=getComputedStyle(p),size=parseFloat(style.fontSize)||16;
  return {line:parseFloat(style.lineHeight)/size||1.6,paragraph:Math.max(parseFloat(style.marginTop)||0,parseFloat(style.marginBottom)||0)/size};
 }
 refresh(edited){
  if(!this.panel?.isConnected)return;
  const defaults=this.defaults();
  for(const name of Object.keys(ETParagraphSpacing.fields)){
   const row=this.panel.querySelector('[data-spacing="'+name+'"]'),n=ETParagraphSpacing.value(name,this.state[name]??defaults[name]);
   const range=row.querySelector('input[type=range]'),limits=ETParagraphSpacing.fields[name];range.value=n;range.style.setProperty('--spacing-fill',((n-limits.min)/(limits.max-limits.min)*100)+'%');
   const number=row.querySelector('input[type=number]');if(document.activeElement!==number||edited===name)number.value=Number(n.toFixed(2));
   row.querySelector('.et-spacing-number').title=this.state[name]===null?'当前使用主题默认间距':'自定义间距，已自动保存';
  }
  const isDefault=Object.values(this.state).every(n=>n===null);
  this.panel.querySelector('[data-spacing-reset]').disabled=isDefault;
  this.panel.querySelector('.et-spacing-status').textContent=isDefault?'主题默认':'即时生效';
 }
 buildPanel(){
  const host=document.createElement('div'),root=document.createElement('section');this.panel=root;root.className='et-spacing-controls';
  root.setAttribute('role','group');root.setAttribute('aria-label','行段间距');
  const icon=paths=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+paths+'</svg>';
  root.innerHTML='<div class="et-spacing-heading"><strong>行段间距</strong><span title="应用于全文正文，调整后立即生效">全文</span></div>';
  for(const [name,label,unit,hint] of [['line','行间距','倍','正文、列表与引用的行高，按当前字号计算。'],['paragraph','段落间距','em','正文段落之间的距离，1 em 等于当前段落的字号。']]){
   const limits=ETParagraphSpacing.fields[name],row=document.createElement('div');row.className='et-spacing-row';row.dataset.spacing=name;
   const glyph=icon(name==='line'?'<path d="M5 4v16M2 7l3-3 3 3M2 17l3 3 3-3M12 5h9M12 12h9M12 19h9"/>':'<path d="M4 4h16M4 7h12M4 17h16M4 20h12M18 10v4m-2-2 2 2 2-2"/>');
   row.innerHTML='<div class="et-spacing-label"><label for="et-spacing-'+name+'">'+glyph+'<span>'+label+'</span></label><label class="et-spacing-number"><input id="et-spacing-'+name+'" type="number" aria-label="'+label+'" min="'+limits.min+'" max="'+limits.max+'" step="'+limits.step+'"><span>'+unit+'</span></label></div><input type="range" aria-label="'+label+'滑块" min="'+limits.min+'" max="'+limits.max+'" step="'+limits.step+'">';
   row.title=hint;
   const range=row.querySelector('[type=range]'),number=row.querySelector('[type=number]');
   range.addEventListener('input',()=>this.set(name,range.value));
   number.addEventListener('input',()=>{if(number.value!==''&&number.validity.valid){this.set(name,number.value);}});
   const commit=()=>{if(number.value!=='')this.set(name,number.value);this.refresh(name);};
   number.addEventListener('change',commit);number.addEventListener('blur',commit);
   number.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();commit();}});
   root.append(row);
  }
  const footer=document.createElement('div');footer.className='et-spacing-footer';footer.innerHTML='<span class="et-spacing-status" role="status"></span>';
  const reset=document.createElement('button');reset.type='button';reset.dataset.spacingReset='';reset.className='et-spacing-reset';reset.innerHTML=icon('<path d="M3 5v5h5M3.5 10a8 8 0 1 1 .5 6"/>')+'<span>恢复默认</span>';reset.setAttribute('aria-label','恢复主题默认');reset.title='恢复主题原有的行高和段落间距，同时清除已保存的间距设置。';
  reset.addEventListener('click',()=>{this.state=ETParagraphSpacing.normalize(null);this.apply();this.save();this.refresh();});footer.append(reset);root.append(footer);
  root.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();const trigger=this.toolbar.activePopover?.parentElement.querySelector(':scope > .et-btn');this.toolbar._closeActivePopover();trigger?.focus({preventScroll:true});}});
  for(const event of ['click','mousedown','input','change','keyup','keypress','paste','copy','cut'])root.addEventListener(event,e=>e.stopPropagation());
  host.append(root);requestAnimationFrame(()=>{const back=root.closest('.et-menu-panel')?.querySelector('.et-menu-back');if(back){back.classList.add('et-spacing-back');back.innerHTML=icon('<path d="m14 6-6 6 6 6"/>');back.setAttribute('aria-label','返回段落菜单');back.title='返回段落菜单';}this.refresh();});return host;
 }
 createControl(id,definition,location){
  const wrapper=document.createElement('div');wrapper.className='et-popover-anchor';
  const panel=document.createElement('div');panel.className='et-menu-panel et-actions-detail';panel.hidden=true;panel.setAttribute('role','dialog');panel.setAttribute('aria-label','行段间距');
  const button=this.toolbar._createButton(id,definition,location,()=>{this.toolbar._saveSelection();panel.replaceChildren(this.buildPanel());this.toolbar._togglePopover(panel,location);});
  wrapper.append(button,panel);this.toolbar._preparePopover(panel);return wrapper;
 }
}
