'use strict';
// Project saved item links into the document graph without rewriting Markdown.
class KnowledgeLibraryGraph {
  static async project(store, data) {
    if (!data) return { nodes: [], edges: [] };
    const items = new Map(data.items.filter(item => !item.deleted).map(item => [item.id, item]));
    const pairs = [], needed = new Set();
    for (const item of items.values()) for (const target of item.relatedOut || []) {
      if (target === item.id || !items.has(target)) continue;
      pairs.push([item.id, target]); needed.add(item.id); needed.add(target);
    }
    const byItem = new Map();
    for (const id of needed) {
      const item = items.get(id), files = item.files.filter(file => file.linkType !== 'url' && /\.(md|markdown|mdown|txt)$/i.test(file.path));
      const file = files.find(file => file.id === item.defaultFile) || files[0];
      const path = file ? store.resolveFile(file) : '';
      const exists = !path || !!(await store.io.stat(path).catch(() => null))?.isFile();
      byItem.set(id, {
        id: path ? store.path.resolve(path).replace(/\\/g, '/').toLowerCase() : 'library:' + data.libraryId + ':' + id,
        path, relative: path ? store.path.basename(path) : '文库条目', label: item.title || '',
        kind: path ? 'note' : 'library', exists, tags: [...item.tags], libraryItemId: id,
      });
    }
    const nodes = new Map(), edges = new Map();
    for (const [from, to] of pairs) {
      const source = byItem.get(from), target = byItem.get(to);
      if (source.id === target.id) continue;
      nodes.set(source.id, source); nodes.set(target.id, target);
      edges.set(source.id + '\0' + target.id, { source: source.id, target: target.id, kind: 'library' });
    }
    return { nodes: [...nodes.values()], edges: [...edges.values()] };
  }
  static merge(index, library) {
    if (!library?.edges.length) return index;
    const nodes = new Map(index.nodes.map(node => [node.id, node]));
    for (const node of library.nodes) {
      const old = nodes.get(node.id);
      nodes.set(node.id, old ? { ...old, label: node.label || old.label, libraryItemId: node.libraryItemId } : node);
    }
    const edges = new Map(index.edges.map(edge => [edge.source + '\0' + edge.target, edge]));
    for (const edge of library.edges) edges.set(edge.source + '\0' + edge.target, { ...edges.get(edge.source + '\0' + edge.target), ...edge });
    return { ...index, nodes: [...nodes.values()], edges: [...edges.values()] };
  }
}
module.exports = KnowledgeLibraryGraph;
