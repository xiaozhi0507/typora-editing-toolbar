import {TextSelection,NodeSelection,AllSelection} from 'prosemirror-state';
import {toggleMark,setBlockType,wrapIn,lift} from 'prosemirror-commands';
import {wrapInList,liftListItem,sinkListItem} from 'prosemirror-schema-list';
import {undo,redo,closeHistory} from 'prosemirror-history';
import {cleanStyle} from './annotation-live-formats.js';
import {safeLink} from './annotation-note-structure.js';
import {imageLayout,floatingWrap} from './annotation-image-layout.js';

import {alignNoteCells,runNoteTableAction} from './annotation-tables.js';
export const actionMarks={bold:'strong',italic:'em',underline:'underline',strikethrough:'strike',highlight:'highlight',superscript:'superscript',subscript:'subscript',code:'code'};
export function createNoteActions(view,schema,options,io){
 const notice=text=>options.notice?.(text);
 const selectedBlocks=()=>{const {from,to,empty,$from}=view.state.selection,result=[];if(empty&&$from.parent.isTextblock)return[{node:$from.parent,pos:$from.before()}];view.state.doc.nodesBetween(from,to,(node,pos)=>{if(node.isTextblock){if(pos+1<to&&pos+node.nodeSize-1>=from)result.push({node,pos});return false;}});return result;};
 const dispatch=tr=>view.dispatch(tr.scrollIntoView());
 const command=fn=>fn(view.state,dispatch,view);
 const nextID=(kind,prefix)=>{const used=new Set();view.state.doc.descendants(n=>{if(kind==='foot')n.type===schema.nodes.note_footnote&&used.add(n.attrs.id);else for(const m of n.marks)if(m.attrs.ref)used.add(m.attrs.ref);});let i=1;while(used.has(prefix+i))i++;return prefix+i;};
 function styleRange(change){const {from,to,empty,$from}=view.state.selection;if(empty){const old=schema.marks.text_style.isInSet(view.state.storedMarks||$from.marks())?.attrs||{},a=cleanStyle(change({...old}));let tr=view.state.tr.removeStoredMark(schema.marks.text_style);if(Object.values(a).some(x=>x!==null))tr.addStoredMark(schema.marks.text_style.create(a));dispatch(tr);return;}
  let tr=view.state.tr;view.state.doc.nodesBetween(from,to,(node,pos)=>{if(!(node.isText||node.type===schema.nodes.math_inline))return;const a=Math.max(from,pos),b=Math.min(to,pos+node.nodeSize);if(a>=b)return;const old=schema.marks.text_style.isInSet(node.marks)?.attrs||{},attrs=cleanStyle(change({...old}));tr.removeMark(a,b,schema.marks.text_style);if(Object.values(attrs).some(x=>x!==null))tr.addMark(a,b,schema.marks.text_style.create(attrs));});dispatch(tr);
 }
 function insertBlocks(nodes){let tr=view.state.tr.replaceSelectionWith(nodes[0]);for(const n of nodes.slice(1))tr.replaceSelectionWith(n);dispatch(tr);}
 function blockConvert(type){const blocks=selectedBlocks();if(!blocks.length){insertBlocks([schema.nodes[type].create(null,type==='code_block'?null:undefined)]);return;}
  if(blocks.some(b=>b.node.type.spec.code&&type!=='code_block')){notice('请先选中普通文字，再转换公式。');return;}
  // Only merge siblings; nested list/table cells retain their structure.
  const a=view.state.doc.resolve(blocks[0].pos),last=blocks.at(-1),b=view.state.doc.resolve(last.pos);if(!a.sameParent(b)){notice('请分别处理不同列表或表格单元格中的文字。');return;}
  if(b.index()-a.index()+1!==blocks.length){notice('选区包含其他内容块，请分别转换文字段落。');return;}
  const sel=view.state.selection,first=blocks[0],start=sel.empty?0:Math.max(0,sel.from-first.pos-1),end=sel.empty?last.node.content.size:Math.min(last.node.content.size,sel.to-last.pos-1);
  const parts=blocks.map((b,i)=>b.node.textBetween(i===0?start:0,i===blocks.length-1?end:b.node.content.size,'\n',n=>n.attrs.tex||n.attrs.alt||n.attrs.text||''));
  const text=parts.join('\n\n'),target=type==='code_block'?schema.nodes.code_block.create({params:''},text?schema.text(text):null):schema.nodes.math_block.create({tex:blocks.length>1?'\\begin{gathered}\n'+parts.join(' \\\\\n')+'\n\\end{gathered}':text}),content=[];
  if(start>0)content.push(first.node.copy(first.node.content.cut(0,start)));const targetPos=first.pos+content.reduce((s,n)=>s+n.nodeSize,0);content.push(target);if(end<last.node.content.size)content.push(last.node.copy(last.node.content.cut(end)));
  let tr=view.state.tr.replaceWith(first.pos,last.pos+last.node.nodeSize,content);tr.setSelection(type==='code_block'?TextSelection.create(tr.doc,targetPos+1+text.length):NodeSelection.create(tr.doc,targetPos));dispatch(tr);
 }
 function list(type,task){const s=view.state.selection;let found=null;for(let d=s.$from.depth;d>0;d--){const n=s.$from.node(d);if(n.type===schema.nodes.bullet_list||n.type===schema.nodes.ordered_list){found={node:n,pos:s.$from.before(d)};break;}}
  if(found){if(found.node.type===schema.nodes[type]&&Boolean(found.node.attrs.task)===task){command(liftListItem(schema.nodes.list_item));return;}dispatch(view.state.tr.setNodeMarkup(found.pos,schema.nodes[type],{...found.node.attrs,task}));}
  else if(!command(wrapInList(schema.nodes[type],{task}))){notice('此处不能插入列表。');return;}
  let tr=view.state.tr;view.state.doc.nodesBetween(view.state.selection.from,view.state.selection.to,(n,pos)=>{if(n.type===schema.nodes.list_item)tr.setNodeMarkup(pos,null,{...n.attrs,checked:task?Boolean(n.attrs.checked):null});});dispatch(tr);
 }
 function inlineMath(ascii){const {from,to,empty}=view.state.selection;if(empty){dispatch(view.state.tr.replaceSelectionWith(schema.nodes.math_inline.create({tex:''})));return;}
  let tr=view.state.tr;const runs=[];
  if(ascii)view.state.doc.nodesBetween(from,to,(n,pos)=>{if(n.isText&&!n.marks.some(m=>['code','link'].includes(m.type.name))){for(const e of options.asciiEdits(n.text,Math.max(0,from-pos),Math.min(n.text.length,to-pos)))runs.push({start:pos+e.start,end:pos+e.end,tex:n.text.slice(e.start,e.end),left:e.text.startsWith(' '),right:e.text.endsWith(' '),marks:n.marks});}});
  else view.state.doc.nodesBetween(from,to,(n,pos,parent)=>{if(parent.type.spec.code||!n.isText||n.marks.some(m=>['code','link'].includes(m.type.name)))return;const start=Math.max(from,pos),end=Math.min(to,pos+n.nodeSize),raw=n.text.slice(start-pos,end-pos);if(raw.trim())runs.push({start,end,tex:raw.trim(),left:/^\s/.test(raw),right:/\s$/.test(raw),marks:n.marks});});
  for(const r of runs.reverse()){if(!r.tex)continue;const content=[];if(r.left)content.push(schema.text(' ',r.marks));content.push(schema.nodes.math_inline.create({tex:r.tex},null,r.marks));if(r.right)content.push(schema.text(' ',r.marks));tr.replaceWith(r.start,r.end,content);}dispatch(tr);
 }
 function run(id,value){if(!view.editable)return false;if(id==='undo'||id==='redo')return command(id==='undo'?undo:redo);let boundary=closeHistory(view.state.tr);if(view.state.selection instanceof AllSelection)boundary.setSelection(TextSelection.between(TextSelection.atStart(view.state.doc).$from,TextSelection.atEnd(view.state.doc).$to));view.dispatch(boundary);
  if(id.startsWith('table-'))return runNoteTableAction(view,id);
  if(id.startsWith('align-')&&alignNoteCells(view.state,dispatch,id.slice(6)))return true;
  if(actionMarks[id])return command(toggleMark(schema.marks[actionMarks[id]]));
  if(id==='font-size-increase'||id==='font-size-decrease'){styleRange(a=>({...a,size:Math.max(.6,Math.min(3,(a.size||1)+(id==='font-size-increase'?.1:-.1)))}));return true;}
  if(id==='font-color'||id==='bg-color'){styleRange(a=>({...a,[id==='font-color'?'color':'background']:value}));return true;}
  if(id==='clear-format'){const s=view.state.selection;dispatch(s.empty?view.state.tr.setStoredMarks([]):view.state.tr.removeMark(s.from,s.to));return true;}
  if(/^h[1-6]$/.test(id)||id==='paragraph'){const type=id==='paragraph'?schema.nodes.paragraph:schema.nodes.heading,level=+id[1];let tr=view.state.tr;for(const {node,pos} of selectedBlocks())if(['paragraph','heading'].includes(node.type.name))tr.setNodeMarkup(pos,type,{...node.attrs,...(id==='paragraph'?{}:{level})});if(!tr.docChanged)return false;dispatch(tr);return true;}
  if(id.startsWith('align-')||id==='indent'||id==='outdent'){if((id==='indent'||id==='outdent')&&view.state.selection.$from.path.some(n=>n?.type===schema.nodes.list_item))return command(id==='indent'?sinkListItem(schema.nodes.list_item):liftListItem(schema.nodes.list_item));let tr=view.state.tr;for(const {node,pos} of selectedBlocks())if(['paragraph','heading'].includes(node.type.name))tr.setNodeMarkup(pos,null,{...node.attrs,...(id.startsWith('align-')?{alignment:id.slice(6)}:{indent:Math.max(0,Math.min(12,(node.attrs.indent||0)+(id==='indent'?1:-1)))})});dispatch(tr);return true;}
  if(['ordered-list','unordered-list','task-list'].includes(id)){list(id==='ordered-list'?'ordered_list':'bullet_list',id==='task-list');return true;}
  if(id==='blockquote'){const inside=view.state.selection.$from.path.some(n=>n?.type===schema.nodes.blockquote);return command(inside?lift:wrapIn(schema.nodes.blockquote));}
  if(id==='codeblock'||id==='math-block'){blockConvert(id==='codeblock'?'code_block':'math_block');return true;}
  if(id==='inline-math'||id==='inline-math-ascii'){inlineMath(id==='inline-math-ascii');return true;}
  if(id.startsWith('warning-')&&id!=='warning-block'){const type=id.slice(8);const sel=view.state.selection;if(!sel.empty)return command(wrapIn(schema.nodes.note_card,{variant:type}));insertBlocks([schema.nodes.note_card.create({variant:type},schema.nodes.paragraph.create())]);return true;}
  if(id.startsWith('template-')&&id!=='template-library'){const t=options.template(id);if(t)insertBlocks([schema.nodes.note_card.create({variant:t.variant},io.parse(t.markdown.replace(/==([^=]+)==/g,'<mark>$1</mark>')).content)]);return Boolean(t);}
  if(id==='hr'){insertBlocks([schema.nodes.horizontal_rule.create()]);return true;}
  if(id==='table'){const rows=Math.max(1,Math.min(30,+value?.rows||3)),cols=Math.max(1,Math.min(12,+value?.cols||3));insertBlocks([schema.nodes.table.create(null,Array.from({length:rows},(_,r)=>schema.nodes.table_row.create(null,Array.from({length:cols},()=>schema.nodes[r===0?'table_header':'table_cell'].create(null,schema.nodes.paragraph.create())))))]);return true;}
  if(id==='link'||id==='link-reference'){if(!safeLink(value?.href)){notice('请输入有效的 https://、http:// 或 mailto: 地址。');return false;}const ref=id==='link-reference'?nextID('ref','ref'):null;const attrs={href:value.href,title:null,ref},s=view.state.selection;let tr=view.state.tr;if(s.empty)tr.insertText(value.label||value.href).addMark(s.from,s.from+(value.label||value.href).length,schema.marks.link.create(attrs));else tr.addMark(s.from,s.to,schema.marks.link.create(attrs));dispatch(tr);return true;}
  if(id==='footnote'){const id=value?.id||nextID('foot',''),node=schema.nodes.note_footnote.create({id,text:value?.text||''});let tr=view.state.tr;if(value?.pos!=null)tr.setNodeMarkup(value.pos,null,node.attrs);else tr.insert(view.state.selection.to,node);dispatch(tr);return true;}
  if(id==='emoji'){dispatch(view.state.tr.insertText(value));return true;}
  if(id==='image-size'||id==='image-wrap'||id==='image-side'){const s=view.state.selection;if(!view.editable||!(s instanceof NodeSelection)||s.node.type!==schema.nodes.image)return false;const dom=view.nodeDOM(s.from),displayed=Number(dom?.dataset.imageWidth)||dom?.getBoundingClientRect().width||200,attrs={...s.node.attrs};
   if(id==='image-size')attrs.width=value==='auto'?null:Math.max(32,Math.min(12000,Math.round(displayed*value)));
   else{Object.assign(attrs,imageLayout({...attrs,[id==='image-wrap'?'wrap':'side']:value}));if(id==='image-wrap'&&floatingWrap(attrs.wrap)&&!attrs.width)attrs.width=Math.max(32,Math.round(Math.min(displayed,(view.dom.clientWidth-52)*.48)));}
   let tr=closeHistory(view.state.tr).setNodeMarkup(s.from,null,attrs);tr.setSelection(NodeSelection.create(tr.doc,s.from));dispatch(tr);view.dispatch(closeHistory(view.state.tr));return true;}
  if(id==='note-video-insert'){insertBlocks([schema.nodes.note_video.create({src:value})]);return true;}
  if(['annotation','fullscreen','toolbar-settings'].includes(id)){options.external?.(id);return true;}
  return false;
 }
 return {run,selectedBlocks,selectedText:()=>view.state.doc.textBetween(view.state.selection.from,view.state.selection.to,'\n')};
}
