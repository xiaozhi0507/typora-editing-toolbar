'use strict';
// Resolve a project environment without executing activation scripts or changing global settings.
function projectDirectory(requireNode, projects, file) {
  const path=requireNode('path');
  const contains=(root,target)=>{const relative=path.relative(root,target);return relative===''||(!relative.startsWith('..'+path.sep)&&relative!=='..'&&!path.isAbsolute(relative));};
  const candidates=(projects?.items||[]).filter(p=>p.root&&path.isAbsolute(p.root)&&file&&contains(p.root,file)).sort((a,b)=>b.root.length-a.root.length);
  const project=candidates[0]||projects?.active?.();
  if(project){if(!project.trusted)throw Error('请先在项目设置中信任此文件夹');return project.root;}
  return file&&path.isAbsolute(file)?path.dirname(file):null;
}
async function pythonEnvironment(requireNode,cwd,override) {
  const fs=requireNode('fs'),path=requireNode('path'),env=requireNode('process').env;
  const exists=async p=>{try{return (await fs.promises.stat(p)).isFile();}catch{return false;}};
  const describe=async exe=>{
    const dir=path.dirname(exe),root=path.basename(dir).toLowerCase()==='scripts'?path.dirname(dir):dir;
    const virtual=await exists(path.join(root,'pyvenv.cfg'));
    let conda=false;try{conda=(await fs.promises.stat(path.join(root,'conda-meta'))).isDirectory();}catch{}
    return {exe,root,kind:virtual?'venv':conda?'conda':'system',label:virtual||conda?'Python · '+path.basename(root):'Python',paths:conda?[root,path.join(root,'Scripts'),path.join(root,'Library','bin')]:[dir]};
  };
  if(override){if(!path.isAbsolute(override)||!/^python\.exe$/i.test(path.basename(override))||!await exists(override))throw Error('请选择有效的 python.exe，或恢复自动检测');return describe(override);}
  for(const name of ['.venv','venv','.env','env','.conda']){
    for(const exe of [path.join(cwd,name,'Scripts','python.exe'),path.join(cwd,name,'python.exe')])if(await exists(exe))return describe(exe);
  }
  // Inspect PATH directly: no subprocess, no Windows Store alias launches, no network wait.
  const pathKey=Object.keys(env).find(k=>k.toLowerCase()==='path');
  for(const dir of String(env[pathKey]||'').split(';').map(s=>s.trim().replace(/^"|"$/g,''))){
    if(!path.isAbsolute(dir)||/[/\\]Microsoft[/\\]WindowsApps(?:[/\\]|$)/i.test(dir))continue;
    const exe=path.join(dir,'python.exe');if(await exists(exe))return describe(exe);
  }
  return null;
}
function environmentVariables(base,python) {
  const env={...base};if(!python)return env;
  const pathKey=Object.keys(env).find(k=>k.toLowerCase()==='path'),original=pathKey?env[pathKey]:'';
  for(const key of Object.keys(env))if(key.toLowerCase()==='path'||key.toLowerCase()==='pythonhome'||key.toLowerCase()==='virtual_env'||key.toLowerCase()==='conda_prefix')delete env[key];
  env.Path=[...python.paths,original].filter(Boolean).join(';');
  if(python.kind==='venv')env.VIRTUAL_ENV=python.root;
  if(python.kind==='conda')env.CONDA_PREFIX=python.root;
  return env;
}
module.exports={projectDirectory,pythonEnvironment,environmentVariables};
