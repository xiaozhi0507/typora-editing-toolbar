// A bounded disk-derived preview, never an authority for file existence or edits.
// Keep only graph metadata: Markdown bodies and unsaved overlays are not stored.
const KEY='et-research-graph-cache-v1',MAX_LENGTH=1000000,MAX_AGE=7*86400000;
const rootKey=root=>String(root).replace(/\\/g,'/').replace(/\/+$/,'').toLowerCase();
export class ResearchGraphCache {
 constructor(storage){this.storage=storage;}
 entries(){try{const text=this.storage.getItem(KEY);if(!text||text.length>MAX_LENGTH)return[];const data=JSON.parse(text);return data.version===1&&Array.isArray(data.entries)?data.entries.slice(0,3).filter(e=>e&&Number.isFinite(e.savedAt)&&Date.now()-e.savedAt>=0&&Date.now()-e.savedAt<MAX_AGE):[];}catch{return[];}}
 valid(index,root){
  if(!index||typeof index.root!=='string'||rootKey(index.root)!==rootKey(root)||!Array.isArray(index.nodes)||index.nodes.length>30000||!Array.isArray(index.edges)||index.edges.length>80000||!Number.isInteger(index.notes)||index.notes<0||!Array.isArray(index.warnings)||index.warnings.some(w=>typeof w!=='string'))return false;
  const ids=new Set();for(const n of index.nodes){if(!n||typeof n.id!=='string'||ids.has(n.id)||typeof n.label!=='string'||typeof n.relative!=='string'||!['note','attachment','tag'].includes(n.kind)||typeof n.exists!=='boolean'||(n.kind!=='tag'&&typeof n.path!=='string')||!Array.isArray(n.tags)||n.tags.some(t=>typeof t!=='string'))return false;ids.add(n.id);}
  return index.edges.every(e=>e&&ids.has(e.source)&&ids.has(e.target));
 }
 load(root){const entry=this.entries().find(e=>rootKey(e.index?.root)===rootKey(root));return entry&&this.valid(entry.index,root)?entry.index:null;}
 save(index){try{
  const compact={root:index.root,nodes:index.nodes.map(n=>({id:n.id,path:n.path,relative:n.relative,label:n.label,kind:n.kind,exists:n.exists,tags:n.tags||[]})),edges:index.edges.map(e=>({source:e.source,target:e.target})),notes:index.notes,warnings:index.warnings,limited:!!index.limited};
  if(!this.valid(compact,index.root))return false;
  const entry={savedAt:Date.now(),index:compact},entries=[entry,...this.entries().filter(e=>rootKey(e.index?.root)!==rootKey(index.root))].slice(0,3);let text;
  while(entries.length){text=JSON.stringify({version:1,entries});if(text.length<=MAX_LENGTH)break;entries.pop();}
  if(!entries.length)return false;this.storage.setItem(KEY,text);return true;
 }catch{return false;}}
}
