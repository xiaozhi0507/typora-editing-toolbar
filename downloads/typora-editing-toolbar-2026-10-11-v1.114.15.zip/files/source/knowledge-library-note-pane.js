// Dock the existing editor without reparenting its iframe or creating a second writer.
class KnowledgeLibraryNotePane {
  constructor(host) {
    this.host = host; this.generation = 0;
    const style = document.createElement('style');
    style.textContent = `
      #et-document-note-panel.et-library-note-docked{position:fixed!important;inset:auto!important;left:var(--library-note-x)!important;top:var(--library-note-y)!important;width:var(--library-note-width)!important;height:var(--library-note-height)!important;z-index:var(--library-note-z,100091)!important;border:0!important;border-radius:0!important;box-shadow:none!important;padding:0!important;gap:0!important;background:var(--bg-color)!important;color:var(--text-color)!important;}
      #et-document-note-panel.et-library-note-docked>:not(.et-panel-scroll-body):not(footer){display:none!important;}
      #et-document-note-panel.et-library-note-docked>.et-panel-scroll-body{gap:0;overflow:hidden;}
      #et-document-note-panel.et-library-note-docked>.et-panel-scroll-body>:not(.et-note-work){display:none!important;}
      #et-document-note-panel.et-library-note-docked .et-note-work{display:flex!important;flex:1!important;min-height:0!important;padding:0!important;gap:0!important;}
      #et-document-note-panel.et-library-note-docked .et-note-work>:not(iframe){display:none!important;}
      #et-document-note-panel.et-library-note-docked .et-note-editor-frame{width:100%!important;min-height:0!important;border:0!important;border-radius:0!important;flex:1!important;}
      #et-document-note-panel.et-library-note-docked footer{padding:3px 10px!important;min-height:22px;}
    `;
    document.head.append(style);
    this.observer = new ResizeObserver(() => this.schedule());
    window.addEventListener('resize', () => this.schedule());
  }
  schedule(surface) {
    if(surface)this.pendingSurface=surface;
    if(this.layoutFrame)return;
    this.layoutFrame=requestAnimationFrame(()=>{
      this.layoutFrame=0;const next=this.pendingSurface;this.pendingSurface=null;this.layout(next);
    });
  }
  flush() {
    if (!this.manager) return true;
    this.manager._flushEditor();
    if (!this.manager._save()) {
      this.failed = true;
      this.host.ui?.error('笔记尚未保存，请重试后再离开。');
      return false;
    }
    if (this.failed) { this.failed=false; this.host.ui?.noteSaved(); }
    return true;
  }
  close() {
    if (!this.flush()) return false;
    this.generation++;
    cancelAnimationFrame(this.layoutFrame);this.layoutFrame=0;this.pendingSurface=null;
    this.observer.disconnect(); this.surface = null;
    if (this.manager) {
      const manager = this.manager; this.manager = null;
      manager.close();
      manager.panel.classList.remove('et-library-note-docked');
      for (const key of this.overrides || []) manager.panel.style.removeProperty(key);
      manager.panel.style.visibility = '';
      manager._themeEditor();
    }
    return true;
  }
  async open(file, id, create) {
    if (!this.close()) throw Error('笔记尚未保存');
    const generation = this.generation, host = this.host;
    if (file.linkType === 'url' || !/\.(md|markdown|mdown|txt)$/i.test(file.path)) throw Error('请先关联一个 Markdown 文件，用于保存文档笔记。');
    const manager = host.toolbar.documentNotes;
    if (!manager) throw Error('笔记模块尚未加载，请稍后再试。');
    manager._flushEditor();
    if (manager.ctx && !manager._save()) throw Error('当前笔记尚未保存，请保存后再打开。');
    await host.openFile(file);
    if (generation !== this.generation || !host.isOpen) return null;
    // File.bundle can update before Typora finishes loading the editor.
    for (let n = 0; n < 100 && manager._loading(); n++) await new Promise(resolve => setTimeout(resolve, 50));
    if (generation !== this.generation || !host.isOpen) return null;
    manager._switchDocument();
    const target = host.store.resolveFile(file);
    if (manager.ctx?.key?.toLowerCase() !== target.toLowerCase()) throw Error('文档笔记尚未就绪，请稍后重试。');
    if (manager.ctx.readonly) throw Error(manager.ctx.error || '笔记暂时无法读取。');
    if (id && !manager.ctx.notes.some(note => note.id === id)) throw Error('这篇笔记已不存在，请返回刷新列表。');
    const virgin = manager.ctx.virgin;
    manager.open();
    if (create && !virgin) manager.newNote();
    if (id) manager.selectNote(id);
    const note = manager._selected();
    if (!note) { manager.close(); throw Error('没有可打开的笔记。'); }
    this.manager = manager;
    this.focusPending = true;
    manager.panel.classList.add('et-library-note-docked');
    manager.toolbar.panelWorkspace?.layout();
    manager.panel.style.visibility = 'hidden';
    return { id: note.id, title: note.title || '' };
  }
  layout(surface) {
    if (surface && surface !== this.surface) {
      this.observer.disconnect(); this.surface = surface;
      this.observer.observe(surface); this.observer.observe(this.host.frame);
      if (!this.libraryObserver) {
        this.libraryObserver = new MutationObserver(() => this.schedule());
        this.libraryObserver.observe(surface.ownerDocument.body, {subtree:true,attributes:true,attributeFilter:['hidden']});
        surface.ownerDocument.addEventListener('scroll', () => this.schedule(), true);
      }
    }
    const manager = this.manager;
    if (!manager) return;
    let rect = this.surface?.isConnected && this.surface.getBoundingClientRect();
    const doc = this.host.frame.contentDocument;
    if (rect) {
      const bounds=doc.querySelector('[data-library]').getBoundingClientRect();
      const left=Math.max(rect.left,bounds.left),top=Math.max(rect.top,bounds.top);
      rect={left,top,width:Math.min(rect.right,bounds.right)-left,height:Math.min(rect.bottom,bounds.bottom)-top};
    }
    const blocked = ['[data-shade]', '[data-menu]', '[data-import-shade]'].some(selector => { const el=doc.querySelector(selector);return el&&!el.hidden; });
    const visible = this.host.isOpen && !blocked && rect && rect.width > 0 && rect.height > 0;
    manager.panel.style.visibility = visible ? '' : 'hidden';
    if (!visible) return;
    const outer = this.host.frame.getBoundingClientRect();
    const css = this.surface.ownerDocument.defaultView.getComputedStyle(this.surface);
    const props = {
      '--library-note-z': String((Number(this.host.overlay.style.zIndex)||100090)+1),
      '--library-note-x': (outer.left + rect.left) + 'px', '--library-note-y': (outer.top + rect.top) + 'px',
      '--library-note-width': rect.width + 'px', '--library-note-height': rect.height + 'px',
      '--bg-color': css.backgroundColor, '--text-color': css.color,
      '--et-text': css.color, '--et-text-dim': css.getPropertyValue('--kb-muted'),
      '--et-border': css.getPropertyValue('--kb-line'), '--et-hover': css.getPropertyValue('--kb-hover'),
      '--et-surface-strong': css.backgroundColor
    };
    this.overrides = Object.keys(props);
    let themeChanged=false;
    for (const [key, value] of Object.entries(props)) {
      if(manager.panel.style.getPropertyValue(key)===value)continue;
      manager.panel.style.setProperty(key,value);
      if(!key.startsWith('--library-note-'))themeChanged=true;
    }
    // Moving/resizing a library is geometry-only; don't restyle the live editor
    // on every frame when its theme has not changed.
    if(themeChanged||this.focusPending)manager._themeEditor();
    if (this.focusPending) { this.focusPending=false; manager.editor?.focus(); }
  }
}
