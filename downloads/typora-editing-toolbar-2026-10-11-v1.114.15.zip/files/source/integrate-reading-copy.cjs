const fs=require('node:fs'),path=require('node:path');
module.exports=code=>{
 const replace=(a,b)=>{if(!code.includes(a))throw Error('Missing reading/copy integration: '+a.slice(0,90));code=code.replace(a,b);};
 const icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5C9.5 3.2 5.5 3 2.5 4v15c3-1 7-0.8 9.5 1 2.5-1.8 6.5-2 9.5-1V4C18.5 3 14.5 3.2 12 5Z"/><path d="M12 5v15"/></svg>';
 replace('const BUTTON_DEFINITIONS = {',`const BUTTON_DEFINITIONS = {\n"reading-mode":{icon:${JSON.stringify(icon)},title:'阅读模式'},`);
 replace('"insert-menu","annotation","document-note"','"insert-menu","reading-mode","annotation","document-note"');
 replace('"fullscreen","floating-toolbar-toggle","theme-palette"','"fullscreen","reading-mode","floating-toolbar-toggle","theme-palette"');
 code=code.replaceAll('controls:["undo","redo","annotation"','controls:["undo","redo","reading-mode","annotation"');
 code=code.replaceAll('buttons:["undo","redo","annotation"','buttons:["undo","redo","reading-mode","annotation"');
 code=code.replaceAll('themePaletteRevision:1,','themePaletteRevision:1,readingModeRevision:1,');
 replace('        const top = topLayout === "classic"',`        if(!input.readingModeRevision){for(const ids of [compact.order,classic.buttons])if(!ids.includes('reading-mode')){let at=ids.indexOf('floating-toolbar-toggle');if(at<0)at=ids.indexOf('annotation');if(at<0)at=ids.indexOf('toolbar-settings');ids.splice(at<0?ids.length:at,0,'reading-mode');}}
        const top = topLayout === "classic"`);
 replace('        if (action === "annotation")','        if (action === "reading-mode") {this.readingMode?.toggle();return;}\n        if (action === "annotation")');
 replace('    _mountToolbarUI() {','    _mountToolbarUI() {\n        this.readingMode=new EditingToolbarReadingMode(this);\n        this.imageMarkup=new EditingToolbarImageMarkup(this);\n        this.previewCopy=new EditingToolbarPreviewCopy(this);');
 replace('            if (id==="floating-toolbar-toggle") return;','            if (id==="reading-mode") {this.readingMode?.updateButton(button);return;}\n            if (id==="floating-toolbar-toggle") return;');
 replace('        if (id === "floating-toolbar-toggle") {','        if (id === "reading-mode") this.readingMode?.updateButton(button);\n        if (id === "floating-toolbar-toggle") {');
 replace('            const id=button.dataset.action;', '            const id=button.dataset.action;\n            if(this.readingMode?.syncActionButton(button))return;');
 replace('            button.title = item.title || item.label;', '            button.title = item.title || item.label;\n            button.dataset.action=item.action||item.id;button.dataset.baseTitle=button.title;this.readingMode?.syncActionButton(button);');
 const pos=code.lastIndexOf('(function () {');if(pos<0)throw Error('Missing boot');
 return code.slice(0,pos)+['body-reading-mode.js','image-markup-model.js','image-markup.js','preview-copy.js'].map(n=>fs.readFileSync(path.join(__dirname,n),'utf8')).join('\n')+'\n'+code.slice(pos);
};
