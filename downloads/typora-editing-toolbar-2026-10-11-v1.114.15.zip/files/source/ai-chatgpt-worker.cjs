'use strict';
const {ChatGPTService,publicError}=require('./ai-chatgpt-service.cjs');
const service=new ChatGPTService(process.argv[2]),controllers=new Map();
const send=data=>process.stdout.write(JSON.stringify(data)+'\n');
let buffer='';process.stdin.setEncoding('utf8');process.stdin.on('data',chunk=>{
  buffer+=chunk;if(Buffer.byteLength(buffer)>40*1024*1024)process.exit(1);let at;
  while((at=buffer.indexOf('\n'))>=0){const line=buffer.slice(0,at);buffer=buffer.slice(at+1);let msg;try{msg=JSON.parse(line);}catch{continue;}
    if(msg.method==='cancel'){controllers.get(msg.id)?.abort();continue;}
    const controller=new AbortController();controllers.set(msg.id,controller);
    const notify=(event,data)=>send({id:msg.id,event,data});
    let timer;const updates=new Map(),flush=()=>{clearTimeout(timer);timer=null;for(const {event,data}of updates.values())notify(event,data);updates.clear();};
    const stream=(event,data)=>{if(event==='execution'){flush();notify(event,data);return;}updates.set(event,{event,data});if(!timer)timer=setTimeout(flush,80);};
    Promise.resolve().then(()=>{
      if(msg.method==='list')return service.list();
      if(msg.method==='signIn')return service.signIn(msg.account,{signal:controller.signal,onAuthorize:url=>notify('authorize',url)});
      if(msg.method==='models')return service.models(msg.account);
      if(msg.method==='usage')return service.usage(msg.account);
      if(msg.method==='disconnect')return service.disconnect(msg.account);
      if(msg.method==='request')return service.request(msg.profile,msg.messages,{signal:controller.signal,onText:text=>stream('text',text),onReasoning:(text,kind)=>stream('reasoning',{text,kind}),onEvent:event=>stream('execution',event)});
      throw Error('不支持的 ChatGPT 操作');
    }).then(result=>{flush();send({id:msg.id,result});},e=>{flush();send({id:msg.id,error:publicError(e)});}).finally(()=>controllers.delete(msg.id));
  }
});process.stdin.on('end',()=>{for(const c of controllers.values())c.abort();setTimeout(()=>process.exit(),200);});
