'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),http=require('http'),{EventEmitter}=require('events'),fs=require('fs'),path=require('path');
const Network=require('./ai-plugin-network.cjs'),Plugins=require('./ai-plugins.cjs');
function nodeReq(env={},platform='win32',Agent){return id=>id==='process'?{platform,env,versions:{node:'24.15.0'}}:id==='https'&&Agent?{Agent}:require(id);}
test('system proxy resolution receives only official origin and caches routing, never credentials',async()=>{
 let calls=0;const seen=[],network=new Network(nodeReq({},'win32',class{constructor(o){this.options=o;}}),{resolveProxy:async origin=>{calls++;seen.push(origin);return 'http://127.0.0.1:12345';}});
 const agent=await network.agent('https://api.github.com/user?private=redacted');await network.agent('https://api.github.com/repos');
 assert.deepEqual(seen,['https://api.github.com']);assert.equal(calls,1);assert.equal(agent.options.proxyEnv.HTTPS_PROXY,'http://127.0.0.1:12345/');
});
test('explicit proxy and bypass settings take priority without reading system configuration',async()=>{
 const network=new Network(nodeReq({https_proxy:'http://proxy.test:8080',HTTPS_PROXY:'http://other.test:8080',no_proxy:'api.github.com'},'win32',class{constructor(o){this.options=o;}}),{resolveProxy:async()=>{throw Error('unexpected system lookup');}});
 const agent=await network.agent('https://api.github.com/user');assert.equal(agent.options.proxyEnv.HTTPS_PROXY,'http://proxy.test:8080/');assert.equal(agent.options.proxyEnv.NO_PROXY,'api.github.com');assert.equal(agent.options.keepAlive,false);
});
test('direct routing stays direct and invalid proxy schemes never silently fall back',async()=>{
 const network=new Network(nodeReq({},'win32',class{constructor(o){this.options=o;}}),{resolveProxy:async()=>null});assert.deepEqual((await network.agent('https://api.github.com')).options.proxyEnv,{});
 await assert.rejects(new Network(nodeReq({HTTPS_PROXY:'socks5://secret:password@proxy.test:1080'})).agent('https://github.com'),e=>/HTTP\(S\)/.test(e.message)&&!e.message.includes('password'));
 await assert.rejects(new Network(nodeReq(),{resolveProxy:async()=>{throw Error('proxy unavailable');}}).agent('https://github.com'),/proxy unavailable/);
 assert.equal(Network.supported('22.21.0'),true);assert.equal(Network.supported('24.4.0'),false);
});
test('Windows proxy helper hides its window, limits runtime and passes origin through stdin',async()=>{
 let captured,input;const child=new EventEmitter();child.stdin=new EventEmitter();child.stdin.end=v=>input=v;
 const network=new Network(id=>id==='child_process'?{execFile:(file,args,options,callback)=>{captured={file,args,options};queueMicrotask(()=>callback(null,'http://127.0.0.1:12345'));return child;}}:require(id));
 assert.equal(await network.systemProxy('https://github.com'),'http://127.0.0.1:12345');assert.equal(input,'https://github.com');assert.equal(captured.options.windowsHide,true);assert.equal(captured.options.timeout,8000);assert.ok(!captured.args.join(' ').includes('https://github.com'));
});
test('cancelling system proxy lookup terminates the owned helper',async()=>{
 let killed=false;const child=new EventEmitter();child.stdin=new EventEmitter();child.stdin.end=()=>{};child.kill=()=>killed=true;
 const network=new Network(id=>id==='child_process'?{execFile:()=>child}:require(id)),controller=new AbortController();
 const pending=network.systemProxy('https://github.com',controller.signal);controller.abort();await assert.rejects(pending,{name:'AbortError'});assert.equal(killed,true);
});
async function localProxy(t,handler){const server=http.createServer(),sockets=new Set();server.on('connection',s=>{sockets.add(s);s.on('close',()=>sockets.delete(s));});server.on('connect',handler);await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(async()=>{for(const s of sockets)s.destroy();await new Promise(r=>server.close(r));});return {url:'http://127.0.0.1:'+server.address().port,sockets};}
test('actual HTTPS request uses CONNECT and absolute timeout covers a stalled proxy handshake',async t=>{
 let seen;const proxy=await localProxy(t,(request,socket)=>{seen={url:request.url,headers:request.headers};socket.write('HTTP/1.1 200 Connection Established\r\n\r\n');});
 const r=nodeReq(),store=new Plugins(r,__dirname,{protect:async s=>s});store.network=new Network(r,{resolveProxy:async()=>proxy.url});
 await assert.rejects(store.request('https://github.com/login/oauth/access_token',{form:{code:'never-in-proxy-headers',client_secret:'never-in-proxy-headers'},timeout:500}),{code:'PLUGIN_NETWORK_TIMEOUT'});
 assert.equal(seen.url,'github.com:443');assert.ok(!JSON.stringify(seen).includes('never-in-proxy-headers'));assert.equal(seen.headers.authorization,undefined);
});
test('cancellation aborts proxy connections promptly instead of waiting for OAuth deadline',async t=>{
 let connected;const ready=new Promise(r=>connected=r),proxy=await localProxy(t,()=>connected());
 const r=nodeReq(),store=new Plugins(r,__dirname,{protect:async s=>s});store.network=new Network(r,{resolveProxy:async()=>proxy.url});
 const controller=new AbortController(),pending=store.request('https://api.github.com/user',{signal:controller.signal,timeout:30000});await ready;controller.abort();await assert.rejects(pending,{name:'AbortError'});
});
test('OAuth progress distinguishes callback, exchange, verification and persistence',async t=>{
 const base=path.join(process.env.USERPROFILE,'Downloads','codex-temp','plugin-network-tests');fs.mkdirSync(base,{recursive:true});const root=fs.mkdtempSync(path.join(base,'case-'));t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
 const stages=[],store=new Plugins(require,root,{protect:async(v,d)=>d?Buffer.from(v,'base64').toString():Buffer.from(v).toString('base64'),transport:async(url,o)=>{
  if(url.includes('/access_token')){assert.equal(stages.at(-1),'exchanging');assert.equal(o.form.progress,undefined);return {access_token:'test-access'};}assert.equal(stages.at(-1),'verifying');return {login:'test-reader',id:7};
 }});
 await store.configureGitHub({client_id:'test-client',client_secret:'test-secret'});
 const open=url=>new Promise((resolve,reject)=>{const auth=new URL(url);http.get(auth.searchParams.get('redirect_uri')+'?state='+auth.searchParams.get('state')+'&code=test-code',response=>{response.resume();response.on('end',resolve);}).on('error',reject);});
 await store.connectGitHubOAuth(open,{onProgress:s=>stages.push(s)});assert.ok(stages.includes('exchanging'));assert.ok(stages.indexOf('verifying')>stages.indexOf('exchanging'));assert.equal(stages.at(-1),'saving');
 store.transport=async()=>{throw Object.assign(Error('network timeout'),{code:'PLUGIN_NETWORK_TIMEOUT'});};await assert.rejects(store.connectGitHubOAuth(open),e=>e.stage==='exchanging'&&/授权已收到.*换取登录令牌/.test(e.message));
 assert.equal(store.accounts('github').length,1);
});
