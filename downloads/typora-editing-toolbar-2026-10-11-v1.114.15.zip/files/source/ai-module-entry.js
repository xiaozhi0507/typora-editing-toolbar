// Executed inside the module's activation scope, after all AI classes are declared.
const toolbar=host.toolbar;
if(toolbar.aiAssistant)throw Error('AI 阅读助手已加载');
for(let attempt=0;!toolbar.documentTabs?.list&&attempt<100;attempt++)await new Promise(resolve=>host.delay(resolve,100));
if(!toolbar.documentTabs?.list)throw Error('项目侧栏尚未就绪，请稍后重试');
const workspace=new EditingToolbarAIWorkspace(host);
api.register(async()=>{if(!workspace.disposed){await workspace.stop();scope.close();workspace.dispose();}});
api.registerBeforeStop?.(()=>workspace.prepare());
host.bindPanel(EditingToolbarAI);
const ai=new EditingToolbarAI(toolbar);ai.moduleRoot=host.directory;ai.keys=host.sessionKeys();toolbar.aiAssistant=ai;
// Keep the current window on its own conversation when toggling or updating the module.
const mount=ai.mount;
ai.mount=function(){
 mount.call(this);const saved=host.readSession?.();if(!saved||this.conversations.key(saved.file)!==this.conversations.key(this.file()))return;
 try{const store=new ETAISessionStore(reqnode,saved.directory),record=store.read(saved.id);if(record.deleted)return;this.conversations.owners.set(record,store);this.conversations.restore(record,store.context(record));host.writeSession(null);}catch(e){this.notice('上次会话暂未恢复：'+e.message,true);}
};
const tracked=new Set();
for(const owner of [ai,ai.webChat,ai.selectionUI.temporary,ai.paperTranslation]){
 for(const key of Object.getOwnPropertyNames(Object.getPrototypeOf(owner))){
  const descriptor=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(owner),key),fn=descriptor?.value;
  if(fn?.constructor?.name!=='AsyncFunction')continue;
  owner[key]=function(...args){if(ai.moduleClosing)return Promise.resolve();const job=fn.apply(this,args);tracked.add(job);job.then(()=>tracked.delete(job),()=>tracked.delete(job));return job;};
 }
}
host.setEnabled(true);
api.registerCommand({id:'open-assistant',name:'打开 AI 阅读助手',callback:()=>ai.open()});
return async()=>{
 ai.moduleClosing=true;ai.queue?.suspend('AI 模块已停用，排队已暂停');
 scope.abort();ai.controller?.abort();ai.selectionUI?.temporary?.controller?.abort();
 ai.chatgptUI?.shutdown();ai.webChat?.browser?.destroy();
 await Promise.race([Promise.allSettled([...tracked]),new Promise(resolve=>host.delay(resolve,3000))]);
 for(const turn of ai.turns||[]){if(turn.status==='running'){turn.status='stopped';turn.detail='AI 模块已停用';}EditingToolbarAITiming.finish(turn);}
 const draft=ai.panel?ai.composerUI.draft.snapshot():null;
 const hasDraft=!!(draft&&(draft.text||draft.folded||draft.quotes?.length||draft.images?.length||draft.skills?.selected?.length||ai.attachments.selected.length||ai.codeUI.targets?.length||ai.queue.items.length));
 const saved=ai.conversations?.flush(hasDraft);
 if(saved&&ai.conversations.record)host.writeSession({file:ai.conversations.record.file,id:ai.conversations.record.id,directory:ai.conversations.store.directory});
 try{ai.close();}catch{}
 try{ai.richComposer?.view?.destroy();ai.selectionUI?.temporary?.richComposer?.view?.destroy();}catch{}
 await workspace.stop();
 scope.close();workspace.dispose();
 if(toolbar.aiAssistant===ai)toolbar.aiAssistant=null;
 host.setEnabled(false);host.detachPanel(ai);
 if(saved===false)toolbar._showToolbarNotice('AI 已停用，但会话保存失败，请检查文库目录权限');
};
