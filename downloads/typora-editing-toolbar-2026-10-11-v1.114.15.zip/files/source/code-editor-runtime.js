import 'monaco-editor/nls/lang/zh-cn.js';
import './code-editor-runtime.css';
import * as monaco from 'monaco-editor/editor/editor.api.js';
import 'monaco-editor/editor/browser/coreCommands.js';
import 'monaco-editor/editor/contrib/find/browser/findController.js';
import 'monaco-editor/editor/contrib/folding/browser/folding.js';
import 'monaco-editor/editor/contrib/bracketMatching/browser/bracketMatching.js';
import 'monaco-editor/editor/contrib/comment/browser/comment.js';
import 'monaco-editor/editor/contrib/clipboard/browser/clipboard.js';
import 'monaco-editor/editor/contrib/contextmenu/browser/contextmenu.js';
import 'monaco-editor/editor/contrib/wordHighlighter/browser/wordHighlighter.js';
import 'monaco-editor/editor/contrib/wordOperations/browser/wordOperations.js';
import 'monaco-editor/editor/contrib/linesOperations/browser/linesOperations.js';
import 'monaco-editor/editor/contrib/multicursor/browser/multicursor.js';
import 'monaco-editor/editor/contrib/hover/browser/hoverContribution.js';
import 'monaco-editor/editor/contrib/suggest/browser/suggestController.js';
import 'monaco-editor/editor/standalone/browser/quickAccess/standaloneGotoLineQuickAccess.js';
import 'monaco-editor/basic-languages/monaco.contribution.js';
import {language as pythonSyntax} from 'monaco-editor/languages/definitions/python/python.js';

// These are lexical accents, not a Python language server or semantic analysis.
pythonSyntax.tokenizer.root.unshift([/(def)(\s+)([A-Za-z_]\w*)/,['keyword','white','function']],[/\b(?:int|str|bool|float|list|dict|tuple|set|bytes)\b/,'type'],[/[A-Za-z_]\w*(?=\s*\()/,{cases:{'@keywords':'keyword','@default':'function'}}]);
const preparedLanguages=new Map();
globalThis.ETCodePrepareLanguage=id=>{
 if(!preparedLanguages.has(id))preparedLanguages.set(id,(async()=>{const def=monaco.languages.getLanguages().find(d=>d.id===id);if(def?.loader){const mod=await def.loader();monaco.languages.setMonarchTokensProvider(id,mod.language);monaco.languages.setLanguageConfiguration(id,mod.conf);}})());
 return preparedLanguages.get(id);
};

let workerURL;
globalThis.MonacoEnvironment={getWorker(){workerURL ||= URL.createObjectURL(new Blob([ET_CODE_WORKER],{type:'text/javascript'}));return new Worker(workerURL);}};
monaco.languages.register({id:'matlab',extensions:['.m'],aliases:['MATLAB']});
monaco.languages.setMonarchTokensProvider('matlab',{
 keywords:['break','case','catch','classdef','continue','else','elseif','end','for','function','global','if','otherwise','parfor','persistent','return','spmd','switch','try','while','properties','methods','events','enumeration','arguments'],
 tokenizer:{root:[[/^\s*%\{/,'comment','@comment'],[/%.*$/,'comment'],[/\.\.\..*$/,'comment'],[/[a-zA-Z_]\w*/,{cases:{'@keywords':'keyword','@default':'identifier'}}],[/\d+(?:\.\d*)?(?:[eEdD][+-]?\d+)?[ij]?/,'number'],[/"(?:[^"\\]|\\.|"")*"/,'string'],[/'(?:[^'\r\n]|'')*'/,'string'],[/[+\-*\/\\^=<>~:&|]+/,'operator'],[/[{}()[\]]/,'@brackets']],comment:[[/^\s*%\}/,'comment','@pop'],[/.*$/,'comment']]}
});
monaco.languages.setLanguageConfiguration('matlab',{comments:{lineComment:'%',blockComment:['%{','%}']},brackets:[['(',')'],['[',']'],['{','}']],autoClosingPairs:[{open:'(',close:')'},{open:'[',close:']'},{open:'{',close:'}'},{open:'"',close:'"'}]});
globalThis.ETCodeMonaco=monaco;
