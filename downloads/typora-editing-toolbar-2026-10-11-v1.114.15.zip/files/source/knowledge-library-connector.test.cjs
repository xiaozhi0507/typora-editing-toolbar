'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs/promises'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto'),{Readable}=require('node:stream');
const Connector=require('./knowledge-library-connector.cjs'),Store=require('./knowledge-library-store.cjs');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const entry=(p,data='test')=>({path:p,bytes:Buffer.byteLength(data),sha256:hash(data)});
const invalid=files=>new Connector({}).begin({id:crypto.randomUUID(),files},'test-origin');
test('receiver uses the new port and preserves extension identity, approval and token checks',async()=>{
 const {once}=require('node:events');let allow=false,pairs={};
 const c=new Connector({approve:async()=>allow,getPairs:()=>pairs,setPairs:value=>{pairs=value;}});
 assert.equal(c.port,23120);assert.equal(new Connector({port:24001}).port,24001);
 // Bind an ephemeral isolated listener for protocol checks, leaving real apps untouched.
 c.port=0;c.start();await once(c.server,'listening');c.port=c.server.address().port;
 const base=`http://127.0.0.1:${c.port}/v1`,identity='chrome-extension://'+'a'.repeat(32),headers={'X-Typora-Connector':identity};
 try{
  let r=await fetch(base+'/health',{headers});assert.equal(r.status,200);assert.deepEqual(await r.json(),{service:'typora-library',version:1});
  r=await fetch(base+'/health',{headers:{...headers,Origin:'https://example.com'}});assert.equal(r.status,403);
  r=await fetch(base+'/health');assert.equal(r.status,403);
  r=await fetch(base+'/pair',{method:'POST',headers,body:'{}'});assert.equal(r.status,400);assert.match((await r.json()).error,/未允许连接/);assert.deepEqual(pairs,{});
  allow=true;r=await fetch(base+'/pair',{method:'POST',headers,body:'{}'});const {token}=await r.json();assert.match(token,/^[a-f0-9]{64}$/);assert.equal(pairs[identity],hash(token));
  r=await fetch(base+'/unpair',{method:'POST',headers:{...headers,Authorization:'Bearer wrong'},body:'{}'});assert.equal(r.status,401);
  r=await fetch(base+'/unpair',{method:'POST',headers:{...headers,Authorization:'Bearer '+token},body:'{}'});assert.equal(r.status,200);assert.deepEqual(pairs,{});
 }finally{c.close();}
});
test('connector reports the rejected resource path and does not accept bin or unsafe names',async()=>{
 for(const p of ['_assets/014-inline.bin','_assets/../outside.jpg','_assets/NUL.jpg','_assets/a?.jpg','_assets/a\\b.jpg'])await assert.rejects(invalid([entry('Paper.md'),entry(p)]),e=>e.message.includes(p)&&e.message.includes('路径或格式'));
 await assert.rejects(invalid([entry('Paper.md'),null]),/文件缺少路径/);
});
test('connector distinguishes duplicate path, length and SHA metadata errors',async()=>{
 await assert.rejects(invalid([entry('Paper.md'),entry('paper.md')]),/路径重复.*paper.md/);
 await assert.rejects(invalid([entry('Paper.md'),{...entry('_assets/img.jpg'),bytes:50*1024*1024+1}]),/50 MB.*img.jpg/);
 await assert.rejects(invalid([entry('Paper.md'),{...entry('_assets/img.jpg'),sha256:'bad'}]),/SHA-256.*img.jpg/);
});
test('supplement images and sidecars transfer, commit once and remain hash identical',async()=>{
 const temp=path.join(os.homedir(),'Downloads','codex-temp');await fs.mkdir(temp,{recursive:true});const root=await fs.mkdtemp(path.join(temp,'connector-supplement-'));const store=new Store(root),{data}=await store.open();
 const c=new Connector({Store,QuickFile:require('./knowledge-library-quick-file.cjs'),root:()=>root}),id=crypto.randomUUID(),md='# PlantSegNeRF\n\n![Supplementary material 1](<_assets/paper/supplement.jpg>)\n';
 const content=[['Paper_English.md',md],['_assets/paper/supplement.jpg',Buffer.from([255,216,255,224,...Array(32).fill(0)])],['_xref/Paper_English/xref-index.json',JSON.stringify({schema:'xref-sidecar-v2',path_base:'markdown-directory',documents:[{id:1,markdown:'Paper_English.md',sha256:hash(md),metadata:{title_original:'PlantSegNeRF',language:'en'},targets:[],bibliography:[]}]})]];
 try{
  await c.begin({id,libraryId:data.libraryId,files:content.map(([p,b])=>entry(p,b))},'test-origin');const job=c.jobs.get(id);
  await assert.rejects(c.write(job,1,Readable.from([Buffer.from('not the image')])),/文件校验失败/);
  for(const [i,[p,b]] of content.entries()){await c.write(job,i,Readable.from([Buffer.from(b)]));assert.equal(hash(await fs.readFile(path.join(job.folder,p))),hash(b));}
  const saved=await c.commit(job);assert.equal(saved.created,true);assert.deepEqual(await c.commit(job),saved);
  assert.equal((await store.read()).data.items.length,1);assert.equal((await store.read()).data.items[0].title,'PlantSegNeRF');
 }finally{assert.equal(path.dirname(path.resolve(root)),path.resolve(temp));await fs.rm(root,{recursive:true,force:true});}
});

test('legacy doc and xls attachments import with original bytes and local links; corruption is rejected',async()=>{
 const temp=path.join(os.homedir(),'Downloads','codex-temp');await fs.mkdir(temp,{recursive:true});const root=await fs.mkdtemp(path.join(temp,'connector-legacy-office-'));
 const store=new Store(root),{data}=await store.open(),c=new Connector({Store,QuickFile:require('./knowledge-library-quick-file.cjs'),root:()=>root}),id=crypto.randomUUID();
 const md='# Legacy Office\n\n[Methods](<_assets/paper/001-supplement.doc>)\n\n[Results](<_assets/paper/002-supplement.XLS>)\n';
 const doc=Buffer.alloc(512),xls=Buffer.alloc(512);for(const b of [doc,xls])Buffer.from('d0cf11e0a1b11ae1','hex').copy(b);doc[128]=1;xls[128]=2;
 const content=[['Paper_English.md',md],['_assets/paper/001-supplement.doc',doc],['_assets/paper/002-supplement.XLS',xls],['_xref/Paper_English/xref-index.json',JSON.stringify({schema:'xref-sidecar-v2',path_base:'markdown-directory',documents:[{id:1,markdown:'Paper_English.md',sha256:hash(md),metadata:{title_original:'Legacy Office',language:'en'},targets:[],bibliography:[]}]})]];
 try{
  for(const p of ['_assets/paper/file.doc.exe','_assets/../escape.xls','_assets/CON.doc'])assert.equal(c.validPath(p),false);
  await c.begin({id,libraryId:data.libraryId,files:content.map(([p,b])=>entry(p,b))},'test-origin');const job=c.jobs.get(id),corrupt=Buffer.from(xls);corrupt[128]++;
  await assert.rejects(c.write(job,2,Readable.from([corrupt])),/文件校验失败/);
  await assert.rejects(fs.stat(path.join(job.folder,content[2][0])),{code:'ENOENT'});
  for(const [i,[p,b]] of content.entries()){await c.write(job,i,Readable.from([Buffer.from(b)]));assert.deepEqual(await fs.readFile(path.join(job.folder,p)),Buffer.from(b));}
  const saved=await c.commit(job);assert.equal(saved.created,true);assert.deepEqual(await c.commit(job),saved);
  const items=(await store.read()).data.items;assert.equal(items.length,1);assert.equal(items[0].title,'Legacy Office');
  assert.equal(await fs.readFile(path.join(job.folder,'Paper_English.md'),'utf8'),md);
 }finally{assert.equal(path.dirname(path.resolve(root)),path.resolve(temp));await fs.rm(root,{recursive:true,force:true});}
});
