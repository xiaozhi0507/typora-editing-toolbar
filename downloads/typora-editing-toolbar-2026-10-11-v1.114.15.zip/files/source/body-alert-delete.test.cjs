const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),{JSDOM}=require('jsdom');
const source=fs.readFileSync(__dirname+'/base/editing-toolbar.js','utf8');
const clone=v=>JSON.parse(JSON.stringify(v));
function fixture(type='IMPORTANT',body=''){
 const dom=new JSDOM('<div id="write" contenteditable="true"></div>',{runScripts:'outside-only'}),w=dom.window,d=w.document;
 w.eval(source.slice(0,source.lastIndexOf('(function () {'))+';window.Toolbar=EditingToolbarPlugin;window.buttons=BUTTON_DEFINITIONS;');
 const paragraph=(id,text)=>({id,content:{type:'paragraph',text},children:[],relation:{parent_id:'q'}});
 let json={id:'q',content:{type:'blockquote',alert:type.toLowerCase()},relation:{parent_id:null,before_id:'prev',after_id:'next'},is_top:true,children:[paragraph('h','[!'+type+']'),paragraph('b',body)]};
 const write=d.getElementById('write'),toolbar=Object.create(w.Toolbar.prototype),commands=[];
 const node={cid:'q',storeToJson:()=>clone(json)};
 const render=()=>{write.innerHTML=json.content.type==='blockquote'?'<blockquote cid="q" class="md-alert"><p cid="h"><span class="md-alert-text">'+type+'</span></p><p cid="b">'+json.children[1].content.text+'</p></blockquote>':'<p cid="q"><br></p>';};
 const jump=id=>{const p=d.querySelector('[cid="'+id+'"]');if(!p)return;const r=d.createRange();r.selectNodeContents(p);r.collapse(true);w.getSelection().removeAllRanges();w.getSelection().addRange(r);};
 const editor={sourceView:{},getNode:id=>id==='q'?node:null,store(){if(this.pendingText!==undefined)json.children[1].content.text=this.pendingText;},findElemById:id=>({id}),selection:{buildUndo:()=>({type:'cursor',id:(w.getSelection().anchorNode?.nodeType===1?w.getSelection().anchorNode:w.getSelection().anchorNode?.parentElement)?.closest('[cid]')?.getAttribute('cid')}),jumpIntoElemBegin:elem=>jump(elem.id)},refocus(){},quickRefresh(){},brush:{pause(){},resume(){}},undo:{endSnap(){},buildReplaceUndo:n=>({type:'replace',id:n.cid,json:n.storeToJson()}),exeCommand(c){if(c.type==='cursor')jump(c.id);else{json=clone(c.json);render();}},register:c=>commands.push(c)}};
 w.File={editor};toolbar._getEditor=()=>editor;toolbar._saveSelection=()=>{};toolbar.readingMode={protected:false};render();jump('b');toolbar._bindAlertTitleGuard();
 return {w,d,toolbar,editor,commands,get json(){return json;},setBody(html){d.querySelector('[cid="b"]').innerHTML=html;jump('b');},key(key,options={}){const event=key.startsWith('delete')?new w.InputEvent('beforeinput',{inputType:key,bubbles:true,cancelable:true,...options}):new w.KeyboardEvent('keydown',{key,bubbles:true,cancelable:true,...options});d.querySelector('[cid="b"],[cid="q"]').dispatchEvent(event);return event;},undo(){for(const c of [...commands.at(-1).undo].reverse())editor.undo.exeCommand(c);},redo(){for(const c of commands.at(-1).redo)editor.undo.exeCommand(c);},close:()=>w.close()};
}
test('empty alerts of all five types delete to a plain paragraph with native undo and redo',()=>{
 for(const type of ['NOTE','TIP','IMPORTANT','WARNING','CAUTION'])for(const key of ['Backspace','Delete','deleteContentBackward','deleteContentForward']){
  const f=fixture(type);const original=clone(f.json);assert.equal(f.key(key).defaultPrevented,true);assert.equal(f.json.content.type,'paragraph');assert.equal(f.json.content.text,'');assert.equal(f.commands.length,1);assert.deepEqual(f.json.relation,original.relation);assert.equal(f.w.getSelection().anchorNode.getAttribute('cid'),'q');f.undo();assert.deepEqual(f.json,original);f.redo();assert.equal(f.json.content.type,'paragraph');f.close();
 }
});
test('nonempty alerts and invisible media/structure are never deleted as an empty block',()=>{
 for(const html of ['content','<img src="x" alt="">','<input type="checkbox">','<table><tr><td></td></tr></table>']){const f=fixture('NOTE');f.setBody(html);f.key('Backspace');assert.equal(f.json.content.type,'blockquote');assert.equal(f.commands.length,0);f.close();}
 const f=fixture('NOTE','stored text');f.setBody('<br>');f.key('Backspace');assert.equal(f.commands.length,0);f.close();
});
test('current empty content is stored before replacement, with marker and model validation',()=>{
 const f=fixture('TIP','last letter');f.setBody('<br>');f.editor.pendingText='';f.key('Backspace');assert.equal(f.json.content.type,'paragraph');f.undo();assert.equal(f.json.children[1].content.text,'');f.close();
 const g=fixture();g.json.children[0].content.text+=' keep this';g.key('Delete');assert.equal(g.commands.length,0);g.close();
});
test('protected, locked, busy, source and composing states cannot remove empty alerts',()=>{
 for(const setup of [f=>f.toolbar.readingMode.protected=true,f=>f.w.File.isLocked=true,f=>f.w.File.inBusyMode=true,f=>f.editor.sourceView.inSourceMode=true,f=>f.editor.isIME=true]){const f=fixture();setup(f);f.key('Backspace');assert.equal(f.commands.length,0);assert.equal(f.json.content.type,'blockquote');f.close();}
 const f=fixture();f.key('Backspace',{isComposing:true});assert.equal(f.commands.length,0);f.close();
});
test('deleting at a nonempty body start keeps the marker protected; noncollapsed selection is left to Typora',()=>{
 const f=fixture('IMPORTANT','content');assert.equal(f.key('Backspace').defaultPrevented,true);assert.equal(f.commands.length,0);const range=f.d.createRange();range.selectNodeContents(f.d.querySelector('[cid="b"]'));f.w.getSelection().removeAllRanges();f.w.getSelection().addRange(range);assert.equal(f.key('Delete').defaultPrevented,false);f.close();
});
