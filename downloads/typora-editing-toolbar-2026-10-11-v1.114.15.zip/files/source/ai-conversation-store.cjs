// Conversation files are separate from provider settings and credentials.
const ConversationExecution=require('./ai-execution.cjs');
class AIConversationStore {
  constructor(requireNode, directory) { this.fs=requireNode('fs');this.path=requireNode('path');this.crypto=requireNode('crypto');this.directory=directory; }
  id() { return this.crypto.randomUUID(); }
  folder(id) { if(!/^[a-f0-9-]{36}$/.test(id))throw Error('无效的会话 ID');return this.path.join(this.directory,id); }
  normalize(data) {data=JSON.parse(JSON.stringify(data));return {...data,turns:data.turns.map((t,i)=>({...t,id:t.id||this.stableId(data.id+':'+i),...(Array.isArray(t.execution)?{execution:ConversationExecution.snapshot(t.execution)}:{})}))};}
  stableId(text) {const h=this.crypto.createHash('sha256').update(text).digest('hex').slice(0,32);return h.slice(0,8)+'-'+h.slice(8,12)+'-'+h.slice(12,16)+'-'+h.slice(16,20)+'-'+h.slice(20);}
  read(id) { const data=JSON.parse(this.fs.readFileSync(this.path.join(this.folder(id),'state.json'),'utf8'));if(data.version!==1||data.id!==id||!Array.isArray(data.turns))throw Error('会话文件格式损坏');return this.normalize(data); }
  context(record) { if(!record.contextFile)return null;if(!/^context-[a-f0-9-]{36}\.json$/.test(record.contextFile))throw Error('无效的资料快照');return JSON.parse(this.fs.readFileSync(this.path.join(this.folder(record.id),record.contextFile),'utf8')); }
  async list() {
    let entries;try{entries=await this.fs.promises.readdir(this.directory,{withFileTypes:true});}catch(e){if(e.code==='ENOENT')return {records:[],errors:0};throw e;}
    const records=[];let errors=0;
    // Read metadata/turns only. Large image/reference snapshots load only on resume.
    for(const entry of entries){if(!entry.isDirectory()||!/^[a-f0-9-]{36}$/.test(entry.name))continue;
      try{const data=JSON.parse(await this.fs.promises.readFile(this.path.join(this.folder(entry.name),'state.json'),'utf8'));if(data.version!==1||data.id!==entry.name||!Array.isArray(data.turns))throw Error('format');if(!data.deleted)records.push(this.normalize(data));}catch{errors++;}
    }
    return {records:records.sort((a,b)=>String(b.updated).localeCompare(String(a.updated))),errors};
  }
  atomic(file, data) {
    const tmp=file+'.'+this.id()+'.tmp';
    try{this.fs.writeFileSync(tmp,JSON.stringify(data),'utf8');this.fs.renameSync(tmp,file);}finally{try{this.fs.unlinkSync(tmp);}catch{}}
  }
  write(input, expectedRevision, snapshot) {
    const dir=this.folder(input.id);this.fs.mkdirSync(dir,{recursive:true});const lock=this.path.join(dir,'write.lock');let fd;
    try{try{fd=this.fs.openSync(lock,'wx');}catch(e){if(e.code!=='EEXIST')throw e;if(Date.now()-this.fs.statSync(lock).mtimeMs>30000){this.fs.unlinkSync(lock);fd=this.fs.openSync(lock,'wx');}else throw Error('会话正在另一个窗口中保存，请稍后重试');}
      let previous;try{previous=this.read(input.id);}catch(e){if(e.code!=='ENOENT')throw e;}
      if((previous?.revision||null)!==(expectedRevision||null))throw Object.assign(Error('会话已在其他窗口更改'),{code:'CHAT_CONFLICT'});
      const record=this.normalize({...input,version:1,revision:this.id(),updated:new Date().toISOString()});
      if(snapshot!==undefined){record.contextFile=snapshot?'context-'+this.id()+'.json':null;if(snapshot)this.atomic(this.path.join(dir,record.contextFile),snapshot);}
      else record.contextFile=previous?.contextFile||null;
      this.atomic(this.path.join(dir,'state.json'),record);
      // A successful clear/delete removes its obsolete reference snapshot too.
      if(previous?.contextFile&&previous.contextFile!==record.contextFile)try{this.fs.unlinkSync(this.path.join(dir,previous.contextFile));}catch{}
      return record;
    }finally{if(fd!==undefined){this.fs.closeSync(fd);try{this.fs.unlinkSync(lock);}catch{}}}
  }
  remove(record) { return this.write({...record,deleted:true,turns:[],contextState:null,draft:'',title:'',file:''},record.revision,null); }
}
module.exports=AIConversationStore;
