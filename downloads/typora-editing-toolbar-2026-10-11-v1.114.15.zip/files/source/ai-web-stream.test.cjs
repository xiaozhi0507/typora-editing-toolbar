const {test}=require('node:test'),assert=require('node:assert/strict'),{JSDOM}=require('jsdom'),create=require('./ai-web-stream.cjs'),events=require('./ai-web-events.cjs');
const frame=(v,eol='\n')=>'data: '+(typeof v==='string'?v:JSON.stringify(v))+eol+eol;
const message=(extra={})=>({id:'a1',author:{role:'assistant'},channel:'final',content:{content_type:'text',parts:['Hello']},end_turn:false,...extra});
test('SSE preserves every CRLF split and compact patch path with Unicode text',()=>{
 const input=frame({conversation_id:'chat',message:message()},'\r\n')+frame({p:'/message/content/parts/0',o:'append',v:' 中文'},'\r\n')+frame({v:' 🌱'},'\r\n')+frame({p:'/message/end_turn',o:'replace',v:true},'\r\n');
 for(let i=0;i<input.length;i++){const d=create();d.push(input.slice(0,i));d.push(input.slice(i));assert.equal(d.state().text,'Hello 中文 🌱');assert.equal(d.state().completed,true);assert.equal(d.state().conversationId,'chat');}
 const d=create();for(const c of input)d.push(c);assert.equal(d.state().text,'Hello 中文 🌱');
});
test('tool message success, EOF and stream-complete never imply turn completion',()=>{
 const d=create();d.push(frame({message:message({status:'finished_successfully'})})+frame({type:'message_stream_complete'})+frame('[DONE]'));d.end();assert.equal(d.state().completed,false);assert.equal(d.state().ended,true);assert.equal(d.state().text,'Hello');
});
test('hidden and analysis messages stay hidden through role/channel/content patches',()=>{
 for(const extra of [{metadata:{is_visually_hidden_from_conversation:true}},{channel:'analysis'},{author:{role:'assistant'},recipient:'python'}]){const d=create();d.push(frame({message:message(extra)})+frame({o:'patch',v:[{p:'/message/channel',o:'replace',v:'final'},{p:'/message/author/role',o:'replace',v:'assistant'},{p:'/message/content/parts/0',o:'append',v:' secret'},{p:'/message/end_turn',o:'replace',v:true}]}));assert.equal(d.state().text,'');assert.equal(d.state().completed,false);}
});
test('multiple messages, all string parts and explicit final end_turn are tracked',()=>{
 const d=create();d.push(frame({message:message({channel:'analysis'})})+frame({v:{message:message({id:'final',content:{content_type:'text',parts:['A','B']}})}})+frame({o:'patch',v:[{p:'/message/content/parts/1',o:'append',v:'C'},{p:'/message/end_turn',o:'replace',v:true}]}));assert.equal(d.state().text,'ABC');assert.equal(d.state().completed,true);assert.equal(d.state().messageId,'final');
});
test('unsupported patch schema and multimodal bodies require DOM fallback',()=>{
 const d=create();d.push(frame({message:message()})+frame({p:'/message/content/parts/0',o:'unexpected',v:'wrong'}));assert.equal(d.state().supported,false);assert.equal(d.state().text,'');
 const m=create();m.push(frame({message:message({content:{content_type:'text',parts:['visible',{secret:'not text'}]},end_turn:true})}));assert.equal(m.state().text,'');assert.equal(m.state().completed,false);
});
test('SSE enforces bounded frames without accepting prototype paths',()=>{
 assert.throws(()=>create().push('x'.repeat(2*1024*1024+1)),/too large/);const d=create();d.push(frame({message:message()})+frame({p:'/message/__proto__/polluted',o:'add',v:true}));assert.equal({}.polluted,undefined);assert.equal(d.state().supported,false);
});
function page(fetch){const w=new JSDOM('<main><div data-message-role="user">Q</div></main>',{url:'https://chatgpt.com/c/chat',runScripts:'outside-only'}).window;Object.assign(w,{fetch,Request,Response,TextEncoder,TextDecoder,AbortController});Object.defineProperty(w.crypto,'subtle',{value:require('node:crypto').webcrypto.subtle});w.eval('window.events='+events.toString()+';window.decoder='+create.toString());return w;}
const arm=w=>w.events('arm',{id:'task',text:'Q',conversationId:'chat'},w.decoder);
const request={method:'POST',body:JSON.stringify({conversation_id:'chat',messages:[{author:{role:'user'},content:{parts:['Q']}}]})};
async function readUntil(w,predicate){let s;for(let i=0;i<15;i++){s=await w.events('wait',{id:'task',revision:s?.revision||0,ms:120});if(predicate(s))return s;}assert.fail('No expected event: '+JSON.stringify(s));}
test('matched public stream wakes bridge and original response is unmodified',async()=>{
 const body=frame({conversation_id:'chat',message:message()})+frame({p:'/message/end_turn',o:'replace',v:true});const original=async()=>new Response(body,{headers:{'content-type':'text/event-stream'}}),w=page(original);await arm(w);const response=await w.fetch('/backend-api/f/conversation',request);assert.equal(await response.text(),body);const s=await readUntil(w,s=>s.eof);assert.equal(s.text,'Hello');assert.equal(s.completed,true);assert.ok(s.firstTextAt);await w.events('dispose',{id:'task'});assert.equal(w.fetch,original);w.close();
});
test('unrelated conversation and user prompt streams are never captured',async()=>{
 const w=page(async()=>new Response(frame({message:message({end_turn:true})}),{headers:{'content-type':'text/event-stream'}}));await arm(w);await w.fetch('/backend-api/f/conversation',{...request,body:request.body.replace('"Q"','"different"')});await w.fetch('/backend-api/f/conversation',{...request,body:request.body.replace('"chat"','"other"')});const s=await w.events('wait',{id:'task',revision:1,ms:10});assert.equal(s.stream,false);assert.equal(s.text,undefined);await w.events('dispose',{id:'task'});w.close();
});
test('fetch rejection and EOF remain recoverable and new arm clears stale waiters',async()=>{
 let failed=true;const w=page(async()=>{if(failed)throw Error('network');return new Response(frame({message:message()}),{headers:{'content-type':'text/event-stream'}});});await arm(w);await assert.rejects(w.fetch('/backend-api/f/conversation',request),/network/);failed=false;await w.fetch('/backend-api/f/conversation',request);const s=await readUntil(w,s=>s.eof);assert.equal(s.completed,false);const waiting=w.events('wait',{id:'task',revision:s.revision,ms:2000});await w.events('arm',{id:'next',observeOnly:true},w.decoder);assert.equal((await waiting).disposed,true);assert.equal(await w.events('wait',{id:'task'}),null);await w.events('dispose',{id:'next'});w.close();
});
test('DOM fallback wakes on public mutations and identity cookie changes are reported',async()=>{
 const w=page(async()=>new Response('{}'));await arm(w);const pending=w.events('wait',{id:'task',revision:1,ms:2000});w.document.querySelector('main').insertAdjacentHTML('beforeend','<p>new answer</p>');assert.ok((await pending).revision>1);w.document.cookie='workspace=other';assert.equal((await w.events('wait',{id:'task',revision:0})).scopeChanged,true);await w.events('dispose',{id:'task'});w.close();
});
test('principal digest requires user/workspace and rejects identity change during lookup',async()=>{
 let session={user:{id:'a'},account:{id:'space'}},after;const w=page(async()=>{after?.();return new Response(JSON.stringify(session));});const a=await w.events('scope');assert.equal(a.status,'verified');assert.match(a.key,/^[a-f0-9]{64}$/);session.account.id='other';assert.notEqual((await w.events('scope')).key,a.key);session={user:{id:'a'}};assert.equal((await w.events('scope')).status,'unavailable');session.account={id:'space'};after=()=>w.document.cookie='workspace=changed';assert.equal((await w.events('scope')).status,'unavailable');w.close();
});

test('identity hint is document-bound and ignores unrelated cookie churn',async()=>{
 const w=page(async()=>{w.document.cookie='analytics=changed';return new Response(JSON.stringify({user:{id:'a'},account:{id:'space'}}));});const a=await w.events('scope-hint');w.document.cookie='analytics=first';const b=await w.events('scope-hint');assert.equal(a.stamp,b.stamp);assert.equal(a.documentId,b.documentId);assert.equal((await w.events('scope')).status,'verified');w.document.cookie='workspace=other';assert.notEqual((await w.events('scope-hint')).stamp,a.stamp);w.close();
});
test('slow identity fetch aborts within a bounded lookup instead of blocking repeated multi-second reads',async()=>{
 let aborted=false;const w=page((url,{signal})=>new Promise((resolve,reject)=>signal.addEventListener('abort',()=>{aborted=true;reject(Error('Abort'));})));const start=Date.now();assert.equal((await w.events('scope')).status,'unavailable');assert.equal(aborted,true);assert.ok(Date.now()-start<1800);w.close();
});
