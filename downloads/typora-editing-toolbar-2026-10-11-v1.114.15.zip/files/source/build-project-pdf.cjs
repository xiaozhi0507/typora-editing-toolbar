const fs=require('node:fs'),path=require('node:path'),esbuild=require('esbuild');
module.exports=()=>{
 const options={bundle:true,platform:'browser',format:'iife',minify:true,write:false,target:'chrome120',define:{process:'undefined'},logLevel:'silent'};
 const main=esbuild.buildSync({...options,stdin:{contents:'export {getDocument,PDFWorker} from "pdfjs-dist/legacy/build/pdf.mjs";',resolveDir:__dirname},globalName:'window.ETProjectPDF'}).outputFiles[0].text;
 const worker=esbuild.buildSync({...options,entryPoints:[path.join(__dirname,'node_modules/pdfjs-dist/legacy/build/pdf.worker.mjs')]}).outputFiles[0].text;
 return 'const ET_PROJECT_PDF_MAIN='+JSON.stringify(main)+';\nconst ET_PROJECT_PDF_WORKER='+JSON.stringify(worker)+';\n'+fs.readFileSync(path.join(__dirname,'ai-project-pdf.js'),'utf8')+'\nconst ETAIProjectReferences=(()=>{const module={exports:{}};'+fs.readFileSync(path.join(__dirname,'ai-project-references.cjs'),'utf8')+';return module.exports;})();\n';
};
