Object.assign(EditingToolbarCodeEditor.prototype,{
 readAppearance(){try{this.appearance=ETCodeWorkspace.appearance(JSON.parse(localStorage.getItem('et-code-appearance-v1'))||{});}catch{this.appearance=ETCodeWorkspace.appearance();}this.colorSchemes=new ETCodeSchemes.ColorSchemes(localStorage);this.appearance=this.colorSchemes.startup(this.appearance);this.wrap=this.appearance.wrap;},
 palette(){
  const a=this.appearance||ETCodeWorkspace.appearance(),t=this.toolbar.themePalette,bg=getComputedStyle(document.body).backgroundColor;
  const followsDark=t?.profile()?t.mode()==='dark':(bg.match(/\d+/g)||[255,255,255]).slice(0,3).reduce((n,v)=>n+Number(v),0)<390;
  const dark=a.mode==='dark'||a.mode==='auto'&&followsDark||a.mode==='classic'&&followsDark;
  const base=dark?{background:'#101213',foreground:'#d6deeb',cursor:'#d8e2ef',comment:'#788997',keyword:'#c792ea',string:'#a5d6ff',number:'#ffb86b',function:'#c7a6ff',identifier:'#5fd8c6',line:'#252829',gutter:'#7a8793',chrome:'#202224'}:{background:'#ffffff',foreground:'#243447',cursor:'#35495e',comment:'#6e7781',keyword:'#a626a4',string:'#0b679b',number:'#986801',function:'#7540a6',identifier:'#167a70',line:'#f1f4f7',gutter:'#87909a',chrome:'#f5f6f8'};
  return {...base,...Object.fromEntries(Object.entries(a).filter(([k])=>k in base)),dark};
 },
 theme(){
  if(!this.monaco)return;const p=this.palette(),a=this.appearance||ETCodeWorkspace.appearance(),signature=JSON.stringify([p,a.mode]);if(signature===this.themeSignature)return;this.themeSignature=signature;
  const c={ 'editor.background':p.background,'editor.foreground':p.foreground,'editorCursor.foreground':p.cursor,'editorLineNumber.foreground':p.gutter,'editorLineNumber.activeForeground':p.foreground,'editor.lineHighlightBackground':p.line,'editor.lineHighlightBorder':'#00000000','editor.selectionBackground':p.dark?'#34495e99':'#c8e4fa99','editor.inactiveSelectionBackground':p.dark?'#2b384599':'#dce8f199','editorIndentGuide.background1':p.dark?'#343a40':'#e5e8ec','editorIndentGuide.activeBackground1':p.dark?'#606a73':'#a7b0b8','editorWhitespace.foreground':p.dark?'#41464d':'#d8dce2','minimap.background':p.background,'diffEditor.insertedTextBackground':p.dark?'#2e66404d':'#2ea04333','diffEditor.removedTextBackground':p.dark?'#842e324d':'#ff555533','diffEditor.insertedLineBackground':p.dark?'#1f442a66':'#dafbe166','diffEditor.removedLineBackground':p.dark?'#53212566':'#ffebe966'};
  this.monaco.editor.defineTheme('et-code-reference',{base:p.dark?'vs-dark':'vs',inherit:true,colors:c,rules:Object.entries({comment:p.comment,keyword:p.keyword,string:p.string,number:p.number,function:p.function,type:p.identifier,identifier:p.identifier,delimiter:p.foreground}).map(([token,color])=>({token,foreground:color.slice(1)}))});
  this.monaco.editor.setTheme(a.mode==='classic'?(p.dark?'vs-dark':'vs'):'et-code-reference');this.panel.dataset.dark=String(p.dark);this.frame.style.background=p.background;
  for(const [k,v]of Object.entries({bg:p.background,fg:p.foreground,chrome:p.chrome,muted:p.gutter,line:p.line}))this.panel.style.setProperty('--et-code-'+k,v);
 },
 queueStyle(){if(this.styleFrame)return;this.styleFrame=requestAnimationFrame(()=>{this.styleFrame=0;this.appearance=ETCodeWorkspace.appearance(this.appearance);this.wrap=this.appearance.wrap;this.theme();const options={fontSize:this.appearance.fontSize,lineHeight:Math.round(this.appearance.fontSize*this.appearance.lineHeight),wordWrap:this.wrap?'on':'off'},key=JSON.stringify(options);if(this.metricsSignature!==key){this.metricsSignature=key;this.editor?.updateOptions(options);}this.layout();try{localStorage.setItem('et-code-appearance-v1',JSON.stringify(this.appearance));}catch{this.toolbar._showToolbarNotice('代码样式暂未保存');}});},
 showAppearance(){
  if(this.styleDialog?.open){this.styleDialog.focus();return;}
  const d=this.styleDialog=this.toolbar.documentTabs.projects.modal('代码样式','et-code-style-dialog'),body=this.node('div','et-code-style-body'),presets=this.node('div','et-code-presets'),fields=[],S=ETCodeSchemes,store=this.colorSchemes;
  store.read();
  let selectedId=S.resolve(store.data,store.data.defaultId)&&S.same(this.appearance,S.resolve(store.data,store.data.defaultId))?store.data.defaultId:'',confirmDelete=false;
  const message=this.node('p','et-code-scheme-message');message.setAttribute('role','status');message.setAttribute('aria-live','polite');
  const report=(text,error=false)=>{message.textContent=text;message.classList.toggle('is-error',error);};
  const attempt=fn=>{try{fn();}catch(e){report(/quota|storage|denied/i.test(e.message)?'无法保存方案，请检查本地存储空间。':e.message,true);}};
  const preview=input=>{const v=input.value.trim(),valid=/^#?[\da-f]{6}$/i.test(v);if(valid)input.style.setProperty('--et-code-swatch','#'+v.replace('#','').toLowerCase());else input.style.removeProperty('--et-code-swatch');return valid;};
  const valid=()=>fields.every(([,input])=>/^#?[\da-f]{6}$/i.test(input.value.trim()));
  const match=()=>{
   if(S.resolve(store.data,selectedId)&&S.same(this.appearance,S.resolve(store.data,selectedId)))return selectedId;
   for(const [mode]of S.presets)if(S.same(this.appearance,{mode}))return 'builtin:'+mode;
   return store.data.schemes.find(x=>S.same(this.appearance,x.colors))?.id||'';
  };
  const schemes=this.node('div','et-code-schemes'),heading=this.node('div','et-code-scheme-heading'),saved=this.node('select'),actions=this.node('div','et-code-scheme-actions'),defaultRow=this.node('div','et-code-scheme-default'),defaultText=this.node('span');
  saved.setAttribute('aria-label','已保存的配色方案');
  const nameBox=this.node('div','et-code-scheme-namebox'),name=this.node('input'),nameActions=this.node('div','et-code-scheme-actions');
  nameBox.hidden=true;name.type='text';name.maxLength=40;name.placeholder='例如：论文绘图 · 浅色';name.setAttribute('aria-label','方案名称');
  const saveAs=this.button('保存方案…',()=>{nameBox.hidden=false;name.value='';report('');name.focus();}),
   update=this.button('更新',()=>attempt(()=>{store.update(selectedId,this.appearance);sync();report('已更新方案');})),
   remove=this.button('删除',()=>attempt(()=>{if(!confirmDelete){confirmDelete=true;remove.textContent='确认删除';report('再次点击删除此方案；若为启动默认，将改为跟随软件。');return;}store.remove(selectedId);selectedId='';sync();report('已删除方案，当前配色保留');})),
   makeDefault=this.button('设为默认',()=>attempt(()=>{store.setDefault(match());sync();report('已设为启动默认，下次打开 Typora 时应用');})),
   saveName=this.button('保存',()=>attempt(()=>{if(!valid())throw Error('请先修正无效的十六进制颜色');selectedId=store.create(name.value,this.appearance);nameBox.hidden=true;sync();report('方案已保存');})),
   cancelName=this.button('取消',()=>{nameBox.hidden=true;report('');saveAs.focus();});
  update.setAttribute('aria-label','更新当前方案');remove.setAttribute('aria-label','删除当前方案');makeDefault.title='启动时使用此配色，字号与行距保持不变';saveName.className='primary';
  name.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();saveName.click();}if(e.key==='Escape'){e.preventDefault();e.stopPropagation();cancelName.click();}};
  nameActions.append(saveName,cancelName);nameBox.append(name,nameActions);
  heading.append(this.node('span','','我的方案'),saveAs);actions.append(saved,update,remove);defaultRow.append(defaultText,makeDefault);schemes.append(heading,actions,nameBox,defaultRow,message);
  const sync=()=>{
   const matched=match(),entry=store.data.schemes.find(x=>x.id===selectedId);
   if(matched)selectedId=matched;
   else if(!entry)selectedId='';
   saved.replaceChildren(this.node('option','','选择已保存方案'));saved.firstChild.value='';
   for(const scheme of store.data.schemes){const option=this.node('option','',scheme.name+(scheme.id===store.data.defaultId?' · 默认':'')+(scheme.id===selectedId&&!S.same(this.appearance,scheme.colors)?' · 已修改':''));option.value=scheme.id;saved.append(option);}
   saved.value=selectedId.startsWith('scheme-')?selectedId:'';const selected=store.data.schemes.find(x=>x.id===selectedId);
   update.disabled=!selected||!valid()||S.same(this.appearance,selected.colors);remove.disabled=!selected;
   saveAs.disabled=!valid();makeDefault.disabled=!valid()||!matched||matched===store.data.defaultId;
   makeDefault.textContent=matched&&matched===store.data.defaultId?'已是默认':'设为默认';
   defaultText.textContent='启动默认：'+S.label(store.data,store.data.defaultId);defaultText.title=defaultText.textContent;
   confirmDelete=false;remove.textContent='删除';
   for(const b of presets.children)b.setAttribute('aria-pressed',String(S.same(this.appearance,{mode:b.dataset.mode})));
  };
  const refresh=()=>{const p=this.palette();for(const [key,input]of fields){input.value=this.appearance[key]||p[key];input.removeAttribute('aria-invalid');preview(input);}sync();};
  const apply=palette=>{this.appearance=S.merge(this.appearance,palette);this.queueStyle();nameBox.hidden=true;report('');refresh();};
  saved.onchange=()=>{if(!saved.value){selectedId='';sync();return;}selectedId=saved.value;apply(S.resolve(store.data,selectedId));};
  for(const [value,label]of S.presets){const b=this.button(label,()=>{selectedId='builtin:'+value;apply({mode:value});});b.dataset.mode=value;presets.append(b);}
  body.append(presets,schemes);
  const grid=this.node('div','et-code-style-grid');
  for(const[key,label]of [['background','背景'],['foreground','正文'],['cursor','光标'],['keyword','关键字'],['string','字符串'],['number','数字'],['function','函数'],['comment','注释']]){
   const row=this.node('label','',label),input=this.node('input');input.type='text';input.maxLength=7;input.placeholder='#RRGGBB';input.spellcheck=false;input.setAttribute('aria-label',label+'十六进制');
   input.oninput=()=>{input.removeAttribute('aria-invalid');report('');if(preview(input)){if(this.appearance.mode==='classic')this.appearance.mode=this.palette().dark?'dark':'light';this.appearance[key]=input.style.getPropertyValue('--et-code-swatch');this.queueStyle();}sync();};
   input.onchange=()=>{if(preview(input)){input.value=input.style.getPropertyValue('--et-code-swatch');input.removeAttribute('aria-invalid');}else input.setAttribute('aria-invalid','true');sync();};
   row.append(input);grid.append(row);fields.push([key,input]);
  }
  body.append(grid);
  const metrics=this.node('div','et-code-style-metrics');
  for(const [key,label,min,max,step]of [['fontSize','代码字号',11,24,1],['lineHeight','行距',1.3,2,.1]]){
   const row=this.node('label','',label),input=this.node('input');input.type='number';input.min=min;input.max=max;input.step=step;input.value=this.appearance[key];input.setAttribute('aria-label',label);
   input.onchange=()=>{this.appearance[key]=Math.max(min,Math.min(max,Number(input.value)||min));input.value=this.appearance[key];this.queueStyle();};row.append(input);metrics.append(row);
  }
  body.append(metrics);
  const toggles=this.node('div','et-code-style-toggles');
  for(const [key,label]of [['minimap','显示缩略图'],['wrap','自动换行']]){const row=this.node('label','',label),input=this.node('input');input.type='checkbox';input.checked=this.appearance[key];input.onchange=()=>{this.appearance[key]=input.checked;this.queueStyle();};row.prepend(input);toggles.append(row);}
  body.append(toggles,this.node('p','et-code-style-hint','淡色背景预览 · 左侧色条为原色 · 配色实时生效'));
  const foot=this.node('div','et-project-footer'),reset=this.button('恢复默认方案',()=>{selectedId=store.data.defaultId||'builtin:auto';apply(S.resolve(store.data,store.data.defaultId)||{mode:'auto'});}),close=this.button('完成',()=>d.close());close.className='primary';foot.append(reset,close);d.append(body,foot);refresh();d.addEventListener('close',()=>this.editor?.focus(),{once:true});d.showModal();
 }
});
