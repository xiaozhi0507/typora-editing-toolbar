'use strict';
// Read only book front matter. ISBNs from exercises/references are not book identifiers.
class KnowledgeLibraryBookMetadata {
  static plain(value) { return String(value || '').replace(/<!--[^]*?-->/g,'').replace(/[*_`]/g,'').replace(/<[^>]+>/g,'').trim(); }
  static parse(documents, normalizeISBN) {
    const plain=this.plain, fields={}, evidence={}, candidates=[];
    const set=(key,value,file)=>{value=plain(value);if(value&&!fields[key]){fields[key]=value;evidence[key]=file;}};
    for(const doc of documents){
      const raw=doc.text.split('<!-- book-navigation -->')[0],text=plain(raw),lines=text.split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
      const copyright=/版权|出版|copyright|colophon/i.test(doc.name);
      const cip=text.match(/(?:图书在版编目|CIP[^\n]*数据)[^\n]*\n+([^]*?)(?=\n\s*(?:Ⅰ|Ⅱ|中国国家版本馆|#)|$)/i)?.[1]||'';
      for(const line of lines){
        if(!copyright&&!cip&&!/书名页|title[ _-]?page/i.test(doc.name)&&!/^(?:#{1,6}\s*)?(?:ISBN(?=[\s:\-：\d])|标准书号|本书ISBN)/i.test(line))continue;
        for(const m of line.matchAll(/\bISBN(?:[-\s]*(?:10|13))?\s*[:：]?\s*['"]?((?:97[89][\s\-‐‑–—]*)?(?:\d[\s\-‐‑–—]*){9}[\dXx])(?!\d)/gi)){
          const isbn=normalizeISBN(m[1]);if(!isbn)continue;
          let score=copyright?40:10;
          if(cip.includes(line))score+=100;
          if(/标准书号|本书ISBN|中文(?:简体字)?版.{0,10}ISBN/i.test(line))score+=100;
          if(/authorized translation|English language edition|原版.{0,12}ISBN|original edition/i.test(line))score-=80;
          candidates.push({isbn,score,file:doc.path,text:line});
        }
      }
      // Explicit metadata fields are useful for other book layouts and YAML front matter.
      const labels={title:'书名|title',author:'作者|著者|author',translator:'译者|translator',publisher:'出版社|出版者|publisher',date:'出版日期|出版时间|出版年月|published',edition:'版次|版本|edition',language:'语言|language'};
      for(const [key,label] of Object.entries(labels)){
        const value=text.match(new RegExp('^(?:#{1,6}\\s*)?(?:'+label+')\\s*[:：]\\s*([^\\n]+)$','im'))?.[1];
        if(value)set(key,value.replace(/^['"]|['"]$/g,''),doc.path);
      }
      if(cip){
        const record=cip.replace(/\s*\n\s*/g,' '),bibliography=record.split(/\s*\/\s*/)[0];
        const edition=bibliography.match(/(?:原书)?第\s*[\d一二三四五六七八九十]+\s*版/)?.[0]?.replace(/\s+/g,'');
        const title=bibliography.replace(/\s*[:：]\s*(?:原书)?第[^]*$/,'').trim();
        set('title',title+(edition?'（'+edition+'）':''),doc.path);set('edition',edition,doc.path);
        const author=record.match(/\/\s*([^]*?)著\s*[;；]/)?.[1];
        if(author){
          const latin=[...author.matchAll(/[（(]([A-Za-z][^（）()]+)[）)]/g)].map(m=>m[1]);
          set('author',latin.length?latin.join('；'):author.replace(/[（(](?:美|英|德|法|日|中)[）)]/g,'').split(/[，,、]/).map(s=>s.trim()).filter(Boolean).join('；'),doc.path);
        }
        set('translator',record.match(/[;；]\s*([^;.。]*?)译/)?.[1],doc.path);
        const publication=record.match(/--\s*([^:：]+)\s*[:：]\s*([^，,]+)[，,]\s*((?:19|20)\d{2})(?:[.年/-](\d{1,2}))?/);
        if(publication){set('place',publication[1],doc.path);set('publisher',publication[2],doc.path);set('date',publication[3]+(publication[4]?'-'+publication[4].padStart(2,'0'):''),doc.path);}
        set('language','zh',doc.path);
      }
      if(/书名页|title[ _-]?page/i.test(doc.name)){
        const content=lines.filter(s=>!/^#|^\[|^---$/.test(s));
        if(content[0]&&!/^ISBN/i.test(content[0]))set('title',content[0],doc.path);
        set('edition',text.match(/(?:原书)?第\s*[\d一二三四五六七八九十]+\s*版/)?.[0]?.replace(/\s+/g,''),doc.path);
        const author=lines.find(s=>/著$/.test(s));
        if(author){const latin=[...author.matchAll(/[（(]([A-Za-z][^（）()]+)[）)]/g)].map(m=>m[1]);set('author',latin.length?latin.join('；'):author.replace(/著$/,'').replace(/\[[^\]]+\]/g,''),doc.path);}
        set('translator',lines.find(s=>/译$/.test(s))?.replace(/译$/,'').trim().split(/\s+/).join('；'),doc.path);
        set('publisher',lines.find(s=>/出版社(?:[（(][^]*)?$/.test(s))?.replace(/[（(][^]*$/,''),doc.path);
      }
    }
    const best=new Map();for(const c of candidates)if(!best.has(c.isbn)||best.get(c.isbn).score<c.score)best.set(c.isbn,c);
    const unique=[...best.values()].sort((a,b)=>b.score-a.score);
    const ambiguous=unique.length>1&&unique[0].score===unique[1].score,originalOnly=unique.length>0&&unique[0].score<0;
    if(unique.length&&!ambiguous&&!originalOnly){fields.isbn=unique[0].isbn;evidence.isbn=unique[0].file;}
    const year=fields.date?.match(/(?:19|20)\d{2}/)?.[0];if(year)fields.year=year;
    return {fields,evidence,isbnCandidates:unique,warning:originalOnly?'仅找到原版 ISBN，未自动作为当前版本的书号。':ambiguous?'前置资料含多个同等可信的 ISBN，已保留书籍，请在信息栏选择本版书号。':''};
  }
}
module.exports=KnowledgeLibraryBookMetadata;
