import {Readability} from '@mozilla/readability';
import Turndown from 'turndown';
import {gfm} from 'turndown-plugin-gfm';
// Detached documents are never attached to a browsing context or executed.
export function extract(html,url,makeDocument=()=>document.implementation.createHTMLDocument('')){
 const doc=makeDocument();doc.documentElement.innerHTML=String(html);const clean=s=>String(s||'').replace(/\s+/g,' ').trim();
 const meta=(...names)=>{for(const name of names){const e=[...doc.querySelectorAll('meta')].find(e=>e.getAttribute('name')?.toLowerCase()===name||e.getAttribute('property')?.toLowerCase()===name);if(e?.content)return clean(e.content);}return '';};
 const absolute=value=>{try{const u=new URL(value,url);return ['http:','https:'].includes(u.protocol)&&!u.username&&!u.password?u.href:'';}catch{return '';}};
 const title=meta('og:title','twitter:title')||clean(doc.title),website=meta('og:site_name')||new URL(url).hostname,author=meta('author','article:author'),date=meta('article:published_time','date','dc.date','datepublished');
 const result={url,title,website,author,date:/^\d{4}-\d{2}-\d{2}(?:[T\s].*)?$/.test(date)?date:'',summary:meta('description','og:description'),images:[],warnings:[],markdown:'',text:''};
 const paperTitle=meta('citation_title'),doi=meta('citation_doi'),journal=meta('citation_journal_title'),authors=[...doc.querySelectorAll('meta[name="citation_author"]')].map(e=>clean(e.content)).filter(Boolean),pub=meta('citation_publication_date');
 if(paperTitle&&/^10\.\d{4,9}\/\S+$/i.test(doi)&&(journal||authors.length))result.paper={title:paperTitle,doi,author:authors.join('; '),publicationTitle:journal,date:pub.replace(/\//g,'-')};
 const rawText=clean(doc.body?.textContent),blocked=/^(?:access denied|forbidden|page not found|404\b|just a moment|attention required|安全验证|访问受限|登录|登陆|验证访问)/i.test(title)||!!doc.querySelector('input[type=password],#challenge-running,.cf-challenge')||[...doc.querySelectorAll('script[type="application/ld+json"]')].some(e=>/"isAccessibleForFree"\s*:\s*(?:false|"false")/i.test(e.textContent));
 if(blocked){result.error='页面需要登录、订阅或访问验证，未取得可确认的完整正文。可粘贴正文或导入 Markdown。';return result;}
 doc.querySelectorAll('script,style,noscript,iframe,form,nav,footer,aside,button,[hidden],[aria-hidden="true"],[role=navigation],[role=banner],[role=contentinfo],.advertisement,.ad-container,.cookie-banner').forEach(e=>e.remove());
 for(const e of doc.querySelectorAll('*'))for(const a of [...e.attributes])if(/^on/i.test(a.name)||['srcdoc','style'].includes(a.name))e.removeAttribute(a.name);
 for(const e of doc.querySelectorAll('a')){const href=absolute(e.getAttribute('href'));if(href)e.setAttribute('href',href);else e.removeAttribute('href');}
 for(const e of doc.querySelectorAll('img')){const value=e.getAttribute('data-src')||e.getAttribute('data-original')||e.getAttribute('src')||'';const href=absolute(value);e.removeAttribute('srcset');e.removeAttribute('sizes');if(href)e.setAttribute('src',href);else e.remove();}
 let article;try{article=new Readability(doc,{charThreshold:180,maxElemsToParse:45000,keepClasses:true}).parse();}catch{}
 if(!article?.content||clean(article.textContent).length<180){result.error=rawText.length<300?'页面正文过少或依赖动态加载，未取得完整正文。可粘贴正文或导入 Markdown。':'无法可靠识别网页正文，请粘贴正文或导入已有 Markdown。';return result;}
 const content=makeDocument();content.body.innerHTML=article.content;content.querySelectorAll('script,style,iframe,form,object,embed,svg').forEach(e=>e.remove());
 const td=new Turndown({headingStyle:'atx',codeBlockStyle:'fenced',bulletListMarker:'-',emDelimiter:'*'});td.use(gfm);
 td.addRule('web-image',{filter:'img',replacement:(_content,node)=>{const src=absolute(node.getAttribute('src'));if(!src)return '';const alt=clean(node.getAttribute('alt')).replace(/[\[\]\\]/g,''),token='ETWEBIMAGE'+result.images.length+'TOKEN';result.images.push({url:src,alt,token});return '\n\n'+token+'\n\n';}});
 result.markdown=td.turndown(content.body).trim();result.text=clean(article.textContent);result.title=result.title||clean(article.title);result.summary=result.summary||clean(article.excerpt).slice(0,500);result.author=result.author||clean(article.byline);
 if(!result.markdown||result.text.length<180){result.error='提取结果不完整，请改用粘贴正文或导入 Markdown。';result.markdown='';}return result;
}
