'use strict';
// Codex owns authentication. This bridge never reads or copies its credentials.
const PROVIDERS={
 github:{runtime:'github',connector:'connector_76869538009648d5b282a4bb21c3d157',slug:'github'},
 'google-drive':{runtime:'google_drive',connector:'connector_5f3c8c41a1e54ad7a76272c89e2554fa',slug:'google-drive'}
};
const aborted=()=>Object.assign(Error('已取消 Codex 请求'),{name:'AbortError'});
class CodexConnector {
 constructor(req,directory,options={}){this.req=req;this.dir=directory;this.options=options;}
 provider(id){const p=PROVIDERS[id];if(!p)throw Error('不支持的 Codex 插件');return p;}
 installURL(id){const p=this.provider(id);return 'https://chatgpt.com/apps/'+p.slug+'/'+p.connector;}
 executable(){
  if(this.options.executable)return this.options.executable;
  const fs=this.req('fs'),path=this.req('path'),env=this.req('process').env,base=path.join(env.LOCALAPPDATA||path.join(this.req('os').homedir(),'AppData','Local'),'OpenAI','Codex','bin');
  const files=[];
  for(const item of fs.existsSync(base)?fs.readdirSync(base,{withFileTypes:true}):[]){if(!item.isDirectory())continue;const file=path.join(base,item.name,'codex.exe');try{files.push({file,time:fs.statSync(file).mtimeMs});}catch{}}
  if(files.length)return files.sort((a,b)=>b.time-a.time)[0].file;
  for(const root of String(env.PATH||'').split(path.delimiter)){if(!root)continue;const file=path.join(root,'codex.exe');try{if(fs.statSync(file).isFile())return file;}catch{}}
  throw Error('未找到本机 Codex，请先安装并登录 Codex 桌面应用');
 }
 async session(signal,work){
  if(signal?.aborted)throw aborted();
  const fs=this.req('fs');fs.mkdirSync(this.dir,{recursive:true});
  const child=(this.options.spawn||this.req('child_process').spawn)(this.executable(),['app-server','--listen','stdio://'],{cwd:this.dir,windowsHide:true,shell:false,stdio:['pipe','pipe','pipe']});
  let next=1,buffer='',closed=false,failure;const pending=new Map();
  const fail=error=>{failure=error;for(const p of pending.values()){clearTimeout(p.timer);p.reject(error);}pending.clear();};
  const stop=()=>{if(closed)return;closed=true;child.stdin.destroy();child.kill();};
  const cancel=()=>{fail(aborted());stop();};
  const send=value=>child.stdin.write(JSON.stringify(value)+'\n');
  child.stderr.resume();child.on('error',()=>fail(Error('无法启动本机 Codex，请重新安装或更新 Codex')));
  child.on('exit',()=>fail(Error('Codex 连接进程已退出，请重试')));
  child.stdin.on('error',()=>fail(Error('Codex 通信已中断，请重试')));
  child.stdout.setEncoding('utf8');child.stdout.on('data',chunk=>{
   buffer+=chunk;if(buffer.length>8*1024*1024){fail(Error('Codex 响应过大，请缩小查询范围'));stop();return;}
   let index;while((index=buffer.indexOf('\n'))>=0){const line=buffer.slice(0,index);buffer=buffer.slice(index+1);if(!line.trim())continue;let msg;try{msg=JSON.parse(line);}catch{fail(Error('Codex 返回了无效数据，请更新 Codex'));stop();return;}
    if(msg.method&&msg.id!=null){
     // No model turns are started and only read-only tools are callable. Do not
     // silently approve any new permissions requested by the external runtime.
     send({id:msg.id,error:{code:-32601,message:'Complete this action in Codex before retrying in Typora.'}});
     fail(Error('请先在 Codex 中完成登录或授权，再回到 Typora 刷新连接'));continue;
    }
    const p=pending.get(msg.id);if(!p)continue;pending.delete(msg.id);clearTimeout(p.timer);
    if(msg.error){const raw=String(msg.error.message||'');const code=/401|unauthoriz|not logged/i.test(raw)?'请先在 Codex 登录 ChatGPT 账户':/403|forbidden/i.test(raw)?'Codex 暂时无法访问连接器，请在 Codex 中检查账户权限后重试':'Codex 请求失败，请检查网络、更新 Codex 并重新连接';p.reject(Error(code));}else p.resolve(msg.result);
   }
  });
  const rpc=(method,params={})=>new Promise((resolve,reject)=>{
   if(signal?.aborted)return reject(aborted());if(failure||closed)return reject(failure||Error('Codex 连接已关闭'));
   const id=next++,timer=setTimeout(()=>{pending.delete(id);reject(Error('Codex 请求超时，请检查网络并重试'));},this.options.requestTimeout||60000);
   pending.set(id,{resolve,reject,timer});try{send({id,method,params});}catch{clearTimeout(timer);pending.delete(id);reject(Error('Codex 通信失败'));}
  });
  const deadline=setTimeout(()=>{fail(Error('Codex 连接超时，请重试'));stop();},this.options.sessionTimeout||120000);
  signal?.addEventListener('abort',cancel,{once:true});
  try{
   await rpc('initialize',{clientInfo:{name:'typora_editing_toolbar',title:'Typora Editing Toolbar',version:'1.98.0'},capabilities:{experimentalApi:true}});send({method:'initialized',params:{}});
   const auth=await rpc('account/read',{refreshToken:false});if(auth?.account?.type!=='chatgpt')throw Error('请先在 Codex 中登录 ChatGPT 账户，API Key 登录不能使用此连接方式');
   const tag=this.req('crypto').createHash('sha256').update(JSON.stringify([auth.account.type,auth.account.email||'',auth.account.id||''])).digest('hex');
   return await work(rpc,tag);
  }finally{clearTimeout(deadline);signal?.removeEventListener('abort',cancel);fail(aborted());stop();}
 }
 async inventory(rpc,id,threadId){
  const p=this.provider(id),installed=await rpc('app/installed',threadId?{threadId}:{});
  const apps=installed.data||installed.apps||[];
  const app=apps.find(a=>a.id===p.connector);
  if(!app||app.enabled!==true||app.callable!==true)return {accounts:[],tools:[]};
  let cursor,tools=[];do{
   const result=await rpc('mcpServerStatus/list',{detail:'toolsAndAuthOnly',serverName:'codex_apps',...(threadId?{threadId}:{}),...(cursor?{cursor}:{})});
   for(const server of result.data||[]){if(server.name!=='codex_apps')continue;for(const [key,tool] of Object.entries(server.tools||{})){if(tool._meta?.connector_id===p.connector)tools.push({...tool,callName:tool.name||key});}}
   cursor=result.nextCursor;
  }while(cursor);
  const accounts=[];
  for(const tool of tools){const meta=tool._meta;if(meta.resource_name!==p.runtime+'.get_profile'||!meta.link_id||accounts.some(a=>a.key===meta.link_id)||tool.annotations?.readOnlyHint!==true||tool.annotations?.destructiveHint===true)continue;const user=meta.link_owner_profile||{};accounts.push({key:meta.link_id,connectorId:p.connector,providerId:String(user.id||''),account:String(user.email||user.nickname||user.name||'Codex 账户'),avatar:String(user.picture||'')});}
  return {accounts,tools};
 }
 async discover(id,signal){this.provider(id);return this.session(signal,async rpc=>{const {accounts}=await this.inventory(rpc,id);return {accounts,installUrl:this.installURL(id)};});}
 async thread(rpc){const result=await rpc('thread/start',{ephemeral:true,cwd:this.dir,sandbox:'read-only',approvalPolicy:'on-request',baseInstructions:'Local read-only connector transport. No model turn.',config:{'features.apps':true}});if(!result?.thread?.id)throw Error('Codex 版本不支持连接器通道，请更新 Codex');return result.thread.id;}
 async call(rpc,threadId,id,key,tools,action,args){
  const p=this.provider(id),matches=tools.filter(t=>t._meta?.connector_id===p.connector&&t._meta?.link_id===key&&t._meta?.resource_name===p.runtime+'.'+action);
  const tool=matches.length===1?matches[0]:null;
  if(!tool||tool.annotations?.readOnlyHint!==true||tool.annotations?.destructiveHint===true)throw Error('Codex 未提供此账户的只读功能，请在 Codex 检查连接并刷新');
  const result=await rpc('mcpServer/tool/call',{threadId,server:'codex_apps',tool:tool.callName,arguments:args});
  if(result?.isError)throw Error('Codex 插件读取失败，请检查资源访问权限或重新连接账户');
  if(result?.structuredContent!=null)return result.structuredContent;
  const content=(result?.content||[]).filter(c=>c.type==='text').map(c=>c.text).join('\n');
  try{return JSON.parse(content);}catch{return {content};}
 }
 async connect(id,key,signal){return this.session(signal,async(rpc,tag)=>{
  const threadId=await this.thread(rpc),{accounts,tools}=await this.inventory(rpc,id,threadId),account=key?accounts.find(a=>a.key===key):accounts.length===1?accounts[0]:null;
  if(!account)throw Error(accounts.length?'请选择要连接的 Codex 账户':'请先在 Codex 中连接此插件账户，然后刷新');
  const user=await this.call(rpc,threadId,id,account.key,tools,'get_profile',{});
  if(!user?.id||account.providerId&&String(user.id)!==account.providerId)throw Error('Codex 返回的账户与选择不符，请刷新后重试');
  if(signal?.aborted)throw aborted();
  return {...account,providerId:String(user.id),account:String(user.email||user.nickname||user.name||account.account),avatar:String(user.picture||account.avatar),codexAccountTag:tag,checkedAt:new Date().toISOString()};
 });}
 mapping(id,args){
  const action=args.action,p=this.provider(id),query=()=>{if(typeof args.query!=='string'||args.query.length>1000)throw Error('搜索词无效');return args.query;};
  if(id==='github'){
   if(action==='repos')return ['list_repositories',{page_size:50,page_offset:0}];
   if(action==='issues')return ['search_issues',{query:query(),topn:30}];
   const parts=String(args.repo||'').split('/');if(parts.length!==2||parts.some(x=>!/^[-\w.]+$/.test(x)||x==='.'||x==='..'))throw Error('仓库格式应为 owner/repo');
   const repository_full_name=parts.join('/');
   if(action==='repo')return ['get_repo',{repository_full_name}];
   if(action==='file'){if(typeof args.path!=='string'||args.path.length>1000||args.path.split('/').some(x=>!x||x==='.'||x==='..')||/[\\\x00-\x1f]/.test(args.path))throw Error('文件路径无效');return ['fetch_file',{repository_full_name,path:args.path,...(args.ref?{ref:String(args.ref).slice(0,200)}:{})}];}
   if(action==='pull_request'){if(!Number.isInteger(args.number)||args.number<1)throw Error('PR 编号无效');return ['fetch_pr',{repo_full_name:repository_full_name,pr_number:args.number}];}
  }else{
   if(action==='search')return ['search',{query:query(),topn:40,best_effort_fetch:false,...(args.pageToken?{page_token:String(args.pageToken).slice(0,2000)}:{})}];
   if(action==='file'){if(typeof args.fileId!=='string'||!/^[-\w]{1,200}$/.test(args.fileId))throw Error('Drive 文件 ID 无效');return ['fetch',{url:'https://drive.google.com/file/d/'+args.fileId+'/view'}];}
  }
  throw Error('不支持的 Codex 只读操作：'+p.slug);
 }
 async read(id,connection,args,signal){const [action,input]=this.mapping(id,args);return this.session(signal,async(rpc,tag)=>{
  if(tag!==connection.codexAccountTag)throw Error('Codex 登录账户已更换，请重新连接插件');
  const threadId=await this.thread(rpc),{accounts,tools}=await this.inventory(rpc,id,threadId),account=accounts.find(a=>a.key===connection.key&&a.connectorId===connection.connectorId);
  if(!account||account.providerId!==connection.providerId)throw Error('Codex 中的账户连接已变更，请重新连接插件');
  return this.call(rpc,threadId,id,connection.key,tools,action,input);
 });}
}
module.exports=CodexConnector;
