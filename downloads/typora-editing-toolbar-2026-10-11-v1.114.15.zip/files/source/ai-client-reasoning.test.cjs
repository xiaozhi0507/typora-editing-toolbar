const {test}=require('node:test'),assert=require('node:assert/strict'),http=require('node:http');
const Client=require('./ai-client.cjs');
const sse=packets=>packets.map(p=>'data: '+(typeof p==='string'?p:JSON.stringify(p))+'\n\n').join('');
async function fixture(t,protocol,data,options={}){
  const server=http.createServer((req,res)=>{req.resume();res.writeHead(200,{'Content-Type':options.json?'application/json':'text/event-stream'});const bytes=Buffer.from(options.json?JSON.stringify(data):sse(data));if(options.hold){res.write(bytes);return;}for(let i=0;i<bytes.length;i+=7)res.write(bytes.subarray(i,i+7));res.end();});
  await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>{server.closeAllConnections();server.close();});
  return {client:new Client(require),profile:{model:'mock',url:'http://127.0.0.1:'+server.address().port,protocol},messages:[{role:'user',content:'test'}]};
}
test('Chat SSE keeps reasoning_content separate, including fragmented UTF-8 and mixed deltas',async t=>{
  const f=await fixture(t,'openai-chat',[{choices:[{delta:{reasoning_content:'先看条件：'}}]},{choices:[{delta:{reasoning_content:'α > 0',content:'**结论**'}}]},{choices:[{delta:{content:'：成立。'},finish_reason:'stop'}]},'[DONE]']);
  const thoughts=[],answers=[],r=await f.client.request(f.profile,'',f.messages,{onText:s=>answers.push(s),onReasoning:(s,k)=>thoughts.push([s,k])});
  assert.equal(r.text,'**结论**：成立。');assert.equal(r.reasoning,'先看条件：α > 0');assert.equal(thoughts.at(-1)[1],'thinking');assert.equal(thoughts.length,2);assert.ok(answers.every(s=>!s.includes('先看')));
});
test('Chat JSON and compatible reasoning alias retain only string thinking',async t=>{
  const f=await fixture(t,'openai-chat',{choices:[{message:{reasoning:'草稿',content:'回答'},finish_reason:'stop'}]},{json:true});
  assert.equal((await f.client.request(f.profile,'',f.messages)).reasoning,'草稿');
});
test('Responses summary deltas, done events, multiple parts and final snapshot are not duplicated',async t=>{
  const reasoning={id:'r1',type:'reasoning',summary:[{type:'summary_text',text:'检查 A。'},{type:'summary_text',text:'验证 B。'}],encrypted_content:'NEVER DISPLAY'};
  const f=await fixture(t,'openai-responses',[
    {type:'response.reasoning_summary_text.delta',item_id:'r1',summary_index:0,delta:'检查 '},
    {type:'response.reasoning_summary_text.delta',item_id:'r1',summary_index:0,delta:'A。'},
    {type:'response.reasoning_summary_text.done',item_id:'r1',summary_index:0,text:'检查 A。'},
    {type:'response.reasoning_summary_text.delta',item_id:'r1',summary_index:1,delta:'验证 B。'},
    {type:'response.output_text.delta',delta:'答案'},
    {type:'response.completed',response:{status:'completed',output:[reasoning,{type:'message',content:[{type:'output_text',text:'答案'}]}]}}
  ]);const updates=[],r=await f.client.request(f.profile,'',f.messages,{onReasoning:s=>updates.push(s)});
  assert.equal(r.reasoning,'检查 A。\n\n验证 B。');assert.equal(r.reasoningKind,'summary');assert.equal(r.text,'答案');assert.equal(updates.length,3);assert.ok(!JSON.stringify(r).includes('NEVER'));
});
test('Responses nonstream summary and explicit reasoning_text are supported',async t=>{
  const f=await fixture(t,'openai-responses',{status:'completed',output:[{type:'reasoning',summary:[{type:'summary_text',text:'摘要'}]},{type:'message',content:[{type:'output_text',text:'答案'}]}]},{json:true});
  const r=await f.client.request(f.profile,'',f.messages);assert.equal(r.reasoning,'摘要');assert.equal(r.reasoningKind,'summary');
  const g=await fixture(t,'openai-responses',[{type:'response.reasoning_text.delta',item_id:'r',content_index:0,delta:'过程'},{type:'response.output_text.delta',delta:'完成'},{type:'response.completed',response:{status:'completed'}}]);
  const q=await g.client.request(g.profile,'',g.messages);assert.equal(q.reasoning,'过程');assert.equal(q.reasoningKind,'thinking');
});
test('Anthropic thinking blocks stream separately; signatures and redacted blocks stay hidden',async t=>{
  const f=await fixture(t,'anthropic-messages',[
    {type:'content_block_start',index:0,content_block:{type:'thinking',thinking:'先'}},
    {type:'content_block_delta',index:0,delta:{type:'thinking_delta',thinking:'检查'}},
    {type:'content_block_delta',index:0,delta:{type:'signature_delta',signature:'SECRET_SIGNATURE'}},
    {type:'content_block_start',index:1,content_block:{type:'redacted_thinking',data:'REDACTED'}},
    {type:'content_block_start',index:2,content_block:{type:'text',text:''}},
    {type:'content_block_delta',index:2,delta:{type:'text_delta',text:'回答'}},
    {type:'message_delta',delta:{stop_reason:'end_turn'}},{type:'message_stop'}
  ]);const r=await f.client.request(f.profile,'',f.messages);assert.equal(r.reasoning,'先检查');assert.equal(r.text,'回答');assert.ok(!JSON.stringify(r).includes('SECRET'));assert.ok(!JSON.stringify(r).includes('REDACTED'));
});
test('Anthropic JSON supports thinking and leaves ordinary responses empty',async t=>{
  const f=await fixture(t,'anthropic-messages',{content:[{type:'thinking',thinking:'一步'},{type:'thinking',thinking:'二步'},{type:'text',text:'结果'}],stop_reason:'end_turn'},{json:true});
  assert.equal((await f.client.request(f.profile,'',f.messages)).reasoning,'一步\n\n二步');
  const g=await fixture(t,'openai-chat',[{choices:[{delta:{content:'普通回答'},finish_reason:'stop'}]},'[DONE]']);
  let called=false;const r=await g.client.request(g.profile,'',g.messages,{onReasoning:()=>called=true});assert.equal(r.reasoning,'');assert.equal(called,false);
});
test('thinking-only completion and interrupted streams preserve callback text but do not report a complete answer',async t=>{
  const f=await fixture(t,'openai-chat',[{choices:[{delta:{reasoning_content:'尚未完成'},finish_reason:'length'}]},'[DONE]']);
  let text='';await assert.rejects(f.client.request(f.profile,'',f.messages,{onReasoning:s=>text=s}),/只返回了思考内容.*输出上限/);assert.equal(text,'尚未完成');
  const g=await fixture(t,'openai-chat',[{choices:[{delta:{reasoning_content:'中断'}}]}]);
  await assert.rejects(g.client.request(g.profile,'',g.messages),/连接提前结束/);
});
test('abort during thinking retains received text and rejects with AbortError',async t=>{
  const f=await fixture(t,'openai-chat',[{choices:[{delta:{reasoning_content:'已收到'}}]}],{hold:true}),controller=new AbortController();let text='';
  await assert.rejects(f.client.request(f.profile,'',f.messages,{signal:controller.signal,onReasoning:s=>{text=s;controller.abort();}}),{name:'AbortError'});assert.equal(text,'已收到');
});
