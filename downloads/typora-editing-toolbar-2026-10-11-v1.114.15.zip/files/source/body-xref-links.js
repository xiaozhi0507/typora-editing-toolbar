// Resolve publisher anchors only against the current document's local index.
class EditingToolbarXrefLinks {
 constructor(doc, records) {
  this.records=records;this.aliases=new Map();this.ambiguous=new Set();
  try{const url=new URL(doc.source_url);if(url.protocol==='https:'&&url.hostname==='www.sciencedirect.com'&&/^\/science\/article\/pii\/[^/]+$/.test(url.pathname))this.source=url;}catch{}
  const add=(key,id)=>{
   if(typeof key!=='string'||!key||key.length>250||/[\s#/?\\<>]/u.test(key)||this.ambiguous.has(key))return;
   if(this.aliases.has(key)&&this.aliases.get(key)!==id){this.aliases.delete(key);this.ambiguous.add(key);}else this.aliases.set(key,id);
  };
  for(const target of (Array.isArray(doc.targets)?doc.targets:[]).slice(0,20000)){
   if(!target||!records.has(target.id))continue;
   for(const key of (Array.isArray(target.source_ids)?target.source_ids:[]).slice(0,100))add(key,target.id);
   // Older ScienceDirect exports recorded #bb0105 as ref--bb0105, while
   // citation links used #b0105. Accept only this publisher's known aliases.
   if(this.source&&target.kind==='reference'){
    const legacy=target.id.match(/^ref--?(b{1,3}\d+|b?bib\d+|sbref\d+)$/i)?.[1];
    if(legacy)for(const key of EditingToolbarXrefLinks.referenceAliases(legacy))add(key,target.id);
   }
  }
 }
 static referenceAliases(id){
  const match=id.match(/^(?:b{1,3}|b?bib|sbref)(\d+)$/i);
  if(!match)return [id];
  const family=/^(?:b?bib|sbref)/i.test(id)?['bib','bbib','sbref']:['b','bb','bbb'];
  return [...new Set([id,...family.map(prefix=>prefix+match[1])])];
 }
 static candidate(href){
  if(typeof href!=='string')return false;
  if(/^#(?:ref|fig|tab|table)-[^\s]+$/u.test(href))return true;
  try{const url=new URL(href);return url.protocol==='https:'&&url.hostname==='www.sciencedirect.com'&&/^\/science\/article\/pii\/[^/]+$/.test(url.pathname)&&!!url.hash;}catch{return /^#(?:b{1,3}\d+|b?bib\d+|sbref\d+|[ft]\d+)$/i.test(href);}
 }
 resolve(href){
  if(typeof href!=='string')return null;
  let fragment;
  if(href.startsWith('#'))fragment=href.slice(1);
  else{
   if(!this.source)return null;
   try{const url=new URL(href);if(url.origin!==this.source.origin||url.pathname!==this.source.pathname||url.search!==this.source.search||url.username||url.password)return null;fragment=url.hash.slice(1);}catch{return null;}
  }
  try{fragment=decodeURIComponent(fragment);}catch{return null;}
  return this.records.has(fragment)?fragment:this.aliases.get(fragment)||null;
 }
}
