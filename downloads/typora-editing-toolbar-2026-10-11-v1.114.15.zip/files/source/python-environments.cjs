'use strict';
// Python state is separate from terminal appearance, so an older window cannot
// overwrite an environment choice when it saves its size or position.
const KEY='et-python-environments-v1';
const PACKAGES=['numpy','pandas','matplotlib','seaborn','scipy','ipykernel','jupyter_client'];
const INSTALLER={version:'3.13.16',x64:{suffix:'amd64',sha256:'fb4f9f5d438b2396da0086dc70b935c530cb578e37adc6d354f7ad2037fee83b'},arm64:{suffix:'arm64',sha256:'696e2226062c6ec3622c13f143d28336a856968518e49cb4f4c62513215a4f5d'}};
const PROBE=`import sys
sys.path=[p for p in sys.path if p]
import json,importlib,struct,io
r={'exe':sys.executable,'version':'.'.join(map(str,sys.version_info[:3])),'bits':struct.calcsize('P')*8,'prefix':sys.prefix,'base':sys.base_prefix,'packages':{}}
for n in ${JSON.stringify(PACKAGES)}:
 try:
  m=importlib.import_module(n)
  r['packages'][n]={'ok':True,'version':str(getattr(m,'__version__',''))}
 except Exception as e:
  r['packages'][n]={'ok':False,'error':type(e).__name__+': '+str(e)[:180]}
r['plotReady']=False
if r['packages']['matplotlib']['ok']:
 try:
  from matplotlib.figure import Figure
  from matplotlib.backends.backend_agg import FigureCanvasAgg
  f=Figure(figsize=(1,1)); FigureCanvasAgg(f); f.add_subplot().plot([0,1],[0,1]); f.savefig(io.BytesIO(),format='png'); r['plotReady']=True
 except Exception as e: r['plotError']=type(e).__name__+': '+str(e)[:180]
print('ET_PYTHON_INFO:'+json.dumps(r,ensure_ascii=True))`;
// Data arrives on stdin; paths and network addresses are never evaluated as shell code.
const DOWNLOAD_PS=`$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; [Console]::InputEncoding=New-Object Text.UTF8Encoding; [Console]::OutputEncoding=New-Object Text.UTF8Encoding; $p=[Console]::In.ReadToEnd()|ConvertFrom-Json
try {
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
$r=[Net.HttpWebRequest]::Create([string]$p.url); $r.AllowAutoRedirect=$false; $r.Timeout=30000; $r.ReadWriteTimeout=60000
if($p.proxy){$r.Proxy=New-Object Net.WebProxy([string]$p.proxy)}
$response=$r.GetResponse(); if([int]$response.StatusCode -ne 200){throw 'Download HTTP error'}
$inputStream=$response.GetResponseStream(); $outputStream=[IO.File]::Open([string]$p.file,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write)
try{$buffer=New-Object byte[] 65536; $count=0L; $last=0L; while(($n=$inputStream.Read($buffer,0,$buffer.Length)) -gt 0){$count+=$n; if($count -gt 83886080){throw 'Download too large'}; $outputStream.Write($buffer,0,$n); if($count-$last -ge 1048576){[Console]::Out.WriteLine('ET_DOWNLOAD:'+$count);$last=$count}}}
finally{$outputStream.Dispose();$inputStream.Dispose();$response.Dispose()}
} catch { [Console]::Error.WriteLine('Python download interrupted. Please check your network or proxy.'); exit 1 }`;
const abortError=()=>Object.assign(Error('已取消，原有默认环境保持不变'),{name:'AbortError'});
const clean=value=>String(value||'').replace(/(https?:\/\/)[^\s/@]+(?::[^\s/@]*)?@/gi,'$1***@').replace(/\x1b\[[0-9;]*[A-Za-z]/g,'');
class Manager {
 constructor(req,{storage,directory,legacy={},environment}={}){
  this.req=req;this.path=req('path');this.fs=req('fs').promises;this.storage=storage;this.environment=environment;this.directory=this.path.resolve(directory);this.cache=new Map();this.busy=false;
  if(!storage.getItem(KEY)){const projects={};for(const [root,exe]of Object.entries(legacy))if(this.valid(exe))projects[this.key(root)]=exe;storage.setItem(KEY,JSON.stringify({version:1,global:'',projects,known:[]}));}
 }
 key(value){return this.path.resolve(value).toLowerCase();}
 valid(exe){return typeof exe==='string'&&this.path.isAbsolute(exe)&&/^python\.exe$/i.test(this.path.basename(exe))&&!/[/\\]Microsoft[/\\]WindowsApps[/\\]/i.test(exe);}
 read(){let s;try{s=JSON.parse(this.storage.getItem(KEY));}catch{}return {version:1,global:typeof s?.global==='string'?s.global:'',projects:s?.projects&&typeof s.projects==='object'&&!Array.isArray(s.projects)?s.projects:{},known:Array.isArray(s?.known)?s.known.filter(p=>this.valid(p)):[]};}
 change(fn){const s=this.read();fn(s);this.storage.setItem(KEY,JSON.stringify(s));}
 choice(root){const s=this.read();return root&&s.projects[this.key(root)]||s.global||'';}
 remember(exe){if(!this.valid(exe))throw Error('请选择 python.exe');this.change(s=>{s.known=[exe,...s.known.filter(p=>this.key(p)!==this.key(exe))].slice(0,64);});}
 async select(exe,{project}={}){
  if(exe){const info=await this.inspect(exe);if(info.error)throw Error(info.error);this.remember(exe);}
  this.change(s=>{if(project){if(exe)s.projects[this.key(project)]=exe;else delete s.projects[this.key(project)];}else s.global=exe||'';});
 }
 async exists(file){try{return(await this.fs.stat(file)).isFile();}catch{return false;}}
 async children(dir){try{return(await this.fs.readdir(dir,{withFileTypes:true})).filter(e=>e.isDirectory()).map(e=>this.path.join(dir,e.name));}catch{return [];}}
 async candidates(roots=[]){
  const p=this.path,env=this.req('process').env,s=this.read(),out=new Map(),add=exe=>{if(this.valid(exe)&&out.size<96)out.set(this.key(exe),exe);},local=root=>{for(const name of ['.venv','venv','.env','env','.conda']){add(p.join(root,name,'Scripts','python.exe'));add(p.join(root,name,'python.exe'));}};
  for(const exe of [s.global,...Object.values(s.projects),...s.known,p.join(this.directory,'scientific','Scripts','python.exe')])if(exe)add(exe);
  for(const root of roots)local(root);
  const pathKey=Object.keys(env).find(k=>k.toLowerCase()==='path');for(const dir of String(env[pathKey]||'').split(';').map(x=>x.trim().replace(/^"|"$/g,'')))if(p.isAbsolute(dir))add(p.join(dir,'python.exe'));
  const home=env.USERPROFILE||this.req('os').homedir();
  for(const parent of [env.LOCALAPPDATA&&p.join(env.LOCALAPPDATA,'Programs','Python'),env.ProgramFiles,env['ProgramFiles(x86)']].filter(Boolean))for(const dir of await this.children(parent))if(/python/i.test(p.basename(dir)))add(p.join(dir,'python.exe'));
  let conda=[];try{conda=(await this.fs.readFile(p.join(home,'.conda','environments.txt'),'utf8')).split(/\r?\n/).map(x=>x.trim()).filter(x=>p.isAbsolute(x));}catch{}
  for(const root of [...conda,p.join(home,'miniconda3'),p.join(home,'anaconda3'),env.CONDA_PREFIX].filter(Boolean)){add(p.join(root,'python.exe'));for(const dir of await this.children(p.join(root,'envs')))add(p.join(dir,'python.exe'));}
  // A PATH entry can be either a conda root or its Scripts/condabin directory.
  for(const exe of [...out.values()]){const dir=p.dirname(exe),root=/^(scripts|condabin)$/i.test(p.basename(dir))?p.dirname(dir):dir;if(await this.exists(p.join(root,'conda-meta','history'))){add(p.join(root,'python.exe'));for(const sub of await this.children(p.join(root,'envs')))add(p.join(sub,'python.exe'));}}
  return [...out.values()].filter(exe=>this.valid(exe));
 }
 async discover(roots=[]){
  const candidates=await this.candidates(roots),saved=this.read(),configured=new Set([saved.global,...Object.values(saved.projects),...saved.known].filter(Boolean).map(x=>this.key(x))),rows=[];
  // Limit imports to two Python processes at a time; slow imports never block the renderer.
  let at=0;await Promise.all([0,1].map(async()=>{while(at<candidates.length){const exe=candidates[at++];if(await this.exists(exe)||configured.has(this.key(exe)))rows.push(await this.inspect(exe));}}));
  return rows.sort((a,b)=>Number(this.key(b.exe)===this.key(saved.global||this.directory))-Number(this.key(a.exe)===this.key(saved.global||this.directory))||a.exe.localeCompare(b.exe));
 }
 async inspect(exe,{fresh=false}={}){
  if(!this.valid(exe))return {exe,error:'请选择有效的 python.exe'};
  const cached=this.cache.get(this.key(exe));if(!fresh&&cached&&cached.until>Date.now())return cached.value;
  let value;try{
   if(!await this.exists(exe))throw Error('路径不存在，请重新选择环境');
   const python=await this.environment.pythonEnvironment(this.req,this.path.dirname(exe),exe),env=this.environment.environmentVariables(this.req('process').env,python);
   const out=await this.run(exe,['-E','-c',PROBE],{env,timeout:45000});const line=out.split(/\r?\n/).find(x=>x.startsWith('ET_PYTHON_INFO:'));if(!line)throw Error('解释器没有返回环境信息');
   const info=JSON.parse(line.slice(15));if(!/^\d+\.\d+\.\d+$/.test(info.version)||!info.packages)throw Error('解释器信息不完整');
   value={...info,exe,kind:python.kind,ready:PACKAGES.every(n=>info.packages[n]?.ok)&&!!info.plotReady};
  }catch(e){value={exe,error:clean(e.message)};}
  this.cache.set(this.key(exe),{until:Date.now()+60000,value});return value;
 }
 run(exe,args,{env,timeout=600000,signal,onOutput,input,accepted=[0]}={}){
  return new Promise((resolve,reject)=>{
   let child,done=false,out='',err='',timer,stopping;const finish=(error)=>{if(done)return;done=true;clearTimeout(timer);signal?.removeEventListener('abort',abort);error?reject(error):resolve(out);};
   const stop=error=>{if(done||stopping)return;stopping=error;clearTimeout(timer);if(this.req('process').platform==='win32'&&Number.isInteger(child?.pid)){
    this.req('child_process').execFile(this.path.join(this.req('process').env.SystemRoot||'C:\\Windows','System32','taskkill.exe'),['/PID',String(child.pid),'/T','/F'],{windowsHide:true,timeout:8000},()=>{try{child.kill();}catch{}finish(error);});
   }else{try{child?.kill();}catch{}finish(error);}},abort=()=>stop(abortError());
   if(signal?.aborted)return abort();
   try{child=this.req('child_process').spawn(exe,args,{windowsHide:true,shell:false,env:env||this.req('process').env,stdio:['pipe','pipe','pipe']});
    signal?.addEventListener('abort',abort,{once:true});timer=setTimeout(()=>stop(Error('操作超时，请检查网络后重试')),timeout);
    child.stdout.on('data',b=>{const text=clean(b.toString());out=(out+text).slice(-131072);onOutput?.(text);});child.stderr.on('data',b=>{const text=clean(b.toString());err=(err+text).slice(-8192);onOutput?.(text);});
    child.on('error',e=>finish(stopping||Error('无法启动：'+clean(e.message))));child.on('close',code=>{if(!stopping)finish(accepted.includes(code)?null:Error((err||out||'进程退出码 '+code).slice(-2000)));});
    child.stdin.on('error',()=>{});child.stdin.end(input||'');
   }catch(e){finish(e);}
  });
 }
 powershell(){return this.path.join(this.req('process').env.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');}
 async proxy(){
  const env=this.req('process').env,explicit=env.HTTPS_PROXY||env.https_proxy||env.HTTP_PROXY||env.http_proxy;let proxy=explicit;
  if(!proxy){const script="$u=[Uri]'https://pypi.org/';$p=[Net.WebRequest]::GetSystemWebProxy().GetProxy($u);if($p.AbsoluteUri -ne $u.AbsoluteUri){[Console]::Out.Write($p.AbsoluteUri)}";try{proxy=(await this.run(this.powershell(),['-NoProfile','-NonInteractive','-Command',script],{timeout:10000})).trim();}catch{}}
  if(!proxy)return '';const u=new URL(proxy);if(!['http:','https:'].includes(u.protocol))throw Error('请为安装设置 HTTP 或 HTTPS 代理');return u.href;
 }
 async downloadInstaller(file,spec,{signal,report,attempt=0}={}){
  const url='https://www.python.org/ftp/python/'+INSTALLER.version+'/python-'+INSTALLER.version+'-'+spec.suffix+'.exe';
  const partial=file+'.'+this.req('crypto').randomBytes(6).toString('hex')+'.part';
  try{await this.run(this.powershell(),['-NoProfile','-NonInteractive','-EncodedCommand',this.req('buffer').Buffer.from(DOWNLOAD_PS,'utf16le').toString('base64')],{signal,timeout:1800000,input:JSON.stringify({url,file:partial,proxy:await this.proxy()}),onOutput:text=>{for(const match of text.matchAll(/ET_DOWNLOAD:(\d+)/g))report?.('正在下载 Python · '+Math.round(Number(match[1])/1048576)+' MB');}});
   const digest=this.req('crypto').createHash('sha256').update(await this.fs.readFile(partial)).digest('hex');if(digest!==spec.sha256)throw Error('Python 安装包校验失败，请重试');
   await this.fs.rename(partial,file);
  }catch(e){if(signal?.aborted||e.name==='AbortError')throw abortError();if(attempt<1){await this.fs.unlink(partial).catch(()=>{});report?.('下载中断，正在重试…');return this.downloadInstaller(file,spec,{signal,report,attempt:attempt+1});}throw Error(/校验/.test(e.message)?e.message:'Python 下载失败，请检查网络或代理后重试，也可从官网下载并选择解释器');}finally{await this.fs.unlink(partial).catch(()=>{});}
 }
 async lock(){
  await this.fs.mkdir(this.directory,{recursive:true});const file=this.path.join(this.directory,'install.lock');
  for(let attempt=0;attempt<2;attempt++)try{const h=await this.fs.open(file,'wx');await h.writeFile(JSON.stringify({pid:this.req('process').pid}));await h.close();return ()=>this.fs.unlink(file).catch(()=>{});}catch(e){if(e.code!=='EEXIST')throw e;let old;try{old=JSON.parse(await this.fs.readFile(file,'utf8'));}catch{throw Error('安装锁尚未就绪，请稍后重试');}if(!Number.isInteger(old.pid)||old.pid<=0)throw Error('安装锁无效，请检查 Python 环境目录');try{this.req('process').kill(old.pid,0);throw Error('另一个窗口正在安装，请等待完成');}catch(check){if(check.code!=='ESRCH')throw check;}await this.fs.unlink(file).catch(()=>{});}
  throw Error('无法获取安装锁，请稍后重试');
 }
 async packages(exe,{signal,report}={}){
  report?.('正在安装基础科研包…');const python=await this.environment.pythonEnvironment(this.req,this.path.dirname(exe),exe),env=this.environment.environmentVariables(this.req('process').env,python),proxy=await this.proxy();
  const args=['-E','-m','pip','--isolated','--disable-pip-version-check','install','--index-url','https://pypi.org/simple','--only-binary=:all:','--retries','2','--timeout','30',...(proxy?['--proxy',proxy]:[]),...PACKAGES];
  try{await this.run(exe,args,{env,signal,timeout:1800000,onOutput:text=>report?.(text,true)});}catch(e){
   if(signal?.aborted||e.name==='AbortError')throw abortError();
   if(/hashes|ProxyError|ConnectionError|ReadTimeout|connection|download/i.test(e.message)){report?.('下载未完成，正在绕过缓存重试…');try{await this.run(exe,[...args.slice(0,-PACKAGES.length),'--no-cache-dir',...PACKAGES],{env,signal,timeout:1800000,onOutput:text=>report?.(text,true)});}catch(retry){if(signal?.aborted||retry.name==='AbortError')throw abortError();throw Error('科研包下载失败或校验未通过，请检查网络或代理后重试；原默认环境未改变');}}
   else throw Error('科研包安装失败，请查看安装输出；可重新选择环境或一键安装独立环境');
  }
  if(signal?.aborted)throw abortError();report?.('正在验证绘图与 Notebook…');const info=await this.inspect(exe,{fresh:true});
  if(!info.ready)throw Error(info.error||'安装后仍有不可用的包：'+PACKAGES.filter(n=>!info.packages?.[n]?.ok).join('、')+(info.plotError?'；'+info.plotError:''));return info;
 }
 async operation(work){if(this.busy)throw Error('已有安装任务正在进行');this.busy=true;const controller=this.controller=new AbortController();let release;try{release=await this.lock();return await work(controller.signal);}finally{await release?.();this.busy=false;this.controller=null;this.cache.clear();}}
 cancel(){this.controller?.abort();}
 async repair(exe,{report}={}){return this.operation(signal=>this.packages(exe,{signal,report}));}
 async install({roots=[],report}={}){
  return this.operation(async signal=>{
   const check=()=>{if(signal.aborted)throw abortError();};check();report?.('正在检查可用的 Python…');
   const p=this.path,envRoot=p.join(this.directory,'scientific'),exe=p.join(envRoot,'Scripts','python.exe'),marker=p.join(envRoot,'et-managed.json');
   let owned=false;try{owned=JSON.parse(await this.fs.readFile(marker,'utf8')).format==='typora-scientific-environment';}catch{}
   try{if((await this.fs.readdir(envRoot)).length&&!owned)throw Error('科研环境目录已有其他文件，请选择现有解释器');}catch(e){if(e.code!=='ENOENT')throw e;}
   if(!await this.exists(exe)){
    const rows=await this.discover(roots);check();let base=rows.find(r=>!r.error&&Number(r.version.split('.')[0])===3&&Number(r.version.split('.')[1])>=10&&r.bits===64)?.exe;
    if(!base){
     const process=this.req('process'),spec=INSTALLER[process.arch];if(process.platform!=='win32'||!spec)throw Error('一键安装支持 Windows 64 位；请手动选择 Python 环境');
     const runtime=p.join(this.directory,'python-'+INSTALLER.version),installer=p.join(this.directory,'python-'+INSTALLER.version+'-'+spec.suffix+'.exe');base=p.join(runtime,'python.exe');
     if(!await this.exists(base)){
      report?.('正在下载 Python…');await this.downloadInstaller(installer,spec,{signal,report});check();
      report?.('正在安装 Python；取消请求将在此步骤完成后生效');
      await this.run(installer,['/quiet','InstallAllUsers=0','TargetDir='+runtime,'PrependPath=0','AppendPath=0','Include_launcher=0','Include_test=0','Include_doc=0','Shortcuts=0','AssociateFiles=0','Include_pip=1'],{timeout:600000,accepted:[0,3010]});check();
      if(!await this.exists(base))throw Error('Python 安装未完成，请从官网下载后重新检测');
     }
    }
    check();await this.fs.mkdir(envRoot,{recursive:true});await this.fs.writeFile(marker,JSON.stringify({format:'typora-scientific-environment',version:1}));report?.('正在创建科研环境…');
    await this.run(base,['-I','-m','venv',envRoot],{signal,timeout:180000});
   }
   const info=await this.packages(exe,{signal,report});check();await this.select(exe);report?.('安装完成，已设为全局默认环境');return info;
  });
 }
}
module.exports={Manager,KEY,PACKAGES,INSTALLER,PROBE};
