const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {JSDOM}=require('jsdom');

function fixture({wrapped=true,panelHeight=800,chatHeight=750,naturalHeight=96}={}){
 const dom=new JSDOM('<section id="panel"><div id="chat">'+(wrapped?'<div id="viewport"><div id="messages"></div></div>':'<div id="messages"></div>')+'<nav></nav><aside hidden></aside><div id="composer"><div id="input" contenteditable="true">第一段\n第二段\n第三段</div></div></div></section>');
 const d=dom.window.document,panel=d.querySelector('#panel'),chat=d.querySelector('#chat'),messages=d.querySelector('#messages'),input=d.querySelector('#input');
 const box=(n,height)=>{n.getBoundingClientRect=()=>({height});n.getClientRects=()=>n.hidden?[]:[{height}];};
 box(d.querySelector('#viewport')||messages,chatHeight-122);box(d.querySelector('nav'),32);box(d.querySelector('aside'),500);box(d.querySelector('#composer'),90);box(input,34);
 Object.defineProperty(panel,'clientHeight',{value:panelHeight});Object.defineProperty(chat,'clientHeight',{value:chatHeight});Object.defineProperty(input,'scrollHeight',{get:()=>naturalHeight});
 let frame;const context={requestAnimationFrame:fn=>(frame=fn,1),getComputedStyle:dom.window.getComputedStyle.bind(dom.window)};
 const Draft=vm.runInNewContext(fs.readFileSync(path.join(__dirname,'ai-composer-draft.js'),'utf8')+';EditingToolbarAIDraft',context);
 let positioned=0;const draft=Object.assign(Object.create(Draft.prototype),{ai:{panel,chat,messages,prompt:input,composerUI:{menu:null,modelMenu:{},positionMenu(){positioned++;}}}});
 return {dom,input,draft,run(){draft.resize();frame();return Number.parseFloat(input.style.height);},positioned:()=>positioned};
}

test('multiline draft grows with direct or wrapped chat history without changing text',()=>{
 for(const wrapped of [false,true]){const f=fixture({wrapped}),text=f.input.textContent;assert.equal(f.run(),97);assert.equal(f.input.textContent,text);assert.equal(f.positioned(),1);f.dom.window.close();}
});
test('long drafts cap at 180px and keep remaining reply space in short windows',()=>{
 const long=fixture({naturalHeight:800});assert.equal(long.run(),180);long.dom.window.close();
 const short=fixture({panelHeight:300,chatHeight:190,naturalHeight:800});assert.equal(short.run(),66);short.dom.window.close();
 const empty=fixture({naturalHeight:0});assert.equal(empty.run(),34);empty.dom.window.close();
});
