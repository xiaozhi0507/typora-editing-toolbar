'use strict';
const fs=require('node:fs'),path=require('node:path');
// Compile the same implementation for legacy hosts; never install a second active copy.
module.exports=()=>`const ETDragSupport=host.toolbar.dragSupport?.version===1?host.toolbar.dragSupport:(()=>{
 const module={exports:{}};${fs.readFileSync(path.join(__dirname,'drag-support.cjs'),'utf8')}
 const style=document.createElement('style');style.dataset.etDragFallback='1';
 style.textContent=${JSON.stringify(fs.readFileSync(path.join(__dirname,'drag-motion.css'),'utf8'))};
 document.head.append(style);return module.exports;
})();\n`;
