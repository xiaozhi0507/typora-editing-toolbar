'use strict';
const {test} = require('node:test');
const assert = require('node:assert/strict');
const MarkdownIt = require('markdown-it');
const {installMathRules} = require('./annotation-math.cjs');
const md = new MarkdownIt('commonmark', {html: false}).enable(['table', 'strikethrough']);
installMathRules(md);
function tokens(source) { return md.parse(source, {}).flatMap(t => [t, ...(t.children || [])]); }
function math(source) { return tokens(source).filter(t => /^note_math/.test(t.type)).map(t => ({tex: t.content, display: t.type === 'note_math_block' || !!t.meta?.display})); }

test('AI backslash inline formulas retain TeX, intervals and subscripts', () => {
    assert.deepEqual(math(String.raw`函数 \(f(x)=x^2\)，实数集 \(\mathbb{R}\)，区间 \([a,\infty)\)。`), [
        {tex: 'f(x)=x^2', display: false}, {tex: String.raw`\mathbb{R}`, display: false}, {tex: String.raw`[a,\infty)`, display: false}
    ]);
});
test('backslash display math works alone and within a paragraph', () => {
    const tex = String.raw`f(x)=\frac{\log_{10}(x+8)\sqrt{26-2x}}{(x-2)(x+19)}`;
    assert.deepEqual(math('\\[\n' + tex + '\n\\]'), [{tex, display: true}]);
    assert.deepEqual(math('并举例 \\[ ' + tex + ' \\] 的定义域。'), [{tex, display: true}]);
});
test('existing dollar inline and display math remain supported', () => {
    assert.deepEqual(math('$x^2$\n\n$$\n\\frac{1}{2}\n$$\n\n得到 $$x+y$$。'), [
        {tex: 'x^2', display: false}, {tex: String.raw`\frac{1}{2}`, display: true}, {tex: 'x+y', display: true}
    ]);
});
test('multiple display formulas on one line do not become one formula', () => {
    assert.deepEqual(math(String.raw`\[a\] 和 \[b\]`), [{tex:'a',display:true},{tex:'b',display:true}]);
    assert.deepEqual(math('$$a$$ $$b$$'), [{tex:'a',display:true},{tex:'b',display:true}]);
});
test('lists and blockquotes preserve structure and display math', () => {
    const source = '1. **求定义域**\n\n   \\[\n   x \\in \\mathbb{R}\n   \\]\n\n2. 下一项\n\n> \\[\n> y^2\n> \\]';
    assert.deepEqual(math(source), [{tex:String.raw`x \in \mathbb{R}`,display:true},{tex:'y^2',display:true}]);
    assert.equal(tokens(source).filter(t=>t.type==='list_item_open').length, 2);
    assert.equal(tokens(source).filter(t=>t.type==='strong_open').length, 1);
});
test('math scanner never consumes a following list item', () => {
    const source = '- \\[未完成\n- 第二项\n\n\\]';
    assert.equal(tokens(source).filter(t=>t.type==='list_item_open').length, 2);
    assert.equal(math(source).length, 0);
});
test('aligned multiline math preserves row breaks', () => {
    const tex = String.raw`\begin{aligned}
a &= 1 \\
b &= 2
\end{aligned}`;
    assert.deepEqual(math('\\[\n'+tex+'\n\\]'), [{tex,display:true}]);
});
test('tables parse formulas without breaking Markdown cells', () => {
    assert.deepEqual(math('| 参数 | 值 |\n| --- | --- |\n| $x$ | \\(\\sqrt{2}\\) |'), [{tex:'x',display:false},{tex:String.raw`\sqrt{2}`,display:false}]);
    assert.equal(tokens('| 参数 | 值 |\n| --- | --- |\n| $x$ | 2 |').filter(t=>t.type==='table_open').length, 1);
});
test('inline code, fenced code and indented code remain literal', () => {
    const source = '`\\(x\\)` and `$y$`\n\n```latex\n\\[x\\]\n$$y$$\n```\n\n    \\[z\\]';
    assert.deepEqual(math(source), []);
    assert.deepEqual(tokens(source).filter(t=>t.type==='code_inline').map(t=>t.content), [String.raw`\(x\)`, '$y$']);
    assert.equal(tokens(source).filter(t=>['fence','code_block'].includes(t.type)).length, 2);
});
test('escaped delimiters, prices, ordinary parentheses and links stay text', () => {
    assert.deepEqual(math(String.raw`\\(literal\\) \$20 and $30. 普通 (a,b) [0,1]。`), []);
    assert.deepEqual(math('[链接](https://example.com/$x$)'), []);
    assert.deepEqual(math('$5 + $10 and $ 20 and $x $'), []);
});
test('escaped dollars inside math and even backslashes before delimiter', () => {
    assert.deepEqual(math(String.raw`$\text{cost: \$5}$`), [{tex:String.raw`\text{cost: \$5}`,display:false}]);
    assert.deepEqual(math(String.raw`$$a\\$$`), [{tex:String.raw`a\\`,display:true}]);
});
test('unfinished streamed backslash formula is preserved exactly', () => {
    const source = String.raw`公式 \(\frac{a_1}{b`;
    assert.equal(tokens(source).filter(t=>t.type==='text').map(t=>t.content).join(''), source);
    assert.equal(math(source).length, 0);
    assert.deepEqual(math(source + String.raw`_2}\)`), [{tex:String.raw`\frac{a_1}{b_2}`,display:false}]);
});
test('raw HTML stays inert outside and inside math', () => {
    const source = String.raw`<img src=x onerror=alert(1)> \(<script>alert(1)</script>\)`;
    assert.ok(tokens(source).every(t=>!/^html/.test(t.type)));
    assert.deepEqual(math(source), [{tex:'<script>alert(1)</script>',display:false}]);
});
