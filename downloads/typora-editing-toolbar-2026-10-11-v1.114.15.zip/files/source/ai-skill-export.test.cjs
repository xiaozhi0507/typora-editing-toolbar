const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const Skills=require('./ai-skills.cjs'),Zip=require('./ai-skill-zip.cjs');
const scratch=path.join(process.env.USERPROFILE||process.cwd(),'Downloads','codex-temp','skill-export-tests');fs.mkdirSync(scratch,{recursive:true});
const markdown='---\nname: 科研-demo\ndescription: Export resources\n---\nRead [guide](references/说明.md).\n';
async function setup(t,mode='copy'){
 const dir=fs.mkdtempSync(path.join(scratch,'case-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const original=path.join(dir,'原始技能'),out=path.join(dir,'打包 输出');fs.mkdirSync(path.join(original,'references'),{recursive:true});fs.mkdirSync(path.join(original,'assets'));fs.mkdirSync(path.join(original,'scripts'));fs.mkdirSync(out);
 fs.writeFileSync(path.join(original,'SKILL.md'),markdown);fs.writeFileSync(path.join(original,'references/说明.md'),'正文内容');fs.writeFileSync(path.join(original,'assets/图片.bin'),Buffer.from([0,255,2,128]));fs.writeFileSync(path.join(original,'scripts/check.py'),'print("do not execute")');
 const store=new Skills(require,path.join(dir,'store')),row=await store.add(original,mode);return {dir,original,out,store,row};
}
test('export copied disabled skill round-trips UTF-8 names and binary resources without changing registry',async t=>{
 const f=await setup(t);f.store.enable(f.row.id,false);const registry=fs.readFileSync(f.store.registry);
 const result=await f.store.exportZip(f.row.id,f.out);assert.equal(path.basename(result.path),'科研-demo.zip');assert.equal(result.files,4);
 const zip=await new Zip(require).read(result.path);assert.deepEqual([...zip.files.keys()].sort(),['SKILL.md','assets/图片.bin','references/说明.md','scripts/check.py']);
 assert.equal(zip.files.get('SKILL.md').toString(),markdown);assert.deepEqual(zip.files.get('assets/图片.bin'),Buffer.from([0,255,2,128]));
 const receiver=new Skills(require,path.join(f.dir,'receiver')),restored=await receiver.add(result.path);assert.equal(restored.name,f.row.name);assert.equal(await receiver.text(restored.root,'references/说明.md'),'正文内容');assert.deepEqual(fs.readFileSync(f.store.registry),registry);
});
test('concurrent exports preserve existing ZIP and allocate different names',async t=>{
 const f=await setup(t,'reference'),first=path.join(f.out,'科研-demo.zip');fs.writeFileSync(first,'keep original');
 const results=await Promise.all([f.store.exportZip(f.row.id,f.out),f.store.exportZip(f.row.id,f.out)]);assert.notEqual(results[0].path,results[1].path);assert.equal(fs.readFileSync(first,'utf8'),'keep original');for(const r of results)await new Zip(require).read(r.path);
});
test('legacy Markdown reference exports selected entry and resources without sibling skills',async t=>{
 const f=await setup(t,'reference');await f.store.uninstall(f.row.id);fs.renameSync(path.join(f.original,'SKILL.md'),path.join(f.original,'custom.md'));fs.writeFileSync(path.join(f.original,'unrelated.md'),'private sibling');
 const row=await f.store.add(path.join(f.original,'custom.md'),'reference'),r=await f.store.exportZip(row.id,f.out),z=await new Zip(require).read(r.path);assert.equal(z.files.get('SKILL.md').toString(),markdown);assert(!z.files.has('custom.md'));assert(!z.files.has('unrelated.md'));
});
test('source destination, oversized file, missing skill and directory errors leave no ZIP',async t=>{
 const f=await setup(t);await assert.rejects(f.store.exportZip(f.row.id,f.row.root),/之外/);await assert.rejects(f.store.exportZip(f.row.id,path.join(f.dir,'missing')),/ENOENT/);
 const large=path.join(f.row.root,'large.bin');const fd=fs.openSync(large,'w');fs.ftruncateSync(fd,17*1024**2);fs.closeSync(fd);await assert.rejects(f.store.exportZip(f.row.id,f.out),/16 MiB/);assert.deepEqual(fs.readdirSync(f.out),[]);
 await f.store.uninstall(f.row.id);await assert.rejects(f.store.location(f.row.id),/卸载/);
});
test('links and nested skill packages fail before any output is written',async t=>{
 const f=await setup(t,'reference');fs.symlinkSync(f.out,path.join(f.original,'linked'),'junction');await assert.rejects(f.store.exportZip(f.row.id,f.out),/之外|符号链接/);fs.unlinkSync(path.join(f.original,'linked'));
 fs.mkdirSync(path.join(f.original,'nested'));fs.writeFileSync(path.join(f.original,'nested/SKILL.md'),markdown);await assert.rejects(f.store.exportZip(f.row.id,f.out),/其他 SKILL/);assert.deepEqual(fs.readdirSync(f.out),[]);
});
test('unavailable directory reports error but malformed skill contents still allow locating the directory',async t=>{
 const f=await setup(t,'reference');fs.writeFileSync(path.join(f.original,'SKILL.md'),'broken');assert.equal((await f.store.location(f.row.id)).root,f.original);await assert.rejects(f.store.exportZip(f.row.id,f.out),/元数据/);fs.renameSync(f.original,f.original+'-moved');await assert.rejects(f.store.location(f.row.id),/ENOENT/);assert.deepEqual(fs.readdirSync(f.out),[]);
});
test('ZIP packer enforces import limits and rejects unsafe or conflicting names',async()=>{
 const zip=new Zip(require);await assert.rejects(zip.pack(new Map([['../escape',Buffer.from('x')]])),/不安全/);await assert.rejects(zip.pack(new Map([['a',Buffer.from('x')],['A',Buffer.from('y')]])),/冲突/);await assert.rejects(zip.pack(new Map(Array.from({length:4001},(_,i)=>['f'+i,Buffer.alloc(0)]))),/4000/);
});
test('failed destination write cleans only its own partial output',async t=>{
 const f=await setup(t),actualOpen=f.store.fs.promises.open.bind(f.store.fs.promises),io=Object.create(f.store.fs.promises);io.open=async(...args)=>{const h=await actualOpen(...args);return {writeFile:async()=>{await h.writeFile('partial');throw Error('disk full fixture');},close:()=>h.close()};};f.store.fs={...f.store.fs,promises:io};await assert.rejects(f.store.exportZip(f.row.id,f.out),/disk full/);assert.deepEqual(fs.readdirSync(f.out),[]);
});
