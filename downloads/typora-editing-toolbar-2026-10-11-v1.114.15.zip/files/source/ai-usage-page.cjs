'use strict';
// Read only rendered usage labels. Never infer account allowance from token counts or limit controls.
class AIUsagePage {
  static url='https://chatgpt.com/settings/usage';
  static allowed(value){if(value==='about:blank')return true;try{const u=new URL(value);return !u.username&&!u.password&&u.protocol==='https:'&&['chatgpt.com','auth.openai.com','auth0.openai.com','accounts.google.com','appleid.apple.com','login.microsoftonline.com','login.live.com'].includes(u.hostname);}catch{return false;}}
  static usageURL(value){try{const u=new URL(value);return u.origin==='https://chatgpt.com'&&(/^\/settings\/usage\/?$/i.test(u.pathname)||/^#settings\/usage\/?$/i.test(u.hash));}catch{return false;}}
  static parse(snapshot){
    const base={available:false,source:'webpage',checkedAt:Date.now(),metrics:[]};
    if(snapshot.challenge)return {...base,status:'verification_required',reason:'官方网页需要人工验证，请打开用量网页完成验证。'};
    if(snapshot.login)return {...base,status:'login_required',reason:'请先在用量网页中登录 ChatGPT。'};
    let url;try{url=new URL(snapshot.url);}catch{return {...base,status:'unavailable',reason:'无法识别官方用量页面。'};}
    if(url.origin!=='https://chatgpt.com'||!snapshot.usage)return {...base,status:'unavailable',reason:'尚未进入官方用量页。请打开网页并进入“用量”。'};
    const lines=String(snapshot.text||'').slice(0,24000).split(/\r?\n/).map(x=>x.trim()).filter(Boolean),metrics=[],seen=new Set();
    const clean=x=>x.replace(/[\x00-\x1f<>]/g,' ').slice(0,120),isReset=x=>/(?:\breset|重置)/i.test(x);
    let label='网页用量',reset='',last=null;
    for(let i=0;i<lines.length;i++){
      const line=lines[i];
      // The app dropdown is an allocation setting, never account usage.
      if(/^(?:应用用量限制|应用使用限制|应用限额|app(?:lication)?\s+(?:usage\s+)?limits?)\s*[:：]?$/i.test(line))break;
      if(isReset(line)){reset=line;if(last&&!last.resetText)last.resetText=clean(line);continue;}
      if(!/[%％]/.test(line)&&/(?:\b\d+\s*[- ]?hours?\b|\bweekly\b|\bdaily\b|\bmonthly\b|\bweek\b|\busage\b|\blimits?\b|每周|每月|每天|每日|每\s*\d+\s*小时|\d+\s*小时(?:限额|用量)|周限额)/i.test(line)){label=line;reset='';last=null;continue;}
      const pct=line.match(/(?:^|[^\d.\-−])(\d{1,3}(?:\.\d+)?)\s*[%％]/);if(!pct||(line.match(/[%％]/g)||[]).length!==1)continue;
      const value=Number(pct[1]);if(value<0||value>100)continue;
      // Only explicit "used"/"remaining" labels qualify; a naked percentage is not quota.
      const direction=/(?:\bremaining\b|\bleft\b|\bused\b|\bconsumed\b|剩余|已用|已使用|已消耗)/i.test(line)?line:[lines[i-1],lines[i+1]].find(x=>/^(?:remaining|left|used|consumed|剩余|已用|已使用|已消耗)\s*[:：]?$/i.test(x||''));if(!direction)continue;
      if(/(?:set|max(?:imum)?|budget|configure|设置|最大|预算|上限设置)/i.test(line+' '+direction))continue;
      const remaining=/(?:remaining|left|剩余)/i.test(direction),remainingPercent=remaining?value:Math.max(0,100-value),usedPercent=remaining?Math.max(0,100-value):value;
      const key=label+':'+remainingPercent;if(seen.has(key))continue;seen.add(key);
      last={label:clean(label),remainingPercent,usedPercent,resetText:clean(reset),basis:remaining?'remaining':'used'};metrics.push(last);
    }
    return metrics.length?{...base,available:true,status:'ready',metrics:metrics.slice(0,8),reason:'读取自当前登录的 ChatGPT 用量网页。'}:{...base,status:'unavailable',reason:'已进入用量页，但页面没有可明确识别的已用或剩余百分比。'};
  }
  // One bounded observation during a user-requested read; no network or idle polling.
  static observe(snapshot,parse,timeout){
    return new Promise(resolve=>{
      let observer,deadline,unavailable,queued,last,finished=false;
      const finish=data=>{if(finished)return;finished=true;observer?.disconnect();clearTimeout(deadline);clearTimeout(unavailable);clearTimeout(queued);window.removeEventListener('pagehide',leave);resolve(data);};
      const leave=()=>finish({url:location.href,usage:false,text:''});
      const check=()=>{
        queued=null;if(finished)return;last=snapshot();
        if(last.login||last.challenge||parse(last).available){finish(last);return;}
        if(last.usage){unavailable ||= setTimeout(()=>finish(snapshot()),3000);}
        else {clearTimeout(unavailable);unavailable=null;}
      };
      observer=new MutationObserver(()=>{if(!queued)queued=setTimeout(check,16);});
      observer.observe(document,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['hidden','aria-hidden','class','style']});
      window.addEventListener('pagehide',leave,{once:true});
      deadline=setTimeout(()=>finish(snapshot()),Math.max(1,Math.min(20000,timeout)));
      check();
    });
  }
  // This function runs inside the sandboxed guest. It returns no cookies, storage, inputs or request headers.
  static snapshot(){
    const text=(document.body?.innerText||''),url=location.href,begin=(document.title+' '+text.slice(0,600));
    const challenge=/verify you are human|checking your browser|just a moment|验证您是真人|验证你是真人|正在验证|安全验证|验证您是人|验证你是人/i.test(begin);
    const login=/\/auth\/|auth\.openai\.com|auth0\.openai\.com/.test(url)||!!document.querySelector('input[type="password"]')||(/登录或注册|log in or sign up/i.test(text.slice(0,500))&&(!document.querySelector('main')||!!document.querySelector('input[type="email"]')));
    if(login||challenge)return {url,login,challenge,usage:false,text:''};
    if(location.origin!=='https://chatgpt.com')return {url,login:false,challenge:false,usage:false,text:''};
    const visible=n=>n.getClientRects().length&&!n.closest('[hidden],[aria-hidden="true"]');
    const usageTitle=/^(?:用量|使用情况|usage)$/i,usageWords=/(?:usage|remaining|limits?|用量|限额|已用|剩余)/i;
    const route=/^\/settings\/usage\/?(?:[?#]|$)|#settings\/usage\/?(?:[?]|$)/i.test(location.pathname+location.search+location.hash);
    const headings=[...document.querySelectorAll('h1,h2,h3,h4,[role="heading"],[role="tab"][aria-selected="true"]')].filter(n=>visible(n)&&usageTitle.test(n.textContent.trim())&&!n.closest('article,[data-message-author-role]'));
    let root;
    // Current Settings is a full-page div layout; it need not have a main or dialog.
    for(const heading of headings){for(let n=heading.parentElement;n&&n!==document.body;n=n.parentElement){if(/(?:限额|\blimits?\b)/i.test(n.innerText)&&usageWords.test(n.innerText)){root=n;break;}}if(root)break;}
    root ||= [...document.querySelectorAll('[role="dialog"],main,[role="main"]')].find(n=>visible(n)&&usageWords.test(n.innerText));
    if(!root&&route)root=document.body;
    const content=root?.innerText||'',usage=!!root&&(route||headings.some(h=>root.contains(h)))&&usageWords.test(content);
    // Return only quota labels/values/reset lines, never the sidebar, account, or form contents.
    const lines=[];
    if(usage)for(const raw of content.split(/\r?\n/)){
      const line=raw.trim();if(!line)continue;
      if(/^(?:应用用量限制|应用使用限制|应用限额|app(?:lication)?\s+(?:usage\s+)?limits?)\s*[:：]?$/i.test(line))break;
      if(/^(?:剩余(?:额度|积分)|remaining\s+(?:credits|balance))/i.test(line))continue;
      if(/^(?:用量|使用情况|套餐限额|usage|plan limits?)$/i.test(line)||(/(?:\b\d+\s*[- ]?hours?\b|\bweekly\b|\bdaily\b|\bmonthly\b|\blimits?\b|每周|每月|每天|每日|每\s*\d+\s*小时|\d+\s*小时(?:限额|用量))|(?:\breset|重置)|(?:\bremaining\b|\bleft\b|\bused\b|\bconsumed\b|剩余|已用|已使用|已消耗)|^\d+(?:\.\d+)?\s*[%％]$/i.test(line)&&line.length<=180))lines.push(line);
      if(lines.length>=80)break;
    }
    return {url,login:false,challenge:false,usage,text:lines.join('\n').slice(0,10000)};
  }
}
module.exports=AIUsagePage;
