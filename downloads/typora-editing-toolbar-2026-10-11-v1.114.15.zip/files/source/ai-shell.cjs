'use strict';
// Runs only explicit tool calls. Presentation logs are bounded separately from tool results.
class AIShell {
 constructor(requireNode){this.req=requireNode;this.proc=requireNode('process');}
 static maxCommandChars=100000;
 static async stageScript(requireNode,script){
  if(script.length<=7000)return {command:script,dispose:async()=>{}};
  // Keep long source out of the Windows command line; read UTF-8 without shell interpolation.
  const fs=requireNode('fs').promises,path=requireNode('path'),base=path.join(requireNode('os').homedir(),'Downloads','codex-temp');
  await fs.mkdir(base,{recursive:true});const dir=await fs.mkdtemp(path.join(base,'typora-ai-shell-')),file=path.join(dir,'command.ps1');
  const dispose=async()=>{try{await fs.unlink(file);}catch{}try{await fs.rmdir(dir);}catch{}};
  try{await fs.writeFile(file,script,{encoding:'utf8',mode:0o600});}catch(e){await dispose();throw e;}
  return {command:"& ([ScriptBlock]::Create([IO.File]::ReadAllText('"+file.replace(/'/g,"''")+"', [Text.Encoding]::UTF8)))",dispose};
 }
 static secretName=/token|secret|password|api[_-]?key|authorization|cookie|credential/i;
 static scrub(text,secrets=[]){let value=String(text??'').replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'').replace(/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/g,'');for(const key of [...secrets].filter(s=>typeof s==='string'&&s.length>=4).sort((a,b)=>b.length-a.length))value=value.split(key).join('[已隐藏]');return value.replace(/Bearer\s+[^\s"'<>]+/gi,'Bearer [已隐藏]').replace(/((?:authorization|proxy-authorization|x-api-key|api[_-]?key|access[_-]?token|refresh[_-]?token|password|cookie|set-cookie)\s*["']?\s*[:=]\s*)[^\r\n,;&]+/gi,'$1[已隐藏]').replace(/sk-[\w-]{12,}/g,'[已隐藏]');}
 static bounded(text,max){if(text.length<=max)return text;const half=Math.floor((max-40)/2);return text.slice(0,half)+'\n… 输出已截断 …\n'+text.slice(-half);}
 static liveText(text,secrets=[]){
  // Display partial stdout/stderr without waiting for a newline, but never publish a secret prefix.
  let value=String(text);for(const secret of secrets.filter(s=>typeof s==='string'&&s.length>=4))for(let n=Math.min(secret.length-1,value.length);n>0;n--)if(value.endsWith(secret.slice(0,n))){value=value.slice(0,-n)+'[已隐藏]';break;}
  return this.scrub(value,secrets).replace(/sk-[\w-]*$/g,'[已隐藏]');
 }
 static abort(){return Object.assign(Error('命令已取消'),{name:'AbortError'});}
 async directory(root,workdir){const fs=this.req('fs').promises,path=this.req('path');if(!root||!path.isAbsolute(root))throw Error('Shell 需要有效的已信任项目');const realRoot=await fs.realpath(root),target=await fs.realpath(path.resolve(realRoot,workdir||'.')),relative=path.relative(realRoot,target);if(relative==='..'||relative.startsWith('..'+path.sep)||path.isAbsolute(relative))throw Error('命令工作目录必须位于已授权的项目中');if(!(await fs.stat(target)).isDirectory())throw Error('命令工作目录不是文件夹');return target;}
 static wrapper(command,ownerPid=0){return `
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$OutputEncoding = [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
# A non-inheritable job handle is held by this shell. Exit/crash/kill closes it,
# which terminates every descendant, including children that opened no pipe.
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class ETShellJob {
 [StructLayout(LayoutKind.Sequential)] struct Basic { public long A,B; public uint Flags; public UIntPtr Min,Max; public uint Active; public UIntPtr Affinity; public uint Priority,Schedule; }
 [StructLayout(LayoutKind.Sequential)] struct IO { public ulong A,B,C,D,E,F; }
 [StructLayout(LayoutKind.Sequential)] struct Extended { public Basic Basic; public IO IO; public UIntPtr ProcessMemory,JobMemory,PeakProcess,PeakJob; }
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr CreateJobObject(IntPtr a,string n);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool SetInformationJobObject(IntPtr j,int c,IntPtr p,uint s);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool AssignProcessToJobObject(IntPtr j,IntPtr p);
 static IntPtr handle;
 public static void Attach(int ownerPid) { handle=CreateJobObject(IntPtr.Zero,null); if(handle==IntPtr.Zero)throw new System.ComponentModel.Win32Exception(); var x=new Extended(); x.Basic.Flags=0x2000; int size=Marshal.SizeOf(x); IntPtr p=Marshal.AllocHGlobal(size); try { Marshal.StructureToPtr(x,p,false); if(!SetInformationJobObject(handle,9,p,(uint)size)||!AssignProcessToJobObject(handle,System.Diagnostics.Process.GetCurrentProcess().Handle))throw new System.ComponentModel.Win32Exception(); } finally {Marshal.FreeHGlobal(p);} if(ownerPid>0){var owner=System.Diagnostics.Process.GetProcessById(ownerPid);var monitor=new System.Threading.Thread(()=>{try{owner.WaitForExit();}finally{Environment.Exit(130);}});monitor.IsBackground=true;monitor.Start();} }
}
'@
[ETShellJob]::Attach(${Number.isInteger(ownerPid)?ownerPid:0})
try {
 $global:LASTEXITCODE = 0
 & {
${command}
 } | Out-Default
 $ok = $?
 if ($global:LASTEXITCODE -ne 0) { exit $global:LASTEXITCODE }
 if (-not $ok) { exit 1 }
 exit 0
} catch { [Console]::Error.WriteLine($_.ToString()); exit 1 }
`;}
 async run(args,{root,signal,secrets=[],onUpdate=()=>{},transport}={}){
  if(this.proc.platform!=='win32')throw Error('当前 Shell 执行器仅支持 Windows PowerShell');
  if(!args||typeof args.command!=='string'||!args.command.trim()||args.command.includes('\0'))throw Error('命令必须是非空且不含空字符的 PowerShell 文本');
  if(args.command.length>AIShell.maxCommandChars)throw Error('命令共 '+args.command.length+' 字符，超过 '+AIShell.maxCommandChars+' 字符上限；请用文件工具保存脚本后再运行');
  if(args.workdir!=null&&typeof args.workdir!=='string')throw Error('工作目录格式不正确');
  if(args.timeout_ms!=null&&(!Number.isInteger(args.timeout_ms)||args.timeout_ms<1000||args.timeout_ms>300000))throw Error('超时须在 1000–300000 毫秒之间');
  if(signal?.aborted)throw AIShell.abort();const cwd=await this.directory(root,args.workdir);if(signal?.aborted)throw AIShell.abort();
  const env={},hidden=[...secrets];for(const[k,v]of Object.entries(this.proc.env)){if(AIShell.secretName.test(k)){if(v)hidden.push(v);}else if(!/^(?:CODEX_|NODE_REPL_)/i.test(k))env[k]=v;}
  // Electron/automation launches may omit PATHEXT; PowerShell can then silently skip native executables.
  env.PATHEXT ||= '.COM;.EXE;.BAT;.CMD';env.ComSpec ||= this.req('path').join(env.SystemRoot||env.SYSTEMROOT||'C:\\Windows','System32','cmd.exe');
  Object.assign(env,{PYTHONIOENCODING:'utf-8',PYTHONUNBUFFERED:'1',NO_COLOR:'1'});
  const executable=this.req('path').join(env.SystemRoot||env.SYSTEMROOT||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
  const timeoutMs=args.timeout_ms||120000,startedAt=Date.now(),clean=text=>AIShell.scrub(text,hidden);
  if(transport)return transport(args,{root,cwd,signal,env,hidden,timeoutMs,onUpdate});
  const staged=await AIShell.stageScript(this.req,AIShell.wrapper(args.command,this.proc.pid));
  try{if(signal?.aborted)throw AIShell.abort();return await new Promise((resolve,reject)=>{
   let child,output='',bytes=0,reason='',done=false,timer,emitTimer,lastEmit=0;const limit=1024*1024,Decoder=this.req('string_decoder').StringDecoder,decoders=[new Decoder('utf8'),new Decoder('utf8')];
   const view=final=>{const safe=final?clean(output):AIShell.liveText(output,hidden);return {command:AIShell.bounded(clean(args.command),7000),commandChars:args.command.length,commandTruncated:args.command.length>7000,workdir:cwd,description:clean(args.description||''),output:AIShell.bounded(safe,64000),outputTruncated:safe.length>64000||bytes>limit,timeoutMs,elapsedMs:Date.now()-startedAt};};
   const emit=final=>{clearTimeout(emitTimer);emitTimer=null;lastEmit=Date.now();try{onUpdate(view(final));}catch{}};
   const kill=why=>{if(done||reason)return;reason=why;child?.kill();};
   const abort=()=>kill('cancelled');
   const finish=(code,error)=>{if(done)return;done=true;clearTimeout(timer);clearTimeout(emitTimer);signal?.removeEventListener('abort',abort);output+=decoders.map(d=>d.end()).join('');emit(true);const state={...view(true),exitCode:Number.isInteger(code)?code:null,timedOut:reason==='timeout',outputLimit:reason==='limit'};
    if(reason==='cancelled')return reject(Object.assign(AIShell.abort(),{result:state}));
    if(error)return reject(Error(clean(error.message)));
    const problem=reason==='timeout'?'命令超过时间限制，已终止进程树':reason==='limit'?'命令输出超过 1 MiB，已终止进程树':code!==0?'命令退出码 '+(code??'未知'):null;
    resolve({...state,output:AIShell.bounded(state.output,16000),...(problem?{error:problem}:{})});
   };
   try{child=this.req('child_process').spawn(executable,['-NoLogo','-NoProfile','-NonInteractive','-OutputFormat','Text','-EncodedCommand',this.req('buffer').Buffer.from(staged.command,'utf16le').toString('base64')],{cwd,env,windowsHide:true,stdio:['ignore','pipe','pipe']});}
   catch(e){finish(null,e);return;}
   child.once('error',e=>finish(null,e));child.once('close',code=>finish(code));
   [child.stdout,child.stderr].forEach((stream,i)=>stream.on('data',chunk=>{if(done)return;bytes+=chunk.length;if(bytes<=limit)output+=decoders[i].write(chunk);else kill('limit');if(Date.now()-lastEmit>=100)emit(false);else if(!emitTimer)emitTimer=setTimeout(()=>emit(false),100);}));
   signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)abort();timer=setTimeout(()=>kill('timeout'),timeoutMs);emit(false);
  });}finally{await staged.dispose();}
 }
}
module.exports=AIShell;
