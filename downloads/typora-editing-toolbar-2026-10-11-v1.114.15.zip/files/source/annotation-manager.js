// Local annotations. The document body is never wrapped or rewritten.
class EditingToolbarAnnotations {
    constructor(toolbar, MarkdownIt) {
        this.toolbar=toolbar; this.fs=reqnode('fs'); this.path=reqnode('path'); this.crypto=reqnode('crypto'); this.Buffer=reqnode('buffer').Buffer;
        this.contexts=new Map(); this.locations=new Map(); this.previewSerial=0; this.mathQueue=Promise.resolve();
        this.draftDir=this.path.join(File.option.userDataPath,this.isDocumentNote?'editing-toolbar-document-note-drafts':'editing-toolbar-annotation-drafts');
        this._createPanel(); this._bind(); this._switchDocument();
        if(!this.isDocumentNote&&!this.isManualMark)this.hoverPreview=new EditingToolbarAnnotationHover(this);
    }
    _id(){return this.crypto.randomUUID();}
    _hash(value){return this.crypto.createHash('sha256').update(value).digest('hex');}
    _key(){return File.bundle?.filePath || 'untitled:'+File.bundle?.untitledId;}
    _loading(){return typeof File.isFileLoading==='function'?File.isFileLoading():Boolean(File.isFileLoading);}
    _storageKind(){return this.isManualMark?'标注':this.isDocumentNote?'笔记':'注释';}
    _dir(file){return this.path.join(this.path.dirname(file),this.path.basename(file)+'.资料',this._storageKind());}
    _legacyDir(file){return this.path.join(this.path.dirname(file),this.path.basename(file)+'.'+this._storageKind());}
    _hideDataDirectory(dir){
        // Hide only the generated .资料 container; never recurse into its files.
        // Cosmetic metadata must not block saving or create an empty directory.
        try{
            const process=reqnode('process');if(process.platform!=='win32'||!this.path.basename(dir).endsWith('.资料'))return;
            const root=this.path.resolve(dir),stat=this.fs.lstatSync(root);if(!stat.isDirectory()||stat.isSymbolicLink())return;
            const cache=EditingToolbarAnnotations.hiddenDirectories||(EditingToolbarAnnotations.hiddenDirectories=new Map()),key=root.toLowerCase(),token=stat.ino+':'+stat.birthtimeMs,entry=cache.get(key);
            if(entry?.token===token&&entry.until>Date.now())return;
            if(cache.size>256)cache.clear();const pending={token,until:Infinity};cache.set(key,pending);
            const attrib=this.path.join(process.env.SystemRoot||'C:\\Windows','System32','attrib.exe');
            reqnode('child_process').execFile(attrib,['+H',root],{windowsHide:true,timeout:3000},error=>{
                if(error){pending.until=Date.now()+60000;console.warn('[EditingToolbar] 资料已保留，隐藏属性未设置：',root,error.message);}
            });
        }catch(error){console.warn('[EditingToolbar] 无法设置资料隐藏属性：',error.message);}
    }
    _mkdirStorage(dir){
        this.fs.mkdirSync(dir,{recursive:true});
        for(let root=this.path.resolve(dir);;root=this.path.dirname(root)){
            if(this.path.basename(root).endsWith('.资料')){this._hideDataDirectory(root);break;}
            if(this.path.dirname(root)===root)break;
        }
    }
    _storageDirectoryExists(dir){
        let stat;try{stat=this.fs.lstatSync(dir);}catch(error){if(error.code==='ENOENT')return false;throw error;}
        if(!stat.isDirectory()||stat.isSymbolicLink())throw Error('资料位置不是普通文件夹：'+dir);
        if(this.path.basename(dir).endsWith('.资料'))this._hideDataDirectory(dir);
        return true;
    }
    _prepareStorage(file){
        const parent=this.path.resolve(this.path.dirname(file)),legacy=this.path.resolve(this._legacyDir(file)),dir=this.path.resolve(this._dir(file)),root=this.path.dirname(dir);
        // Move the entire old folder, including backups and unreferenced attachments.
        if(this.path.dirname(legacy)!==parent||this.path.dirname(root)!==parent||legacy===root)throw Error('资料路径超出文档目录');
        this._storageDirectoryExists(root);
        const currentExists=this._storageDirectoryExists(dir);
        if(!this._storageDirectoryExists(legacy))return;
        if(currentExists)throw Error('新旧'+this._storageKind()+'文件夹同时存在，已保留两份，请合并后重新打开文档：'+legacy+'；'+dir);
        const index=this.path.join(legacy,'index.json'),lock=index+'.lock';
        if(this.fs.existsSync(lock)){
            let alive=true;try{reqnode('process').kill(JSON.parse(this._read(lock)).pid,0);}catch(error){alive=error.code!=='ESRCH';}
            if(alive||Date.now()-this.fs.statSync(lock).mtimeMs<=30000)throw Error('旧'+this._storageKind()+'正在保存，请关闭其他窗口后重新打开文档');
        }
        const oldIndex=this._read(index);if(oldIndex)this._validate(JSON.parse(oldIndex));
        this._mkdirStorage(root);
        try{this.fs.renameSync(legacy,dir);}catch(error){
            // Another window may have finished the same migration first.
            if(this._storageDirectoryExists(legacy)||!this._storageDirectoryExists(dir))throw error;
        }
    }
    _read(file){return this.fs.existsSync(file)?this.fs.readFileSync(file,'utf8'):'';}
    _atomic(file,text){
        this._mkdirStorage(this.path.dirname(file));
        const tmp=file+'.tmp-'+this._id();
        try{const fd=this.fs.openSync(tmp,'wx');try{this.fs.writeFileSync(fd,text,'utf8');this.fs.fsyncSync(fd);}finally{this.fs.closeSync(fd);}this.fs.renameSync(tmp,file);}
        finally{if(this.fs.existsSync(tmp))this.fs.unlinkSync(tmp);}
    }
    _draftFile(ctx){return this.path.join(this.draftDir,this._hash(ctx.key)+'.json');}
    _validate(data){
        if(data?.version!==1 || !Array.isArray(data.notes) || data.notes.length>5000)throw Error('不支持的注释文件');
        const ids=new Set();
        for(const n of data.notes){
            if(typeof n.id!=='string'||ids.has(n.id)||!n.anchor||typeof n.anchor.exact!=='string'||typeof n.markdown!=='string'||n.markdown.length>2000000)throw Error('注释文件不完整');
            ids.add(n.id);
        }
        return data;
    }
    _load(key){
        const file=key.startsWith('untitled:')?null:key,dir=file?this._dir(file):this.path.join(this.draftDir,this._hash(key)+'.assets');
        const ctx={key,file,dir,notes:[],documentId:this._id(),dirty:false,base:'',error:'',selected:null};
        try{
            if(file)this._prepareStorage(file);
            ctx.base=file?this._read(this.path.join(dir,'index.json')):'';
            if(ctx.base){const data=this._validate(JSON.parse(ctx.base));ctx.notes=data.notes;ctx.documentId=data.documentId||ctx.documentId;}
            const draftText=this._read(this._draftFile(ctx));
            if(draftText){const draft=this._validate(JSON.parse(draftText));if(draft.baseHash===this._hash(ctx.base)){ctx.notes=draft.notes;ctx.documentId=draft.documentId;ctx.dirty=true;}else{ctx.notes=this._mergeNotes(draft.baseNotes||[],draft.notes,ctx.notes);ctx.dirty=true;}}
        }catch(error){ctx.error='无法读取'+this._storageKind()+'：'+error.message;ctx.readonly=true;}
        return ctx;
    }
    _switchDocument(){
        if(this.ctx?.key!==this._key()||this._loading())this.hoverPreview?.hide();
        this.hoverPreview?.sync();
        if(this.savingAs||this._loading())return;
        const key=this._key(); if(!key||this.ctx?.key===key)return;
        if(this.ctx){this._flushEditor();this._save(this.ctx);}
        this.ctx=this.contexts.get(key)||this._load(key);this.contexts.set(key,this.ctx);
        this.lastText=null;this.locations.clear();this.ctx.selected=this.ctx.notes[0]?.id||null;
        this._scan();this._renderList();this._showSelected();this._status(this.ctx.error||(!this.ctx.file?'未命名文档：注释暂存为本机草稿':'已载入'));
        if(this.ctx.dirty){const ctx=this.ctx;clearTimeout(this.saveTimer);this.saveTimer=setTimeout(()=>this._save(ctx),650);}
    }
    _draft(ctx){
        try{this._atomic(this._draftFile(ctx),JSON.stringify({version:1,key:ctx.key,dir:ctx.dir,documentId:ctx.documentId,updated:new Date().toISOString(),baseHash:this._hash(ctx.base),baseNotes:ctx.base?JSON.parse(ctx.base).notes:[],notes:ctx.notes},null,2));return true;}
        catch(error){this._status('草稿保存失败：'+error.message,true);return false;}
    }
    _touch(){
        this.hoverPreview?.sync();
        const ctx=this.ctx;if(!ctx||ctx.readonly)return;
        ctx.dirty=true;const drafted=this._draft(ctx);if(drafted)this._status(ctx.file?'正在保存…':'已暂存本机草稿；保存正文后随文保存');
        clearTimeout(this.saveTimer);this.saveTimer=setTimeout(()=>this._save(ctx),650);
    }
    _save(ctx=this.ctx,options={}){
        if(!ctx||!ctx.dirty||ctx.readonly)return !ctx?.readonly;
        if(!ctx.file){this._draft(ctx);return true;}
        const index=this.path.join(ctx.dir,'index.json'),lock=index+'.lock';let fd;
        try{
            this._prepareStorage(ctx.file);
            this._mkdirStorage(ctx.dir);
            if(this.fs.existsSync(lock)){
                let alive=true;try{const pid=JSON.parse(this._read(lock)).pid;reqnode('process').kill(pid,0);}catch(error){alive=error.code!=='ESRCH';}
                if(!alive&&Date.now()-this.fs.statSync(lock).mtimeMs>30000)this.fs.unlinkSync(lock);
            }
            fd=this.fs.openSync(lock,'wx');this.fs.writeFileSync(fd,JSON.stringify({pid:reqnode('process').pid}));
            const disk=this._read(index);
            let merged=false;
            if(disk!==ctx.base){
                const remote=disk?this._validate(JSON.parse(disk)).notes:[],base=ctx.base?this._validate(JSON.parse(ctx.base)).notes:[];
                if(options.draft!==false)this._draft(ctx);ctx.notes=this._mergeNotes(base,ctx.notes,remote);merged=true;
                if(!ctx.notes.some(n=>n.id===ctx.selected))ctx.selected=ctx.notes[0]?.id||null;
            }
            const text=JSON.stringify({version:1,documentId:ctx.documentId,updated:new Date().toISOString(),notes:ctx.notes},null,2);
            if(disk)this._atomic(this.path.join(ctx.dir,'index.previous.json'),disk);
            this._atomic(index,text);ctx.base=text;ctx.dirty=false;ctx.conflict=false;ctx.error='';
            try{
                this._atomic(this.path.join(ctx.dir,this.isDocumentNote?'笔记.md':'阅读笔记.md'),this._export(ctx));
                if(this.fs.existsSync(this._draftFile(ctx)))this.fs.unlinkSync(this._draftFile(ctx));
                if(ctx===this.ctx){if(merged){this._scan();this._renderList();this._showSelected();}this._status((merged?'已合并其他窗口修改 · ':'已保存 · ')+new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}));}
            }catch(error){if(ctx===this.ctx)this._status('注释已保存，阅读副本未更新：'+error.message,true);}
            return true;
        }catch(error){ctx.error=error.message;if(options.draft!==false)this._draft(ctx);if(ctx===this.ctx)this._status('保存未完成：'+error.message,true);return false;}
        finally{if(fd!==undefined){this.fs.closeSync(fd);try{this.fs.unlinkSync(lock);}catch(_){}}}
    }
    _export(ctx){
        return '# 阅读笔记\n\n> 此文件由工具栏自动生成；编辑注释请使用工具栏中的「注释」。\n\n'+ctx.notes.map((n,i)=>'## '+(i+1)+'. '+(n.title||'注释')+'\n\n'+n.anchor.exact.split('\n').map(x=>'> '+x).join('\n')+'\n\n'+n.markdown+'\n').join('\n---\n\n');
    }
    _copyAssets(source,target,notes){
        const names=new Set(notes.flatMap(n=>[...JSON.stringify({markdown:n.markdown,imageOriginals:n.imageOriginals}).matchAll(/assets\/([a-f0-9]{32}\.(?:png|mp4|webm|ogg|mov|m4v))/g)].map(m=>m[1])));
        for(const name of names){const src=this.path.join(source,'assets',name),dest=this.path.join(target,'assets',name);if(!this.fs.existsSync(src))throw Error('缺少图片 '+name);this._mkdirStorage(this.path.dirname(dest));if(this.fs.existsSync(dest)){if(this._hash(this.fs.readFileSync(src))!==this._hash(this.fs.readFileSync(dest)))throw Error('目标图片冲突');}else this.fs.copyFileSync(src,dest,this.fs.constants.COPYFILE_EXCL);}
    }
    _afterSaveAs(previous){
        const key=this._key();if(!previous||key===previous.key||key.startsWith('untitled:')||!previous.notes.length)return;
        try{
            this._save(previous);const next=this._load(key);
            if(next.readonly)throw Error(next.error);
            this._copyAssets(previous.dir,next.dir,previous.notes);
            next.notes=this._mergeNotes([],JSON.parse(JSON.stringify(previous.notes)),next.notes);next.documentId=previous.documentId;next.dirty=true;next.selected=previous.selected;
            this.contexts.set(key,next);this.ctx=next;this._save(next);this.lastText=null;this._scan();this._renderList();this._showSelected();
        }catch(error){this._draft(previous);this._status('正文已保存，注释迁移未完成：'+error.message+'；原注释已保留。',true);}
    }
    _index(){
        const write=document.getElementById('write'),segments=[];let text='';
        if(!write)return {text,segments};
        for(const block of write.querySelectorAll('p,h1,h2,h3,h4,h5,h6,td,th')){
            if(block.closest('.md-fences,.md-math-block,.md-htmlblock')||block.querySelector('[md-inline="alert_text"]'))continue;
            const walker=document.createTreeWalker(block,4);let node,has=false;
            while(node=walker.nextNode()){
                if(node.parentElement.closest('.md-meta,.md-content,mjx-container,.MathJax,.CodeMirror,.md-math-after-sym,script,style'))continue;
                const value=node.textContent.replace(/\u00a0/g,' ');if(!value)continue;
                if(!has&&text){text+='\n\n';}has=true;
                segments.push({node,start:text.length,end:text.length+value.length});text+=value;
            }
        }
        return {text,segments};
    }
    _capture(){
        const t=this.toolbar,r=t._resolveRange(window.getSelection());
        const range=t._selectionInEditor(r)&&!r.collapsed?r:(t._selectionInEditor(t.savedRange)&&!t.savedRange.collapsed?t.savedRange:null);
        if(!range||File.editor?.sourceView?.inSourceMode)return null;
        const idx=this._index();let start=null,end=null;
        for(const s of idx.segments){const hit=t._formattingOverlap(s.node,range);if(!hit)continue;const a=s.start+(hit.startContainer===s.node?hit.startOffset:0),b=s.start+(hit.endContainer===s.node?hit.endOffset:s.node.length);if(a===b)continue;if(start===null)start=a;end=b;}
        if(start===null)return null;
        while(start<end&&/\s/.test(idx.text[start]))start++;while(end>start&&/\s/.test(idx.text[end-1]))end--;
        if(start===end)return null;
        return this._anchor(idx.text,start,end);
    }
    _anchor(text,start,end){return{exact:text.slice(start,end),prefix:text.slice(Math.max(0,start-64),start),suffix:text.slice(end,end+64),start,end,hash:this._hash(text)};}
    _resolve(anchor,text,hash){
        if(!anchor.exact)return null;
        if(anchor.hash===hash&&text.slice(anchor.start,anchor.end)===anchor.exact)return {start:anchor.start,end:anchor.end};
        const hits=[];let at=-1;
        while((at=text.indexOf(anchor.exact,at+1))>=0){
            const end=at+anchor.exact.length;let score=0;
            for(let i=1;i<=(anchor.prefix||'').length&&at-i>=0;i++){if(text[at-i]!==anchor.prefix[anchor.prefix.length-i])break;score++;}
            for(let i=0;i<(anchor.suffix||'').length&&end+i<text.length;i++){if(text[end+i]!==anchor.suffix[i])break;score++;}
            hits.push({start:at,end,score});if(hits.length>1000)return null;
        }
        if(hits.length===1)return hits[0];hits.sort((a,b)=>b.score-a.score);
        return hits.length>1&&hits[0].score>=8&&hits[0].score>hits[1].score?hits[0]:null;
    }
    _range(idx,start,end){
        const a=idx.segments.find(s=>s.end>start&&s.start<=start),b=[...idx.segments].reverse().find(s=>s.start<end&&s.end>=end);
        if(!a||!b)return null;const r=document.createRange();r.setStart(a.node,start-a.start);r.setEnd(b.node,end-b.start);return r;
    }
    _scan(){
        if(!this.ctx||this.savingAs||this._loading()||File.editor?.isIME)return;
        if(File.editor?.sourceView?.inSourceMode){this.hoverPreview?.hide();window.CSS?.highlights?.delete('et-annotation');window.CSS?.highlights?.delete('et-annotation-active');return;}
        // Formula rendering mutates thousands of nodes even in unannotated chapters.
        // There is no anchor to resolve until the first annotation is added.
        if(!this.ctx.notes.length){this.index=null;this.lastText=null;this.locations.clear();this.hoverPreview?.hide();window.CSS?.highlights?.delete('et-annotation');window.CSS?.highlights?.delete('et-annotation-active');return;}
        const idx=this._index(),hash=this._hash(idx.text);this.index=idx;
        const oldText=this.lastText;let prefix=0,oldEnd=oldText?.length||0,newEnd=idx.text.length;
        if(oldText!==idx.text)this.hoverPreview?.hide();
        if(oldText!==null&&oldText!==undefined&&oldText!==idx.text){while(prefix<oldEnd&&prefix<newEnd&&oldText[prefix]===idx.text[prefix])prefix++;while(oldEnd>prefix&&newEnd>prefix&&oldText[oldEnd-1]===idx.text[newEnd-1]){oldEnd--;newEnd--;}}
        const previous=this.locations,next=new Map(),ranges=[];let changed=false,anchorsChanged=false;
        for(const note of this.ctx.notes){
            let pos=null,prior=previous.get(note.id);
            if(prior&&oldText!==null&&oldText!==idx.text){let start=prior.start,end=prior.end;if(end<=prefix)pos={start,end};else if(start>=oldEnd){const delta=newEnd-oldEnd;pos={start:start+delta,end:end+delta};}if(pos&&idx.text.slice(pos.start,pos.end)!==note.anchor.exact)pos=null;}
            pos=pos||this._resolve(note.anchor,idx.text,hash);
            if(pos){const range=this._range(idx,pos.start,pos.end);if(range){next.set(note.id,{...pos,range});ranges.push(range);if(note.anchor.hash!==hash&&!this.ctx.readonly){note.anchor=this._anchor(idx.text,pos.start,pos.end);anchorsChanged=true;}}}
            if(Boolean(prior)!==next.has(note.id))changed=true;
        }
        this.locations=next;this.lastText=idx.text;
        this.hoverPreview?.sync();
        if(window.CSS?.highlights&&window.Highlight){CSS.highlights.set('et-annotation',new Highlight(...ranges));const active=next.get(this.ctx.selected);CSS.highlights.set('et-annotation-active',new Highlight(...(active?[active.range]:[])));}
        if(changed)this._renderList();this._updateQuote();
        if(anchorsChanged)this._touch();
    }
    openFromSelection(){this._switchDocument();const anchor=this._capture();this.open();if(anchor)this._add(anchor);}
    _add(anchor){
        if(this.ctx.readonly){this._status(this.ctx.error,true);return;}
        const duplicate=this.ctx.notes.find(n=>n.anchor.exact===anchor.exact&&this.locations.get(n.id)?.start===anchor.start);
        if(duplicate){this._select(duplicate.id,true);return;}
        const now=new Date().toISOString(),note={id:this._id(),anchor,markdown:'',title:'',created:now,updated:now};
        this.ctx.notes.push(note);this.ctx.selected=note.id;this._touch();this._scan();this._renderList();this._showSelected();this._focusEditor();
    }
    open(){const wasHidden=this.panel.hidden;if(wasHidden){this.expandedNotes=new Set();this.expandedNotesKey=this.ctx?.key;this.listHeight=null;this.openingNotes=true;}this.panel.hidden=false;if(!this.toolbar.panelWorkspace)document.body.classList.add('et-annotations-open');this.toolbar.hide();this._layout();this._scan();this._renderList();if(wasHidden||this.editorPending)this._showSelected();if(wasHidden){const list=this.panel.querySelector('.et-note-list'),active=list.querySelector('.active');if(active)list.scrollTop+=active.getBoundingClientRect().top-list.getBoundingClientRect().top;list.offsetHeight;this.openingNotes=false;this._layoutNoteSplit();}}

    close(){if(this.panel.hidden)return;this._finishResize();this._finishNoteSplit();this._flushEditor();this.editor?.blur();this._save();this.panel.hidden=true;document.body.classList.remove('et-annotations-open');this._cancelDelete();this.toolbar._applyTopPlacement();}
    _selected(){return this.ctx?.notes.find(n=>n.id===this.ctx.selected);}
    _select(id,focus=false){this._flushEditor();this._save();this.ctx.selected=id;this._cancelDelete();this._scan();this._renderList();this._showSelected();if(focus)this._focusEditor();}
    _locate(){const hit=this.locations.get(this.ctx.selected);if(!hit){this._status('原句已改变或无法唯一定位，请重新选择正文后关联。',true);return;}const sel=getSelection();sel.removeAllRanges();sel.addRange(hit.range.cloneRange());const el=hit.range.startContainer.parentElement;el.scrollIntoView({block:'center',behavior:'smooth'});this.toolbar._saveSelection();this.toolbar.hide();}
    _noteIcon(name){const paths={close:'M7 7l10 10M17 7 7 17',check:'m6 12 4 4 8-9',link:'M10 13a4.2 4.2 0 0 0 6 0l3-3a4.2 4.2 0 0 0-6-6l-1.8 1.8M14 11a4.2 4.2 0 0 0-6 0l-3 3a4.2 4.2 0 0 0 6 6l1.8-1.8'};return '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="'+paths[name]+'"/></svg>';}

    _createPanel(){
        const p=document.createElement('aside');p.id=this.isDocumentNote?'et-document-note-panel':'et-annotation-panel';p.hidden=true;p.setAttribute('aria-label',this.isDocumentNote?'笔记':'注释');
        p.innerHTML=`<div class="et-note-resize" role="separator" aria-label="调整注释面板宽度" tabindex="0"></div>
          <header><div><strong>${this.isDocumentNote?'笔记':'注释'}</strong><span class="et-note-count"></span></div><button data-note="close" aria-label="关闭${this.isDocumentNote?'笔记':'注释'}面板">${this._noteIcon('close')}</button></header>
          <div class="et-panel-scroll-body" role="region" aria-label="${this.isDocumentNote?'笔记':'注释'}内容" tabindex="0"><div class="et-note-list" id="${this.isDocumentNote?'et-document-note-items':'et-note-items'}" aria-label="当前文档的注释"></div>
          <div class="et-note-empty">选中正文中的文字，点击工具栏的「注释」。</div>
          <div class="et-note-work" hidden><div class="et-note-anchor-status"></div><div class="et-note-editor-resize" role="separator" aria-orientation="horizontal" aria-controls="${this.isDocumentNote?'et-document-note-items':'et-note-items'}" aria-label="调整注释列表与编辑区高度" title="拖动后保持位置；双击或关闭重开恢复自动高度" tabindex="0"></div><iframe class="et-note-editor-frame" title="实时${this.isDocumentNote?'笔记':'注释'}编辑区"></iframe></div>
          </div><footer><span class="et-note-status" role="status" aria-live="polite"></span></footer>`;
        document.body.appendChild(p);this.panel=p;
        p.addEventListener('mousedown',e=>{this.toolbar.hide();if(e.target.closest('[data-note-rebind]')){this.toolbar._saveSelection();e.preventDefault();}e.stopPropagation();});
        for(const type of ['keydown','keyup','keypress','beforeinput','paste','copy','cut','drop','dragover','input','click','mouseup'])p.addEventListener(type,e=>e.stopPropagation());
        p.querySelector('[data-note="close"]').onclick=()=>this.close();
        const handle=p.querySelector('.et-note-resize');
        handle.addEventListener('pointerdown',e=>{if(e.button!==0)return;e.preventDefault();this.resizeViewport=document.documentElement.clientWidth;this.resizeOffset=this.panel.getBoundingClientRect().left-e.clientX;this.resizing=true;document.body.classList.add('et-note-resizing');handle.setPointerCapture(e.pointerId);});
        handle.addEventListener('pointermove',e=>{if(!this.resizing)return;this.pendingWidth=this.resizeViewport-e.clientX-this.resizeOffset;if(!this.resizeFrame)this.resizeFrame=requestAnimationFrame(()=>{this.resizeFrame=0;this._width(this.pendingWidth,false);});});
        for(const type of ['pointerup','pointercancel','lostpointercapture'])handle.addEventListener(type,()=>this._finishResize());
        window.addEventListener('blur',()=>{this._finishResize();this._finishNoteSplit();});
        handle.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();this._width(this.width+(e.key==='ArrowLeft'?20:-20));}});
        handle.setAttribute('aria-label','调整'+(this.isDocumentNote?'笔记':'注释')+'面板宽度');
        this.width=Number(localStorage.getItem(this.isDocumentNote?'et-document-note-width':'et-annotation-width'))||410;this._width(this.width);
        this.listHeight=null;localStorage.removeItem('et-annotation-list-height');
        const split=p.querySelector('.et-note-editor-resize'),list=p.querySelector('.et-note-list');
        list.addEventListener('wheel',e=>e.stopPropagation(),{passive:true});
        split.addEventListener('pointerdown',e=>{if(e.button!==0)return;e.preventDefault();this._finishResize();this.splitStartY=e.clientY;const target=this.isDocumentNote?this.toolbar.researchMaterials?.list:list;if(!target)return;this.splitStartHeight=target.getBoundingClientRect().height;this.splitMoved=false;this.pendingListHeight=null;this.splitting=true;split.focus({preventScroll:true});document.body.classList.add('et-note-splitting');target.style.height=this.splitStartHeight+'px';split.setPointerCapture(e.pointerId);});
        split.addEventListener('pointermove',e=>{if(!this.splitting||(!this.splitMoved&&Math.abs(e.clientY-this.splitStartY)<2))return;this.splitMoved=true;this.pendingListHeight=this.splitStartHeight+e.clientY-this.splitStartY;if(!this.splitFrame)this.splitFrame=requestAnimationFrame(()=>{this.splitFrame=0;this.listHeight=this.pendingListHeight;this._layoutNoteSplit();});});
        for(const type of ['pointerup','pointercancel','lostpointercapture'])split.addEventListener(type,()=>this._finishNoteSplit());
        split.addEventListener('dblclick',()=>{this.listHeight=null;localStorage.removeItem('et-annotation-list-height');this._layoutNoteSplit();});
        split.addEventListener('keydown',e=>{if(!['ArrowUp','ArrowDown','Home','End'].includes(e.key))return;e.preventDefault();this.listHeight=e.key==='Home'?this.splitMin:e.key==='End'?this.splitMax:this.renderedListHeight+(e.key==='ArrowUp'?-20:20);this._layoutNoteSplit();this.listHeight=this.renderedListHeight;});
        this.splitObserver=new ResizeObserver(()=>{if(!this.splitLayoutFrame)this.splitLayoutFrame=requestAnimationFrame(()=>{this.splitLayoutFrame=0;this._layoutNoteSplit();});});
        for(const el of [p,p.querySelector('.et-note-anchor-status'),p.querySelector('footer')])this.splitObserver.observe(el);
        this.frame=p.querySelector('iframe');
    }

    _ensureRenderer(){
        if(this.frame.contentWindow.ETNoteLive)return this.frame.contentWindow.ETNoteLive;
        const d=this.frame.contentDocument;
        d.open();d.write('<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; script-src \'unsafe-inline\'; style-src \'unsafe-inline\'; img-src data:; media-src blob:; font-src data:; connect-src \'none\'"></head><body><div id="editor"></div></body></html>');d.close();
        const style=d.createElement('style');style.textContent=ET_NOTE_LIVE_CSS;d.head.append(style);
        const script=d.createElement('script');script.textContent=ET_NOTE_LIVE_BUNDLE;d.head.append(script);
        return this.frame.contentWindow.ETNoteLive;
    }

    _ensureEditor(){
        if(this.editor)return;
        this._ensureRenderer();const d=this.frame.contentDocument;
        this.editor=this.frame.contentWindow.ETNoteLive.create(d.getElementById('editor'),{
            placeholder:'',
            label:this.isDocumentNote?'笔记':'注释',popupKey:this.isDocumentNote?'et-document-note-popups':'et-note-popups',
            retainStates:Boolean(this.isDocumentNote),
            controls:()=>this.toolbar.uiSettings.floating.map(id=>({id,...BUTTON_DEFINITIONS[id]})).filter(item=>item.icon),
            definition:id=>BUTTON_DEFINITIONS[id],template:id=>TEMPLATE_LIBRARY[id],asciiEdits:(...args)=>this.toolbar._asciiMathTextEdits(...args),
            emojiSections:()=>this.toolbar.config.EMOJI_SECTIONS,
            colorSections:kind=>{const favorites=kind==='font-color'?this.toolbar.uiSettings.fontColors:this.toolbar.uiSettings.bgColors;return [...(favorites?.length?[{label:'常用颜色',colors:favorites}]:[]),...(kind==='font-color'?this.toolbar.config.FONT_COLOR_SECTIONS:this.toolbar.config.BG_COLOR_SECTIONS)];},
            notice:text=>this._status(text,true),onVideos:files=>this._videos(files),videoAsset:src=>this._videoAsset(src),
            writeClipboard:data=>reqnode('electron').clipboard.write(data),readClipboard:()=>{const c=reqnode('electron').clipboard;return{text:c.readText(),html:c.readHTML(),image:c.availableFormats().some(f=>/^image\//i.test(f))};},
            external:id=>{if(id==='fullscreen')this.toolbar._toggleFullscreen();else if(id==='toolbar-settings')this.toolbar._openToolbarSettings();else if(id==='annotation'){this._locate();this.panel.querySelector('.et-note-item.active')?.scrollIntoView({block:'nearest'});}},
            colors:kind=>kind==='font-color'?this.toolbar.uiSettings.fontColors:this.toolbar.uiSettings.bgColors,
            onChange:markdown=>{const n=this._selected();if(this.editorPending||!n||this.ctx.readonly)return;n.markdown=markdown;n.updated=new Date().toISOString();this._touch();this._renderList();},
            onFiles:files=>this._files(files),onNativeImage:()=>{try{const img=reqnode('electron').clipboard.readImage();if(!img.isEmpty())this._image(img.toPNG(),this.ctx,this._selected());}catch(error){this._status('图片未插入：'+error.message,true);}},
            imageURL:src=>this._imageURL(src),renderMath:(tex,display)=>this._renderMath(tex,display),openLink:url=>reqnode('electron').shell.openExternal(url),
            onCollect:packet=>this.toolbar.researchMaterials?.collectEditor(this,packet),dropMaterial:event=>this.toolbar.researchMaterials?.dropIntoEditor(event,this),
            onFocus:()=>this.toolbar.hide(),onBlur:()=>this._save()
        });
    }

    _flushEditor(){if(!this.editorPending)this.editor?.flush();}

    _focusEditor(){if(!this.toolbar.panelWorkspace?.drag?.active)this.editor?.focus();}

    _cancelDelete(){clearTimeout(this.deleteTimer);this.deleting=null;this.panel?.querySelectorAll('[data-note-delete]').forEach(b=>{b.innerHTML=this._noteIcon('close');b.classList.remove('confirm');b.setAttribute('aria-label','删除注释');b.title='删除注释';});}

    _cardAction(id,action){
        const note=this.ctx?.notes.find(n=>n.id===id);if(!note||this.ctx.readonly)return;
        if(action==='rebind'){
            const anchor=this._capture();if(!anchor){this._status('请先选中新原文，再点击这条笔记的关联图标。');return;}
            this._flushEditor();note.anchor=anchor;note.updated=new Date().toISOString();this.ctx.selected=id;this._cancelDelete();this._touch();this._scan();this._renderList();this._showSelected();return;
        }
        if(action==='delete'){
            if(this.deleting!==id){this._cancelDelete();this.deleting=id;this._renderList();this.deleteTimer=setTimeout(()=>{this._cancelDelete();},10000);return;}
            this._flushEditor();this.ctx.notes=this.ctx.notes.filter(n=>n!==note);if(this.ctx.selected===id)this.ctx.selected=this.ctx.notes[0]?.id||null;
            this._cancelDelete();this._touch();this._scan();this._renderList();this._showSelected();this._save();
        }
    }

    _themeEditor(){if(!this.frame||this.panel.hidden)return;const css=getComputedStyle(this.panel),root=this.frame.contentDocument.documentElement;for(const [key,value] of Object.entries({'--note-text':css.getPropertyValue('--text-color')||css.color,'--note-bg':css.getPropertyValue('--bg-color')||'#fff','--note-muted':css.getPropertyValue('--et-text-dim')||'#888','--note-toolbar-bg':css.getPropertyValue('--et-surface-strong'),'--note-border':css.getPropertyValue('--et-border'),'--note-hover':css.getPropertyValue('--et-hover')}))if(value.trim())root.style.setProperty(key,value.trim());}
    _width(value,persist=true){const width=Math.round(Math.max(300,Math.min(720,value)));if(Number.isFinite(width)){this.width=width;this._layout();if(persist)localStorage.setItem(this.isDocumentNote?'et-document-note-width':'et-annotation-width',String(this.width));}}

    _layout(){if(this.toolbar.panelWorkspace?.layoutOwner(this))return;const width=Math.min(this.width,Math.max(280,document.documentElement.clientWidth-340));this.panel.style.width=width+'px';if(!this.panel.hidden)document.documentElement.style.setProperty('--et-note-width',width+'px');this._layoutNoteSplit();if(!this.resizing)this.toolbar._applyTopPlacement();}

    _finishResize(){if(!this.resizing)return;cancelAnimationFrame(this.resizeFrame);this.resizeFrame=0;if(Number.isFinite(this.pendingWidth))this._width(this.pendingWidth,false);this.pendingWidth=null;localStorage.setItem(this.isDocumentNote?'et-document-note-width':'et-annotation-width',String(this.width));this.resizing=false;this.toolbar._applyTopPlacement();document.body.classList.remove('et-note-resizing');}

    _layoutNoteSplit(){
        if(this.panel.hidden)return;
        const list=this.panel.querySelector('.et-note-list'),work=this.panel.querySelector('.et-note-work');list.hidden=!this.ctx?.notes.length;
        const automatic=!Number.isFinite(this.listHeight);this.panel.classList.toggle('et-note-auto-split',automatic&&!this.openingNotes);
        this._updateNoteExcerpts();
        if(work.hidden||list.hidden)return;
        const body=this.panel.querySelector('.et-panel-scroll-body'),frame=this.panel.querySelector('.et-note-editor-frame'),split=this.panel.querySelector('.et-note-editor-resize'),css=getComputedStyle(body),gap=parseFloat(css.rowGap)||0;
        const extras=frame.getBoundingClientRect().top-work.getBoundingClientRect().top+1;
        // Use unscrolled local dimensions: scrolling must not change the split.
        // In a short slot the body scrolls instead of collapsing either surface.
        this.splitMax=Math.max(72,Math.floor(body.clientHeight-2*gap-extras-180));this.splitMin=Math.min(72,list.firstElementChild?.offsetHeight||72);
        const natural=[...list.children].reduce((height,item)=>height+item.offsetHeight,0)+Math.max(0,list.children.length-1)*(parseFloat(getComputedStyle(list).rowGap)||0);
        const compact=Math.min(60,natural),expanded=[...list.querySelectorAll('.et-note-item.expanded')];
        const expandedHeight=expanded.reduce((sum,item)=>sum+item.offsetHeight,0)+Math.max(0,expanded.length-1)*(parseFloat(getComputedStyle(list).rowGap)||0);
        const desired=this.splitting&&!this.splitMoved?this.splitStartHeight:automatic?Math.min(natural,Math.max(compact,expandedHeight),this.panel.clientHeight*.42):this.listHeight;
        const height=Math.round(Math.max(this.splitMin,Math.min(this.splitMax,desired)));this.renderedListHeight=height;
        if(list.style.height!==height+'px')list.style.height=height+'px';
        split.setAttribute('aria-valuemin',String(this.splitMin));split.setAttribute('aria-valuemax',String(this.splitMax));split.setAttribute('aria-valuenow',String(height));split.setAttribute('aria-valuetext','笔记列表高度 '+height+' 像素');
    }

    _finishNoteSplit(){
        if(!this.splitting)return;cancelAnimationFrame(this.splitFrame);this.splitFrame=0;
        if(this.splitMoved){if(Number.isFinite(this.pendingListHeight))this.listHeight=this.pendingListHeight;this._layoutNoteSplit();this.listHeight=this.renderedListHeight;}
        this.pendingListHeight=null;this.splitting=false;document.body.classList.remove('et-note-splitting');this._layoutNoteSplit();
    }
    _status(text,error=false){const el=this.panel.querySelector('.et-note-status');el.textContent=text;el.classList.toggle('et-note-error',error);}
    _renderList(){
        if(!this.ctx||this.panel.hidden)return;const list=this.panel.querySelector('.et-note-list'),scroll=list.scrollTop;
        if(this.expandedNotesKey!==this.ctx.key){this.expandedNotesKey=this.ctx.key;this.expandedNotes=new Set();}this.expandedNotes??=new Set();for(const id of this.expandedNotes)if(!this.ctx.notes.some(n=>n.id===id))this.expandedNotes.delete(id);
        list.replaceChildren();this.panel.querySelector('.et-note-count').textContent=this.ctx.notes.length?' · '+this.ctx.notes.length+' 条':'';
        for(const note of this.ctx.notes){
            const row=document.createElement('div');row.dataset.id=note.id;row.className='et-note-item';row.classList.toggle('active',note.id===this.ctx.selected);
            const expanded=this.expandedNotes.has(note.id);row.classList.toggle('expanded',expanded);
            const b=document.createElement('button');b.type='button';b.className='et-note-select';b.setAttribute('aria-pressed',String(note.id===this.ctx.selected));
            const title=document.createElement('span');title.className='et-note-excerpt';
            const text=document.createElement('span');text.className='et-note-excerpt-text';text.id='et-note-excerpt-'+note.id;text.textContent=(this.locations.has(note.id)?'':'待关联 · ')+note.anchor.exact;
            const toggle=document.createElement('span');toggle.className='et-note-excerpt-toggle';toggle.hidden=true;toggle.setAttribute('aria-hidden','true');title.append(text,toggle);b.setAttribute('aria-controls',text.id);
            const summary=document.createElement('small'),preview=Array.from(note.markdown.replace(/<img\b[^>]*>|!\[[^\]]*\]\([^)]*\)/g,' [图片] ').replace(/<\/(?:p|td|th|tr)>/g,' ').replace(/<\/?(?:span|u|mark|sup|sub|table|tbody|thead|tr|td|th|p)\b[^>]*>/g,'').replace(/(?:^|\n)#{1,6}\s+/g,' ').replace(/[*~`]/g,'').replace(/\s+/g,' '));summary.textContent=(preview.slice(0,90).join('')+(preview.length>90?'…':''))||'还没有填写笔记';b.append(title,summary);
            b.addEventListener('click',()=>{
                if(b.getAttribute('aria-expanded')==='false')this.expandedNotes.add(note.id);else this.expandedNotes.delete(note.id);
                this._select(note.id);this._locate();
                const current=[...list.children].find(item=>item.dataset.id===note.id);if(!current)return;
                current.querySelector('.et-note-select').focus({preventScroll:true});
                const r=current.getBoundingClientRect(),bounds=list.getBoundingClientRect();
                if(r.top<bounds.top)list.scrollTop+=r.top-bounds.top;else if(r.top+Math.min(60,r.height)>bounds.bottom)list.scrollTop+=r.top+Math.min(60,r.height)-bounds.bottom;
                if(!Number.isFinite(this.listHeight)&&current.classList.contains('expanded')){const expanded=[...list.querySelectorAll('.et-note-item.expanded')],first=expanded[0].getBoundingClientRect(),last=expanded.at(-1).getBoundingClientRect();if(last.bottom-first.top<=this.renderedListHeight+1)list.scrollTop+=first.top-list.getBoundingClientRect().top;}
            });
            const actions=document.createElement('div');actions.className='et-note-card-actions';
            const link=document.createElement('button');link.type='button';link.dataset.noteRebind=note.id;link.title='关联当前选中的原文';link.setAttribute('aria-label','关联当前选区');link.innerHTML=this._noteIcon('link');link.onclick=()=>this._cardAction(note.id,'rebind');
            const del=document.createElement('button');del.type='button';del.dataset.noteDelete=note.id;const confirm=this.deleting===note.id;del.innerHTML=this._noteIcon(confirm?'check':'close');del.className=confirm?'confirm':'';del.setAttribute('aria-label',confirm?'确认删除注释':'删除注释');del.title=confirm?'再次点击确认删除':'删除注释';del.onclick=()=>this._cardAction(note.id,'delete');
            actions.append(link,del);row.append(b,actions);list.append(row);
        }this._layoutNoteSplit();list.scrollTop=scroll;
    }

    _updateNoteExcerpts(){
        const rows=[...this.panel.querySelectorAll('.et-note-item')];
        for(const row of rows)row.querySelector('.et-note-excerpt-toggle').hidden=true;
        const overflow=rows.map(row=>{const text=row.querySelector('.et-note-excerpt-text');return row.classList.contains('expanded')||text.scrollWidth>text.clientWidth+1;});
        rows.forEach((row,i)=>{const b=row.querySelector('.et-note-select'),toggle=row.querySelector('.et-note-excerpt-toggle'),expanded=row.classList.contains('expanded');toggle.hidden=!overflow[i];toggle.textContent=expanded?'收起':'… 展开';if(overflow[i])b.setAttribute('aria-expanded',String(expanded));else b.removeAttribute('aria-expanded');b.title=overflow[i]?(expanded?'定位原文并收起':'定位原文并展开全文'):'定位原文';});
    }

    _updateQuote(){const note=this._selected();this.panel.querySelector('.et-note-anchor-status').textContent=note&&!this.locations.has(note.id)?'原句已改变或无法唯一定位，笔记仍保留。选中新原句后可重新关联。':'';}

    _showSelected(){
        // Keep the old editor untouched while hidden. Flush before changing ctx,
        // and never flush that stale view into the next document's selected note.
        this.editorPending=this.panel.hidden;if(this.editorPending)return;
        this._ensureEditor();
        const n=this._selected();this.panel.querySelector('.et-note-work').hidden=!n;this.panel.querySelector('.et-note-empty').hidden=Boolean(n);
        this.editor?.setMarkdown(n?.markdown||'',(this.ctx?.key||'')+':'+(n?.id||''),Boolean(this.ctx?.readonly));this._updateQuote();this._themeEditor();this._layoutNoteSplit();
    }
    _files(files){const ctx=this.ctx,note=this._selected();if(!note)return;for(const file of files){(async()=>{try{if(file.size>20*1024*1024)throw Error('图片超过 20 MB');this._image(this.Buffer.from(await file.arrayBuffer()),ctx,note);}catch(error){this._status('图片未插入：'+error.message,true);}})();}}

    _imageURL(src){if(!/^assets\/[a-f0-9]{32}\.png$/.test(src||'')||!this.ctx)return '';try{const file=this.path.join(this.ctx.dir,src);if(this.fs.statSync(file).size>20*1024*1024)return '';return 'data:image/png;base64,'+this.fs.readFileSync(file).toString('base64');}catch(_){return '';}}

    _videos(files){const ctx=this.ctx,note=this._selected();if(!note||ctx.readonly)return;for(const file of files)(async()=>{try{const ext=(file.name.split('.').pop()||'').toLowerCase();if(!['mp4','webm','ogg','mov','m4v'].includes(ext))throw Error('请选择 MP4、WebM、OGG、MOV 或 M4V 视频');if(file.size>200*1024*1024)throw Error('视频超过 200 MB');const buffer=this.Buffer.from(await file.arrayBuffer());if(!ctx.notes.includes(note))return;const name=this._hash(buffer).slice(0,32)+'.'+ext,folder=this.path.join(ctx.dir,'assets');this._mkdirStorage(folder);const target=this.path.join(folder,name);if(!this.fs.existsSync(target))this.fs.writeFileSync(target,buffer,{flag:'wx'});if(ctx===this.ctx&&note===this._selected())this.editor.insertVideo('assets/'+name);else{note.markdown+='\n\n<video controls src="assets/'+name+'"></video>';ctx.dirty=true;this._draft(ctx);this._save(ctx);}}catch(error){this._status('视频未插入：'+error.message,true);}})();}

    _videoAsset(src){if(!/^assets\/[a-f0-9]{32}\.(mp4|webm|ogg|mov|m4v)$/.test(src||'')||!this.ctx)return null;try{const file=this.path.join(this.ctx.dir,src);if(this.fs.statSync(file).size>200*1024*1024)return null;const b=this.fs.readFileSync(file),ext=src.split('.').pop();return{bytes:b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),mime:ext==='webm'?'video/webm':ext==='ogg'?'video/ogg':ext==='mov'?'video/quicktime':'video/mp4'};}catch(_){return null;}}

    _image(buffer,ctx,note){
        if(!note||ctx.readonly||!ctx.notes.includes(note))return;if(buffer.length>20*1024*1024)throw Error('图片超过 20 MB');
        const image=reqnode('electron').nativeImage.createFromBuffer(buffer);if(image.isEmpty())throw Error('无法识别图片格式');
        const size=image.getSize();if(size.width>12000||size.height>12000)throw Error('图片尺寸过大');
        const png=image.toPNG(),name=this._hash(png).slice(0,32)+'.png',folder=this.path.join(ctx.dir,'assets');this._mkdirStorage(folder);
        const file=this.path.join(folder,name);if(!this.fs.existsSync(file))this.fs.writeFileSync(file,png,{flag:'wx'});
        const markdown='\n![图片](assets/'+name+')\n';
        if(ctx===this.ctx&&this._selected()===note)this.editor.insertImage('assets/'+name);
        else{note.markdown+=markdown;ctx.dirty=true;this._draft(ctx);this._save(ctx);}
    }
    _renderMath(tex,display){
        const run=async()=>{
            if(tex.length>20000)throw Error('公式过长');
            await prepareMathJax();
            const input=new MathJax._.input.tex_ts.TeX({packages:['base','ams','newcommand','textmacros','boldsymbol','color'],tags:'none',maxBuffer:20000,maxMacros:1000});
            // MathJax 4's default font uses an unconfigured dynamic resource path.
            // Reuse Typora's configured font data, but isolate macros and SVG IDs.
            const font=MathJax.startup?.document?.outputJax?.font;
            const output=new MathJax._.output.svg_ts.SVG({fontCache:'none',...(font?{fontData:font}:{})});
            const doc=MathJax._.mathjax.mathjax.document(document,{InputJax:input,OutputJax:output});
            const math=await doc.convertPromise(tex,{display});
            if(math.querySelector('[data-mml-node="merror"]'))throw Error('公式尚未完整');
            math.setAttribute('aria-label',tex);return math.outerHTML;
        };
        const result=this.mathQueue.catch(()=>{}).then(run);this.mathQueue=result.catch(()=>{});return result;
    }

    _mergeNotes(base,local,remote){
        const before=new Map(base.map(n=>[n.id,n])),left=new Map(local.map(n=>[n.id,n])),right=new Map(remote.map(n=>[n.id,n]));const result=[];
        const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
        for(const id of new Set([...left.keys(),...right.keys(),...before.keys()])){
            const b=before.get(id),l=left.get(id),r=right.get(id);
            if(same(l,r)){if(l)result.push(l);continue;}
            if(same(l,b)){if(r)result.push(r);continue;}
            if(same(r,b)){if(l)result.push(l);continue;}
            if(!l){if(r)result.push(r);continue;}
            if(!r){result.push({...l,id:this._id()});continue;}
            if(l.markdown===r.markdown){result.push({...r,anchor:l.anchor,updated:l.updated});continue;}
            result.push(l);
            if(![...left.values(),...right.values()].some(n=>n.id!==id&&n.markdown===r.markdown&&n.anchor.exact===r.anchor.exact))result.push({...r,id:this._id()});
        }return result;
    }

    _bind(){
        const write=document.getElementById('write');
        const schedule=()=>{clearTimeout(this.scanTimer);this.scanTimer=setTimeout(()=>{this._switchDocument();this._scan();},220);};
        this.observer=new MutationObserver(schedule);this.observer.observe(write,{subtree:true,childList:true,characterData:true});
        this.poll=setInterval(()=>{this._switchDocument();if(this.ctx?.dirty&&Date.now()-(this.lastRetry||0)>3000){this.lastRetry=Date.now();this._save();}},700);
        window.addEventListener('beforeunload',()=>{this._flushEditor();this._save();});window.addEventListener('blur',()=>{this._flushEditor();this._save();});window.addEventListener('resize',()=>{this._layout();this._themeEditor();});
        write.addEventListener('pointerdown',e=>this.down={x:e.clientX,y:e.clientY});
        write.addEventListener('click',e=>{if(!this.ctx||!getSelection()?.isCollapsed||!this.down||Math.hypot(e.clientX-this.down.x,e.clientY-this.down.y)>5||e.target.closest('a,img,.md-fences,.md-math-block'))return;const hits=[...this.locations].filter(([,v])=>[...v.range.getClientRects()].some(r=>e.clientX>=r.left&&e.clientX<=r.right&&e.clientY>=r.top&&e.clientY<=r.bottom));if(hits.length){this.open();this._select(hits[0][0]);}});
        const original=File.saveAsUseNode,manager=this;
        if(typeof original==='function'){
            const saveAs=async function(...args){const previous=manager.ctx;manager._flushEditor();manager.savingAs=true;try{const result=await original.apply(this,args);if(!(result instanceof Error))manager._afterSaveAs(previous);else manager._draft(previous);return result;}finally{manager.savingAs=false;try{manager._switchDocument();manager._scan();manager._renderList();manager._showSelected();}catch(error){console.warn('[EditingToolbar] Annotation view refresh:',error);}}};
            File.saveAsUseNode=saveAs;if(File.FileSave?.saveAsUseNode===original)File.FileSave.saveAsUseNode=saveAs;
        }
    }
}
