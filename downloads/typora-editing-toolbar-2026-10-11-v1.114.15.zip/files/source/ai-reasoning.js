// Only text explicitly returned by the provider belongs in this disclosure.
class EditingToolbarAIReasoning {
  constructor(ai, turn, before) {
    this.ai=ai;this.turn=turn;
    this.root=ai.node('section','et-ai-reasoning');this.root.hidden=true;
    this.toggle=ai.node('button','et-ai-reasoning-toggle');this.toggle.type='button';
    this.toggle.innerHTML='<svg viewBox="0 0 20 20" aria-hidden="true"><path d="m7 4 6 6-6 6"/></svg>';
    this.label=ai.node('span');this.toggle.append(this.label);
    this.body=ai.node('div','et-ai-answer et-ai-reasoning-body');this.body.id='et-reasoning-'+reqnode('crypto').randomUUID();this.body.hidden=true;
    this.toggle.setAttribute('aria-controls',this.body.id);this.toggle.setAttribute('aria-expanded','false');
    this.root.append(this.toggle,this.body);before.before(this.root);
    this.toggle.onclick=()=>{this.manual=true;this.expanded=!this.expanded;this.update();};
  }
  update() {
    const t=this.turn,text=String(t.reasoning||''),thinking=t.status==='running'&&!t.answer;
    this.root.hidden=!!t.execution?.length||!text.trim();if(this.root.hidden)return;
    if(!this.manual)this.expanded=thinking;
    const title=t.reasoningKind==='summary'?'思考摘要':'思考过程';
    this.label.textContent=title+(thinking?' · 生成中…':['error','stopped'].includes(t.status)&&!t.answer?' · 未完成':'');
    this.toggle.title='模型接口返回的'+title+'，点击'+(this.expanded?'收起':'展开');
    this.toggle.setAttribute('aria-expanded',String(!!this.expanded));this.body.hidden=!this.expanded;
    if(!this.expanded||this.rendered===text)return;
    const bottom=this.body.scrollHeight-this.body.scrollTop-this.body.clientHeight<45;
    this.rendered=text;const serial=this.serial=(this.serial||0)+1,m=this.ai.toolbar.annotations;
    try{m._ensureRenderer().renderPreview(this.body,text,{...this.ai.referencesUI.options(this.turn),isCurrent:()=>this.root.isConnected&&this.serial===serial,renderMath:(tex,display)=>m._renderMath(tex,display),openLink:url=>{if(/^https?:\/\//i.test(url))reqnode('electron').shell.openExternal(url);}});}catch{this.body.textContent=text;}
    if(bottom)this.body.scrollTop=this.body.scrollHeight;
  }
}
