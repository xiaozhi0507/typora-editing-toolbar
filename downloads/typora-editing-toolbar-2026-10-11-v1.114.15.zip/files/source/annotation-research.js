import {TextSelection} from 'prosemirror-state';
import {closeHistory} from 'prosemirror-history';

// Only collect and insert content. Existing saved metadata is left untouched.
export function researchActions(view,io){
 const capture=()=>{const {selection,doc}=view.state;if(selection.empty)return null;const selected=selection.content().content;const markdown=io.serialize(doc.type.create(null,selected));if(!markdown.trim())return null;
  let image=0,math=0,plain=0;selected.descendants(n=>{if(n.type.name==='image')image++;else if(n.type.name.startsWith('math_'))math++;else if(n.isText&&n.text.trim())plain++;});
  return{markdown,kind:image?'image':math&&!plain?'math':'text'};
 };
 const append=markdown=>{if(!view.editable)return false;const parsed=io.parse(markdown),doc=view.state.doc,last=doc.lastChild;let tr=closeHistory(view.state.tr);if(last?.type.name==='paragraph'&&!last.content.size)tr=tr.replaceWith(doc.content.size-last.nodeSize,doc.content.size,parsed.content);else tr=tr.insert(doc.content.size,parsed.content);tr.setSelection(TextSelection.atEnd(tr.doc));view.dispatch(tr.scrollIntoView());view.dispatch(closeHistory(view.state.tr));view.focus();return true;};
 return{capture,append};
}
