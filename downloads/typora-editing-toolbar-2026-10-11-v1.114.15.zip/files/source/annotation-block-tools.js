import {Plugin,TextSelection,NodeSelection} from 'prosemirror-state';
import {Decoration,DecorationSet} from 'prosemirror-view';
import {closeHistory} from 'prosemirror-history';

export function removeEmptyNoteBlock(state,dispatch,pos,node){
 if(!node||!['heading','code_block','math_block','math_inline'].includes(node.type.name))return false;
 if(['heading','code_block'].includes(node.type.name)?node.content.size:node.attrs.tex.length)return false;
 const at=state.doc.resolve(pos),paragraph=state.schema.nodes.paragraph;
 if(!node.isInline&&!at.parent.canReplaceWith(at.index(),at.index()+1,paragraph))return false;
 if(dispatch){
  const tr=closeHistory(state.tr).replaceWith(pos,pos+node.nodeSize,node.isInline?[]:paragraph.create());
  tr.setSelection(TextSelection.near(tr.doc.resolve(node.isInline?pos:pos+1))).setStoredMarks([]);
  dispatch(tr.scrollIntoView());
 }
 return true;
}

export function emptyNoteBlockDelete(state,dispatch,view){
 if(!view?.editable||view.composing)return false;
 const s=state.selection;
 if(s instanceof NodeSelection)return removeEmptyNoteBlock(state,dispatch,s.from,s.node);
 if(!s.empty||!['heading','code_block'].includes(s.$from.parent.type.name)||s.$from.parent.content.size)return false;
 return removeEmptyNoteBlock(state,dispatch,s.$from.before(),s.$from.parent);
}

function decorations(doc){
 const items=[];doc.forEach((node,pos)=>{
  const attrs={class:'note-draggable-block'};
  if(node.type.name==='heading')attrs['data-note-heading']='H'+node.attrs.level;
  items.push(Decoration.node(pos,pos+node.nodeSize,attrs));
 });return DecorationSet.create(doc,items);
}

export function noteBlockTools(){
 const plugin=new Plugin({
  state:{init:(_,s)=>decorations(s.doc),apply:(tr,old)=>tr.docChanged?decorations(tr.doc):old},
  props:{decorations:state=>plugin.getState(state)},
  view:view=>blockGutter(view)
 });return plugin;
}

function blockGutter(view){
 const doc=view.dom.ownerDocument,win=doc.defaultView;
 const grip=doc.createElement('button');grip.className='note-block-grip';grip.type='button';grip.hidden=true;
 grip.innerHTML='<svg viewBox="0 0 16 20" aria-hidden="true" fill="currentColor"><circle cx="5" cy="5" r="1.3"/><circle cx="11" cy="5" r="1.3"/><circle cx="5" cy="10" r="1.3"/><circle cx="11" cy="10" r="1.3"/><circle cx="5" cy="15" r="1.3"/><circle cx="11" cy="15" r="1.3"/></svg>';
 const line=doc.createElement('div');line.className='note-block-drop-line';line.hidden=true;
 const shade=doc.createElement('div');shade.className='note-block-drag-shade';shade.hidden=true;
 doc.body.append(grip,line,shade);
 let hot=null,drag=null,raf=0,layoutFrame=0,destroyed=false;
 const blocks=()=>{const result=[];view.state.doc.forEach((node,pos)=>{const dom=view.nodeDOM(pos);if(dom?.getBoundingClientRect)result.push({node,pos,dom,rect:dom.getBoundingClientRect()});});return result;};
 const dockBottom=()=>doc.querySelector('.note-editor-dock')?.getBoundingClientRect().bottom||0;
 const label=node=>node.type.name==='heading'?'H'+node.attrs.level+' 标题':({paragraph:'段落',code_block:'代码块',math_block:'公式块',blockquote:'引用块',note_card:'卡片',bullet_list:'列表',ordered_list:'列表',table:'表格',horizontal_rule:'分割线',note_video:'视频'})[node.type.name]||'内容块';
 const show=block=>{
  hot=block?.pos??null;
  if(!block||!view.editable||block.rect.bottom<dockBottom()+5||block.rect.top>win.innerHeight-8){grip.hidden=true;return;}
  grip.hidden=false;grip.dataset.blockPos=block.pos;
  grip.setAttribute('aria-label','拖动'+label(block.node));grip.title='拖动'+label(block.node)+'调整顺序';
  grip.style.left=Math.max(2,block.rect.left-22)+'px';grip.style.top=Math.max(dockBottom()+3,block.rect.top+1)+'px';
 };
 const clean=()=>{
  const active=drag;drag=null;cancelAnimationFrame(raf);raf=0;line.hidden=shade.hidden=true;grip.classList.remove('dragging');doc.body.classList.remove('note-block-dragging');
  if(active&&grip.hasPointerCapture(active.pointerId))grip.releasePointerCapture(active.pointerId);
 };
 const moveBlock=(from,to,target,node)=>{
  if(target===from||target===to)return;
  const dest=target>from?target-(to-from):target;
  let tr=closeHistory(view.state.tr).delete(from,to).insert(dest,node);
  tr.setSelection(node.isAtom?NodeSelection.create(tr.doc,dest):TextSelection.near(tr.doc.resolve(dest+1))).setStoredMarks([]).setMeta('uiEvent','drop');
  view.dispatch(tr.scrollIntoView());view.dispatch(closeHistory(view.state.tr));view.focus();hot=dest;show(blocks().find(b=>b.pos===dest));
 };
 const targetAt=y=>{
  const list=blocks(),last=list.at(-1);if(!last)return null;
  for(let i=0;i<list.length;i++)if(y<list[i].rect.top+list[i].rect.height/2){
   const prev=list[i-1];return{pos:list[i].pos,y:prev?(prev.rect.bottom+list[i].rect.top)/2:list[i].rect.top-3,left:list[i].rect.left,right:list[i].rect.right};
  }
  return{pos:view.state.doc.content.size,y:last.rect.bottom+5,left:last.rect.left,right:last.rect.right};
 };
 const paintDrag=()=>{
  if(!drag?.started)return;
  if(view.state.doc!==drag.doc){clean();return;}
  const b=blocks().find(b=>b.pos===drag.from),target=targetAt(drag.y);if(!b||!target){clean();return;}
  drag.target=target.pos;shade.hidden=false;Object.assign(shade.style,{left:b.rect.left+'px',top:b.rect.top+'px',width:b.rect.width+'px',height:Math.max(4,b.rect.height)+'px'});
  const noMove=target.pos===drag.from||target.pos===drag.to;
  line.hidden=noMove||target.y<dockBottom()+2||target.y>win.innerHeight-2;
  Object.assign(line.style,{left:target.left+'px',top:target.y+'px',width:Math.max(24,target.right-target.left)+'px'});
 };
 const tick=()=>{
  raf=0;if(!drag?.started||destroyed)return;
  const top=dockBottom()+32,bottom=win.innerHeight-34;
  const speed=drag.y<top?-Math.min(18,(top-drag.y)/2):drag.y>bottom?Math.min(18,(drag.y-bottom)/2):0;
  if(speed)win.scrollBy(0,speed);paintDrag();if(drag)raf=win.requestAnimationFrame(tick);
 };
 const pointerMove=e=>{
  if(drag){drag.x=e.clientX;drag.y=e.clientY;if(!drag.started&&Math.hypot(e.clientX-drag.startX,e.clientY-drag.startY)>4){drag.started=true;grip.classList.add('dragging');doc.body.classList.add('note-block-dragging');raf=win.requestAnimationFrame(tick);}paintDrag();return;}
  if(grip.contains(e.target))return;
  if(!view.editable||view.composing||e.buttons||e.target.closest?.('.note-child-panel,.note-format-toolbar,.note-editor-dock')){if(doc.activeElement!==grip)show(null);return;}
  const area=view.dom.getBoundingClientRect();
  if(e.clientX<area.left||e.clientX>area.right||e.clientY<dockBottom()){show(null);return;}
  show(blocks().find(b=>e.clientY>=b.rect.top-3&&e.clientY<=b.rect.bottom+3));
 };
 grip.addEventListener('pointerdown',e=>{
  if(e.button!==0||!view.editable||view.composing)return;
  const b=blocks().find(b=>b.pos===hot);if(!b)return;
  e.preventDefault();e.stopPropagation();grip.focus({preventScroll:true});
  drag={from:b.pos,to:b.pos+b.node.nodeSize,node:b.node,doc:view.state.doc,startX:e.clientX,startY:e.clientY,x:e.clientX,y:e.clientY,pointerId:e.pointerId,started:false};grip.setPointerCapture(e.pointerId);
 });
 const pointerUp=e=>{if(!drag)return;const d=drag;e.preventDefault();e.stopPropagation();paintDrag();const target=d.target,area=view.dom.getBoundingClientRect(),inside=e.clientX>=area.left&&e.clientX<=area.right&&e.clientY>=dockBottom()&&e.clientY<=win.innerHeight;clean();if(inside&&d.started&&view.editable&&view.state.doc===d.doc&&target!=null)moveBlock(d.from,d.to,target,d.node);};
 const cancel=()=>clean();
 const keydown=e=>{
  if(e.key==='Escape'&&drag){e.preventDefault();e.stopPropagation();clean();return;}
  if(e.target!==grip||!e.altKey||!['ArrowUp','ArrowDown'].includes(e.key)||!view.editable)return;
  const list=blocks(),i=list.findIndex(b=>b.pos===hot),b=list[i],other=list[i+(e.key==='ArrowUp'?-1:1)];if(!b||!other)return;
  e.preventDefault();moveBlock(b.pos,b.pos+b.node.nodeSize,e.key==='ArrowUp'?other.pos:other.pos+other.node.nodeSize,b.node);
 };
 const refresh=()=>{if(layoutFrame)return;layoutFrame=win.requestAnimationFrame(()=>{layoutFrame=0;if(drag)paintDrag();else if(hot!==null)show(blocks().find(b=>b.pos===hot));});};
 const leave=()=>{if(!drag&&doc.activeElement!==grip)show(null);};
 doc.addEventListener('pointermove',pointerMove);doc.addEventListener('pointerup',pointerUp,true);doc.addEventListener('pointercancel',cancel);doc.addEventListener('keydown',keydown,true);doc.documentElement.addEventListener('pointerleave',leave);
 grip.addEventListener('lostpointercapture',cancel);win.addEventListener('blur',cancel);win.addEventListener('scroll',refresh);win.addEventListener('resize',refresh);
 const resize=new ResizeObserver(refresh);resize.observe(view.dom);
 return{update(v,prev){view=v;if(drag&&(v.state.doc!==drag.doc||!v.editable))clean();if(v.state.doc!==prev.doc){hot=null;grip.hidden=true;}else refresh();},destroy(){destroyed=true;clean();cancelAnimationFrame(layoutFrame);resize.disconnect();doc.removeEventListener('pointermove',pointerMove);doc.removeEventListener('pointerup',pointerUp,true);doc.removeEventListener('pointercancel',cancel);doc.removeEventListener('keydown',keydown,true);doc.documentElement.removeEventListener('pointerleave',leave);win.removeEventListener('blur',cancel);win.removeEventListener('scroll',refresh);win.removeEventListener('resize',refresh);grip.remove();line.remove();shade.remove();}};
}
