'use strict';
// Discover linked Markdown files without opening, moving or rewriting their contents.
class KnowledgeLibraryImport {
  constructor(store) { this.store = store; this.io = store.io; this.path = store.path; }
  normalize(file) { const value = this.path.normalize(file); return this.store.process.platform === 'win32' ? value.toLowerCase() : value; }
  async key(file) { return this.normalize(await this.io.realpath(file).catch(() => this.path.resolve(file))); }
  markdown(file) { return /\.(md|markdown|mdown)$/i.test(file); }
  auxiliary(name) { return name.startsWith('.') || ['_xref', '_assets', 'node_modules'].includes(name.toLowerCase()) || /\.(资料|笔记|注释|标注)$/.test(name); }
  async scan(paths, existing = [], options = {}) {
    const { signal, onProgress = () => {}, detectBook } = options;
    const result = { files: [], duplicates: 0, ignored: 0, folders: 0, entries: 0, warningCount: 0, warnings: [] };
    const check = () => {
      if (signal?.aborted) { const error = new Error('已取消导入'); error.name = 'AbortError'; throw error; }
      if (result.files.length > 10000 || result.entries > 100000) throw new Error('文件夹过大，请分批拖入（本次尚未导入条目）。');
    };
    const warn = (file, error) => { result.warningCount++; if (result.warnings.length < 6) result.warnings.push(file + '：' + (error.code || error.message)); };
    const known = new Map(), seenFiles = new Set(), seenDirectories = new Set();
    onProgress('正在核对已有文件…');
    for (const entry of existing) {
      check();
      if(entry.file.linkType==='url')continue;
      const target = this.store.resolveFile(entry.file); if (!this.markdown(target)) continue;
      for(const candidate of [target,entry.file.sourcePath].filter(Boolean)){
        const key = await this.key(candidate), old = known.get(key);
        if (!old || old.deleted && !entry.deleted) known.set(key, entry);
      }
    }
    const queue = [...new Set(paths)].reverse().map(file => ({ file, explicit: true }));
    while (queue.length) {
      check();
      const { file, explicit } = queue.pop(); result.entries++;
      if (typeof file !== 'string' || !this.path.isAbsolute(file) || file.includes('\0')) { warn(String(file), new Error('不是有效本地路径')); continue; }
      let stat;
      try { stat = explicit ? await this.io.stat(file) : await this.io.lstat(file); }
      catch (error) { warn(file, error); continue; }
      // Do not descend into nested junctions/symlinks or generated sidecar folders.
      if (stat.isSymbolicLink()) { result.ignored++; continue; }
      if(detectBook&&(stat.isDirectory()||stat.isFile()&&/^(?:目录|目錄|index|readme)\.md$/i.test(this.path.basename(file)))){
        if(!explicit&&this.auxiliary(this.path.basename(file))){result.ignored++;continue;}
        const book=await detectBook(file,{signal});check();
        if(book){
          const entry=this.path.join(book.folder,book.entry),key=await this.key(entry);
          if(seenFiles.has(key)){result.duplicates++;continue;}seenFiles.add(key);
          const previous=known.get(key);
          result.files.push({key,kind:'book',book,file:this.store.fileRef(entry,'Markdown'),title:book.metadata.fields.title||this.path.basename(book.folder),existingId:previous?.id||null,deleted:!!previous?.deleted});
          result.folders++;onProgress('已识别整本书：'+this.path.basename(book.folder));continue;
        }
      }
      if (stat.isDirectory()) {
        if (!explicit && this.auxiliary(this.path.basename(file))) { result.ignored++; continue; }
        const key = await this.key(file); if (seenDirectories.has(key)) continue; seenDirectories.add(key);
        result.folders++;
        let entries;
        try { entries = await this.io.readdir(file, { withFileTypes: true }); }
        catch (error) { warn(file, error); continue; }
        if (result.entries + queue.length + entries.length > 100000) throw new Error('文件夹过大，请分批拖入（本次尚未导入条目）。');
        entries.sort((a, b) => a.name.localeCompare(b.name, 'zh-CN', { numeric: true }));
        for (let n = entries.length - 1; n >= 0; n--) {
          const entry = entries[n];
          if (entry.isDirectory() && this.auxiliary(entry.name) || entry.isFile() && !this.markdown(entry.name)) { result.ignored++; continue; }
          queue.push({ file: this.path.join(file, entry.name), explicit: false });
        }
      } else if (stat.isFile() && this.markdown(file)) {
        const key = await this.key(file);
        if (seenFiles.has(key)) { result.duplicates++; continue; } seenFiles.add(key);
        const previous = known.get(key);
        result.files.push({ key, file: this.store.fileRef(file, 'Markdown'), title: this.path.basename(file, this.path.extname(file)), existingId: previous?.id || null, deleted: !!previous?.deleted });
      } else result.ignored++;
      if (result.entries % 32 === 0) {
        onProgress('已扫描 ' + result.folders + ' 个文件夹，识别 ' + result.files.length + ' 个 Markdown…');
        await new Promise(resolve => setTimeout(resolve, 0));
      }
    }
    // A folder plus its TOC/chapters in the same drop still represents one book.
    const books=result.files.filter(f=>f.kind==='book');
    result.files=result.files.filter(entry=>{
      const redundant=books.some(book=>book!==entry&&(()=>{const relative=this.path.relative(book.book.folder,entry.kind==='book'?entry.book.folder:this.store.resolveFile(entry.file));return relative!==''&&!relative.startsWith('..'+this.path.sep)&&relative!=='..'&&!this.path.isAbsolute(relative);})());
      if(redundant)result.duplicates++;return !redundant;
    });
    check(); return result;
  }
}
module.exports = KnowledgeLibraryImport;
