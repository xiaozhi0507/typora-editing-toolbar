const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path'),crypto=require('crypto'),http=require('http');
const {ChatGPTService,publicError,requestJSON,CLIENT_VERSION}=require('./ai-chatgpt-service.cjs');
const ISS='https://auth.openai.com';
const keys=crypto.generateKeyPairSync('rsa',{modulusLength:2048}),jwk={...keys.publicKey.export({format:'jwk'}),kid:'test',alg:'RS256',use:'sig'};
const jwt=(claims,key=keys.privateKey,header={alg:'RS256',kid:'test'})=>{const a=Buffer.from(JSON.stringify(header)).toString('base64url')+'.'+Buffer.from(JSON.stringify(claims)).toString('base64url');return a+'.'+crypto.sign('sha256',Buffer.from(a),key).toString('base64url');};
const get=url=>new Promise((resolve,reject)=>{http.get(url,r=>{r.resume();r.on('end',()=>resolve(r.statusCode));}).on('error',reject);});
function fixture(t){
  const base=path.join(os.homedir(),'Downloads','codex-temp'),dir=fs.mkdtempSync(path.join(base,'chatgpt-auth-test-'));t.after(()=>{if(!path.resolve(dir).startsWith(path.resolve(base)+path.sep))throw Error('Unsafe cleanup');fs.rmSync(dir,{recursive:true,force:true});});
  const f={dir,now:Date.now(),calls:[],scope:'openid email profile offline_access resource.invoke chatgpt.tokens.use.direct',subject:'user-a',nonce:'',rotation:0};
  f.claims=()=>({iss:ISS,aud:'oaiapp_test',sub:f.subject,nonce:f.nonce,exp:f.now/1000+3600,iat:f.now/1000,email:'test@example.invalid',name:'测试账号'});
  f.transport=async(url,opts={})=>{f.calls.push({url,opts});if(url.endsWith('openid-configuration'))return {issuer:ISS,jwks_uri:ISS+'/jwks',revocation_endpoint:ISS+'/revoke'};if(url.endsWith('/jwks'))return {keys:[jwk]};if(url.endsWith('/oauth/token')){if(f.tokenError)throw Object.assign(Error('Token failure'),{code:f.tokenError});return {token_type:'Bearer',id_token:jwt(f.claims()),access_token:'ACCESS_SECRET_'+(++f.rotation),refresh_token:'REFRESH_SECRET_'+f.rotation,expires_in:3600,scope:f.scope};}if(new URL(url).pathname.endsWith('/models'))return {models:[{slug:'model-a',display_name:'Model A',visibility:'list'},{slug:'hidden',visibility:'hidden'}]};if(url.endsWith('/revoke')){if(f.revokeError)throw Error('Offline');return {};}throw Error('Unexpected URL');};
  f.service=new ChatGPTService(dir,{transport:f.transport,now:()=>f.now,protect:async(s,decrypt)=>decrypt?Buffer.from(s,'base64').toString():Buffer.from(s).toString('base64'),client:{request:async(p,key,m,o)=>{f.inference={p,key,m};o.onText?.('回答');return {text:'回答'};}}});
  f.login=async(opts={})=>f.service.signIn(opts.returning?'oaiapp_test':undefined,{signal:opts.signal,onAuthorize:url=>{f.url=new URL(url);f.nonce=f.url.searchParams.get('nonce');const callback=new URL(f.url.searchParams.get('redirect_uri'));callback.searchParams.set('state',f.url.searchParams.get('state'));callback.searchParams.set('client_id',opts.clientId||'oaiapp_test');callback.searchParams.set('code','code-test');get(callback.toString()).catch(()=>{});}});
  return f;
}
test('dynamic registration uses loopback, PKCE, nonce and state, stores only protected tokens',async t=>{
  const f=fixture(t),a=await f.login();assert.equal(a.enabled,true);assert.equal(f.url.origin,ISS);assert.equal(f.url.searchParams.get('client_id'),'dynamic_agent_client');assert.equal(f.url.searchParams.get('agent_name_hint'),'Typora AI 阅读助手');assert.equal(f.url.searchParams.get('code_challenge_method'),'S256');
  const exchange=f.calls.find(x=>x.opts.form?.grant_type==='authorization_code').opts.form;assert.equal(exchange.client_id,'oaiapp_test');assert.equal(exchange.redirect_uri,f.url.searchParams.get('redirect_uri'));assert.equal(new URL(exchange.redirect_uri).hostname,'127.0.0.1');assert.equal(crypto.createHash('sha256').update(exchange.code_verifier).digest('base64url'),f.url.searchParams.get('code_challenge'));
  const bytes=fs.readFileSync(path.join(f.dir,'credentials.dpapi'),'utf8');assert.ok(!bytes.includes('SECRET'));assert.ok(!JSON.stringify(a).includes('token'));assert.ok(!JSON.stringify(await f.service.list()).includes('SECRET'));assert.equal((await f.service.read()).accounts[0].access_token,'ACCESS_SECRET_1');
});
test('reauthorization retains host/client and validates the original identity',async t=>{
  const f=fixture(t);await f.login();const host=f.url.searchParams.get('ext_agent_host_id');await f.login({returning:true});assert.equal(f.url.searchParams.get('ext_agent_host_id'),host);assert.equal(f.url.searchParams.get('client_id'),'oaiapp_test');assert.equal(f.url.searchParams.has('agent_name_hint'),false);assert.equal(f.url.searchParams.has('id_token_hint'),false);
  f.subject='attacker';await assert.rejects(f.login({returning:true}),/身份校验/);assert.equal((await f.service.read()).accounts[0].subject,'user-a');
});
test('wrong state cannot consume an authorization attempt; cancellation closes listener',async t=>{
  const f=fixture(t),controller=new AbortController();let callback,wrongStatus;
  const task=f.service.signIn(undefined,{signal:controller.signal,onAuthorize:async url=>{const u=new URL(url);callback=new URL(u.searchParams.get('redirect_uri'));callback.searchParams.set('state','wrong');wrongStatus=await get(callback.toString());controller.abort();}});
  await assert.rejects(task,{name:'AbortError'});assert.equal(wrongStatus,400);assert.equal(f.calls.length,0);await assert.rejects(get(callback.toString()));assert.equal((await f.service.list()).length,0);
});
test('denied consent and changed returning client never exchange tokens',async t=>{
  const f=fixture(t);await assert.rejects(f.service.signIn(undefined,{onAuthorize:url=>{const u=new URL(url),callback=new URL(u.searchParams.get('redirect_uri'));callback.searchParams.set('state',u.searchParams.get('state'));callback.searchParams.set('error','access_denied');get(callback.toString());}}),{code:'access_denied'});assert.equal(f.calls.length,0);
  await f.login();const before=f.rotation;await assert.rejects(f.login({returning:true,clientId:'oaiapp_other'}),/注册信息/);assert.equal(f.rotation,before);
});
test('signature, issuer, audience, expiration and nonce are all verified',async t=>{
  const f=fixture(t),claims={...f.claims(),nonce:'expected'};for(const change of [{iss:'https://evil.invalid'},{aud:'wrong'},{azp:'wrong'},{exp:f.now/1000-1},{nonce:'wrong'},{sub:''}])await assert.rejects(f.service.verify(jwt({...claims,...change}),'oaiapp_test',claims.nonce||'expected'),/身份校验/);
  await assert.rejects(f.service.verify(jwt({...claims,nonce:'n'},crypto.generateKeyPairSync('rsa',{modulusLength:2048}).privateKey),'oaiapp_test','n'),/身份校验/);
  assert.equal((await f.service.verify(jwt({...claims,nonce:'n'}),'oaiapp_test','n')).sub,'user-a');
});
test('identity-only grant is saved but cannot list models or run inference',async t=>{
  const f=fixture(t);f.scope='openid profile email';const a=await f.login();assert.equal(a.enabled,false);await assert.rejects(f.service.models(a.id),/尚未授权套餐/);assert.ok(!f.calls.some(c=>new URL(c.url).pathname.endsWith('/models')));
});
test('refresh rotates credentials once for concurrent requests and retains registration after expiry',async t=>{
  const f=fixture(t);await f.login();f.now+=3600*1000;await Promise.all([f.service.credentials('oaiapp_test'),f.service.credentials('oaiapp_test')]);assert.equal(f.calls.filter(c=>c.opts.form?.grant_type==='refresh_token').length,1);assert.equal((await f.service.read()).accounts[0].refresh_token,'REFRESH_SECRET_2');
  f.now+=3600*1000;f.tokenError='invalid_grant';await assert.rejects(f.service.credentials('oaiapp_test'));const a=(await f.service.read()).accounts[0];assert.equal(a.client_id,'oaiapp_test');assert.equal(a.access_token,undefined);assert.equal(a.refresh_token,undefined);
});
test('transport failures preserve saved credentials and failed exchange retains issued client',async t=>{
  const f=fixture(t);f.tokenError='invalid_grant';await assert.rejects(f.login());assert.equal((await f.service.read()).accounts[0].client_id,'oaiapp_test');f.tokenError=null;await f.login({returning:true});f.now+=3600*1000;f.tokenError='temporarily_unavailable';await assert.rejects(f.service.credentials('oaiapp_test'));assert.ok((await f.service.read()).accounts[0].refresh_token);
});
test('catalog respects visibility/order; inference pins official endpoint and strips user-supplied extras',async t=>{
  const f=fixture(t);await f.login();assert.deepEqual(await f.service.models('oaiapp_test'),[{id:'model-a',name:'Model A'}]);const messages=[{role:'user',content:'资料'}];await f.service.request({chatgptAccount:'oaiapp_test',model:'model-a',url:'https://evil.invalid',extra:'{}',maxTokensEnabled:true,temperatureEnabled:true},messages,{});
  assert.equal(f.inference.p.url,'https://api.openai.com/v1/responses');assert.equal(f.inference.p.extra,undefined);assert.equal(f.inference.p.temperatureEnabled,undefined);assert.equal(f.inference.key,'ACCESS_SECRET_1');assert.deepEqual(f.inference.m,messages);await assert.rejects(f.service.request({chatgptAccount:'oaiapp_test',model:'hidden'},messages,{}),/模型列表/);
});
test('sign out clears every token, retains account/host and reports revocation failure',async t=>{
  const f=fixture(t);await f.login();const host=f.service.host();f.revokeError=true;assert.deepEqual(await f.service.disconnect('oaiapp_test'),{revoked:false});const a=(await f.service.read()).accounts[0];assert.equal(a.access_token,undefined);assert.equal(a.id_token,undefined);assert.equal(a.refresh_token,undefined);assert.equal(a.subject,'user-a');assert.equal(f.service.host(),host);assert.equal((await f.service.list())[0].connected,false);
});
test('account edit mode permits only the built-in current-document tool and carries continuation results',async t=>{
  const f=fixture(t);await f.login();const messages=[{role:'system',content:'edit'},{role:'user',content:'原文'},{role:'assistant',content:'',responseItems:[{type:'function_call',call_id:'c1',name:'edit_current_document',arguments:'{}'}]},{role:'tool',tool_call_id:'c1',content:'{"applied":true}'}];
  await f.service.request({chatgptAccount:'oaiapp_test',model:'model-a',documentEdit:true,tools:[{name:'shell'}],extra:'{"tools":[{"name":"shell"}]}'},messages,{});
  const body=require('./ai-client.cjs').body(f.inference.p,f.inference.m);assert.equal(body.tools.length,2);assert.deepEqual(body.tools.map(t=>t.name),['read_current_document','edit_current_document']);assert.equal(body.input.at(-1).type,'function_call_output');assert.equal(body.input.at(-1).call_id,'c1');assert.equal(body.store,false);
});
test('model catalog includes actual assistant version and remains server-driven',async t=>{
  const f=fixture(t);await f.login();const transport=f.service.transport;
  f.service.transport=async(url,opts)=>{const u=new URL(url);if(u.pathname==='/v1/models'){
    assert.equal(u.origin,'https://api.openai.com');assert.deepEqual([...u.searchParams],[['client_version',CLIENT_VERSION]]);assert.equal(opts.token,'ACCESS_SECRET_1');
    return {models:[{slug:'newly-released-model',display_name:'New release',visibility:'list'},{slug:'hidden-new-model',visibility:'hide'}]};
  }return transport(url,opts);};
  assert.deepEqual(await f.service.models('oaiapp_test'),[{id:'newly-released-model',name:'New release'}]);
  const host=fs.readFileSync(path.join(__dirname,'knowledge-library-host.js'),'utf8');assert.ok(host.includes("this.version = '"+CLIENT_VERSION+"'"),'helper version must match assistant release');
});
test('unsafe remote URLs rejected and quota errors have actionable explanation',async()=>{
  assert.throws(()=>requestJSON('http://auth.openai.com/api/accounts/oauth/token'),/非官方/);assert.throws(()=>requestJSON('https://evil.invalid'),/非官方/);assert.match(publicError({code:'subscription_sharing_usage_limit_exceeded'}).message,/管理额度/);
});
test('account Responses requests stream, disable storage and preserve quota failures after partial output',async t=>{
  const Client=require('./ai-client.cjs'),client=new Client(require),requests=[];
  const server=http.createServer((req,res)=>{let raw='';req.on('data',b=>raw+=b);req.on('end',()=>{
    const body=JSON.parse(raw);requests.push(body);res.setHeader('Content-Type','text/event-stream');
    const emit=packet=>res.write('data: '+JSON.stringify(packet)+'\n\n');emit({type:'response.output_text.delta',delta:'已输出的一部分'});
    if(body.model==='event-quota')emit({type:'error',code:'subscription_sharing_usage_limit_exceeded',message:'limit qa-secret'});
    else if(body.model==='quota')emit({type:'response.failed',response:{error:{code:'subscription_sharing_usage_limit_exceeded',message:'limit qa-secret'}}});
    else emit({type:'response.completed',response:{status:'completed'}});res.end();
  });});await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>{server.closeAllConnections();return new Promise(r=>server.close(r));});
  const p={url:'http://127.0.0.1:'+server.address().port+'/responses',fullUrl:true,protocol:'openai-responses',authType:'chatgpt',model:'ok'},messages=[{role:'system',content:'系统要求'},{role:'user',content:'提问'}];
  assert.equal((await client.request(p,'qa-secret',messages,{})).text,'已输出的一部分');assert.equal(requests[0].stream,true);assert.equal(requests[0].store,false);assert.equal(requests[0].instructions,'系统要求');assert.ok(Array.isArray(requests[0].input));
  let partial;await assert.rejects(client.request({...p,model:'quota'},'qa-secret',messages,{onText:text=>partial=text}),e=>e.code==='subscription_sharing_usage_limit_exceeded'&&!e.message.includes('qa-secret'));assert.equal(partial,'已输出的一部分');await assert.rejects(client.request({...p,model:'event-quota'},'qa-secret',messages,{}),e=>e.code==='subscription_sharing_usage_limit_exceeded'&&!e.message.includes('qa-secret'));
});
test('account inference rejects non-stream, incomplete and truncated responses',async t=>{
  const Client=require('./ai-client.cjs'),client=new Client(require);
  const server=http.createServer((req,res)=>{let raw='';req.on('data',b=>raw+=b);req.on('end',()=>{
    const {model}=JSON.parse(raw);if(model==='json'){res.setHeader('Content-Type','application/json');return res.end(JSON.stringify({status:'completed',output_text:'不应该完成'}));}
    res.setHeader('Content-Type','text/event-stream');res.write('data: '+JSON.stringify({type:'response.output_text.delta',delta:'部分回答'})+'\n\n');
    if(model==='incomplete')res.write('data: '+JSON.stringify({type:'response.incomplete',response:{status:'incomplete',incomplete_details:{reason:'max_output_tokens'}}})+'\n\n');res.end();
  });});await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>{server.closeAllConnections();return new Promise(r=>server.close(r));});
  for(const model of ['json','incomplete','truncated'])await assert.rejects(client.request({url:'http://127.0.0.1:'+server.address().port+'/responses',fullUrl:true,protocol:'openai-responses',authType:'chatgpt',model},'qa-secret',[{role:'user',content:'问题'}],{}));
});

test('helper enforces catalog effort and strips unrelated fast-mode parameters',async t=>{
  const f=fixture(t);await f.login();const old=f.service.transport;
  f.service.transport=async(url,opts)=>new URL(url).pathname.endsWith('/models')?{models:[{slug:'gpt-6.1-sol',display_name:'GPT-6.1 Sol',visibility:'list',supported_reasoning_levels:['low','medium','high','xhigh','max','ultra'].map(effort=>({effort})),default_reasoning_level:'medium'}]}:old(url,opts);
  const [m]=await f.service.models('oaiapp_test');assert.deepEqual(m.reasoningEfforts,['low','medium','high','xhigh']);
  for(const effort of ['low','medium','high','xhigh','ultra']){
    await f.service.request({chatgptAccount:'oaiapp_test',model:m.id,reasoningEffort:effort,extra:'{"service_tier":"priority","reasoning":{"effort":"ultra"}}',service_tier:'priority'},[{role:'user',content:'test'}],{});
    assert.equal(f.inference.p.reasoningEffort,effort==='ultra'?'xhigh':effort);assert.equal(f.inference.p.extra,undefined);assert.equal(f.inference.p.service_tier,undefined);
    assert.equal(require('./ai-client.cjs').body(f.inference.p,f.inference.m).reasoning.effort,effort==='ultra'?'xhigh':effort);
  }
});
test('helper does not trust UI-supplied reasoning capability for unsupported models',async t=>{
  const f=fixture(t);await f.login();await assert.rejects(f.service.request({chatgptAccount:'oaiapp_test',model:'model-a',reasoningEffort:'high',reasoningEfforts:['high']},[{role:'user',content:'test'}],{}),/未提供可用的思考档位/);assert.equal(f.inference,undefined);
});

test('account bridge forwards explicit shell capability without changing model or exposing credentials',async t=>{
 const f=fixture(t);await f.login();await f.service.request({chatgptAccount:'oaiapp_test',model:'model-a',shellEnabled:true,project:{trusted:true,root:'C:\\project'},shellGrant:'LOCAL_ONLY'},[{role:'user',content:'运行命令'}],{});
 assert.equal(f.inference.p.shellEnabled,true);assert.equal(f.inference.p.model,'model-a');assert.equal(f.inference.p.shellGrant,undefined);assert.deepEqual(require('./ai-client.cjs').tools(f.inference.p).map(t=>t.name),['run_shell_command']);
});
test('ChatGPT bridge preserves skill instructions, progressive tools and local execution guards',async t=>{
 const f=fixture(t);await f.login();const messages=[{role:'system',content:'User instructions have priority'},{role:'user',content:'Selected skill: use 结论、例子、检查'},{role:'user',content:'Explain derivative'}];
 await f.service.request({chatgptAccount:'oaiapp_test',model:'model-a',skillsEnabled:true,skillScripts:true},messages,{});
 assert.deepEqual(f.inference.m,messages);assert.equal(f.inference.p.skillsEnabled,true);assert.deepEqual(require('./ai-client.cjs').tools(f.inference.p).map(t=>t.name),['read_skill','read_skill_resource']);
 await f.service.request({chatgptAccount:'oaiapp_test',model:'model-a',skillsEnabled:true,skillScripts:true,shellEnabled:true,project:{trusted:true}},messages,{});
 assert.ok(require('./ai-client.cjs').tools(f.inference.p).some(t=>t.name==='run_skill_script'));
 await f.service.request({chatgptAccount:'oaiapp_test',model:'model-a',skillsEnabled:false},messages,{});assert.equal(require('./ai-client.cjs').tools(f.inference.p).length,0);
});


test('account service retains attached file scope and never imports draft or permission fields',async t=>{
 const f=fixture(t);await f.login();const Client=require('./ai-client.cjs'),codeFiles=[{file:'C:\\project\\main.py',kind:'editable',text:'private draft',projectRoot:'private root',grant:true},{file:'legacy.py'}];
 for(const documentEdit of [true,false]){
  await f.service.request({chatgptAccount:'oaiapp_test',model:'model-a',codeFiles,documentEdit,webSearch:true,shellEnabled:true,skillsEnabled:true,project:{trusted:true}},[],{});
  assert.deepEqual(f.inference.p.codeFiles,[{file:codeFiles[0].file,kind:'editable'},{file:'legacy.py'}]);
  assert.deepEqual(Client.tools(f.inference.p).map(t=>t.name),documentEdit?['read_code_file','edit_code_file','run_python_file','read_skill','read_skill_resource']:['read_code_file','read_skill','read_skill_resource']);
 }
 f.inference=null;await assert.rejects(f.service.request({chatgptAccount:'oaiapp_test',model:'model-a',codeFiles:[{file:'bad\0name'}]},[],{}),/关联文件信息无效/);assert.equal(f.inference,null);
});
test('ChatGPT plugin bridge preserves allowed IDs and never copies connector credentials',async t=>{
 const f=fixture(t);await f.login();await f.service.request({chatgptAccount:'oaiapp_test',model:'model-a',pluginsEnabled:['github','data','unknown'],pluginToken:'PRIVATE_CONNECTOR_TOKEN',googleConfig:{client_secret:'PRIVATE_CONFIG'}},[{role:'user',content:'Read my selected repo'}],{});
 assert.deepEqual(f.inference.p.pluginsEnabled,['github','data']);assert.ok(!JSON.stringify(f.inference.p).includes('PRIVATE_'));assert.ok(require('./ai-client.cjs').tools(f.inference.p).some(t=>t.name==='plugin_read'));
});
test('renderer JSON and account service carry read edit run tools and Responses continuation end to end',async t=>{
 const f=fixture(t);await f.login();const Client=require('./ai-client.cjs'),client=new Client(require),vm=require('node:vm'),requests=[];
 const file='C:\\project\\main.py',calls=[['read_code_file',{file}],['edit_code_file',{file,summary:'更新输出',edits:[{old_text:'print(1)',new_text:'print(42)'}]}],['run_python_file',{file}]];
 const server=http.createServer((req,res)=>{let raw='';req.on('data',b=>raw+=b);req.on('end',()=>{
  const body=JSON.parse(raw),index=requests.push(body)-1;res.setHeader('Content-Type','text/event-stream');const emit=packet=>res.write('data: '+JSON.stringify(packet)+'\n\n');
  if(calls[index]){const [name,args]=calls[index];emit({type:'response.completed',response:{status:'completed',output:[{type:'function_call',id:'item-'+index,call_id:'call-'+index,name,arguments:JSON.stringify(args)}]}});}
  else {emit({type:'response.output_text.delta',delta:'已完成修改与运行'});emit({type:'response.completed',response:{status:'completed'}});}res.end();
 });});await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>{server.closeAllConnections();return new Promise(r=>server.close(r));});
 f.service.client={request(p,key,m,o){assert.equal(p.url,'https://api.openai.com/v1/responses');return client.request({...p,url:'http://127.0.0.1:'+server.address().port+'/responses'},key,m,o);}};
 const UI=vm.runInNewContext(fs.readFileSync(__dirname+'/ai-chatgpt.js','utf8')+'\nEditingToolbarAIChatGPT;',{window:{addEventListener(){}},ETAIClient:Client,Map,Set,Promise,Date}),ui=new UI({});
 ui.call=async(method,params,options)=>{assert.equal(method,'request');const wire=JSON.parse(JSON.stringify(params));return f.service.request(wire.profile,wire.messages,options);};
 const profile={chatgptAccount:'oaiapp_test',model:'model-a',documentEdit:true,codeFiles:[{file,kind:'editable'}]},messages=[{role:'user',content:'修改附件并运行'}];
 for(let i=0;i<calls.length;i++){
  const result=await ui.request(profile,messages,{});assert.equal(result.toolCalls.length,1);assert.equal(result.toolCalls[0].name,calls[i][0]);
  messages.push({role:'assistant',content:result.text||'',toolCalls:result.toolCalls,responseItems:result.responseItems},{role:'tool',tool_call_id:result.toolCalls[0].id,content:JSON.stringify({ok:true,file})});
 }
 assert.equal((await ui.request(profile,messages,{})).text,'已完成修改与运行');assert.equal(requests.length,4);
 for(let i=0;i<requests.length;i++){assert.deepEqual(requests[i].tools.map(t=>t.name),calls.map(c=>c[0]));assert.equal(requests[i].stream,true);assert.equal(requests[i].store,false);assert.equal(requests[i].input.filter(x=>x.type==='function_call_output').length,i);}
});
