const endpoint=value=>typeof value==='object'?value.id:value;
const hash=text=>{let value=2166136261;for(const c of text)value=Math.imul(value^c.charCodeAt(0),16777619);value=Math.imul(value^(value>>>16),2246822507);value=Math.imul(value^(value>>>13),3266489909);return((value^(value>>>16))>>>0)/4294967296;};
export const importance=count=>1-1/Math.sqrt(1+Math.max(0,count)/6);
export function nodeColor(base,count){
 const rgb=/^#([\da-f]{6})$/i.exec(base);if(!rgb)return base;
 const weight=importance(count),white=.62*(1-weight),shade=1-.18*weight;
 return '#'+[0,2,4].map(i=>Math.round((parseInt(rgb[1].slice(i,i+2),16)*(1-white)+255*white)*shade).toString(16).padStart(2,'0')).join('');
}

// Geometry helpers never add edges. Folder membership is only a layout hint.
export function prepareLayout(nodes,edges,options,aspect=1){
 const byId=new Map(nodes.map(n=>[n.id,n])),neighbors=new Map(nodes.map(n=>[n.id,new Set()])),springs=[],seen=new Set();
 for(const e of edges){const a=endpoint(e.source),b=endpoint(e.target);if(a===b||!byId.has(a)||!byId.has(b))continue;
  neighbors.get(a).add(b);neighbors.get(b).add(a);const key=JSON.stringify(a<b?[a,b]:[b,a]);
  if(!seen.has(key)){seen.add(key);springs.push({source:a,target:b});}
 }
 const folders=new Map();
 for(const n of nodes){n.degree=neighbors.get(n.id).size;n.layoutX=0;n.layoutY=0;n.layoutGroup='';
  if(n.current||n.kind!=='note')continue;
  const parts=String(n.relative||'').replace(/\\/g,'/').split('/');parts.pop();const folder=parts.join('/');
  if(folder){if(!folders.has(folder))folders.set(folder,[]);folders.get(folder).push(n);}
 }
 const groups=[...folders].filter(([,members])=>members.length>=2).sort(([a],[b])=>a.localeCompare(b,undefined,{numeric:true}));
 const grouped=options.folderGrouping===true&&nodes.length>=32&&groups.length>=2&&groups.length<=40;
 if(grouped){
  const cols=Math.max(2,Math.ceil(Math.sqrt(groups.length*Math.max(.6,Math.min(1.5,aspect))))),rows=Math.ceil(groups.length/cols);
  const spacing=80+Math.sqrt(Math.max(...groups.map(([,members])=>members.length)))*30;
  groups.forEach(([name,members],i)=>{const x=((i%cols)-(cols-1)/2)*spacing,y=(Math.floor(i/cols)-(rows-1)/2)*spacing;
   for(const n of members){n.layoutGroup=name;n.layoutX=x;n.layoutY=y;}
  });
 }
 for(const n of nodes)n.radius=(n.kind==='heading'?7-n.headingLevel*1.25:Math.max(n.outlineExpanded?8:4,4+12*importance(n.connectionCount??n.degree)))*options.nodeSize;
 return{neighbors,springs,grouped};
}
export function seedPosition(node,count){
 const spread=node.layoutGroup?45:Math.max(45,Math.sqrt(count)*13);
 return{x:node.layoutX+(hash(node.id+'x')-.5)*spread*2,y:node.layoutY+(hash(node.id+'y')-.5)*spread*2};
}
export function linkStrength(edge,attraction){return attraction/Math.max(1,Math.min(edge.source.degree,edge.target.degree));}
