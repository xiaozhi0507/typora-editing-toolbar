// A local pipe lets the Windows file association reach an existing editor
// before Typora is launched for the new file. No HTTP server or main patch.
class EditingToolbarDocumentOpenPipe {
  constructor(router){
    this.router=router;this.manager=router.manager;this.fs=reqnode('fs');this.path=reqnode('path');
    const profile=String(File.option.userDataPath),normalized=this.path.resolve(profile).replace(/\\/g,'/').toLowerCase();
    this.prefix='et-typora-open-'+reqnode('crypto').createHash('sha256').update(normalized).digest('hex').slice(0,24)+'-';
    this.name=this.prefix+router.id;this.dir=this.path.join(profile,'editing-toolbar-windows');this.meta=this.path.join(this.dir,router.id+'.json');
    this.server=reqnode('net').createServer(socket=>this.accept(socket));
    this.server.on('error',()=>this.cleanup());
    this.server.listen('\\\\.\\pipe\\'+this.name,()=>{this.ready=true;this.publish();});
  }
  publish(){
    if(!this.ready||this.closed)return;
    const r=this.router,data={version:1,pid:reqnode('process').pid,pipe:this.name,file:File.bundle?.filePath||'',tabs:this.manager.tabs.map(t=>t.path),focused:r.focused,ready:!r.loading()};
    const json=JSON.stringify(data);if(json===this.signature)return;
    try{this.fs.mkdirSync(this.dir,{recursive:true});this.fs.writeFileSync(this.meta+'.tmp',json);this.fs.renameSync(this.meta+'.tmp',this.meta);this.signature=json;}catch{}
  }
  accept(socket){
    socket.setEncoding('utf8');socket.setTimeout(4000,()=>socket.destroy());socket.on('error',()=>{});let buffer='',done=false;
    socket.on('data',chunk=>{
      if(done)return;buffer+=chunk;if(buffer.length>65536){done=true;socket.destroy();return;}const end=buffer.indexOf('\n');if(end<0)return;done=true;
      try{
        const data=JSON.parse(buffer.slice(0,end)),file=data.file;
        if(this.closed||data.version!==1||!this.manager.supported(file)||!this.fs.statSync(file).isFile())throw Error('unsupported');
        // Retain first: cancelling the native save prompt keeps the new tab
        // available without opening a second window or losing the old buffer.
        this.manager.change(db=>db.tabs.push({path:file}));this.manager.setFilter('all');
        this.router.queue.push({local:true,file});void this.router.drain();
        socket.end(JSON.stringify({accepted:true})+'\n');
      }catch{socket.end(JSON.stringify({accepted:false})+'\n');}
    });
  }
  cleanup(){this.ready=false;try{this.fs.unlinkSync(this.meta);}catch{}try{this.fs.unlinkSync(this.meta+'.tmp');}catch{}}
  dispose(){this.closed=true;this.cleanup();try{this.server.close();}catch{}}
}
