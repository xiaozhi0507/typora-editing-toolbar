// Codex's two-view picker: compact effort card -> model list -> card.
class EditingToolbarAIEffort {
  static labels={low:'低',medium:'中',high:'高',xhigh:'极高',max:'最高'};
  static label(p){return p?.authType==='chatgpt-web'?p.webLabel||'':ETAIClient.thinkingDisabled(p)?'不思考':this.labels[ETAIClient.effortValue(p)]||'';}
  static modelName(p){return (p?.modelLabel||p?.model||'选择模型').replace(/^(GPT-\d+(?:\.\d+)?)-(Sol|Astra|Luna|Terra)$/i,(_,a,b)=>a.toUpperCase()+' '+b[0].toUpperCase()+b.slice(1).toLowerCase());}
  static signature(p){return JSON.stringify(p?[p.id,this.modelName(p),p.chatgptAvailable,ETAIClient.effortLevels(p),ETAIClient.effortDefault(p)]:null);}
  static isGPT(p){return /^gpt(?:-|\s|$)/i.test(p.model||'')||/^gpt(?:-|\s|$)/i.test(p.modelLabel||'');}
  static family(p){return p.authType==='chatgpt-web'?'GPT 网页':this.isGPT(p)?'GPT':/^deepseek(?:-|\s|$)/i.test(p.model||'')||ETAIClient.deepSeekModels(p).length?'DeepSeek':'';}
  static modelOption(ai,p,profile,profiles,onModel){
    const b=ai.node('button','et-ai-model-option');b.type='button';b.dataset.profile=p.id;b.dataset.model=p.model;b.setAttribute('role','menuitemradio');b.setAttribute('aria-checked',String(profile?.id===p.id&&profile?.model===p.model));b.disabled=p.chatgptAvailable===false;
    const duplicate=profiles.filter(row=>this.modelName(row)===this.modelName(p)).length>1,copy=ai.node('span','et-ai-model-option-copy');copy.append(ai.node('span','et-ai-model-option-name',this.modelName(p)));
    if(duplicate)copy.append(ai.node('small','',p.name||p.id));b.title=this.modelName(p)+(b.disabled?' · 当前账号不可用':duplicate?' · '+(p.name||p.id):'');
    const check=ai.node('span','et-ai-menu-check');check.innerHTML='<svg viewBox="0 0 20 20" aria-hidden="true"><path d="m4 10 4 4 8-9"/></svg>';b.append(copy,check);b.onclick=()=>onModel(p);return b;
  }
  static renderModels(ai,parent,{profiles,profile,onModel}){
    const primary=ai.node('div','et-ai-model-primary');parent.append(primary);primary.append(ai.node('div','et-ai-model-heading','选择模型'));
    const state=ai.chatgptUI;if(state?.pickerLoading||state?.pickerError){const status=ai.node('div','et-ai-model-status',state.pickerLoading?'正在更新模型…':'更新未完成，可在顶部设置中刷新');status.setAttribute('role','status');if(state.pickerError)status.title=state.pickerError;primary.append(status);}
    const list=ai.node('div','et-ai-model-list');list.setAttribute('role','menu');list.setAttribute('aria-label','已配置模型');primary.append(list);
    const groups=new Map();
    parent._closeGroup=(focus=false)=>{clearTimeout(parent._groupTimer);const open=[...groups.values()].find(row=>!row.submenu.hidden);if(!open)return;open.submenu.hidden=true;open.group.setAttribute('aria-expanded','false');delete parent.dataset.submenuMode;if(parent._pickerAnchor)this.position(parent,parent._pickerAnchor);if(focus)open.group.focus({preventScroll:true});};
    parent._openGroup=(family,focus=false)=>{clearTimeout(parent._groupTimer);const row=groups.get(family);if(!row)return;if(!row.submenu.hidden){if(focus)this.focus(row.submenu);return;}for(const item of groups.values()){item.submenu.hidden=item!==row;item.group.setAttribute('aria-expanded',String(item===row));}if(parent._pickerAnchor)this.position(parent,parent._pickerAnchor);else this.positionSubmenu(parent);if(focus)this.focus(row.submenu);if(family==='GPT 网页')ai.webChat.loadOptions(parent);};
    for(const p of profiles){
      const family=this.family(p);
      if(!family){const b=this.modelOption(ai,p,profile,profiles,onModel);b.onmouseenter=()=>parent._closeGroup?.();list.append(b);continue;}
      if(groups.has(family))continue;
      const models=profiles.filter(p=>this.family(p)===family),group=ai.node('button','et-ai-model-option et-ai-model-group');group.type='button';group.dataset.group=family;group.setAttribute('role','menuitem');group.setAttribute('aria-haspopup','menu');group.setAttribute('aria-expanded','false');group.dataset.current=String(models.some(p=>p.id===profile?.id&&p.model===profile?.model));group.title=group.dataset.current==='true'?'当前：'+this.modelName(profile):'选择 '+family+' 模型';
      group.setAttribute('aria-label',family+' 模型分类');group.append(ai.node('span','et-ai-model-option-name',family));group.insertAdjacentHTML('beforeend','<svg class="et-ai-group-chevron" viewBox="0 0 16 16" aria-hidden="true"><path d="m6 4 4 4-4 4"/></svg>');list.append(group);
      const submenu=ai.node('div','et-ai-model-submenu');submenu.hidden=true;submenu.id=(parent.id||'et-ai-temp-model-menu')+'-'+family.toLowerCase().replace(/\s+/g,'-');group.setAttribute('aria-controls',submenu.id);submenu.setAttribute('aria-label',family+' 模型');parent.append(submenu);groups.set(family,{group,submenu});
      const head=ai.node('div','et-ai-submenu-heading'),back=ai.node('button','et-ai-submenu-back');back.type='button';back.setAttribute('aria-label','返回模型分类');back.innerHTML='<svg viewBox="0 0 16 16" aria-hidden="true"><path d="m10 4-4 4 4 4"/></svg>';back.onclick=()=>parent._closeGroup(true);head.append(back,ai.node('span','',family));submenu.append(head);
      const choices=ai.node('div','et-ai-model-list');choices.setAttribute('role','menu');choices.setAttribute('aria-label',family+' 模型');submenu.append(choices);if(family==='GPT 网页')ai.webChat.renderVersions(choices,{onModel});else for(const item of models)choices.append(this.modelOption(ai,item,profile,profiles,onModel));
      submenu.onmouseenter=()=>clearTimeout(parent._groupTimer);
      group.onmouseenter=()=>{clearTimeout(parent._groupTimer);const r=parent.getBoundingClientRect();if(Math.max(innerWidth-r.right-10,r.left-10)<250)return;parent._openGroup(family);};group.onclick=()=>parent._openGroup(family,true);
    }
    if(!profiles.length)list.append(ai.node('p','et-ai-model-empty','暂无模型，请在顶部设置中添加'));
    list.onscroll=()=>this.positionSubmenu(parent);return list;
  }
  static positionSubmenu(parent){
    const submenu=parent.querySelector('.et-ai-model-submenu:not([hidden])'),group=parent.querySelector('.et-ai-model-group[aria-expanded=true]');if(!submenu||!group)return;
    const margin=10,gap=6,width=244,p=parent.getBoundingClientRect();
    // Keep a true flyout when there is room; small windows use the same menu as a drilldown.
    const right=innerWidth-p.right-margin,left=p.left-margin,inline=Math.max(right,left)<width+gap;
    const mode=inline?'inline':'flyout',changed=parent.dataset.submenuMode!==mode;parent.dataset.submenuMode=mode;submenu.dataset.side=right>=width+gap?'right':'left';
    if(inline){submenu.style.cssText='';return changed;}
    const g=group.getBoundingClientRect();submenu.style.width=width+'px';submenu.style.maxHeight=Math.max(0,Math.min(344,innerHeight-margin*2))+'px';
    submenu.style.left=(submenu.dataset.side==='right'?p.right+gap:p.left-gap-width)+'px';
    const height=submenu.getBoundingClientRect().height,bottom=parent.dataset.side==='top'?Math.min(p.bottom,innerHeight-margin):innerHeight-margin;
    submenu.style.top=Math.max(margin,Math.min(g.top-5,bottom-height))+'px';return changed;
  }
  static quota(ai,head,root,profile){
    if(!this.isGPT(profile))return;const key=profile.chatgptAccount&&ai.chatgptUI?.readWebUsage?EditingToolbarAIWebSession.usageKey:[profile.chatgptAccount||profile.id,ai.chatgptUI?.accountRevision||0].join(':'),cache=ai.manualUsageCache||=new Map(),state=cache.get(key)||{status:'idle'};cache.set(key,state);
    head.classList.toggle('et-ai-effort-head-status',true);const label=ai.node('button','et-ai-usage-label','额度 —'),refresh=ai.node('button','et-ai-effort-reset et-ai-usage-refresh'),detail=ai.node('div','et-ai-usage-detail');label.type=refresh.type='button';label.setAttribute('aria-label','查看额度状态');label.setAttribute('aria-expanded','false');refresh.title='刷新额度';refresh.setAttribute('aria-label','刷新额度');refresh.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 10a9 9 0 1 1 1.7 7.3M3 4v6h6"/></svg>';detail.hidden=true;detail.setAttribute('role','status');
    const sync=()=>{
      const metric=state.status==='ready'&&state.metrics?.[0];label.textContent=metric?'剩余 '+Number(metric.remainingPercent.toFixed(1))+'%':state.status==='authorizing'?'登录中':state.status==='loading'?'查询中':state.status==='idle'?'额度 —':state.status==='error'?'额度 !':['login_required','verification_required'].includes(state.status)?'待登录':'未提供';label.setAttribute('data-state',state.status);refresh.disabled=['loading','authorizing'].includes(state.status);refresh.classList.toggle('is-loading',state.status==='loading');
      detail.replaceChildren(ai.node('p','',state.status==='idle'?'仅在点击刷新时读取用量。':state.status==='authorizing'?'请在窗口内完成登录并读取用量。':state.status==='loading'?'正在读取用量网页…':state.reason));
      if(state.status==='ready')for(const m of state.metrics||[]){const row=ai.node('div','et-ai-usage-metric');row.append(ai.node('span','',m.label),ai.node('strong','','剩余 '+Number(m.remainingPercent.toFixed(1))+'%'));detail.append(row);if(m.resetText)detail.append(ai.node('small','',m.resetText));}
      if(state.checkedAt)detail.append(ai.node('small','','读取于 '+new Date(state.checkedAt).toLocaleString()));
      const actions=ai.node('div','et-ai-usage-actions');if(profile.chatgptAccount&&ai.chatgptUI?.readWebUsage){const b=ai.node('button','et-ai-usage-manage',['idle','login_required'].includes(state.status)?'登录用量网页':'打开用量网页');b.type='button';b.disabled=['loading','authorizing'].includes(state.status);b.onclick=()=>{const menu=root.closest?.('[popover]');if(ai.composerUI?.menu===menu)ai.composerUI.closeMenu();else menu?.hidePopover();void run(true);};actions.append(b);}
      if(state.manageUrl){const b=ai.node('button','et-ai-usage-manage','官方用量页');b.type='button';b.onclick=()=>void reqnode('electron').shell.openExternal('https://chatgpt.com/settings/usage');actions.append(b);}detail.append(actions);
      label.title=metric?metric.label+' · 剩余 '+metric.remainingPercent+'% · '+new Date(state.checkedAt).toLocaleString():state.reason||'尚未刷新额度';
    };
    const run=async visible=>{if(['loading','authorizing'].includes(state.status))return;state.status=visible?'authorizing':'loading';state.metrics=[];detail.hidden=false;label.setAttribute('aria-expanded','true');sync();try{
      const data=profile.chatgptAccount?(ai.chatgptUI.readWebUsage?await ai.chatgptUI.readWebUsage(profile,visible):await ai.chatgptUI.call('usage',{account:profile.chatgptAccount})):{available:false,checkedAt:Date.now(),reason:'当前 API 连接没有提供账号剩余额度接口。请求的 token 用量不等于账号余额。'};
      Object.assign(state,{status:data.available?'ready':data.status||'unavailable',metrics:data.metrics||[],reason:data.reason,checkedAt:data.checkedAt,manageUrl:data.manageUrl});
    }catch(e){Object.assign(state,{status:'error',reason:e.message,metrics:[],checkedAt:Date.now(),manageUrl:null});}if(root.isConnected){sync();if(root.parentElement?._pickerAnchor)this.position(root.parentElement,root.parentElement._pickerAnchor);}};
    label.onclick=()=>{detail.hidden=!detail.hidden;label.setAttribute('aria-expanded',String(!detail.hidden));if(root.parentElement?._pickerAnchor)this.position(root.parentElement,root.parentElement._pickerAnchor);};refresh.onclick=()=>run(false);
    head.append(label,refresh);root.append(detail);sync();
  }
  static render(ai,parent,{profiles,profile,view,onView,onModel,onChange}){
    const keepGroup=parent.dataset.pickerView==='models'&&view==='models'?parent.querySelector('.et-ai-model-group[aria-expanded=true]')?.dataset.group:null;
    const active=parent.contains(document.activeElement)?document.activeElement:null,focusId=active?.dataset.profile,focusModel=active?.dataset.model,focusGroup=active?.dataset.group,focusVersion=active?.dataset.webVersion;
    clearTimeout(parent._groupTimer);parent._openGroup=parent._closeGroup=null;delete parent.dataset.submenuMode;parent.replaceChildren();parent.dataset.pickerView=view;parent.dataset.profileSignature=this.signature(profile);
    if(view==='models'||!profile){
      parent.dataset.pickerView='models';const list=this.renderModels(ai,parent,{profiles,profile,onModel});
      if(keepGroup)parent._openGroup?.(keepGroup);if(focusVersion)this.controls(parent).find(b=>b.dataset.webVersion===focusVersion)?.focus({preventScroll:true});else if(focusId)this.controls(parent).find(b=>b.dataset.profile===focusId&&b.dataset.model===focusModel)?.focus({preventScroll:true});else if(focusGroup)[...parent.querySelectorAll('.et-ai-model-group')].find(b=>b.dataset.group===focusGroup)?.focus({preventScroll:true});
      return list;
    }
    if(profile.authType==='chatgpt-web')return ai.webChat.renderPicker(parent,{onView});
    const root=ai.node('div','et-ai-effort'),head=ai.node('div','et-ai-effort-head'),toggle=ai.node('button','et-ai-effort-model');
    toggle.type='button';toggle.setAttribute('aria-label','选择模型');toggle.title=this.modelName(profile);toggle.onclick=()=>onView('models');
    const value=ai.node('span','et-ai-effort-value',profile.chatgptAvailable===false?'不可用':this.label(profile)||'默认');value.setAttribute('aria-live','polite');
    const model=ai.node('span','et-ai-effort-model-row');model.append(ai.node('span','',this.modelName(profile)));model.insertAdjacentHTML('beforeend','<svg viewBox="0 0 16 16" aria-hidden="true"><path d="m6 4 4 4-4 4"/></svg>');toggle.append(value,model);head.append(toggle);root.append(head);parent.append(root);
    this.quota(ai,head,root,profile);const levels=profile.chatgptAvailable===false?[]:ETAIClient.effortLevels(profile);if(!levels.length)return root;
    const slider=ai.node('div','et-ai-effort-slider'),rail=ai.node('div','et-ai-effort-rail'),dots=ai.node('div','et-ai-effort-dots');dots.setAttribute('aria-hidden','true');
    levels.forEach((level,i)=>{const dot=ai.node('span','');dot.dataset.effort=level;dot.style.left=(levels.length===1?50:i/(levels.length-1)*100)+'%';dots.append(dot);});rail.append(dots);
    const input=ai.node('input','et-ai-effort-range');input.type='range';input.min='0';input.max=String(levels.length-1);input.step='1';input.value=String(Math.max(0,levels.indexOf(ETAIClient.effortValue(profile))));input.disabled=levels.length===1;input.setAttribute('aria-label','模型思考程度');input.title=levels.map(e=>this.labels[e]).join(' · ');
    slider.dataset.single=String(levels.length===1);slider.append(rail,input);root.append(slider);
    const sync=()=>{const index=Number(input.value),label=this.labels[levels[index]],ratio=levels.length===1?.5:index/(levels.length-1);value.textContent=label;input.setAttribute('aria-valuetext',label+'，第 '+(index+1)+' 档，共 '+levels.length+' 档');slider.style.setProperty('--effort-ratio',ratio);slider.dataset.maximum=String(levels.length>1&&index===levels.length-1);for(const [i,dot]of [...dots.children].entries())dot.dataset.filled=String(i<=index);};
    input.oninput=()=>{sync();onChange(levels[Number(input.value)]);};sync();return root;
  }
  static controls(parent){return [...parent.querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled)')].filter(b=>b.getClientRects().length&&!b.closest('[hidden]'));}
  static focus(parent){const rows=this.controls(parent),target=rows.find(b=>b.getAttribute('aria-checked')==='true'||b.dataset.current==='true')||rows[0];target?.focus({preventScroll:true});target?.scrollIntoView({block:'nearest'});}
  static keydown(e,parent,{onBack,onClose}){
    const inSubmenu=!!e.target.closest('.et-ai-model-submenu'),expanded=!!parent.querySelector('.et-ai-model-group[aria-expanded=true]');
    if(e.key==='ArrowRight'&&e.target.closest('.et-ai-model-group')){e.preventDefault();e.stopPropagation();parent._openGroup?.(e.target.closest('.et-ai-model-group').dataset.group,true);return;}
    if(expanded&&((e.key==='ArrowLeft'&&inSubmenu)||e.key==='Escape')){e.preventDefault();e.stopPropagation();parent._closeGroup?.(true);return;}
    if(e.key==='Escape'){e.preventDefault();e.stopPropagation();parent.dataset.pickerView==='models'&&onBack?onBack():onClose();return;}
    if(e.target.matches('input[type=range]')&&['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End','PageUp','PageDown'].includes(e.key)){e.stopPropagation();return;}
    if(e.target.matches('select')&&e.key!=='Tab'){e.stopPropagation();return;}
    if(e.key==='Enter'&&e.target.matches('input[type=range]')){e.preventDefault();e.stopPropagation();onClose();return;}
    if(!['Tab','ArrowDown','ArrowUp','Home','End'].includes(e.key))return;
    const rows=this.controls(e.key==='Tab'?parent:e.target.closest('[role=menu]')||parent);if(!rows.length)return;e.preventDefault();e.stopPropagation();
    const at=rows.indexOf(document.activeElement),index=e.key==='Home'?0:e.key==='End'?rows.length-1:(at+((e.key==='Tab'&&e.shiftKey)||e.key==='ArrowUp'?-1:1)+rows.length)%rows.length;rows[index].focus({preventScroll:true});rows[index].scrollIntoView({block:'nearest'});
  }
  static position(menu,anchor){
    menu._pickerAnchor=anchor;
    const r=anchor.getBoundingClientRect(),margin=10,gap=8,width=Math.min(268,innerWidth-margin*2);menu.style.width=width+'px';menu.style.maxHeight='none';
    const above=Math.max(0,r.top-gap-margin),below=Math.max(0,innerHeight-r.bottom-gap-margin),wanted=Math.min(344,menu.scrollHeight+2),up=above>=Math.min(wanted,128)||above>=below;
    menu.style.maxHeight=Math.floor(Math.min(344,up?above:below))+'px';const height=menu.getBoundingClientRect().height;menu.dataset.side=up?'top':'bottom';
    menu.style.left=Math.max(margin,Math.min(r.right-width,innerWidth-width-margin))+'px';menu.style.top=Math.max(margin,Math.min(up?r.top-gap-height:r.bottom+gap,innerHeight-height-margin))+'px';if(this.positionSubmenu(menu))this.position(menu,anchor);
  }
}
