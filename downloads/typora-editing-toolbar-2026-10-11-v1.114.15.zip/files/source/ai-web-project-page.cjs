'use strict';
// Sandboxed webpage adapter: public links and visible controls only.
async function webProjectPage(action,args={}) {
  const visible=e=>!!e&&!e.closest('[hidden],[aria-hidden="true"],[inert],[role="menu"][data-state="closed"]')&&e.getBoundingClientRect().height>0&&getComputedStyle(e).visibility!=='hidden';
  const all=(s,r=document)=>[...r.querySelectorAll(s)].filter(visible),text=e=>(e?.innerText||e?.textContent||'').trim(),label=e=>e.getAttribute('aria-label')||text(e);
  const safe=href=>{try{if(typeof href!=='string'||!href.trim()||/^[#?]/.test(href.trim()))return '';const u=new URL(href,location.href);return u.origin==='https://chatgpt.com'&&!u.hash?u.origin+u.pathname.replace(/\/$/,''):'';}catch{return '';}};
  const project=href=>{const u=safe(href);return /^https:\/\/chatgpt\.com\/g\/g-p-[\w-]+\/project$/.test(u)?u:'';};
  const chat=href=>{const u=safe(href);return /^https:\/\/chatgpt\.com\/(?:g\/[\w-]+\/)?c\/[\w-]+$/.test(u)?u:'';};
  const outside=e=>!e.closest('[data-message-author-role],[data-message-role],article[data-testid^="conversation-turn"]');
  const controls=(re,root=document)=>all('button,[role="button"],[role="menuitem"]',root).filter(e=>outside(e)&&re.test(label(e).trim())&&!e.disabled&&e.getAttribute('aria-disabled')!=='true');
  const createLabel=/^(?:添加新项目|添加项目|新建项目|创建项目|New project|Create project|Add(?: a)?(?: new)? project)(?:[.…]+)?$/i;
  const wait=ms=>new Promise(r=>setTimeout(r,ms));
  const rows=(links,parse,title=text)=>{const seen=new Set();return links.flatMap(e=>{const url=parse(e.getAttribute('href')),name=title(e)||e.getAttribute('aria-label');if(!url||!name||seen.has(url))return [];seen.add(url);return [{url,name:name.replace(/\s+/g,' ').slice(0,160)}];});};
  // Card previews, timestamps and action captions are not part of a chat title.
  const chatTitle=e=>{
    const labelled=(e.getAttribute('aria-labelledby')||'').split(/\s+/).map(id=>document.getElementById(id)).find(n=>n&&e.contains(n));
    const named=e.querySelector('[data-chat-title],[data-conversation-title],[data-testid="conversation-title"],[data-testid="chat-title"],h2,h3,h4,[role="heading"]');
    if(labelled||named)return text(labelled||named);
    const copy=e.cloneNode(true);copy.querySelectorAll('button,[role="button"],svg,time,[hidden],[aria-hidden="true"],[data-chat-preview],[data-conversation-preview]').forEach(n=>n.remove());
    const line=copy.querySelector('[class~="truncate"],[class*="line-clamp"],[class~="font-medium"],[class~="font-semibold"]');
    if(line&&text(line))return text(line);
    const first=root=>{for(const n of root.childNodes){if(n.nodeType===3&&n.textContent.trim())return n.textContent.trim();if(n.nodeType===1&&text(n))return /^(SPAN|STRONG|B|EM|I)$/.test(n.tagName)?text(n):first(n);}return '';};
    return first(copy);
  };
  // New web sidebar project rows are buttons with a nested, named project
  // actions control. They have no href. Use their published project identity
  // or confirm an observed navigation; never derive an ID from the title.
  const projectButtons=()=>{
    // The sidebar uses content-visibility:auto. Offscreen row descendants
    // (including action buttons and innerText) can have no layout at all.
    // Read the mounted row's public identity/label, not those hover controls.
    const seen=new Set(),marked=[...document.querySelectorAll('[data-app-action-sidebar-project-row][data-app-action-sidebar-project-id]')].filter(outside).flatMap(element=>{
      const id=element.getAttribute('data-app-action-sidebar-project-id'),name=(element.getAttribute('data-app-action-sidebar-project-label')||'').trim();
      if(!/^g-p-[\w-]+$/.test(id||'')||!name||seen.has(id)||element.closest('[role="menu"],dialog,[role="dialog"]')||element.getAttribute('aria-disabled')==='true')return [];
      seen.add(id);
      return [{id,name,element}];
    });
    const fallback=[...document.querySelectorAll('button[aria-label],[role="button"][aria-label]')].filter(outside).flatMap(action=>{
    const title=action.getAttribute('aria-label')||'',match=title.match(/^(.+?)\s*的项目操作$/)||title.match(/^Project actions for (.+)$/i);
    if(!match)return [];
    const name=match[1].trim(),parent=action.parentElement?.closest('button,[role="button"]');
    if(!parent||marked.some(p=>p.element===parent)||!visible(parent)||parent.disabled||parent.getAttribute('aria-disabled')==='true'||!outside(parent))return [];
    const copy=parent.cloneNode(true);copy.querySelectorAll('button,[role="button"]').forEach(e=>e.remove());
    const own=(copy.getAttribute('aria-label')||text(copy)).replace(/\s+/g,' ').trim();
    if(own!==name)return [];
    return [{name,element:parent}];
    });return [...marked,...fallback];
  };
  const list=()=>{
    const links=rows([...new Set([...all('a[href]'),...document.querySelectorAll('nav a[href],aside a[href],[data-testid*="sidebar"] a[href]')])].filter(e=>outside(e)&&!e.closest('dialog,[role="dialog"],[role="menu"]')),project),buttons=projectButtons();
    for(const b of buttons){
      // The ID is explicitly published on the sidebar row. Use the existing
      // project route with this ID; a hidden/virtualized row need not be clicked.
      const url=b.id?project('/g/'+b.id+'/project'):'';
      if(!links.some(p=>url?p.url===url:p.url&&p.name===b.name))links.push({name:b.name,buttonName:b.name,...(b.id?{buttonId:b.id,url}:{})});
    }
    return links;
  };
  if(action==='projects'){
    let peek;
    const pointer=(element,type)=>{const r=element.getBoundingClientRect();element.dispatchEvent(new (typeof PointerEvent==='function'?PointerEvent:MouseEvent)(type,{bubbles:type!=='pointerenter'&&type!=='pointerleave',pointerType:'mouse',pointerId:1,clientX:r.left+r.width/2,clientY:r.top+r.height/2}));};
    try{
    if(args.expand){
      // A collapsed sidebar can mount its rows only after the opening transition.
      // Keep the guest in the background, retry delayed controls, and never
      // navigate or touch the composer while discovering projects.
      const clicked=new WeakSet();let toggled=false,previous='',stable=0;
      for(let i=0;i<60;i++){
        const sections=all('button[aria-expanded="false"],[role="button"][aria-expanded="false"]')
          .filter(e=>outside(e)&&/^(项目|Projects|置顶|Pinned)$/i.test(label(e))&&!projectButtons().some(p=>p.element===e));
        for(const section of sections)if(!clicked.has(section)){clicked.add(section);section.click();stable=0;}
        const found=list();
        if(!found.length&&!sections.length&&!toggled){
          const open=controls(/^(?:打开|展开|显示)(?:侧边栏|侧栏|边栏)$|^Open sidebar$/i);
          const toggle=controls(/^(?:显示\/隐藏(?:侧边栏|侧栏|边栏)|Toggle sidebar)$/i).filter(e=>e.getAttribute('aria-expanded')!=='true');
          // The current app shell hides the chat sidebar behind the Home rail
          // button. Hover opens its public peek panel; clicking this button
          // navigates home and would abandon the current chat and draft.
          const home=all('nav[data-app-navigation-rail] button[data-sidebar-destination="builtin:home"][data-slate-sidebar-peek-area="home"][aria-expanded="false"]')
            .filter(e=>outside(e)&&!e.closest('main,[role="main"],dialog,[role="dialog"],[role="menu"]')&&!e.disabled&&e.getAttribute('aria-disabled')!=='true'&&(e.getAttribute('aria-current')==='page'||e.hasAttribute('data-selected')));
          const candidates=open.length?open:toggle.length?toggle:home;
          if(candidates.length===1){const entry=candidates[0];if(home.includes(entry)){peek=entry;for(const type of ['pointerover','pointerenter','pointermove'])pointer(peek,type);}else entry.click();toggled=true;}
        }
        const signature=JSON.stringify(found.map(p=>[p.url,p.buttonId,p.name]));
        const sidebar=document.getElementById('app-shell-sidebar'),loading=sidebar&&all('[aria-busy="true"],[role="progressbar"],[data-testid*="skeleton"]',sidebar).some(outside);
        stable=found.length&&!loading&&signature===previous?stable+1:0;previous=signature;
        if(stable>=4&&!sections.length)break;
        await wait(100);
      }
    }
    const main=document.querySelector('main,[role="main"]');
    const heading=main&&all('h1',main).filter(outside);
    const projects=list(),currentURL=project(location.href),row=projects.find(p=>p.buttonId&&currentURL?.split('/')[4]===p.buttonId);
    if(row)row.url=currentURL;
    const current=row||(currentURL&&heading?.length===1?{url:currentURL,name:text(heading[0])}:null);
    if(current?.name&&!projects.some(p=>p.url===current.url||p.name===current.name))projects.push(current);
    const partial=!projectButtons().length&&!all('a[href]').some(e=>outside(e)&&project(e.getAttribute('href'))&&!e.closest('main,[role="main"]'));
    return {url:location.href,projects,current,partial};
    }finally{if(peek)for(const type of ['pointerout','pointerleave'])pointer(peek,type);}
  }
  if(action==='open-project'){
    const name=String(args.name||'').trim(),buttons=projectButtons().filter(p=>p.name===name&&(!args.id||p.id===args.id));
    if(buttons.length!==1)throw Error(buttons.length?'存在同名项目，无法确认目标，请在网页打开所需项目后重试':'项目入口已变化，请刷新项目列表');
    if(buttons[0].id){location.href=project('/g/'+buttons[0].id+'/project');return {opened:true,name};}
    const element=buttons[0].element,titleId=element.getAttribute('aria-labelledby'),title=titleId&&document.getElementById(titleId);
    (title&&element.contains(title)?title:element).click();return {opened:true,name};
  }
  if(action==='chats') {
    if(project(location.href)!==project(args.project)||!project(args.project))throw Error('尚未进入所选项目');
    const main=document.querySelector('main')||document.querySelector('[role="main"]')||document.body;
    const tabs=all('[role="tab"],button',main).filter(e=>/^(聊天|Chats|对话)$/i.test(label(e)));
    if(args.activate!==false&&tabs.length===1&&tabs[0].getAttribute('aria-selected')!=='true'&&tabs[0].getAttribute('data-state')!=='active'){tabs[0].click();await wait(150);}
    const more=()=>all('button,[role="button"]',main).filter(e=>outside(e)&&/^(加载更多|查看更多|显示更多|Load more|Show more)$/i.test(label(e)));
    let advanced=false;const buttons=more();
    if(args.more&&buttons.length===1&&!buttons[0].disabled&&buttons[0].getAttribute('aria-disabled')!=='true'){buttons[0].click();advanced=true;await wait(150);}
    // Read mounted list rows, including offscreen content-visibility rows.
    // Sidebar recents and assistant content never establish membership.
    const links=[...main.querySelectorAll('a[href]')].filter(e=>outside(e)&&!e.closest('nav,aside,[data-testid*="sidebar"],[hidden],[aria-hidden="true"],[inert]'));
    const chats=rows(links,chat,chatTitle),loading=all('[aria-busy="true"],[role="progressbar"],[data-testid*="skeleton"]',main).some(outside);
    const empty=!chats.length&&all('p,span,[data-testid]',main).some(e=>outside(e)&&/^(?:暂无聊天|还没有聊天|没有聊天|尚无聊天|No chats(?: yet)?|No conversations(?: yet)?)[.!。！]?$/i.test(text(e)));
    return {project:project(location.href),chats,more:more().length===1,advanced,loading,empty};
  }
  if(action==='create-project'||action==='submit-project') {
    const name=String(args.name||'').trim();if(!name||name.length>100)throw Error('项目名称需为 1–100 个字符');
    const previousURL=project(location.href),previousLinks=new Set(rows(all('a[href]').filter(outside),project).map(p=>p.url));
    let dialog=all('[role="dialog"],dialog').find(e=>/创建项目|新建项目|Create project|New project/i.test(text(e)));
    if(!dialog&&action==='create-project'){const buttons=controls(createLabel);if(buttons.length!==1)throw Error('无法确认网页的新建项目入口，请展开网页侧栏后重试');buttons[0].click();for(let i=0;i<15&&!dialog;i++){await wait(100);dialog=all('[role="dialog"],dialog').find(e=>/创建项目|新建项目|Create project|New project/i.test(text(e)));}}
    if(!dialog)throw Error('网页创建项目窗口尚未打开');
    const inputs=all('input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]),textarea',dialog);if(inputs.length!==1)throw Error('项目名称输入框无法确认');
    const input=inputs[0];if(action==='create-project'){const setter=Object.getOwnPropertyDescriptor(input.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,'value').set;setter.call(input,name);input.dispatchEvent(new Event('input',{bubbles:true}));await wait(100);return {previousURL,previousLinks:[...previousLinks]};}
    if(input.value!==name)throw Error('项目名称发生变化，未创建');const submit=controls(/^(创建项目|新建项目|Create project|Create)$/i,dialog);if(submit.length!==1)throw Error('创建项目按钮尚不可用');submit[0].click();return {submitted:true};
  }
  throw Error('不支持的项目操作');
}
module.exports=webProjectPage;
