'use strict';
// One book owns one managed folder. Chapters refer to that copy, never to the source.
class KnowledgeLibraryBook {
  constructor(store, { Managed, ISBN, Metadata, lookupISBN } = {}) {
    this.store=store;this.Managed=Managed||require('./knowledge-library-managed.cjs');
    this.ISBN=ISBN||require('./knowledge-library-isbn.cjs');this.Metadata=Metadata||require('./knowledge-library-book-metadata.cjs');this.lookupISBN=lookupISBN;
  }
  static key(path) { return path.replaceAll('\\', '/').toLowerCase(); }
  check(signal){if(signal?.aborted){const e=Error('已取消导入');e.name='AbortError';throw e;}}
  async inspect(input,{signal,force=false}={}){
    const {io,path}=this.store,managed=new this.Managed(this.store);this.check(signal);
    input=path.resolve(input);const stat=await managed.regular(input),isFile=stat.isFile();
    if(isFile&&!/^(?:目录|目錄|index|readme)\.md$/i.test(path.basename(input)))return null;
    if(!isFile&&!stat.isDirectory())return null;
    const folder=isFile?path.dirname(input):input,entries=await io.readdir(folder,{withFileTypes:true});
    const entry=['目录.md','目錄.md','index.md','readme.md'].map(name=>entries.find(e=>e.isFile()&&e.name.toLowerCase()===name)).find(Boolean);
    if(!entry||isFile&&KnowledgeLibraryBook.key(path.join(folder,entry.name))!==KnowledgeLibraryBook.key(input))return null;
    const documents=[],seen=new Set();let bytes=0;
    const read=async file=>{
      this.check(signal);if(seen.has(file)||documents.length>=64)return;seen.add(file);
      const st=await managed.regular(file);if(!st.isFile()||st.size>512*1024||bytes+st.size>2*1024*1024)return;
      bytes+=st.size;documents.push({name:path.basename(file),path:path.relative(folder,file).replaceAll('\\','/'),text:await io.readFile(file,'utf8')});
    };
    const front=/前置|前言|front[ _-]?matter/i,title=/版权|出版信息|书名页|copyright|colophon|title[ _-]?page|^(?:book|metadata)\.md$/i;
    const walkFront=async(dir,depth)=>{
      for(const e of await io.readdir(dir,{withFileTypes:true})){
        this.check(signal);if(e.name.startsWith('.')||e.isSymbolicLink())continue;
        const file=path.join(dir,e.name);if(e.isDirectory()&&depth<2){await managed.regular(file);await walkFront(file,depth+1);}
        else if(e.isFile()&&/\.(?:md|markdown|mdown)$/i.test(e.name)&&!/参考|bibliograph|references/i.test(e.name))await read(file);
      }
    };
    for(const e of entries){if(e.isFile()&&title.test(e.name)&&/\.md$/i.test(e.name))await read(path.join(folder,e.name));else if(e.isDirectory()&&front.test(e.name)){await managed.regular(path.join(folder,e.name));await walkFront(path.join(folder,e.name),0);}}
    await read(path.join(folder,entry.name));
    documents.sort((a,b)=>(/版权|copyright|colophon/i.test(b.name)?2:/书名页|title[ _-]?page/i.test(b.name)?1:0)-(/版权|copyright|colophon/i.test(a.name)?2:/书名页|title[ _-]?page/i.test(a.name)?1:0));
    const metadata=this.Metadata.parse(documents,v=>this.ISBN.normalize(v)),toc=documents.find(d=>d.path===entry.name)?.text||'';
    const hasChapters=this.Managed.links(toc).some(link=>/\.(?:md|markdown|mdown)(?:#.*)?$/i.test(link)&&!/^https?:/i.test(link));
    const frontMatter=entries.some(e=>e.isDirectory()&&front.test(e.name)||e.isFile()&&title.test(e.name));
    if(!force&&!(metadata.isbnCandidates.length||frontMatter&&hasChapters))return null;
    return {folder,entry:entry.name,metadata};
  }
  async enrich(record,{signal,onProgress=()=>{}}={}){
    const fields={...record.metadata.fields},warnings=record.metadata.warning?[record.metadata.warning]:[];
    let catalog;
    // A complete local CIP record needs no online request. Missing fields use the existing exact-ISBN client.
    if(fields.isbn&&this.lookupISBN&&['title','author','publisher','date'].some(key=>!fields[key])){
      onProgress('正在按 ISBN 补全书籍信息…','identifying');let timer,onAbort;
      try{
        this.check(signal);
        const response=await Promise.race([this.lookupISBN(fields.isbn),new Promise((_,reject)=>{
          timer=setTimeout(()=>reject(Error('ISBN 查询暂未完成，已保留本地信息，可稍后重试识别。')),20000);
          onAbort=()=>{const e=Error('已取消导入');e.name='AbortError';reject(e);};signal?.addEventListener('abort',onAbort,{once:true});
        })]);
        this.check(signal);
        if(this.ISBN.normalize(response?.fields?.isbn)!==fields.isbn)throw Error('书目来源 ISBN 不匹配，已保留本地信息。');
        for(const [key,value] of Object.entries(response.fields||{}))if(!fields[key]&&typeof value==='string')fields[key]=value;
        catalog={isbn:fields.isbn,source:response.source,url:response.url,checkedAt:new Date().toISOString()};
      }catch(e){if(e.name==='AbortError')throw e;warnings.push(e.message);}finally{clearTimeout(timer);signal?.removeEventListener('abort',onAbort);}
    }
    if(!fields.year&&fields.date)fields.year=fields.date.match(/(?:19|20)\d{2}/)?.[0]||'';
    return {fields,warnings,catalog};
  }
  async prepareFolder(folder, { metadata = {}, signal, onProgress = () => {}, detected } = {}) {
    const { io, path } = this.store, managed = new this.Managed(this.store);
    const check = () => this.check(signal);
    folder = path.resolve(folder); check();
    if (!(await managed.regular(folder)).isDirectory()) throw Error('请选择整本 Markdown 书籍所在的文件夹。');
    if (managed.inside(this.store.root, folder)) throw Error('请选择知识库之外的原始书籍文件夹。');
    onProgress('正在读取目录与前置书目信息…','identifying');
    const record=detected||await this.inspect(folder,{signal,force:true});
    if(!record)throw Error('书籍根目录需要有“目录.md”（也支持 index.md 或 README.md），用于打开全书目录。');
    const enriched=await this.enrich(record,{signal,onProgress});metadata={...enriched.fields,...metadata};check();
    let ref;
    try {
      onProgress('正在复制书籍、章节和图片…', 'copying');
      ref = await managed.prepare(this.store.fileRef(path.join(folder, record.entry)), { signal, bookRoot: folder }); check();
      const owned = path.join(managed.storage, ref.storageKey), manifest = JSON.parse(await io.readFile(path.join(owned, '.managed.json'), 'utf8'));
      const chapters = manifest.files.filter(f => /\.(md|markdown|mdown)$/i.test(f.path) && !/(?:^|\/)(?:_xref|_assets|assets)(?:\/|$)|\.(?:资料|笔记|注释|标注)(?:\/|$)/i.test(f.path));
      const compare = new Intl.Collator('zh-CN', { numeric: true });
      chapters.sort((a, b) => compare.compare(a.path, b.path));
      const files = chapters.map(f => {
        const target = path.join(owned, f.path), primary = path.resolve(target) === this.store.resolveFile(ref);
        return { ...(primary ? ref : this.store.fileRef(target, 'Markdown')), managed: true, storageKey: ref.storageKey, sourcePath: f.source, bookPath: f.path };
      });
      const at = files.findIndex(f => f.id === ref.id); if (at < 0) throw Error('全书目录未成功复制。');
      files.unshift(...files.splice(at, 1));
      const values = {};
      for (const field of ['title', 'author', 'year', 'date', 'publisher', 'isbn', 'edition', 'translator', 'language', 'summary', 'place', 'numPages', 'url', 'libraryCatalog', 'extra']) if (typeof metadata[field] === 'string') values[field] = metadata[field].trim();
      const item = { id: this.store.crypto.randomUUID(), type: 'book', title: path.basename(folder), author: '', year: '', summary: '', language: '', ...values, tags: [], files, related: [], collections: [], status: 'unread', star: false, defaultFile: ref.id, added: new Date().toISOString(), last: 0,
        book: { version: 1, sourceRoot: folder, storageKey: ref.storageKey, entryFile: ref.id, metadata: {source:'local-frontmatter',evidence:record.metadata.evidence,isbnCandidates:record.metadata.isbnCandidates,warnings:enriched.warnings} } };
      if(enriched.catalog)item.isbnMetadata=enriched.catalog;
      return {item,ref,files:manifest.files.length,chapters:files.length,warnings:enriched.warnings};
    } catch (e) { if (ref) await managed.rollback([ref]); throw e; }
  }
  async importFolder(folder, { collectionId = null, metadata = {}, signal, onProgress = () => {} } = {}) {
    folder=this.store.path.resolve(folder);this.check(signal);
    const before=await this.store.read();if(!before||before.recovered)throw Error('请先打开有效的知识库，再导入书籍。');
    if(collectionId&&!before.data.collections.some(c=>c.id===collectionId))throw Error('目标分类已不存在，请重新选择。');
    const existing=before.data.items.find(i=>i.type==='book'&&KnowledgeLibraryBook.key(i.book?.sourceRoot||'')===KnowledgeLibraryBook.key(folder));
    if(existing){
      if(existing.deleted)throw Error('这本书已在回收站，请先恢复书籍。');
      let data=before.data;
      if(collectionId&&!existing.collections.includes(collectionId)){const next=this.store.constructor.clone(data);next.items.find(i=>i.id===existing.id).collections.push(collectionId);data=await this.store.commit(data,next);}
      return {data,id:existing.id,reused:true};
    }
    const prepared=await this.prepareFolder(folder,{metadata,signal,onProgress});
    try{
      const item=prepared.item;if(collectionId)item.collections=[collectionId];
      const next=this.store.constructor.clone(before.data);next.items.push(item);this.check(signal);onProgress('正在保存书籍…','saving');
      const data = await this.store.commit(before.data, next, live => {
        if (live.items.some(i => KnowledgeLibraryBook.key(i.book?.sourceRoot || '') === KnowledgeLibraryBook.key(folder))) throw Error('其他窗口已导入这本书，请重新打开知识库。');
      });
      return { data, id: item.id, files: prepared.files, chapters: prepared.chapters, warnings:prepared.warnings, reused: false };
    }catch(e){await new this.Managed(this.store).rollback([prepared.ref]);throw e;}
  }
}
module.exports = KnowledgeLibraryBook;
