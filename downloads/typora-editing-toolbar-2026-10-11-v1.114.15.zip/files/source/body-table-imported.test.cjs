const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const {JSDOM}=require('jsdom');
const C=vm.runInNewContext(fs.readFileSync(path.join(__dirname,'body-table-columns.js'),'utf8')+'\nEditingToolbarTableColumns');
function fixture(){
 const dom=new JSDOM('<div id="write"><p id="caption">Table 1. Measurements</p><div class="md-htmlblock"><div class="md-htmlblock-container"><table><thead><tr><th colspan="2">Values</th></tr></thead><tbody><tr><td>A</td><td>B</td></tr></tbody></table></div></div><p>Ordinary unindexed HTML</p><div class="md-htmlblock"><div class="md-htmlblock-container"><table id="ordinary"><tr><td>Keep</td></tr></table></div></div></div>');
 const d=dom.window.document,caption=d.querySelector('#caption'),cp={file:'paper.md',records:new Map([['tab-1',{kind:'table',threeLine:true}]]),media:{locate:()=>caption}};
 const m=Object.assign(Object.create(C.prototype),{file:'paper.md',write:d.querySelector('#write'),toolbar:{citationPreview:cp}});return {dom,d,cp,m,t:d.querySelector('table')};
}
test('sanitized complex table gets indexed three-line display without source/structure changes',()=>{
 const {dom,d,m,t}=fixture();m.scanImportedTables();assert.ok(t.classList.contains('et-table-three-line'));assert.equal(t.tHead.rows[0].cells[0].colSpan,2);assert.equal(t.textContent,'ValuesAB');assert.equal(t.style.getPropertyValue('--et-imported-table-min-width'),'12em');assert.ok(t.parentElement.classList.contains('et-imported-table-scroll'));assert.equal(d.querySelector('#ordinary').className,'');dom.window.close();
});
test('re-rendered HTML receives styling again and index/file removal clears only managed styles',()=>{
 const {dom,m,t,cp}=fixture();m.scanImportedTables();const p=t.parentElement;p.innerHTML='<table><thead><tr><th colspan="3">Updated</th></tr></thead><tbody><tr><td colspan="3">A</td></tr></tbody></table>';const newer=p.querySelector('table');m.scanImportedTables();assert.ok(newer.classList.contains('et-table-three-line'));assert.equal(newer.style.getPropertyValue('--et-imported-table-min-width'),'18em');cp.file='other.md';m.scanImportedTables();assert.equal(newer.className,'');assert.equal(newer.style.getPropertyValue('--et-imported-table-min-width'),'');assert.equal(p.className,'md-htmlblock-container');dom.window.close();
});
test('ordinary table style, absent index and ambiguous multi-table blocks stay untouched',()=>{
 const {dom,m,t,cp}=fixture();cp.records.get('tab-1').threeLine=false;m.scanImportedTables();assert.equal(t.className,'');cp.records.get('tab-1').threeLine=true;t.parentElement.append(t.cloneNode(true));m.scanImportedTables();assert.equal(t.className,'');cp.records.clear();m.scanImportedTables();assert.equal(t.className,'');dom.window.close();
});


test('document default covers captionless pipe and HTML tables without changing ordinary documents or user override',()=>{
 const {dom,d,m,cp,t}=fixture();cp.records.clear();cp.tableStyle='three-line';m.bindings=new Map();m.scanImportedTables();assert(t.classList.contains('et-table-three-line'));const figure=d.createElement('figure');figure.setAttribute('cid','pipe');figure.innerHTML='<table class="md-table"><tbody><tr><th>Name</th></tr><tr><td>Value</td></tr></tbody></table>';m.write.append(figure);const pipe=figure.firstElementChild;assert.equal(m.isThreeLine(pipe),true);m.bindings.set('pipe',{threeLine:false,widths:[]});assert.equal(m.isThreeLine(pipe),false);m.bindings.clear();cp.tableStyle='';m.scanImportedTables();assert.equal(m.isThreeLine(pipe),false);assert(!t.classList.contains('et-table-three-line'));cp.tableStyle='three-line';cp.file='other.md';assert.equal(m.isThreeLine(pipe),false);m.scanImportedTables();assert(!t.classList.contains('et-table-three-line'));dom.window.close();
});
