const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),Client=require('./ai-client.cjs');
function fixture(){
  const data=new Map(),box={URL,ETAIClient:Client,localStorage:{getItem:k=>data.get(k)||null,setItem:(k,v)=>data.set(k,v)}};
  vm.createContext(box);vm.runInContext(fs.readFileSync(require.resolve('./ai-assistant.js'),'utf8')+';globalThis.AI=EditingToolbarAI;',box);
  const original={id:'ds',name:'DeepSeek',model:'deepseek-v4-pro',protocol:'openai-chat',url:'https://api.deepseek.com/v1/chat/completions',secret:'encrypted-test-value'};
  const create=()=>Object.assign(Object.create(box.AI.prototype),{configKey:'qa',config:JSON.parse(data.get('qa')||JSON.stringify({profiles:[original],active:'ds'})),keys:new Map()});
  return{create,data};
}
test('only explicitly saved DeepSeek profiles are selectable, without automatic variants',()=>{
  const {create,data}=fixture(),a=create();
  assert.deepEqual(Array.from(a.modelProfiles(),p=>p.model),['deepseek-v4-pro']);
  a.selectModel({id:'ds',model:'deepseek-flash'});assert.equal(a.profile().model,'deepseek-v4-pro');assert.equal(data.has('qa'),false);
  data.set('qa:last-model',JSON.stringify({id:'ds',model:'deepseek-flash'}));a.persist();
  assert.equal(a.profile().model,'deepseek-v4-pro');assert.equal(JSON.parse(data.get('qa')).profiles[0].model,'deepseek-v4-pro');
});

test('explicitly saving Flash makes it selectable and selection survives reopen',async()=>{
  const {create}=fixture(),a=create(),flash={...a.profile(),id:'flash',model:'deepseek-flash'};
  a.formProfile=()=>flash;a.form={elements:{remember:{checked:true}}};a.formKey=async()=> 'test-key';
  a.client={protect:async()=> 'encrypted-test-key'};a.lockSettings=()=>{};a.syncProfiles=()=>{};a.fillProfile=()=>{};a.notice=()=>{};
  assert.equal(a.modelProfiles().length,1);await a.saveProfile();assert.equal(a.modelProfiles().length,2);
  const old=create(),current=create();current.selectModel(current.modelProfiles().find(p=>p.id==='ds'));old.persist();
  assert.equal(create().profile().model,'deepseek-v4-pro');const reopened=create();reopened.selectModel(reopened.modelProfiles().find(p=>p.id==='flash'));
  assert.equal(create().profile().model,'deepseek-flash');assert.equal(Client.body(create().profile(),[{role:'user',content:'hi'}]).model,'deepseek-flash');
});

test('custom endpoints and other accounts are not assigned unconfigured model IDs',()=>{
  assert.deepEqual(Client.deepSeekModels({url:'https://proxy.example',model:'deepseek-v4-pro'}),[]);
  assert.deepEqual(Client.deepSeekModels({url:'https://api.deepseek.com.evil.example',model:'deepseek-v4-pro'}),[]);
  const {create}=fixture(),a=create();a.selectModel({id:'ds',model:'unknown-model'});assert.equal(a.profile().model,'deepseek-v4-pro');
  a.config.profiles.push({...a.config.profiles[0],id:'other',model:'deepseek-flash',secret:'different-encrypted-value'});a.selectModel(a.modelProfiles().find(p=>p.id==='other'&&p.model==='deepseek-flash'));
  assert.equal(a.profile().id,'other');assert.equal(a.profile().secret,'different-encrypted-value');assert.equal(a.config.profiles[0].model,'deepseek-v4-pro');
});
test('saved-key display is only a placeholder and never replaces the form key value',async()=>{
  const {create}=fixture(),a=create(),key={value:'',dataset:{},setAttribute(){}};let clearButton={};
  a.editingId='ds';a.form={elements:{key,url:{value:a.profile().url}}};a.preferences={querySelector:()=>clearButton};
  const box={URL};vm.createContext(box);vm.runInContext(fs.readFileSync(require.resolve('./ai-settings.js'),'utf8')+';globalThis.Settings=EditingToolbarAISettings;',box);
  const s=new box.Settings(a);s.syncKey();assert.match(key.placeholder,/^•+$/);assert.equal(key.value,'');assert.equal(clearButton.disabled,false);
  a.keyFor=async()=> 'existing-test-key';assert.equal(await a.formKey(),'existing-test-key');
  key.value='replacement-test-key';s.syncKey();assert.equal(await a.formKey(),'replacement-test-key');
  key.value='';a.clearKey=true;s.syncKey();assert.equal(key.placeholder,'');assert.equal(await a.formKey(),'');assert.equal(clearButton.disabled,true);
  a.clearKey=false;a.form.elements.url.value='https://different.example/v1/chat/completions';s.syncKey();assert.equal(key.placeholder,'');await assert.rejects(()=>a.formKey(),/服务地址已更换/);
});

test('closing settings discards typed credentials and requires restoring the saved form',()=>{
  const {create,data}=fixture(),a=create(),box={};vm.createContext(box);vm.runInContext(fs.readFileSync(require.resolve('./ai-settings.js'),'utf8')+';globalThis.Settings=EditingToolbarAISettings;',box);
  a.preferences={};a.preferencesBackdrop={hidden:false};a.panel={inert:true};a.settingsInitialized=true;a.clearKey=true;
  a.form={elements:{key:{value:'unsaved-test-key'}}};const s=new box.Settings(a);
  s.motion={finish(){}};s.closeEditor=s.closeMenu=s.hideHelp=()=>{};s.closeWindow(false);
  assert.equal(a.form.elements.key.value,'');assert.equal(a.settingsInitialized,false);assert.equal(a.clearKey,false);
  assert.equal(a.preferencesBackdrop.hidden,true);assert.equal(a.panel.inert,false);assert.equal(data.has('qa'),false);assert.equal(a.profile().secret,'encrypted-test-value');
});


test('V4 Pro maximum strength persists across reopen and a stale window write',()=>{
  const {create}=fixture(),old=create(),a=create();a.profile().reasoningEffort='max';a.rememberModel(a.profile());a.persist();old.persist();
  const restored=create();assert.equal(restored.profile().reasoningEffort,'max');assert.equal(Client.body(restored.profile(),[{role:'user',content:'hi'}]).reasoning_effort,'max');
});


test('retired ChatGPT 5.5 profiles stay out of menus even when cached, while explicit API profiles survive',()=>{
 const {create}=fixture(),a=create();a.config.profiles.push({id:'old',authType:'chatgpt',model:'gpt-5.5',chatgptAvailable:false},{id:'current',authType:'chatgpt',model:'gpt-6-astra'},{id:'custom',authType:'api',model:'gpt-5.5'});assert.deepEqual(Array.from(a.modelProfiles(),p=>p.id),['ds','current','custom']);assert.equal(a.config.profiles.length,4);
});
