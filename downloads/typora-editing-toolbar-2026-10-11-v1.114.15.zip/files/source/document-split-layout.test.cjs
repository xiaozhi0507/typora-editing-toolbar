const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const {JSDOM}=require('jsdom');
function fixture(width=1400){
 const dom=new JSDOM('<body><content style="top:8px;right:0px"><div id="editing-toolbar-top-host" data-placement="docked"></div><div id="write" style="font:16px/1.6 Arial;padding:30px"><h1>Primary</h1><p>Untouched</p></div></content></body>');
 const {window}=dom,{document}=window,frames=new Map();let serial=0;
 const host=document.getElementById('editing-toolbar-top-host'),content=document.querySelector('content');host.getBoundingClientRect=()=>({left:0,top:0,bottom:64,width});
 const Split=vm.runInNewContext(fs.readFileSync(__dirname+'/document-split.js','utf8')+';EditingToolbarDocumentSplit',{
  window,document,MutationObserver:window.MutationObserver,ResizeObserver:class{observe(){}},getComputedStyle:window.getComputedStyle.bind(window),localStorage:{getItem:()=>null,setItem(){}},innerWidth:width,innerHeight:900,reqnode:require,setTimeout,clearTimeout,
  File:{bundle:{filePath:'C:/fixture/main.md'},editor:{library:{isSidebarShown:()=>false}}},ETSplitStore:{SplitDocumentStore:class{}},EditingToolbarCitationPreview:class{hide(){}clearMark(){}},
  requestAnimationFrame(fn){frames.set(++serial,fn);return serial;},cancelAnimationFrame(id){frames.delete(id);}
 });
 const s=new Split({panelWorkspace:{dockWidth:()=>0,scheduleLayout(){}}});
 return {s,document,content,host,close(){dom.window.close();},flush(){const jobs=[...frames.values()];frames.clear();jobs.forEach(fn=>fn());}};
}
test('split uses a shared toolbar and aligned pane tops, then restores exact original DOM and insets',()=>{
 const h=fixture(),before=h.document.getElementById('write').outerHTML;
 h.s.enable('right');
 assert.equal(h.host.parentElement,h.document.body);assert.equal(h.s.panel.style.top,'64px');assert.equal(h.s.primaryHeader.style.top,'64px');assert.equal(h.content.style.top,'96px');
 assert.equal(h.s.panel.style.height, h.s.primaryFooter.style.top.replace('px','')-64+22+'px');
 h.flush();assert.equal(h.s.rendered.style.fontSize,'16px');assert.equal(h.s.rendered.style.paddingLeft,'30px');
 assert.equal(h.document.getElementById('write').outerHTML,before);
 h.s.close();assert.equal(h.host.parentElement,h.content);assert.equal(h.host.nextElementSibling.id,'write');assert.equal(h.content.style.top,'8px');assert.equal(h.content.style.right,'0px');
 assert.equal(h.document.body.classList.contains('et-split-active'),false);assert.equal(h.s.primaryHeader.hidden,true);h.close();
});
test('left, right, top and bottom layouts allocate equal pane sizes without overlapping headers',()=>{
 const h=fixture();
 for(const side of ['left','right','top','bottom']){
  h.s.enable(side);const panel=h.s.panel.style,head=h.s.primaryHeader.style,foot=h.s.primaryFooter.style;
  assert.equal(h.s.layoutSide,side);
  if(['left','right'].includes(side)){assert.equal(head.top,panel.top);assert.ok(Math.abs(parseFloat(head.width)-parseFloat(panel.width))<=1);}
  else{const primaryHeight=parseFloat(foot.top)+22-parseFloat(head.top);assert.ok(Math.abs(primaryHeight-parseFloat(panel.height))<=1);assert.equal(head.width,panel.width);}
  assert.equal(parseFloat(h.content.style.top),parseFloat(head.top)+32);
 }
 h.s.close();h.close();
});
test('narrow layouts fall back vertically and closing keeps floating toolbar placement intact',()=>{
 const h=fixture(500);h.host.dataset.placement='floating';h.host.style.left='75px';h.host.style.top='50px';h.s.enable('right');
 assert.equal(h.s.layoutSide,'bottom');assert.equal(h.s.primaryHeader.style.top,'0px');
 h.s.close();assert.equal(h.host.style.left,'75px');assert.equal(h.host.style.top,'50px');assert.equal(h.host.parentElement,h.content);h.close();
});


test('measuring bounds for the code editor does not mutate inherited document styles',()=>{
 const h=fixture();h.document.body.style.setProperty('--custom-note-color','red');
 const before=h.document.body.getAttribute('style');
 for(let i=0;i<50;i++){h.s.toolbar.panelWorkspace.dockWidth=()=>300+i;h.s.bounds();}
 assert.equal(h.document.body.getAttribute('style'),before);h.close();
});
