const fs=require('node:fs'),path=require('node:path'),esbuild=require('esbuild');
module.exports=code=>{
  const replace=(a,b)=>{if(!code.includes(a))throw Error('Missing terminal integration: '+a);code=code.replace(a,b);};
  const icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m4 6 6 6-6 6m10 0h6"/></svg>';
  replace('const BUTTON_DEFINITIONS = {','const BUTTON_DEFINITIONS = {\n"terminal":{icon:'+JSON.stringify(icon)+',title:"终端（Ctrl+Alt+T）"},');
  code=code.replaceAll('"ai-assistant","theme-palette","toolbar-settings"','"ai-assistant","terminal","theme-palette","toolbar-settings"');
  code=code.replaceAll('aiAssistantRevision:1,','aiAssistantRevision:1,terminalRevision:1,');
  replace('        const top = topLayout === "classic"',`        if(!input.terminalRevision){for(const ids of [compact.order,classic.buttons])if(!ids.includes('terminal')){const at=ids.indexOf('theme-palette');ids.splice(at<0?ids.length:at,0,'terminal');}}
        const top = topLayout === "classic"`);

  replace('    _executeAction(action) {','    _executeAction(action) {\n        if(action === "terminal") {void this.terminal?.toggle();return;}');
  replace('    _editingNotePanel(){return ','    _editingNotePanel(){return this.terminal?.panel?.contains(document.activeElement)||');
  const pos=code.lastIndexOf('(function () {');
  const helper='const ETTerminalEnvironment=(()=>{const module={exports:{}};'+fs.readFileSync(path.join(__dirname,'terminal-environment.cjs'),'utf8')+';return module.exports;})();';
  return code.slice(0,pos)+helper+'\n'+code.slice(pos);
};
