'use strict';
// Portable ZIPs contain metadata plus the complete local document/resource closure.
// Existing library data is committed only after extraction and checksum verification.
class KnowledgeLibraryArchive {
  constructor(store,{Managed,Zip,limits={}}) {
    this.store=store;this.io=store.io;this.path=store.path;this.crypto=store.crypto;
    this.managed=new Managed(store);this.zip=Zip;
    this.limits={bytes:2*1024**3,files:20000,json:16*1024**2,...limits};
  }
  check(signal){if(signal?.aborted){const e=Error('已取消');e.name='AbortError';throw e;}}
  digest(bytes){return this.crypto.createHash('sha256').update(bytes).digest('hex');}
  key(file){return this.path.resolve(file).toLowerCase();}
  safe(name){
    if(typeof name!=='string'||name.length>2048||/[\\:\x00-\x1f]/.test(name)||name.startsWith('/'))throw Error('导入包包含不安全的文件路径');
    const parts=name.split('/');
    if(parts.some(p=>!p||p==='.'||p==='..'||/[. ]$/.test(p)||/^(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\.|$)/i.test(p)))throw Error('导入包包含不安全的文件路径：'+name);
    return name;
  }
  packageId(library,files){return this.digest(JSON.stringify({library,files}));}
  async collect({signal,onProgress=()=>{}}={}){
    this.check(signal);
    const initial=(await this.store.read()).data,library=JSON.parse(JSON.stringify(initial));
    const files=new Map(),roots=new Map();let total=0;
    for(const item of library.items)for(const ref of item.files){
      if(ref.linkType==='url')continue;this.check(signal);
      const source=this.store.resolveFile(ref);if(files.has(this.key(source)))continue;
      onProgress('正在收集附件和笔记：'+ref.name,'scanning');
      const plan=await this.managed.plan(ref,{signal,includeNotes:true});
      for(const f of plan.files){
        const key=this.key(f.file);if(files.has(key))continue;
        total+=f.bytes;if(total>this.limits.bytes||files.size>=this.limits.files)throw Error('导出内容超过 2 GB 或 20000 个文件，请拆分文库后导出');
        files.set(key,f);const volume=this.path.parse(f.file).root.toLowerCase();
        let base=roots.get(volume)||this.path.dirname(f.file);
        while(!this.managed.inside(base,f.file))base=this.path.dirname(base);
        roots.set(volume,base);
      }
    }
    const groups=[...roots.keys()].sort();
    for(const f of files.values()){
      const volume=this.path.parse(f.file).root.toLowerCase();
      f.entry=this.safe('data/'+(groups.indexOf(volume)+1)+'/'+this.path.relative(roots.get(volume),f.file).replaceAll('\\','/'));
    }
    for(const item of library.items){delete item.notes;for(const ref of item.files)if(ref.linkType!=='url'){
      ref.path=files.get(this.key(this.store.resolveFile(ref))).entry;ref.relative=true;
      delete ref.sourcePath;delete ref.storageKey;delete ref.managed;
    }if(item.book){delete item.book.sourceRoot;delete item.book.storageKey;}}
    return {initial,library,files,total};
  }
  async export(folder,options={}){return this.pack(await this.collect(options),folder,options);}
  async pack({initial,library,files,total},folder,{signal,onProgress=()=>{}}={}){
    this.check(signal);await this.managed.regular(folder);
    const stamp=new Date().toISOString().replace(/[-:]/g,'').replace('T','-').slice(0,15);
    const output=this.path.join(folder,'知识库-'+stamp+'-'+this.crypto.randomBytes(3).toString('hex')+'.zip'),temp=output+'.partial';
    let handle,pending=Promise.resolve(),writeError,ended=false;const manifestFiles=[];
    try{
      handle=await this.io.open(temp,'wx');
      const zip=new this.zip.Zip((error,chunk,final)=>{
        if(error){writeError=error;return;}pending=pending.then(()=>handle.writeFile(chunk)).catch(e=>{writeError=e;});if(final)ended=true;
      });
      const drain=async()=>{await pending;if(writeError)throw writeError;this.check(signal);};
      const pushText=async(name,value)=>{const bytes=new TextEncoder().encode(JSON.stringify(value));if(bytes.length>this.limits.json)throw Error('知识库元数据超过 16 MB，请拆分后导出');const entry=new this.zip.ZipDeflate(name,{level:3});zip.add(entry);entry.push(bytes,true);await drain();};
      for(const f of [...files.values()].sort((a,b)=>a.entry.localeCompare(b.entry))){
        this.check(signal);onProgress('正在打包：'+this.path.basename(f.file),'copying');
        const before=await this.managed.regular(f.file);if(before.size!==f.bytes||before.mtimeMs!==f.mtime)throw Error('导出期间文件已修改，请重试：'+f.file);
        const entry=new this.zip.ZipPassThrough(f.entry),hash=this.crypto.createHash('sha256');zip.add(entry);
        const input=await this.io.open(f.file,'r');try{
          const buffer=new Uint8Array(64*1024);let size=0;
          for(;;){this.check(signal);const {bytesRead}=await input.read(buffer,0,buffer.length,null);if(!bytesRead)break;
            size+=bytesRead;if(size>f.bytes)throw Error('导出期间文件已修改：'+f.file);
            const chunk=buffer.slice(0,bytesRead);hash.update(chunk);entry.push(chunk,false);await drain();
          }
          const after=await input.stat();if(size!==f.bytes||after.mtimeMs!==f.mtime)throw Error('导出期间文件已修改：'+f.file);
        }finally{await input.close();}
        entry.push(new Uint8Array(),true);await drain();const sha256=hash.digest('hex');if(f.sha256&&f.sha256!==sha256)throw Error('导出期间文件内容已变化，请重试');manifestFiles.push({path:f.entry,bytes:f.bytes,sha256});
      }
      if(initial&&this.store.hash((await this.store.read()).data)!==this.store.hash(initial))throw Error('导出期间知识库已更新，请重试');
      for(const f of files.values()){this.check(signal);const stat=await this.managed.regular(f.file);if(stat.size!==f.bytes||stat.mtimeMs!==f.mtime)throw Error('导出期间文件已修改，请重试：'+f.file);}
      const packageId=this.packageId(library,manifestFiles);
      await pushText('library.json',library);
      await pushText('manifest.json',{format:'typora-knowledge-library',version:1,packageId,createdAt:new Date().toISOString(),files:manifestFiles});
      zip.end();await drain();if(!ended)throw Error('导出包未完成');await handle.sync();await handle.close();handle=null;
      onProgress('正在完成导出…','saving');this.check(signal);
      await this.io.copyFile(temp,output,this.store.fs.constants.COPYFILE_EXCL);
      return {path:output,items:library.items.length,files:files.size,bytes:total};
    }finally{await pending;if(handle)await handle.close().catch(()=>{});await this.io.unlink(temp).catch(()=>{});}
  }
  async extract(file,folder,{signal,onProgress=()=>{}}={}){
    const metadata=new Map(),entries=new Map();let total=0,pending=Promise.resolve(),failure;
    const unzip=new this.zip.Unzip(entry=>{
      try{
        this.check(signal);const name=this.safe(entry.name),key=name.toLowerCase();
        if(entries.has(key)||entries.size>=this.limits.files+2)throw Error('导入包文件重复或数量超限');
        if(!['library.json','manifest.json'].includes(name)&&!name.startsWith('data/'))throw Error('导入包包含未知文件：'+name);
        if(entry.originalSize>this.limits.bytes)throw Error('导入包文件过大');
        const record={path:name,bytes:0,complete:false,hash:this.crypto.createHash('sha256')},chunks=[];entries.set(key,record);
        const json=!name.startsWith('data/'),target=this.path.join(folder,...name.split('/'));
        if(!this.managed.inside(folder,target))throw Error('导入目标超出知识库');
        pending=pending.then(async()=>{await this.io.mkdir(this.path.dirname(target),{recursive:true});await this.io.writeFile(target,new Uint8Array(),{flag:'wx'});}).catch(e=>{failure ||= e;});
        onProgress('正在读取：'+this.path.basename(name),'copying');
        entry.ondata=(error,chunk,final)=>{
          try{
            if(error)throw error;if(failure)return;this.check(signal);
            record.bytes+=chunk.length;if(!json)total+=chunk.length;
            if(total>this.limits.bytes||json&&record.bytes>this.limits.json)throw Error('导入包解压内容超过大小限制');
            record.hash.update(chunk);if(json)chunks.push(chunk);
            pending=pending.then(()=>this.io.appendFile(target,chunk)).catch(e=>{failure ||= e;});
            if(final){record.complete=true;record.sha256=record.hash.digest('hex');delete record.hash;
              if(json){const text=new TextDecoder('utf-8',{fatal:true}).decode(this.zipBytes(chunks,record.bytes));metadata.set(name,JSON.parse(text));}}
          }catch(e){failure ||= e;entry.terminate();}
        };entry.start();
      }catch(e){failure ||= e;entry.terminate();}
    });
    unzip.register(this.zip.UnzipInflate);
    const input=await this.io.open(file,'r');try{
      const initial=await input.stat();if(!initial.isFile()||initial.size>this.limits.bytes+32*1024**2)throw Error('导入包过大或不是文件');
      // Require a complete classic ZIP directory; fflate also accepts streams without one.
      const tail=new Uint8Array(Math.min(initial.size,65557));await input.read(tail,0,tail.length,initial.size-tail.length);
      const view=new DataView(tail.buffer);let end=-1;
      for(let i=tail.length-22;i>=0;i--)if(view.getUint32(i,true)===0x06054b50&&i+22+view.getUint16(i+20,true)===tail.length){end=i;break;}
      if(end<0||view.getUint16(end+4,true)!==0||view.getUint16(end+6,true)!==0||view.getUint16(end+8,true)!==view.getUint16(end+10,true)||view.getUint32(end+12,true)+view.getUint32(end+16,true)!==initial.size-tail.length+end)throw Error('导入包损坏或 ZIP 格式不受支持');
      const expectedEntries=view.getUint16(end+10,true);
      const buffer=new Uint8Array(64*1024);let read=0;
      for(;;){this.check(signal);const {bytesRead}=await input.read(buffer,0,buffer.length,null);if(!bytesRead)break;read+=bytesRead;
        if(read>initial.size)throw Error('导入包读取期间发生变化');unzip.push(buffer.slice(0,bytesRead),false);await pending;if(failure)throw failure;
      }
      unzip.push(new Uint8Array(),true);await pending;if(failure)throw failure;
      if(entries.size!==expectedEntries)throw Error('导入包文件目录不完整');
      const final=await input.stat();if(final.size!==initial.size||final.mtimeMs!==initial.mtimeMs)throw Error('导入包读取期间发生变化');
    }finally{await pending;await input.close();}
    if([...entries.values()].some(e=>!e.complete))throw Error('导入包不完整');
    const manifest=metadata.get('manifest.json'),library=metadata.get('library.json');
    if(!manifest||manifest.format!=='typora-knowledge-library'||manifest.version!==1||!Array.isArray(manifest.files)||!library)throw Error('请选择由知识库导出的 ZIP 文件');
    const seen=new Set();for(const f of manifest.files){
      this.safe(f.path);const key=f.path.toLowerCase(),actual=entries.get(key);
      if(!f.path.startsWith('data/')||seen.has(key)||!actual||actual.path!==f.path||!Number.isSafeInteger(f.bytes)||f.bytes!==actual.bytes||!/^[a-f0-9]{64}$/.test(f.sha256)||f.sha256!==actual.sha256)throw Error('导入包文件校验失败：'+f.path);seen.add(key);
    }
    if(seen.size+2!==entries.size||manifest.packageId!==this.packageId(library,manifest.files))throw Error('导入包元数据或清单校验失败');
    this.store.validate(library);
    for(const item of library.items)for(const ref of item.files)if(ref.linkType!=='url'){
      this.safe(ref.path);if(!ref.relative||!seen.has(ref.path.toLowerCase())||entries.get(ref.path.toLowerCase()).path!==ref.path)throw Error('导入包附件未包含在文件清单中');
    }
    return {manifest,library};
  }
  zipBytes(chunks,length){const result=new Uint8Array(length);let at=0;for(const chunk of chunks){result.set(chunk,at);at+=chunk.length;}return result;}
  async import(file,{signal,onProgress=()=>{}}={}){
    this.check(signal);await this.managed.regular(file);const base=(await this.store.read()).data;
    await this.io.mkdir(this.managed.storage,{recursive:true});await this.managed.regular(this.managed.storage);
    const key=this.crypto.randomBytes(4).toString('hex').toUpperCase(),folder=this.path.join(this.managed.storage,key);await this.io.mkdir(folder);
    let committed=false;
    try{
      const {manifest,library}=await this.extract(file,folder,{signal,onProgress});this.check(signal);
      const packageId=manifest.packageId,next=JSON.parse(JSON.stringify(base)),itemIDs=new Map(),collectionIDs=new Map();
      const imported=(group,id)=>group.find(x=>x.archiveImport?.packageId===packageId&&x.archiveImport.sourceId===id);
      for(const item of library.items)itemIDs.set(item.id,imported(base.items,item.id)?.id||this.crypto.randomUUID());
      for(const c of library.collections)collectionIDs.set(c.id,imported(base.collections,c.id)?.id||this.crypto.randomUUID());
      for(const c of library.collections)if(!imported(base.collections,c.id))next.collections.push({...c,id:collectionIDs.get(c.id),parentId:c.parentId?collectionIDs.get(c.parentId):null,archiveImport:{packageId,sourceId:c.id}});
      const added=[];
      for(const original of library.items){
        if(imported(base.items,original.id))continue;
        const item=JSON.parse(JSON.stringify(original)),fileIDs=new Map(item.files.map(f=>[f.id,this.crypto.randomUUID()]));
        // Cached metadata can also identify its source attachment (author affiliations, xrefs).
        const remapSources=value=>{if(!value||typeof value!=='object')return;for(const [name,child] of Object.entries(value)){if(name==='fileId'&&fileIDs.has(child))value[name]=fileIDs.get(child);else remapSources(child);}};remapSources(item);
        item.id=itemIDs.get(original.id);item.archiveImport={packageId,sourceId:original.id};delete item.notes;
        item.collections=item.collections.map(id=>collectionIDs.get(id));item.related=item.related.map(id=>itemIDs.get(id));
        if(item.relatedOut)item.relatedOut=item.relatedOut.map(id=>itemIDs.get(id));
        item.defaultFile=fileIDs.get(item.defaultFile)||null;item.lastFile=fileIDs.get(item.lastFile)||null;
        for(const ref of item.files){ref.id=fileIDs.get(ref.id);delete ref.sourcePath;
          if(ref.linkType!=='url'){ref.path='storage/'+key+'/'+ref.path;ref.relative=true;ref.managed=true;ref.storageKey=key;}}
        if(item.book){item.book.storageKey=key;delete item.book.sourceRoot;if(fileIDs.has(item.book.entryFile))item.book.entryFile=fileIDs.get(item.book.entryFile);}
        if(item.webpage){if(fileIDs.has(item.webpage.currentFile))item.webpage.currentFile=fileIDs.get(item.webpage.currentFile);for(const v of item.webpage.versions||[])if(fileIDs.has(v.fileId))v.fileId=fileIDs.get(v.fileId);}
        next.items.push(item);added.push(item.id);
      }
      if(!added.length&&next.collections.length===base.collections.length)return {data:base,added:0,reused:library.items.length,id:itemIDs.values().next().value};
      await this.io.writeFile(this.path.join(folder,'.managed.json'),JSON.stringify({version:1,created:new Date().toISOString(),files:manifest.files,archivePackage:packageId}),{flag:'wx'});
      this.check(signal);onProgress('正在保存导入的条目…','saving');
      const data=await this.store.commit(base,next,live=>{this.check(signal);if(live.revision!==base.revision)throw Error('导入期间知识库已更新，请重新导入');});committed=true;
      return {data,added:added.length,reused:library.items.length-added.length,id:added[0]||itemIDs.values().next().value};
    }finally{if(!committed)await this.managed.removeFolder(folder);}
  }
}
module.exports=KnowledgeLibraryArchive;
