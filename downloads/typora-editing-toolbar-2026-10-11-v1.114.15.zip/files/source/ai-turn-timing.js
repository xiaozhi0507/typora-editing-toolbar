// Only elapsedMs is persisted. Live clocks never resume from a saved wall timestamp.
class EditingToolbarAITiming {
  static active = new WeakMap();
  // Local calendar dates, with Monday as the first day of the week.
  static questionTime(value,now=new Date()) {
    if(!['string','number'].includes(typeof value)||value==='')return null;
    const date=new Date(value);if(!Number.isFinite(date.getTime())||!Number.isFinite(now.getTime()))return null;
    const hm=date.getHours()+':'+String(date.getMinutes()).padStart(2,'0'),md=(date.getMonth()+1)+'月'+date.getDate()+'日',full=date.getFullYear()+'年'+md+' '+hm;
    let label;
    if(date.toDateString()===now.toDateString())label=hm;
    else if(date.getFullYear()!==now.getFullYear())label=full;
    else {
      const start=new Date(now.getFullYear(),now.getMonth(),now.getDate());start.setDate(start.getDate()-(start.getDay()+6)%7);
      const end=new Date(start);end.setDate(end.getDate()+7);
      label=(date>=start&&date<end?'星期'+'日一二三四五六'[date.getDay()]:md)+' '+hm;
    }
    return {label,full,dateTime:date.toISOString()};
  }
  static begin(turn,{resume=false}={}) {
    this.finish(turn);const offset=resume?(this.elapsed(turn)||0):0;turn.elapsedMs=offset;
    this.active.set(turn,{start:performance.now(),offset,timer:null});
  }
  static elapsed(turn) {
    const clock=this.active.get(turn);
    if(clock)return (clock.offset||0)+Math.max(0,Math.round(performance.now()-clock.start));
    return Number.isFinite(turn.elapsedMs)&&turn.elapsedMs>=0?turn.elapsedMs:undefined;
  }
  static format(ms) {
    const seconds=Math.floor(ms/1000),hours=Math.floor(seconds/3600),minutes=Math.floor(seconds%3600/60);
    return (hours?hours+'小时':'')+(hours||minutes?minutes+'分':'')+seconds%60+'秒';
  }
  static label(turn) {
    const ms=this.elapsed(turn),running=turn.status==='running',detail=turn.detail||(turn.status==='stopped'?'已停止':turn.status==='error'?'未完成':'完成');
    if(ms===undefined)return running?'生成中…':detail;
    const duration=!running&&ms<1000?'不足 1秒':this.format(ms);
    return running?'已处理 '+duration:(detail==='完成'?'':detail+' · ')+'用时 '+duration;
  }
  static update(turn) {
    turn.executionUI?.updateClock();
    if(!turn.meta)return;
    const text=turn.execution?.length?turn.model:turn.model+' · '+this.label(turn);
    if(turn.meta.textContent!==text)turn.meta.textContent=text;
  }
  static watch(turn) {
    this.update(turn);const clock=this.active.get(turn);
    if(!clock||clock.timer!==null)return;
    // No markdown rendering, storage writes or scroll changes on timer ticks.
    clock.timer=setInterval(()=>{
      if(turn.status!=='running'||!turn.article?.isConnected){clearInterval(clock.timer);clock.timer=null;return;}
      this.update(turn);
    },1000);
  }
  static finish(turn) {
    const clock=this.active.get(turn);if(!clock)return;
    turn.elapsedMs=this.elapsed(turn);clearInterval(clock.timer);this.active.delete(turn);
  }
}
