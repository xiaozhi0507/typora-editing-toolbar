// Grants are local to this window. Defaults use the captured model/mode, never historical permission flags.
class EditingToolbarAIShell {
 constructor(ai){this.ai=ai;this.io=new ETAIShell(reqnode);this.jobs=new Map();this.grants=new Map();this.overrides=new Map();window.addEventListener('unload',()=>{this.revoke('formal');this.revoke('temporary');});}
 icon(){return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="4"/><path d="m7 8 3 3-3 3m6 1h4"/></svg>';}
 context(scope='formal'){return {...(scope==='temporary'?this.ai.selectionUI?.temporary?.profile():this.ai.profile?.()),documentEdit:scope==='formal'&&!!this.ai.editUI?.enabled,shellScope:scope};}
 allowed(profile=this.context(),project=this.ai.webUI.defaultProject()){if(profile.authType==='chatgpt-web')return false;const scope=profile.shellScope||'formal',override=this.overrides.get(scope);if(override!==undefined)return !!(override&&override.id===project?.id&&override.root===project?.root);return scope==='formal'&&profile.documentEdit===true&&/^gpt(?:[-.]|$)/i.test(profile.model||'');}
 capture(project=this.ai.webUI.defaultProject(),profile=this.context()){
  const current=this.ai.webUI.defaultProject();if(!project?.trusted||!current?.trusted||project.id!==current.id||project.root!==current.root||!this.allowed(profile,project))return null;
  const scope=profile.shellScope||'formal',key=JSON.stringify([scope,project.id,project.root]);let grant=this.grants.get(key);
  if(!grant){grant={scope,token:reqnode('crypto').randomUUID()};this.grants.set(key,grant);}return grant.token;
 }
 get enabled(){return !!this.capture();}
 mount(){const a=this.ai;this.button=a.node('button','et-ai-file-picker et-ai-shell-toggle');this.button.type='button';this.button.innerHTML=this.icon()+'<span>终端执行</span><span class="et-ai-web-check">✓</span>';this.button.onclick=()=>this.toggle();a.attachments.menu.querySelector('.et-ai-library-search').before(this.button);this.chip=a.node('button','et-ai-web-chip et-ai-shell-chip');this.chip.type='button';this.chip.innerHTML=this.icon()+'<span>终端执行</span><span aria-hidden="true">×</span>';this.chip.setAttribute('aria-label','关闭 终端执行');this.chip.onclick=()=>this.revoke();a.prompt.before(this.chip);this.sync();}
 toggle(scope='formal'){if(this.capture(undefined,this.context(scope))){this.revoke(scope);return;}if(this.ai.busy||this.ai.selectionUI?.temporary?.busy)return;const p=this.ai.webUI.defaultProject();if(!p?.trusted){this.ai.notice('请先在项目菜单中设置已信任的默认文件夹，再启用 终端执行',true);return;}this.overrides.set(scope,{id:p.id,root:p.root});this.sync();this.ai.composerUI.closeMenu();}
 revoke(scope='formal'){this.overrides.set(scope,false);for(const[key,grant]of this.grants)if(grant.scope===scope)this.grants.delete(key);for(const[controller,jobScope]of this.jobs)if(jobScope===scope)controller.abort();this.sync();}
 closeTemporary(){this.revoke('temporary');this.overrides.delete('temporary');}
 sync(){const active=this.enabled,p=this.ai.webUI.defaultProject(),t=this.ai.selectionUI?.temporary;
  if(this.button){const code=!!this.ai.codeUI?.targets.length;this.chip.hidden=!active||code;this.button.hidden=code;this.button.disabled=this.ai.webChat?.active()||!active&&!!(this.ai.busy||t?.busy);this.button.setAttribute('aria-pressed',String(active));this.button.querySelector('.et-ai-web-check').hidden=!active;this.button.title='GPT 模型在编辑模式中默认开启；手动关闭后本窗口保持关闭。命令在已信任的默认项目中以当前用户权限运行。';this.chip.title='终端执行已开启 · '+(p?.root||'')+'\n点击停止命令并关闭';}
  if(t?.shellButton){const on=!!this.capture(p,this.context('temporary')),label='终端执行'+(on?'：已开启':'：已关闭');t.shellButton.setAttribute('aria-label',label);t.shellButton.setAttribute('aria-pressed',String(on));t.shellButton.title=label+'。临时聊天单独控制，关闭临时聊天后清除权限。';t.shellButton.dataset.active=String(on);t.shellButton.disabled=!on&&!!(this.ai.busy||t.busy);}
 }
 sanitizer(key){const secrets=[...this.ai.keys.values(),key].filter(v=>typeof v==='string');return text=>ETAIShell.scrub(text,secrets);}
 async execute(profile,call,options,turn,item){
  const manager=this.ai.webUI.project();manager?.read?.();const p=manager?.items.find(p=>p.trusted&&p.id===profile.project?.id&&p.root===profile.project?.root);
  if(!p||!profile.shellEnabled||!profile.shellGrant||profile.shellGrant!==this.capture(p,profile))throw Error('终端权限未开启或已撤销，请开启当前项目的 终端执行后重新提问');
  const controller=new AbortController(),abort=()=>controller.abort();this.jobs.set(controller,profile.shellScope||'formal');options.signal?.addEventListener('abort',abort,{once:true});if(options.signal?.aborted)abort();
  try{await manager.core.check(p);if(controller.signal.aborted)throw ETAIShell.abort();const args=JSON.parse(call.arguments),sanitize=options.sanitize||this.sanitizer();
   const result=await this.io.run(args,{root:p.root,signal:controller.signal,transport:(args,prepared)=>{const terminal=this.ai.toolbar?.terminal;if(!terminal)throw Error('终端组件尚未就绪');return terminal.executeCommand(args,prepared);},secrets:[...this.ai.keys.values(),options.shellKey].filter(v=>typeof v==='string'),onUpdate:state=>{if(item)Object.assign(item,state,{command:sanitize(state.command),description:sanitize(state.description),output:sanitize(state.output)});ETAIExecution.update(turn,options);}});
   if(item)Object.assign(item,{exitCode:result.exitCode,elapsedMs:result.elapsedMs,timedOut:result.timedOut,outputLimit:result.outputLimit});return result;
  }catch(e){if(item&&e.result)Object.assign(item,e.result);throw e;}
  finally{options.signal?.removeEventListener('abort',abort);this.jobs.delete(controller);}
 }
}
