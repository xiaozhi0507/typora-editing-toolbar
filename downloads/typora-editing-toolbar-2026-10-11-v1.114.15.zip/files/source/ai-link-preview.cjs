'use strict';
const Web=require('./ai-web.cjs');
// Metadata is presentation-only. Nothing from this cache is sent to the model.
class AILinkPreview {
 constructor(web=new Web(),now=()=>Date.now()){this.web=web;this.now=now;this.cache=new Map();this.assets=new Map();this.limit=32;this.ttl=30*60*1000;}
 static metadata(html,url){
  const source=html.slice(0,1500000).replace(/<(script|style|noscript)\b[^>]*>[\s\S]*?<\/\1>/gi,''),meta={},links=[];
  const attrs=s=>Object.fromEntries([...s.matchAll(/([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/g)].map(m=>[m[1].toLowerCase(),Web.decode(m[2]??m[3]??m[4]??'')]));
  for(const tag of source.matchAll(/<(meta|link)\s+([^>]+)>/gi)){const a=attrs(tag[2]);if(tag[1].toLowerCase()==='meta')meta[(a.property||a.name||'').toLowerCase()]=a.content;else links.push(a);}
  const safe=value=>{try{return Web.url(new URL(value,url).href).href;}catch{return null;}};
  const clean=(s,n)=>Web.text(s||'').slice(0,n);
  return {url,domain:new URL(url).hostname,title:clean(meta['og:title']||meta['twitter:title']||(source.match(/<title[^>]*>([\s\S]*?)<\/title>/i)||[])[1],240),description:clean(meta['og:description']||meta.description||meta['twitter:description'],500),image:meta['og:image']||meta['twitter:image']?safe(meta['og:image']||meta['twitter:image']):null,icon:safe(links.find(a=>/(^|\s)(?:icon|shortcut)(\s|$)/i.test(a.rel||''))?.href||new URL('/favicon.ico',url).href)};
 }
 trim(map){while(map.size>this.limit)map.delete(map.keys().next().value);}
 cached(url){try{const key=Web.url(url).href.split('#')[0],item=this.cache.get(key);return item?.expires>this.now()?item.value:null;}catch{return null;}}
 async asset(url){if(!url)return null;const old=this.assets.get(url);if(old?.expires>this.now())return old.promise;const entry={expires:this.now()+this.ttl};entry.promise=this.web.fetch(url,undefined,0,{image:true}).then(r=>{const b=r.bytes;let mime;if(b?.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))mime='image/png';else if(b?.[0]===255&&b?.[1]===216)mime='image/jpeg';else if(b?.toString('ascii',0,3)==='GIF')mime='image/gif';else if(b?.toString('ascii',0,4)==='RIFF'&&b?.toString('ascii',8,12)==='WEBP')mime='image/webp';else if(b?.subarray(0,4).equals(Buffer.from([0,0,1,0])))mime='image/x-icon';return mime?'data:'+mime+';base64,'+b.toString('base64'):null;}).catch(()=>null);this.assets.set(url,entry);this.trim(this.assets);return entry.promise;}
 async get(url,{image=true}={}){
  let key;try{key=Web.url(url).href.split('#')[0];}catch{return {url,domain:new URL(url).hostname};}
  let entry=this.cache.get(key);
  if(!(entry?.expires>this.now())){
   entry={expires:this.now()+this.ttl};entry.promise=(async()=>{try{const r=await this.web.fetch(key),m=AILinkPreview.metadata(r.text,r.url);return {...m,iconData:await this.asset(m.icon)};}catch{entry.expires=this.now()+5*60*1000;return {url:key,domain:new URL(key).hostname};}})().then(value=>{entry.value=value;return value;});
   this.cache.set(key,entry);this.trim(this.cache);
  }
  const value=await entry.promise;
  // Inline links need only their title and favicon. Fetch the large cover on hover.
  if(!image||!value.image)return value;
  entry.imagePromise ||= this.asset(value.image).then(data=>{value.imageData=data;return value;});
  return entry.imagePromise;
 }
}
module.exports=AILinkPreview;
