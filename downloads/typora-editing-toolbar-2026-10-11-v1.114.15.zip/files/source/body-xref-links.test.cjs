const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const Resolver=vm.runInNewContext(fs.readFileSync(require('node:path').join(__dirname,'body-xref-links.js'),'utf8')+'\nEditingToolbarXrefLinks',{URL});
const source='https://www.sciencedirect.com/science/article/pii/S0022169422012410';
const build=(targets,url=source)=>new Resolver({source_url:url,targets},new Map(targets.filter(Boolean).map(t=>[t.id,{}])));
test('legacy ScienceDirect b/bb references resolve to existing local bibliography',()=>{
 const r=build([{id:'ref--bb0105',kind:'reference'}]);
 for(const href of ['#b0105','#bb0105',source+'#b0105',source+'#%62%30%31%30%35'])assert.equal(r.resolve(href),'ref--bb0105');
 assert.equal(r.resolve('#b0106'),null);
});
test('legacy bib and sbref variants share the indexed reference',()=>{
 const r=build([{id:'ref-bib1',kind:'reference'}]);
 for(const key of ['bib1','bbib1','sbref1'])assert.equal(r.resolve(source+'#'+key),'ref-bib1');
});

test('triple-b publisher bibliography IDs resolve legacy body links and early hover candidates',()=>{
 const r=build([{id:'ref-bbb0030',kind:'reference'}]);
 for(const id of ['b0030','bb0030','bbb0030']){
  assert.equal(r.resolve(source+'#'+id),'ref-bbb0030');assert.equal(Resolver.candidate(source+'#'+id),true);
 }
 assert.equal(r.resolve(source.replace('2410','2411')+'#bbb0030'),null);
 assert.equal(build([{id:'ref-bbb0030',kind:'reference'},{id:'ref-b0030',kind:'reference'}]).resolve('#bb0030'),null);
});
test('publisher links cannot resolve another article, origin, query or credentials',()=>{
 const r=build([{id:'ref--bb0105',kind:'reference'}]);
 for(const href of [source.replace('2410','2411')+'#b0105',source.replace('https:','http:')+'#b0105',source+'?article=other#b0105',source.replace('www.','user@www.')+'#b0105','https://example.com/#b0105'])assert.equal(r.resolve(href),null);
});
test('legacy aliases are restricted to a ScienceDirect source document',()=>{
 assert.equal(build([{id:'ref--bb0105',kind:'reference'}],'https://example.com/article').resolve('#b0105'),null);
});
test('explicit source aliases support figure and table previews without label guessing',()=>{
 const r=build([{id:'fig-1',kind:'figure',source_ids:['f0005']},{id:'tab-1',kind:'table',source_ids:['t0005']}]);
 assert.equal(r.resolve(source+'#f0005'),'fig-1');assert.equal(r.resolve(source+'#t0005'),'tab-1');assert.equal(r.resolve('#fig-1'),'fig-1');assert.equal(r.resolve(source+'#f0006'),null);
});
test('conflicting aliases remain unresolved instead of choosing the wrong reference',()=>{
 const r=build([{id:'ref--bb0105',kind:'reference'},{id:'ref-b0105',kind:'reference'}]);
 assert.equal(r.resolve('#b0105'),null);assert.equal(r.resolve('#bb0105'),null);assert.equal(r.resolve('#ref-b0105'),'ref-b0105');
});
test('invalid and absent index entries do not create readable content',()=>{
 const r=build([null,{id:'fig-1',kind:'figure',source_ids:['bad id','#unsafe']}]);
 for(const href of [null,'javascript:alert(1)','#%E0%A4%A','#unknown','#unsafe','#bad%20id'])assert.equal(r.resolve(href),null);
 assert.equal(new Resolver({source_url:source,targets:[{id:'ref--bb0105',kind:'reference'}]},new Map()).resolve('#b0105'),null);
});
test('early hover candidates include publisher anchors but not ordinary topic links',()=>{
 assert.equal(Resolver.candidate(source+'#b0105'),true);assert.equal(Resolver.candidate('#fig-1'),true);
 assert.equal(Resolver.candidate('https://www.sciencedirect.com/topics/agriculture/plant'),false);assert.equal(Resolver.candidate('javascript:alert(1)'),false);
});
