// Typora owns the primary document. The second pane edits exact Markdown source separately.
class EditingToolbarDocumentSplit {
 constructor(toolbar){this.toolbar=toolbar;this.store=new ETSplitStore.SplitDocumentStore(reqnode);this.ratio=.5;this.side='right';this.key='et-document-split-v1';try{const s=JSON.parse(localStorage.getItem(this.key));if(['right','left','top','bottom'].includes(s?.side))this.side=s.side;this.ratio=Math.max(.25,Math.min(.75,Number(s?.ratio)||.5));}catch{}
  window.addEventListener('resize',()=>this.layout());document.addEventListener('et-document-loaded',()=>{this.syncMain();this.layout();});window.addEventListener('focus',()=>this.refreshExternal());
  document.addEventListener('dragover',e=>this.dragOver(e),true);document.addEventListener('drop',e=>this.drop(e),true);document.addEventListener('dragend',()=>this.endDrag(),true);document.addEventListener('dragleave',e=>{if(!e.relatedTarget)this.preview?.remove();},true);
  window.addEventListener('beforeunload',e=>{if(!this.save()){e.preventDefault();e.returnValue='副栏有尚未保存的内容';}});
 }
 node(tag,cls='',text=''){const n=document.createElement(tag);n.className=cls;n.textContent=text;return n;}
 button(text,fn){const b=this.node('button','',text);b.type='button';b.onclick=fn;return b;}
 keyOf(file){if(!file)return '';try{return reqnode('fs').realpathSync(file).toLowerCase();}catch{return reqnode('path').resolve(file).toLowerCase();}}
 mount(){if(this.panel)return;this.panel=this.node('section','et-document-split');this.panel.hidden=true;this.panel.setAttribute('aria-label','双栏文档');this.header=this.node('div','et-split-head');this.title=this.node('strong','','副栏');this.title.title='将左侧打开的标签页拖到正文左、右、上、下区域';this.modeButton=this.button('源码编辑',()=>this.toggleEdit());this.saveButton=this.button('保存',()=>this.save());const reload=this.button('重新载入',()=>{if(this.dirty){this.status('请先保存或另存为当前草稿');return;}if(this.record)this.open(this.record.file);}),saveAs=this.button('另存为',()=>this.saveAs());this.closeButton=this.button('×',()=>this.close());this.closeButton.setAttribute('aria-label','关闭双栏');this.header.append(this.title,this.modeButton,this.saveButton,saveAs,reload,this.closeButton);
  const more=this.button('···',()=>{this.actions.hidden=!this.actions.hidden;more.setAttribute('aria-expanded',String(!this.actions.hidden));});more.setAttribute('aria-label','副栏操作');more.setAttribute('aria-expanded','false');this.actions=this.node('div','et-split-actions');this.actions.hidden=true;this.actions.append(this.saveButton,saveAs,reload);this.header.replaceChildren(this.title,this.modeButton,more,this.closeButton);this.panel.append(this.actions);document.addEventListener('pointerdown',e=>{if(!this.actions.contains(e.target)&&e.target!==more){this.actions.hidden=true;more.setAttribute('aria-expanded','false');}},true);
  this.panel.addEventListener('keydown',e=>{if(e.key==='Escape'&&!this.actions.hidden){e.preventDefault();e.stopPropagation();this.actions.hidden=true;more.setAttribute('aria-expanded','false');more.focus();}});
  this.primaryHeader=this.node('div','et-split-head et-split-primary-head');this.primaryTitle=this.node('strong');this.primaryHeader.append(this.primaryTitle,this.node('span','et-split-primary-label','正文'));this.primaryHeader.hidden=true;this.primaryFooter=this.node('div','et-split-status et-split-primary-status','Typora 编辑');this.primaryFooter.hidden=true;document.body.append(this.primaryHeader,this.primaryFooter);
  this.typography=this.node('style');document.head.append(this.typography);this.themeObserver=new MutationObserver(()=>this.scheduleTypography());for(const el of [document.documentElement,document.body])this.themeObserver.observe(el,{attributes:true,attributeFilter:['class','style','data-theme']});const theme=document.getElementById('et-theme-palette-overrides');if(theme)this.themeObserver.observe(theme,{childList:true,subtree:true,characterData:true});document.addEventListener('load',e=>{if(e.target.tagName==='LINK')this.scheduleTypography();},true);
  this.content=this.node('div','et-split-content');this.rendered=this.node('div','et-split-preview');this.source=this.node('textarea','et-split-source');this.source.spellcheck=false;this.source.setAttribute('aria-label','副栏 Markdown 源码');this.source.hidden=true;this.source.oninput=()=>{if(!this.record)return;this.dirty=true;this.status('未保存');clearTimeout(this.saveTimer);this.saveTimer=setTimeout(()=>this.save(),650);};this.source.onkeydown=e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();this.save();}if(e.key==='Tab'){e.preventDefault();this.source.setRangeText('  ',this.source.selectionStart,this.source.selectionEnd,'end');this.source.dispatchEvent(new Event('input'));}e.stopPropagation();};
  this.message=this.node('div','et-split-status');this.content.append(this.rendered,this.source);this.panel.append(this.header,this.content,this.message);document.body.append(this.panel);this.divider=this.node('div','et-split-divider');this.divider.hidden=true;this.divider.tabIndex=0;this.divider.setAttribute('role','separator');this.divider.setAttribute('aria-label','调整双栏比例');this.divider.onpointerdown=e=>this.resize(e);this.divider.onkeydown=e=>{if(e.key.startsWith('Arrow')){e.preventDefault();this.ratio=Math.max(.25,Math.min(.75,this.ratio+((e.key==='ArrowRight'||e.key==='ArrowDown') ? .03 : -.03)));this.layout();this.persist();}};document.body.append(this.divider);
  this.citationPreview=new EditingToolbarCitationPreview(this.toolbar,{file:()=>this.record?.file||'',root:()=>this.rendered,valid:()=>!!this.enabled&&!this.editing&&!this.panel.hidden,scroller:()=>this.content,openLink:url=>this.openPreviewLink(url),onIndex:()=>this.applyXrefTableStyles()});
  this.resizeObserver=new ResizeObserver(()=>this.toolbar.panelWorkspace?.scheduleLayout());for(const el of [document.getElementById('typora-sidebar'),document.getElementById('editing-toolbar-top-host')])if(el)this.resizeObserver.observe(el);
  for(const event of ['keydown','keypress','keyup','mousedown','click','paste','wheel'])this.panel.addEventListener(event,e=>e.stopPropagation());
 }
 showMenu(){const t=this.toolbar.documentTabs,anchor=document.querySelector('#editing-toolbar-top [data-action="split-view"]')||this.toolbar.topToolbar,r=anchor.getBoundingClientRect();this.toolbar._closeActivePopover();t.showMenu([{id:'split-horizontal',label:'左右双栏',checked:!!this.enabled&&['left','right'].includes(this.side),run:()=>this.enable('right')},{id:'split-vertical',label:'上下双栏',checked:!!this.enabled&&['top','bottom'].includes(this.side),run:()=>this.enable('bottom')},null,{id:'split-close',label:'关闭双栏',disabled:!this.enabled,run:()=>this.close()}],{x:r.left,y:r.bottom+4},anchor,'双栏模式');}
 enable(side='right'){this.mount();this.side=side;this.enabled=true;this.panel.hidden=false;this.divider.hidden=false;if(!this.record){this.rendered.textContent='将左侧栏打开的标签页拖到正文区域，选择左、右、上、下落点。';this.status('副栏支持预览与 Markdown 源码编辑');}this.layout();this.persist();}
 close(){if(!this.save())return;this.enabled=false;this.citationPreview?.hide();this.citationPreview?.clearMark();this.endDrag();if(this.panel)this.panel.hidden=true;if(this.divider)this.divider.hidden=true;this.restore();this.releaseChrome();this.toolbar.panelWorkspace?.scheduleLayout();}
 persist(){try{localStorage.setItem(this.key,JSON.stringify({side:this.side,ratio:this.ratio}));}catch{}}
 status(text){if(this.message){this.message.textContent=text;this.message.title=text;}}
 bindTab(row){if((row._etSplitDrag&&row._etSplitDrag===row.ondragstart)||!this.toolbar.documentTabs?.supported(row.dataset.path))return;row.draggable=true;const previous=row.ondragstart;row.ondragstart=row._etSplitDrag=e=>{if(e.target.closest('button:not(.et-dt-open)')){e.preventDefault();return;}previous?.(e);if(e.defaultPrevented)return;this.dragFile=row.dataset.path;e.dataTransfer.setData('application/x-et-document-tab',row.dataset.path);e.dataTransfer.effectAllowed='copyMove';};}
 endDrag(){this.dragFile=null;this.preview?.remove();this.preview=null;}
 bounds(){const c=document.querySelector('content'),left=c?.getBoundingClientRect().left||0;const sidebar=document.getElementById('typora-sidebar');const nativeLeft=this.toolbar.panelWorkspace?.documentLeft?.()??(File.editor.library.isSidebarShown()?Math.max(0,sidebar?.getBoundingClientRect().width||left):0);const dock=this.toolbar.panelWorkspace?.dockWidth()||0,term=this.toolbar.terminal,terminalHeight=term?.panel&&!term.panel.hidden&&term.mode==='bottom'?term.panel.getBoundingClientRect().height:0;const host=document.getElementById('editing-toolbar-top-host');return {left:nativeLeft,top:host&&host.dataset.placement!=='floating'?Math.max(0,host.getBoundingClientRect().bottom):0,right:innerWidth-dock,bottom:innerHeight-24-terminalHeight};}
 dragOver(e){if(e.target.closest?.('#et-ai-panel,.et-ai-temporary')){this.preview?.remove();this.preview=null;return;}if(!this.enabled||!this.dragFile)return;const b=this.bounds();if(e.clientX<b.left||e.clientX>b.right||e.clientY<b.top||e.clientY>b.bottom){this.preview?.remove();this.preview=null;return;}e.preventDefault();e.stopImmediatePropagation();e.dataTransfer.dropEffect='copy';const x=(e.clientX-b.left)/(b.right-b.left),y=(e.clientY-b.top)/(b.bottom-b.top),edges=[['left',x],['right',1-x],['top',y],['bottom',1-y]];edges.sort((a,b)=>a[1]-b[1]);this.dropSide=edges[0][0];if(!this.preview){this.preview=this.node('div','et-split-drop');document.body.append(this.preview);}const horizontal=['left','right'].includes(this.dropSide),w=(b.right-b.left)/(horizontal?2:1),h=(b.bottom-b.top)/(horizontal?1:2);Object.assign(this.preview.style,{left:(b.left+(this.dropSide==='right'?w:0))+'px',top:(b.top+(this.dropSide==='bottom'?h:0))+'px',width:w+'px',height:h+'px'});this.preview.textContent={left:'在左侧打开',right:'在右侧打开',top:'在上方打开',bottom:'在下方打开'}[this.dropSide];}
 drop(e){if(e.target.closest?.('#et-ai-panel,.et-ai-temporary')){this.endDrag();return;}if(!this.enabled||!this.dragFile||!this.preview)return;e.preventDefault();e.stopImmediatePropagation();const file=this.dragFile,side=this.dropSide;this.endDrag();if(this.save()){this.enable(side);this.open(file);}}
 open(file){if(!this.save())return false;try{const record=this.store.read(file);this.record=record;this.source.value=record.text;this.dirty=false;this.title.textContent=reqnode('path').basename(file);this.title.title=file;this.editing=false;this.syncMain();this.render();this.status('预览');return true;}catch(error){this.status(error.message);return false;}}
 syncMain(){if(!this.enabled||!this.record)return;const same=this.keyOf(this.record.file)===this.keyOf(File.bundle?.filePath);if(same){if(this.dirty){this.status('此文件已在正文中打开，请另存为副栏草稿');this.source.readOnly=true;return;}this.editing=false;this.modeButton.disabled=true;this.modeButton.title='此文件由 Typora 正文编辑，副栏同步预览';this.render();}else{this.modeButton.disabled=false;this.modeButton.title='编辑副栏文件的 Markdown 源码';this.source.readOnly=false;}this.source.hidden=!this.editing;this.rendered.hidden=!!this.editing;this.modeButton.textContent=this.editing?'预览':'源码编辑';}
 imageURL(src,file){
  if(typeof src!=='string'||src.length>8*1024*1024||/[\u0000-\u001f<>]/.test(src))return '';
  try{
   if(/^https?:\/\//i.test(src)){const u=new URL(src);return !u.username&&!u.password?u.href:'';}
   if(/^data:image\/(?:png|jpeg|gif|webp|avif);base64,[a-z0-9+/=]+$/i.test(src))return src;
   const path=reqnode('path'),url=reqnode('url');let absolute;
   if(/^file:/i.test(src)){const u=new URL(src);if(u.hostname)return '';absolute=url.fileURLToPath(u);}
   else{const decoded=decodeURIComponent(src);if(/^(?:[a-z][\w+.-]*:|[/\\]{2})/i.test(decoded)&&!/^\w:[/\\]/.test(decoded))return '';absolute=path.resolve(path.dirname(file),decoded);}
   return /\.(?:png|jpe?g|gif|webp|bmp|svg|avif)$/i.test(absolute)?url.pathToFileURL(absolute).href:'';
  }catch{return '';}
 }
 openPreviewLink(url){
  if(url.startsWith('#')){let id;try{id=decodeURIComponent(url.slice(1));}catch{return;}const target=[...this.rendered.querySelectorAll('[data-preview-anchor]')].find(n=>n.dataset.previewAnchor===id);if(target)this.content.scrollTo({top:Math.max(0,this.content.scrollTop+target.getBoundingClientRect().top-this.content.getBoundingClientRect().top-20),behavior:'instant'});else this.status('未找到此链接的本地目标');return;}
  if(/^https?:\/\//i.test(url))reqnode('electron').shell.openExternal(url);
 }
 render(){
  if(!this.record)return;const file=this.record.file,same=this.keyOf(file)===this.keyOf(File.bundle?.filePath),markdown=same?File.editor.getMarkdown():this.source.value,m=this.toolbar.annotations;
  this.citationPreview?.hide();this.citationPreview?.bind();
  const isCurrent=()=>this.enabled&&!this.editing&&this.record?.file===file;
  try{m._ensureRenderer().renderPreview(this.rendered,markdown,{
   contextKey:file,documentHTML:true,isCurrent,renderMath:(tex,display)=>m._renderMath(tex,display),imageURL:src=>this.imageURL(src,file),openLink:url=>this.openPreviewLink(url),
   decorateLink:(link,url)=>{if(!/^#[^\s<>]{1,750}$/.test(url))return false;link.setAttribute('href',url);link.addEventListener('click',e=>{e.preventDefault();this.openPreviewLink(url);});return true;},
   afterRender:host=>{for(const img of host.querySelectorAll('img')){if(img.dataset.splitBound)continue;img.dataset.splitBound='true';img.decoding='async';const p=img.closest('p');if(p&&!p.textContent.trim())p.style.textAlign='center';img.addEventListener('error',()=>{if(!isCurrent()||!img.isConnected)return;const missing=this.node('span','et-xref-missing','图片暂时无法读取：'+(img.alt||'图片'));missing.title=img.src;img.replaceWith(missing);},{once:true});}}
  });}catch{this.rendered.textContent=markdown;}
  this.applyXrefTableStyles();this.scheduleTypography();
 }
 applyXrefTableStyles(){
  const c=this.citationPreview;if(!c||!this.rendered)return;
  for(const table of this.rendered.querySelectorAll('table'))table.classList.toggle('et-table-three-line',c.tableStyle==='three-line');
  if(c.tableStyle!=='three-line')for(const record of c.records.values())if(record.kind==='table'&&record.threeLine){const caption=c.media.locate(record),next=caption?.nextElementSibling,table=next?.matches('table')?next:next?.querySelector('table');table?.classList.add('et-table-three-line');}
 }
 toggleEdit(){if(!this.record)return;if(!this.save())return;this.editing=!this.editing;this.citationPreview?.hide();this.syncMain();if(this.editing)this.source.focus();else this.render();}
 save(){clearTimeout(this.saveTimer);if(!this.dirty||!this.record)return true;try{if(this.keyOf(this.record.file)===this.keyOf(File.bundle?.filePath))throw Error('此文件正在正文中编辑，请另存为副栏草稿');this.record=this.store.save(this.record,this.source.value);this.dirty=false;this.status('已保存');return true;}catch(error){this.status(error.message);return false;}}
 async saveAs(){if(!this.record)return;try{const result=await JSBridge.invoke('dialog.showSaveDialog',{title:'另存副栏草稿',defaultPath:this.record.file.replace(/\.md$/i,'-副栏.md'),filters:[{name:'Markdown',extensions:['md']}]});if(!result?.filePath||result.canceled)return;reqnode('fs').writeFileSync(result.filePath,this.source.value,{flag:'wx',encoding:'utf8'});this.dirty=false;this.open(result.filePath);}catch(error){this.status('另存未完成：'+error.message);}}
 refreshExternal(){if(!this.enabled||!this.record||this.dirty)return;try{const record=this.store.read(this.record.file);if(!record.base.equals(this.record.base)){this.record=record;this.source.value=record.text;this.render();this.status('已同步外部修改');}}catch(error){this.status(error.message);}}
 shareChrome(){
  document.body.classList.add('et-split-active');
  const host=document.getElementById('editing-toolbar-top-host');
  if(host&&!this.toolbarSlot){this.toolbarSlot=document.createComment('split toolbar position');host.before(this.toolbarSlot);document.body.append(host);}
 }
 releaseChrome(){
  document.body.classList.remove('et-split-active');for(const key of ['--et-split-left','--et-split-right'])document.body.style.removeProperty(key);
  const host=document.getElementById('editing-toolbar-top-host');if(this.toolbarSlot){if(host)this.toolbarSlot.replaceWith(host);else this.toolbarSlot.remove();this.toolbarSlot=null;}
  if(this.primaryHeader)this.primaryHeader.hidden=true;if(this.primaryFooter)this.primaryFooter.hidden=true;
 }
 scheduleTypography(){if(!this.enabled||this.typographyFrame)return;this.typographyFrame=requestAnimationFrame(()=>{this.typographyFrame=0;this.syncTypography();});}
 syncTypography(){
  if(!this.enabled||!this.rendered)return;const write=document.getElementById('write');if(!write)return;const root=getComputedStyle(write);
  for(const key of ['font-family','font-size','font-weight','line-height','letter-spacing','color','text-align','padding-top','padding-right','padding-bottom','padding-left','max-width']){const value=root.getPropertyValue(key);if(this.rendered.style.getPropertyValue(key)!==value)this.rendered.style.setProperty(key,value);}
  const properties=['font-family','font-size','font-weight','font-style','line-height','letter-spacing','color','background-color','text-align','margin-top','margin-bottom','padding-top','padding-bottom','padding-left','padding-right','border-top','border-bottom','border-left','border-right'];let css='';
  for(const tag of ['h1','h2','h3','h4','h5','h6','p','ul','ol','li','blockquote','pre','code','table','th','td','a','strong','em','li > p','blockquote > p','pre > code','tbody tr:nth-child(2n)','tbody tr:nth-child(2n+1)']){const node=write.querySelector(tag);if(!node)continue;const s=getComputedStyle(node);css+='.et-document-split .et-split-preview '+tag+'{'+properties.map(k=>k+':'+s.getPropertyValue(k)).join(';')+'}';}
  const header=write.querySelector('thead');if(header)css+='.et-document-split .et-split-preview tr:has(th){background:'+getComputedStyle(header).backgroundColor+'}';
  const figure=write.querySelector('figure.md-table-fig');if(figure){const s=getComputedStyle(figure);css+='.et-document-split .et-split-preview table{margin-top:'+s.marginTop+';margin-bottom:'+s.marginBottom+'}';}
  for(const [from,to]of [['.md-math-block','[data-note-math="block"]'],['.md-math-container','[data-note-math="block"]'],['.md-math-container mjx-container','[data-note-math="block"] mjx-container']]){const node=write.querySelector(from);if(!node)continue;const s=getComputedStyle(node),keys=from==='.md-math-container'?['font-family','font-size','line-height','background-color']:properties;css+='.et-document-split .et-split-preview '+to+'{'+keys.map(k=>k+':'+s.getPropertyValue(k)).join(';')+'}';}
  css+='.et-document-split .et-split-preview [data-note-math="block"]{display:flow-root}';
  css+='.et-document-split .et-split-preview :is(th,td)>p{margin:0;padding:0;font:inherit;letter-spacing:inherit;color:inherit;background:transparent}';
  if(this.typography.textContent!==css)this.typography.textContent=css;
 }
 restore(){if(!this.original)return;const c=this.original.node;for(const [key,v]of Object.entries(this.original.styles)){if(v.value)c.style.setProperty(key,v.value,v.priority);else c.style.removeProperty(key);}this.original=null;}
 layout(){
  if(!this.enabled||!this.panel||this.layingOut)return;this.layingOut=true;
  try{
   const c=document.querySelector('content');if(!c)return;this.shareChrome();
   if(!this.original)this.original={node:c,styles:Object.fromEntries(['left','right','top','bottom'].map(k=>[k,{value:c.style.getPropertyValue(k),priority:c.style.getPropertyPriority(k)}]))};
   const b=this.bounds(),side=['left','right'].includes(this.side)&&b.right-b.left<560?'bottom':this.side,horizontal=['left','right'].includes(side),span=horizontal?b.right-b.left:b.bottom-b.top;this.layoutSide=side;
   // Measuring code-workspace bounds must not invalidate every descendant style.
   for(const [k,v]of [['--et-split-left',b.left+'px'],['--et-split-right',(innerWidth-b.right)+'px']])if(document.body.style.getPropertyValue(k)!==v)document.body.style.setProperty(k,v);
   if(span<260||b.right-b.left<200){this.restore();this.releaseChrome();this.panel.hidden=true;this.divider.hidden=true;return;}
   this.panel.hidden=false;this.divider.hidden=false;this.primaryHeader.hidden=false;this.primaryFooter.hidden=false;
   const gap=5,size=Math.round((span-gap)*this.ratio),r={left:b.left,top:b.top,width:b.right-b.left,height:b.bottom-b.top},main={...r};
   if(horizontal){r.width=size;main.width=span-size-gap;if(side==='right')r.left=b.right-size;else main.left=b.left+size+gap;Object.assign(this.divider.style,{left:(side==='right'?r.left-gap:b.left+size)+'px',top:b.top+'px',width:gap+'px',height:r.height+'px',cursor:'ew-resize'});}
   else{r.height=size;main.height=span-size-gap;if(side==='bottom')r.top=b.bottom-size;else main.top=b.top+size+gap;Object.assign(this.divider.style,{left:b.left+'px',top:(side==='bottom'?r.top-gap:b.top+size)+'px',width:r.width+'px',height:gap+'px',cursor:'ns-resize'});}
   const set=(key,value)=>{if(c.style.getPropertyValue(key)!==value+'px')c.style.setProperty(key,value+'px','important');};
   set('left',main.left);set('right',innerWidth-main.left-main.width);set('top',main.top+32);set('bottom',innerHeight-main.top-main.height+22);
   for(const k of ['left','top','width','height'])if(this.panel.style[k]!==r[k]+'px')this.panel.style[k]=r[k]+'px';this.panel.dataset.narrow=String(r.width<440);
   Object.assign(this.primaryHeader.style,{left:main.left+'px',top:main.top+'px',width:main.width+'px',height:'32px'});
   Object.assign(this.primaryFooter.style,{left:main.left+'px',top:(main.top+main.height-22)+'px',width:main.width+'px',height:'22px'});
   const file=File.bundle?.filePath||'';this.primaryTitle.textContent=file?reqnode('path').basename(file):'未命名';this.primaryTitle.title=file;
   this.scheduleTypography();
  }finally{this.layingOut=false;this.toolbar.codeEditor?.layout();}
 }
 resize(e){if(e.button!==0)return;e.preventDefault();const start=this.ratio,b=this.bounds(),side=this.layoutSide||this.side,horizontal=['left','right'].includes(side),origin=horizontal?e.clientX:e.clientY,span=horizontal?b.right-b.left:b.bottom-b.top,direction=['left','top'].includes(side)?1:-1,shield=this.node('div','et-term-drag-shield');document.body.append(shield);shield.setPointerCapture(e.pointerId);shield.onpointermove=v=>{this.ratio=Math.max(.25,Math.min(.75,start+direction*((horizontal?v.clientX:v.clientY)-origin)/span));this.layout();};const done=()=>{shield.remove();window.removeEventListener('blur',done);window.removeEventListener('keydown',escape,true);this.persist();},escape=v=>{if(v.key==='Escape'){v.preventDefault();done();}};window.addEventListener('blur',done,{once:true});window.addEventListener('keydown',escape,true);shield.onpointerup=done;shield.onpointercancel=done;}
}
