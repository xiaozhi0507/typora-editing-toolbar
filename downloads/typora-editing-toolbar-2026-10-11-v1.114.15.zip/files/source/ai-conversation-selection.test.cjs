const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
function fixture(){
  const state={removed:[],errors:[],reset:0,flush:0,loading:false};const box={File:{isFileLoading:()=>state.loading}};vm.createContext(box);vm.runInContext(fs.readFileSync(require.resolve('./ai-conversations.js'),'utf8')+';globalThis.C=EditingToolbarAIConversations;',box);
  const records='abcde'.split('').map(id=>({id,title:'Title '+id,revision:'r1',file:id+'.md',turns:[]})),store={remove(r){if(state.fail===r.id)throw Error('revision conflict');state.removed.push({...r});}};
  const c=Object.assign(Object.create(box.C.prototype),{visible:records,records,filter:'all',store,record:null,selection:null,list:{children:records.map(r=>({dataset:{id:r.id},focus(){},scrollIntoView(){}}))},syncManagerSelection(){},ask:async(...args)=>{state.ask=args;return true;},recordStore:()=>store,storage:()=>store,flush(){state.flush++;return state.saveOK!==false;},error:e=>state.errors.push(e.message),ai:{busy:false,newConversation(){state.reset++;}},dialog:{open:false}});c.reconcileSelection('all');return {c,state,records,ids:()=>Array.from(c.selection)};
}
test('Ctrl toggles arbitrary rows including deselecting the last row; normal click replaces',()=>{
  const {c,ids}=fixture();c.selectRecord('c',{ctrlKey:true});assert.deepEqual(ids(),['a','c']);c.selectRecord('a',{ctrlKey:true});assert.deepEqual(ids(),['c']);c.selectRecord('c',{ctrlKey:true});assert.deepEqual(ids(),[]);assert.equal(c.selected,null);c.selectRecord('e');assert.deepEqual(ids(),['e']);
});
test('Shift extends and shrinks a forward or backward range from the original anchor',()=>{
  const {c,ids}=fixture();c.selectRecord('b');c.selectRecord('e',{shiftKey:true});assert.deepEqual(ids(),['b','c','d','e']);c.selectRecord('c',{shiftKey:true});assert.deepEqual(ids(),['b','c']);assert.equal(c.selectionAnchor,'b');c.selectRecord('a',{shiftKey:true});assert.deepEqual(ids(),['a','b']);
});
test('Ctrl+Shift unions a range and favorites remain single selection',()=>{
  const {c,ids}=fixture();c.selectRecord('e',{ctrlKey:true});c.selectRecord('c',{ctrlKey:true,shiftKey:true});assert.deepEqual(ids(),['a','e','c','d']);c.filter='favorites';c.selectRecord('b',{ctrlKey:true,shiftKey:true});assert.deepEqual(ids(),['b']);
});
test('new search/filter resets hidden choices and stale IDs never survive reconciliation',()=>{
  const {c,ids,records}=fixture();c.selectRecord('e',{ctrlKey:true});c.visible=records.slice(1,3);c.reconcileSelection('all/search');assert.deepEqual(ids(),['b']);c.selectRecord('c',{ctrlKey:true});c.visible=[records[2]];c.reconcileSelection('all/search');assert.deepEqual(ids(),['c']);c.visible=[];c.reconcileSelection('all/search');assert.deepEqual(ids(),[]);assert.equal(c.focusId,null);
});
test('list keyboard selection uses only visible rows and Delete dispatches their selection',()=>{
  const {c,ids,records}=fixture();c.visible=records.slice(1,4);c.reconcileSelection('search');const key=(id,k,extra={})=>({key:k,target:{closest:()=>({dataset:{id}})},preventDefault(){this.prevented=true},...extra});
  c.managerSelectionKey(key('b','ArrowDown',{shiftKey:true}));assert.deepEqual(ids(),['b','c']);c.managerSelectionKey(key('c','a',{ctrlKey:true}));assert.deepEqual(ids(),['b','c','d']);
  let selected;c.deleteRecords=async rows=>{selected=rows};c.managerSelectionKey(key('c','Delete'));assert.deepEqual(selected.map(r=>r.id),['b','c','d']);
});
test('cancel performs no writes and retains selection',async()=>{
  const {c,state,ids}=fixture();c.selectRecord('c',{ctrlKey:true});c.ask=async()=>null;await c.deleteRecords(c.selectedRecords());assert.equal(state.removed.length,0);assert.deepEqual(ids(),['a','c']);assert.equal(c.managerDeleting,false);
});
test('batch confirmation matches deduplicated conversation targets and excludes favorites',async()=>{
  const {c,state,records}=fixture();const result=await c.deleteRecords([records[0],records[0],{...records[1],kind:'favorite'},records[2]]);assert.equal(state.ask[0],'删除这 2 个对话？');assert.deepEqual(Array.from(state.ask[3].subjects),['Title a','Title c']);assert.deepEqual(Array.from(result.removed),['a','c']);assert.deepEqual(state.removed.map(r=>r.id),['a','c']);
});
test('changing selection during confirmation cannot substitute deletion targets',async()=>{
  const {c,state}=fixture();let confirm;c.ask=()=>new Promise(resolve=>confirm=resolve);const pending=c.deleteRecords(c.selectedRecords());c.selection=new Set(['e']);c.filter='current';confirm(true);await pending;assert.deepEqual(state.removed.map(r=>r.id),['a']);
});
test('one conflict preserves its record while unrelated selected records can be deleted',async()=>{
  const {c,state,records}=fixture();state.fail='b';const result=await c.deleteRecords(records.slice(0,3));assert.deepEqual(state.removed.map(r=>r.id),['a','c']);assert.equal(result.failed.length,1);assert.equal(result.failed[0].record.id,'b');assert.match(state.errors[0],/revision conflict/);
});
test('current conversation flushes latest revision and resets only after removal',async()=>{
  const {c,state,records}=fixture();c.record=records[1];c.flush=()=>{state.flush++;c.record={...c.record,revision:'latest'};return true};await c.deleteRecords(records.slice(0,3));assert.equal(state.flush,1);assert.equal(state.removed[1].revision,'latest');assert.equal(state.reset,1);assert.equal(c.record,null);
});
test('failed current-session save prevents the whole batch',async()=>{
  const {c,state,records}=fixture();c.record=records[1];state.saveOK=false;await c.deleteRecords(records.slice(0,3));assert.equal(state.removed.length,0);assert.equal(state.reset,0);
});
test('busy or loading after confirmation prevents writes',async()=>{
  const {c,state,records}=fixture();c.ask=async()=>{c.ai.busy=true;return true};await c.deleteRecords(records);assert.equal(state.removed.length,0);c.ai.busy=false;c.ask=async()=>true;state.loading=true;await c.deleteRecords(records);assert.equal(state.removed.length,0);assert.match(state.errors[0],/加载/);
});
