'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const Core=require('./document-projects.cjs');
function tabs(host={}){const C=vm.runInNewContext(fs.readFileSync(__dirname+'/document-tabs.js','utf8')+';EditingToolbarDocumentTabs',host);return Object.assign(Object.create(C.prototype),{path,fs,fileSelection:new Map(),selectionAnchor:null});}
function row(key,project='p',visible=true){const attrs={},classes=new Set();const button={getAttribute:k=>attrs[k]??null,setAttribute:(k,v)=>attrs[k]=v};return {dataset:{key,path:'C:/project/'+key,projectId:project},classList:{contains:c=>classes.has(c),toggle:(c,on)=>on?classes.add(c):classes.delete(c)},getClientRects:()=>visible?[{}]:[],querySelector:()=>button,attrs,classes};}

test('ordinary selection skips layout reads and repaint of unchanged selection skips DOM writes',()=>{
 const t=tabs(),a=row('a'),b=row('b');t.list={querySelectorAll:()=>[a,b]};for(const r of [a,b])r.getClientRects=()=>assert.fail('ordinary selection should not measure rows');
 t.selectProjectFile(a);for(const r of [a,b]){r.classList.toggle=()=>assert.fail('unchanged class');r.querySelector().setAttribute=()=>assert.fail('unchanged aria state');}t.paintFileSelection();
});
test('project selection replaces, toggles and ranges only visible rows, without opening files',()=>{
 const t=tabs(),rows=[row('a'),row('hidden','p',false),row('b'),row('c'),row('other','q')];t.list={querySelectorAll:()=>rows};t.openEntry=()=>assert.fail('selection opened a file');
 t.selectProjectFile(rows[0]);assert.deepEqual([...t.fileSelection.keys()],['a']);assert.equal(rows[0].attrs['aria-selected'],'true');
 t.selectProjectFile(rows[2],{ctrlKey:true});assert.deepEqual([...t.fileSelection.keys()],['a','b']);
 t.selectProjectFile(rows[0],{ctrlKey:true});assert.deepEqual([...t.fileSelection.keys()],['b']);
 t.selectProjectFile(rows[3],{shiftKey:true});assert.deepEqual([...t.fileSelection.keys()],['a','b','c']);
 t.selectProjectFile(rows[4],{shiftKey:true});assert.deepEqual([...t.fileSelection.keys()],['other']);
 t.selectProjectFile(rows[0]);t.selectProjectFile(rows[2],{ctrlKey:true,shiftKey:true});assert.deepEqual([...t.fileSelection.keys()],['a','b']);
});
test('selection survives rebuilt rows and right-click menu acts on the selected set',()=>{
 const t=tabs(),a=row('a'),b=row('b');t.list={querySelectorAll:()=>[a,b]};t.selectProjectFile(a);t.selectProjectFile(b,{ctrlKey:true});
 const fresh=row('a');t.paintSelectedRow(fresh);assert.equal(fresh.attrs['aria-selected'],'true');
 // Menu paths use normalized keys, just as real rendered rows do.
 t.fileSelection=new Map([['c:/a.py','C:/a.py'],['c:/b.py','C:/b.py']]);t.showMenu=(items)=>{assert.equal(items.length,1);assert.equal(items[0].label,'删除 2 个文件');};t.rowMenu('C:/a.py',{}, {closest:()=>({})});
});
test('documents use their default app while disabled AI workspace code never executes externally',async()=>{
 const opened=[],notices=[],t=tabs({reqnode:()=>({shell:{openPath:async file=>{opened.push(file);return file.includes('bad')?'no association':'';}}})});
 t.fs={promises:{stat:async()=>({isFile:()=>true})}};t.fileAction=fn=>fn();t.activate=file=>opened.push('Typora:'+file);t.notice=message=>notices.push(message);
 await t.openEntry('C:/中文 路径/demo.py');await t.openEntry('C:/docs/note.md');await t.openEntry('C:/bad.pdf');assert.equal(opened.length,2);assert.equal(opened[0],'Typora:C:/docs/note.md');assert.match(opened[1],/bad\.pdf$/);assert.deepEqual(notices,['请在插件市场启用 AI 阅读助手后打开此文件','no association']);
});
async function deletion(t){
 const scratch='C:/Users/xiaozhi/Downloads/codex-temp',dir=fs.mkdtempSync(path.join(scratch,'selection-delete-'));
 t.after(()=>{assert.ok(path.resolve(dir).startsWith(path.resolve(scratch)+path.sep));fs.rmSync(dir,{recursive:true,force:true});});
 const core=new Core(),p=await core.trust(await core.plan('Test','',dir));const files=[];for(const name of ['中文 甲.py','空格 乙.js','丙.txt'])files.push((await core.createFile(p,name,'original')).path);
 const state={response:1,trash:[],fail:null,confirm(){},dirty:false,current:''};const ui=tabs({File:{bundle:{get filePath(){return state.current;}},isDocumentEdited:()=>state.dirty},window:{},JSBridge:{invoke:async(name,file)=>{
  if(name==='dialog.showMessageBox'){state.confirm();return {response:state.response};}
  if(name==='shell.trashItem'){if(file===state.fail)return false;fs.unlinkSync(file);state.trash.push(file);return true;}
 }}}),db={tabs:files.map(path=>({path})),favorites:files.map(path=>({path})),pinned:files.map(path=>({path}))};
 Object.assign(ui,{projects:{core,items:[p]},change:fn=>fn(db),schedule(){},notice(){}});ui.fileSelection=new Map(files.map(f=>[ui.key(f),f]));return {ui,files,db,state};
}
test('batch cancel preserves every file and selection; success recycles each unique file once',async t=>{
 const f=await deletion(t);assert.equal(await f.ui.deleteFiles(f.files),false);assert.equal(f.state.trash.length,0);assert.equal(f.ui.fileSelection.size,3);
 f.state.response=0;assert.equal(await f.ui.deleteFiles([...f.files,f.files[0]]),true);assert.equal(f.state.trash.length,3);assert.equal(f.ui.fileSelection.size,0);assert.equal(f.db.favorites.length,0);assert.ok(f.files.every(p=>!fs.existsSync(p)));
});
test('batch preflight rechecks all files before any deletion and protects a dirty active document',async t=>{
 const f=await deletion(t);f.state.response=0;f.state.confirm=()=>fs.writeFileSync(f.files[2],'changed while confirming');await assert.rejects(f.ui.deleteFiles(f.files),/变化/);assert.equal(f.state.trash.length,0);
 f.state.current=f.files[0];f.state.dirty=true;assert.equal(await f.ui.deleteFiles(f.files),false);assert.ok(f.files.every(p=>fs.existsSync(p)));
});
test('partial recycle failure keeps remaining selection and metadata consistent with disk',async t=>{
 const f=await deletion(t);f.state.response=0;f.state.fail=f.files[1];await assert.rejects(f.ui.deleteFiles(f.files),/已移到回收站 2/);assert.deepEqual([...f.ui.fileSelection.values()],[f.files[1]]);assert.deepEqual(f.db.favorites,[{path:f.files[1]}]);assert.ok(fs.existsSync(f.files[1]));
});
function web(){
 const C=vm.runInNewContext(fs.readFileSync(__dirname+'/ai-web.js','utf8')+';EditingToolbarAIWeb',{ETAIFileReference:{web:s=>s}}),ui=Object.create(C.prototype);
 const node=(tag,cls,text)=>({tag,cls,text,children:[],get childElementCount(){return this.children.length;},append(...n){this.children.push(...n);},remove(){this.removed=true;}});
 ui.ai={node,referencesUI:{created:f=>node('button','created',f.path),changes:(_t,f)=>f.length?node('div','changes'):null,webLink:n=>n}};return ui;
}
test('created file results stay hidden through streaming then appear at completion without new tool data',()=>{
 const ui=web(),inserted=[],turn={status:'running',requestContext:{createdFiles:[{path:'real.py'}]},actions:{isConnected:true,before:n=>inserted.push(n)}};
 ui.render(turn);assert.equal(inserted.length,0);turn.answer='still streaming';ui.render(turn);assert.equal(inserted.length,0);
 turn.status='done';ui.render(turn);assert.equal(inserted.length,1);assert.equal(inserted[0].children[0].cls,'et-ai-file-artifacts');assert.equal(inserted[0].children[0].children[0].text,'real.py');ui.render(turn);assert.equal(inserted.length,1);
});
test('sources remain live; actual created files remain accessible after stop, error and legacy restore',()=>{
 for(const status of ['stopped','error',undefined]){const ui=web(),inserted=[],turn={status:'running',requestContext:{webSources:[{title:'Source',url:'https://example.com'}],createdFiles:[{path:'real.py'}]},actions:{isConnected:true,before:n=>inserted.push(n)}};ui.render(turn);assert.equal(inserted[0].children.length,1);turn.status=status;ui.render(turn);assert.equal(inserted.length,2);assert.equal(inserted[0].removed,true);assert.equal(inserted[1].children.length,2);}
});
