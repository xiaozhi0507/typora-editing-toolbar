import {parentPort,fs,path,fileURLToPath} from './research-index-platform.js';
import {parseNote} from './research-note-core.js';
const key=p=>path.resolve(p).replace(/\\/g,'/').toLowerCase(),skip=name=>name.startsWith('.')||/\.(资料|笔记|注释|标注)$/.test(name)||['node_modules','素材暂存盘','$RECYCLE.BIN'].includes(name);
let cache=new Map(),generation=0,inventory=null;
async function build(message){
 const gen=++generation,{root,file,source,id}=message,notes=[],reuse=message.incremental&&inventory?.root===key(root),files=reuse?[...inventory.files]:[],warnings=reuse?[...inventory.warnings]:[],known=reuse?new Map(inventory.known):new Map();let limit=reuse?inventory.limit:false;
 const walk=async dir=>{if(gen!==generation||limit)return;let entries;try{entries=await fs.promises.readdir(dir,{withFileTypes:true});}catch(e){warnings.push(path.relative(root,dir)+': '+e.code);return;}for(const ent of entries){if(gen!==generation||limit)return;if(skip(ent.name)||ent.isSymbolicLink())continue;const name=path.join(dir,ent.name);if(ent.isDirectory())await walk(name);else if(ent.isFile()){if(files.length>=30000){limit=true;return;}files.push(name);known.set(key(name),name);}}};
 if(!reuse){await walk(root);if(gen!==generation)return;inventory={root:key(root),files:[...files],known:new Map(known),warnings:[...warnings],limit};}
 if(file&&!known.has(key(file))){files.push(file);known.set(key(file),file);}let processed=0,cursor=0;
 const markdown=files.filter(p=>/\.(md|markdown)$/i.test(p)),parsedNotes=new Array(markdown.length);
 // Small bounded I/O batches avoid a renderer round trip for every single file.
 // Only navigation may reuse the inventory; watcher/manual refreshes revalidate it.
 await Promise.all(Array.from({length:Math.min(8,markdown.length)},async()=>{while(cursor<markdown.length&&gen===generation){const at=cursor++,name=markdown[at],nameKey=key(name),current=nameKey===key(file),cached=cache.get(nameKey);try{
   let parsed;if(reuse&&!current&&cached)parsed=cached.parsed;else{const stat=await fs.promises.stat(name);if(gen!==generation)return;if(stat.size>8*1024*1024){cache.delete(nameKey);warnings.push(path.basename(name)+' 超过 8 MB，已跳过');continue;}
    if(current&&typeof source==='string')parsed=parseNote(source);
    else if(cached&&cached.mtime===stat.mtimeMs&&cached.size===stat.size)parsed=cached.parsed;
    else{const text=await fs.promises.readFile(name,'utf8');if(gen!==generation)return;parsed=parseNote(text);cache.set(nameKey,{mtime:stat.mtimeMs,size:stat.size,parsed});}
   }
   parsedNotes[at]={id:nameKey,path:name,relative:path.relative(root,name).replace(/\\/g,'/'),label:path.basename(name,path.extname(name)),kind:'note',exists:true,...parsed};
  }catch(e){if(gen===generation)cache.delete(nameKey);warnings.push(path.basename(name)+': '+e.message);}processed++;if(processed%100===0&&gen===generation)parentPort.postMessage({id,progress:processed});}}));
 if(gen!==generation)return;notes.push(...parsedNotes.filter(Boolean));
 for(const cachedKey of cache.keys())if(!known.has(cachedKey))cache.delete(cachedKey);
 const nodes=new Map(notes.map(n=>[n.id,n])),byName=new Map();for(const n of notes)for(const alias of new Set([n.label,...n.aliases])){const a=alias.toLowerCase();if(!byName.has(a))byName.set(a,[]);byName.get(a).push(n.id);}
 const edges=new Map(),existence=new Map(),add=(a,b)=>{if(a!==b)edges.set(a+'\u0000'+b,{source:a,target:b});};
 for(const n of notes){for(const link of n.links){if(gen!==generation)return;if(link.embed&&!link.wiki)continue;let target=String(link.target||'').split('#')[0].split('?')[0].trim();if(!target)continue;try{target=decodeURIComponent(target);}catch{}if(/^file:/i.test(target)){try{target=fileURLToPath(target);}catch{continue;}}else if(/^[a-z][\w+.-]*:/i.test(target)&&!path.isAbsolute(target))continue;
  const candidates=path.isAbsolute(target)?[target]:[path.resolve(path.dirname(n.path),target),...(link.wiki?[path.resolve(root,target)]:[])];let resolved=null;for(const c of candidates){for(const p of [c,...(!path.extname(c)?[c+'.md',c+'.markdown']:[])])if(known.has(key(p))){resolved=known.get(key(p));break;}if(resolved)break;}
  if(!resolved&&link.wiki){const matches=byName.get(target.toLowerCase());if(matches?.length===1)resolved=nodes.get(matches[0]).path;}
  const targetPath=resolved||candidates[0];
  // Images remain in the document, but are not graph relationships (including
  // ordinary image-file links, wiki embeds and missing image targets).
  if(/\.(?:png|apng|jpe?g|gif|webp|svg|bmp|ico|tiff?|avif|heic|heif)$/i.test(targetPath))continue;
  let exists=!!resolved;if(!exists&&path.isAbsolute(targetPath)){const targetKey=key(targetPath);if(!existence.has(targetKey)){let found=false;try{found=(await fs.promises.stat(targetPath)).isFile();}catch{}existence.set(targetKey,found);}exists=existence.get(targetKey);}
  const isNote=/\.(md|markdown)$/i.test(targetPath)||(!exists&&!path.extname(targetPath)),targetId=resolved?key(resolved):'missing:'+key(isNote&&!path.extname(targetPath)?targetPath+'.md':targetPath);
  if(!nodes.has(targetId))nodes.set(targetId,{id:targetId,path:targetPath,relative:path.relative(root,targetPath).replace(/\\/g,'/'),label:path.basename(targetPath,isNote?path.extname(targetPath):''),kind:isNote?'note':'attachment',exists,tags:[]});add(n.id,targetId);
 }for(const tag of n.tags){const id='tag:'+tag;if(!nodes.has(id))nodes.set(id,{id,label:'#'+tag,relative:'#'+tag,kind:'tag',exists:true,tags:[tag]});add(n.id,id);}}
 if(gen===generation)parentPort.postMessage({id,result:{root,nodes:[...nodes.values()],edges:[...edges.values()],notes:notes.filter(n=>key(n.path).startsWith(key(root)+'/')).length,warnings:warnings.slice(0,20),limited:limit}});
}
parentPort.on('message',m=>{if(m.cancel){generation++;return;}build(m).catch(e=>parentPort.postMessage({id:m.id,error:e.message}));});
