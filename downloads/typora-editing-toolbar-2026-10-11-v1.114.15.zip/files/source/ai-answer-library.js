class EditingToolbarAIAnswerLibrary {
  constructor(conversations) {
    this.c=conversations;this.ai=conversations.ai;this.items=new Map();
    this.ensureStore();
  }
  ensureStore() {
    const path=reqnode('path'),directory=path.join(this.c.storage().directory,'favorites');if(this.store?.directory===directory)return;
    this.store=new ETAISessionStore(reqnode,directory,{legacy:new ETAIConversationStore(reqnode,path.join(this.c.legacyStore.directory,'favorites'))});this.items.clear();this.ready=false;this.version=(this.version||0)+1;
  }
  async load() {this.ensureStore();const store=this.store,version=this.version||0,result=await store.list();if(store===this.store&&version===(this.version||0)){this.items=new Map(result.records.map(r=>[r.id,r]));this.ready=true;this.errors=result.errors;this.sync();}return {records:[...this.items.values()],errors:this.errors||0};}
  id(turn) {return this.store.stableId('answer:'+turn.id);}
  has(turn) {return !!turn.id&&this.items.has(this.id(turn));}
  sync() {
    for(const t of this.ai.turns)this.update(t.actions,t);
  }
  update(actions,turn) {
    const b=actions?.querySelector('[data-answer-action=favorite]');if(!b)return;const active=this.has(turn);
    b.title=active?'取消收藏':'收藏回答';b.setAttribute('aria-label',b.title);b.setAttribute('aria-pressed',String(active));b.disabled=!this.ready||turn.status==='running'||(turn.answer!==undefined&&!turn.answer);
  }
  async toggle(turn,record) {
    if(turn.status==='running'||!turn.answer)return;
    this.ensureStore();
    if(!this.ready)await this.load();
    if(!record){if(!this.c.flush())return;record=this.c.record;}
    const id=this.id(turn),desired=!this.items.has(id);let previous;
    try{previous=this.store.read(id);}catch(e){if(e.code!=='ENOENT')throw e;}
    if(desired){
      const fields=['id','question','displayQuestion','answer','reasoning','reasoningKind','status','model','reference','time','elapsedMs'];
      const saved=this.store.write({id,kind:'favorite',originId:record.originId||record.id,title:(turn.displayQuestion||turn.question||record.title).replace(/\s+/g,' ').slice(0,100),file:record.file,created:previous?.created||new Date().toISOString(),turns:[Object.fromEntries(fields.map(k=>[k,turn[k]]))],draft:''},previous?.revision,null);
      this.items.set(id,saved);
    }else {if(previous&&!previous.deleted)this.store.remove(previous);this.items.delete(id);}
    this.version=(this.version||0)+1;this.sync();this.ai.toolbar._showToolbarNotice(desired?'已收藏回答':'已取消收藏');
    if(this.c.dialog?.open){const scroll=this.c.preview.scrollTop;this.c.renderManager();this.c.preview.scrollTop=scroll;}
  }
}
