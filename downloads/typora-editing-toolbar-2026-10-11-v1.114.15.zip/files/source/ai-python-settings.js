class EditingToolbarAIPythonSettings {
 constructor(ai){this.ai=ai;this.rows=[];this.generation=0;}
 get manager(){return this.ai.toolbar.terminal.pythonManager;}
 node(tag,cls='',text=''){return this.ai.node(tag,cls,text);}
 button(text,fn,cls=''){const b=this.node('button',cls,text);b.type='button';b.onclick=()=>Promise.resolve().then(fn).catch(e=>this.notice(e.message,true));return b;}
 icon(name){const icon=this.node('span','et-python-icon');icon.setAttribute('aria-hidden','true');const paths={refresh:'<path d="M20 4v6h-6M4 20v-6h6M4.8 9a7.5 7.5 0 0 1 12.4-4L20 8M4 16l2.8 3A7.5 7.5 0 0 0 19.2 15"/>',folder:'<path d="M3 7V6a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Zm0 1h18"/>',download:'<path d="M12 3v12m-4-4 4 4 4-4M5 15v5h14v-5"/>',python:'<rect x="3" y="4" width="18" height="16" rx="3"/><path d="m7 9 3 3-3 3m6 0h4"/>',global:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a18 18 0 0 1 0 18 18 18 0 0 1 0-18"/>'};icon.innerHTML='<svg viewBox="0 0 24 24">'+paths[name]+'</svg>';return icon;}
 iconButton(text,fn,name){const button=this.button('',fn);button.setAttribute('aria-label',text);button.title=text;button.append(this.icon(name));return button;}
 mount(){
  const a=this.ai,tab=this.button('项目环境',()=>a.setView('python'));tab.dataset.ai='python';tab.setAttribute('role','tab');tab.setAttribute('aria-selected','false');tab.tabIndex=-1;a.nav.append(tab);
  this.panel=this.node('section','et-ai-python');this.panel.hidden=true;this.panel.setAttribute('aria-label','项目环境');a.preferencesStatus.before(this.panel);
  const head=this.node('div','et-skills-head'),title=this.node('div','et-skills-heading');title.append(this.node('h2','','项目环境'),this.node('p','','管理 Python 与科研绘图依赖'));const tools=this.node('div','et-skills-controls');
  this.refreshButton=this.iconButton('重新检测',()=>this.refresh(true),'refresh');this.browseButton=this.iconButton('选择 Python…',()=>this.browse(),'folder');
  this.installButton=this.button('',()=>this.install(),'et-skills-add');this.installButton.setAttribute('aria-label','一键安装科研环境');this.installButton.title='一键安装科研环境';this.installButton.append(this.icon('download'),this.node('span','','安装环境'));tools.append(this.refreshButton,this.browseButton,this.installButton);head.append(title,tools);
  const defaults=this.node('div','et-python-defaults');
  this.projectSelect=this.node('select');this.projectSelect.setAttribute('aria-label','选择项目');this.projectSelect.onchange=()=>{this.projectRoot=this.projectSelect.value;this.selectedExe=this.manager.choice(this.projectRoot);this.renderChoices();this.renderRows();};
  this.projectPython=this.node('select');this.projectPython.setAttribute('aria-label','项目 Python');this.projectPython.onchange=()=>this.setChoice(this.projectPython.value,true).catch(e=>this.notice(e.message,true));
  const project=this.node('div','et-python-setting'),projectHead=this.node('div','et-python-setting-head');projectHead.append(this.icon('folder'),this.node('strong','','项目单独设置'));project.append(projectHead,this.projectSelect,this.projectPython);this.projectPath=this.node('div','et-python-path');project.append(this.projectPath);defaults.append(project);
  const inspector=this.node('div','et-python-inspector'),inspectorHead=this.node('div','et-skills-installed');inspectorHead.append(this.node('h3','','已检测'));this.count=this.node('span','et-skills-count');inspectorHead.append(this.count);
  this.environmentSelect=this.node('select');this.environmentSelect.setAttribute('aria-label','查看 Python 环境');this.environmentSelect.onchange=()=>{this.selectedExe=this.environmentSelect.value;this.renderRows();};
  this.list=this.node('div','et-python-list');this.list.setAttribute('aria-label','选中环境的详情');inspector.append(inspectorHead,this.environmentSelect,this.list);
  this.cancelButton=this.button('取消安装',()=>{this.manager.cancel();this.notice('正在取消，安装中的 Python 将在当前步骤完成后停止');});this.cancelButton.hidden=true;
  this.status=this.node('div','et-python-status');this.status.setAttribute('role','status');this.status.setAttribute('aria-live','polite');this.status.hidden=true;
  this.progress=this.node('progress');this.progress.setAttribute('aria-label','安装进度');this.progress.hidden=true;
  this.log=this.node('pre','et-python-log');this.log.hidden=true;this.log.tabIndex=0;this.log.setAttribute('aria-label','安装输出');
  const defaultsHead=this.node('div','et-skills-installed et-python-defaults-head');defaultsHead.append(this.node('h3','','默认设置'));
  this.scroll=this.node('div','et-skills-scroll et-python-scroll');this.scroll.append(this.status,this.cancelButton,this.progress,this.log,inspector,defaultsHead,defaults);this.panel.append(head,this.scroll);
  window.addEventListener('storage',e=>{if(e.key===ETPythonManager.KEY&&!this.panel.hidden){this.renderChoices();this.renderRows();}});
 }
 projects(){const p=this.ai.toolbar.documentTabs?.projects;p?.read();return p?.items||[];}
 project(){return this.projects().find(p=>this.manager.key(p.root)===this.manager.key(this.projectRoot||this.manager.directory));}
 trustedRoots(){return this.projects().filter(p=>p.trusted).map(p=>p.root);}
 async open(){if(!this.opened){this.opened=true;const active=this.ai.toolbar.documentTabs?.projects?.active?.();this.projectRoot=active?.root||this.projects()[0]?.root||'';}this.renderChoices();await this.refresh();}
 notice(message,error=false,transient=false){window.clearTimeout(this.noticeTimer);this.status.textContent=message;this.status.dataset.error=String(error);this.status.hidden=!message;if(message&&transient)this.noticeTimer=window.setTimeout(()=>this.notice(''),2200);}
 clearFeedback(){this.notice('');this.log.textContent='';this.log.hidden=true;this.progress.hidden=true;}
 controls(){const busy=!!(this.manager.busy||this.installing||this.choosing);for(const n of [this.projectSelect,this.browseButton,this.installButton])n.disabled=busy;this.environmentSelect.disabled=busy||!this.rows.length;this.refreshButton.disabled=busy||!!this.refreshing;this.installButton.disabled=this.browseButton.disabled=busy||!!this.refreshing;this.projectPython.disabled=busy||!this.project()?.trusted;this.cancelButton.hidden=!this.manager.busy;this.progress.hidden=!this.manager.busy;for(const b of this.list.querySelectorAll('button'))b.disabled=busy||b.dataset.unavailable==='true';}
 environmentName(row){const path=String(row.exe).replaceAll('\\','/'),parts=path.split('/').filter(Boolean),managed=this.manager.key(this.manager.directory).replaceAll('\\','/').replace(/\/$/,'')+'/scientific/';parts.pop();if(/^scripts$/i.test(parts.at(-1)))parts.pop();return this.manager.key(row.exe).replaceAll('\\','/').startsWith(managed)?'科研环境':parts.at(-1)||'Python';}
 option(row){const option=new Option((row.version?'Python '+row.version+' · ':'')+this.environmentName(row)+(row.error?' · 不可用':row.ready?' · 已就绪':''),row.exe);option.title=row.exe;return option;}
 options(select,value,empty){select.replaceChildren();select.append(new Option(empty,''));const choices=new Map(this.rows.map(r=>[this.manager.key(r.exe),r]));if(value&&!choices.has(this.manager.key(value)))choices.set(this.manager.key(value),{exe:value});for(const row of choices.values())select.append(this.option(row));select.value=value?choices.get(this.manager.key(value))?.exe||value:'';select.title=value||empty;}
 renderChoices(){
  const s=this.manager.read(),projects=this.projects();
  this.projectSelect.replaceChildren();if(!projects.length)this.projectSelect.append(new Option('尚未添加项目',''));for(const p of projects)this.projectSelect.append(new Option((p.name||reqnode('path').basename(p.root))+(p.trusted?'':'（未信任）'),p.root));
  if(!projects.some(p=>p.root===this.projectRoot))this.projectRoot=projects[0]?.root||'';this.projectSelect.value=this.projectRoot;
  this.options(this.projectPython,this.projectRoot?s.projects[this.manager.key(this.projectRoot)]||'':'','跟随全局默认');this.projectPath.textContent=this.projectRoot;this.projectPath.title=this.projectRoot;this.controls();
 }
 renderRows(){
  this.list.replaceChildren();const state=this.manager.read(),project=this.project();
  const key=exe=>exe?this.manager.key(exe):'',preferred=[this.selectedExe,project&&this.manager.choice(project.root),state.global].map(key);const row=preferred.map(exe=>this.rows.find(r=>key(r.exe)===exe)).find(Boolean)||this.rows.find(r=>r.ready)||this.rows[0];
  this.selectedExe=row?.exe||'';this.environmentSelect.replaceChildren(...this.rows.map(r=>this.option(r)));if(!row)this.environmentSelect.append(new Option(this.refreshing?'正在检测…':'未检测到环境',''));this.environmentSelect.value=this.selectedExe;this.environmentSelect.title=this.selectedExe;this.count.textContent=String(this.rows.length);this.count.setAttribute('aria-label',this.rows.length+' 个环境');
  if(row){
   const card=this.node('article','et-python-card'),head=this.node('div','et-python-card-head');head.append(this.node('strong','',row.error?'Python 不可用':'Python '+row.version+' · '+row.bits+' 位'));
   if(this.manager.key(state.global||this.manager.directory)===this.manager.key(row.exe))head.append(this.node('span','et-python-tag','全局默认'));
   if(project&&this.manager.key(state.projects[this.manager.key(project.root)]||this.manager.directory)===this.manager.key(row.exe))head.append(this.node('span','et-python-tag','当前项目'));
   const path=this.node('div','et-python-path',row.exe);path.title=row.exe;const hero=this.node('div','et-python-card-hero'),copy=this.node('div','et-python-card-copy');copy.append(head,path);hero.append(this.icon('python'),copy);card.append(hero);
   if(row.error)card.append(this.node('p','et-python-error',row.error));else{
    const packages=this.node('div','et-python-packages');for(const name of ETPythonManager.PACKAGES){const item=row.packages[name],badge=this.node('span','et-python-package',(item?.ok?'✓ ':'− ')+name);badge.dataset.ok=String(!!item?.ok);badge.title=item?.ok?(name+' '+(item.version||'可用')):(name+'：'+(item?.error||'未安装'));badge.setAttribute('aria-label',name+(item?.ok?' 已安装':' 缺少或异常'));packages.append(badge);}card.append(packages);
   }
   const actions=this.node('div','et-python-actions');
   const isGlobal=key(state.global)===key(row.exe),isProject=project&&key(state.projects[key(project.root)])===key(row.exe),global=this.button(isGlobal?'已设为全局默认':'设为全局默认',()=>this.setChoice(row.exe)),projectButton=this.button(isProject?'已用于当前项目':'用于当前项目',()=>this.setChoice(row.exe,true));global.dataset.unavailable=String(!!row.error||isGlobal);projectButton.dataset.unavailable=String(!!row.error||!project?.trusted||!!isProject);actions.append(global,projectButton);
   if(!row.error&&!row.ready)actions.append(this.button('补齐科研包',()=>this.repair(row.exe)));
   card.append(actions);this.list.append(card);
  }
  if(!this.rows.length)this.list.append(this.node('p','et-python-empty',this.refreshing?'正在检测 Python…':'未检测到 Python。可以选择已有环境，或一键安装。'));this.controls();
 }
 async refresh(fresh=false){
  if(this.refreshing||this.manager.busy)return;this.refreshing=true;this.refreshButton.setAttribute('aria-busy','true');const generation=++this.generation;if(fresh)this.manager.cache.clear();this.controls();this.renderRows();
  try{const rows=await this.manager.discover(this.trustedRoots());if(generation!==this.generation)return;this.rows=rows;this.renderChoices();}catch(e){this.notice(e.message,true);}finally{this.refreshing=false;this.refreshButton.removeAttribute('aria-busy');this.renderRows();}
 }
 async setChoice(exe,forProject=false){
  if(this.manager.busy||this.choosing)return;const project=forProject?this.project():null;if(forProject&&!project?.trusted){this.renderChoices();throw Error('请先在项目设置中信任此文件夹');}
  this.choosing=true;this.controls();try{await this.manager.select(exe,{project:project?.root});this.selectedExe=exe||this.manager.choice(project?.root);this.ai.toolbar.terminal.pythonEnvironmentChanged(project?.root);this.notice(forProject?'项目环境已保存，新终端生效':'全局默认已保存，新终端生效',false,true);}finally{this.choosing=false;this.renderChoices();this.renderRows();}
 }
 async browse(){const pick=await JSBridge.invoke('dialog.showOpenDialog',{title:'选择 Python 解释器',properties:['openFile'],filters:[{name:'Python 解释器',extensions:['exe']}]});const exe=pick?.filePaths?.[0];if(!exe)return;const row=await this.manager.inspect(exe,{fresh:true});this.manager.remember(exe);this.rows=[row,...this.rows.filter(r=>this.manager.key(r.exe)!==this.manager.key(exe))];this.selectedExe=row.exe;this.renderChoices();this.renderRows();this.notice(row.error||'已添加环境，请选择用途',!!row.error,!row.error);}
 report(text,output=false){if(output){this.log.hidden=false;this.log.textContent=(this.log.textContent+text).slice(-6000);this.log.scrollTop=this.log.scrollHeight;}else this.notice(text);this.controls();}
 async job(run){if(this.manager.busy||this.installing||this.refreshing)return;this.clearFeedback();this.scroll.scrollTop=0;this.installing=true;try{const pending=run();this.controls();const row=await pending;this.rows=[row,...this.rows.filter(r=>this.manager.key(r.exe)!==this.manager.key(row.exe))];this.selectedExe=row.exe;this.ai.toolbar.terminal.pythonEnvironmentChanged();this.clearFeedback();}catch(e){this.notice(e.message,e.name!=='AbortError');}finally{this.installing=false;this.renderChoices();this.renderRows();}}
 async install(){return this.job(()=>this.manager.install({roots:this.trustedRoots(),report:(...args)=>this.report(...args)}));}
 async repair(exe){return this.job(async()=>{const row=await this.manager.repair(exe,{report:(...args)=>this.report(...args)});this.notice('科研包已就绪');return row;});}
}
