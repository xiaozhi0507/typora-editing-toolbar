const TurndownService = require('turndown');
const {gfm} = require('turndown-plugin-gfm');
// Convert untrusted answer HTML in an inert document; no remote HTML is mounted.
function markdown(html){
  const doc=new DOMParser().parseFromString(String(html||''),'text/html');
  // Current website code cards may use a block-styled <code> without <pre>.
  // Normalize before Turndown collapses whitespace in inline code.
  for(const code of [...doc.querySelectorAll('code')]){
    if(code.closest('pre'))continue;
    const block=code.matches('[class*="whitespace-pre"],[style*="white-space: pre"],[style*="white-space:pre"]')||code.closest('[data-code-block],.code-block')||(/\n/.test(code.textContent)&&!code.closest('p,li,h1,h2,h3,h4,h5,h6'));
    if(!block)continue;
    const body=code.cloneNode(true);
    // Some code editors represent each source line with a separate element.
    const lines=body.querySelectorAll('.cm-line,[data-code-line]');
    const source=lines.length?[...lines].map(e=>e.textContent).join('\n'):body.textContent;
    let root=code;
    for(let parent=code.parentElement;parent&&parent!==doc.body;parent=parent.parentElement){
      if(parent.querySelectorAll('code').length!==1||parent.querySelector('p,h1,h2,h3,h4,h5,h6,ul,ol,table,blockquote'))break;
      const copy=parent.cloneNode(true);copy.querySelectorAll('code,button,svg').forEach(e=>e.remove());
      const label=copy.textContent.trim();
      if(/^(?:纯文本|Plain ?text|text|plaintext|[a-z][\w+#.-]{0,24})$/i.test(label))root=parent;
    }
    const pre=doc.createElement('pre'),clean=doc.createElement('code');clean.className=code.className;clean.textContent=source;pre.append(clean);root.replaceWith(pre);
  }
  // An assistant response supplies sections within a note, not its document title.
  // Public file mentions are buttons, not anchors, in the current website.
  for(const e of doc.querySelectorAll('[data-file-reference="true"],a[href^="sandbox:"]')){
    const name=e.getAttribute('data-markdown-copy-text')||e.textContent.match(/(?:^|\s)([^\s/\\]+\.zip)\s*$/i)?.[1];
    if(!name||/[\\/\r\n]/.test(name))continue;const a=doc.createElement('a');a.href='#et-web-file/'+encodeURIComponent(name);a.textContent=e.textContent.trim()||name;e.replaceWith(a);
  }
  for(const e of doc.querySelectorAll('[data-markdown-copy="inline-code"]')){const c=doc.createElement('code');c.textContent=e.textContent;e.replaceWith(c);}
  doc.querySelectorAll('h1').forEach(e=>{const h=doc.createElement('h2');h.append(...e.childNodes);e.replaceWith(h);});
  doc.querySelectorAll('script,style,iframe,object,embed,button,form,input,textarea').forEach(e=>e.remove());
  const math=new WeakMap();
  doc.querySelectorAll('.katex').forEach(e=>{const tex=e.querySelector('annotation[encoding="application/x-tex"]');if(tex){const display=!!e.closest('.katex-display'),node=doc.createElement(display?'div':'span');node.textContent='math';node.setAttribute('data-et-math','');math.set(node,display?'\n\n$$\n'+tex.textContent+'\n$$\n\n':'$'+tex.textContent+'$');(display?e.closest('.katex-display'):e).replaceWith(node);}});
  doc.querySelectorAll('a').forEach(e=>{try{const u=new URL(e.getAttribute('href'),'https://chatgpt.com');if(!['https:','http:'].includes(u.protocol)&&!e.getAttribute('href')?.startsWith('#'))e.removeAttribute('href');else if(!e.getAttribute('href').startsWith('#'))e.setAttribute('href',u.href);}catch{e.removeAttribute('href');}});
  doc.querySelectorAll('img').forEach(e=>{if(!/^https:\/\//i.test(e.getAttribute('src')||''))e.remove();});
  const service=new TurndownService({headingStyle:'atx',codeBlockStyle:'fenced',bulletListMarker:'-'});service.use(gfm);
  // Turndown clones nodes, so copy raw TeX into a lookup before converting.
  const formulas=[];doc.querySelectorAll('[data-et-math]').forEach(node=>{node.setAttribute('data-et-math',String(formulas.length));formulas.push(math.get(node));});
  service.addRule('math',{filter:node=>node.hasAttribute('data-et-math'),replacement:(_content,node)=>formulas[Number(node.getAttribute('data-et-math'))]||''});
  service.addRule('code',{filter:'pre',replacement:(_content,node)=>{const code=node.querySelector('code')||node,language=(code.className.match(/language-([\w+-]+)/)||[])[1]||'',body=code.textContent.replace(/\n$/,'');const fence='`'.repeat(Math.max(3,...[...body.matchAll(/`+/g)].map(m=>m[0].length+1)));return '\n\n'+fence+language+'\n'+body+'\n'+fence+'\n\n';}});
  return service.turndown(doc.body).trim();
}
module.exports={markdown};
