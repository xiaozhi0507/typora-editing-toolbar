const {test}=require('node:test'),assert=require('node:assert/strict'),path=require('node:path');
const {JSDOM}=require('jsdom'),build=require('esbuild').buildSync;
const bundle=name=>build({entryPoints:[path.join(__dirname,name)],bundle:true,format:'iife',globalName:'Module',platform:'browser',write:false}).outputFiles[0].text;
const format=bundle('ai-web-chat-format.js'),editor=bundle('annotation-live-editor.js');
function fixture(){const w=new JSDOM('<div id="preview"></div><div id="note"></div>',{runScripts:'outside-only',pretendToBeVisual:true}).window;w.eval(format+';window.format=Module');w.eval(editor+';window.editor=Module');return w;}

test('website block-styled code cards preserve newlines, indentation, Unicode diagrams and literal fences',()=>{
 const w=fixture(),source='  ┌─────────┐\n  │ RGB 图像 │\n  └────┬────┘\n       ↓\nLeaf A → 红色\nLeaf B → 蓝色\n```';
 const root=w.document.createElement('div');root.innerHTML='<h1>13. 从 NeRF 抠出点云</h1><div class="card"><div>纯文本<button>复制</button></div><div><code class="!whitespace-pre"></code></div></div><p>下文 <code>inline</code></p>';root.querySelector('code').textContent=source;
 const md=w.format.markdown(root.innerHTML);assert.ok(md.startsWith('## 13'));assert.ok(md.includes('````\n'+source+'\n````'));assert.ok(!md.includes('纯文本'));assert.ok(!md.includes('复制'));assert.ok(md.includes('`inline`'));
 w.editor.renderPreview(w.document.querySelector('#preview'),md,{});assert.equal(w.document.querySelector('pre code').textContent,source);assert.equal(w.document.querySelectorAll('#preview h1').length,0);w.close();
});

test('line-based code, ordinary pre blocks and inline-code prose remain separate',()=>{
 const w=fixture();const md=w.format.markdown('<div data-code-block><div>Plain text</div><code><div class="cm-line">one</div><div class="cm-line">  two</div><div class="cm-line"></div><div class="cm-line">three</div></code></div><p>Keep <code>a</code> and <code>b</code>.</p><pre><code class="language-python">x = 1\nprint(x)\n</code></pre>');
 assert.ok(md.includes('```\none\n  two\n\nthree\n```'));assert.ok(md.includes('Keep `a` and `b`.'));assert.ok(md.includes('```python\nx = 1\nprint(x)\n```'));w.close();
});

test('streamed previews retain completed blocks, code scroll, selection and rendered formulas',async()=>{
 const w=fixture(),host=w.document.querySelector('#preview');let calls=0;const options={minHeadingLevel:2,renderMath:async()=>{calls++;return '<span class="formula">x²</span>';}};
 const source='# Section\n\nStable paragraph\n\n```text\na\n  b\n```\n\n$$\nx^2\n$$\n\n';
 w.editor.renderPreview(host,source+'Streaming',options);await new Promise(r=>setImmediate(r));const heading=host.firstChild,paragraph=host.querySelector('p'),pre=host.querySelector('pre'),math=host.querySelector('.formula');pre.scrollLeft=42;
 const range=w.document.createRange();range.selectNodeContents(paragraph);w.getSelection().addRange(range);math.classList.add('in-text-selection');
 for(let i=1;i<=20;i++)w.editor.renderPreview(host,source+'Streaming '+i,options);
 await new Promise(r=>setImmediate(r));assert.equal(host.firstChild,heading);assert.equal(heading.tagName,'H2');assert.equal(host.querySelector('p'),paragraph);assert.equal(host.querySelector('pre'),pre);assert.equal(pre.scrollLeft,42);assert.equal(w.getSelection().toString(),'Stable paragraph');assert.equal(host.querySelector('.formula'),math);assert.equal(calls,1);assert.match(host.lastChild.textContent,/20$/);
 w.editor.renderPreview(host,'Short answer',{});assert.equal(host.children.length,1);assert.equal(host.textContent,'Short answer');w.close();
});

test('incremental renderer supports changed links, images and late math without restoring obsolete content',async()=>{
 const w=fixture(),host=w.document.querySelector('#preview');let resolve;const options={imageURL:src=>'https://example.com/'+src,renderMath:()=>new Promise(r=>resolve=r)};
 w.editor.renderPreview(host,'$x$\n\n[Link](https://example.com/a)\n\n![figure](a.png)',options);await Promise.resolve();
 w.editor.renderPreview(host,'[Changed](https://example.com/b)',options);resolve('<span>old formula</span>');await new Promise(r=>setImmediate(r));assert.equal(host.querySelector('a').href,'https://example.com/b');assert.ok(!host.textContent.includes('formula'));assert.equal(host.querySelector('img'),null);w.close();
});

test('dragging within a code block preserves selected lines without browser presentation styles',()=>{
 const w=fixture(),host=w.document.querySelector('#preview');w.editor.renderPreview(host,'```text\nLeaf A → 红色\n  Leaf B → 蓝色\nLeaf C\n```',{});
 const code=host.querySelector('code'),range=w.document.createRange();range.setStart(code.firstChild,0);range.setEnd(code.firstChild,27);w.getSelection().addRange(range);
 const data={},event=new w.Event('dragstart',{bubbles:true});Object.defineProperty(event,'dataTransfer',{value:{setData:(type,value)=>data[type]=value}});code.dispatchEvent(event);
 const fragment=w.document.createElement('div');fragment.innerHTML=data['text/html'];assert.equal(fragment.firstChild.tagName,'PRE');assert.equal(fragment.querySelector('code').textContent,range.toString());assert.match(fragment.textContent,/\n  Leaf B/);assert.ok(!fragment.querySelector('[style]'));assert.equal(data['text/plain'],range.toString());w.close();
});

test('dragging mixed answer blocks keeps heading level, paragraph boundaries and editable math',async()=>{
 const w=fixture(),host=w.document.querySelector('#preview');w.editor.renderPreview(host,'# Section\n\nParagraph\n\n$$\nx^2\n$$\n\nAfter',{minHeadingLevel:2,renderMath:async()=>'<svg><text>x²</text></svg>'});await new Promise(r=>setImmediate(r));
 const range=w.document.createRange();range.selectNodeContents(host);w.getSelection().addRange(range);const data={},event=new w.Event('dragstart',{bubbles:true});Object.defineProperty(event,'dataTransfer',{value:{setData:(type,value)=>data[type]=value}});host.querySelector('p').dispatchEvent(event);
 const fragment=w.document.createElement('div');fragment.innerHTML=data['text/html'];assert.equal(fragment.firstChild.tagName,'H2');assert.equal(fragment.querySelectorAll('p').length,2);assert.equal(fragment.querySelector('[data-note-math]').dataset.tex,'x^2');assert.equal(fragment.querySelector('svg'),null);w.close();
});
