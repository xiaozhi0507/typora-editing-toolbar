class EditingToolbarTerminal {
  constructor(toolbar){
    this.toolbar=toolbar;this.sessions=[];this.serial=0;this.key='et-terminal-v1';
    try{this.saved=JSON.parse(localStorage.getItem(this.key))||{};}catch{this.saved={};}
    this.mode=this.saved.layoutRevision===2&&this.saved.mode==='bottom'?'bottom':'float';this.height=Number(this.saved.height)||280;this.rect=this.saved.rect||{};this.interpreters=this.saved.interpreters||{};
    this.pythonManager=new ETPythonManager.Manager(reqnode,{storage:localStorage,legacy:this.interpreters,directory:reqnode('path').join(reqnode('process').env.LOCALAPPDATA||File.option.userDataPath,'TyporaEditingToolbar','python'),environment:ETTerminalEnvironment});
    window.addEventListener('storage',e=>{if(e.key===ETPythonManager.KEY)this.pythonEnvironmentChanged();});
    this.appearance={};for(const key of ['background','foreground','cursor'])if(/^#[0-9a-f]{6}$/i.test(this.saved.appearance?.[key]||''))this.appearance[key]=this.saved.appearance[key];
    this.appearance.fontSize=Math.max(10,Math.min(24,Number(this.saved.appearance?.fontSize)||12));this.appearance.uiFontSize=Math.max(10,Math.min(14,Number(this.saved.appearance?.uiFontSize)||11.5));this.appearance.cursorStyle=['bar','block','underline'].includes(this.saved.appearance?.cursorStyle)?this.saved.appearance.cursorStyle:'bar';
    document.addEventListener('keydown',e=>{if(e.ctrlKey&&e.altKey&&e.code==='KeyT'){e.preventDefault();e.stopImmediatePropagation();this.toggle();}},true);
    window.addEventListener('resize',()=>this.layout());
    window.addEventListener('optimizedResize',()=>this.layout());
    window.addEventListener('unload',()=>{this.pythonManager.cancel();this.flushAppearance();for(const s of this.sessions)s.backend?.stop();});
  }
  node(tag,cls='',text=''){const n=document.createElement(tag);n.className=cls;n.textContent=text;return n;}
  icon(name){const p={terminal:'M4 6l5 6-5 6m9 0h7',plus:'M12 5v14M5 12h14',close:'M6 6l12 12M18 6 6 18',hide:'M5 12h14',float:'M9 4h11v11M20 4 10 14M5 8H3v13h13v-2',dock:'M3 15h18M3 4h18v16H3z',expand:'M4 9V4h5M15 4h5v5M20 15v5h-5M9 20H4v-5',search:'M15.5 15.5 21 21m-3-11a7 7 0 1 1-14 0 7 7 0 0 1 14 0',clear:'m5 17 7-12 8 5-7 12H8zM3 22h18',folder:'M3 6h6l2 2h10v12H3z',stop:'M6 6h12v12H6z',up:'m6 15 6-6 6 6',down:'m6 9 6 6 6-6',copy:'M8 8h12v13H8zM16 8V3H3v13h5'}[name]||'';return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="'+p+'"/></svg>';}
  button(title,icon,fn){const b=this.node('button','et-term-icon');b.type='button';b.title=title;b.setAttribute('aria-label',title);b.innerHTML=this.icon(icon);b.onclick=fn;return b;}
  mount(){
    if(this.panel)return;
    const p=this.panel=this.node('section','et-terminal-panel');p.id='et-terminal-panel';p.hidden=true;p.setAttribute('aria-label','终端');
    this.head=this.node('header','et-term-head');const name=this.node('span','et-term-heading','终端');name.insertAdjacentHTML('afterbegin',this.icon('terminal'));this.head.append(name);
    this.tabs=this.node('div','et-term-tabs');this.tabs.setAttribute('role','tablist');this.tabs.setAttribute('aria-label','终端会话');
    this.newButton=this.button('新建终端','plus',()=>this.newSession());
    this.menuButton=this.button('选择终端与目录','down',()=>{this.menu.hidden=!this.menu.hidden;this.menuButton.setAttribute('aria-expanded',String(!this.menu.hidden));});this.menuButton.setAttribute('aria-expanded','false');
    const newGroup=this.node('div','et-term-new');newGroup.append(this.newButton,this.menuButton);
    const actions=this.node('div','et-term-actions');
    this.appearanceButton=this.button('终端样式','terminal',()=>this.showAppearance());this.appearanceButton.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="9"/><circle cx="8" cy="8" r="1"/><circle cx="15" cy="7" r="1"/><circle cx="17" cy="13" r="1"/><path d="M5 15h5l2 5"/></svg>';
    this.appearanceButton.classList.add('et-term-style-button');this.appearanceButton.append(this.node('span','','样式'));
    actions.append(this.appearanceButton,this.button('查找输出（Ctrl+F）','search',()=>this.showSearch()),this.button('关闭终端窗口（会话继续运行）','close',()=>this.hide()));
    this.head.append(this.tabs,newGroup,actions);
    this.menu=this.node('div','et-term-menu');this.menu.hidden=true;
    this.menu.append(this.node('strong','et-term-menu-title','新建会话'));const label=this.node('label','et-term-profile-row','命令行');this.profile=this.node('select');this.profile.setAttribute('aria-label','新终端类型');for(const [value,text]of [['powershell','PowerShell'],['cmd','命令提示符（CMD）']])this.profile.append(new Option(text,value));this.profile.value=this.saved.profile==='cmd'?'cmd':'powershell';this.profile.onchange=()=>this.persist();label.append(this.profile);this.menu.append(label);
    for(const [text,fn]of [['在当前项目目录新建',()=>this.newSession()],['在当前文件目录新建',()=>this.newSession({fileDirectory:true})],['选择文件夹新建…',()=>this.newSession({choose:true})]]){const b=this.node('button','et-term-menu-item',text);b.type='button';b.onclick=fn;this.menu.append(b);}
    const pythonSettings=this.node('button','et-term-menu-item','项目环境…');pythonSettings.type='button';pythonSettings.onclick=async()=>{this.menu.hidden=true;await this.toolbar.aiAssistant.open();this.toolbar.aiAssistant.settings(true,'python');};this.menu.append(pythonSettings);
    this.searchBar=this.node('div','et-term-search');this.searchBar.hidden=true;this.searchInput=this.node('input');this.searchInput.placeholder='查找终端输出';this.searchInput.setAttribute('aria-label','查找终端输出');this.searchInput.oninput=()=>this.find(false,true);this.searchInput.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();this.find(e.shiftKey);}if(e.key==='Escape'){e.preventDefault();this.searchBar.hidden=true;this.layout();this.focus();}};
    this.searchResult=this.node('span','et-term-search-result');this.searchBar.append(this.searchInput,this.searchResult,this.button('上一个','up',()=>this.find(true)),this.button('下一个','down',()=>this.find()),this.button('关闭查找','close',()=>{this.searchBar.hidden=true;this.layout();this.focus();}));
    this.frame=this.node('iframe','et-term-frame');this.frame.title='交互式终端';
    this.empty=this.node('div','et-term-empty');const emptyIcon=this.node('div','et-term-empty-icon');emptyIcon.innerHTML=this.icon('terminal');const create=this.node('button','et-term-create','新建终端');create.type='button';create.onclick=()=>this.newSession();this.empty.append(emptyIcon,this.node('strong','','在项目目录运行命令'),this.node('span','','项目 Python · PowerShell / CMD'),create);
    this.foot=this.node('footer','et-term-foot');this.stateLabel=this.node('span','et-term-state');this.cwdLabel=this.node('span','et-term-cwd');this.pythonLabel=this.node('span','et-term-python');this.sizeLabel=this.node('span','et-term-size');this.foot.append(this.stateLabel,this.cwdLabel,this.pythonLabel,this.sizeLabel);
    this.message=this.node('div','et-term-message');this.message.hidden=true;this.message.setAttribute('role','status');
    this.divider=this.node('div','et-term-divider');this.divider.tabIndex=0;this.divider.setAttribute('role','separator');this.divider.setAttribute('aria-label','调整终端高度');this.divider.setAttribute('aria-orientation','horizontal');
    this.resize=this.node('div','et-term-resize');this.resize.tabIndex=0;this.resize.setAttribute('role','separator');this.resize.setAttribute('aria-label','调整终端窗口大小');
    p.append(this.divider,this.head,this.menu,this.searchBar,this.message,this.frame,this.empty,this.foot,this.resize);document.body.append(p);
    this.context=this.node('div','et-term-menu et-term-context');this.context.hidden=true;this.context.setAttribute('role','menu');
    const clear=this.node('button','et-term-menu-item','Clear');clear.type='button';clear.setAttribute('role','menuitem');clear.onclick=()=>{this.active?.term.clearSelection();this.active?.term.clear();this.context.hidden=true;this.focus();};this.context.append(clear);p.append(this.context);
    this.context.onkeydown=e=>{if(e.key==='Escape'){e.preventDefault();this.context.hidden=true;this.focus();}};
    this.appearanceMenu=this.node('div','et-term-menu et-term-appearance');this.appearanceMenu.hidden=true;this.appearanceMenu.setAttribute('role','dialog');this.appearanceMenu.setAttribute('aria-label','终端样式');p.append(this.appearanceMenu);
    p.addEventListener('contextmenu',e=>{if(!e.target.closest('input,select'))this.contextMenu(e);});
    this.edges=[];for(const edge of ['n','s','e','w','ne','nw','sw']){const handle=this.node('div','et-term-edge');handle.dataset.edge=edge;handle.onpointerdown=e=>this.drag(e,edge);p.append(handle);this.edges.push(handle);}
    // Terminal keyboard input lives in its own document so Typora editing shortcuts cannot consume it.
    this.frameReady=new Promise(resolve=>{this.frame.onload=()=>{const w=this.frame.contentWindow;w.eval(ET_TERMINAL_VENDOR);this.vendor=w.ETTerminalVendor;w.document.addEventListener('contextmenu',e=>this.contextMenu(e,true),true);w.document.addEventListener('pointerdown',()=>{this.context.hidden=true;this.menu.hidden=true;this.appearanceMenu.hidden=true;},true);resolve();};});
    this.frame.srcdoc='<!doctype html><html><head><meta charset="utf-8"><style>'+ET_TERMINAL_CSS+'</style><style>html,body{margin:0;width:100%;height:100%;overflow:hidden}body{background:transparent}.session{position:absolute;inset:8px 10px 4px}.session[hidden]{display:none}.xterm{height:100%}.xterm-viewport{background:transparent!important}.xterm-viewport::-webkit-scrollbar{width:8px}.xterm-viewport::-webkit-scrollbar-thumb{background:#8885;border-radius:8px}</style></head><body></body></html>';
    this.observer=new ResizeObserver(()=>{if(p.hidden||this.resizeFrame)return;this.resizeFrame=requestAnimationFrame(()=>{this.resizeFrame=0;if(!p.hidden)this.layout();});});this.observer.observe(this.frame);for(const c of document.querySelectorAll('content'))this.observer.observe(c);
    this.themeObserver=new MutationObserver(()=>this.queueAppearance(false,false));this.themeObserver.observe(document.documentElement,{attributes:true,attributeFilter:['class','style','data-theme']});this.themeObserver.observe(document.body,{attributes:true,attributeFilter:['class','style']});
    const palette=document.getElementById('et-theme-palette-overrides');if(palette)this.themeObserver.observe(palette,{childList:true,subtree:true,characterData:true});
    document.addEventListener('load',e=>{if(e.target.tagName==='LINK')this.queueAppearance(false,false);},true);
    document.addEventListener('pointerdown',e=>{if(!this.menu.contains(e.target)&&!this.menuButton.contains(e.target))this.menu.hidden=true;if(!this.context.contains(e.target))this.context.hidden=true;if(!this.appearanceMenu.contains(e.target)&&!this.appearanceButton.contains(e.target))this.appearanceMenu.hidden=true;},true);
    for(const type of ['keydown','keypress','keyup','mousedown','click','paste','wheel'])p.addEventListener(type,e=>e.stopPropagation());
    this.head.title='拖动移动窗口 · 双击最大化或还原 · 窗口下边缘靠近底部时吸附';this.head.tabIndex=0;
    const titleTarget=e=>!e.target.closest('button,select,input');
    this.head.addEventListener('pointerdown',e=>{if(titleTarget(e))this.drag(e,'move');});
    this.head.ondblclick=e=>{if(titleTarget(e)){e.preventDefault();this.toggleMaximize();}};
    this.head.onkeydown=e=>{if(e.target===this.head&&e.key==='Enter'){e.preventDefault();this.toggleMaximize();}};
    this.divider.onpointerdown=e=>this.drag(e,'height');this.resize.onpointerdown=e=>this.drag(e,'se');
    this.divider.onkeydown=e=>{if(['ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();this.height+=e.key==='ArrowUp'?20:-20;this.maximized=false;this.layout();this.persist();}};
    this.resize.onkeydown=e=>{if(e.key.startsWith('Arrow')){e.preventDefault();this.rect.width=(this.rect.width||600)+(e.key==='ArrowRight'?20:e.key==='ArrowLeft'?-20:0);this.rect.height=(this.rect.height||320)+(e.key==='ArrowDown'?20:e.key==='ArrowUp'?-20:0);this.layout();this.persist();}};
  }
  async toggle(){this.mount();if(!this.panel.hidden){this.hide();return;}this.panel.hidden=false;this.layout();if(!this.sessions.length)await this.newSession();else this.focus();}
  async openFloatingAt(x,y){
    this.mount();this.cancelDrag?.();this.mode='float';this.maximized=false;this.rect={...this.rect,left:x-60,top:y-18};this.panel.hidden=false;this.layout();this.persist();if(!this.sessions.length&&!this.creating)await this.newSession();else this.focus();
  }
  hide(){if(!this.panel)return;this.cancelDrag?.();this.panel.hidden=true;this.menu.hidden=true;this.context.hidden=true;this.appearanceMenu.hidden=true;this.applyInset(0);this.rightReservation=0;this.toolbar.panelWorkspace?.scheduleLayout();document.querySelector('#editing-toolbar-top [data-action="terminal"]')?.focus({preventScroll:true});}
  async directory(choose=false,fileDirectory=false){
    const path=reqnode('path'),file=File.bundle?.filePath;
    if(!choose){if(fileDirectory&&file&&path.isAbsolute(file))return path.dirname(file);const cwd=ETTerminalEnvironment.projectDirectory(reqnode,this.toolbar.documentTabs?.projects,file);if(cwd)return cwd;}
    const pick=await JSBridge.invoke('dialog.showOpenDialog',{title:'选择终端工作目录',properties:['openDirectory']});return pick?.filePaths?.[0]||null;
  }
  async newProjectSession(){const projects=this.toolbar.documentTabs?.projects,project=projects?.active();if(!project){this.notice('请先在侧栏选择一个本地项目');return;}if(!project.trusted){this.notice('请先在项目设置中信任此文件夹');return;}await this.newSession({cwd:project.root});}
  pythonOverride(root){return this.pythonManager?this.pythonManager.choice(root):this.interpreters?.[reqnode('path').resolve(root).toLowerCase()]||'';}
  pythonEnvironmentChanged(root){this.toolbar.notebook?.projectEnvironmentChanged(root);}
  async choosePython(reset=false,{cwd,startSession=true}={}){
    if(this.menu)this.menu.hidden=true;
    try{cwd=cwd||this.active?.cwd||await this.directory();if(!cwd)return;const projects=this.toolbar.documentTabs?.projects;projects?.read();const owner=ETCodeWorkspace.owner(reqnode,projects?.items,reqnode('path').join(cwd,'__python_context__'));cwd=owner?.root||cwd;const key=reqnode('path').resolve(cwd).toLowerCase();
      let exe='';if(!reset){const pick=await JSBridge.invoke('dialog.showOpenDialog',{title:'选择此目录的 Python 解释器',properties:['openFile'],filters:[{name:'Python 解释器',extensions:['exe']}]});exe=pick?.filePaths?.[0];if(!exe)return;await ETTerminalEnvironment.pythonEnvironment(reqnode,cwd,exe);}
      if(this.pythonManager)await this.pythonManager.select(exe,{project:cwd});else{if(exe)this.interpreters[key]=exe;else delete this.interpreters[key];this.persist();}this.pythonEnvironmentChanged(cwd);if(startSession)await this.newSession({cwd,pythonRoot:cwd});
    }catch(error){this.notice(error.message);}
  }
  async newSession({choose=false,cwd,fileDirectory=false,deferStart=false,ai=false,pythonRoot,focus=true}={}){
    this.mount();this.menu.hidden=true;if(this.creating)return;this.creating=true;this.sessionReady=new Promise(resolve=>{this.resolveSessionReady=resolve;});this.newButton.disabled=true;let created;
    try{
      if(this.sessions.length>=8)throw Error('最多同时保留 8 个会话，请先关闭一个会话');
      cwd=cwd||await this.directory(choose,fileDirectory);if(!cwd)return;
      const owner=ETCodeWorkspace.owner(reqnode,this.toolbar.documentTabs?.projects?.items,reqnode('path').join(pythonRoot||cwd,'__python_context__'));
      const environmentRoot=pythonRoot||owner?.root||cwd;
      const python=await ETTerminalEnvironment.pythonEnvironment(reqnode,environmentRoot,this.pythonOverride(environmentRoot));
      this.panel.hidden=false;this.notice('');this.layout();await this.frameReady;
      const s=created={id:++this.serial,profile:ai?'powershell':this.profile.value,cwd,python,ai};s.name=ai?'AI 执行 '+s.id:(s.profile==='cmd'?'CMD':'PowerShell')+' '+s.id;
      const doc=this.frame.contentDocument;s.host=doc.createElement('div');s.host.className='session';doc.body.append(s.host);
      s.term=new this.vendor.Terminal({fontFamily:'Cascadia Mono, Consolas, Microsoft YaHei, monospace',fontSize:this.appearance.fontSize,lineHeight:1.12,scrollback:5000,cursorBlink:true,cursorStyle:'bar',allowProposedApi:false,minimumContrastRatio:4.5,convertEol:false,windowsPty:{backend:'conpty',buildNumber:Number(reqnode('os').release().split('.')[2])||19045}});
      s.fit=new this.vendor.FitAddon();s.search=new this.vendor.SearchAddon();s.term.loadAddon(s.fit);s.term.loadAddon(s.search);s.term.open(s.host);
      s.term.attachCustomKeyEventHandler(e=>{if(e.type!=='keydown')return true;if(e.ctrlKey&&e.altKey&&e.code==='KeyT'){e.preventDefault();this.toggle();return false;}if(e.ctrlKey&&(e.key.toLowerCase()==='f')&&!e.altKey){e.preventDefault();this.showSearch();return false;}if(e.ctrlKey&&e.shiftKey&&e.code==='KeyC'){e.preventDefault();this.copySelection();return false;}return true;});
      s.term.onData(text=>{if(!s.ai)s.backend?.write(text);});s.term.onResize(({cols,rows})=>{if(!s.ai)s.backend?.resize(cols,rows);this.status();});
      // No OSC 52 clipboard writes or shell-controlled HTML/link handlers are installed.
      s.backend=new ETTerminalSession.TerminalSession(reqnode,{onData:(data,ack)=>s.term.write(new this.frame.contentWindow.Uint8Array(data),ack),onError:error=>{s.error=error.message;this.notice(error.message);this.renderTabs();},onState:()=>{this.renderTabs();this.status();}});
      this.sessions.push(s);this.select(s,{focus});this.syncTheme();
      if(deferStart){s.term.options.disableStdin=true;return s;}
      const host=reqnode('path').join(this.moduleRoot,'assets','editing-toolbar.terminal.exe');
      await s.backend.start({host,profile:s.profile,cwd,cols:s.term.cols,rows:s.term.rows,environment:ETTerminalEnvironment.environmentVariables(reqnode('process').env,python)});if(focus)this.focus();return s;
    }catch(error){if(created?.backend){created.error=error.message;created.backend.stop();if(created.backend.state==='idle')created.backend.ended(-1);}this.notice(error.message);if(ai)throw error;}finally{this.creating=false;this.newButton.disabled=false;this.renderTabs();this.status();this.resolveSessionReady?.();this.resolveSessionReady=null;}
  }
  async executeCommand(args,prepared){
    if(this.creating)await this.sessionReady;
    if(prepared.signal?.aborted)throw ETAIShell.abort();
    for(const old of [...this.sessions])if(old.ai&&old.backend.state==='exited')this.closeSession(old);
    const s=await this.newSession({cwd:prepared.cwd,pythonRoot:prepared.root,deferStart:true,ai:true,focus:false});if(!s)throw Error('终端正在创建会话，请稍后重试');
    const controller=new AbortController(),abort=()=>controller.abort();prepared.signal?.addEventListener('abort',abort,{once:true});s.cancel=abort;if(prepared.signal?.aborted)abort();
    s.transcript=new ETTerminalTranscript.TerminalTranscript(s.term,{connected:()=>s.host.isConnected});
    const render=state=>{prepared.onUpdate(state);s.transcript.update('> '+state.command+'\n\n'+state.output);};
    try{return await new ETTerminalCommand.TerminalCommand(reqnode,s.backend,ETAIShell).run(args,{...prepared,signal:controller.signal,host:reqnode('path').join(this.moduleRoot,'assets','editing-toolbar.terminal.exe'),env:ETTerminalEnvironment.environmentVariables(prepared.env,s.python),onUpdate:render});}
    finally{prepared.signal?.removeEventListener('abort',abort);s.cancel=null;await s.transcript.flush();this.status();this.renderTabs();}
  }
  select(s,{focus=true}={}){this.active=s;for(const other of this.sessions)other.host.hidden=other!==s;this.notice(s.error||'');this.renderTabs();this.status();this.layout();requestAnimationFrame(()=>{this.tabs.querySelector('.active')?.scrollIntoView({block:'nearest',inline:'nearest'});this.fit();if(focus)this.focus();});}
  renderTabs(){
    if(!this.tabs)return;this.tabs.replaceChildren();this.empty.hidden=!!this.sessions.length;this.frame.hidden=!this.sessions.length;
    for(const s of this.sessions){const row=this.node('div','et-term-tab'+(this.active===s?' active':''));const b=this.node('button','et-term-tab-select',s.name);b.type='button';b.setAttribute('role','tab');b.setAttribute('aria-selected',String(s===this.active));b.tabIndex=s===this.active?0:-1;b.title=s.name+' · '+s.cwd+(s.backend.state==='exited'?' · 已退出':'');b.onclick=()=>this.select(s);b.onkeydown=e=>{if(['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();const i=this.sessions.indexOf(s),next=this.sessions[(i+(e.key==='ArrowRight'?1:this.sessions.length-1))%this.sessions.length];this.select(next);this.tabs.querySelector('[aria-selected="true"]')?.focus();}};
      const dot=this.node('i','et-term-dot');dot.dataset.state=s.backend.state;b.prepend(dot);const close=this.button('终止并关闭 '+s.name,'close',()=>this.closeSession(s));close.classList.add('et-term-tab-close');row.append(b,close);this.tabs.append(row);}
  }
  closeSession(s){s.cancel?.();s.transcript?.dispose();s.backend.options.onData=(data,ack)=>ack();s.backend.stop();s.term.dispose();s.host.remove();this.sessions=this.sessions.filter(x=>x!==s);if(this.active===s)this.active=this.sessions.at(-1);if(this.active)this.select(this.active);else{this.notice('');this.renderTabs();this.status();this.newButton.focus();}}
  focus(){if(!this.panel?.hidden)this.active?.term.focus();}
  fit(){
    if(this.moveGesture||this.sizeGesture||this.panel?.hidden||!this.active)return;
    const s=this.active,o=s.term.options,w=this.frame?.clientWidth,h=this.frame?.clientHeight;
    if(!w||!h)return;const key=[w,h,o.fontFamily,o.fontSize,o.lineHeight,o.letterSpacing].join('|');
    // Content and iframe resize observers can report the same size on adjacent frames.
    if(s.fitSize===key)return;try{s.fit.fit();s.fitSize=key;}catch{}this.status();
  }
  status(){if(!this.stateLabel)return;const s=this.active;this.stateLabel.textContent=!s?'无会话':s.error?'启动或连接异常':s.backend.state==='exited'?'已退出 · '+s.backend.exitCode:s.backend.state==='starting'?'启动中…':'运行中';this.cwdLabel.textContent=s?s.cwd:'新会话从当前项目目录开始';this.cwdLabel.title='初始目录 · '+this.cwdLabel.textContent;this.pythonLabel.textContent=s?(s.python?.label||'未检测到 Python'):'';this.pythonLabel.title=s?.python?.exe||'自动检测项目 Python 环境；未检测到时使用系统命令行';this.sizeLabel.textContent=s?s.term.cols+' × '+s.term.rows:'';}
  contextMenu(e,inFrame=false){e.preventDefault();e.stopImmediatePropagation();if(!this.active)return;this.menu.hidden=true;this.appearanceMenu.hidden=true;const p=this.panel.getBoundingClientRect(),f=inFrame?this.frame.getBoundingClientRect():{left:0,top:0};this.context.hidden=false;this.context.style.left=Math.max(4,Math.min(e.clientX+f.left-p.left,p.width-this.context.offsetWidth-4))+'px';this.context.style.top=Math.max(4,Math.min(e.clientY+f.top-p.top,p.height-this.context.offsetHeight-4))+'px';this.context.firstElementChild.focus();}
  toggleMaximize(){if(this.maximized){this.maximized=false;this.mode=this.restoreMode||'float';}else{this.restoreMode=this.mode;this.mode='float';this.maximized=true;}this.layout();this.persist();this.focus();}
  notice(text){this.message.textContent=text;this.message.hidden=!text;this.layout();}
  showSearch(){if(!this.active)return;this.searchBar.hidden=!this.searchBar.hidden;this.layout();if(!this.searchBar.hidden){this.searchInput.focus();this.searchInput.select();}else this.focus();}
  find(previous=false,incremental=false){const q=this.searchInput.value;if(!q){this.active?.search.clearDecorations();this.searchResult.textContent='';return;}const found=this.active?.search[previous?'findPrevious':'findNext'](q,{incremental});this.searchResult.textContent=found?'':'未找到';}
  copySelection(){const value=this.active?.term.getSelection();if(value)reqnode('electron').clipboard.writeText(value);}
  colorHex(value){
    const text=String(value||'').trim().replace(/^#/,'');
    if(/^[\da-f]{6}$/i.test(text))return '#'+text.toLowerCase();
    if(/^[\da-f]{3}$/i.test(text))return '#'+[...text].map(c=>c+c).join('').toLowerCase();
    return null;
  }
  queueAppearance(metrics=false,save=true){
    this.appearanceMetrics=!!this.appearanceMetrics||metrics;this.appearanceSave=!!this.appearanceSave||save;
    if(!this.appearanceFrame)this.appearanceFrame=requestAnimationFrame(()=>this.flushAppearance());
  }
  flushAppearance(){
    if(!this.appearanceFrame&&!this.appearanceMetrics&&!this.appearanceSave)return;
    cancelAnimationFrame(this.appearanceFrame);this.appearanceFrame=0;
    const metrics=this.appearanceMetrics,save=this.appearanceSave;this.appearanceMetrics=this.appearanceSave=false;
    this.syncTheme();if(metrics)this.fit();if(save)this.persist();
  }
  showAppearance(){
    const menu=this.appearanceMenu;if(!menu.hidden){menu.hidden=true;return;}this.menu.hidden=true;this.context.hidden=true;menu.replaceChildren();
    const heading=this.node('div','et-term-style-heading');heading.append(this.node('strong','','终端样式'),this.button('关闭样式设置','close',()=>{menu.hidden=true;this.appearanceButton.focus();}));menu.append(heading);
    const tabs=this.node('div','et-term-style-tabs');tabs.setAttribute('role','tablist');tabs.setAttribute('aria-label','样式分类');
    const colors=this.node('div','et-term-style-page'),type=this.node('div','et-term-style-page');
    const pages=[['colors','配色',colors],['type','字号与光标',type]],tabButtons=[];
    const showTab=key=>{this.appearanceTab=key;pages.forEach(([id,,page],i)=>{page.hidden=id!==key;tabButtons[i].setAttribute('aria-selected',String(id===key));tabButtons[i].tabIndex=id===key?0:-1;});};
    pages.forEach(([id,title,page],i)=>{const b=this.node('button','',title);b.type='button';b.id='et-term-style-tab-'+id;b.setAttribute('role','tab');b.setAttribute('aria-controls','et-term-style-page-'+id);page.id='et-term-style-page-'+id;page.setAttribute('role','tabpanel');page.setAttribute('aria-labelledby',b.id);b.onclick=()=>showTab(id);b.onkeydown=e=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();const next=e.key==='Home'?0:e.key==='End'?1:1-i;showTab(pages[next][0]);tabButtons[next].focus();}};tabButtons.push(b);tabs.append(b);});menu.append(tabs,colors,type);
    const asHex=value=>this.colorHex(value)||('#'+(String(value).match(/\d+/g)||[32,32,32]).slice(0,3).map(v=>Math.max(0,Math.min(255,Number(v))).toString(16).padStart(2,'0')).join(''));
    const fallback=this.active?.term.options.theme||{},style=getComputedStyle(this.panel);
    const valueOf=key=>asHex(this.appearance[key]||fallback[key]||(key==='background'?style.backgroundColor:style.color));
    const fields=[],presets=[],cursorButtons=[];let swatches;
    const refresh=()=>{for(const f of fields){f.input.value=valueOf(f.key).toUpperCase();f.input.removeAttribute('aria-invalid');f.row.classList.remove('invalid');f.swatch.style.backgroundColor=valueOf(f.key);f.palette.hidden=true;f.swatch.setAttribute('aria-expanded','false');}for(const [b,p]of presets)b.setAttribute('aria-pressed',String(Object.entries(p).every(([k,v])=>valueOf(k)===v)));for(const [b,v]of cursorButtons)b.setAttribute('aria-pressed',String(v===this.appearance.cursorStyle));};
    const strip=this.node('div','et-term-presets');strip.setAttribute('aria-label','终端配色预设');
    for(const [title,background,foreground,cursor]of [['深色','#242422','#ecebe8','#e3a480'],['浅色','#faf9f6','#302f2b','#b86647'],['纸张','#f4eee2','#453f34','#936442']]){const p={background,foreground,cursor},b=this.node('button','et-term-preset');b.type='button';b.title=title+'配色';b.setAttribute('aria-label',b.title);const sample=this.node('span','et-term-preset-sample','Aa');sample.style.backgroundColor=background;sample.style.color=foreground;b.append(sample,this.node('span','',title));b.onclick=()=>{Object.assign(this.appearance,p);refresh();this.queueAppearance();};presets.push([b,p]);strip.append(b);}colors.append(strip);
    for(const [key,title]of [['background','背景颜色'],['foreground','字体颜色'],['cursor','光标颜色']]){
      const row=this.node('div','et-term-hex-row'),label=this.node('label','',title),control=this.node('div','et-term-hex-control'),input=this.node('input'),swatch=this.node('button','et-term-color-swatch'),palette=this.node('div','et-term-swatches'),error=this.node('span','et-term-hex-error','请输入 3 位或 6 位十六进制颜色');
      input.type='text';input.id='et-term-hex-'+key;label.htmlFor=input.id;input.setAttribute('aria-label',title+'十六进制');input.setAttribute('aria-describedby',input.id+'-error');input.maxLength=7;input.spellcheck=false;input.autocomplete='off';input.placeholder='#RRGGBB';error.id=input.id+'-error';
      swatch.type='button';swatch.title=title+'色板';swatch.setAttribute('aria-label',swatch.title);swatch.setAttribute('aria-expanded','false');palette.setAttribute('role','group');palette.setAttribute('aria-label',title+'常用颜色');
      swatch.onclick=()=>{const open=palette.hidden;for(const f of fields){f.palette.hidden=true;f.swatch.setAttribute('aria-expanded','false');}palette.hidden=!open;swatch.setAttribute('aria-expanded',String(open));swatches=open?{palette,swatch}:null;};
      const apply=(value,commit)=>{const color=this.colorHex(value),valid=!!color;input.setAttribute('aria-invalid',String(commit&&!valid));row.classList.toggle('invalid',commit&&!valid);if(!valid)return false;this.appearance[key]=color;swatch.style.backgroundColor=color;if(commit)input.value=color.toUpperCase();for(const [b]of presets)b.setAttribute('aria-pressed','false');this.queueAppearance();return true;};
      input.oninput=()=>{row.classList.remove('invalid');input.removeAttribute('aria-invalid');if(/^#?[\da-f]{6}$/i.test(input.value.trim()))apply(input.value,false);};
      input.onchange=()=>apply(input.value,true);input.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();apply(input.value,true);}else if(e.key==='Escape'){e.preventDefault();e.stopPropagation();input.value=valueOf(key).toUpperCase();input.removeAttribute('aria-invalid');row.classList.remove('invalid');}};
      for(const color of ['#ffffff','#faf9f6','#f4eee2','#d5d5d0','#242422','#000000','#b86647','#e3a480','#7da88a','#80a7db','#c599d4','#ecebe8']){const b=this.node('button');b.type='button';b.style.backgroundColor=color;b.title=color.toUpperCase();b.setAttribute('aria-label',title+' '+color.toUpperCase());b.onclick=()=>{apply(color,true);palette.hidden=true;swatch.setAttribute('aria-expanded','false');swatches=null;swatch.focus();};palette.append(b);}
      control.append(swatch,input);row.append(label,control,error,palette);colors.append(row);fields.push({key,input,row,swatch,palette});
    }
    const numbers=[];
    const fontRow=(key,title,min,max,fallback)=>{
      const row=this.node('div','et-term-font-row'),label=this.node('label','',title),control=this.node('div','et-term-stepper'),number=this.node('input');number.type='number';number.min=min;number.max=max;number.step=.5;number.value=this.appearance[key];number.setAttribute('aria-label',title);number.id='et-term-'+key;label.htmlFor=number.id;numbers.push([number,key]);
      const apply=value=>{this.appearance[key]=Math.round(Math.max(min,Math.min(max,value))*2)/2;number.value=this.appearance[key];this.queueAppearance(true);};
      number.oninput=()=>{if(number.value!==''&&Number(number.value)>=min&&Number(number.value)<=max)apply(Number(number.value));};number.onchange=()=>apply(Number(number.value)||fallback);
      const less=this.button('减小'+title,'hide',()=>apply(this.appearance[key]-.5)),more=this.button('增大'+title,'plus',()=>apply(this.appearance[key]+.5));control.append(less,number,more);row.append(label,control);type.append(row);
    };
    fontRow('fontSize','终端字号',10,24,12);fontRow('uiFontSize','界面字号',10,14,11.5);
    const cursorRow=this.node('div','et-term-cursor-row'),cursorGroup=this.node('div','et-term-cursors');cursorGroup.setAttribute('role','group');cursorGroup.setAttribute('aria-label','光标形状');cursorRow.append(this.node('span','','光标形状'),cursorGroup);
    for(const [value,title]of [['bar','竖线'],['block','方块'],['underline','下划线']]){const b=this.node('button','',title);b.type='button';b.setAttribute('aria-label',title+'光标');b.onclick=()=>{this.appearance.cursorStyle=value;for(const [other,v]of cursorButtons)other.setAttribute('aria-pressed',String(v===value));this.queueAppearance();};cursorButtons.push([b,value]);cursorGroup.append(b);}type.append(cursorRow);
    const reset=this.node('button','et-term-style-reset','恢复默认 · 跟随软件主题');reset.type='button';reset.onclick=()=>{this.appearance={fontSize:12,uiFontSize:11.5,cursorStyle:'bar'};this.queueAppearance(true);this.flushAppearance();for(const key of ['background','foreground','cursor'])fallback[key]=this.active?.term.options.theme?.[key]||'';for(const [n,k]of numbers)n.value=this.appearance[k];refresh();};menu.append(reset);
    menu.onkeydown=e=>{if(e.key==='Escape'){e.preventDefault();if(swatches&&!swatches.palette.hidden){swatches.palette.hidden=true;swatches.swatch.setAttribute('aria-expanded','false');swatches.swatch.focus();swatches=null;}else{menu.hidden=true;this.appearanceButton.focus();}}};
    refresh();showTab(this.appearanceTab==='type'?'type':'colors');menu.hidden=false;
  }
  syncTheme(){
    if(!this.panel)return;
    const a=this.appearance,chromeKey=[a.uiFontSize,a.background,a.foreground].join('|');
    if(this.chromeThemeKey!==chromeKey){this.chromeThemeKey=chromeKey;this.panel.style.setProperty('--et-term-ui-size',a.uiFontSize+'px');this.panel.style.backgroundColor=a.background||'';this.panel.style.color=a.foreground||'';}
    const style=getComputedStyle(this.panel),bg=style.backgroundColor,fg=style.color,frameKey=bg+'|'+fg;
    const doc=this.frame?.contentDocument;if(doc?.body&&(this.frameThemeKey!==frameKey||this.themeDocument!==doc)){this.frameThemeKey=frameKey;this.themeDocument=doc;this.panel.style.setProperty('--et-term-bg',bg);doc.documentElement.style.backgroundColor=bg;doc.body.style.backgroundColor=bg;doc.body.style.color=fg;}
    for(const s of this.sessions){
      // Font options trigger xterm measurement; color-only edits must not touch them.
      for(const [k,v]of Object.entries({fontFamily:'Cascadia Mono, Consolas, Microsoft YaHei, monospace',fontSize:a.fontSize,cursorStyle:a.cursorStyle,minimumContrastRatio:a.foreground?1:4.5}))if(s.term.options[k]!==v)s.term.options[k]=v;
      const key=frameKey+'|'+a.cursor;if(s.themeKey===key)continue;s.themeKey=key;s.term.options.theme={background:bg,foreground:fg,cursor:a.cursor||fg,selectionBackground:'#b4846555',black:'#333333',red:'#b64a48',green:'#4f8059',yellow:'#a17736',blue:'#5c85b8',magenta:'#9979b2',cyan:'#4d939d',white:'#d6d6d6',brightBlack:'#818181',brightRed:'#e36f6c',brightGreen:'#80b18a',brightYellow:'#d4b16a',brightBlue:'#8eade4',brightMagenta:'#c49ed5',brightCyan:'#81bdc7',brightWhite:'#ffffff'};
    }
  }
  applyInset(height){
    if(!this.insets)this.toolbar.splitView?.restore();
    if(!this.insets)this.insets=[...document.querySelectorAll('content')].map(node=>({node,value:node.style.getPropertyValue('bottom'),priority:node.style.getPropertyPriority('bottom'),base:parseFloat(getComputedStyle(node).bottom)||24}));
    for(const i of this.insets){const v=height?(height+i.base)+'px':i.value;if(i.node.style.getPropertyValue('bottom')!==v){if(v)i.node.style.setProperty('bottom',v,height?'important':i.priority);else i.node.style.removeProperty('bottom');}}
  }
  layout(fromWorkspace=false){
    if(!this.panel||this.layingOut||this.moveGesture)return;this.layingOut=true;
    try{
      if(this.panel.hidden){this.applyInset(0);this.rightReservation=0;return;}
      const W=innerWidth,H=innerHeight,bottom=24,maxH=Math.max(150,H-160),dock=this.toolbar.panelWorkspace?.dockWidth()||0;
      const content=document.querySelector('content'),left=this.toolbar.panelWorkspace?.documentLeft?.()??Math.max(0,Math.min(content?.getBoundingClientRect().left||0,W-280));
      let r;this.rightReservation=0;
      if(this.mode==='bottom'){
        const height=this.maximized?maxH:Math.min(maxH,Math.max(160,this.height));this.height=this.maximized?this.height:height;
        r={left,top:H-bottom-height,width:Math.max(0,W-left-dock),height};this.applyInset(height);
      }else{
        this.applyInset(0);r=this.maximized?{left:8,top:52,width:W-16,height:H-84}:{left:Number(this.rect.left)||Math.max(12,left+24),top:Number(this.rect.top)||Math.max(60,H-380),width:Number(this.rect.width)||Math.min(640,W-32),height:Number(this.rect.height)||310};
        r.width=Math.min(W-16,Math.max(300,r.width));r.height=Math.min(H-50,Math.max(190,r.height));r.left=Math.max(8,Math.min(r.left,W-r.width-8));r.top=Math.max(8,Math.min(r.top,H-r.height-24));if(!this.maximized)this.rect={...r};
      }
      for(const k of ['left','top','width','height'])if(this.panel.style[k]!==r[k]+'px')this.panel.style[k]=r[k]+'px';
      this.panel.dataset.mode=this.mode;this.panel.dataset.maximized=String(!!this.maximized);this.panel.dataset.narrow=String(r.width<480);this.menuButton.setAttribute('aria-expanded',String(!this.menu.hidden));
      if(!this.toolbar.panelWorkspace?.liveResize())this.syncTheme();this.fit();
    }finally{this.layingOut=false;}
    if(!fromWorkspace)this.toolbar.panelWorkspace?.scheduleLayout();
  }
  persist(){try{localStorage.setItem(this.key,JSON.stringify({layoutRevision:2,mode:this.maximized?this.restoreMode:this.mode,height:this.height,rect:this.rect,profile:this.profile?.value||'powershell',interpreters:this.interpreters,appearance:this.appearance}));}catch{}}
  drag(e,kind){
    if(e.button!==0||(this.maximized&&kind!=='move'))return;
    this.cancelDrag?.();const start=this.panel.getBoundingClientRect(),x=e.clientX,y=e.clientY,W=innerWidth,H=innerHeight;
    const saved={mode:this.mode,maximized:this.maximized,rect:{...this.rect},height:this.height};
    let origin={left:start.left,top:start.top,width:start.width,height:start.height},base={...origin},next={...origin};
    let shield,preview,frame=0,latest={x,y},moved=false,ended=false,snap=false,snapArmed=saved.mode!=='bottom'&&!saved.maximized;
    const capture=e.currentTarget||e.target;capture.setPointerCapture(e.pointerId);
    const paint=()=>{
      frame=0;if(!moved||ended)return;const dx=latest.x-x,dy=latest.y-y;
      if(kind==='move'){
        const raw={...origin,left:origin.left+dx,top:origin.top+dy};
        next={...raw,left:Math.max(8,Math.min(raw.left,W-raw.width-8)),top:Math.max(8,Math.min(raw.top,H-raw.height-24))};
        // Pure position changes belong to the compositor. Do not refit xterm,
        // change editor insets, read geometry, or rebuild workspace layout here.
        this.panel.style.transform='translate3d('+(next.left-base.left)+'px,'+(next.top-base.top)+'px,0)';
        const lowerEdge=raw.top+raw.height,bottom=H-24;
        if(!snapArmed&&lowerEdge<bottom-24)snapArmed=true;
        const shouldSnap=snapArmed&&lowerEdge>=bottom-16&&raw.left<W&&raw.left+raw.width>0;
        if(snap!==shouldSnap){snap=shouldSnap;preview.hidden=!snap;}
        return;
      }
      if(kind==='height')this.height=start.height-dy;
      else{
        const minW=Math.min(300,W-16),minH=Math.min(190,H-50),r={...origin};
        if(kind.includes('e'))r.width=Math.max(minW,Math.min(W-origin.left-8,origin.width+dx));
        if(kind.includes('s'))r.height=Math.max(minH,Math.min(H-origin.top-24,origin.height+dy));
        if(kind.includes('w')){r.left=Math.max(8,Math.min(origin.left+dx,origin.left+origin.width-minW));r.width=origin.left+origin.width-r.left;}
        if(kind.includes('n')){r.top=Math.max(8,Math.min(origin.top+dy,origin.top+origin.height-minH));r.height=origin.top+origin.height-r.top;}
        this.rect=r;
      }
      this.layout();
    };
    const activate=()=>{
      moved=true;this.menu.hidden=true;this.context.hidden=true;this.appearanceMenu.hidden=true;
      shield=this.node('div','et-term-drag-shield');shield.style.cursor=kind==='move'?'move':kind==='height'?'ns-resize':({n:'ns',s:'ns',e:'ew',w:'ew',ne:'nesw',sw:'nesw',nw:'nwse',se:'nwse'}[kind]+'-resize');document.body.append(shield);
      if(kind==='move'){
        if(saved.maximized||saved.mode==='bottom'){
          const width=Math.min(W-16,Math.max(300,Number(saved.rect.width)||640)),height=Math.min(H-50,Math.max(190,Number(saved.rect.height)||310));
          origin={left:x-Math.min(width-24,Math.max(24,(x-start.left)/start.width*width)),top:y-Math.min(24,y-start.top),width,height};
          this.mode='float';this.maximized=false;this.rect={...origin};this.layout();base={...this.rect};
        }
        const left=Math.max(0,document.querySelector('content')?.getBoundingClientRect().left||0),dock=this.toolbar.panelWorkspace?.dockWidth()||0;
        preview=this.node('div','et-term-snap-preview','松开以停靠到底部');preview.hidden=true;
        Object.assign(preview.style,{left:left+'px',width:Math.max(0,W-left-dock)+'px',height:Math.min(Math.max(150,H-160),Math.max(160,this.height))+'px'});document.body.append(preview);
        this.moveGesture=true;this.panel.classList.add('et-term-moving');
      }else this.sizeGesture=true;
      shield.tabIndex=-1;shield.focus({preventScroll:true});
    };
    const move=v=>{
      if(v.pointerId!==e.pointerId||ended)return;latest={x:v.clientX,y:v.clientY};
      if(!moved&&Math.hypot(latest.x-x,latest.y-y)<4)return;
      v.preventDefault();if(!moved)activate();if(!frame)frame=requestAnimationFrame(paint);
    };
    const finish=cancel=>{
      if(ended)return;cancelAnimationFrame(frame);frame=0;if(moved&&!cancel)paint();ended=true;
      window.removeEventListener('pointermove',move,true);window.removeEventListener('pointerup',up,true);window.removeEventListener('pointercancel',abort,true);window.removeEventListener('blur',blur);window.removeEventListener('resize',abort);window.removeEventListener('keydown',key,true);capture.removeEventListener('lostpointercapture',abort);
      try{capture.releasePointerCapture(e.pointerId);}catch{}shield?.remove();preview?.remove();this.cancelDrag=null;
      this.moveGesture=false;this.sizeGesture=false;this.panel.classList.remove('et-term-moving');this.panel.style.transform='';
      if(!moved)return;
      if(cancel)Object.assign(this,saved);
      else if(kind==='move'){this.rect=next;if(snap){this.mode='bottom';this.maximized=false;this.rect=saved.rect;}}
      this.layout();this.persist();this.focus();
    };
    const up=v=>{if(v.pointerId===e.pointerId){latest={x:v.clientX,y:v.clientY};finish(false);}},abort=()=>finish(true),blur=()=>{if(!document.hasFocus())finish(true);},key=v=>{if(v.key==='Escape'){v.preventDefault();v.stopImmediatePropagation();finish(true);}};
    this.cancelDrag=abort;window.addEventListener('pointermove',move,true);window.addEventListener('pointerup',up,true);window.addEventListener('pointercancel',abort,true);window.addEventListener('blur',blur);window.addEventListener('resize',abort);window.addEventListener('keydown',key,true);capture.addEventListener('lostpointercapture',abort);
  }
}
