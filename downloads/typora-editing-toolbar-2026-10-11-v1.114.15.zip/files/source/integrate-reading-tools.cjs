const fs=require('fs'),path=require('path');
module.exports=code=>{
 const esbuild=require(require.resolve('esbuild',{paths:[__dirname,path.join(__dirname,'annotation-editor-deps')]}));
 const nodePaths=[path.join(__dirname,'annotation-editor-deps/node_modules'),path.join(__dirname,'node_modules'),...(process.env.NODE_PATH||'').split(path.delimiter).filter(Boolean)];
 const ui=esbuild.buildSync({entryPoints:[path.join(__dirname,'research-sidebar.js')],bundle:true,write:false,format:'iife',globalName:'ETResearchSidebar',platform:'browser',minify:true,nodePaths}).outputFiles[0].text;
 const worker=esbuild.buildSync({entryPoints:[path.join(__dirname,'research-note-index.js')],bundle:true,write:false,format:'iife',platform:'browser',minify:true,nodePaths}).outputFiles[0].text;
 const from='this.researchMaterials=new EditingToolbarResearchMaterials(this);';if(!code.includes(from))throw Error('Missing reading tools init');
 code=code.replace(from,from+'this.chapterMinimap=new EditingToolbarChapterMinimap(this);this.readingPosition=new EditingToolbarReadingPosition(this);this.tableColumns=new EditingToolbarTableColumns(this);this.centerCaptions=new EditingToolbarCenterCaptions(this);this.markdownLinks=new EditingToolbarMarkdownLinks(this);this.imageScale=new EditingToolbarImageScale(this);this.citationPreview=new EditingToolbarCitationPreview(this);this.researchSidebar=new ETResearchSidebar.ResearchSidebar(this,ETResearchIndexWorkerSource);this.documentTabs=new EditingToolbarDocumentTabs(this);');
 // Native zoom accepts fractional percentages; avoid visible 1% jumps on release.
 const zoom='Math.round((width / (naturalWidth || width)) * 100)';if(!code.includes(zoom))throw Error('Missing native image zoom');
 code=code.replace(zoom,'Math.round((width / (naturalWidth || width)) * 10000) / 100');
 const pos=code.lastIndexOf('(function () {');if(pos<0)throw Error('Missing reading tools boot');
 return code.slice(0,pos)+ui+'\nconst ETResearchIndexWorkerSource='+JSON.stringify(worker)+';\n'+'const ETDocumentProjects=(()=>{const module={exports:{}};'+fs.readFileSync(path.join(__dirname,'document-projects.cjs'),'utf8')+';return module.exports;})();\n'.replace('\\n','\n')+'const ETIllustratorLauncher=(()=>{const module={exports:{}};'+fs.readFileSync(path.join(__dirname,'illustrator-launcher.cjs'),'utf8')+';return module.exports;})();\n'+['document-open-pipe.js','document-open-router.js','document-tabs.js','chapter-minimap.js','smooth-image-resize.js','body-reading-position.js','body-table-columns.js','body-center-captions.js','body-markdown-links.js','body-image-scale.js','body-xref-links.js','body-xref-media.js','body-citation-preview.js'].map(f=>fs.readFileSync(path.join(__dirname,f),'utf8')).join('\n')+'\n'+code.slice(pos);
};
