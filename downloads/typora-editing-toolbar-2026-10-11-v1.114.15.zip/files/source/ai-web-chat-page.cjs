'use strict';
// Runs inside the sandboxed guest. Read visible DOM and operate ordinary controls only.
// Never access cookies, tokens, framework stores or private HTTP endpoints.
async function webChatPage(action, args = {}) {
  let styleCache=new WeakMap();const style=e=>{if(!styleCache.has(e))styleCache.set(e,getComputedStyle(e));return styleCache.get(e);};
  const visible = e => {
    if(!e||e.closest('[hidden],[aria-hidden="true"],[inert],[role="menu"][data-state="closed"],[role="listbox"][data-state="closed"]'))return false;
    for(let p=e;p;p=p.parentElement){const s=style(p);if(s.display==='none'||s.visibility==='hidden'||s.visibility==='collapse')return false;}
    return e.getBoundingClientRect().height>0||(style(e).display==='contents'&&[...e.children].some(visible));
  };
  const all = (s, root = document) => [...root.querySelectorAll(s)].filter(visible);
  const text = e => String(e?.innerText || e?.textContent || '').trim();
  const label = e => (e?.getAttribute('aria-label') || (e?.getAttribute('aria-labelledby')||'').split(/\s+/).map(id=>text(document.getElementById(id))).filter(Boolean).join(' ') || text(e)).trim();
  const disabled = e => !e || e.disabled || e.getAttribute('aria-disabled') === 'true';
  const button = (re, root = document) => all('button,[role="button"]', root).find(e => re.test(label(e)));
  const editor = () => all('#prompt-textarea,#mobile-composer-prompt,textarea[placeholder],textarea[aria-label],[contenteditable="true"][role="textbox"],[contenteditable="true"].ProseMirror')[0];
  const uploadInputs = files => {
    const root=editor()?.closest('form')||document;
    const accepts=(input,file)=>!input.accept.trim()||input.accept.toLowerCase().split(',').map(t=>t.trim()).some(t=>t===file.type.toLowerCase()||(t.startsWith('.')&&file.name.toLowerCase().endsWith(t))||(t.endsWith('/*')&&file.type.toLowerCase().startsWith(t.slice(0,-1))));
    return [...root.querySelectorAll('input[type="file"]')].filter(e=>!e.hasAttribute('capture')&&!inMessage(e)&&files.every(f=>accepts(e,f)));
  };
  const uploadInput = files => uploadInputs(files).find(e=>!disabled(e)&&!e.matches(':disabled'));
  const plainText = value => String(value ?? '').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ');
  // Chromium innerText counts an empty editable div as two line breaks;
  // ProseMirror paragraphs also add visual spacing. Read logical editor lines
  // so blank lines and code indentation survive without collapsing whitespace.
  const draftText = e => {
    if(!e)return '';
    if(e.tagName==='TEXTAREA')return plainText(e.value);
    const read = node => {
      if(node.nodeType===3)return node.nodeValue;
      if(node.nodeType!==1)return '';
      if(node.tagName==='BR')return node.classList.contains('ProseMirror-trailingBreak')?'':'\n';
      const children=[...node.childNodes];
      if(children.length===1&&children[0].nodeName==='BR')return '';
      let out='',previousBlock=false;
      children.forEach((child,i)=>{const block=child.nodeType===1&&/^(P|DIV|PRE)$/.test(child.tagName);if(i&&(block||previousBlock))out+='\n';out+=read(child);previousBlock=block;});
      return out;
    };
    return plainText(read(e));
  };
  const sendButton = () => all('[data-testid="send-button"],[data-composer-submit]')[0] || button(/^(发送(消息)?|Send( message| prompt)?)$/i);
  const stopButton = () => all('[data-testid="stop-button"]')[0] || button(/^(停止(生成|流式传输|回答)?|Stop( generating| streaming| response)?)$/i);
  const inMessage = e => e.closest('[data-message-author-role],[data-message-role],[data-turn-role],[data-content-search-unit-key],[data-user-message-bubble],[data-markdown-text-style="assistant-message"],article[data-testid^="conversation-turn"]');
  const challengePresent = () => {
    // Challenge text lives in a cross-origin frame. Inspect only its public
    // element/URL, never its document, response tokens or verification controls.
    const frame = all('iframe').some(e => {
      if(inMessage(e))return false;
      const r=e.getBoundingClientRect();if(r.width<80||r.height<40)return false;
      for(let p=e;p;p=p.parentElement){const s=getComputedStyle(p);if(s.display==='none'||s.visibility==='hidden'||s.opacity==='0')return false;}
      try{const u=new URL(e.getAttribute('src'),location.href);return u.protocol==='https:'&&u.hostname==='challenges.cloudflare.com'&&/^\/(?:cdn-cgi\/challenge-platform|turnstile)\//.test(u.pathname);}catch{return false;}
    });
    if(frame)return true;
    // A discussion or chat title about verification must not block a working
    // composer. Invisible background widgets also do not indicate a challenge.
    if(editor())return false;
    if(all('#challenge-form,#cf-challenge-running').some(e=>!inMessage(e)))return true;
    const title=/^(?:just a moment|checking your browser|请稍候)(?:[.!…\s-]|$)/i.test(document.title);
    const prompt=all('h1,h2,p,[role="alert"]').filter(e=>!inMessage(e)).some(e=>/^(?:verify you are human|verifying|checking your browser|验证您是人类|请完成验证|正在验证)(?:[.!…\s，。]|$)/i.test(text(e)));
    return title||prompt;
  };
  const controls = () => all('button,[role="button"]').filter(e => !inMessage(e));
  const modes = /^(Instant|Medium|High|Extra High|(?:(?:GPT[- ]?)?\d+(?:\.\d+)?\s*)?Pro|即时|中|高|极高)$/i;
  const versionLabel = /^(?:Latest|GPT[- ]\d[^\n]*|\d+(?:\.\d+)?(?:[ -](?:Sol|Astra|Luna|Terra))?)$/i;
  const modelLabel = {test:name=>versionLabel.test(name)||/^(Pro|Auto|Thinking|Instant)$/i.test(name)};
  const cleanLabel = e => {
    // The version title is separate from its check icon and retirement note.
    // Reading the whole row can prefix Latest with an accessible icon title.
    const row=e?.querySelector('[data-menu-row-content="true"]');
    const title=row&&all('span',row).find(s=>!s.querySelector('span')&&!s.closest('svg')&&text(s));
    const name=text(title||e).split('\n')[0].trim().replace(/[›⌄⌃]$/,'').trim();
    return /^(最新|最新版本)$/i.test(name)?'Latest':name;
  };
  // The composer displays the current mode (including bare "Pro") while idle.
  // Its descriptive "thinking intensity" label may appear only on hover.
  const modeTrigger = () => all('[data-codex-intelligence-trigger],[data-composer-navigation-target="reasoning"]')[0] || controls().find(e => /^(思考强度|思考程度|思考|Thinking( intensity| effort)?|Reasoning( effort)?)$/i.test(label(e))) || controls().find(e => (modes.test(cleanLabel(e))||/^Pro$/i.test(cleanLabel(e))) && !e.closest('[role="menu"],[role="listbox"],[popover]:popover-open'));
  const versionTrigger = () => all('[data-testid="model-switcher-dropdown-button"]')[0] || controls().find(e => modelLabel.test(cleanLabel(e)) && !e.closest('[role="menu"],[role="listbox"],[popover]:popover-open'));
  // Octane exposes a focusable menuitem for keyboard input; its visual thumb is
  // aria-hidden. Read that control's public range metadata, focus the menuitem.
  const slider = () => all('[data-reasoning-slider="true"],[role="slider"],input[type="range"]').find(e => !inMessage(e));
  const sliderRange = e => e?.matches('[data-reasoning-slider]') ? e.querySelector('[role="slider"]') : e;
  const sliderLabel = e => {
    const described = (e?.getAttribute('aria-describedby')||'').split(/\s+/).map(id=>text(document.getElementById(id))).join(' ');
    // The announcement may include a version prefix: "5.6 Extra High，第 4 项…".
    // Keep Pro's version, but expose ordinary effort names independently.
    const announced=described.split(/[,，]/)[0].trim(),effort=announced.match(/(?:^|\s)(Instant|Medium|High|Extra High)$/i);
    return effort?.[1] || (modes.test(announced)?announced:'');
  };
  const value = e => Number(e?.getAttribute('aria-valuenow') ?? e?.value);
  const selected = e => ['aria-checked','aria-selected','data-model-selected','data-state'].some(k => ['true','checked'].includes(e.getAttribute(k))) || !!e.querySelector('[data-state="checked"],[data-testid*="check"],svg.lucide-check');
  const wait = ms => new Promise(r => setTimeout(()=>{styleCache=new WeakMap();r();}, ms));
  const popupOptions = () => all('[role="menuitemradio"],[role="option"],[role="menuitem"]')
    .filter(e => !inMessage(e)).map(e => ({label:cleanLabel(e),selected:selected(e),disabled:disabled(e)}));
  const state = () => {
    const s=slider(), range=sliderRange(s), mt=modeTrigger(), vt=versionTrigger(), options=popupOptions();
    const popup=s?.closest('[role="dialog"],[role="menu"],[popover]') || s?.parentElement?.parentElement;
    const modeText=sliderLabel(s) || range?.getAttribute('aria-valuetext') || (popup&&all('button,span,div',popup).filter(e=>!inMessage(e)).map(cleanLabel).find(t=>modes.test(t))) || options.find(o=>o.selected&&modes.test(o.label))?.label || (mt&&modes.test(cleanLabel(mt))?cleanLabel(mt):'');
    const mode=({'即时':'Instant','中':'Medium','高':'High','极高':'Extra High'})[modeText]||modeText||'';
    return {mode,version:options.find(o=>o.selected&&modelLabel.test(o.label))?.label||cleanLabel(vt),options,
      slider:s&&range?{min:Number(range.getAttribute('aria-valuemin')??range.min??0),max:Number(range.getAttribute('aria-valuemax')??range.max??0),value:value(range),native:s.tagName==='INPUT',label:modeText||''}:null};
  };
  const messageSelector = role => `[data-message-author-role="${role}"],[data-message-role="${role}"],[data-turn-role="${role}"],[data-content-search-unit-key$=":${role}"],[data-chatgpt-search-unit-key$=":${role}"]`;
  const processSelector='[data-testid="reasoning"],[data-testid="reasoning-content"],[data-agent-activity],[data-message-channel="analysis"],[data-message-channel="commentary"]';
  const messageNodes = role => {
    const marked=[...document.querySelectorAll(messageSelector(role))].filter(e=>visible(e)||(!e.closest('[hidden],[aria-hidden="true"],[inert]')&&all('[data-user-message-bubble],[data-markdown-text-style="assistant-message"],.markdown',e).length));
    const fallback=all(role==='user'?'[data-user-message-bubble]':'[data-chatgpt-selection-message-id]').filter(e=>!e.closest(processSelector)&&(role==='user'||e.querySelector('[data-markdown-text-style="assistant-message"]')));
    const rows=[...new Set([...marked,...fallback])].sort((a,b)=>a.compareDocumentPosition(b)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1);
    return rows.filter((e,i)=>!rows.some((p,j)=>j!==i&&p.contains(e)));
  };
  const messageId = e => e?.getAttribute('data-message-id')||e?.getAttribute('data-content-search-unit-key')||e?.getAttribute('data-chatgpt-selection-message-id')||e?.id||'';
  const userText = e => {
    if(!e)return '';const copy=(e.querySelector('[data-user-message-bubble]')||e).cloneNode(true);
    // Message controls and attachment chips are not part of the submitted text.
    copy.querySelectorAll('button,[role="button"],script,style,svg,[data-file-reference],[data-message-actions],[hidden],[aria-hidden="true"]').forEach(n=>n.remove());
    return draftText(copy).trim();
  };
  const normalizedMessage = value => plainText(value).normalize('NFC').replace(/[\u200b\ufeff]/g,'').replace(/\s+/g,' ').trim();
  const expandUser = user => {
    // Some layouts put Show more beside the content unit, inside the same turn.
    // Do not search another message or the whole conversation for a control.
    for(let root=user;root&&root!==document.body&&root.tagName!=='MAIN';root=root.parentElement){
      if([...root.querySelectorAll(messageSelector('user')+','+messageSelector('assistant'))].some(e=>e!==user&&!user.contains(e)&&!e.contains(user)))break;
      const b=button(/^(显示更多(?:内容)?|展开(?:消息|全文|内容)?|Show more(?: text)?|Read more)$/i,root);if(b)return b;
    }
    return null;
  };
  const answerCopy = last => {
    // New website layouts put the action bar beside the content unit. Search
    // its enclosing turn, but never borrow an older answer's completion button.
    for(let root=last;root&&root!==document.body;root=root.parentElement){
      if([...messageNodes('assistant'),...messageNodes('user').filter(e=>last.compareDocumentPosition(e)&Node.DOCUMENT_POSITION_FOLLOWING)].some(e=>root.contains(e)&&e!==last&&!last.contains(e)&&!e.contains(last)))break;
      const copy=all('button,[role="button"]',root).find(e=>!e.closest('pre,code,'+processSelector)&&!e.closest(messageSelector('user'))&&(e.getAttribute('data-testid')==='copy-turn-action-button'||/^(复制(回答|回复|响应|消息)?|Copy( response| answer| message)?)$/i.test(label(e))));if(copy)return copy;
    }
    return null;
  };
  // Scope removal to the current composer; never operate chat-history controls.
  const removeButtons = (root,ed) => [...root.querySelectorAll('button,[role="button"]')].filter(b=>!ed?.contains(b)&&!inMessage(b)&&/^(?:Remove|Delete)\b|^(?:移除|删除)(?=[\s“”"'‘’「『（(]|图片|图像|附件|文件|$)/i.test(b.getAttribute('aria-label')||b.title||text(b))&&(visible(b)||(b.closest('[data-composer-attachments]')&&visible(b.parentElement))));
  const composerRoot = ed => ed?.closest('form')||ed?.parentElement?.parentElement?.parentElement;
  const writeDraft = (e,value) => {
    e.focus();if(e.tagName==='TEXTAREA'){Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set.call(e,value);e.dispatchEvent(new Event('input',{bubbles:true}));}
    else {const selection=getSelection(),range=document.createRange();range.selectNodeContents(e);selection.removeAllRanges();selection.addRange(range);if(!document.execCommand(value?'insertText':'delete',false,value))throw Error('网页输入框未接受文字，请打开网页检查');}
  };
  const composerAttachments = (form,ed) => {
    if(!form)return {composerText:'',composerImages:[],uploadBusy:false};
    // The draft itself is not upload evidence. Images often expose their file
    // name only through alt/title, or show a thumbnail with a remove button.
    const copy=form.cloneNode(true);
    copy.querySelectorAll('textarea,[contenteditable="true"],[hidden],[aria-hidden="true"],script,style').forEach(e=>e.remove());
    const composerText=[...copy.querySelectorAll('*')].filter(e=>!e.children.length).map(text).filter(Boolean).join('\n');
    // The current site says 移除“filename”, and may hide the close control
    // until hover. Its visible attachment card remains upload evidence.
    const composerImages=all('img',form).filter(img=>{
      if(inMessage(img)||ed?.contains(img))return false;
      for(let root=img.parentElement;root&&root!==form;root=root.parentElement){
        if(ed&&root.contains(ed))break;
        if(removeButtons(root,ed).length)return true;
      }
      return false;
    }).map(img=>({names:[img.getAttribute('alt'),img.getAttribute('title'),img.getAttribute('aria-label')].filter(Boolean),ready:img.complete&&img.naturalWidth>0}));
    const composerAttachmentCount=removeButtons(form,ed).length;
    const composerHasAttachments=!!(composerImages.length||composerAttachmentCount||all('[data-composer-attachments]',form).some(root=>text(root)||all('img,button,[role="button"],[role="progressbar"]',root).length));
    return {composerText,composerImages,composerAttachmentCount,composerHasAttachments,uploadBusy:composerImages.some(i=>!i.ready)||!!all('[role="progressbar"],[aria-busy="true"]',form).length};
  };

  const activityRoots=()=>{
    const user=messageNodes('user').at(-1);if(!user)return [];
    const after=e=>!!(user.compareDocumentPosition(e)&Node.DOCUMENT_POSITION_FOLLOWING)&&!e.closest(messageSelector('user'));
    const roots=[...document.querySelectorAll('[data-chatgpt-agent-turn-start],[data-testid="reasoning"],[data-testid="reasoning-content"],[data-testid="reasoning-summary"],[data-testid="reasoning-summary-button"],[data-agent-activity]')].filter(after).flatMap(e=>{
      if(!e.hasAttribute('data-chatgpt-agent-turn-start'))return [e];
      const root=e.parentElement;
      // The turn-start marker can share a parent with the final answer. Only
      // its activity branches belong to progress; never exclude the whole turn.
      const final=messageNodes('assistant').filter(n=>root.contains(n));
      if(!final.length)return [root];
      const branches=node=>[...node.children].flatMap(child=>final.some(n=>child===n)?[]:final.some(n=>child.contains(n))?branches(child):[child]);
      return branches(root);
    });
    // Ordinary chats can expose just a public disclosure/status outside an
    // agent-activity wrapper. Its visible caption is enough for live feedback.
    // Read an explicitly controlled visible panel, never a whole answer parent.
    for(const e of all('button[aria-expanded],summary,[role="status"]')){
      if(!after(e)||e.closest('nav,aside,form')||e.closest('.markdown,[data-markdown-text-style="assistant-message"],pre,code'))continue;
      const publicStatus=e.matches('[role="status"]')&&!!e.closest(messageSelector('assistant'));
      if(!publicStatus&&!/^(?:正在思考|思考中|思考了|已思考|正在分析|正在推理|Thinking\b|Thought for\b|Reasoning\b)/i.test(label(e)))continue;
      roots.push(e);
      for(const id of (e.getAttribute('aria-controls')||'').split(/\s+/)){
        const panel=id&&document.getElementById(id);
        if(panel&&visible(panel)&&after(panel)&&!panel.contains(user)&&!panel.querySelector(messageSelector('user')+','+messageSelector('assistant')))roots.push(panel);
      }
      if(e.tagName==='SUMMARY'&&e.parentElement?.tagName==='DETAILS'&&e.parentElement.open)roots.push(e.parentElement);
    }
    return [...new Set(roots)].filter((e,i,rows)=>!rows.some((p,j)=>j!==i&&p.contains(e)));
  };
  const activity=()=>activityRoots().flatMap(root=>{
    const nodes=[],block='p,h1,h2,h3,h4,h5,h6,pre,table,ul,ol,blockquote',rich='strong,b,em,i,code,a,pre,table,ul,ol,blockquote,math,.katex,img,br';
    const walk=e=>{
      if(!visible(e)||e.matches('script,style,svg,form,input,textarea'))return;
      if(e.matches('button,[role="button"]')&&/^(复制(回答|回复|响应|消息)?|Copy( response| answer| message)?)$/i.test(label(e)))return;
      const header=e.matches('[class~="group/activity-header"],summary,[role="status"],button[aria-expanded]');
      if(header&&!e.querySelector('.markdown,[data-markdown-text-style]')){nodes.push(e);return;}
      if(e.matches(block)){nodes.push(e);return;}
      const children=[...e.children].filter(visible);
      if(!children.length||children.every(c=>/^(SPAN|STRONG|B|EM|I|CODE|A|BR|SVG)$/.test(c.tagName))){if(text(e))nodes.push(e);return;}
      for(const child of children)walk(child);
    };walk(root);
    return nodes.map(e=>{
      const copy=e.cloneNode(true);
      // Styles/hidden descendants must not leak through cloning and textContent.
      const originals=[...e.querySelectorAll('*')],clones=[...copy.querySelectorAll('*')];
      originals.forEach((node,i)=>{if(!node.closest('.katex')&&!visible(node))clones[i]?.remove();});
      copy.querySelectorAll('[hidden],[aria-hidden="true"],script,style,svg').forEach(n=>n.remove());
      for(const button of copy.querySelectorAll('button:not([data-file-reference]),[role="button"]:not([data-file-reference])')){const caption=text(button);if(/^(复制|重试|显示更多|Copy|Retry|Show more)$/i.test(caption))button.remove();else button.replaceWith(document.createTextNode(caption));}
      const value=text(copy),short=value.length<=80&&!/[\n。！？.!?：:；;]/.test(value)&&!copy.matches(rich)&&!copy.querySelector(rich);
      const step=e.matches('[class~="group/activity-header"],summary,[role="status"],button[aria-expanded]')||short||/^Used (?:container|python) tool$/i.test(value),name=/搜索|search|browse|网页/i.test(value)?'web_search':/container|python|terminal|代码|命令|脚本|解压|打包/i.test(value)?'run_shell_command':'reasoning';
      return {kind:step?'step':'commentary',name,text:value.slice(0,16000),...(step?{}:{html:copy.outerHTML.slice(0,100000)})};
    }).filter(row=>row.text);
  }).filter((row,i,rows)=>!i||row.text!==rows[i-1].text).slice(0,300).map((row,i)=>({id:'web-activity:'+i,...row}));
  const snapshot = () => {
    const users=messageNodes('user'),user=users.at(-1),answers=messageNodes('assistant'),last=answers.at(-1);
    const processRoots=activityRoots(),rich='[data-markdown-text-style="assistant-message"],.markdown,[data-message-content],.prose';
    const candidates=last?all(rich,last).filter(e=>!e.closest(processSelector)&&!processRoots.some(root=>root.contains(e)||e.contains(root))):[];
    const blocks=candidates.filter((e,i)=>!candidates.some((p,j)=>j!==i&&p.contains(e)));
    const cleanAnswer=e=>{
      const clone=e.cloneNode(true),originals=[...e.querySelectorAll('*')],copies=[...clone.querySelectorAll('*')];
      originals.forEach((n,i)=>{if(!n.closest('.katex')&&!visible(n))copies[i]?.remove();});
      clone.querySelectorAll('[hidden],[aria-hidden="true"],script,style,button:not([data-file-reference]),pre [role="button"],'+processSelector).forEach(n=>n.remove());
      return clone.innerHTML;
    };
    const answerHTML=blocks.length?blocks.map(cleanAnswer).join('\n'):last&&!last.closest(processSelector)&&!processRoots.some(root=>last.contains(root)||root.contains(last))?cleanAnswer(last):'';
    const copy=last&&answerCopy(last);
    const connectionText=all('main p,main span,main div').filter(e=>!e.childElementCount&&/^(?:连接已中断|Connection (?:lost|interrupted))(?:[，,。.\s]|$)/i.test(text(e)));
    const currentNotices=[...new Set([...all('[role="alert"],[role="status"],[data-conversation-recovery]'),...connectionText])].filter(e=>!e.closest(messageSelector('user'))&&(!user||user.compareDocumentPosition(e)&Node.DOCUMENT_POSITION_FOLLOWING));
    const failure=currentNotices.filter(e=>e.matches('[role="alert"],[data-conversation-recovery]')).map(text).filter(t=>/error|failed|limit|出错|失败|上限|达到|错误|无法建立连接|connection/i.test(t)).join('\n').slice(0,1200);
    const login=!!controls().find(e=>/^(登录|Log in|Sign in)$/i.test(label(e)));
    const challenge=challengePresent();
    const ed=editor(),form=composerRoot(ed);
    const mt=modeTrigger();
    const historyLoading=all('main [aria-busy="true"],main [role="progressbar"],[data-testid="conversation-loading"]').some(e=>!inMessage(e)&&!form?.contains(e));
    const disconnected=currentNotices.some(e=>/连接已中断|connection (?:lost|interrupted)/i.test(text(e)));
    return {url:location.href,login,challenge,ready:!!ed&&!login&&!challenge,modeReady:!!mt&&!disabled(mt),busy:!!stopButton(),historyLoading,disconnected,error:failure,
      draft:draftText(ed),sendReady:!disabled(sendButton()),userCount:users.length,answerCount:answers.length,
      lastUser:userText(user),lastUserId:messageId(user),lastUserCollapsed:!!expandUser(user),
      replyAfterUser:!!(user&&last&&(user.compareDocumentPosition(last)&Node.DOCUMENT_POSITION_FOLLOWING)),
      answerId:last?.getAttribute('data-message-id')||last?.getAttribute('data-chatgpt-selection-message-id')||last?.querySelector('[data-chatgpt-selection-message-id]')?.getAttribute('data-chatgpt-selection-message-id')||last?.id||'',answerHTML,activity:args.progress?activity():[],complete:!!copy&&!stopButton(),
      ...composerAttachments(form,ed),...state()};
  };
  const sameConversation = (left,right) => {
    try{const a=new URL(left),b=new URL(right),id=u=>u.pathname.match(/^\/(?:g\/[\w-]+\/)?c\/([\w-]+)\/?$/)?.[1];
      if(a.origin!=='https://chatgpt.com'||b.origin!==a.origin)return false;
      return id(b)?id(a)===id(b):a.pathname.replace(/\/$/,'')===b.pathname.replace(/\/$/,'');
    }catch{return false;}
  };
  const matchesConversation = (s,expected) => (!expected.url||sameConversation(s.url,expected.url))&&(expected.userCount===undefined||s.userCount===expected.userCount)&&(!expected.lastUserId||s.lastUserId===expected.lastUserId);
  if(['clear-composer','prepare','upload-ready','upload','send'].includes(action)&&!matchesConversation(snapshot(),args))throw Error('网页会话发生变化，未发送，也未清理当前草稿');
  if(action==='snapshot'){
    if(args.expectedText&&!challengePresent()){
      const user=messageNodes('user').at(-1);
      if(user&&!(args.bound&&args.userId&&messageId(user)===args.userId)&&normalizedMessage(userText(user))!==normalizedMessage(args.expectedText)){
        const expand=expandUser(user);
        if(expand&&!disabled(expand)){expand.click();await wait(100);}
      }
    }
    if(args.progress&&!challengePresent())for(const root of activityRoots()){
      const toggle=all('[class~="group/activity-header"] button[aria-expanded="false"],summary',root).find(e=>e.tagName!=='SUMMARY'||!e.parentElement.open);
      if(toggle){toggle.click();await wait(60);}
    }
    return snapshot();
  }
  if(action==='menu-closed')return {closed:!document.querySelector('[data-model-picker-view]')&&!all('[role="menu"],[role="listbox"]').length};
  if(action!=='dismiss'&&challengePresent())throw Error('Cloudflare 网页验证尚未通过，已暂停网页操作');

  if(action.startsWith('file-download-')){
    if(action==='file-download-end'){const t=window.__etWebDownload;if(t?.id===args.id){t.cleanup();clearTimeout(t.releaseTimer);delete window.__etWebDownload;}return true;}
    if(action==='file-download-state'){
      const t=window.__etWebDownload;if(!t||t.id!==args.id)throw Error('下载任务已失效');
      if(t.bytes&&Number.isInteger(args.offset)){const offset=args.offset;if(offset<0||offset>t.bytes.length)throw Error('下载偏移无效');const chunk=t.bytes.subarray(offset,offset+384*1024);let raw='';for(let i=0;i<chunk.length;i+=8192)raw+=String.fromCharCode(...chunk.subarray(i,i+8192));return {state:'bytes',size:t.bytes.length,base64:btoa(raw),length:chunk.length};}
      return {state:t.state,url:t.url,size:t.bytes?.length,error:t.error};
    }
    if(action!=='file-download-start')throw Error('未知下载操作');
    if(!/^[^\\/\x00-\x1f]+\.zip$/i.test(args.name))throw Error('下载文件名无效');
    const candidates=messageNodes('assistant').flatMap(root=>all('[data-file-reference="true"],a',root)).filter(e=>{
      const name=e.getAttribute('data-markdown-copy-text')||label(e).replace(/^(?:下载|Download)\s+/i,'');return name===args.name;
    });
    if(candidates.length!==1)throw Error('当前聊天中未找到唯一的译稿下载链接，请查看网页');
    window.__etWebDownload?.cleanup();clearTimeout(window.__etWebDownload?.releaseTimer);const originalClick=HTMLAnchorElement.prototype.click,originalOpen=window.open,t=window.__etWebDownload={id:args.id,state:'pending'};
    const capture=async value=>{
      if(t.state!=='pending')return;t.state='resolving';
      try{
        const u=new URL(value,location.href);
        if(u.protocol==='blob:'&&u.origin===location.origin){const response=await fetch(u.href),buffer=await response.arrayBuffer();if(buffer.byteLength>60*1024*1024)throw Error('下载包超过 60 MB');t.bytes=new Uint8Array(buffer);t.state='bytes';}
        else if(u.protocol==='https:'&&!u.username&&!u.password){t.url=u.href;t.state='url';}
        else throw Error('网页尚未提供可下载的文件地址');
      }catch(e){t.error=e.message;t.state='error';}finally{t.cleanup();t.releaseTimer=setTimeout(()=>{t.bytes=null;if(window.__etWebDownload===t)delete window.__etWebDownload;},120000);}
    };
    const click=function(){if(t.state==='pending'&&this.href&&!this.href.startsWith('sandbox:')){void capture(this.href);return;}return originalClick.apply(this,arguments);};
    const open=function(url){if(t.state==='pending'&&typeof url==='string'){void capture(url);return null;}return originalOpen.apply(this,arguments);};
    const listener=e=>{const a=e.target.closest?.('a');if(a&&t.state==='pending'&&a.href&&!a.href.startsWith('sandbox:')){e.preventDefault();e.stopPropagation();void capture(a.href);}};
    t.cleanup=()=>{clearTimeout(t.timer);if(HTMLAnchorElement.prototype.click===click)HTMLAnchorElement.prototype.click=originalClick;if(window.open===open)window.open=originalOpen;document.removeEventListener('click',listener,true);};
    HTMLAnchorElement.prototype.click=click;window.open=open;document.addEventListener('click',listener,true);
    t.timer=setTimeout(()=>{t.cleanup();t.bytes=null;t.error='网页文件下载等待超时，请重试';t.state='error';},90000);
    candidates[0].click();return {started:true};
  }
  if(action==='upload-ready')return {...snapshot(),uploadReady:!!uploadInput(args.files||[])};
  if(action==='open-mode'||action==='open-version'){
    const settled=async kind=>{
      let s,previous='',stable=0;
      for(let i=0;i<20;i++){
        await wait(80);s=state();if(kind==='open-mode'&&s.slider&&s.mode)return s;
        const versions=s.options.filter(o=>versionLabel.test(o.label)),key=JSON.stringify(versions);
        // Menu views mount/animate rows separately. The first older model is
        // not proof that Latest (often the checked row) has finished mounting.
        stable=versions.length?(key===previous?stable+1:1):0;previous=key;
        if(stable>=4)return s;
      }
      if(kind==='open-version')throw Error('网页未提供可识别的模型版本菜单，请等待菜单加载完成后重试');
      return s;
    };
    const returnToIntensity=()=>all('[role="menuitemradio"]').find(e=>selected(e)&&versionLabel.test(cleanLabel(e)));
    const current=state();if(action==='open-mode'&&current.slider)return current;
    if(action==='open-version'&&current.options.some(o=>versionLabel.test(o.label)))return settled(action);
    // Re-selecting the checked version returns this menu to its intensity view
    // without changing the model. Some website versions remember the last view.
    if(action==='open-mode'&&returnToIntensity()){returnToIntensity().click();return settled(action);}
    if(action==='open-version'){
      // Versions are a second view inside the same popover, not another
      // composer button. Open the slider first when the shared menu is closed.
      const sharedTrigger=modeTrigger();
      if(!current.slider && sharedTrigger&&!disabled(sharedTrigger)){sharedTrigger.click();const opened=await settled('open-mode');if(opened.options.some(o=>versionLabel.test(o.label)))return opened;}
      const toggle=all('[data-model-picker-view-toggle="true"]')[0];
      if(toggle&&!disabled(toggle)){toggle.click();return settled(action);}
    }
    const e=action==='open-mode'?modeTrigger():versionTrigger();if(!e||disabled(e))throw Error('网页未提供可识别的'+(action==='open-mode'?'思考档位':'模型版本')+'菜单，请打开网页检查');
    e.click();let result=await settled(action);
    if(action==='open-mode'&&!result.slider&&returnToIntensity()){returnToIntensity().click();result=await settled(action);}
    return result;
  }
  if(action==='choose-option'){
    const e=all('[role="menuitemradio"],[role="option"],[role="menuitem"],button').find(e=>!inMessage(e)&&cleanLabel(e)===args.label&&!disabled(e));
    if(!e)throw Error('网页选项已变化，请刷新后重试');e.click();await wait(180);return state();
  }
  if(action==='slider-focus'){
    const e=slider();if(!e)throw Error('网页思考滑块不可用');e.focus();return state();
  }
  if(action==='slider-step'){
    const e=slider();if(!e||!['ArrowLeft','ArrowRight'].includes(args.key))throw Error('网页思考滑块不可用');
    e.focus();const code=args.key,keyCode=code==='ArrowRight'?39:37;
    for(const type of ['keydown','keyup'])e.dispatchEvent(new KeyboardEvent(type,{key:code,code,keyCode,which:keyCode,bubbles:true,cancelable:true}));
    await wait(160);return state();
  }
  if(action==='slider-value'){
    const e=slider();if(!e||e.tagName!=='INPUT')throw Error('需要键盘操作网页滑块');
    const n=Number(args.value),s=state().slider;if(!Number.isInteger(n)||n<s.min||n>s.max)throw Error('无效网页档位');
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(e,String(n));e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));await wait(140);return state();
  }
  if(action==='dismiss'){document.activeElement?.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',code:'Escape',bubbles:true}));return true;}
  if(action==='clear-composer'){
    const before=snapshot(),clicked=new WeakMap();let stable=0;
    // Reset through ordinary editor/removal controls so React/ProseMirror sees
    // the change. Reacquire after each update: removing a file may remount them.
    for(let i=0;i<40;i++){
      const s=snapshot(),e=editor(),root=composerRoot(e);
      if(!s.ready||s.busy||!matchesConversation(s,before))throw Error('网页状态发生变化，已停止清理，未发送');
      if(s.draft)writeDraft(e,'');
      const buttons=root?removeButtons(root,e):[],b=buttons.find(b=>!disabled(b)&&clicked.get(b)!==label(b));
      if(b){clicked.set(b,label(b));b.click();}
      const empty=!s.draft&&!s.composerHasAttachments&&!s.uploadBusy;
      stable=empty?stable+1:0;if(stable>=3)return s;
      await wait(80);
    }
    throw Error('网页旧草稿或附件尚未清空，未发送，请打开网页检查');
  }
  if(action==='prepare'){
    const e=editor();if(!e||stopButton())throw Error('网页输入框不可用或正在生成回答');
    const current=draftText(e),expected=plainText(args.text);if(current.trim()&&current.trim()!==expected.trim())throw Error('网页输入框已有草稿，请先在网页处理后重试');
    writeDraft(e,args.text);
    await wait(100);if(draftText(editor()).trim()!==expected.trim())throw Error('网页输入内容校验失败，未发送');return snapshot();
  }
  if(action==='upload'){
    const e=uploadInput(args.files);
    if(!e)throw Error('网页文件上传控件尚未可用，请等待网页加载完成或检查附件菜单');
    const dt=new DataTransfer();for(const f of args.files){const b=Uint8Array.from(atob(f.base64),c=>c.charCodeAt(0));dt.items.add(new File([b],f.name,{type:f.type}));}
    e.files=dt.files;e.dispatchEvent(new Event('change',{bubbles:true}));await wait(150);return snapshot();
  }
  if(action==='send'){
    const ledger=window.__etWebChatSubmissions ||= Object.create(null);if(ledger[args.id])return {duplicate:true,...ledger[args.id]};
    const s=snapshot();if(!s.ready||s.busy||!s.sendReady||s.draft.trim()!==plainText(args.text).trim()||s.userCount!==args.userCount)throw Error('网页状态发生变化，未发送，请检查网页');
    // Record before clicking: a lost host acknowledgement must never resend this turn.
    ledger[args.id]={submitted:true,userCount:s.userCount,answerCount:s.answerCount};sendButton().click();return ledger[args.id];
  }
  if(action==='stop'){const e=stopButton();if(e)e.click();await wait(150);return {clicked:!!e,...snapshot()};}
  if(action==='new-chat'){const e=all('a,button').find(e=>/^(新聊天|新对话|New chat)(?:\s|$)/i.test(label(e))&&!inMessage(e));if(!e)throw Error('未找到新聊天按钮');e.click();await wait(200);return snapshot();}
  throw Error('未知网页操作');
}
module.exports=webChatPage;
