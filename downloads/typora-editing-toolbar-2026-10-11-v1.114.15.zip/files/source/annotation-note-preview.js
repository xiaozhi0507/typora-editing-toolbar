import {DOMSerializer} from 'prosemirror-model';
import {sizeDocumentImage} from './annotation-document-preview.js';

// A streamed answer repeatedly reuses the same host. Keep completed formula HTML
// and in-flight work there, so every token does not restart the MathJax queue.
const previews = new WeakMap();
const MAX_CACHED_MATH = 128;

// Native selection drags can export a code block as styled spans, losing its
// line breaks in the receiving editor. Export the selected semantic HTML.
function bindSelectionDrag(host) {
    host.addEventListener('dragstart', event => {
        const selection=host.ownerDocument.getSelection();
        if(!event.dataTransfer||!selection?.rangeCount||selection.isCollapsed||event.target.closest?.('a,img'))return;
        const range=selection.getRangeAt(0);
        if(!host.contains(range.startContainer)||!host.contains(range.endContainer)||!range.intersectsNode(event.target))return;
        const doc=host.ownerDocument,container=doc.createElement('div');
        const start=range.startContainer.nodeType===1?range.startContainer:range.startContainer.parentElement;
        const block=start.closest('pre,p,h1,h2,h3,h4,h5,h6,[data-note-math]');
        if(block&&host.contains(block)&&block.contains(range.endContainer)){
            const wrapper=block.cloneNode(false);
            if(block.tagName==='PRE'){
                const code=doc.createElement('code');code.textContent=range.toString();
                code.className=block.querySelector('code')?.className||'';wrapper.append(code);
            }else wrapper.append(range.cloneContents());
            container.append(wrapper);
        }else container.append(range.cloneContents());
        container.querySelectorAll('[data-note-math]').forEach(math=>{math.textContent=math.dataset.tex||'';});
        event.dataTransfer.setData('text/html',container.innerHTML);
        event.dataTransfer.setData('text/plain',selection.toString());
        event.dataTransfer.effectAllowed='copy';
        event.stopPropagation();
    });
}

// Reuse the editor's Markdown parser/schema, without creating an editable view.
export function renderNotePreview(host, markdown, schema, parser, options = {}) {
    let preview = previews.get(host);
    if (!preview) { preview = {generation: 0, math: new Map(), paintedMath:new WeakMap()}; previews.set(host, preview); bindSelectionDrag(host); }
    const generation = ++preview.generation;
    const isCurrent = () => preview.generation === generation && (!options.isCurrent || options.isCurrent());
    const serial = DOMSerializer.fromSchema(schema);
    const safe = new DOMSerializer({ ...serial.nodes,
        heading: node => serial.nodes.heading(node.attrs.level<(options.minHeadingLevel||1)?node.type.create({...node.attrs,level:options.minHeadingLevel},node.content,node.marks):node),
        image: node => {const img=host.ownerDocument.createElement('img');img.dataset.previewImage=node.attrs.src;img.alt=node.attrs.alt||'图片';img.loading='lazy';if(options.documentHTML)sizeDocumentImage(img,node.attrs.previewStyle);return img;},
        note_video: () => ['p', {class: 'et-note-preview-media'}, '视频附件 · 打开注释查看'],
    }, { ...serial.marks,
        link: mark => ['a', {'data-preview-link': mark.attrs.href, title: mark.attrs.title || ''}, 0],
    });
    const validate=parser.tokenizer.validateLink;let doc;
    if(preview.source===markdown&&preview.validate===options.allowFileLink&&preview.documentHTML===!!options.documentHTML)doc=preview.doc;
    else try{if(options.allowFileLink)parser.tokenizer.validateLink=url=>validate(url)||options.allowFileLink(url);doc=parser.parse(markdown||'',{documentPreview:!!options.documentHTML});}finally{parser.tokenizer.validateLink=validate;}
    const blocks=[];let cursor=host.firstChild;
    doc.forEach((node,_offset,index)=>{
        const old=preview.blocks?.[index];
        const same=old?.model.eq(node)&&old.dom.parentNode===host&&preview.headingLevel===options.minHeadingLevel&&preview.contextKey===options.contextKey&&preview.documentHTML===!!options.documentHTML;
        const dom=same?old.dom:safe.serializeNode(node,{document:host.ownerDocument});
        if(dom!==cursor)host.insertBefore(dom,cursor);
        else cursor=cursor.nextSibling;
        if(!same&&old?.dom===cursor){cursor=cursor.nextSibling;old.dom.remove();}
        blocks.push({model:node,dom});
    });
    while(cursor){const next=cursor.nextSibling;cursor.remove();cursor=next;}
    preview.blocks=blocks;preview.source=markdown;preview.doc=doc;preview.validate=options.allowFileLink;preview.headingLevel=options.minHeadingLevel;preview.contextKey=options.contextKey;preview.documentHTML=!!options.documentHTML;
    for (const input of host.querySelectorAll('input')) input.disabled = true;
    for (const img of host.querySelectorAll('[data-preview-image]')) {
        const src = options.imageURL?.(img.dataset.previewImage);
        img.removeAttribute('data-preview-image');
        if (src) img.src = src;
        else { const missing = host.ownerDocument.createElement('span'); missing.textContent = '[' + img.alt + ']'; img.replaceWith(missing); }
    }
    for (const link of host.querySelectorAll('[data-preview-link]')) {
        const url = link.dataset.previewLink;
        link.removeAttribute('data-preview-link');
        if(options.decorateLink?.(link,url))continue;
        if (/^(https?:\/\/|mailto:|zotero:\/\/(?:open-pdf|select)\/)/i.test(url) && !/[\u0000-\u0020<>"\\]/.test(url)) {
            link.href = url;
            link.addEventListener('click', event => { event.preventDefault(); options.openLink?.(url); });
        }
    }
    options.afterRender?.(host);
    // Both guards prevent late math from reviving a closed or superseded popup.
    // Only trusted MathJax output becomes markup; Markdown HTML stays disabled.
    for (const math of host.querySelectorAll('[data-note-math]')) {
        if (!options.renderMath) continue;
        const tex = math.dataset.tex || '', display = math.dataset.noteMath === 'block';
        const key = (display ? 'block:' : 'inline:') + tex;
        let entry = preview.math.get(key);
        if (!entry) {
            entry = {html: '', isCurrent, renderMath: options.renderMath};
            preview.math.set(key, entry);
            entry.promise = Promise.resolve().then(() => entry.isCurrent() ? entry.renderMath(tex, display) : null).then(html => {
                entry.html = html || '';
                if (!html && preview.math.get(key) === entry) preview.math.delete(key);
                return html;
            }).catch(() => {
                // Invalid/incomplete TeX remains readable and can be retried.
                if (preview.math.get(key) === entry) preview.math.delete(key);
            });
        } else {
            entry.isCurrent = isCurrent;
            entry.renderMath = options.renderMath;
            preview.math.delete(key);
            preview.math.set(key, entry);
        }
        while (preview.math.size > MAX_CACHED_MATH) preview.math.delete(preview.math.keys().next().value);
        const paint=html=>{if(html&&isCurrent()&&host.contains(math)&&preview.paintedMath.get(math)!==html){math.innerHTML=html;preview.paintedMath.set(math,html);}};
        if (entry.html) paint(entry.html);
        else entry.promise.then(html => {
            paint(html);
        });
    }
}
