class EditingToolbarReadingMode {
    constructor(toolbar) {
        this.toolbar=toolbar;this.key='et-reading-mode-v1';this.mode='edit';this.formatDepth=0;this.formatCommands=new WeakSet();this.editable=new Map();this.codeEditors=new Map();this.buttonIcons=new WeakMap();
        try {this.mode=this.decode(localStorage.getItem(this.key));}catch{}
        this.installGuards();this.apply();
        window.addEventListener('storage',event=>{if(event.key===this.key){this.mode=this.decode(event.newValue);this.apply();}});
        document.addEventListener('et-document-loaded',()=>this.apply());
        window.addEventListener('click',event=>{
            if(!this.enabled||event.button!==0)return;
            if(this.protected&&event.target.closest?.('#write input,#write .md-task-list-item input')){this.stop(event);return;}
            const block=event.target.closest?.('#write .md-rawblock');if(!block||event.target.closest('a,button,input'))return;this.stop(event);
        },true);
    }
    decode(value){return value==='protected'?'protected':value==='true'||value==='read'?'read':'edit';}
    get enabled(){return this.mode!=='edit';}
    get protected(){return this.mode==='protected';}
    toggle(){this.mode=this.mode==='edit'?'read':this.mode==='read'?'protected':'edit';try{localStorage.setItem(this.key,this.mode);}catch{}this.apply();}
    blocksAction(action){return this.protected&&!EditingToolbarReadingMode.protectedActions.has(action);}
    static protectedActions=new Set(['paragraph-spacing','paragraph-menu','reading-mode','ai-assistant','knowledge-library','manual-mark','add-mark','document-note','theme-palette','annotation','toolbar-settings','undo','redo','bold','italic','strikethrough','underline','highlight','font-size-decrease','font-size-increase','font-color','bg-color','clear-format','fullscreen','floating-toolbar-toggle','common-menu','more-menu']);
    syncActionButton(button){
        if(this.blocksAction(button.dataset.action)){if(button.dataset.protectedDisabled!=='true'){button.dataset.protectedDisabled='true';button.dataset.protectedPreviousDisabled=String(button.disabled);}button.disabled=true;button.setAttribute('aria-disabled','true');button.classList.remove('et-btn-active','et-btn-mixed');button.dataset.baseTitle||=button.title;button.title=button.dataset.baseTitle+'（保护模式下不可用）';button.setAttribute('aria-label',button.title);return true;}
        if(button.dataset.protectedDisabled==='true'){button.disabled=button.dataset.protectedPreviousDisabled==='true';delete button.dataset.protectedDisabled;delete button.dataset.protectedPreviousDisabled;button.removeAttribute('aria-disabled');button.title=button.dataset.baseTitle||button.title;button.setAttribute('aria-label',button.title);}return false;
    }
    stop(event){event.preventDefault();event.stopImmediatePropagation();}
    inEditor(event){const target=event.target;if(target?.closest?.('#write,#typora-source'))return true;if(target?.closest?.('input,textarea,button,[contenteditable="true"],dialog,[role="dialog"]'))return false;const node=window.getSelection()?.anchorNode;return !!(node?.parentElement?.closest('#write')&&(target===document.body||target===document.documentElement));}
    hasSelection(){const t=this.toolbar,r=t.savedRangy||t.savedRange;if(r&&!r.collapsed)return true;const s=window.getSelection();return !!(s&&!s.isCollapsed&&s.anchorNode?.parentElement?.closest('#write'));}
    format(run){if(!this.protected||this.formatDepth)return run();if(!this.hasSelection()||File.editor?.sourceView?.inSourceMode)return;this.formatDepth++;this.restoreEditable();try{return run();}finally{this.formatDepth--;this.lockEditable();}}
    wrap(object,name,handler){const original=object?.[name];if(typeof original!=='function')return;object[name]=function(...args){return handler(original,this,args);};}
    installGuards(){
        if(!File.editor?.UserOp){setTimeout(()=>this.installGuards(),100);return;}if(this.guardsInstalled)return;this.guardsInstalled=true;
        const t=this.toolbar,e=File.editor,blocked=()=>this.protected&&!this.formatDepth;
        for(const type of ['beforeinput','compositionstart','compositionupdate','paste','cut','drop'])window.addEventListener(type,event=>{if(blocked()&&this.inEditor(event))this.stop(event);},true);
        window.addEventListener('keydown',event=>{
            if(!blocked()||!this.inEditor(event))return;const key=event.key.toLowerCase(),mod=event.ctrlKey||event.metaKey;
            if(mod&&['b','i','u'].includes(key)){this.stop(event);t._saveSelection?.();t._executeAction({b:'bold',i:'italic',u:'underline'}[key]);return;}
            if(mod&&['z','y'].includes(key)){this.stop(event);(key==='y'||event.shiftKey?e.undo.redo:e.undo.undo).call(e.undo);return;}
            if((['Backspace','Delete','Enter'].includes(event.key)||event.key==='Tab'&&!mod)||(!mod&&!event.altKey&&(event.key.length===1||event.key==='Process'))||mod&&['v','x'].includes(key))this.stop(event);
        },true);
        const deny=(original,self,args)=>blocked()?undefined:original.apply(self,args);
        this.wrap(e,'insertText',deny);
        for(const name of ['backspaceHandler','deleteSelectable','deleteLineProcessor','deleteLine','deleteBlock','backToParagraph','insertInlineText','insertUrlWithTitle','pasteHandler','insertDom','insertParagraph','pasteBlocksAt','insertFileLink','moveRowUpOrDown','handlePair','surroundPair'])this.wrap(e.UserOp,name,deny);
        for(const name of ['replaceAll','replaceSelection'])this.wrap(e.searchPanel,name,deny);
        for(const name of ['insertTable','deleteRow','addRow','deleteCol','addCol','deleteTable','moveTableRow','moveTableCol','moveRowUpOrDown','moveColLeftOrRight','moveToNextCell','moveToBelowCell'])this.wrap(e.tableEdit,name,deny);
        for(const name of ['insertBlock','insertAlert','insertMetaBlock','toggleFences','toggleMathBlock','toggleTaskStatus','changeBetweenCodeMirror'])this.wrap(e.stylize,name,deny);
        for(const name of ['_applySelectionStyle','_clearFormat'])this.wrap(t,name,(original,self,args)=>this.format(()=>original.apply(self,args)));
        this.wrap(t,'_toggleInlineStyle',(original,self,args)=>this.protected&&['superscript','subscript'].includes(args[0])?undefined:this.format(()=>original.apply(self,args)));
        for(const name of ['_toggleInlineCode','_setAlignment','_changeHeading','_toggleQuote','_changeListStyle','_changeIndent','_insertCodeBlock','_toggleInlineMath','_convertSelectionAsciiToMath','_toggleMathBlock'])this.wrap(t,name,(original,self,args)=>this.protected?undefined:original.apply(self,args));
        this.wrap(t,'_executeAction',(original,self,args)=>this.blocksAction(args[0])?undefined:original.apply(self,args));
        this.wrap(e.undo,'register',(original,self,args)=>{if(this.protected&&this.formatDepth&&args[0]&&typeof args[0]==='object')this.formatCommands.add(args[0]);return original.apply(self,args);});
        for(const name of ['undo','redo'])this.wrap(e.undo,name,(original,self,args)=>{if(blocked()){if(e.sourceView?.inSourceMode)return;const command=self.commandStack?.[self.index+(name==='redo'?1:0)];if(!command||(!command.cursorOnly&&!this.formatCommands.has(command)))return;}return original.apply(self,args);});
        for(const name of ['show','prep'])this.wrap(e.sourceView,name,(original,self,args)=>{const result=original.apply(self,args);if(this.protected)this.lockEditable();return result;});
        this.observer=new MutationObserver(()=>{if(blocked())this.lockEditable();});
        const body=document.getElementById('write');if(body)this.observer.observe(body,{attributes:true,attributeFilter:['contenteditable'],childList:true,subtree:true});
    }
    lockEditable(){
        if(!this.protected||this.formatDepth)return;for(const node of this.editable.keys())if(!node.isConnected)this.editable.delete(node);const body=document.getElementById('write');
        if(body)for(const node of [body,...body.querySelectorAll('[contenteditable="true"]')]){if(!this.editable.has(node))this.editable.set(node,node.getAttribute('contenteditable'));if(node.getAttribute('contenteditable')!=='false')node.setAttribute('contenteditable','false');}
        const cm=File.editor?.sourceView?.cm;if(cm){if(!this.codeEditors.has(cm))this.codeEditors.set(cm,cm.getOption('readOnly'));if(cm.getOption('readOnly')!==true)cm.setOption('readOnly',true);}
    }
    restoreEditable(){for(const [node,value]of this.editable){if(!node.isConnected)continue;if(value===null)node.removeAttribute('contenteditable');else node.setAttribute('contenteditable',value);}this.editable.clear();for(const [cm,value]of this.codeEditors)cm.setOption('readOnly',value);this.codeEditors.clear();}
    apply(){this.toolbar._closeActivePopover?.();document.documentElement.classList.toggle('et-reading-mode',this.enabled);document.documentElement.classList.toggle('et-protected-mode',this.protected);if(this.protected)this.lockEditable();else this.restoreEditable();document.querySelectorAll('[data-action="reading-mode"]').forEach(button=>this.updateButton(button));this.toolbar._updateToolbarState?.();}
    updateButton(button){const svg=button.querySelector('svg');if(svg){if(!this.buttonIcons.has(button))this.buttonIcons.set(button,svg.innerHTML);if(button.dataset.readingMode!==this.mode)svg.innerHTML=this.buttonIcons.get(button)+(this.protected?'<rect x="14.5" y="14" width="8" height="8" rx="1.5" fill="currentColor" stroke="none"/><path d="M16 14v-2a2.5 2.5 0 0 1 5 0v2"/>':'');}button.classList.toggle('et-btn-active',this.enabled);button.classList.toggle('et-reading-protected',this.protected);button.setAttribute('aria-pressed',String(this.enabled));button.dataset.readingMode=this.mode;button.title=this.protected?'保护模式 · 点击切换为编辑模式':this.enabled?'阅读模式 · 点击切换为保护模式':'编辑模式 · 点击切换为阅读模式';button.setAttribute('aria-label',button.title);button.disabled=false;}
}
