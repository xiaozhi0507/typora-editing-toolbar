// Read-only heading navigation for Typora's rendered document.
class EditingToolbarChapterMinimap {
 constructor(toolbar){
  this.toolbar=toolbar;this.items=[];this.active=-1;this.raf=0;this.hoverRaf=0;this.hoverY=null;this.dirty=true;this.geometryDirty=true;
  this.rail=document.createElement('nav');this.rail.id='et-chapter-minimap';this.rail.hidden=true;this.rail.setAttribute('aria-label','Markdown 章节导航');
  this.marks=document.createElement('div');this.marks.className='et-minimap-marks';this.rail.append(this.marks);
  this.preview=document.createElement('div');this.preview.id='et-chapter-preview';this.preview.hidden=true;this.preview.setAttribute('role','tooltip');
  this.caption=document.createElement('div');this.caption.className='et-chapter-caption';this.title=document.createElement('strong');this.summary=document.createElement('p');this.preview.append(this.caption,this.title,this.summary);document.body.append(this.rail,this.preview);
  this.onScroll=e=>{if(e.target===this.scroller||e.target===document){this.hidePreview();this.schedule();}};
  this.onResize=()=>{this.geometryDirty=true;this.schedule();};
  document.addEventListener('scroll',this.onScroll,true);window.addEventListener('resize',this.onResize);
  this.observer=new MutationObserver(records=>{
   // MathJax replaces SVG descendants on entry. Those change geometry, not the
   // heading list; rebuilding buttons also forces another layout of the chapter.
   if(records.some(record=>this.changesHeadings(record)))this.dirty=true;
   clearTimeout(this.editTimer);this.editTimer=setTimeout(()=>{this.geometryDirty=true;this.schedule();},100);
  });
  // ResizeObserver runs after layout: measure here instead of the next RAF,
  // where sidebar writes would make heading reads force layout again.
  this.resizeObserver=new ResizeObserver(()=>{this.geometryDirty=true;this.update();});
  this.layoutObserver=new MutationObserver(()=>{this.geometryDirty=true;this.schedule();});
  this.layoutObserver.observe(document.body,{attributes:true,attributeFilter:['class','style']});
  this.layoutObserver.observe(document.documentElement,{attributes:true,attributeFilter:['class','style']});
  // Size is covered by ResizeObserver. Observing each inline max-width write
  // would schedule another heading measurement before the next layout.
  if(toolbar.topHost)this.layoutObserver.observe(toolbar.topHost,{attributes:true,attributeFilter:['data-placement','data-collapsed']});
  this.rail.addEventListener('mousemove',e=>{this.hoverY=e.clientY;this.scheduleHover();});
  this.rail.addEventListener('mouseleave',()=>{this.clearHover();this.hidePreview();});
  window.addEventListener('blur',()=>{this.clearHover();this.hidePreview();});
  this.rail.addEventListener('keydown',e=>this.keydown(e));
  // Typora can replace #write on mode/file changes. Binding stays read-only.
  this.timer=setInterval(()=>this.bind(),750);this.bind();
 }
 bind(){
  const write=document.getElementById('write');if(write===this.write){return;}
  this.observer.disconnect();this.resizeObserver.disconnect();this.clearHover();this.hidePreview();this.write=write;
  this.scroller=write?.closest('content')||document.scrollingElement;
  if(write){this.observer.observe(write,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['style','class','hidden']});this.resizeObserver.observe(write);this.resizeObserver.observe(this.scroller);if(this.toolbar.topHost)this.resizeObserver.observe(this.toolbar.topHost);}
  this.dirty=true;this.geometryDirty=true;this.schedule();
 }
 schedule(){if(!this.raf)this.raf=requestAnimationFrame(()=>{this.raf=0;this.update();});}
 changesHeadings(record){
  const heading='h1,h2,h3,h4,h5,h6',target=record.target.nodeType===1?record.target:record.target.parentElement;
  if(target?.closest(heading))return true;
  if(record.type==='attributes')return target===this.write||Boolean(target?.querySelector(heading));
  if(record.type!=='childList')return false;
  return [...record.addedNodes,...record.removedNodes].some(node=>node.nodeType===1&&(node.matches(heading)||node.querySelector(heading)));
 }
 scheduleHover(){if(!this.hoverRaf)this.hoverRaf=requestAnimationFrame(()=>{this.hoverRaf=0;this.updateHover();});}
 updateHover(){
  // Keep heading positions and left endpoints fixed. Only stretch the strokes.
  // Cached positions avoid measuring every heading on every pointer move.
  const local=this.hoverY===null?null:this.hoverY-this.railTop,radius=72;
  for(const item of this.items){
   const distance=local===null?radius:Math.abs(item.y+6-local),weight=distance>=radius?0:(1+Math.cos(Math.PI*distance/radius))/2;
   const growth=Math.round(weight*6*100)/100;if(growth===(item.hoverGrowth||0))continue;
   item.hoverGrowth=growth;
   if(growth){item.button.style.setProperty('--tick-scale',String(1+growth/(16-(item.level-1)*1.8)));item.button.style.setProperty('--tick-opacity',String(.36+weight*.25));}
   else{item.button.style.removeProperty('--tick-scale');item.button.style.removeProperty('--tick-opacity');}
  }
 }
 clearHover(){this.hoverY=null;if(this.hoverRaf)cancelAnimationFrame(this.hoverRaf);this.hoverRaf=0;this.updateHover();}
 text(el){
  const clone=el.cloneNode(true);clone.querySelectorAll('.md-meta,.md-before,.md-after,.md-toc,.md-img-meta,script,style').forEach(e=>e.remove());
  return (clone.textContent||'').replace(/\s+/g,' ').trim();
 }
 rebuild(){
  this.dirty=false;this.hidePreview();const focus=this.items.findIndex(x=>x.button===document.activeElement);
  this.items=[...this.write.querySelectorAll('h1,h2,h3,h4,h5,h6')].filter(e=>e.matches('[mdtype="heading"],.md-heading')&&!e.closest('.md-toc,.md-fences,.md-htmlblock')&&e.getClientRects().length).map(el=>({el,level:Number(el.tagName[1]),title:this.text(el)||'未命名章节'}));
  const fragment=document.createDocumentFragment();
  for(const [index,item]of this.items.entries()){
   const button=document.createElement('button');button.type='button';button.className='et-chapter-tick';button.dataset.level=item.level;button.style.setProperty('--tick-width',(16-(item.level-1)*1.8)+'px');button.setAttribute('aria-label','H'+item.level+' '+item.title);button.tabIndex=-1;
   button.addEventListener('mouseenter',()=>this.showPreview(index));button.addEventListener('focus',()=>this.showPreview(index));button.addEventListener('blur',()=>this.hidePreview());button.addEventListener('click',()=>this.jump(index));item.button=button;fragment.append(button);
  }
  this.marks.replaceChildren(fragment);this.active=-1;this.geometryDirty=true;
  this.pendingFocus=focus>=0?Math.min(focus,this.items.length-1):-1;
 }
 measure(){
  this.geometryDirty=false;const r=this.scroller.getBoundingClientRect();
  // Only docked toolbars reserve reading space; floating drag must not shrink the rail or shift chapter jumps.
  const host=this.toolbar.topHost,tool=host?.dataset.placement==='floating'?[]:[host,this.toolbar.topToolbar,host?.querySelector('.et-top-chrome')].filter(e=>e&&!e.hidden&&e.getClientRects().length).map(e=>e.getBoundingClientRect().bottom);
  const top=Math.max(r.top+12,...tool.map(y=>y+14));const bottom=Math.min(innerHeight-30,r.bottom-12);
  const left=r.left+3;
  this.height=Math.max(0,bottom-top);this.readOffset=Math.max(28,top-r.top+12);this.extent=Math.max(1,this.scroller.scrollHeight);this.pageHeight=this.scroller.clientHeight;
  this.railTop=Math.round(top);
  const scroll=this.scroller.scrollTop;
  // Read every heading before writing rail geometry, so a live sidebar resize
  // does not force a second synchronous layout in this animation frame.
  for(const item of this.items)item.offset=item.el.getBoundingClientRect().top-r.top+scroll;
  // Monotonic placement with small minimum spacing; dense rails still retain every heading.
  const room=Math.max(1,this.height-12),gap=Math.min(8,room/Math.max(1,this.items.length-1));let previous=-gap;
  for(const item of this.items){item.y=Math.max(previous+gap,Math.min(room,item.offset/this.extent*room));previous=item.y;}
  Object.assign(this.rail.style,{left:Math.round(left)+'px',top:this.railTop+'px',height:this.height+'px'});
  for(let i=this.items.length-1;i>=0;i--){const item=this.items[i];item.y=Math.min(item.y,i===this.items.length-1?room:this.items[i+1].y-gap);Object.assign(item.button.style,{top:(item.y+6)+'px',height:Math.max(1,Math.min(12,gap))+'px'});}
  if(this.hoverY!==null)this.scheduleHover();
 }
 update(){
  if(!this.write?.isConnected||!this.scroller)return;
  const scroll=this.scroller.scrollTop;
  if(this.dirty)this.rebuild();
  const source=document.body.classList.contains('typora-sourceview-on')||!this.write.getClientRects().length;
  this.rail.hidden=source||!this.items.length;
  if(this.rail.hidden){this.clearHover();this.hidePreview();return;}
  if(this.geometryDirty)this.measure();
  if(this.pendingFocus>=0){this.items[this.pendingFocus]?.button.focus({preventScroll:true});this.pendingFocus=-1;}
  if(this.height<60){this.rail.hidden=true;this.clearHover();this.hidePreview();return;}
  const at=scroll+this.readOffset;let next=0;
  // Cached heading positions: no per-heading DOM layout reads while scrolling.
  let lo=0,hi=this.items.length;while(lo<hi){const mid=(lo+hi)>>1;if(this.items[mid].offset<=at)lo=mid+1;else hi=mid;}next=Math.max(0,lo-1);
  if(scroll>0&&scroll+this.pageHeight>=this.extent-3)next=this.items.length-1;
  if(next!==this.active){for(const [i,item]of this.items.entries()){const on=i===next;item.button.classList.toggle('active',on);item.button.tabIndex=on?0:-1;if(on)item.button.setAttribute('aria-current','location');else item.button.removeAttribute('aria-current');}this.active=next;}
 }
 showPreview(index){
  const item=this.items[index];if(!item||this.rail.hidden)return;
  this.caption.textContent='H'+item.level+' · '+(index+1)+' / '+this.items.length;this.title.textContent=item.title;
  const end=this.items[index+1]?.el,walker=document.createTreeWalker(this.write,NodeFilter.SHOW_ELEMENT|NodeFilter.SHOW_TEXT);walker.currentNode=item.el;let text='',node,count=0;
  // Bound hover work even when a single chapter contains thousands of blocks.
  while((node=walker.nextNode())&&node!==end&&text.length<210&&count++<2000){if(item.el.contains(node))continue;if(node.nodeType===3&&!node.parentElement.closest('.md-meta,.md-before,.md-after,.md-toc,.md-img-meta,script,style'))text+=node.textContent+' ';}
  text=text.replace(/\s+/g,' ').trim();this.summary.textContent=text?text.slice(0,180)+(text.length>180?'…':''):'本节暂无正文';
  this.preview.hidden=false;item.button.setAttribute('aria-describedby',this.preview.id);
  const r=this.rail.getBoundingClientRect(),edge=this.scroller.getBoundingClientRect().right;
  this.preview.style.width=Math.max(120,Math.min(280,edge-r.right-20))+'px';
  const p=this.preview.getBoundingClientRect();Object.assign(this.preview.style,{left:(r.right+8)+'px',top:Math.max(8,Math.min(innerHeight-p.height-12,r.top+item.y-p.height/2))+'px'});
 }
 hidePreview(){this.preview.hidden=true;this.marks.querySelector('[aria-describedby]')?.removeAttribute('aria-describedby');}
 jump(index){
  const item=this.items[index];if(!item?.el.isConnected)return;this.geometryDirty=true;this.measure();
  this.scroller.scrollTo({top:Math.max(0,item.offset-this.readOffset+2),behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});this.hidePreview();this.schedule();
 }
 keydown(e){
  const i=this.items.findIndex(x=>x.button===e.target);if(i<0)return;
  if(e.key==='Escape'){this.hidePreview();return;}
  let next;if(e.key==='ArrowDown')next=Math.min(this.items.length-1,i+1);else if(e.key==='ArrowUp')next=Math.max(0,i-1);else if(e.key==='Home')next=0;else if(e.key==='End')next=this.items.length-1;else return;
  e.preventDefault();e.stopPropagation();this.items[next].button.focus({preventScroll:true});this.jump(next);
 }
}
