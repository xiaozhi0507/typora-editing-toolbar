// Toolbar shortcut: choose a library collection without leaving the current document.
class KnowledgeLibraryQuickMenu {
  constructor(host) {
    this.host = host; this.context = null; this.busy = false;
    document.addEventListener('contextmenu', event => {
      const button = event.target.closest?.('[data-action="knowledge-library"]'); if (!button) return;
      event.preventDefault(); event.stopImmediatePropagation(); void this.show(button, event.clientX, event.clientY);
    }, true);
    document.addEventListener('keydown', event => {
      const button = event.target.closest?.('[data-action="knowledge-library"]');
      if (button && (event.key === 'ContextMenu' || event.shiftKey && event.key === 'F10')) {
        event.preventDefault(); event.stopImmediatePropagation(); const rect = button.getBoundingClientRect(); void this.show(button, rect.left, rect.bottom); return;
      }
      if (!this.context || this.menu?.hidden) return;
      if (event.key === 'Escape' || event.key === 'Tab') { event.preventDefault(); event.stopImmediatePropagation(); this.close(true); return; }
      if (this.menu.contains(event.target) && ['ArrowUp', 'ArrowDown', 'Home', 'End'].includes(event.key)) {
        event.preventDefault(); event.stopImmediatePropagation(); const buttons = [...this.menu.querySelectorAll('button:not(:disabled)')], at = buttons.indexOf(document.activeElement);
        buttons[event.key === 'Home' ? 0 : event.key === 'End' ? buttons.length - 1 : (at + (event.key === 'ArrowDown' ? 1 : -1) + buttons.length) % buttons.length]?.focus();
      }
    }, true);
    document.addEventListener('pointerdown', event => { if (this.context && !this.menu.contains(event.target)) this.close(); }, true);
    window.addEventListener('blur', () => this.close()); window.addEventListener('resize', () => this.close());
  }
  node(tag, className, text) { const node = document.createElement(tag); node.className = className; if (text != null) node.textContent = text; return node; }
  close(focus = false) { const context = this.context, button = context?.button; this.context = null; if (this.menu) this.menu.hidden = true; if (button && context.title !== null && !button.hasAttribute('title')) button.setAttribute('title', context.title); if (focus) button?.focus({ preventScroll: true }); }
  valid(context) {
    return !File.isFileLoading?.() && File.bundle?.filePath === context.file && reqnode('path').resolve(this.host.rootPath) === context.store.root;
  }
  place() { const context = this.context; if (!context) return; const rect = this.menu.getBoundingClientRect(); this.menu.style.left = Math.max(8, Math.min(context.x, innerWidth - rect.width - 8)) + 'px'; this.menu.style.top = Math.max(8, Math.min(context.y, innerHeight - rect.height - 8)) + 'px'; }
  async show(button, x, y) {
    this.close(); if (this.busy) { this.host.notice('正在保存分类，请稍候。'); return; }
    if (!this.menu) {
      this.menu = this.node('div', 'et-library-quick-menu'); this.menu.setAttribute('aria-label', '当前文档的知识库分类');
      for (const name of ['pointerdown', 'mousedown', 'click', 'dblclick', 'contextmenu']) this.menu.addEventListener(name, event => { event.stopPropagation(); if (name === 'contextmenu') event.preventDefault(); });
      document.body.append(this.menu);
    }
    const store = new ETKnowledgeStorage(this.host.rootPath, reqnode), file = File.bundle?.filePath;
    const context = this.context = { button, x, y, file, store, title: button.getAttribute('title') };
    button.removeAttribute('title');
    this.menu.replaceChildren(this.node('div', 'et-library-quick-message', '正在读取文件夹…')); this.menu.hidden = false; this.place();
    try {
      if (this.host.ui?.importing()) throw new Error('文件正在导入，请稍后重试。');
      if (this.host.ui && !await this.host.ui.flush()) throw new Error('知识库修改尚未保存，请先完成保存。');
      context.service = new ETKnowledgeQuickFile(store, { Importer: ETKnowledgeImport, Metadata: ETKnowledgeMetadata, Managed: ETKnowledgeManaged });
      context.snapshot = await context.service.inspect(file);
      if (this.context !== context) return;
      if (!this.valid(context)) { this.close(); return; }
      this.render();
    } catch (error) {
      if (this.context !== context) return;
      this.menu.replaceChildren(this.node('div', 'et-library-quick-message', error.code === 'ENOENT' ? '当前 Markdown 文件不存在，请先保存文件。' : error.message));
      this.place();
    }
  }
  render() {
    const context = this.context; if (!context?.snapshot) return;
    const { snapshot } = context; this.menu.replaceChildren();
    const tree = this.node('div', 'et-library-quick-folders'); tree.setAttribute('role', 'menu'); tree.setAttribute('aria-label', '我的文库文件夹');
    const addFolder = (id, name, depth, fullName) => {
      const button = this.node('button', 'et-library-quick-folder'); button.type = 'button'; button.dataset.quickFolder = id; button.setAttribute('role', 'menuitem'); button.style.setProperty('--folder-depth', depth); button.title = fullName;
      const current = id ? snapshot.item?.collections.includes(id) : snapshot.item && !snapshot.item.collections.length;
      const check = this.node('span', 'et-library-quick-check', current ? '✓' : ''); check.setAttribute('aria-hidden', 'true');
      const symbol = this.node('span', 'et-library-quick-folder-icon'); symbol.setAttribute('aria-hidden', 'true'); symbol.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M3 7V5a2 2 0 0 1 2-2h5l2 3h7a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z"/></svg>';
      button.append(check, symbol, this.node('span', 'et-library-quick-name', name));
      button.onclick = () => void this.assign(context, id); tree.append(button);
    };
    addFolder('', '我的文库', 0, '我的文库');
    const collections = ETKnowledgeStorage.orderCollections(snapshot.data?.collections || []);
    const walk = (parent, depth, names) => { for (const collection of collections.filter(c => (c.parentId || null) === parent)) { const trail = [...names, collection.name]; addFolder(collection.id, collection.name, depth, trail.join(' / ')); walk(collection.id, depth + 1, trail); } };
    walk(null, 1, ['我的文库']); this.menu.append(tree);
    this.place(); tree.querySelector('button')?.focus({ preventScroll: true });
  }
  async assign(context, target) {
    if (this.busy || this.context !== context) return;
    this.busy = true; this.close(true);
    try {
      const result = await context.service.assign(context.snapshot, target, 'move', () => this.valid(context));
      this.host.graphChanged();
      const action = result.created ? '已收录到' : !result.changed ? '已在所选位置' : '已移动到';
      let message = action + '：' + result.collectionName;
      if (result.warningCount) message += '；部分元数据未能读取';
      try { if (this.host.store?.root === context.store.root) await this.host.ui?.refresh(); }
      catch (_) { message += '；重新打开知识库查看'; }
      this.host.notice(message);
    } catch (error) { this.host.notice('分类未完成：' + error.message); }
    finally { this.busy = false; }
  }
}
