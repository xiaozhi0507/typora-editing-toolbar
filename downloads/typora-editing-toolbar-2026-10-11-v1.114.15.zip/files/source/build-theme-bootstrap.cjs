const fs=require('node:fs'),path=require('node:path');
// Generate the pre-paint layer from the same validated data and CSS methods as
// the full manager. No editor, graph, Node integration or saved CSS is needed.
module.exports=function(){
 const source=fs.readFileSync(path.join(__dirname,'theme-codex-presets.js'),'utf8')+'\n'+fs.readFileSync(path.join(__dirname,'theme-palette.js'),'utf8');
 const Palette=new Function(source+';return EditingToolbarThemePalette;')();
 const methods=['validHex','normalizeProfile','supports','selectedId','profile','tokens','normalize','cleanName','catalog','palette','read','rgb','mix','luminance','textFor','contrast','mode','colors','apply','updateLauncher'];
 const code=String.raw`(function(){'use strict';try{
  if(window.__editingToolbarNoAutoInit)return;
  try{const reading=localStorage.getItem('et-reading-mode-v1');document.documentElement.classList.toggle('et-reading-mode',['true','read','protected'].includes(reading));document.documentElement.classList.toggle('et-protected-mode',reading==='protected');}catch{}
  ${fs.readFileSync(path.join(__dirname,'toolbar-style-loader.js'),'utf8')}
  try{ensureEditingToolbarStyle(new URL('./editing-toolbar.css',document.currentScript.src).href);}catch(error){console.warn('[EditingToolbar] Early stylesheet unavailable:',error);}
  const palette={key:'et-theme-palette-v1',toolbar:{},presets:${JSON.stringify(Palette.presets)},${methods.map(name=>Palette.prototype[name].toString()).join(',')}};
  let mode;try{mode=localStorage.getItem('et-theme-native-mode-v1');}catch{}
  const css=getComputedStyle(document.documentElement),background=css.getPropertyValue('--bg-color').trim()||css.backgroundColor;
  let hex=/^#[\da-f]{6}$/i.test(background)?background:null;
  const rgba=background.match(/^rgba?\(([^)]+)\)/);if(rgba){const channels=rgba[1].split(',').map(Number);if(channels.length===3||channels[3]>0)hex='#'+channels.slice(0,3).map(v=>Math.round(v).toString(16).padStart(2,'0')).join('');}
  if(mode!=='dark'&&mode!=='light'&&hex)mode=palette.luminance(hex)<.19?'dark':'light';
  palette.nativeMode=mode==='dark'||mode==='light'?mode:matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';
  palette.state=palette.read();palette.style=document.getElementById('et-theme-palette-overrides')||document.createElement('style');palette.style.id='et-theme-palette-overrides';
  if(!palette.style.isConnected)document.head.append(palette.style);
  palette.apply();
  const spacing=(()=>{const module={exports:{}};${fs.readFileSync(path.join(__dirname,'paragraph-spacing.cjs'),'utf8')};return module.exports;})();
  const spacingStyle=document.createElement('style');spacingStyle.id='et-paragraph-spacing-style';spacingStyle.textContent=spacing.css(spacing.read(localStorage.getItem(spacing.key)));document.head.append(spacingStyle);
  performance.mark('et-theme-bootstrap-applied');
 }catch(error){console.warn('[EditingToolbar] Early theme unavailable:',error);}})();`;
 new Function(code);return code;
};

