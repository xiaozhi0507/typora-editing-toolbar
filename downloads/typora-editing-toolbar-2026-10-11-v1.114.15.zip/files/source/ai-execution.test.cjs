'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),http=require('node:http'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),vm=require('node:vm');
const Execution=require('./ai-execution.cjs'),Client=require('./ai-client.cjs'),Store=require('./ai-conversation-store.cjs');
const sse=packets=>packets.map(p=>'data: '+JSON.stringify(p)+'\n\n').join('');
async function server(t,handler){const s=http.createServer(handler);await new Promise(r=>s.listen(0,'127.0.0.1',r));t.after(()=>{s.closeAllConnections();s.close();});return 'http://127.0.0.1:'+s.address().port;}
test('multi-round progress, reasoning and actual tool status remain ordered without log context injection',async()=>{
 const turn={status:'running'},call={id:'create-1',name:'create_project_file',arguments:JSON.stringify({path:'中文 空格/random.py',content:'SECRET FILE BODY'})};
 const result=await Execution.request(turn,async c=>{c.onEvent({id:'r',type:'reasoning',kind:'summary',text:'检查目录'});c.onEvent({id:'m',type:'message',text:'开始创建文件'});c.onEvent({id:'tool:create-1',type:'tool',...call,callId:call.id});return {text:'开始创建文件',reasoning:'检查目录',toolCalls:[call]};});
 assert.equal(turn.answer,'');assert.equal(turn.execution.find(e=>e.type==='tool').status,'preparing');let finish;const wait=new Promise(r=>finish=r);const job=Execution.tool(turn,call,()=>wait);assert.equal(turn.execution.find(e=>e.type==='tool').status,'running');finish({created:true,path:'中文 空格/random.py'});await job;
 await Execution.request(turn,async c=>{c.onEvent({id:'r',type:'reasoning',kind:'summary',text:'核对结果'});c.onEvent({id:'m',type:'message',phase:'final_answer',text:'文件已创建'});return {text:'文件已创建',reasoning:'核对结果'};});
 const shown=turn.execution.filter(e=>e.type!=='model').map(e=>[e.type,e.text||e.status]);assert.deepEqual(shown,[['reasoning','检查目录'],['progress','开始创建文件'],['tool','success'],['reasoning','核对结果'],['answer','文件已创建']]);assert.equal(turn.reasoning,'检查目录\n\n核对结果');assert.ok(!JSON.stringify(turn.execution).includes('SECRET FILE BODY'));
 const continued=Client.continueTools([{role:'user',content:'创建文件'}],result,[{created:true,path:'中文 空格/random.py'}]);assert.ok(!JSON.stringify(continued).includes('execution'));assert.equal(continued[1].reasoning_content,'检查目录');
});
test('Responses event IDs reconcile delta, done and final snapshot with independent message phases',async t=>{
 const packets=[{type:'response.output_item.added',item:{id:'reason',type:'reasoning'}},{type:'response.reasoning_summary_text.delta',item_id:'reason',summary_index:0,sequence_number:1,delta:'摘要'}, {type:'response.reasoning_summary_text.delta',item_id:'reason',summary_index:0,sequence_number:1,delta:'摘要'}, {type:'response.reasoning_summary_text.done',item_id:'reason',summary_index:0,text:'摘要'}, {type:'response.output_item.added',item:{id:'progress',type:'message',phase:'commentary'}}, {type:'response.output_text.delta',item_id:'progress',content_index:0,delta:'正在处理'}, {type:'response.output_item.added',item:{id:'final',type:'message',phase:'final_answer'}}, {type:'response.output_text.delta',item_id:'final',content_index:0,delta:'答'}, {type:'response.output_text.done',item_id:'final',content_index:0,text:'答案'}, {type:'response.completed',response:{status:'completed',output:[{id:'reason',type:'reasoning',encrypted_content:'ENCRYPTED',summary:[{type:'summary_text',text:'摘要'}]},{id:'progress',type:'message',phase:'commentary',content:[{type:'output_text',text:'正在处理'}]},{id:'final',type:'message',phase:'final_answer',content:[{type:'output_text',text:'答案'}]}]}}];
 const url=await server(t,(q,r)=>{q.resume();r.writeHead(200,{'content-type':'text/event-stream'});r.end(sse(packets));});const turn={},client=new Client(require);await Execution.request(turn,c=>client.request({protocol:'openai-responses',model:'mock',url},'',[],c));assert.equal(turn.answer,'答案');assert.equal(turn.reasoning,'摘要');assert.deepEqual(turn.execution.filter(e=>e.type!=='model').map(e=>e.type),['reasoning','progress','answer']);assert.ok(!JSON.stringify(turn.execution).includes('ENCRYPTED'));
});
test('summary auto preserves model/effort; an explicit unsupported parameter is retried without summary only',async t=>{
 const requests=[];const url=await server(t,(q,r)=>{let b='';q.on('data',c=>b+=c);q.on('end',()=>{const body=JSON.parse(b);requests.push(body);r.setHeader('content-type','application/json');if(body.reasoning?.summary){r.statusCode=400;r.end(JSON.stringify({error:{message:'Unsupported parameter: reasoning.summary',param:'reasoning.summary',code:'unsupported_parameter'}}));}else r.end(JSON.stringify({output:[{id:'final',type:'message',content:[{type:'output_text',text:'正常回答'}]}]}));});});
 const profile={model:'gpt-6.1-sol',protocol:'openai-responses',reasoningEffort:'high',url},client=new Client(require),turn={};await Execution.request(turn,c=>client.request(profile,'',[],c));assert.equal(turn.answer,'正常回答');assert.equal(requests.length,2);assert.deepEqual(requests[0].reasoning,{effort:'high',summary:'auto'});assert.deepEqual(requests[1].reasoning,{effort:'high'});assert.ok(requests.every(r=>r.model===profile.model));assert.equal(turn.execution.filter(e=>e.type==='reasoning').length,0);await client.request(profile,'',[]);assert.equal(requests.length,3);assert.equal(requests[2].reasoning.summary,undefined);
});
test('unrelated errors never trigger summary retries; no summaries are fabricated',async t=>{
 let calls=0;const url=await server(t,(q,r)=>{calls++;q.resume();r.writeHead(401,{'content-type':'application/json'});r.end(JSON.stringify({error:{message:'Authentication failed'}}));});const turn={};await assert.rejects(Execution.request(turn,c=>new Client(require).request({model:'gpt-6.1-sol',protocol:'openai-responses',url},'',[],c)));assert.equal(calls,1);assert.equal(turn.execution[0].status,'failed');assert.equal(turn.execution.some(e=>e.type==='reasoning'),false);
});
test('tool failure, cancellation and completed side effects have distinct outcomes',async()=>{
 const turn={},call={id:'x',name:'create_project_file',arguments:'{"path":"a.py","content":"abc"}'};await Execution.tool(turn,call,async()=>({error:'目录不可写'}));assert.equal(turn.execution[0].status,'failed');
 const controller=new AbortController();controller.abort();await assert.rejects(Execution.tool(turn,{...call,id:'y'},()=>{throw Error('must not run');},{signal:controller.signal}),{name:'AbortError'});assert.equal(turn.execution[1].status,'cancelled');
 await Execution.tool(turn,{...call,id:'z'},async()=>({created:true,path:'a.py'}));Execution.finish(turn,'stopped');assert.equal(turn.execution[2].status,'success');assert.ok(turn.execution.every(e=>Number.isFinite(e.endedAt)));
});
test('stopped streaming keeps partial progress and cancels pending calls without claiming execution',async()=>{
 const turn={};await assert.rejects(Execution.request(turn,async c=>{c.onEvent({id:'r',type:'reasoning',kind:'summary',text:'已收到摘要'});c.onEvent({id:'c',callId:'c',type:'tool',name:'create_project_file',arguments:'{}'});throw Object.assign(Error('已停止'),{name:'AbortError'});}));assert.equal(turn.execution.find(e=>e.type==='reasoning').text,'已收到摘要');assert.equal(turn.execution.find(e=>e.type==='tool').status,'cancelled');
});
test('execution records roundtrip through store; sensitive headers and encrypted extras are removed',t=>{
 const base=path.join(os.homedir(),'Downloads','codex-temp'),dir=fs.mkdtempSync(path.join(base,'execution-test-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));const store=new Store(require,dir),events=[{id:'a',round:1,type:'tool',name:'web_search',status:'success',startedAt:1,endedAt:2,parameters:'query',result:'Authorization: Bearer TOP_SECRET',headers:{'x-api-key':'KEY'},encrypted_content:'ENCRYPTED'}];const record=store.write({id:store.id(),turns:[{execution:events,status:'done',answer:'结果'}]},null);const got=store.read(record.id).turns[0].execution;assert.equal(got[0].status,'success');assert.equal(got[0].endedAt,2);assert.ok(!/TOP_SECRET|ENCRYPTED|"headers"/.test(JSON.stringify(got)));assert.deepEqual(Execution.snapshot([{id:'pending',type:'tool',status:'running',startedAt:3}],{interrupted:true})[0].status,'cancelled');
});
test('final code examples remain text and never create command records',async()=>{const turn={};await Execution.request(turn,async c=>{c.onText('运行示例：\n\n\x60\x60\x60sh\npython demo.py\n\x60\x60\x60');return {text:'运行示例：\n\n\x60\x60\x60sh\npython demo.py\n\x60\x60\x60'};});assert.ok(turn.answer.includes('python demo.py'));assert.equal(turn.execution.some(e=>e.type==='tool'),false);});
test('default file opening uses system app for every file type and reports bridge errors',async()=>{const paths=[],UI=vm.runInNewContext(fs.readFileSync(path.join(__dirname,'ai-references.js'),'utf8')+';EditingToolbarAIReferences',{reqnode:()=>({shell:{openPath:async p=>{paths.push(p);return p.endsWith('bad')?'no association':'';}}})}),ui=Object.create(UI.prototype);for(const p of ['C:\\中文 路径\\demo.py','C:\\docs\\note.md','C:\\image.png'])await ui.openFile({path:p});assert.equal(paths.length,3);await assert.rejects(ui.openFile({path:'bad'}),/默认应用/);});

test('nonstream Responses preserves interleaved output order and final answers are not log-truncated',async t=>{
 const output=[{id:'p',type:'message',phase:'commentary',content:[{type:'output_text',text:'先检查'}]},{id:'r',type:'reasoning',summary:[{type:'summary_text',text:'检查摘要'}]},{id:'f',type:'function_call',call_id:'c',name:'read_current_document',arguments:'{}'}];
 const url=await server(t,(q,r)=>{q.resume();r.writeHead(200,{'content-type':'application/json'});r.end(JSON.stringify({output}));});const turn={};await Execution.request(turn,c=>new Client(require).request({protocol:'openai-responses',model:'mock',url,documentEdit:true},'',[],c));assert.deepEqual(turn.execution.filter(e=>e.type!=='model').map(e=>e.type),['progress','reasoning','tool']);
 const answer='完整答案'.repeat(6000);await Execution.request(turn,async c=>{c.onEvent({id:'f',type:'message',phase:'final_answer',text:answer});return {text:answer};});assert.equal(turn.answer,answer);assert.ok(turn.execution.at(-1).text.length<=16000);
});

test('Anthropic content blocks keep text, tool and thinking order without exposing signatures',async t=>{
 const content=[{type:'text',text:'先读取'},{type:'tool_use',id:'c',name:'read_current_document',input:{}},{type:'thinking',thinking:'可显示内容',signature:'PRIVATE_SIGNATURE'},{type:'text',text:'再检查'}];
 const url=await server(t,(q,r)=>{q.resume();r.writeHead(200,{'content-type':'application/json'});r.end(JSON.stringify({content,stop_reason:'tool_use'}));});const turn={};await Execution.request(turn,c=>new Client(require).request({protocol:'anthropic-messages',model:'mock',url,documentEdit:true},'',[],c));assert.deepEqual(turn.execution.filter(e=>e.type!=='model').map(e=>e.type),['progress','tool','reasoning','progress']);assert.equal(turn.reasoning,'可显示内容');assert.ok(!JSON.stringify(turn.execution).includes('PRIVATE_SIGNATURE'));assert.deepEqual(Execution.snapshot([null,0,[],{id:'ok',type:'progress'}]).map(e=>e.id),['ok']);
});

test('reasoning delivered only on item completion survives an empty final snapshot',async t=>{
 const packets=[{type:'response.output_item.done',item:{id:'r',type:'reasoning',encrypted_content:'PRIVATE',summary:[{type:'summary_text',text:'完成摘要'}]}},{type:'response.output_text.delta',item_id:'m',delta:'回答'},{type:'response.completed',response:{status:'completed',output:[]}}];
 const url=await server(t,(q,r)=>{q.resume();r.writeHead(200,{'content-type':'text/event-stream'});r.end(sse(packets));});const turn={};await Execution.request(turn,c=>new Client(require).request({protocol:'openai-responses',model:'mock',url},'',[],c));assert.equal(turn.reasoning,'完成摘要');assert.equal(turn.answer,'回答');assert.ok(!JSON.stringify(turn.execution).includes('PRIVATE'));
});

test('log sanitization never rewrites final code examples',async()=>{
 const text='示例：\nAuthorization: Bearer EXAMPLE_TOKEN\npassword: example',turn={};await Execution.request(turn,async c=>{c.onEvent({id:'m',type:'message',phase:'final_answer',text});return {text};});assert.equal(turn.answer,text);assert.ok(!turn.execution.find(e=>e.type==='answer').text.includes('EXAMPLE_TOKEN'));
});

test('partial code arguments display only available metadata, never undefined or edit bodies',()=>{
 for(const name of ['read_code_file','edit_code_file','run_python_file']){
  const summary=Execution.arguments({name,arguments:'{"summary":"清除注释","edits":[{"old_text":"PRIVATE_BODY"'});assert.equal(summary,'清除注释');
  const fileFirst=Execution.arguments({name,arguments:'{"file":"C:/code/main.py","edits":['});assert.equal(fileFirst,'C:/code/main.py');
  assert.equal(Execution.arguments({name,arguments:'{}'}),'正在接收工具参数');
 }
});
test('stream disconnect marks incomplete tool arguments unexecuted and preserves completed writes',async()=>{
 const turn={};await Execution.tool(turn,{id:'applied',round:0,name:'edit_code_file',arguments:'{"file":"main.py"}'},async()=>({applied:true}));
 await assert.rejects(Execution.request(turn,async c=>{c.onEvent({type:'tool',id:'pending',callId:'pending',name:'edit_code_file',arguments:'{"summary":"more","edits":['});throw Error('连接提前结束');}),/连接提前结束/);
 assert.equal(turn.execution.find(e=>e.callId==='applied').status,'success');assert.equal(turn.execution.find(e=>e.callId==='pending').result,'参数未完整接收，此操作未执行');
});
