'use strict';
// One bounded AI tool call per ConPTY session; never inject commands into a user's shell.
class TerminalCommand {
 constructor(requireNode,session,Shell){this.req=requireNode;this.session=session;this.Shell=Shell;}
 static text(raw){return raw.replace(/\x1b\][\s\S]*?(?:\x07|\x1b\\)/g,'').replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'').replace(/\x1b[()][0-2A-Z]/g,'').replace(/\r\n/g,'\n').replace(/\r/g,'\n');}
 static script(command){return `$ErrorActionPreference='Stop'\n$ProgressPreference='SilentlyContinue'\n$OutputEncoding=[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)\ntry {\n$global:LASTEXITCODE=0\n& {\n${command}\n} | Out-Default\n$ok=$?\nif($global:LASTEXITCODE -ne 0){exit $global:LASTEXITCODE}\nif(-not $ok){exit 1}\nexit 0\n}catch{[Console]::Error.WriteLine($_.ToString());exit 1}`;}
 async run(args,{cwd,host,env,hidden=[],signal,timeoutMs=120000,onUpdate=()=>{}}){
  const s=this.session,Shell=this.Shell;if(signal?.aborted)throw Shell.abort();
  const decoder=new (this.req('string_decoder').StringDecoder)('utf8'),startedAt=Date.now(),limit=1024*1024;
  let raw='',bytes=0,reason='',done=false,timer,emitTimer,lastEmit=0;
  const view=final=>{const text=TerminalCommand.text(raw),safe=final?Shell.scrub(text,hidden):Shell.liveText(text,hidden);return {command:Shell.bounded(Shell.scrub(args.command,hidden),7000),commandChars:args.command.length,commandTruncated:args.command.length>7000,description:Shell.scrub(args.description||'',hidden),workdir:cwd,output:Shell.bounded(safe,64000),outputTruncated:bytes>limit||safe.length>64000,timeoutMs,elapsedMs:Date.now()-startedAt};};
  const emit=final=>{clearTimeout(emitTimer);emitTimer=null;lastEmit=Date.now();try{onUpdate(view(final));}catch{}};
  const stop=why=>{if(done||reason)return;reason=why;s.stop();};
  const staged=await Shell.stageScript(this.req,TerminalCommand.script(args.command));
  try{if(signal?.aborted)throw Shell.abort();return await new Promise((resolve,reject)=>{
   const oldState=s.options.onState,abort=()=>stop('cancelled');
   const finish=error=>{if(done)return;done=true;clearTimeout(timer);clearTimeout(emitTimer);signal?.removeEventListener('abort',abort);raw+=decoder.end();emit(true);const state={...view(true),exitCode:s.exitCode??null,timedOut:reason==='timeout',outputLimit:reason==='limit'};
    if(reason==='cancelled')return reject(Object.assign(Shell.abort(),{result:state}));if(error)return reject(Object.assign(Error(Shell.scrub(error.message,hidden)),{result:state}));
    const problem=reason==='timeout'?'命令超过时间限制，已终止进程树':reason==='limit'?'命令输出超过 1 MiB，已终止进程树':state.exitCode!==0?'命令退出码 '+state.exitCode:null;
    resolve({...state,output:Shell.bounded(state.output,16000),...(problem?{error:problem}:{})});
   };
   s.options.onData=(data,ack)=>{bytes+=data.length;if(bytes<=limit)raw+=decoder.write(data);else stop('limit');ack();if(Date.now()-lastEmit>=100)emit(false);else if(!emitTimer)emitTimer=setTimeout(()=>emit(false),100);};
   s.options.onState=(...v)=>{oldState?.(...v);if(v[0]==='exited')finish(s.error);};
   s.options.onError=error=>{s.error=error;};
   signal?.addEventListener('abort',abort,{once:true});timer=setTimeout(()=>stop('timeout'),timeoutMs);emit(false);
   s.start({host,profile:'powershell',cwd,environment:env,command:staged.command,cols:180,rows:32}).then(()=>{if(reason||signal?.aborted){reason||='cancelled';s.stop();}}).catch(error=>{s.stop();finish(error);});
  });}finally{await staged.dispose();}
 }
}
module.exports={TerminalCommand};
