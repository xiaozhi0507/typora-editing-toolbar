const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
function browser(){const box={window:{addEventListener(){}},URL,setTimeout,clearTimeout};vm.createContext(box);vm.runInContext(fs.readFileSync(path.join(__dirname,'ai-web-chat-browser.js'),'utf8')+';globalThis.B=EditingToolbarWebChatBrowser;',box);return new box.B({});}
function fixture(){const b=browser(),f={stamp:'cookie-A',documentId:'doc1',key:'A',reads:0,invalidations:0};b.ai.webChat={projects:{invalidate(){f.invalidations++;}}};b.events=async action=>action==='scope-hint'?{stamp:f.stamp,documentId:f.documentId}:(f.reads++,f.response?f.response():{status:'verified',key:f.key});return {b,f};}
const deferred=()=>{let resolve;return {promise:new Promise(r=>resolve=r),resolve:v=>resolve(v)};};
test('concurrent identity requests coalesce and warm reads do not fetch session again',async()=>{
 const {b,f}=fixture(),result=deferred();f.response=()=>result.promise;const reads=[b.scope(),b.scope(),b.scope()];await new Promise(setImmediate);assert.equal(f.reads,1);result.resolve({status:'verified',key:'A'});assert.deepEqual(await Promise.all(reads),['A','A','A']);assert.equal(await b.scope(),'A');assert.equal(f.reads,1);
});
test('soft expiry returns immediately while a single background revalidation is pending',async()=>{
 const {b,f}=fixture();await b.scope();b.scopeCache.at-=16000;const result=deferred();f.response=()=>result.promise;assert.equal(await b.scope(),'A');assert.equal(await b.scope(),'A');assert.equal(f.reads,2);result.resolve({status:'verified',key:'A'});await new Promise(setImmediate);assert.ok(Date.now()-b.scopeCache.at<1000);
});
test('hard expiry does not extend trusted cache when session lookup becomes unavailable',async()=>{
 const {b,f}=fixture();await b.scope();b.scopeCache.at-=61000;f.response=()=>({status:'unavailable'});assert.equal(await b.scope(),'');assert.equal(await b.scope(),'');assert.equal(f.reads,2);assert.equal(b.principal,'A');assert.equal(f.invalidations,0);assert.equal(b.differentScope('A',''),false);
});
test('new page revalidates once and unknown result keeps principal without false account change',async()=>{
 const {b,f}=fixture();await b.scope();f.documentId='doc2';f.response=()=>({status:'unavailable',reason:'incomplete'});assert.equal(await b.scope(),'');assert.equal(await b.scope(),'');assert.equal(f.reads,2);assert.equal(b.principal,'A');assert.equal(f.invalidations,0);
});
test('cookie change invalidates membership cache; only verified new identity replaces principal',async()=>{
 const {b,f}=fixture();await b.scope();b.memberships.set('proof',{});f.stamp='cookie-B';f.response=()=>({status:'unavailable'});assert.equal(await b.scope(),'');assert.equal(b.memberships.size,0);assert.equal(b.principal,'A');f.response=null;f.key='B';assert.equal(await b.scope({force:true}),'B');assert.equal(b.principal,'B');assert.equal(b.differentScope('A','B'),true);
});
test('logout invalidation cannot be undone by pending identity lookup',async()=>{
 const {b,f}=fixture(),result=deferred();f.response=()=>result.promise;const waiting=b.scope();await new Promise(setImmediate);b.invalidateScope();result.resolve({status:'verified',key:'A'});assert.equal(await waiting,'');assert.equal(b.principal,'');assert.equal(b.scopeCache,null);
});
test('temporary identity outage after routing still requires exact project membership and target URL',async()=>{
 const project='https://chatgpt.com/g/g-p-p/project',chat='https://chatgpt.com/g/g-p-p/c/c',b=browser();let scope='A',routes=0;b.scope=async()=>scope;b.projectChats=async()=>[{url:chat}];b.ensure=async()=>({url:project});b.settleConversation=async x=>x;b.navigateTarget=async url=>{routes++;scope='';return{url};};
 assert.equal((await b.projectRoute({enabled:true,scope:'A',project:{url:project},chat:{url:chat}})).url,chat);assert.equal(routes,1);assert.equal(b.memberships.size,0);
 scope='A';await assert.rejects(b.projectRoute({enabled:true,scope:'A',project:{url:project},chat:{url:'https://chatgpt.com/c/wrong'}}),/所选聊天/);assert.equal(routes,1);
 scope='A';b.navigateTarget=async url=>{scope='B';return{url};};await assert.rejects(b.projectRoute({enabled:true,scope:'A',project:{url:project},chat:{url:chat}}),/账号或工作区/);
 scope='A';await assert.rejects(b.projectRoute({enabled:true,scope:'A',project:{url:project},chat:null}),/账号或工作区/);
});
