'use strict';
function protect(requireNode,value,decrypt=false) {
    const { Buffer } = requireNode('buffer');
    const bytes=Buffer.byteLength(String(value),'utf8');
    if(bytes>(decrypt?32:16)*1024**2)return Promise.reject(Object.assign(Error('本机加密数据超过大小限制，原有文件已保留'),{code:'LOCAL_PROTECTION_LIMIT'}));
    const script = "$ErrorActionPreference='Stop';Add-Type -AssemblyName System.Security;try {$b=[Convert]::FromBase64String([Console]::In.ReadToEnd());$r=[Security.Cryptography.ProtectedData]::" + (decrypt ? 'Unprotect' : 'Protect') + "($b,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser);[Console]::Out.Write([Convert]::ToBase64String($r))}catch{exit 1}";
    return new Promise((resolve, reject) => {
      const child = requireNode('child_process').execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { windowsHide: true, timeout: 30000, maxBuffer: 32*1024**2 }, (error, stdout) => {
        if (error) return reject(Object.assign(Error(decrypt ? '无法解密本机加密数据，原有文件已保留，请检查当前 Windows 用户后重试' : '无法加密保存本机数据，原有文件已保留，请重试'),{code:'LOCAL_PROTECTION_FAILED'}));
        resolve(decrypt ? Buffer.from(stdout.trim(), 'base64').toString('utf8') : stdout.trim());
      });
      child.stdin.on('error', () => {});
      child.stdin.end(decrypt ? value : Buffer.from(value, 'utf8').toString('base64'));
    });
  }
module.exports=protect;
