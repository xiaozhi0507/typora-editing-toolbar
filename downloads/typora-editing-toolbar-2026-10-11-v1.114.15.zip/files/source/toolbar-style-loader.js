// Shared by the head bootstrap and the main plugin. Start one stylesheet request
// early, and mount plugin UI only after the browser has applied that stylesheet.
function ensureEditingToolbarStyle(href) {
    let link = document.getElementById('editing-toolbar-style');
    const pending = window.__etToolbarStyle;
    if (pending && pending.link === link) return pending.ready;
    if (!link) {
        link = document.createElement('link');
        link.id = 'editing-toolbar-style';
        link.rel = 'stylesheet';
        link.href = href;
    }
    let resolve;
    const ready = new Promise(done => { resolve = done; });
    window.__etToolbarStyle = { link, ready };
    const finish = loaded => {
        link.removeEventListener('load', onLoad);
        link.removeEventListener('error', onError);
        if (loaded) performance.mark('et-toolbar-style-ready');
        else console.warn('[EditingToolbar] Stylesheet unavailable; toolbar was not mounted.');
        resolve(loaded);
    };
    const onLoad = () => finish(true);
    const onError = () => finish(false);
    link.addEventListener('load', onLoad);
    link.addEventListener('error', onError);
    if (!link.isConnected) {
        // Keep saved palette overrides after the base stylesheet in the cascade.
        document.head.insertBefore(link, document.getElementById('et-theme-palette-overrides'));
    }
    if (link.sheet) finish(true);
    return ready;
}
