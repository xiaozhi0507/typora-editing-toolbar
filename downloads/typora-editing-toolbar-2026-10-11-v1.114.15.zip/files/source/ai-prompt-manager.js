class EditingToolbarPromptManager {
  constructor(ai) { this.ai = ai; ai.config.prompts = ETAIPrompts.normalize(ai.config.prompts); }
  mount() {
    const a = this.ai, p = a.node('div', 'et-ai-prompt-manager'); p.hidden = true;
    p.innerHTML = `
      <div class="et-ai-prompt-list"><div class="et-ai-prompt-table-wrap"><table class="et-ai-prompt-table"><thead><tr><th>名称</th><th>范围</th><th>提示词</th></tr></thead><tbody></tbody></table></div><div class="et-ai-prompt-list-actions"><button data-pm="up" title="上移" aria-label="上移提示词">↑</button><button data-pm="down" title="下移" aria-label="下移提示词">↓</button><span></span><button data-pm="edit">编辑</button><button data-pm="add">＋ 新增</button><button data-pm="use" class="et-ai-primary">使用</button></div></div>
      <form class="et-ai-prompt-editor" hidden><div class="et-ai-prompt-fields"><label>名称<input name="promptName" maxlength="60" required></label><label>作用范围<select name="promptType"></select></label><small class="et-ai-type-hint"></small><label class="et-ai-prompt-content-label">提示词<textarea name="promptContent" maxlength="16000" required></textarea></label></div><div class="et-ai-prompt-editor-actions"><button type="button" data-pm="delete">删除</button><span></span><button type="button" data-pm="cancel">取消</button><button type="submit" class="et-ai-primary">保存</button></div></form>
`;
    a.preferencesStatus.before(p); this.panel = p; this.list = p.querySelector('.et-ai-prompt-list'); this.form = p.querySelector('form');
    for (const [id, name] of ETAIPrompts.types) this.form.elements.promptType.append(new Option(name, id));
    this.form.elements.promptType.onchange = () => this.typeHint();
    this.form.onsubmit = e => { e.preventDefault(); this.save(); };
    p.addEventListener('click', e => { const b = e.target.closest('[data-pm]'); if (b && !b.disabled) this.act(b.dataset.pm); });
    this.contextTools = a.node('div', 'et-ai-context-tools'); a.contextPreview.before(this.contextTools);
    this.render();
  }
  act(action) {
    if (action === 'back') this.ai.settings(false);
    if (action === 'add') this.edit();
    if (action === 'edit') this.edit(this.selected);
    if (action === 'cancel') this.open();
    if (action === 'up' || action === 'down') this.move(action === 'up' ? -1 : 1);
    if (action === 'delete') this.remove();
    if (action === 'use') this.use(this.selected);
  }
  open(reset = true) {
    const a = this.ai; if (a.busy || a.settingsBusy) return;
    a.settings(true,'prompts');
    if(reset) { this.form.hidden = true; this.list.hidden = false; }
    this.render();
  }
  render() {
    if (!this.panel) return;
    const rows = this.ai.config.prompts, body = this.panel.querySelector('tbody');
    if (!rows.some(p => p.id === this.selected)) this.selected = rows[0]?.id;
    body.replaceChildren();
    for (const p of rows) {
      const type = ETAIPrompts.types.find(t => t[0] === p.type)[1], row = this.ai.node('tr');
      row.dataset.promptId = p.id; row.tabIndex = 0; row.setAttribute('aria-selected', String(p.id === this.selected));
      for (const text of [p.name, type, p.prompt]) { const cell = this.ai.node('td', '', text); cell.title = text; row.append(cell); }
      const select = () => { this.selected = p.id; this.updateSelection(); };
      row.onclick = select; row.ondblclick = () => this.edit(p.id);
      row.onkeydown = e => { if (['Enter', ' '].includes(e.key)) { e.preventDefault(); select(); if (e.key === 'Enter') this.edit(p.id); } };
      body.append(row);
    }
    if (!rows.length) { const row = this.ai.node('tr'), cell = this.ai.node('td', '', '还没有提示词，点击“新增”创建。'); cell.colSpan = 3; row.append(cell); body.append(row); }
    this.ai.composerUI.refresh(); this.updateSelection();
  }
  updateSelection() {
    for (const row of this.panel.querySelectorAll('[data-prompt-id]')) row.setAttribute('aria-selected', String(row.dataset.promptId === this.selected));
    const at = this.ai.config.prompts.findIndex(p => p.id === this.selected);
    for (const name of ['edit', 'use', 'up', 'down']) this.panel.querySelector('[data-pm="' + name + '"]').disabled = at < 0 || name === 'up' && at === 0 || name === 'down' && at === this.ai.config.prompts.length - 1;
  }
  commit(rows) {
    try { const config = { ...this.ai.config, prompts: rows }; localStorage.setItem(this.ai.configKey, JSON.stringify(config)); this.ai.config = config; return true; }
    catch { this.ai.notice('提示词未能保存，请检查本地存储空间', true); return false; }
  }
  edit(id) {
    const p = this.ai.config.prompts.find(p => p.id === id); this.editId = p?.id || '';
    this.list.hidden = true; this.form.hidden = false;
    this.form.elements.promptName.value = p?.name || ''; this.form.elements.promptType.value = p?.type || 'text'; this.form.elements.promptContent.value = p?.prompt || '';
    const del = this.panel.querySelector('[data-pm="delete"]'); del.hidden = !p; del.textContent = '删除'; delete del.dataset.confirm;
    this.typeHint(); this.form.elements.promptName.focus();
  }
  typeHint() { this.panel.querySelector('.et-ai-type-hint').textContent = ETAIPrompts.types.find(t => t[0] === this.form.elements.promptType.value)[2]; }
  save() {
    const f = this.form.elements, p = { id: this.editId || 'prompt-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7), name: f.promptName.value.trim(), type: f.promptType.value, prompt: f.promptContent.value.trim() };
    if (!p.name || !p.prompt) return this.ai.notice('请填写名称和提示词', true);
    const rows = this.ai.config.prompts.slice(), at = rows.findIndex(x => x.id === p.id); if (at < 0) rows.push(p); else rows[at] = p;
    if (!this.commit(rows)) return; this.selected = p.id; this.open(); this.ai.notice('提示词已保存');
  }
  move(delta) {
    const rows = this.ai.config.prompts.slice(), at = rows.findIndex(p => p.id === this.selected); if (at < 0 || !rows[at + delta]) return;
    [rows[at], rows[at + delta]] = [rows[at + delta], rows[at]]; if (this.commit(rows)) { this.render(); this.panel.querySelector('[aria-selected="true"]')?.scrollIntoView({ block: 'nearest' }); }
  }
  remove() {
    const b = this.panel.querySelector('[data-pm="delete"]'); if (!b.dataset.confirm) { b.dataset.confirm = 'true'; b.textContent = '确认删除'; return; }
    if (this.commit(this.ai.config.prompts.filter(p => p.id !== this.editId))) { this.open(); this.ai.notice('提示词已删除'); }
  }
  use(id) {
    const a=this.ai,p=a.config.prompts.find(p=>p.id===id);if(!p||a.busy||a.settingsBusy)return;
    if(EditingToolbarAIComposer.isFree(p)){a.settings(false);a.composerUI.select(null);return;}
    if(!a.followDocument())return;
    if(p.type!=='quickFill'){
      if(!a.conversations.flush())return;a.composerUI.stageSource();a.capture();
      a.scope.value=ETAIPrompts.scopes[p.type];this.renderContextTools();a.updateContext();
    }else a.composerUI.restoreSource();
    a.settings(false);a.composerUI.select(p);
  }
  captureContext(context, range) {
    const sections = ETAIPrompts.sections(context.markdown); context.sections = sections;
    let offset = 0;
    if (File.editor.sourceView?.inSourceMode) offset = File.editor.sourceView.cm.indexFromPos(File.editor.sourceView.cm.getCursor());
    else {
      const headings = [...document.querySelectorAll('#write h1,#write h2,#write h3,#write h4,#write h5,#write h6')];
      let index = -1;
      if (range?.startContainer?.isConnected) { for (let i = 0; i < headings.length; i++) if (headings[i].contains(range.startContainer) || headings[i].compareDocumentPosition(range.startContainer) & Node.DOCUMENT_POSITION_FOLLOWING) index = i; }
      else { const top = document.querySelector('content')?.getBoundingClientRect().top || 0; for (let i = 0; i < headings.length; i++) if (headings[i].getBoundingClientRect().top <= top + 120) index = i; }
      offset = sections[Math.max(0, index)]?.start || 0;
    }
    context.sectionId = sections.filter(s => s.start <= offset).at(-1)?.id || sections[0]?.id || '';
    context.sectionIds = context.sectionId ? [context.sectionId] : [];
    const m = this.ai.toolbar.documentNotes;
    try { m._switchDocument(); m._flushEditor(); context.notes = (m.ctx?.notes || []).map(n => ({ id: n.id, title: n.title, markdown: n.markdown })); context.noteId = m.ctx?.selected || context.notes[0]?.id || ''; } catch { context.notes = []; }
    this.renderContextTools();
  }
  reference() {
    const a = this.ai, c = a.context, scope = a.scope.value; if (!c) return { text: '', label: '' };
    if(a.attachments.frozen&&!a.composerUI.hasSourceDraft())return a.attachments.frozen;
    const sections = c.sections || [], names = { selection: '选中文字', document: '全文', none: '自由提问', abstract: '摘要', section: '当前章节', sections: '多个章节', note: '笔记', image: '图片' };
    let text = '', detail = '', image;
    if (scope === 'selection') text = c.selected;
    if (scope === 'document') text = c.markdown;
    if (scope === 'abstract') text = ETAIPrompts.abstract(c.markdown, sections);
    if (scope === 'section' || scope === 'sections') { const ids = scope === 'section' ? [c.sectionId] : c.sectionIds || []; text = ETAIPrompts.excerpt(c.markdown, sections, ids); detail = sections.filter(s => ids.includes(s.id)).map(s => s.title).join('、'); }
    if (scope === 'note') { const n = c.notes?.find(n => n.id === c.noteId); text = n?.markdown || ''; detail = n?.title || ''; }
    if (scope === 'image') { image = c.image; detail = image?.name || ''; }
    return { text, image, label: c.label + ' / ' + names[scope] + (detail ? ' / ' + detail : ''), name: names[scope], detail };
  }
  renderContextTools() {
    if (!this.contextTools || !this.ai.context) return;
    const a = this.ai, c = a.context, scope = a.scope.value, root = this.contextTools; root.replaceChildren(); root.classList.remove('et-ai-image-tools'); root.hidden = true;
    const update = () => {a.composerUI.markSourceChanged();a.updateContext();a.conversations.schedule();};
    if (['section', 'note'].includes(scope)) {
      root.hidden = false; const s = a.node('select'); s.setAttribute('aria-label', scope === 'section' ? '选择章节' : '选择笔记');
      const items = scope === 'section' ? c.sections : c.notes;
      for (const item of items || []) s.append(new Option((scope === 'section' ? '　'.repeat(item.level - 1) : '') + item.title, item.id));
      if (!s.options.length) s.append(new Option(scope === 'section' ? '当前文档没有章节标题' : '当前文档没有笔记', ''));
      const key = scope === 'section' ? 'sectionId' : 'noteId'; s.value = c[key] || ''; s.onchange = () => { c[key] = s.value; update(); }; root.append(s);
    }
    if (scope === 'sections') {
      root.hidden = false; const details = a.node('details'), summary = a.node('summary', '', '选择章节'); details.append(summary);
      if (!c.sections?.length) details.append(a.node('small', '', '当前文档没有章节标题'));
      for (const s of c.sections || []) { const label = a.node('label'), box = a.node('input'); box.type = 'checkbox'; box.value = s.id; box.checked = c.sectionIds?.includes(s.id); box.onchange = () => { c.sectionIds = [...details.querySelectorAll('input:checked')].map(b => b.value); update(); }; label.append(box, a.node('span', '', s.title)); details.append(label); }
      root.append(details);
    }
    if (scope === 'image') a.imagesUI.mount(root);
    this.lockContext();
  }
  lockContext() { const disabled = this.ai.scopeLocked(); for (const el of this.contextTools?.querySelectorAll('input,select,button') || []) if(!el.dataset.imageReadonly) el.disabled = disabled; this.ai.imagesUI.sync(); }
}
