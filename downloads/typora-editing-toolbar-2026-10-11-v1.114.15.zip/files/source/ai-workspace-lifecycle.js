// Development tools are owned by one AI-module activation, including their drafts and processes.
class EditingToolbarAIWorkspace {
 constructor(host){
  this.host=host;this.toolbar=host.toolbar;this.pending=new Set();this.saved=host.workspaceState();
  const t=this.toolbar;
  this.code=t.codeEditor=new EditingToolbarCodeEditor(t);this.code.moduleRoot=host.directory;
  this.notebook=t.notebook=new EditingToolbarNotebook(t);
  this.terminal=t.terminal=new EditingToolbarTerminal(t);this.terminal.moduleRoot=host.directory;
  this.projects=new EditingToolbarProjects(t.documentTabs);
  for(const [kind,editor]of [['code',this.code],['notebook',this.notebook]]){
   const restore=editor.restoreDraft;
   editor.restoreDraft=r=>{const cached=this.saved[kind].get(editor.key(r.file));if(cached){const model=r.model;Object.assign(r,cached);if(model){r.model=model;model.setValue(cached.draft);}delete r.draft;this.saved[kind].delete(editor.key(r.file));return;}restore.call(editor,r);};
  }
  const watch=(owner,names)=>{for(const name of names){const fn=owner[name];if(typeof fn!=='function')continue;owner[name]=(...args)=>{if(this.closing)return Promise.resolve(false);const job=Promise.resolve().then(()=>fn.apply(owner,args));this.pending.add(job);job.then(()=>this.pending.delete(job),()=>this.pending.delete(job));return job;};}};
  watch(this.code,['ensureTerminal','open','saveAs','reload','close','forgetFiles','newPython']);
  watch(this.notebook,['open','save','saveAs','reload','writeAI','closeRecord','forgetFiles','create','edit']);
  watch(this.terminal,['newSession','newProjectSession']);
  watch(this.projects,['transferInto','moveInto','renameFolder','deleteFolder','persistProject','createManualFile','setOutputFolder']);
 }
 async prepare(){
  if(this.terminal.pythonManager?.busy)throw Error('Python 环境正在安装，请完成或取消后再切换 AI 阅读助手');
  const deadline=Date.now()+5000;while(this.pending.size&&Date.now()<deadline)await new Promise(resolve=>this.host.delay(resolve,100));
  if(this.pending.size||this.code.openingFile||this.toolbar.documentTabs.projectMoveDepth||[...this.notebook.records.values()].some(r=>r.saving||r.writing))throw Error('文件操作尚未完成，请稍后再切换 AI 阅读助手');
  this.notebook.finishEditing();this.checkpoint(true);
 }
 checkpoint(strict=false){
  this.code.persistDrafts(strict);this.notebook.persistDrafts(strict);
  for(const editor of [this.code,this.notebook])for(const r of editor.records.values())if(r.recovered?.source!==editor.draftFile)this.code.clearRecovered(r);
  this.snapshot();
 }
 recovery(editor,r){try{return {...JSON.parse(reqnode('fs').readFileSync(editor.draftPath(),'utf8')).find(row=>row.file===r.file),source:editor.draftPath()};}catch{return r.recovered;}}
 snapshot(){
  for(const r of this.code.records.values()){
   if(!this.code.dirty(r))continue;
   const {file,base,text,encoding,bom,eol,mode,recovered}=r;
   this.saved.code.set(this.code.key(file),{file,base,text,encoding,bom,eol,mode,recovered:this.recovery(this.code,r),draft:r.model.getValue(),problem:'已恢复停用前的代码草稿，请核对后保存。'});
  }
  for(const r of this.notebook.records.values()){
   if(!this.notebook.dirty(r))continue;
   const {file,base,saved,recovered,revision}=r;
   this.saved.notebook.set(this.notebook.key(file),{file,base,saved,recovered:this.recovery(this.notebook,r),revision,doc:ETNotebookStore.clone(r.doc),modified:true,problem:'已恢复停用前的 Notebook 草稿，请核对后保存。'});
  }
 }
 async stop(){
  this.closing=true;this.projects.disposed=true;++this.code.serial;++this.notebook.serial;
  this.projects.clearFileMove();this.toolbar.documentTabs.closeMenu?.();
  for(const session of [...this.terminal.sessions])this.terminal.closeSession(session);
  await Promise.allSettled([...this.notebook.records.values()].map(r=>this.notebook.shutdown(r)));
  this.notebook.finishEditing();this.checkpoint();
  this.code.hide();this.notebook.hide();this.terminal.flushAppearance();
  for(const dialog of document.querySelectorAll('.et-project-dialog'))dialog.close();
 }
 dispose(){
  if(this.disposed)return;this.disposed=true;this.snapshot();
  for(const r of this.code.records.values()){r.listener?.dispose();r.model?.dispose();}
  this.code.editor?.dispose();this.notebook.editor?.dispose();
  this.code.records.clear();this.notebook.records.clear();
  const t=this.toolbar;if(t.codeEditor===this.code)t.codeEditor=null;if(t.notebook===this.notebook)t.notebook=null;if(t.terminal===this.terminal)t.terminal=null;
  if(t.documentTabs.projects===this.projects)t.documentTabs.projects=null;
  t.documentTabs.fileSelection.clear();t.documentTabs.groupViews?.clear();t.documentTabs.signature='';t.documentTabs.render();
  document.body.classList.remove('et-code-workspace','et-notebook-workspace');
  document.documentElement.style.removeProperty('--et-terminal-height');t._applyTopPlacement();
 }
}
