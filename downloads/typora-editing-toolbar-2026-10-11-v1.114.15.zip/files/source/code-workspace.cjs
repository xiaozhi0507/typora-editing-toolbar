'use strict';
function owner(req,items,file){const path=req('path');return (items||[]).filter(p=>{if(!p.root)return false;const r=path.relative(p.root,file);return r!==''&&r!=='..'&&!r.startsWith('..'+path.sep)&&!path.isAbsolute(r);}).sort((a,b)=>b.root.length-a.root.length)[0]||null;}
async function context(req,Projects,items,file){
 const fs=req('fs').promises,path=req('path'),core=new Projects(req),project=owner(req,items,file);
 if(!path.isAbsolute(file))throw Error('请先保存代码文件');
 if(project)await core.existingFile(project,file);else if(!(await fs.stat(file)).isFile())throw Error('代码文件不存在');
 const root=project?.root||path.dirname(file),relative=project?.outputFolder||'',cwd=relative?await core.directory(project,core.segments(relative)):path.dirname(file);
 if(relative&&owner(req,items,path.join(cwd,'__output__'))?.id!==project.id)throw Error('输出文件夹属于另一个项目，请重新设置');
 return {file,cwd,root,projectId:project?.id||null,projectKey:path.resolve(root).toLowerCase(),output:relative?cwd:null,env:{ET_PROJECT_ROOT:root,ET_SCRIPT_DIR:path.dirname(file),ET_OUTPUT_DIR:cwd,PYTHONIOENCODING:'utf-8',PYTHONUTF8:'1'}};
}
function pythonCommand(exe,file){
 const quote=value=>"'"+String(value).replace(/'/g,"''")+"'";
 return "$ErrorActionPreference='Stop'\n$OutputEncoding=[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)\ntry { & "+quote(exe)+' -u '+quote(file)+"; exit $LASTEXITCODE } catch { [Console]::Error.WriteLine($_.ToString()); exit 1 }";
}
function appearance(input={}){
 const clamp=(v,min,max,fallback)=>Number.isFinite(Number(v))?Math.max(min,Math.min(max,Number(v))):fallback;
 const result={mode:['auto','dark','light','classic'].includes(input.mode)?input.mode:'auto',fontSize:clamp(input.fontSize,11,24,14),lineHeight:clamp(input.lineHeight,1.3,2,1.6),minimap:input.minimap!==false,wrap:!!input.wrap};
 for(const k of ['background','foreground','cursor','comment','keyword','string','number','function'])if(/^#[\da-f]{6}$/i.test(input[k]||''))result[k]=input[k].toLowerCase();return result;
}
module.exports={owner,context,pythonCommand,appearance};
