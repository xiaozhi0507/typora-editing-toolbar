const test=require('node:test'),assert=require('node:assert/strict');
const PT=require('./ai-paper-translation.cjs');
const packet=(id,text)=>JSON.stringify({translations:[{id,text}]});
const accept=(source,text)=>PT.accept(PT.plan(source).units,packet('L1',text)).get('L1');

test('atomic references and formulas can follow natural Chinese word order',()=>{
 assert.equal(accept('For estimating $E$, the model of [Wang, 2014](#ref-wang) was used.','采用⟦ET1⟧的模型估算⟦ET0⟧。'),'采用[Wang, 2014](#ref-wang)的模型估算$E$。');
});

test('complete sibling links may move while retaining their own destinations',()=>{
 assert.equal(accept('The [water balance](https://example.org/balance) was estimated using [thermal imagery](https://example.org/thermal).','利用⟦ET2⟧热成像⟦ET3⟧估算⟦ET0⟧水量平衡⟦ET1⟧。'),'利用[热成像](https://example.org/thermal)估算[水量平衡](https://example.org/balance)。');
});

test('nested emphasis and link blocks can move together',()=>{
 assert.equal(accept('The $E$ values were obtained from **[water balance](https://example.org/balance)**.','根据⟦ET1⟧⟦ET2⟧水量平衡⟦ET3⟧⟦ET4⟧获得⟦ET0⟧值。'),'根据**[水量平衡](https://example.org/balance)**获得$E$值。');
});

test('missing, duplicated and unknown tokens are still rejected',()=>{
 const source='The value was 5, see [Wang, 2014](#ref-wang).';
 for(const [text,reason] of [['数值为⟦ET0⟧。','缺少'],['数值为⟦ET0⟧⟦ET0⟧，见⟦ET1⟧。','重复'],['数值为⟦ET0⟧，见⟦ET1⟧⟦ET999⟧。','未知']])assert.throws(()=>accept(source,text),new RegExp(reason));
});

test('crossed link pairs, emphasis and superscript nesting are rejected',()=>{
 assert.throws(()=>accept('The [first](https://example.org/a) and [second](https://example.org/b) models.','⟦ET0⟧甲⟦ET3⟧和⟦ET2⟧乙⟦ET1⟧'),/配对/);
 assert.throws(()=>accept('The **[model](https://example.org)** was tested.','⟦ET0⟧⟦ET1⟧模型⟦ET3⟧⟦ET2⟧'),/配对/);
 assert.throws(()=>accept('The volume was measured in cm<sup>3</sup>.','体积以 cm⟦ET0⟧⟦ET2⟧⟦ET1⟧计。'),/层级/);
});

test('table cells, structural prefixes and hard breaks cannot move',()=>{
 assert.throws(()=>accept('| Rate 5 | Time 8 |','⟦ET0⟧速率⟦ET3⟧⟦ET2⟧时间⟦ET1⟧⟦ET4⟧'),/单元格/);
 assert.throws(()=>accept('# Model 5','模型⟦ET0⟧⟦ET1⟧'),/行首/);
 assert.throws(()=>accept('The model was evaluated.  ','⟦ET0⟧模型已评估。'),/行尾/);
});

test('HTML and image attributes survive paragraph reordering exactly',()=>{
 assert.equal(accept('The $E$ model uses <em>thermal imagery</em> and <img src="figure.png" style="zoom:25%;">.','使用⟦ET1⟧热成像⟦ET2⟧的⟦ET0⟧模型，见⟦ET3⟧。'),'使用<em>热成像</em>的$E$模型，见<img src="figure.png" style="zoom:25%;">。');
});

test('a definite missing marker retries the whole paragraph with its context',async()=>{
 const units=PT.plan('The $E$ model of [Wang, 2014](#ref-wang) estimates crop water use.').units,calls=[];
 const translated=await PT.translateChunk(units,async(pending,{attempt})=>{
  calls.push(PT.input(pending));return PT.accept(pending,packet('L1',attempt?'采用⟦ET1⟧的⟦ET0⟧模型估算作物耗水量。':'采用⟦ET1⟧的模型估算作物耗水量。'));
 });
 assert.equal(calls.length,2);assert.deepEqual(calls[0],calls[1]);assert.equal(calls[0].segments[0].parts,undefined);
 assert.equal(translated.get('L1'),'采用[Wang, 2014](#ref-wang)的$E$模型估算作物耗水量。');
});

test('marker-dense paragraphs support complete sentence reordering',()=>{
 const source=Array.from({length:20},(_,n)=>`The model uses $E_${n}$ and [Author ${n}](#ref-${n}).`).join(' ');
 const unit=PT.plan(source).units[0],out=Array.from({length:20},(_,n)=>`模型采用⟦ET${n*2+1}⟧的方法和⟦ET${n*2}⟧。`).join('');
 assert.equal(unit.values.length,40);assert.deepEqual(PT.protect(accept(source,out)).values.sort(),unit.values.slice().sort());
});
