const {test}=require('node:test'),assert=require('node:assert/strict'),http=require('node:http');
const Client=require('./ai-client.cjs');
const messages=[{role:'user',content:'测试问题'}],p={model:'gpt-6.1-sol',protocol:'openai-responses'};
test('documented GPT models expose at most four discrete efforts and default medium',()=>{
  for(const model of ['gpt-6.1-sol','gpt-6-astra','gpt-6-luna','gpt-5.6-sol','gpt-5.5']){
    assert.deepEqual(Client.effortLevels({model}),['low','medium','high','xhigh']);assert.equal(Client.effortValue({model}),'medium');
  }
  assert.deepEqual(Client.effortLevels({model:'unknown'}),[]);assert.deepEqual(Client.effortLevels({...p,protocol:'anthropic-messages'}),[]);
});
test('catalog capability subsets are respected, sorted, and never expose max or ultra',()=>{
  const meta=Client.effortMetadata({supported_reasoning_levels:[{effort:'ultra'},{effort:'high'},{effort:'low'},{effort:'max'}],default_reasoning_level:'ultra'});
  assert.deepEqual(meta,{reasoningEfforts:['low','high'],defaultReasoningEffort:'high'});
  assert.deepEqual(Client.effortLevels({...p,reasoningEfforts:[]}),[]);
  assert.equal(Client.effortValue({...p,...meta,reasoningEffort:'xhigh'}),'high');
});
test('old max/ultra settings clamp to xhigh in actual Responses body',()=>{
  for(const level of ['max','ultra'])assert.equal(Client.body({...p,reasoningEffort:level},messages).reasoning.effort,'xhigh');
  assert.equal(Client.body({...p,extra:'{"reasoning":{"effort":"ultra","summary":"auto"}}'},messages).reasoning.effort,'xhigh');
});
test('explicit slider choice overrides old extra effort and preserves unrelated reasoning properties',()=>{
  const b=Client.body({...p,reasoningEffort:'high',extra:'{"reasoning_effort":"low","reasoning":{"summary":"auto"},"text":{"verbosity":"low"}}'},messages);
  assert.deepEqual(b.reasoning,{summary:'auto',effort:'high'});assert.equal(b.reasoning_effort,undefined);assert.equal(b.text.verbosity,'low');
  const c=Client.body({...p,protocol:'openai-chat',reasoningEffort:'low'},messages);assert.equal(c.reasoning_effort,'low');assert.equal(c.reasoning,undefined);
});
test('unconfigured providers keep their existing request shape',()=>{
  const b=Client.body({model:'unknown',protocol:'openai-chat'},messages);assert.equal(b.reasoning,undefined);assert.equal(b.reasoning_effort,undefined);
  const c=Client.body({model:'custom',protocol:'openai-chat',extra:'{"reasoning_effort":"high"}'},messages);assert.equal(c.reasoning_effort,'high');
});
test('all slider choices survive HTTP serialization without fast mode or excess effort',async t=>{
  const received=[],server=http.createServer((req,res)=>{let raw='';req.on('data',b=>raw+=b);req.on('end',()=>{
    received.push(JSON.parse(raw));res.setHeader('Content-Type','text/event-stream');
    res.end('data: '+JSON.stringify({type:'response.output_text.delta',delta:'OK'})+'\n\ndata: '+JSON.stringify({type:'response.completed',response:{status:'completed'}})+'\n\n');
  });});await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>{server.closeAllConnections();return new Promise(r=>server.close(r));});
  const client=new Client(require);
  for(const effort of ['low','medium','high','xhigh'])await client.request({...p,reasoningEffort:effort,url:'http://127.0.0.1:'+server.address().port+'/responses',fullUrl:true,authType:'chatgpt'},'mock',messages,{});
  assert.deepEqual(received.map(b=>b.reasoning.effort),['low','medium','high','xhigh']);for(const b of received){assert.equal(b.service_tier,undefined);assert.equal(b.store,false);assert.equal(b.stream,true);}
});

test('DeepSeek has two distinct allowed strengths and defaults high, without alias stops',()=>{
  const ds={model:'deepseek-flash'};
  assert.deepEqual(Client.effortLevels(ds),['low','high']);assert.equal(Client.effortValue(ds),'high');
  for(const alias of ['medium','xhigh','max','ultra'])assert.equal(Client.effortValue({...ds,reasoningEffort:alias}),'high');
  assert.equal(Client.effortDefault({...ds,reasoningEffort:'low',extra:'{"reasoning_effort":"low"}'}),'high');
});
test('single capability stays fixed and reset uses catalog default',()=>{
  const one={...p,reasoningEfforts:['high'],reasoningEffort:'low'};
  assert.deepEqual(Client.effortLevels(one),['high']);assert.equal(Client.effortValue(one),'high');assert.equal(Client.effortDefault(one),'high');
  assert.equal(Client.effortDefault({...p,defaultReasoningEffort:'low',reasoningEffort:'xhigh'}),'low');
});
test('DeepSeek preserves explicit thinking off and does not silently enable it',()=>{
  for(const extra of ['{"thinking":{"type":"disabled"}}','{"reasoning_effort":"none"}','{"reasoning":{"effort":"none"}}']){
    const ds={model:'deepseek-flash',protocol:'openai-chat',extra};
    assert.equal(Client.thinkingDisabled(ds),true);assert.deepEqual(Client.effortLevels(ds),[]);assert.equal(Client.effortValue(ds),null);
    const body=Client.body(ds,messages);for(const [key,value]of Object.entries(JSON.parse(extra)))assert.deepEqual(body[key],value);
  }
});
test('DeepSeek serializes correct effort field for each supported protocol',()=>{
  for(const level of ['low','high']){
    const ds={model:'deepseek-flash',reasoningEffort:level};
    assert.equal(Client.body({...ds,protocol:'openai-chat'},messages).reasoning_effort,level);
    assert.equal(Client.body({...ds,protocol:'openai-responses'},messages).reasoning.effort,level);
    const body=Client.body({...ds,protocol:'anthropic-messages',extra:'{"output_config":{"effort":"max","format":{"type":"text"}}}'},messages);
    assert.equal(body.output_config.effort,level);assert.deepEqual(body.output_config.format,{type:'text'});assert.equal(body.reasoning_effort,undefined);
  }
});

test('V4 Pro reuses the DeepSeek endpoint and supports text and edit tools on every protocol',()=>{
  assert.equal(Client.endpoint('https://api.deepseek.com/v1/chat/completions','openai-chat',true),'https://api.deepseek.com/v1/chat/completions');
  for(const protocol of ['openai-chat','openai-responses','anthropic-messages']){
    const profile={model:'deepseek-v4-pro',protocol,documentEdit:true},body=Client.body(profile,messages);
    assert.equal(body.model,'deepseek-v4-pro');assert.equal(body.tools.length,2);
    assert.equal(body.reasoning_effort||body.reasoning?.effort||body.output_config?.effort,'high');
    const off=Client.body({...profile,extra:'{"thinking":{"type":"disabled"}}'},messages);assert.equal(off.thinking.type,'disabled');
  }
});

test('V4 Pro rejects image context including history before transport; Flash retains images',()=>{
  const image={type:'image_url',image_url:{url:'data:image/png;base64,YQ=='}},withImage=[{role:'user',content:[{type:'text',text:'资料'},image]},...messages];
  for(const protocol of ['openai-chat','openai-responses','anthropic-messages']){
    assert.throws(()=>Client.body({model:'deepseek-v4-pro',protocol},withImage),/不支持图片理解.*Flash/);
    assert.doesNotThrow(()=>Client.body({model:'deepseek-flash',protocol},withImage));
  }
});


test('V4 Pro exposes low/high/max with high default and normalizes provider aliases',()=>{
  const pro={model:'deepseek-v4-pro'};
  assert.deepEqual(Client.effortLevels(pro),['low','high','max']);assert.equal(Client.effortValue(pro),'high');
  for(const [input,output]of Object.entries({minimal:'low',medium:'high',xhigh:'high',ultra:'max',max:'max'}))assert.equal(Client.effortValue({...pro,reasoningEffort:input}),output);
  assert.equal(Client.effortDefault({...pro,reasoningEffort:'max',extra:'{"reasoning_effort":"max"}'}),'high');
  assert.equal(Client.effortValue({...pro,reasoningEfforts:['low','high'],reasoningEffort:'max'}),'high');
  assert.deepEqual(Client.effortLevels({...pro,reasoningEfforts:['max','low']}),['low','max']);
});

test('V4 Pro serializes all three strengths in every protocol and respects thinking off',()=>{
  for(const level of ['low','high','max'])for(const protocol of ['openai-chat','openai-responses','anthropic-messages']){
    const profile={model:'deepseek-v4-pro',protocol,reasoningEffort:level};const body=Client.body(profile,messages);
    assert.equal(body.reasoning_effort||body.reasoning?.effort||body.output_config?.effort,level);
  }
  for(const extra of ['{"reasoning_effort":"max"}','{"reasoning":{"effort":"max"}}','{"output_config":{"effort":"max"}}'])assert.equal(Client.effortValue({model:'deepseek-v4-pro',extra}),'max');
  for(const extra of ['{"thinking":{"type":"disabled"}}','{"reasoning_effort":"none"}','{"reasoning":{"effort":"none"}}']){
    const pro={model:'deepseek-v4-pro',protocol:'openai-chat',reasoningEffort:'max',extra};
    assert.equal(Client.effortValue(pro),null);assert.deepEqual(Client.effortLevels(pro),[]);
    const body=Client.body(pro,messages);for(const [key,value]of Object.entries(JSON.parse(extra)))assert.deepEqual(body[key],value);
  }
});

test('V4 Pro three slider choices reach the HTTP request unchanged',async t=>{
  const received=[],server=http.createServer((req,res)=>{let raw='';req.on('data',b=>raw+=b);req.on('end',()=>{
    received.push(JSON.parse(raw));res.setHeader('Content-Type','application/json');res.end(JSON.stringify({choices:[{message:{content:'OK'},finish_reason:'stop'}]}));
  });});await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>{server.closeAllConnections();return new Promise(r=>server.close(r));});
  const client=new Client(require);
  for(const effort of ['low','high','max'])await client.request({model:'deepseek-v4-pro',protocol:'openai-chat',reasoningEffort:effort,url:'http://127.0.0.1:'+server.address().port+'/chat/completions',fullUrl:true},'mock',messages,{});
  assert.deepEqual(received.map(b=>b.reasoning_effort),['low','high','max']);assert.ok(received.every(b=>b.model==='deepseek-v4-pro'));
});
