'use strict';
// Independent implementation informed by Linter's duplicate workflow and Zotero's
// DOI / ISBN / title+creator detection. No document content is rewritten here.
class KnowledgeLibraryDuplicates {
  static fields = ('title titleZh author year date publicationTitle conference volume issue pages articleNumber doi url publisher edition isbn language summary affiliations keywords resourceUrls articleType contributor editor translator seriesEditor thesisType university numPages place libraryCatalog accessDate shortTitle archive archiveLocation callNumber rights extra issn journalAbbreviation series seriesTitle seriesText section partNumber partTitle pmid pmcid seriesNumber numberOfVolumes originalDate originalPublisher originalPlace format journalTag citationCount citedCount impactFactor metrics').split(' ');
  static copy(value){return JSON.parse(JSON.stringify(value));}
  static blank(value){return value==null||value===''||Array.isArray(value)&&!value.length;}
  static fieldValue(item,key){return key==='resourceUrls'?(Array.isArray(item.resourceUrls)?item.resourceUrls:[...new Set([...(item.codeUrls||[]),...(item.dataUrls||[])])]):item[key];}
  static text(value){return String(value||'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/<[^>]*>/g,'').toLowerCase().replace(/[\p{P}\p{S}\s]+/gu,' ').trim();}
  static title(value){return this.text(String(value||'').replace(/^\s*\d+(?:\.\d+)*[\s.、_-]+/,''));}
  static doi(value){const v=String(value||'').trim().replace(/^https?:\/\/(?:dx\.)?doi\.org\//i,'').replace(/^doi\s*:\s*/i,'').toLowerCase();return /^10\.\d{4,9}\/\S+$/.test(v)?v:'';}
  static isbn(value){
    let v=String(value||'').replace(/[^\dXx]/g,'').toUpperCase();
    if(v.length===10){if(!/^\d{9}[\dX]$/.test(v)||[...v].reduce((s,c,i)=>s+(c==='X'?10:+c)*(10-i),0)%11)return '';v='978'+v.slice(0,9);v+=String((10-[...v].reduce((s,c,i)=>s+(+c)*(i%2?3:1),0)%10)%10);}
    return /^\d{13}$/.test(v)&&[...v].reduce((s,c,i)=>s+(+c)*(i%2?3:1),0)%10===0?v:'';
  }
  static creators(value){return String(value||'').split(/[;；\n]+/).map(s=>{
    const comma=s.split(','),parts=this.text(s).split(' ');if(!parts[0])return '';
    return comma.length===2?this.text(comma[0])+':'+this.text(comma[1]).charAt(0):parts.length===1?parts[0]:parts.at(-1)+':'+parts[0].charAt(0);
  }).filter(Boolean);}
  static record(i){return {i,id:i.id,type:i.type,doi:this.doi(i.doi),isbn:i.type==='book'?this.isbn(i.isbn):'',title:this.title(i.title),year:Number(String(i.date||i.year||'').match(/(?:18|19|20|21)\d{2}/)?.[0])||0,authors:this.creators(i.author)};}
  static matches(a,b){
    if(a.type!==b.type||a.doi&&b.doi&&a.doi!==b.doi||a.isbn&&b.isbn&&a.isbn!==b.isbn)return false;
    if(a.doi&&a.doi===b.doi||a.isbn&&a.isbn===b.isbn)return true;
    if(a.title.length<5||a.title!==b.title||a.year&&b.year&&Math.abs(a.year-b.year)>1)return false;
    return !a.authors.length&&!b.authors.length||a.authors.some(n=>b.authors.includes(n));
  }
  static groups(items){
    const records=items.filter(i=>!i.deleted&&i.type!=='note'&&i.type!=='webpage').map(i=>this.record(i)),sets=new Map(records.map(r=>[r.id,new Set([r])])),buckets=new Map();
    for(const r of records)for(const [kind,key] of [['doi',r.doi],['isbn',r.isbn],['title',r.title]])if(key){const k=r.type+':'+kind+':'+key;if(!buckets.has(k))buckets.set(k,[]);buckets.get(k).push(r);}
    for(const bucket of buckets.values())for(let a=0;a<bucket.length;a++)for(let b=a+1;b<bucket.length;b++){
      const left=bucket[a],right=bucket[b],one=sets.get(left.id),two=sets.get(right.id);if(one===two||!this.matches(left,right))continue;
      // A missing identifier must not bridge two different DOI/ISBN works.
      if(['doi','isbn'].some(k=>new Set([...one,...two].map(r=>r[k]).filter(Boolean)).size>1))continue;
      for(const r of two){one.add(r);sets.set(r.id,one);}
    }
    return [...new Set(sets.values())].filter(s=>s.size>1).map(s=>[...s].sort((a,b)=>this.versionOrder(a.i,b.i)).map(r=>r.id));
  }
  static versionOrder(a,b){return (Date.parse(a.added)||0)-(Date.parse(b.added)||0)||a.id.localeCompare(b.id);}
  static describe(items,masterId){
    const ordered=[...items].sort((a,b)=>this.versionOrder(a,b)),master=items.find(i=>i.id===masterId)||ordered[0];
    if(!master)return {masterId:null,fields:[]};
    const fields=this.fields.filter(k=>items.some(i=>!this.blank(this.fieldValue(i,k)))).map(key=>{
      const variants=[];for(const i of [master,...ordered.filter(i=>i.id!==master.id)]){const value=this.fieldValue(i,key)??'',encoded=JSON.stringify(value);if(!variants.some(v=>v.encoded===encoded))variants.push({sourceId:i.id,value,encoded});}
      const preferred=!this.blank(this.fieldValue(master,key))?master:ordered.find(i=>!this.blank(this.fieldValue(i,key)))||master;
      return {key,variants:variants.map(({encoded,...v})=>v),sourceId:variants.find(v=>v.encoded===JSON.stringify(this.fieldValue(preferred,key)??'')).sourceId};
    });return {masterId:master.id,fields};
  }
  constructor(store){this.store=store;}
  build(base,request){
    const ids=[...new Set(request.ids||[])],members=ids.map(id=>base.items.find(i=>i.id===id));
    if(ids.length<2||members.some(i=>!i||i.deleted)||new Set(members.map(i=>i.type)).size!==1)throw Error('请选择至少两个未删除且类型相同的条目。');
    if(!ids.includes(request.masterId))throw Error('请选择要保留的主条目。');
    const next=KnowledgeLibraryDuplicates.copy(base),master=next.items.find(i=>i.id===request.masterId),others=members.filter(i=>i.id!==master.id),selected=new Set(ids),losers=new Set(others.map(i=>i.id));
    const description=KnowledgeLibraryDuplicates.describe(members,master.id),keys=new Set(description.fields.map(f=>f.key));
    for(const key of Object.keys(request.choices||{}))if(!keys.has(key))throw Error('合并字段已变化，请重新选择条目。');
    for(const f of description.fields){const sourceId=request.choices?.[f.key]||f.sourceId,source=members.find(i=>i.id===sourceId);if(!source)throw Error('合并字段来源已变化，请重新选择。');master[f.key]=KnowledgeLibraryDuplicates.copy(KnowledgeLibraryDuplicates.fieldValue(source,f.key)??'');}
    const union=(key)=>[...new Set(members.flatMap(i=>i[key]||[]))];
    master.collections=union('collections');master.tags=union('tags');master.star=members.some(i=>i.star);master.rating=Math.max(...members.map(i=>Number(i.rating)||0));
    master.status=members.some(i=>i.status==='done')?'done':members.some(i=>i.status==='reading')?'reading':'unread';master.last=Math.max(...members.map(i=>Number(i.last)||0));
    const fileMap=new Map(),idsInUse=new Set(),mapping=new Map();master.files=[];
    for(const i of [members.find(i=>i.id===master.id),...others])for(const f of i.files){
      const key=f.linkType==='url'?'url:'+f.path:'file:'+this.store.resolveFile(f).toLowerCase();let chosen=fileMap.get(key);
      if(!chosen){chosen=KnowledgeLibraryDuplicates.copy(f);if(idsInUse.has(chosen.id))chosen.id=this.store.crypto.randomUUID();idsInUse.add(chosen.id);fileMap.set(key,chosen);master.files.push(chosen);}
      mapping.set(i.id+':'+f.id,chosen.id);
    }
    master.defaultFile=mapping.get(master.id+':'+master.defaultFile)||master.files[0]?.id;
    const recent=[...members].sort((a,b)=>(Number(b.last)||0)-(Number(a.last)||0)).find(i=>i.lastFile&&mapping.has(i.id+':'+i.lastFile));
    if(recent)master.lastFile=mapping.get(recent.id+':'+recent.lastFile);else delete master.lastFile;
    if(!master.defaultFile)delete master.defaultFile;
    const auto=master.xrefMetadata||{};master.xrefMetadata={...auto,locked:[...new Set([...(auto.locked||[]),...keys,'tags'])],automaticTags:[]};
    master.related=union('related').filter(id=>!selected.has(id));master.relatedOut=union('relatedOut').filter(id=>!selected.has(id));
    master.mergeHistory=[...(master.mergeHistory||[]),{at:new Date().toISOString(),sources:others.map(i=>i.id)}];
    for(const i of next.items){
      if(losers.has(i.id)){i.deleted=true;i.mergedInto=master.id;i.related=[];i.relatedOut=[];continue;}
      i.related=[...new Set(i.related.map(id=>losers.has(id)?master.id:id))].filter(id=>id!==i.id);
      if(i.relatedOut)i.relatedOut=[...new Set(i.relatedOut.map(id=>losers.has(id)?master.id:id))].filter(id=>id!==i.id);
    }
    for(const id of master.related){const peer=next.items.find(i=>i.id===id);if(peer&&!peer.related.includes(master.id))peer.related.push(master.id);}
    this.store.validate(next);return next;
  }
  async merge(base,request){
    const next=this.build(base,request),ids=new Set(request.ids);
    const data=await this.store.commit(base,next,live=>{
      for(const id of ids){const before=base.items.find(i=>i.id===id),now=live.items.find(i=>i.id===id);if(JSON.stringify(before)!==JSON.stringify(now))throw Error('所选条目已被其他窗口修改，请刷新后重新合并。');}
      for(const id of new Set([...base.items,...live.items].map(i=>i.id)))if(!ids.has(id)){
        const before=base.items.find(i=>i.id===id),now=live.items.find(i=>i.id===id);
        if(['related','relatedOut'].some(key=>[...(before?.[key]||[]),...(now?.[key]||[])].some(peer=>ids.has(peer))&&JSON.stringify(before?.[key])!==JSON.stringify(now?.[key])))throw Error('相关条目已更新，请刷新后重新合并。');
      }
    });
    return {data,masterId:request.masterId,count:ids.size};
  }
}
module.exports=KnowledgeLibraryDuplicates;
