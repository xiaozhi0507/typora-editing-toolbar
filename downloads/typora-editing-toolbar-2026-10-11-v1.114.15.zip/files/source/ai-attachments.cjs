'use strict';
// Read-only attachment IO and searchable metadata. Never imports or rewrites files.
class ETAIAttachments {
  static maxFiles=20;
  static textLimit=2*1024*1024;
  static imageLimit=5*1024*1024;
  static extensions=['md','markdown','mdown','txt','png','jpg','jpeg','webp'];
  constructor(requireNode=require) {this.fs=requireNode('fs').promises;this.path=requireNode('path');this.Decoder=requireNode('util').TextDecoder;this.Buffer=requireNode('buffer').Buffer;}
  key(path) {return String(path).startsWith('webpage:')?String(path):this.path.resolve(path).toLowerCase();}
  async describe(path,location='本机文件') {
    const name=this.path.basename(path),ext=this.path.extname(name).slice(1).toLowerCase();
    if(!ETAIAttachments.extensions.includes(ext))throw Error(name+'：仅支持 Markdown、TXT、PNG、JPG 和 WebP');
    const real=await this.fs.realpath(path),stat=await this.fs.stat(real),image=/^(png|jpe?g|webp)$/.test(ext);
    if(!stat.isFile())throw Error(name+'：请选择具体文件');
    if(stat.size>(image?ETAIAttachments.imageLimit:ETAIAttachments.textLimit))throw Error(name+'：'+(image?'图片超过 5 MB':'文本文件超过 2 MB'));
    return {id:this.key(real),path:real,name,location,kind:image?'image':'text',mime:image?'image/'+(ext==='jpg'?'jpeg':ext):'',bytes:stat.size};
  }
  async read(entry,override) {
    if(entry.kind==='text'&&override!==undefined)return {...entry,text:String(override)};
    const limit=entry.kind==='image'?ETAIAttachments.imageLimit:ETAIAttachments.textLimit,handle=await this.fs.open(entry.path,'r');let bytes;
    try{
      const stat=await handle.stat();if(!stat.isFile()||stat.size>limit)throw Error(entry.name+'：文件已变更或超过大小限制');
      const buffer=this.Buffer.alloc(limit+1);let count=0;
      while(count<buffer.length){const result=await handle.read(buffer,count,buffer.length-count,count);if(!result.bytesRead)break;count+=result.bytesRead;}
      if(count>limit)throw Error(entry.name+'：文件超过大小限制');bytes=buffer.subarray(0,count);
    }finally{await handle.close();}
    if(entry.kind==='image'){
      const mime=bytes.subarray(0,8).equals(this.Buffer.from([137,80,78,71,13,10,26,10]))?'image/png':bytes[0]===255&&bytes[1]===216&&bytes[2]===255?'image/jpeg':bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP'?'image/webp':'';
      if(!mime||mime!==entry.mime)throw Error(entry.name+'：图片格式与文件扩展名不符');
      return {...entry,data:'data:'+mime+';base64,'+bytes.toString('base64')};
    }
    let text;
    try{
      if(bytes[0]===255&&bytes[1]===254)text=new this.Decoder('utf-16le',{fatal:true}).decode(bytes.subarray(2));
      else if(bytes[0]===254&&bytes[1]===255)text=new this.Decoder('utf-16be',{fatal:true}).decode(bytes.subarray(2));
      else {try{text=new this.Decoder('utf-8',{fatal:true}).decode(bytes);}catch{text=new this.Decoder('gb18030',{fatal:true}).decode(bytes);}}
    }catch{throw Error(entry.name+'：无法识别文本编码，请另存为 UTF-8');}
    if(/[\x00-\x08\x0b\x0c\x0e-\x1f]/.test(text))throw Error(entry.name+'：不是可读取的文本文件');
    if(!text.trim())throw Error(entry.name+'：文件内容为空');
    return {...entry,text:text.replace(/^\uFEFF/,'')};
  }
  static catalog(data,resolve,libraryRoot='',webChat=false) {
    const root={id:'root',name:'',children:[],folder:true},folders=new Map([['root',root]]),files=[];
    const folder=(parent,id,name)=>{let n=folders.get(id);if(!n){n={id,name,folder:true,children:[],parent};folders.set(id,n);parent.children.push(n);}return n;};
    const collections=new Map((data.collections||[]).map(c=>[c.id,c]));
    const collection=id=>{const c=collections.get(id);if(!c)return folder(root,'unfiled','未分类');if(folders.has('c:'+id))return folders.get('c:'+id);return folder(c.parentId?collection(c.parentId):root,'c:'+id,c.name);};
    for(const item of data.items||[]){
      if(item.deleted)continue;
      if(item.type==='webpage'){
        for(const cid of item.collections?.length?item.collections:[null]){const p=collection(cid),trail=[];for(let n=p;n&&n!==root;n=n.parent)trail.unshift(n.name);const path='webpage:'+data.libraryId+':'+item.id,leaf={id:path,path,name:item.title,location:trail.join(' / '),title:item.title,search:[item.website,item.url,item.summary,...(item.tags||[])].join(' '),webpage:{id:item.id,libraryId:data.libraryId,root:libraryRoot},parent:p};p.children.push(leaf);files.push(leaf);}continue;
      }
      const usable=(item.files||[]).filter(f=>f.linkType!=='url'&&(webChat?/\.(?:md|markdown|mdown|txt|pdf|docx|csv|json|png|jpe?g|webp)$/i:/\.(?:md|markdown|mdown)$/i).test(f.name||f.path));if(!usable.length)continue;
      for(const cid of item.collections?.length?item.collections:[null]){
        let parent=collection(cid);if(item.type==='book'||usable.length>1)parent=folder(parent,parent.id+'/i:'+item.id,item.title);
        for(const f of usable){
          let p=parent;const parts=String(f.bookPath||'').replaceAll('\\','/').split('/').slice(0,-1).filter(x=>x&&x!=='.'&&x!=='..');
          for(const segment of parts)p=folder(p,p.id+'/d:'+segment,segment);
          const path=resolve(f),trail=[];for(let n=p;n&&n!==root;n=n.parent)trail.unshift(n.name);
          const leaf={id:'f:'+item.id+':'+f.id,path,name:f.name||String(path).split(/[\\/]/).at(-1),location:trail.join(' / '),title:item.title,parent:p};p.children.push(leaf);files.push(leaf);
        }
      }
    }
    const compare=new Intl.Collator('zh-CN',{numeric:true});for(const n of folders.values())n.children.sort((a,b)=>Number(!!b.folder)-Number(!!a.folder)||compare.compare(a.name,b.name));
    return {root,folders:[...folders.values()].filter(n=>n!==root),files};
  }
  static search(catalog,query) {
    const terms=query.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);if(!terms.length)return [];
    const match=s=>terms.every(t=>String(s).toLocaleLowerCase().includes(t));
    const folders=catalog.folders.filter(n=>match(n.name)),matched=new Set(folders),covered=n=>{for(let p=n.parent;p;p=p.parent)if(matched.has(p))return true;return false;};
    const seen=new Set(),files=catalog.files.filter(n=>{if(covered(n)||!match(n.name+' '+n.title+' '+n.location+' '+(n.search||'')))return false;const key=n.path.toLowerCase();if(seen.has(key))return false;seen.add(key);return true;});
    return [...folders.filter(n=>!covered(n)),...files];
  }
}
module.exports=ETAIAttachments;
