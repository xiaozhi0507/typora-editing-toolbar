const test=require('node:test'),assert=require('node:assert/strict');
const PT=require('./ai-paper-translation.cjs');
const source='College of Hydraulic and Environmental Engineering, China Three Gorges University, Yichang 443002, China\n\nThis study measures canopy temperature and estimates plant transpiration using a thermal camera.\n\nThe model uses $E = R_n / lambda$ and links to [Figure 1](#fig-1) for comparison.';
const translated=u=>({id:u.id,text:'完整中文译文 '+u.text});
const response=units=>JSON.stringify({translations:units.map(translated)});

test('a missing paragraph carries its exact source location and preserves valid peers',()=>{
 const units=PT.plan(source).units,rows=units.slice(1).map(translated);
 assert.throws(()=>PT.accept(units,JSON.stringify({translations:rows})),e=>{
  assert.equal(e.code,'PAPER_TRANSLATION_VALIDATION');assert.deepEqual(e.issues.map(i=>({id:i.id,line:i.line})),[{id:'L1',line:1}]);
  assert.match(e.message,/第 1 行（L1）.*缺少/);assert.deepEqual([...e.accepted.keys()],['L3','L5']);return true;
 });
});
test('only missing whole paragraphs are retried and valid peers are neither resent nor overwritten',async()=>{
 const units=PT.plan(source).units,calls=[],states=[];
 const result=await PT.translateChunk(units,async(pending,{attempt,feedback})=>{
  calls.push(pending.map(u=>u.id));const rows=pending.map(translated);
  if(!attempt)rows.shift();
  else{assert.match(feedback,/第 1 行（L1）.*缺少/);assert.equal(pending[0].text,units[0].text);assert(!('parts' in PT.input(pending).segments[0]));rows[0].text=pending[0].text.replace('College of Hydraulic and Environmental Engineering, China Three Gorges University, Yichang','中国三峡大学水利与环境工程学院，宜昌').replace(/, China$/,'，中国');}
  return PT.accept(pending,JSON.stringify({translations:rows.reverse()}));
 },{onRepair:s=>states.push(s)});
 assert.deepEqual(calls,[['L1','L3','L5'],['L1']]);assert.deepEqual([...result.keys()],['L1','L3','L5']);assert.match(result.get('L1'),/中国三峡大学/);
 assert.equal(result.get('L3'),'完整中文译文 '+units[1].original);assert.match(result.get('L5'),/\$E = R_n \/ lambda\$/);assert(result.get('L5').includes('[Figure 1](#fig-1)'));
 assert.equal(states[0].remaining,1);assert.equal(states[0].accepted,2);
});
test('missing or malformed pieces remain eligible for bounded repair without discarding validated text',async()=>{
 const units=PT.plan(source).units,calls=[];
 const result=await PT.translateChunk(units,async(pending,{attempt})=>{
  calls.push(pending.map(u=>u.id));
  return PT.accept(pending,attempt===0?JSON.stringify({translations:[translated(units[0])]}):attempt===1?'broken json':response(pending));
 });
 assert.deepEqual(calls,[['L1','L3','L5'],['L3','L5'],['L3','L5']]);assert.equal(result.size,3);
});
test('repairs cannot replace accepted IDs or bypass locked references',async()=>{
 const units=PT.plan(source).units,rows=units.map(translated);rows[2].text=rows[2].text.replace('⟦ET0⟧','');let calls=0;
 await assert.rejects(PT.translateChunk(units,async(pending,{attempt})=>{
  calls++;
  return PT.accept(pending,JSON.stringify({translations:attempt===0?rows:attempt===1?[translated(units[0])]:[{id:units[2].id,text:'中文 '+units[2].text.replace('⟦ET0⟧','') }]}));
 }),e=>e.code==='PAPER_TRANSLATION_VALIDATION'&&/重试 2 次.*第 5 行（L5）.*标记/.test(e.message));
 assert.equal(calls,3);
});
test('repeated missing paragraphs stop after two retries and block the next chunk',async()=>{
 const units=PT.plan(source).units,started=[];let requests=0;
 await assert.rejects(PT.runChunks([units,units],async(group,n)=>{
  started.push(n);return PT.translateChunk(group,async pending=>{requests++;return PT.accept(pending,'{"translations":[]}');});
 }),e=>e.code==='PAPER_TRANSLATION_VALIDATION'&&/重试 2 次.*缺少/.test(e.message));
 assert.equal(requests,3);assert.deepEqual(started,[0]);
});
test('abort before a repair prevents another request and preserves atomic completion',async()=>{
 const controller=new AbortController(),units=PT.plan(source).units;let requests=0;
 await assert.rejects(PT.translateChunk(units,async pending=>{requests++;return PT.accept(pending,'{"translations":[]}');},{signal:controller.signal,onRepair:()=>controller.abort()}),{name:'AbortError'});
 assert.equal(requests,1);
});
test('provider errors are not retried based on translated message text',async()=>{
 const error=Object.assign(Error('译文服务不可用'),{status:429});let requests=0;
 await assert.rejects(PT.translateChunk(PT.plan(source).units,async()=>{requests++;throw error;}),e=>e===error);assert.equal(requests,1);
});
