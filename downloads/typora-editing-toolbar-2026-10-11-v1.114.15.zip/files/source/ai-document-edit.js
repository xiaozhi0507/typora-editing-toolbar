class EditingToolbarAIDocumentEdit {
  static maxRounds=20;
  constructor(ai){this.ai=ai;this.enabled=false;}
  mount(){
    const a=this.ai;this.modeGroup=a.node('div','et-ai-mode-switch');this.modeGroup.setAttribute('role','group');this.modeGroup.setAttribute('aria-label','聊天模式');
    this.ask=a.node('button','et-ai-edit-mode','提问');this.mode=a.node('button','et-ai-edit-mode','编辑');
    for(const [button,enabled,title] of [[this.ask,false,'提问模式：阅读和解释内容'],[this.mode,true,'编辑模式：修改当前文档，或在已信任项目中创建文件']]){button.type='button';button.title=title;button.dataset.mode=enabled?'edit':'ask';button.setAttribute('aria-label',enabled?'编辑当前文档':'提问模式');button.onclick=()=>{if(a.busy)return;a.composerUI.closeMenu();this.enabled=enabled;this.syncMode();a.composerUI.sync();};this.modeGroup.append(button);}
    this.modeGroup.onkeydown=e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key)||a.busy)return;e.preventDefault();const button=e.key==='Home'?this.ask:e.key==='End'?this.mode:document.activeElement===this.ask?this.mode:this.ask;button.click();button.focus();};
    a.composerUI.bar.append(this.modeGroup);this.syncMode();
    this.preview=a.node('div','et-ai-edit-preview');this.preview.setAttribute('popover','manual');this.preview.setAttribute('role','dialog');this.preview.setAttribute('aria-label','变更预览');document.body.append(this.preview);
    this.preview.onpointerenter=()=>clearTimeout(this.closeTimer);this.preview.onpointerleave=()=>this.scheduleClose();
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&this.preview.matches(':popover-open')){this.closePreview();e.stopPropagation();}},true);
    document.addEventListener('pointerdown',e=>{if(!this.preview.contains(e.target)&&!this.anchor?.contains(e.target))this.closePreview();});
    window.addEventListener('resize',()=>this.closePreview());window.addEventListener('blur',()=>this.closePreview());window.addEventListener('scroll',e=>{if(!this.preview.contains(e.target))this.closePreview();},true);
    this.preview.onfocusin=()=>clearTimeout(this.closeTimer);this.preview.onfocusout=e=>{if(!this.preview.contains(e.relatedTarget))this.scheduleClose();};
  }
  change(turn){return turn.requestContext?.documentEdit;}
  assert(file,expected,signal){if(signal?.aborted)throw Object.assign(Error('已停止编辑'),{name:'AbortError'});if(File.isFileLoading?.()||this.ai.file()!==file)throw Object.assign(Error('文档已切换，本次修改未应用'),{name:'AbortError',documentChanged:true});if(this.ai.source()!==expected)throw Error('原文已发生变化，本次修改未应用。请基于最新内容重新提问。');if(File.isLocked)throw Error('当前文档只读，无法修改');}
  write(text){
    if(this.ai.toolbar.readingMode?.protected)throw Error("当前文档处于保护模式，请先切换到编辑模式。");
    const a=this.ai,editor=File.editor,source=editor.sourceView,scroll=document.querySelector('content')?.scrollTop;
    if(source?.inSourceMode){const cm=source.cm;cm.operation(()=>{cm.replaceRange(text,{line:0,ch:0},cm.posFromIndex(cm.getValue().length),'+ai-edit');});}
    else {File.reloadContent(text,{delayRefresh:false});editor.refresh();if(scroll!=null)document.querySelector('content').scrollTop=scroll;}
    a.toolbar.savedRange=null;
    return a.source();
  }
  async run(profile,key,input,options,turn){
    if(profile.codeFiles?.length)return this.ai.codeUI.run(profile,key,input,options,turn);
    const a=this.ai,file=a.file(),editing=profile.documentEdit!==false;let expected=a.source(),readDocument=false,messages=ETAIClient.contextMessages({...profile,documentEdit:editing},input);
    const guard=()=>{if(editing)this.assert(file,expected,options.signal);else if(options.signal?.aborted||a.file()!==file)throw Object.assign(Error('已停止处理'),{name:'AbortError'});};guard();const p={...profile,documentEdit:editing};
    const skills=p.skillsEnabled?new EditingToolbarAISkillSession(a.skillsUI,p,turn,options):null;if(skills){messages=await skills.prepare(messages);options={...options,skillSession:skills};guard();}
    if(p.pluginsEnabled?.length)messages=a.pluginsUI.prepare(p,messages);
    if(p.webSearch||p.project||editing&&a.webUI)messages=await a.webUI.prepare(p,messages,options,turn);
    for(let round=0;round<EditingToolbarAIDocumentEdit.maxRounds;round++){
      guard();if(skills)for(const name of skills.loaded.keys())skills.store.active(name);const result=await a.request(p,key,messages,options);guard();if(!options.temporary)a.contextUI?.recordUsage(p,messages,result,turn);
      const calls=result.toolCalls||[];if(!calls.length)return {...result,text:this.change(turn)?result.text||'已修改当前文档。':(!editing||turn.requestContext?.createdFiles?.length||turn.execution?.some(e=>e.name==='run_shell_command'&&e.startedAt))?result.text||'处理完成。':'未修改文档。\n\n'+result.text};
      if(result.finishReason==='length')throw Error('编辑指令未完整生成，文档未修改');
      const outputs=[];
      for(const call of calls){
        let guarded=false;try{const execute=async item=>{guard();guarded=true;return this.executeCall(call,calls,{a,p,turn,file,get expected(){return expected;},set expected(v){expected=v;},get readDocument(){return readDocument;},set readDocument(v){readDocument=v;},options,editing,item});};outputs.push(await ETAIExecution.tool(turn,{...call,round:turn.executionRound||round+1},execute,options,file));}
        catch(e){if(!guarded||e.executionFatal||e.name==='AbortError'||e.documentChanged)throw e;outputs.push({error:e.message});}
      }
      messages=ETAIClient.continueTools(messages,result,outputs);
    }
    if(!editing||turn.requestContext?.createdFiles?.length)return {text:'已保留本轮取得的结果。本次已达到 '+EditingToolbarAIDocumentEdit.maxRounds+' 轮处理上限，任务可能尚未完成，可继续提问。',finishReason:'stop'};
    return {text:(this.change(turn)?'已保留本次应用的修改。':'未修改文档。')+'本次已达到 '+EditingToolbarAIDocumentEdit.maxRounds+' 轮编辑上限，任务可能尚未完成，可继续提问。',finishReason:'stop'};
  }
  async executeCall(call,calls,state){
    const {a,p,turn,file,options,editing}=state;let expected=state.expected;
    if(['read_skill','read_skill_resource','run_skill_script'].includes(call.name)){if(!options.skillSession)throw Error('本轮未启用技能');return options.skillSession.execute(call,state.item);}
    if(call.name==='plugin_read')return a.pluginsUI.execute(p,call,options);
    if(call.name==='run_shell_command')return a.shellUI.execute(p,call,options,turn,state.item);
    if(['web_search','read_web_page','create_project_file'].includes(call.name))return a.webUI.execute(p,call,options,turn);
    if(editing&&call.name==='read_current_document'){if(expected.length>100000)return {error:'当前文档超过 10 万字符，请选择需要的章节或段落。'};state.readDocument=true;return {untrusted_reference:true,file,markdown:expected};}
    if(editing&&call.name==='edit_current_document'&&!state.readDocument)return {applied:false,error:'请先调用 read_current_document 读取当前文档，再提交精确替换。'};
    if(!editing||calls.filter(c=>c.name==='edit_current_document').length!==1||call.name!=='edit_current_document')return {applied:false,error:'未知工具或本轮文档编辑调用超过一次'};
    let args,next;try{args=JSON.parse(call.arguments);next=ETAIDocumentEdit.apply(expected,args,ETAIDocumentEdit.markdown);}catch(e){return {applied:false,error:e.message};}if(next===expected)return {applied:false,unchanged:true};
    const before=this.change(turn)?.before??expected;let actual,writeError;try{actual=this.write(next);}catch(e){actual=a.source();if(a.file()!==file||actual===expected)throw Object.assign(e,{executionFatal:true});writeError=e;}state.expected=actual;
    turn.requestContext={...turn.requestContext,documentEdit:{file,before,after:actual,summary:args.summary.slice(0,500),time:new Date().toISOString()}};
    this.render(turn);a.conversations.flush();if(writeError)throw Object.assign(Error('文档已发生修改，但刷新失败；可查看变更或撤销。'+writeError.message),{executionFatal:true});return {applied:true,...(actual!==next?{current_markdown:actual}:{})};
  }
  render(turn){
    const change=this.change(turn);if(!change||!turn.article?.isConnected)return;
    const signature=change.before+'\0'+change.after;if(turn.editSignature===signature){this.syncCard(turn);return;}turn.editSignature=signature;
    const a=this.ai,rows=ETAIDocumentEdit.diff(change.before,change.after);turn.editRows=rows;turn.editCounts={added:rows.filter(r=>r.type==='add').length,removed:rows.filter(r=>r.type==='delete').length};
    turn.editCard?.remove();const card=turn.editCard=a.node('section','et-ai-edit-card');card.setAttribute('aria-label','文档修改结果');
    const icon=a.node('span','et-ai-edit-icon');icon.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h12a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2ZM9 9h6m-3-3v6m-3 4h6"/></svg>';
    const file=a.node('button','et-ai-edit-file');file.type='button';file.title=change.file;file.append(a.node('strong','','已编辑 '+reqnode('path').basename(change.file)));const second=a.node('span','et-ai-edit-subline');second.append(this.counts(turn),a.node('span','et-ai-edit-hint','查看变更 ↗'));file.append(second);file.setAttribute('aria-label','查看 '+reqnode('path').basename(change.file)+' 的变更');
    const undo=turn.editUndo=a.node('button','et-ai-edit-undo','撤销 ↶');undo.type='button';undo.onclick=()=>this.undo(turn);const view=a.node('button','et-ai-edit-open','查看变更');view.type='button';view.onclick=()=>this.openReview(turn);file.onclick=()=>this.openReview(turn);
    for(const b of [file,view]){b.onpointerenter=()=>this.schedulePreview(b,turn);b.onpointerleave=()=>this.scheduleClose();b.onfocus=()=>this.schedulePreview(b,turn);b.onblur=()=>this.scheduleClose();}
    card.append(icon,file,undo,view);turn.actions.before(card);this.syncCard(turn);
  }
  counts(turn){const node=this.ai.node('span','et-ai-edit-counts');node.append(this.ai.node('span','et-ai-added','+'+turn.editCounts.added),this.ai.node('span','et-ai-removed','−'+turn.editCounts.removed));return node;}
  syncCard(turn,current){
    const c=this.change(turn);if(!c||!turn.editUndo)return;
    let text=current;try{if(text==null)text=this.ai.source();}catch{}
    const same=this.ai.file()===c.file,undone=same&&text===c.before;turn.editUndo.textContent=undone?'已撤销':'撤销 ↶';turn.editUndo.disabled=this.ai.busy||!same||text!==c.after||File.isFileLoading?.();turn.editUndo.title=undone?'文档已恢复到修改前':!same?'打开对应文档后撤销':text!==c.after?'文档已有后续修改，无法直接撤销这次变更':'撤销这次文档修改';
  }
  syncMode(){if(!this.modeGroup)return;for(const [button,enabled] of [[this.ask,false],[this.mode,true]]){button.disabled=!!this.ai.busy||enabled&&!!this.ai.webChat?.active();if(enabled&&this.ai.webChat?.active())button.title='GPT 网页通道支持聊天和文档上传；本机编辑请使用助手模型';button.setAttribute('aria-pressed',String(this.enabled===enabled));}this.modeGroup.dataset.mode=this.enabled?'edit':'ask';this.ai.webUI?.sync();}
  sync(){this.syncMode();if(!this.ai.turns.some(t=>this.change(t)))return;let current;try{current=this.ai.source();}catch{}for(const t of this.ai.turns)this.syncCard(t,current);}
  undo(turn){try{const c=this.change(turn);if(this.ai.busy||!c)return;this.assert(c.file,c.after);this.write(c.before);this.sync();this.ai.notice('已撤销本次文档修改');}catch(e){this.ai.notice(e.message,true);}}
  diffBody(turn){
    const body=this.ai.node('div','et-ai-diff-body');body.tabIndex=0;body.setAttribute('aria-label','修改前后差异，红色为删除，绿色为新增');
    for(const r of ETAIDocumentEdit.hunks(turn.editRows)){const line=this.ai.node('div','et-ai-diff-line');line.dataset.type=r.type;line.append(this.ai.node('span','et-ai-diff-number',r.old==null?'':String(r.old)),this.ai.node('span','et-ai-diff-number',r.next==null?'':String(r.next)),this.ai.node('span','et-ai-diff-sign',r.type==='add'?'+':r.type==='delete'?'−':''),this.ai.node('code','',r.text));body.append(line);}
    if(!body.childElementCount)body.append(this.ai.node('p','','没有行内容差异（仅行尾换行可能不同）。'));return body;
  }
  head(turn,close){const head=this.ai.node('div','et-ai-diff-head'),name=this.ai.node('strong','',reqnode('path').basename(this.change(turn).file));name.title=this.change(turn).file;head.append(name,this.counts(turn));if(close){const b=this.ai.node('button','','×');b.type='button';b.setAttribute('aria-label','关闭变更');b.onclick=close;head.append(b);}return head;}
  schedulePreview(anchor,turn){clearTimeout(this.hoverTimer);clearTimeout(this.closeTimer);this.hoverTimer=setTimeout(()=>{if(!anchor.isConnected||this.dialog?.open)return;this.anchor=anchor;this.preview.replaceChildren(this.head(turn),this.diffBody(turn));this.preview.showPopover();const r=anchor.getBoundingClientRect(),width=Math.min(760,innerWidth-24);this.preview.style.width=width+'px';this.preview.style.maxHeight=Math.min(420,innerHeight-24)+'px';const h=this.preview.getBoundingClientRect().height;this.preview.style.left=Math.max(12,Math.min(r.left,innerWidth-width-12))+'px';this.preview.style.top=Math.max(12,r.top>=h+12?r.top-h-6:Math.min(r.bottom+6,innerHeight-h-12))+'px';},800);}
  scheduleClose(){clearTimeout(this.hoverTimer);clearTimeout(this.closeTimer);this.closeTimer=setTimeout(()=>this.closePreview(),180);}
  closePreview(){clearTimeout(this.hoverTimer);clearTimeout(this.closeTimer);if(this.preview?.matches(':popover-open'))this.preview.hidePopover();}
  openReview(turn){this.closePreview();this.dialog?.remove();const d=this.dialog=this.ai.node('dialog','et-ai-edit-review');d.setAttribute('aria-label','查看文档变更');const close=()=>d.close();d.append(this.head(turn,close),this.diffBody(turn));document.body.append(d);d.showModal();d.querySelector('button').focus();d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)d.close();}});}
}
