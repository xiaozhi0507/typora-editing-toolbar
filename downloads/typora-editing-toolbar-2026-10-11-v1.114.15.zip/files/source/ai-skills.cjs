'use strict';
const YAML=require('yaml');
const SkillZip=require('./ai-skill-zip.cjs');
// Storage is independent of Codex. Nothing here executes skill instructions or scripts.
class AISkills {
 constructor(req,directory){this.req=req;this.fs=req('fs');this.path=req('path');this.crypto=req('crypto');this.directory=directory;this.owned=this.path.join(directory,'installed');this.registry=this.path.join(directory,'registry.json');}
 static parse(source,appearance=''){
  const match=String(source).replace(/^\uFEFF/,'').match(/^---\s*\r?\n([\s\S]*?)\r?\n---\s*(?:\r?\n|$)([\s\S]*)$/);
  if(!match)throw Error('SKILL.md 缺少 YAML 元数据区（---）');
  const yaml=text=>{const d=YAML.parseDocument(text,{uniqueKeys:true});if(d.errors.length)throw Error('YAML 格式错误：'+d.errors[0].message);return d.toJS({maxAliasCount:30});};
  const data=yaml(match[1]),extra=appearance?yaml(appearance):{};
  if(!data||typeof data.name!=='string'||!data.name.trim()||data.name.length>100||!/^[\p{L}\p{N}][\p{L}\p{N}_.-]*$/u.test(data.name))throw Error('技能 name 必须为 1–100 个字母、数字、汉字、点、横线或下划线，不能含空格');
  if(typeof data.description!=='string'||!data.description.trim()||data.description.length>8192)throw Error('技能 description 缺失或超过 8192 字符');
  if(!match[2].trim())throw Error('SKILL.md 正文为空');
  const ui=extra?.interface||{},policy=extra?.policy||{};
  if(policy.allow_implicit_invocation!=null&&typeof policy.allow_implicit_invocation!=='boolean')throw Error('allow_implicit_invocation 必须为布尔值');
  const str=(v,f)=>typeof v==='string'&&v.trim()?v.trim():f;
  return {name:data.name,description:data.description.trim(),displayName:str(ui.display_name,str(data.metadata?.["display-name"],data.name)),shortDescription:str(ui.short_description,str(data.metadata?.["short-description"],data.description.trim())),icon:str(ui.icon_small,str(ui.icon_large,'')),defaultPrompt:str(ui.default_prompt,''),implicit:policy.allow_implicit_invocation!==false,dependencies:Array.isArray(extra?.dependencies?.tools)?extra.dependencies.tools:[],metadata:data.metadata||{},body:match[2].trim(),markdown:String(source)};
 }
 state(){try{const s=JSON.parse(this.fs.readFileSync(this.registry,'utf8'));if(s.version!==1||!Array.isArray(s.items))throw Error('格式不正确');return s;}catch(e){if(e.code==='ENOENT')return {version:1,automatic:true,items:[]};throw Error('技能管理数据无法读取：'+e.message);}}
 save(change){this.fs.mkdirSync(this.directory,{recursive:true});const lock=this.registry+'.lock';let fd,tmp;
  try{try{fd=this.fs.openSync(lock,'wx');}catch(e){throw Error('技能设置正在其他窗口中保存，请稍后重试');}const state=this.state();change(state);tmp=this.registry+'.'+this.crypto.randomUUID()+'.tmp';this.fs.writeFileSync(tmp,JSON.stringify(state,null,2));this.fs.renameSync(tmp,this.registry);return state;}
  finally{if(tmp&&this.fs.existsSync(tmp))this.fs.unlinkSync(tmp);if(fd!==undefined){this.fs.closeSync(fd);this.fs.unlinkSync(lock);}}
 }
 within(root,target){const rel=this.path.relative(root,target);return rel!== '..'&&!rel.startsWith('..'+this.path.sep)&&!this.path.isAbsolute(rel);}
 async resolve(root,relative){if(typeof relative!=='string'||!relative||relative.includes('\0')||this.path.isAbsolute(relative)||/^[a-z]:|^[\\/]/i.test(relative))throw Error('资源必须使用技能目录内的相对路径');const base=await this.fs.promises.realpath(root);if(base!==this.path.resolve(root))throw Error('技能目录已移动或链接已改变，请重新添加');const candidate=this.path.resolve(base,relative);if(!this.within(base,candidate))throw Error('资源路径超出技能目录');let real;try{real=await this.fs.promises.realpath(candidate);}catch(e){throw Error('资源不存在或不可读取：'+relative+'（'+e.code+'）');}if(!this.within(base,real))throw Error('资源链接指向技能目录之外：'+relative);return real;}
 async text(root,relative,max=200000){const file=await this.resolve(root,relative),stat=await this.fs.promises.stat(file);if(!stat.isFile())throw Error('资源不是文件：'+relative);if(stat.size>max)throw Error('资源超过读取上限 '+max+' 字节：'+relative);const data=await this.fs.promises.readFile(file);if(data.includes(0))throw Error('仅支持读取 UTF-8 文本资源：'+relative);return data.toString('utf8');}
 async inspect(root,entry='SKILL.md',replacement){let markdown;try{markdown=replacement??await this.text(root,entry);}catch(e){throw Error('技能目录不可用 '+root+'：'+e.message);}let appearance='';try{await this.fs.promises.access(this.path.join(root,'agents','openai.yaml'));appearance=await this.text(root,'agents/openai.yaml',64000);}catch(e){if(e.code!=='ENOENT')throw e;}
  const skill=AISkills.parse(markdown,appearance);skill.warnings=[];
  const references=[...skill.body.matchAll(/\]\(<?((?:\.\/)?(?:references|scripts|assets)\/[^\s)>]+)>?(?:\s+"[^"]*")?\)/g)].map(m=>m[1].split('#')[0]);
  for(const ref of new Set(references))try{await this.resolve(root,decodeURIComponent(ref));}catch(e){skill.warnings.push(e.message);}
  if(skill.icon){try{const file=await this.resolve(root,skill.icon),ext=this.path.extname(file).toLowerCase(),stat=await this.fs.promises.stat(file);if(!['.png','.jpg','.jpeg','.webp','.svg'].includes(ext)||stat.size>256000)throw Error('图标必须为不超过 256 KB 的 PNG/JPG/WebP/SVG');const data=await this.fs.promises.readFile(file);skill.iconData='data:image/'+({'.svg':'svg+xml','.jpg':'jpeg','.jpeg':'jpeg'}[ext]||ext.slice(1))+';base64,'+data.toString('base64');}catch(e){skill.warnings.push('图标：'+e.message);}}
  return skill;
 }
 async list(){const state=this.state();return Promise.all(state.items.map(async row=>{try{return {...row,...await this.inspect(row.root,row.entry)};}catch(e){return {...row,error:e.message,warnings:[]};}}));}
 async location(id){
  const row=this.state().items.find(s=>s.id===id);if(!row)throw Error('技能已卸载，请刷新列表');
  const root=await this.fs.promises.realpath(row.root),stat=await this.fs.promises.lstat(row.root);
  if(root!==this.path.resolve(row.root)||stat.isSymbolicLink()||!stat.isDirectory())throw Error('技能目录已移动或链接已改变，请重新添加');
  return {...row,root};
 }
 async exportZip(id,destination){
  const row=await this.location(id),skill=await this.inspect(row.root,row.entry),entry=row.entry||'SKILL.md';
  if(skill.name!==row.name)throw Error('技能 name 已改变，请重新添加后打包');
  if(typeof destination!=='string'||!destination.trim())throw Error('请选择保存文件夹');
  const output=await this.fs.promises.realpath(destination);
  if(!(await this.fs.promises.stat(output)).isDirectory())throw Error('请选择保存文件夹');
  if(this.within(row.root,output))throw Error('请选择技能目录之外的保存文件夹');
  const files=new Map(),keys=new Set();let total=0;
  const collect=async(relative,depth=0)=>{
   if(depth>32)throw Error('技能资源目录层级过深');
   const file=await this.resolve(row.root,relative),stat=await this.fs.promises.lstat(this.path.join(row.root,relative));
   if(stat.isSymbolicLink())throw Error('打包不支持符号链接：'+relative);
   if(stat.isDirectory()){for(const name of (await this.fs.promises.readdir(file)).sort())await collect(this.path.join(relative,name),depth+1);return;}
   if(!stat.isFile())throw Error('不支持的技能资源：'+relative);
   const name=relative===entry?'SKILL.md':relative.split(this.path.sep).join('/');SkillZip.safe(name);
   if(name!=='SKILL.md'&&/(^|\/)skill\.md$/i.test(name))throw Error('技能包包含其他 SKILL.md，请分别打包');
   if(keys.has(name.toLowerCase()))throw Error('技能资源名称冲突：'+name);keys.add(name.toLowerCase());
   if(files.size>=4000||stat.size>16*1024**2||total+stat.size>64*1024**2)throw Error('技能包超过 4000 文件、单文件 16 MiB 或总计 64 MiB');
   const bytes=await this.fs.promises.readFile(file),after=await this.fs.promises.stat(file);
   if(bytes.length!==stat.size||after.size!==stat.size||after.mtimeMs!==stat.mtimeMs)throw Error('技能文件在打包期间发生变化，请重试：'+relative);
   files.set(name,bytes);total+=bytes.length;
  };
  // Legacy single-Markdown references may share a parent with other skills.
  // Match copy-import's resource selection without exporting unrelated siblings.
  if(/^skill\.md$/i.test(entry)){for(const name of (await this.fs.promises.readdir(row.root)).sort())await collect(name);}
  else {
   await collect(entry);const resources=new Set(['references','scripts','assets','agents']);
   for(const match of skill.markdown.matchAll(/\]\(<?([^\s)>]+)>?(?:\s+"[^"]*")?\)/g)){
    let relative;try{relative=decodeURIComponent(match[1].split('#')[0]);}catch(e){continue;}
    if(!relative||/^[a-z][\w+.-]*:|^[\\/]/i.test(relative))continue;
    const target=this.path.resolve(row.root,relative);if(!this.within(row.root,target)||target===row.root)throw Error('技能引用了目录外资源：'+relative);
    resources.add(this.path.relative(row.root,target).split(this.path.sep)[0]);
   }
   for(const relative of resources)if(relative!==entry&&this.fs.existsSync(this.path.join(row.root,relative)))await collect(relative);
  }
  const bytes=await new SkillZip(this.req).pack(files);
  let name=skill.name.replace(/[. ]+$/g,'');if(/^(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\.|$)/i.test(name))name='skill-'+name;
  for(let n=1;n<=1000;n++){
   const target=this.path.join(output,name+(n===1?'':' ('+n+')')+'.zip');let handle;
   try{handle=await this.fs.promises.open(target,'wx');}catch(e){if(e.code==='EEXIST')continue;throw e;}
   try{await handle.writeFile(bytes);await handle.close();return {path:target,files:files.size,bytes:bytes.length};}
   catch(e){await handle.close().catch(()=>{});await this.fs.promises.unlink(target).catch(()=>{});throw e;}
  }
  throw Error('同名压缩包过多，请选择其他保存文件夹');
 }
 // Import accepts one skill package, one Markdown file, or a collection for the picker.
 async discover(input){
  if(String(input).startsWith('skill-zip:'))return [input];
  const value=String(input||'').trim().replace(/^"(.*)"$/,'$1');if(!value)throw Error('请选择技能文件夹，或拖入技能 Markdown 文件');
  let location,stat;try{location=await this.fs.promises.realpath(value);stat=await this.fs.promises.stat(location);}catch(e){throw Error('路径不存在或无法读取：'+value+'（'+e.code+'）');}
  if(stat.isFile()){if(/\.zip$/i.test(location)){const zip=await new SkillZip(this.req).read(location);return zip.entries.map(entry=>SkillZip.token(zip,entry));}if(!/\.md$/i.test(location))throw Error('请选择技能 Markdown 或 ZIP 文件（.md / .zip）');return [location];}
  if(!stat.isDirectory())throw Error('请选择技能文件或文件夹');
  const entries=await this.fs.promises.readdir(location,{withFileTypes:true});const standard=entries.find(e=>e.isFile()&&/^skill\.md$/i.test(e.name));if(standard)return [this.path.join(location,standard.name)];
  const found=entries.filter(e=>e.isFile()&&/\.md$/i.test(e.name)).map(e=>this.path.join(location,e.name));
  for(const ent of entries){if(!ent.isDirectory()||ent.name.startsWith('.')||['node_modules','references','scripts','assets','agents'].includes(ent.name))continue;const folder=this.path.join(location,ent.name);let children;try{children=await this.fs.promises.readdir(folder,{withFileTypes:true});}catch(e){continue;}const file=children.find(e=>e.isFile()&&/^skill\.md$/i.test(e.name));if(file)found.push(this.path.join(folder,file.name));if(found.length>100)break;}
  if(found.length>100)throw Error('目录包含超过 100 个技能，请选择更具体的文件夹');if(!found.length)throw Error('未找到技能 Markdown 文件：'+location+'。请选择包含 SKILL.md 或其他技能 .md 文件的目录');return found.sort((a,b)=>a.localeCompare(b));
 }
 async preview(input){
  if(String(input).startsWith('skill-zip:')){const zip=await new SkillZip(this.req).selected(input);if(zip.files.get(zip.entry).length>200000||(zip.files.get(zip.prefix+'agents/openai.yaml')?.length||0)>64000)throw Error('ZIP 技能元数据或正文过大');const markdown=zip.files.get(zip.entry).toString('utf8'),appearance=zip.files.get(zip.prefix+'agents/openai.yaml')?.toString('utf8')||'',skill=AISkills.parse(markdown,appearance);return {...skill,file:input,archive:zip.file,entry:zip.entry,needsMetadata:false,resourceCount:[...zip.files.keys()].filter(p=>p.startsWith(zip.prefix)).length};}
  const files=await this.discover(input);if(files.length!==1)throw Error('找到 '+files.length+' 个技能文件，请在添加窗口中选择');
  if(String(files[0]).startsWith('skill-zip:'))return this.preview(files[0]);
  const file=files[0],root=this.path.dirname(file),entry=this.path.basename(file),markdown=await this.text(root,entry),plain=markdown.replace(/^\uFEFF/,'');
  if(!plain.trim())throw Error('技能文件为空：'+entry);
  const needsMetadata=!/^---\s*(?:\r?\n|$)/.test(plain);
  if(!needsMetadata)return {file,root,entry,needsMetadata:false,...await this.inspect(root,entry)};
  const heading=plain.match(/^#\s+(.+)$/m)?.[1]?.trim()||entry.replace(/\.md$/i,'');
  const name=heading.replace(/\s+skill$/i,'').replace(/[^\p{L}\p{N}_.-]+/gu,'-').replace(/^[^\p{L}\p{N}]+|[-.]+$/gu,'').slice(0,100)||'local-skill';
  const paragraph=plain.split(/\r?\n\s*\r?\n/).map(x=>x.trim()).find(x=>x&&!/^(?:#|[-*+>\x60]|\d+[.)]|版本|建立日期|最近修订|当前维护文件|version|date)/i.test(x));
  return {file,root,entry,needsMetadata:true,name,displayName:heading,description:(paragraph||heading).replace(/\r?\n/g,' ').replace(/\*\*/g,'').slice(0,1024),markdown};
 }
 async add(input,mode='copy',metadata){
  if(/\.zip$/i.test(String(input))&&!String(input).startsWith('skill-zip:')){const entries=await this.discover(input);if(entries.length!==1)throw Error('ZIP 中包含 '+entries.length+' 个技能，请从预览列表选择');input=entries[0];}
  if(String(input).startsWith('skill-zip:'))return this.addZip(input,mode);
  if(!['reference','copy'].includes(mode))throw Error('未知安装方式');const candidate=await this.preview(input),{root,entry,file}=candidate;
  if(mode==='reference'&&candidate.needsMetadata)throw Error('此 Markdown 缺少标准元数据，请复制安装');
  let markdown=candidate.markdown;if(candidate.needsMetadata){const name=String(metadata?.name??candidate.name).trim(),description=String(metadata?.description??candidate.description).trim();markdown='---\n'+YAML.stringify({name,description,metadata:{'display-name':candidate.displayName}})+'---\n\n'+markdown;}
  let skill=await this.inspect(root,entry,markdown);
  if(this.state().items.some(s=>s.name.toLowerCase()===skill.name.toLowerCase()))throw Error('技能重名：'+skill.name+'。请先卸载旧技能，或使用不同的 name');
  const id=this.crypto.randomUUID();let target=root,targetEntry=entry;
  if(mode==='copy'){await this.fs.promises.mkdir(this.owned,{recursive:true});target=this.path.join(this.owned,id);targetEntry='SKILL.md';const ownedReal=await this.fs.promises.realpath(this.owned);if(/^skill\.md$/i.test(entry)&&this.within(root,ownedReal))throw Error('不能将技能复制到自己的子目录');let count=0,bytes=0;
   const copy=async(from,to)=>{const stat=await this.fs.promises.lstat(from);if(stat.isSymbolicLink())throw Error('复制安装不支持符号链接：'+from);if(stat.isDirectory()){if(this.within(this.path.resolve(from),ownedReal))throw Error('资源目录包含插件存储目录，无法复制');await this.fs.promises.mkdir(to,{recursive:true});for(const ent of await this.fs.promises.readdir(from))await copy(this.path.join(from,ent),this.path.join(to,ent));}else if(stat.isFile()){if(++count>4000||(bytes+=stat.size)>64*1024*1024)throw Error('技能包超过 4000 文件或 64 MiB');await this.fs.promises.mkdir(this.path.dirname(to),{recursive:true});await this.fs.promises.copyFile(from,to);}else throw Error('技能包含不支持的资源类型：'+from);};
   try{
    if(/^skill\.md$/i.test(entry))await copy(root,target);
    else {await this.fs.promises.mkdir(target);const resources=new Set(['references','scripts','assets','agents']);
     // Keep explicitly linked relative resources, never unrelated sibling skill documents.
     for(const match of markdown.matchAll(/\]\(<?([^\s)>]+)>?(?:\s+"[^"]*")?\)/g)){let relative;try{relative=decodeURIComponent(match[1].split('#')[0]);}catch(e){continue;}if(!relative||/^[a-z][\w+.-]*:|^[\\/]/i.test(relative))continue;const candidatePath=this.path.resolve(root,relative);if(!this.within(root,candidatePath)||candidatePath===root){skill.warnings.push('未复制目录外资源：'+relative);continue;}resources.add(this.path.relative(root,candidatePath).split(this.path.sep)[0]);}
     for(const relative of resources){const from=this.path.join(root,relative);if(from===file||!this.fs.existsSync(from))continue;await copy(from,this.path.join(target,relative));}
    }
    if(entry!=='SKILL.md'&&/^skill\.md$/i.test(entry))await this.fs.promises.rename(this.path.join(target,entry),this.path.join(target,'SKILL.md'));
    await this.fs.promises.writeFile(this.path.join(target,'SKILL.md'),markdown,'utf8');
   }catch(e){await this.removeOwned(id);throw e;}
  }
  const row={id,name:skill.name,displayName:skill.displayName,description:skill.description,root:target,entry:targetEntry,source:file,mode,enabled:true,addedAt:new Date().toISOString()};
  try{this.save(s=>{if(s.items.some(x=>x.name.toLowerCase()===row.name.toLowerCase()))throw Error('技能重名：'+row.name);s.items.push(row);});}catch(e){if(mode==='copy')await this.removeOwned(id);throw e;}return {...row,...skill};
 }
 async addZip(input,mode){
  if(mode!=='copy')throw Error('ZIP 技能只能复制安装');
  const zip=await new SkillZip(this.req).selected(input),skill=AISkills.parse(zip.files.get(zip.entry).toString('utf8'));
  if(this.state().items.some(x=>x.name.toLowerCase()===skill.name.toLowerCase()))throw Error('技能重名：'+skill.name);
  const id=this.crypto.randomUUID(),target=this.path.join(this.owned,id);await this.fs.promises.mkdir(target,{recursive:true});
  try{for(const [name,bytes] of zip.files){if(!name.startsWith(zip.prefix))continue;let relative=name.slice(zip.prefix.length);if(name===zip.entry)relative='SKILL.md';const to=this.path.resolve(target,relative);if(!this.within(target,to))throw Error('ZIP 路径超出技能目录');await this.fs.promises.mkdir(this.path.dirname(to),{recursive:true});await this.fs.promises.writeFile(to,bytes,{flag:'wx'});}
   const detail=await this.inspect(target),row={id,name:detail.name,displayName:detail.displayName,description:detail.description,root:target,entry:'SKILL.md',source:zip.file+' / '+zip.entry,mode:'copy',enabled:true,addedAt:new Date().toISOString()};
   this.save(s=>{if(s.items.some(x=>x.name.toLowerCase()===row.name.toLowerCase()))throw Error('技能重名：'+row.name);s.items.push(row);});return {...row,...detail};
  }catch(e){await this.removeOwned(id);throw e;}
 }
 async removeOwned(id){if(!/^[a-f0-9-]{36}$/.test(id))throw Error('无效技能 ID');const target=this.path.resolve(this.owned,id);if(this.path.dirname(target)!==this.path.resolve(this.owned))throw Error('无效副本路径');if(!this.fs.existsSync(target))return;const base=await this.fs.promises.realpath(this.owned),stat=await this.fs.promises.lstat(target);if(stat.isSymbolicLink()||this.path.dirname(await this.fs.promises.realpath(target))!==base)throw Error('副本目录已被替换，拒绝删除');await this.fs.promises.rm(target,{recursive:true});}
 async uninstall(id){const row=this.state().items.find(x=>x.id===id);if(!row)throw Error('技能不存在');if(row.mode==='copy'){if(this.path.resolve(row.root)!==this.path.resolve(this.owned,id))throw Error('副本路径无效，未删除');await this.removeOwned(id);}this.save(s=>{s.items=s.items.filter(x=>x.id!==id);});}
 enable(id,enabled){this.save(s=>{const row=s.items.find(x=>x.id===id);if(!row)throw Error('技能不存在');row.enabled=!!enabled;});}
 active(name){const row=this.state().items.find(x=>x.name.toLowerCase()===String(name).toLowerCase());if(!row)throw Error('技能未安装：'+name);if(!row.enabled)throw Error('技能已禁用：'+name);return row;}
 async inventory(root){const files=[];const scan=async(dir,depth=0)=>{if(depth>5||files.length>=300)return;for(const ent of await this.fs.promises.readdir(this.path.join(root,dir),{withFileTypes:true})){if(files.length>=300)break;const relative=(dir?dir+'/':'')+ent.name;if(ent.isSymbolicLink())continue;if(ent.isDirectory())await scan(relative,depth+1);else if(ent.isFile())files.push(relative);}};await scan('');return files;}
 async load(name){const row=this.active(name),skill=await this.inspect(row.root,row.entry);if(skill.name!==row.name)throw Error('技能 name 已改变，请卸载旧引用后重新添加');return {...row,...skill,resources:await this.inventory(row.root)};}
 async resource(name,relative){const row=this.active(name);return {name,path:relative,content:await this.text(row.root,relative),untrusted_reference:true};}
 static mentions(text){return [...new Set([...String(text).matchAll(/(?:^|\s)\$([\p{L}\p{N}][\p{L}\p{N}_.-]*)(?=$|\s|[，。！？,;:!?])/gu)].map(m=>m[1]))];}
 static quote(value){return "'"+String(value).replace(/'/g,"''")+"'";}
 async script(name,relative,args=[]){const row=this.active(name);if(!/^scripts[\\/]/.test(relative)||!Array.isArray(args)||args.length>40||args.some(x=>typeof x!=='string'||x.includes('\0')||x.length>2000))throw Error('脚本须位于 scripts/，参数须为字符串数组');const file=await this.resolve(row.root,relative),ext=this.path.extname(file).toLowerCase(),runner={'.py':'python','.js':'node','.cjs':'node','.mjs':'node','.ps1':'powershell.exe'}[ext];if(!runner)throw Error('脚本格式不支持；支持 Python、JavaScript 和 PowerShell');return '& '+runner+' '+(ext==='.ps1'?'-NoLogo -NoProfile -NonInteractive -File ':'')+AISkills.quote(file)+' '+args.map(AISkills.quote).join(' ');}
}
module.exports=AISkills;
