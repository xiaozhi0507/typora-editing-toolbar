// Display preferences only: never serialize layout into Markdown.
const key='et-paragraph-spacing-v1';
const fields={line:{min:1,max:3,step:.05},paragraph:{min:0,max:3,step:.1}};
function value(name,input){
 const limits=fields[name];if(!limits||input===null||input===''||typeof input==='boolean')return null;
 const n=Number(input);if(!Number.isFinite(n))return null;
 return Number((Math.round(Math.max(limits.min,Math.min(limits.max,n))/limits.step)*limits.step).toFixed(2));
}
function normalize(input){return {line:value('line',input?.line),paragraph:value('paragraph',input?.paragraph)};}
function read(raw){try{return normalize(JSON.parse(raw));}catch{return normalize(null);}}
function css(input){
 const state=normalize(input),exclude=':not(:where(table *,pre *,.md-fences *,.md-htmlblock *,.md-math-block *,.md-diagram-panel *))';
 const paragraphs='#write p'+exclude,lines=paragraphs+',#write li'+exclude;
 return '@media screen {'+(state.line===null?'':lines+'{line-height:'+state.line.toFixed(2)+'!important;}')+
  (state.paragraph===null?'':paragraphs+'{margin-block-start:0!important;margin-block-end:'+state.paragraph.toFixed(1)+'em!important;}')+'}';
}
module.exports={key,fields,value,normalize,read,css};
