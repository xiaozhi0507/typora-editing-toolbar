const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const {TerminalTranscript}=require('./terminal-transcript.cjs');
test('AI command waits for an in-flight automatic terminal and honours cancellation before spawning',async()=>{
 let ready,created=0;
 const Panel=vm.runInNewContext(fs.readFileSync(__dirname+'/terminal-panel.js','utf8')+';EditingToolbarTerminal',{ETAIShell:{abort:()=>Object.assign(Error('cancelled'),{name:'AbortError'})}});
 const panel=Object.create(Panel.prototype);panel.creating=true;panel.sessionReady=new Promise(r=>ready=r);panel.newSession=async()=>{created++;throw Error('must not spawn')};
 const controller=new AbortController(),job=panel.executeCommand({}, {signal:controller.signal});await Promise.resolve();assert.equal(created,0);controller.abort();panel.creating=false;ready();await assert.rejects(job,{name:'AbortError'});assert.equal(created,0);
});
test('AI command continues once startup completes and drains the final transcript',async()=>{
 let ready,created=0,output='';
 const session={host:{isConnected:true},term:{buffer:{active:{baseY:0,viewportY:0}},write:(text,ack)=>{output+=text;ack();},reset(){output=''}},backend:{state:'idle'}};
 const Panel=vm.runInNewContext(fs.readFileSync(__dirname+'/terminal-panel.js','utf8')+';EditingToolbarTerminal',{
  AbortController,reqnode:n=>n==='process'?{resourcesPath:'test'}:require(n),ETTerminalTranscript:{TerminalTranscript},ETTerminalEnvironment:{environmentVariables:v=>v},ETAIShell:{},ETTerminalCommand:{TerminalCommand:class{async run(args,p){p.onUpdate({command:args.command,output:'first'});p.onUpdate({command:args.command,output:'first\nFINAL'});return {exitCode:0};}}}
 });
 const panel=Object.create(Panel.prototype);Object.assign(panel,{moduleRoot:'C:/test-ai-module',creating:true,sessionReady:new Promise(r=>ready=r),sessions:[],newSession:async()=>{created++;return session},status(){},renderTabs(){}});
 const job=panel.executeCommand({command:'python test.py'},{env:{},onUpdate(){}});await Promise.resolve();assert.equal(created,0);panel.creating=false;ready();const result=await job;assert.equal(result.exitCode,0);assert.equal(created,1);assert.equal(output,'> python test.py\r\n\r\nfirst\r\nFINAL');
});
