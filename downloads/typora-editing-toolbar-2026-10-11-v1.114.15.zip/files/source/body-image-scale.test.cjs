const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const {JSDOM}=require('jsdom');
function setup(){
 const {window}=new JSDOM('<!doctype html><body>');
 const runtime={editor:{sourceView:{}},bundle:{},isFileLoading:()=>false};
 const Scale=vm.runInNewContext(fs.readFileSync(__dirname+'/body-image-scale.js','utf8')+';EditingToolbarImageScale',{document:window.document,File:runtime});
 const scale=Object.create(Scale.prototype);
 const wrapper=(source,html=true)=>{const w=window.document.createElement('span');w.setAttribute('md-inline',html?'imgtag':'image');w.rawText=()=>source;
  if(html)w.innerHTML=source;else {w.innerHTML='<img alt="A &amp; B" title="标题">';w.setAttribute('data-src','assets/图 (1).png?a=1&b=2');}return w;};
 return {window,scale,wrapper,runtime};
}
test('Markdown images retain the exact source path, title and alternate text',()=>{
 const {scale,wrapper,window}=setup(),out=scale.imageMarkup(wrapper('![A & B](assets/a.png)',false),50),t=window.document.createElement('template');t.innerHTML=out;
 const image=t.content.firstChild;assert.equal(image.getAttribute('src'),'assets/图 (1).png?a=1&b=2');assert.equal(image.alt,'A & B');assert.equal(image.title,'标题');assert.equal(image.style.zoom,'50%');
});
test('100% leaves ordinary Markdown images untouched',()=>{
 const {scale,wrapper}=setup(),raw='![caption][shared]';assert.equal(scale.imageMarkup(wrapper(raw,false),100),raw);
});
test('absolute scaling clears prior dimensions, preserves unrelated attributes/styles, and is idempotent',()=>{
 const {scale,wrapper,window}=setup(),raw='<img src="a.png" width="800" height="600" data-note="keep" style="width:40%;height:100px;max-width:200px;min-height:30px;zoom:75%;border:1px solid red;display:block;margin:auto">';
 const out=scale.imageMarkup(wrapper(raw),25),t=window.document.createElement('template');t.innerHTML=out;const image=t.content.firstChild;
 assert.equal(image.style.zoom,'25%');for(const key of ['width','height','maxWidth','minHeight'])assert.equal(image.style[key],'');assert.equal(image.hasAttribute('width'),false);assert.equal(image.hasAttribute('height'),false);assert.equal(image.dataset.note,'keep');assert.equal(image.style.display,'block');assert.equal(image.style.margin,'auto');assert.match(image.style.border,/red/);assert.equal(scale.imageMarkup(wrapper(out),25),out);
});
test('100% clears zoom and sizing without deleting other image styles',()=>{
 const {scale,wrapper}=setup();assert.equal(scale.imageMarkup(wrapper('<img src="a.png" style="zoom:50%;">'),100),'<img src="a.png">');assert.match(scale.imageMarkup(wrapper('<img src="a.png" style="zoom:50%;border:0;">'),100),/border: 0/);
});
test('multiple inline replacements preserve links, text and cursor offset mapping',()=>{
 const {scale,wrapper,window}=setup(),block=window.document.createElement('p'),a=wrapper('![one](x)',false),b=wrapper('![two](y)',false);
 block.append('before ',a,' between ',b,' after');block.rawText=()=>[...block.childNodes].map(n=>n.rawText?n.rawText():n.textContent).join('');
 const original=block.rawText(),out=scale.blockChange(block,[a,b],75);assert.equal(out.count,2);assert.ok(out.text.startsWith('before <img'));assert.ok(out.text.endsWith(' after'));assert.ok(out.text.includes(' between '));assert.equal(out.mapOffset(3),3);assert.equal(out.mapOffset(original.length),out.text.length);
});
test('stale raw source aborts before an editor transaction',()=>{
 const {scale,wrapper,window}=setup(),block=window.document.createElement('p'),image=wrapper('![one](x)',false);block.append(image);block.rawText=()=> 'unexpected update';assert.throws(()=>scale.blockChange(block,[image],75),/图片源码正在更新/);
});
test('table transaction invalidates cached Markdown while preserving IDs and structure',()=>{
 const {scale}=setup(),root={id:'t',content:{type:'table',userText:'old',align:['left']},children:[{id:'r',content:{type:'table_row'},children:[{id:'c',content:{type:'table_cell',text:'old'},children:[]}]}]};
 scale.transform(root,new Map([['c',{text:'new'}]]));assert.equal(root.content.userText,undefined);assert.deepEqual(root.content.align,['left']);assert.equal(root.children[0].children[0].content.text,'new');assert.equal(root.children[0].children[0].id,'c');
});


test('ordinary reading mode permits image formatting while protected mode blocks the transaction',()=>{
 const {scale}=setup();const notices=[];
 scale.toolbar={centerCaptions:{enabled:()=>true},readingMode:{enabled:true,protected:false},_showToolbarNotice:t=>notices.push(t)};
 assert.equal(scale.enabled(),true);
 scale.toolbar.readingMode.protected=true;
 assert.equal(scale.enabled(),false);assert.match(scale.unavailableReason(),/保护模式/);
 scale.levels=[50];scale.run(50);assert.equal(notices.length,1);assert.match(notices[0],/保护模式/);
});

test('image formatting retains source, readonly, loading and active-resize restrictions with reasons',()=>{
 const {scale,runtime}=setup();scale.toolbar={centerCaptions:{enabled:()=>true},readingMode:{enabled:true,protected:false}};
 runtime.editor.sourceView.inSourceMode=true;assert.match(scale.unavailableReason(),/源代码/);runtime.editor.sourceView.inSourceMode=false;
 for(const target of [runtime,runtime.bundle]){target.isLocked=true;assert.match(scale.unavailableReason(),/锁定/);target.isLocked=false;}
 runtime.isReadonlyMode=true;assert.match(scale.unavailableReason(),/只读/);runtime.isReadonlyMode=false;
 runtime.isFileLoading=()=>true;assert.match(scale.unavailableReason(),/加载/);runtime.isFileLoading=()=>false;
 scale.toolbar.imageResizeState={};assert.match(scale.unavailableReason(),/拖动/);scale.toolbar.imageResizeState=null;
 assert.equal(scale.enabled(),true);
});
