class KnowledgeLibraryBackupUI {
 constructor(host){this.host=host;window.addEventListener('unload',()=>this.engine?.close(),{once:true});}
 get busy(){return !!this.engine?.state.busy;}
 async prepare(store=this.host.store){
  if(this.preparing)return this.preparing;
  return this.preparing=(async()=>{
   if(this.engine?.backup.store.root===store.root)return this.engine;
   if(this.busy)throw Error('请先完成或暂停同步');this.engine?.close();
   const h=this.host,a=h.toolbar.connections,p=a;await p.init();
   const cache=reqnode('path').join(File.option.userDataPath,'editing-toolbar','knowledge-backup-cache');
   const backup=new ETKnowledgeBackup(store,{Managed:ETKnowledgeManaged,Archive:ETKnowledgeArchive,Zip:ETKnowledgeZip,destination:cache});
   this.engine=new ETKnowledgeSync(backup,p.store.backup(),{flush:async()=>{
    if(reqnode('path').resolve(h.rootPath).toLowerCase()!==store.root.toLowerCase())throw Error('知识库已切换');if(h.store?.root===store.root&&h.ui&&!await h.ui.flush())throw Error('知识库尚未保存');h.flushBackupNotes();
   },changed:async()=>{if(h.store?.root===store.root)await h.ui?.refresh();h.graphChanged();},onState:s=>this.render(s)});
   await this.engine.start();return this.engine;
  })().finally(()=>this.preparing=null);
 }
 async boot(){try{const store=new ETKnowledgeStorage(this.host.rootPath,reqnode);if(!await store.io.stat(store.file).catch(()=>null))return;await store.read();await this.prepare(store);}catch(e){this.host.notice('云端同步：'+e.message);}}
 render(s){
  const a=this.host.toolbar.connections;if(!a)return;
  if(!this.indicator){const b=this.indicator=a.node('button','et-drive-sync-indicator');b.type='button';b.innerHTML='<span class="et-drive-sync-ring" aria-hidden="true"></span><span></span>';b.onclick=()=>this.host.openDriveBackup().catch(e=>this.host.notice(e.message));document.body.append(b);}
  this.indicator.hidden=!s.busy&&s.stage!=='error';this.indicator.classList.toggle('is-busy',s.busy);this.indicator.lastChild.textContent=s.text;this.indicator.title='Google Drive · '+s.text;this.indicator.setAttribute('aria-label',this.indicator.title);this.update?.(s);
 }
 async show(){
  if(this.dialog?.open){this.dialog.focus();return;}const engine=await this.prepare(),h=this.host,a=h.toolbar.connections,p=a,service=engine.drive,backup=engine.backup;
  const {d,error}=p.form('Google Drive 备份','et-drive-backup');this.dialog=d;
  const node=(tag,cls,text)=>a.node(tag,cls,text),controls=[];
  const run=fn=>Promise.resolve().then(fn).catch(e=>{if(d.open){error.textContent=e.message;error.hidden=false;}});
  const tip=(el,text)=>{el.dataset.syncTip=text;el.setAttribute('aria-description',text);return el;};
  const button=(text,hint,fn)=>{const b=p.button(text,()=>run(fn));tip(b,hint);controls.push(b);return b;};
  const body=node('div','et-drive-backup-body'),source=node('div','et-drive-backup-source');
   source.append(node('span','','当前知识库'),tip(node('strong','',reqnode('path').basename(backup.store.root)),backup.store.root));
   const heading=d.querySelector('.et-plugin-form-head h3');if(heading){const logo=node('span','et-drive-logo');logo.setAttribute('aria-hidden','true');logo.innerHTML='<svg viewBox="0 0 24 24"><path fill="#2684fc" d="M8 15h16l-4 7H4z"/><path fill="#00ac47" d="M8 1h8L4 22l-4-7z"/><path fill="#ffba00" d="m16 1 8 14h-8L8 1z"/></svg>';heading.prepend(logo);}
   const tabs=node('div','et-drive-tabs'),overview=node('section','et-drive-overview');
   tabs.setAttribute('role','tablist');tabs.setAttribute('aria-label','备份页面');
   const overviewTab=p.button('同步概览',()=>selectTab(false)),cloudTab=p.button('云端文件',()=>selectTab(true));
   overview.id='et-drive-overview';overviewTab.id='et-drive-overview-tab';overview.setAttribute('role','tabpanel');overview.setAttribute('aria-labelledby',overviewTab.id);
   for(const b of [overviewTab,cloudTab])b.setAttribute('role','tab');overviewTab.setAttribute('aria-controls',overview.id);tabs.append(overviewTab,cloudTab);
  const account=node('div','et-drive-backup-account'),accountName=node('strong'),avatar=node('span','et-drive-account-avatar');avatar.setAttribute('aria-hidden','true');avatar.textContent='G';
  const login=button('授权备份','备份使用独立授权，仅访问本插件创建的文件；保留现有 Codex 连接。',()=>engine.job(async options=>{
   await service.connect(url=>reqnode('electron').shell.openExternal(url),{...options,onProgress:stage=>options.onProgress(({waiting:'等待浏览器授权…',exchanging:'正在验证授权…',verifying:'正在验证账户…',saving:'正在保存授权…'})[stage]||'正在打开浏览器…','authorizing')});
   engine.emit({text:'授权成功',stage:'idle'});engine.queue();await config();
  }));account.append(avatar,accountName,login);
  const realtime=node('label','et-drive-sync-toggle'),toggle=node('input');toggle.type='checkbox';toggle.setAttribute('role','switch');toggle.setAttribute('aria-label','实时同步');
  realtime.append(node('span','','实时同步'),toggle);tip(realtime,'Typora 运行期间，保存后的文件变化会自动上传。连续修改合并处理；网络恢复后自动重试。云端旧版本继续保留。');toggle.onchange=()=>run(()=>engine.setEnabled(toggle.checked));
  const setup=node('details','et-drive-backup-setup');setup.append(node('summary','','账户设置'));
  const configure=button('导入 OAuth 配置','选择 Google 桌面应用的 OAuth JSON。已有配置可以继续使用。',()=>engine.job(async()=>{
   const picked=await JSBridge.invoke('dialog.showOpenDialog',{title:'选择 Google 桌面应用 OAuth JSON',properties:['openFile'],filters:[{name:'OAuth JSON',extensions:['json']}]});if(!picked?.filePaths?.[0])return;
   const fs=reqnode('fs').promises,file=picked.filePaths[0];if((await fs.stat(file)).size>64000)throw Error('配置文件过大');await p.store.configureGoogle(await fs.readFile(file,'utf8'));await config();engine.emit({text:'配置已保存，请授权备份',stage:'idle'});
  }));
  const settings=button('Google 授权设置','测试状态下，需在“受众”中加入测试用户。测试授权通常 7 天到期；长期使用可正式发布后重新授权。',()=>reqnode('electron').shell.openExternal('https://console.cloud.google.com/auth/audience'));
  const disconnect=button('断开授权','只断开备份授权；保留云端文件和 Codex 连接。',()=>engine.job(async()=>{await service.disconnect();await config();engine.emit({text:'已断开备份授权',stage:'idle'});}));setup.append(configure,settings,disconnect);
  const preview=node('div','et-drive-backup-preview'),stats=node('div','et-drive-backup-stats');tip(preview,'本机变化与上次本地备份比较；条目包含回收站，文件数包含附件。云端待上传数量单独核对，相同内容只上传一份。');preview.append(stats);const statsNote=node('small','et-drive-stats-note');preview.append(statsNote);
  const status=node('p','et-drive-backup-status'),history=node('p','et-drive-backup-history');status.setAttribute('role','status');status.setAttribute('aria-live','polite');
   const stateCard=node('div','et-drive-state'),stateMark=node('span','et-drive-state-mark'),stateCopy=node('div','et-drive-state-copy'),stateTitle=node('strong','et-drive-state-title'),pendingBadge=node('span','et-drive-pending');
   stateMark.setAttribute('aria-hidden','true');stateCopy.append(stateTitle,status,history,error);stateCard.append(stateMark,stateCopy,pendingBadge);
  const scan=button('扫描变化','检查已保存的文件和云端备份，显示待上传数量。',()=>engine.scan());
  const upload=button('立即同步','上传新增或修改的文件。关闭此窗口后仍会继续；可在左下角查看进度。',()=>engine.upload());upload.classList.add('et-drive-backup-primary');
  const cancel=p.button('暂停本次任务',()=>engine.cancel());tip(cancel,'停止当前传输，已上传内容保留；下次从已确认的位置继续。');
  const open=button('查看云端','在 Google Drive 中打开当前知识库的备份目录。',()=>engine.state.last?.url&&reqnode('electron').shell.openExternal(engine.state.last.url));
  const actions=node('div','et-drive-backup-actions');actions.append(open,scan,upload,cancel);
  const cloud=node('section','et-drive-cloud'),head=node('div','et-drive-cloud-head'),title=node('strong','','云端文件');
  const refresh=button('刷新列表','读取当前知识库最近一次完整的云端备份。',()=>engine.catalog());
  const pull=button('下载更新','下载并校验云端文件后更新本机。未上传的本机修改会保留，冲突内容另存副本；缺少的附件会加入知识库。',()=>engine.pull());
  head.append(title,refresh,pull);const search=node('input','et-drive-cloud-search');search.placeholder='查找云端文件';search.setAttribute('aria-label','查找云端文件');
  const files=node('div','et-drive-cloud-files');files.append(node('p','','刷新列表，查看最近一次完整备份'));
   cloud.id='et-drive-cloud';cloudTab.id='et-drive-cloud-tab';cloudTab.setAttribute('aria-controls',cloud.id);cloud.setAttribute('role','tabpanel');cloud.setAttribute('aria-labelledby',cloudTab.id);
   const filter=node('select','et-drive-cloud-filter');filter.setAttribute('aria-label','文件类型');for(const [value,label]of [['all','全部文件'],['document','文档'],['image','图片'],['other','其他附件']]){const o=node('option','',label);o.value=value;filter.append(o);}
   const tools=node('div','et-drive-cloud-tools');tools.append(search,filter);
   let page=0;const size=40,pager=node('div','et-drive-cloud-pager'),pageInfo=node('span'),previous=p.button('上一页',()=>{page--;drawFiles();}),next=p.button('下一页',()=>{page++;drawFiles();});pager.append(pageInfo,previous,next);pager.hidden=true;cloud.append(head,tools,files,pager);
   const selectTab=isCloud=>{d.dataset.view=isCloud?'cloud':'overview';overview.hidden=isCloud;cloud.hidden=!isCloud;for(const [b,selected]of [[overviewTab,!isCloud],[cloudTab,isCloud]]){b.setAttribute('aria-selected',String(selected));b.tabIndex=selected?0:-1;}body.scrollTop=0;};
   tabs.onkeydown=e=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();const target=e.key==='Home'?overviewTab:e.key==='End'?cloudTab:e.target===overviewTab?cloudTab:overviewTab;target.click();target.focus();}};selectTab(false);
  const drawFiles=()=>{const catalog=engine.state.catalog,rows=catalog?.rows;if(!rows){pager.hidden=true;return;}const items=catalog.snapshot?.library?.items||[];
   const kind=path=>/\.(md|txt|pdf|docx?|epub|html?|rtf)$/i.test(path)?'document':/\.(png|jpe?g|gif|svg|webp|bmp|tiff?)$/i.test(path)?'image':'other';
   const refs=items.flatMap(i=>(i.files||[]).filter(f=>f.path).map(f=>({path:f.path,title:i.title})));
   const model=rows.map(f=>{const ref=refs.find(r=>r.path===f.path)||refs.find(r=>f.path.startsWith(r.path.slice(0,r.path.lastIndexOf('/')+1)));const parts=f.path.split('/'),name=parts.pop(),folder=parts.slice(2).join('/');return {...f,name,folder,owner:ref?.title||'',kind:kind(f.path)};});
   const query=search.value.trim().toLowerCase(),filtered=model.filter(f=>(filter.value==='all'||filter.value===f.kind)&&[f.path,f.owner].some(v=>v.toLowerCase().includes(query)));
   const pages=Math.max(1,Math.ceil(filtered.length/size));page=Math.max(0,Math.min(page,pages-1));title.textContent='云端文件';cloudTab.textContent='云端文件 · '+rows.length;files.replaceChildren();
   for(const f of filtered.slice(page*size,(page+1)*size)){const row=node('div','et-drive-cloud-file'),icon=node('span','et-drive-file-icon',f.kind==='image'?'▧':f.kind==='document'?'≡':'◇'),copy=node('div','et-drive-file-copy'),name=node('strong','',f.name);icon.setAttribute('aria-hidden','true');tip(copy,f.path);copy.append(name,node('small','',[f.owner,f.folder].filter(Boolean).join(' · ')||'附件'));row.append(icon,copy,node('span','et-drive-file-size',f.bytes<1024?f.bytes+' B':f.bytes<1024**2?(f.bytes/1024).toFixed(1)+' KB':(f.bytes/1024**2).toFixed(1)+' MB'));files.append(row);}
   if(!filtered.length)files.append(node('p','et-drive-empty',rows.length?'没有匹配文件':'这次备份没有附件文件'));
   pageInfo.textContent=filtered.length?'共 '+filtered.length+' 个 · '+(page*size+1)+'–'+Math.min(filtered.length,(page+1)*size):'0 个文件';pager.hidden=false;previous.disabled=page===0;next.disabled=page>=pages-1;
  };search.oninput=filter.onchange=()=>{page=0;drawFiles();};
  let seenCatalog,seenSummary;
  this.update=s=>{if(!d.open)return;const acc=service.account();accountName.textContent=acc?.account||'尚未授权备份';login.textContent=acc?'更换账户':'授权备份';disconnect.hidden=!acc;
   for(const b of controls)b.disabled=s.busy;for(const b of [scan,upload,refresh,pull])b.disabled=s.busy||!acc;cancel.hidden=!s.busy;toggle.checked=engine.enabled;toggle.disabled=s.busy;open.hidden=!s.last?.url;
   const waiting=!!s.retryAt;stateCard.dataset.tone=s.error?(waiting?'waiting':'error'):s.busy?'busy':s.stage==='done'?'done':'idle';
   stateMark.textContent=s.error?(waiting?'↻':'!'):s.busy?'':s.stage==='done'?'✓':'↗';
   stateTitle.textContent=s.error?(waiting?'等待重试':'需要处理'):s.busy?({scanning:'正在检查变化',uploading:'正在上传',downloading:'正在读取云端',saving:'正在保存备份',waiting:'等待编辑完成',authorizing:'正在连接账户'}[s.stage]||'正在同步'):s.stage==='done'?'本次操作已完成':Number.isInteger(s.pendingFiles)?s.pendingFiles?'有文件待上传':'文件已核对':acc?(engine.enabled?'自动同步已就绪':'实时同步已暂停'):'连接 Google Drive';
   status.textContent=s.error?(waiting?'将在 '+new Date(s.retryAt).toLocaleTimeString()+' 自动重试':'处理后可点击“立即同步”重试'):s.text;status.dataset.stage=s.stage;error.hidden=!s.error;if(s.error)error.textContent=s.error;
   pendingBadge.hidden=!Number.isInteger(s.pendingFiles);pendingBadge.textContent=s.pendingFiles?s.pendingFiles+' 待上传':'无待上传文件';tip(pendingBadge,'云端核对的文件数量；文件上传完毕后还需保存并校验备份清单。');
   source.hidden=false;
   history.textContent=s.last?'上次同步 '+new Date(s.last.completedAt).toLocaleString():'';history.hidden=!s.last;
   const signature=JSON.stringify(s.summary||{});if(signature!==seenSummary){seenSummary=signature;stats.replaceChildren();for(const [label,value]of [['条目',s.summary?.items??'…'],['新增文件',s.summary?.added??'…'],['修改文件',s.summary?.modified??'…'],['未变文件',s.summary?.unchanged??'…']]){const cell=node('div');cell.append(node('strong','',String(value)),node('span','',label));stats.append(cell);}}
   statsNote.textContent=s.summaryState==='waiting'?'知识库变化中，统计待更新':s.summaryState==='stale'?(s.summaryAt?'统计尚未完成，保留上次结果':'本机统计尚未完成'):s.summaryState==='scanning'?(s.summaryAt?'正在更新统计，当前显示上次结果':'正在统计本机文件…'):s.summaryAt?'本机扫描 '+new Date(s.summaryAt).toLocaleTimeString()+(s.summary?.removed?' · 移除 '+s.summary.removed+' 个文件':''):'正在准备本机统计…';
   if(seenCatalog!==s.catalog){seenCatalog=s.catalog;page=0;drawFiles();}d.setAttribute('aria-busy',String(s.busy));
  };
  const config=async()=>{configure.textContent=(await p.store.secrets()).googleConfig?'更换 OAuth 配置':'导入 OAuth 配置';this.render({...engine.state,enabled:engine.enabled});};
  overview.append(source,account,stateCard,realtime,preview,setup);body.append(overview,cloud);d.append(tabs,body,actions);
  const tooltip=node('div','et-drive-tooltip');tooltip.setAttribute('role','tooltip');tooltip.hidden=true;d.append(tooltip);let timer;
  const hide=()=>{clearTimeout(timer);tooltip.hidden=true;};const reveal=e=>{const el=e.target.closest?.('[data-sync-tip]');if(!el)return;hide();timer=setTimeout(()=>{if(!d.open)return;tooltip.textContent=el.dataset.syncTip;tooltip.hidden=false;const r=el.getBoundingClientRect(),box=d.getBoundingClientRect();tooltip.style.left=Math.max(10,Math.min(r.left-box.left,box.width-300))+'px';tooltip.style.top=Math.max(10,Math.min(r.bottom-box.top+6,box.height-tooltip.offsetHeight-12))+'px';},350);};
  d.addEventListener('pointerover',reveal);d.addEventListener('focusin',reveal);d.addEventListener('pointerout',hide);d.addEventListener('focusout',hide);body.addEventListener('scroll',hide);
  d.addEventListener('close',()=>{hide();this.update=null;this.dialog=null;});d.showModal();await config();
  if(service.account()&&!engine.state.last)try{engine.state.last=await backup.json(reqnode('path').join(backup.root,'cloud-'+service.account().key.slice(0,24)+'.json'));}catch{}
  this.render({...engine.state,enabled:engine.enabled});upload.focus();
  if(!engine.state.busy&&!engine.state.summaryAt)void engine.scan({localOnly:true}).catch(()=>{});
 }
}
