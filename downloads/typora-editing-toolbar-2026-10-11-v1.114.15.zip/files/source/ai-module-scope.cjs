'use strict';
// Resources belong to one activation. Never patch the host's global prototypes.
class AIModuleScope {
 constructor(win,doc){
  this.active=true;this.events=[];this.timers=new Map();this.frames=new Set();this.nodes=new Set();this.observers=new Set();this.controllers=new Set();this.win=win;this.doc=doc;
  this.setTimeout=(fn,ms,...args)=>this.timer(false,fn,ms,args);
  this.setInterval=(fn,ms,...args)=>this.timer(true,fn,ms,args);
  this.clearTimeout=this.clearInterval=id=>{win.clearTimeout(id);win.clearInterval(id);this.timers.delete(id);};
  this.requestAnimationFrame=fn=>{if(!this.active)return 0;const id=win.requestAnimationFrame(t=>{this.frames.delete(id);if(this.active)fn(t);});this.frames.add(id);return id;};
  this.cancelAnimationFrame=id=>{win.cancelAnimationFrame(id);this.frames.delete(id);};
  const scope=this;
  this.AbortController=class extends win.AbortController{constructor(){super();scope.controllers.add(this);if(!scope.active)this.abort();}};
  for(const key of ['MutationObserver','ResizeObserver','IntersectionObserver'])if(win[key])this[key]=class extends win[key]{constructor(fn){super((...args)=>{if(scope.active)fn(...args);});scope.observers.add(this);}};
  this.document=new Proxy(doc,{get:(target,key)=>{
   if(key==='addEventListener')return (type,fn,opts)=>this.listen(target,type,fn,opts);
   if(key==='removeEventListener')return (type,fn,opts)=>this.unlisten(target,type,fn,opts);
   const value=Reflect.get(target,key,target);if(typeof value!=='function')return value;
   if(key==='createElement'||key==='createElementNS')return(...args)=>{const node=value.apply(target,args);this.nodes.add(new WeakRef(node));return node;};
   return value.bind(target);
  }});
  this.window=new Proxy(win,{get:(target,key)=>{
   if(key==='window'||key==='self')return this.window;if(key==='document')return this.document;
   if(key==='addEventListener')return(type,fn,opts)=>this.listen(target,type,fn,opts);
   if(key==='removeEventListener')return(type,fn,opts)=>this.unlisten(target,type,fn,opts);
   if(['setTimeout','setInterval','clearTimeout','clearInterval','requestAnimationFrame','cancelAnimationFrame','AbortController','MutationObserver','ResizeObserver','IntersectionObserver'].includes(key))return this[key];
   const value=Reflect.get(target,key,target);return typeof value==='function'&&!value.prototype?value.bind(target):value;
  }});
 }
 timer(repeat,fn,ms,args){if(!this.active)return 0;const id=this.win[repeat?'setInterval':'setTimeout'](()=>{if(!repeat)this.timers.delete(id);if(this.active)fn(...args);},ms);this.timers.set(id,repeat);return id;}
 listen(target,type,fn,opts){if(!this.active||!fn)return;const capture=typeof opts==='boolean'?opts:!!opts?.capture;if(this.events.some(e=>e.target===target&&e.type===type&&e.fn===fn&&e.capture===capture))return;const wrapped=e=>{if(this.active)typeof fn==='function'?fn.call(target,e):fn.handleEvent(e);};this.events.push({target,type,fn,wrapped,opts,capture});target.addEventListener(type,wrapped,opts);}
 unlisten(target,type,fn,opts){const capture=typeof opts==='boolean'?opts:!!opts?.capture;this.events=this.events.filter(e=>{if(e.target!==target||e.type!==type||e.fn!==fn||e.capture!==capture)return true;target.removeEventListener(type,e.wrapped,e.opts);return false;});}
 abort(){for(const c of this.controllers)c.abort();this.controllers.clear();}
 close(){if(!this.active)return;this.abort();
  for(const e of [...this.events])if(e.target===this.win&&['beforeunload','unload'].includes(e.type))try{typeof e.fn==='function'?e.fn.call(this.win,new this.win.Event(e.type)):e.fn.handleEvent(new this.win.Event(e.type));}catch{}
  this.active=false;for(const e of this.events)e.target.removeEventListener(e.type,e.wrapped,e.opts);this.events=[];
  for(const id of this.timers.keys())this.clearTimeout(id);for(const id of this.frames)this.win.cancelAnimationFrame(id);this.frames.clear();
  for(const observer of this.observers)observer.disconnect();this.observers.clear();
  for(const ref of this.nodes){const node=ref.deref();if(node?.isConnected){try{if(node.tagName==='DIALOG'&&node.open)node.close();}catch{}node.remove();}}this.nodes.clear();
 }
}
module.exports=AIModuleScope;
