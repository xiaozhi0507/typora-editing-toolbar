'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),http=require('node:http');
const Client=require('./ai-client.cjs'),Execution=require('./ai-execution.cjs');
class QuickClient extends Client {static retryDelays=[10,20];}
const profile=url=>({url,model:'fixture-model',protocol:'openai-responses',reasoningEffort:'high'});
async function server(t,handler){const s=http.createServer(handler);await new Promise(r=>s.listen(0,'127.0.0.1',r));t.after(()=>{s.closeAllConnections();s.close();});return 'http://127.0.0.1:'+s.address().port;}
function answer(r){r.writeHead(200,{'content-type':'application/json'});r.end(JSON.stringify({output:[{id:'final',type:'message',content:[{type:'output_text',text:'recovered'}]}]}));}
test('a reset after previous tool work retries inference only with identical context',async t=>{
 let calls=0,runs=0;const bodies=[],url=await server(t,(q,r)=>{let body='';q.on('data',b=>body+=b);q.on('end',()=>{bodies.push(body);if(++calls===1)q.socket.destroy();else answer(r);});}),turn={status:'running'};
 await Execution.tool(turn,{id:'once',name:'run_shell_command',arguments:'{}'},async()=>{runs++;return {exitCode:0};});
 const messages=[{role:'user',content:'fixture'},{role:'assistant',content:'',toolCalls:[{id:'once',name:'run_shell_command',arguments:'{}'}]},{role:'tool',tool_call_id:'once',content:'{"exitCode":0}'}];
 await Execution.request(turn,c=>new QuickClient(require).request(profile(url),'',messages,c));assert.equal(turn.answer,'recovered');assert.equal(calls,2);assert.equal(runs,1);assert.equal(bodies[0],bodies[1]);assert(turn.execution.some(e=>/连接已恢复/.test(e.text||'')));assert.equal(turn.execution.filter(e=>e.type==='tool').length,1);
});
test('recovery is bounded to two retries before reporting reset',async t=>{let calls=0;const url=await server(t,q=>{calls++;q.resume();q.socket.destroy();});await assert.rejects(new QuickClient(require).request(profile(url),'',[]),/ECONNRESET/);assert.equal(calls,3);});
test('abort during backoff prevents another request',async t=>{let calls=0;const c=new AbortController(),url=await server(t,q=>{calls++;q.resume();q.socket.destroy();});await assert.rejects(new QuickClient(require).request(profile(url),'',[],{signal:c.signal,onEvent:e=>{if(e.id==='network-retry')c.abort();}}),{name:'AbortError'});assert.equal(calls,1);});
test('partial tool arguments are never executed even when all inference retries fail',async t=>{
 let calls=0;const url=await server(t,(q,r)=>{calls++;q.resume();r.writeHead(200,{'content-type':'text/event-stream'});r.write('data: '+JSON.stringify({type:'response.output_item.added',item:{id:'tool',type:'function_call',call_id:'pending',name:'run_shell_command',arguments:'{"command":'}})+'\n\n');setTimeout(()=>r.destroy(),40);}),turn={};
 await assert.rejects(Execution.request(turn,c=>new QuickClient(require).request({...profile(url),shellEnabled:true,project:{trusted:true}},'',[],c)),/连接中断/);assert.equal(calls,3);assert.equal(turn.execution.find(e=>e.callId==='pending').result,'参数未完整接收，此操作未执行');
});
test('authentication errors have no automatic retries',async t=>{let calls=0;const url=await server(t,(q,r)=>{calls++;q.resume();r.writeHead(401,{'content-type':'application/json'});r.end('{"error":{"message":"unauthorized"}}');});await assert.rejects(new QuickClient(require).request(profile(url),'',[]),/unauthorized/);assert.equal(calls,1);});
test('saved failed turns show their actual error and do not invite replay of completed commands',()=>{const turn={status:'error',detail:'',execution:[{type:'tool',name:'run_shell_command',startedAt:1,status:'failed',result:'命令退出码 1'},{type:'model',status:'failed',result:'请求失败：ECONNRESET'}]};assert.match(Execution.failure(turn),/ECONNRESET/);assert.match(Execution.emptyAnswer(turn),/不会自动重跑/);assert.equal(Execution.failure({...turn,status:'done'}),'');assert.equal(Execution.failure({...turn,webChat:{}}),'');});

const emit=(r,p)=>r.write('data: '+JSON.stringify(p)+'\n\n');
function partial(r){
 r.writeHead(200,{'content-type':'text/event-stream'});
 emit(r,{type:'response.reasoning_summary_text.delta',item_id:'discard-reason',delta:'未完成思考'});
 emit(r,{type:'response.output_item.added',item:{id:'discard-message',type:'message',phase:'final_answer'}});
 emit(r,{type:'response.output_text.delta',item_id:'discard-message',delta:'未完成回答'});
 emit(r,{type:'response.output_item.added',item:{id:'discard-tool',type:'function_call',call_id:'discard-call',name:'run_shell_command',arguments:'{"command":'}});
}
test('midstream EOF replaces only current attempt and keeps previous command executed once',async t=>{
 let calls=0,runs=0;const bodies=[],url=await server(t,(q,r)=>{let body='';q.on('data',b=>body+=b);q.on('end',()=>{bodies.push(body);if(++calls===1){partial(r);r.end();}else answer(r);});}),turn={};
 await Execution.request(turn,async c=>{c.onEvent({id:'prior',type:'reasoning',kind:'summary',text:'已完成检查'});return {text:'',toolCalls:[{id:'once',name:'run_shell_command',arguments:'{}'}]};});
 await Execution.tool(turn,{id:'once',name:'run_shell_command',arguments:'{}'},async()=>{runs++;return {exitCode:0};});
 const messages=Client.continueTools([{role:'user',content:'fixture'}],{toolCalls:[{id:'once',name:'run_shell_command',arguments:'{}'}]},[{exitCode:0}]);
 await Execution.request(turn,c=>new QuickClient(require).request({...profile(url),shellEnabled:true,project:{trusted:true}},'',messages,c));
 assert.equal(calls,2);assert.equal(runs,1);assert.equal(bodies[0],bodies[1]);assert.equal(turn.answer,'recovered');assert.equal(turn.reasoning,'已完成检查');
 assert(!turn.execution.some(e=>/discard/.test(e.id)));assert.equal(turn.execution.filter(e=>e.type==='tool').length,1);assert.equal(turn.execution.find(e=>e.type==='tool').status,'success');
});
test('only complete replacement tool calls are returned for execution',async t=>{
 let calls=0,runs=0;const url=await server(t,(q,r)=>{q.resume();if(++calls===1){partial(r);return r.end();}r.writeHead(200,{'content-type':'text/event-stream'});emit(r,{type:'response.completed',response:{status:'completed',output:[{id:'good-item',type:'function_call',call_id:'good-call',name:'run_shell_command',arguments:'{"command":"Write-Output ok"}'}]}});r.end();}),turn={};
 const result=await Execution.request(turn,c=>new QuickClient(require).request({...profile(url),shellEnabled:true,project:{trusted:true}},'',[],c));
 assert.deepEqual(result.toolCalls.map(c=>c.id),['good-call']);assert.equal(turn.answer,'');assert.equal(turn.reasoning,'');assert(!turn.execution.some(e=>e.callId==='discard-call'));
 for(const call of result.toolCalls)await Execution.tool(turn,call,async()=>{runs++;return {exitCode:0};});assert.equal(runs,1);
});
test('failed reconnects with no replacement preserve partial text and do not claim success',async t=>{
 let calls=0;const url=await server(t,(q,r)=>{q.resume();if(++calls===1){partial(r);r.end();}else q.socket.destroy();}),turn={};
 await assert.rejects(Execution.request(turn,c=>new QuickClient(require).request({...profile(url),shellEnabled:true,project:{trusted:true}},'',[],c)),/ECONNRESET/);
 assert.equal(calls,3);assert.equal(turn.answer,'未完成回答');assert.equal(turn.execution.find(e=>e.type==='model').status,'failed');assert.equal(turn.execution.find(e=>e.callId==='discard-call').result,'参数未完整接收，此操作未执行');
});
test('item completion without response completion is not accepted as a finished answer',async t=>{
 let calls=0;const url=await server(t,(q,r)=>{q.resume();calls++;r.writeHead(200,{'content-type':'text/event-stream'});emit(r,{type:'response.output_item.done',item:{id:'only-item',type:'message',content:[{type:'output_text',text:'partial'}]}});r.end();});
 await assert.rejects(new QuickClient(require).request(profile(url),'',[]),/连接提前结束/);assert.equal(calls,3);
});
test('chat and anthropic partial text is replaced after retry too',async t=>{
 for(const protocol of ['openai-chat','anthropic-messages']){
  let calls=0;const texts=[],reasons=[],events=[],url=await server(t,(q,r)=>{q.resume();r.writeHead(200,{'content-type':'text/event-stream'});const second=++calls===2;
   if(protocol==='openai-chat'){emit(r,{choices:[{delta:{content:second?'complete':'partial'},finish_reason:second?'stop':null}]});}
   else {emit(r,{type:'content_block_start',index:0,content_block:{type:'text',text:second?'complete':'partial'}});if(second)emit(r,{type:'message_stop'});}r.end();
  });
  const result=await new QuickClient(require).request({...profile(url),protocol},'',[],{onEvent:e=>events.push(e),onText:x=>texts.push(x),onReasoning:x=>reasons.push(x)});
  assert.equal(result.text,'complete');assert.deepEqual(texts,['partial','','complete']);assert.equal(events.filter(e=>e.type==='reset').length,1);assert.deepEqual(reasons,['']);
 }
});
test('explicit API failures and malformed packets are not retried after partial output',async t=>{
 for(const fail of ['error','invalid']){let calls=0;const url=await server(t,(q,r)=>{q.resume();calls++;r.writeHead(200,{'content-type':'text/event-stream'});emit(r,{type:'response.output_text.delta',delta:'partial'});if(fail==='error')emit(r,{type:'error',error:{message:'quota',code:'quota'}});else r.write('data: invalid JSON\n\n');r.end();});
  await assert.rejects(new QuickClient(require).request(profile(url),'',[]),fail==='error'?/quota/:/无效/);assert.equal(calls,1);
 }
});
test('retry budget includes prior attempts and backoff',async t=>{
 class DeadlineClient extends Client {static requestTimeout=30;static retryDelays=[100];}
 let calls=0;const url=await server(t,q=>{calls++;q.resume();q.socket.destroy();});await assert.rejects(new DeadlineClient(require).request(profile(url),'',[]),/ECONNRESET/);assert.equal(calls,1);
});
