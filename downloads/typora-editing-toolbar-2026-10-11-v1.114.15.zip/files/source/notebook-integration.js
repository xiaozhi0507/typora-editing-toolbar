// A single file-navigation surface routes .ipynb to its structured editor.
(()=>{
 const proto=EditingToolbarCodeEditor.prototype;
 for(const name of ['supported','open','hide','visibleKey','hasDirty','layout','renderTabs','relocate','forgetFiles']){
  const original=proto[name];proto[name]=function(...args){const nb=this.toolbar.notebook;
   if(name==='supported')return nb?.supported(args[0])||original.apply(this,args);
   if(name==='open'){if(nb?.supported(args[0]))return nb.open(args[0]);if(nb?.panel&&!nb.panel.hidden)this.leaveWorkspace();nb?.hide();}
   if(name==='hide')nb?.hide();
   if(name==='visibleKey'&&nb?.panel&&!nb.panel.hidden&&nb.active)return this.toolbar.documentTabs.key(nb.active.file);
   if(name==='hasDirty'&&nb?.supported(args[0]))return nb.dirty(nb.records.get(this.key(args[0])))||!!nb.records.get(this.key(args[0]))?.writing;
   if(name==='relocate')nb?.relocate(...args);
   if(name==='forgetFiles')return Promise.resolve(nb?.forgetFiles(...args)).then(()=>original.apply(this,args));
   const result=original.apply(this,args);
   if(name==='layout')nb?.layout();
   if(name==='renderTabs'&&nb){
    const hosts=[this.tabs,nb.tabs].filter(Boolean),records=[...this.records.values(),...nb.records.values()],active=nb.panel&&!nb.panel.hidden?nb.active:this.active;
    for(const host of hosts){host.replaceChildren();for(const r of records){const row=this.node('div','et-code-tab'+(r===active?' active':'')),open=this.button('',()=>this.open(r.file)),icon=this.node('span','et-code-language-icon');icon.innerHTML=this.toolbar.documentTabs.fileIcon(r.file);open.className='et-code-tab-open';open.append(icon,this.node('span','et-code-tab-name',reqnode('path').basename(r.file)));open.title=r.file;open.setAttribute('role','tab');open.setAttribute('aria-selected',String(r===active));open.tabIndex=r===active?0:-1;open.onkeydown=e=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();const i=records.indexOf(r),next=e.key==='Home'?0:e.key==='End'?records.length-1:(i+(e.key==='ArrowRight'?1:records.length-1))%records.length;this.open(records[next].file);}else if(e.key==='F2'){e.preventDefault();this.toolbar.documentTabs.renameDialog(r.file);}};const close=this.button(this.hasDirty(r.file)?'●':'×',()=>nb.supported(r.file)?nb.close(r):this.close(r));close.className='et-code-close';close.setAttribute('aria-label','关闭 '+reqnode('path').basename(r.file));row.append(open,close);row.draggable=true;row.ondragstart=e=>{e.dataTransfer.effectAllowed='copyMove';e.dataTransfer.setData('application/x-et-code-file',r.file);};row.oncontextmenu=e=>{e.preventDefault();this.toolbar.documentTabs.rowMenu(r.file,{x:e.clientX,y:e.clientY},open);};host.append(row);}if(host.getClientRects().length)host.querySelector('.active')?.scrollIntoView({block:'nearest',inline:'nearest'});}
   }return result;
  };
 }
})();
