'use strict';
const Skills=require('./ai-skills.cjs');
const Catalog=require('./ai-plugin-catalog.json');
const Packages=require('./ai-plugin-packages.cjs');
const Markets=require('./ai-plugin-marketplaces.cjs');
const authorize=require('./ai-plugin-oauth.cjs');
const PluginNetwork=require('./ai-plugin-network.cjs');
const CodexConnector=require('./ai-plugin-codex.cjs');
const DriveBackup=require('./ai-drive-backup.cjs');
class AIPlugins {
 constructor(req,directory,{protect,transport,codex}={}){this.req=req;this.Buffer=req('buffer').Buffer;this.fs=req('fs');this.path=req('path');this.crypto=req('crypto');this.dir=directory;this.protect=protect;this.transport=transport||this.request.bind(this);this.network=new PluginNetwork(req);this.codex=codex||new CodexConnector(req,req('path').join(directory,'codex-runtime'));this.data=new Skills(req,this.path.join(directory,'data-skills'));this.refreshing=null;this.packages=new Packages(req,this);this.markets=new Markets(req,this);}
 static catalog=Catalog;
 backup(){return this.driveBackup||(this.driveBackup=new DriveBackup(this));}
 id(id){if(!AIPlugins.catalog.some(x=>x.id===id)&&!(typeof id==='string'&&/^local:[a-z0-9][a-z0-9-]{0,63}$/.test(id)&&this.state().plugins[id]?.custom))throw Error('未知插件');return id;}
 state(){try{const s=JSON.parse(this.fs.readFileSync(this.path.join(this.dir,'plugins.json'),'utf8'));if(s.version!==1||!s.plugins)throw Error();return s;}catch(e){if(e.code==='ENOENT')return {version:1,plugins:{}};throw Error('插件设置无法读取，原文件已保留');}}
 async locked(fn){this.fs.mkdirSync(this.dir,{recursive:true});const lock=this.path.join(this.dir,'settings.lock');let fd;try{try{fd=this.fs.openSync(lock,'wx');}catch{throw Error('插件设置正在其他窗口中更新，请稍后重试');}return await fn();}finally{if(fd!==undefined){this.fs.closeSync(fd);this.fs.unlinkSync(lock);}}}
 async write(file,value){const target=this.path.join(this.dir,file),tmp=target+'.'+this.crypto.randomUUID()+'.tmp';try{await this.fs.promises.writeFile(tmp,value,{flag:'wx',mode:0o600});await this.fs.promises.rename(tmp,target);}finally{await this.fs.promises.unlink(tmp).catch(()=>{});}}
 async secrets(){try{const data=await this.fs.promises.readFile(this.path.join(this.dir,'accounts.dpapi'),'utf8');return JSON.parse(await this.protect(data,true));}catch(e){if(e.code==='ENOENT')return {};throw Error('插件凭据无法解密，请重新连接账号');}}
 async update(fn){return this.locked(async()=>{const state=this.state(),secrets=await this.secrets();await fn(state,secrets);await this.write('accounts.dpapi',await this.protect(JSON.stringify(secrets)));await this.write('plugins.json',JSON.stringify(state,null,2));});}
 async enable(id,value){this.id(id);await this.locked(async()=>{const s=this.state();s.plugins[id]={...s.plugins[id],enabled:!!value};await this.write('plugins.json',JSON.stringify(s,null,2));});}
 async addBuiltin(id){if(!AIPlugins.catalog.some(p=>p.id===id))throw Error('未知内置插件');await this.locked(async()=>{const s=this.state(),previous=s.plugins[id];if(previous&&!previous.removed)return;s.plugins[id]={...previous,added:true,removed:false,enabled:false};await this.write('plugins.json',JSON.stringify(s,null,2));});}
 list(all=false){const s=this.state(),rows=[...AIPlugins.catalog.map(p=>({...p,...s.plugins[p.id],enabled:s.plugins[p.id]?.enabled===true})),...Object.values(s.plugins).filter(p=>p.custom)];for(const p of rows){if(p.connectionMode==='codex'){const account=this.codexAccount(p.id,s);Object.assign(p,{connected:!!account,account:account?.account||null,accountLabel:account?.label||null});}}return all?rows:rows.filter(p=>Object.hasOwn(s.plugins,p.id)&&!p.removed);}
 active(id){this.id(id);if(this.state().plugins[id]?.removed||!this.state().plugins[id]?.enabled)throw Error('插件未启用：'+id);}
 request(url,{token,form,signal,text=false,timeout=30000}={}){
  const u=new URL(url),githubToken=u.hostname==='github.com'&&u.pathname==='/login/oauth/access_token'&&!u.search&&!!form&&!token;
  if(u.protocol!=='https:'||u.username||u.password||u.hash||(!['api.github.com','www.googleapis.com','oauth2.googleapis.com'].includes(u.hostname)&&!githubToken)||u.port)throw Error('拒绝非官方插件服务地址');
  const body=form?new URLSearchParams(form).toString():null;
  return new Promise((resolve,reject)=>{
   let request,agent,done=false;const controller=new AbortController();
   const finish=(error,value)=>{if(done)return;done=true;if(error)this.network.invalidate();clearTimeout(timer);signal?.removeEventListener('abort',abort);controller.abort();request?.destroy();agent?.destroy();error?reject(error):resolve(value);};
   const abort=()=>finish(Object.assign(Error('已取消插件请求'),{name:'AbortError'}));
   const timer=setTimeout(()=>finish(Object.assign(Error('插件服务请求超时，请检查系统代理或网络后重试'),{code:'PLUGIN_NETWORK_TIMEOUT'})),timeout);
   if(signal?.aborted)return abort();signal?.addEventListener('abort',abort,{once:true});
   (async()=>{
    agent=await this.network.agent(u.href,controller.signal);if(done){agent.destroy();return;}
    request=this.req('https').request(u,{agent,method:body?'POST':'GET',headers:{Accept:text?'text/plain':'application/json','User-Agent':'Typora-Editing-Toolbar',...(token?{Authorization:'Bearer '+token}:{}),...(body?{'Content-Type':'application/x-www-form-urlencoded','Content-Length':this.Buffer.byteLength(body)}:{}),...(u.hostname==='api.github.com'?{'X-GitHub-Api-Version':'2022-11-28'}:{})}},res=>{
     let bytes=0,chunks=[];
     res.on('data',b=>{bytes+=b.length;if(bytes>2*1024**2)return finish(Error('插件响应超过 2 MiB，请缩小范围'));chunks.push(b);});
     res.on('end',()=>{if(done)return;if(res.statusCode<200||res.statusCode>=300)return finish(Object.assign(Error('插件服务请求失败（HTTP '+res.statusCode+'）'+([401,403].includes(res.statusCode)?'，请检查账号权限或重新连接':'')),{status:res.statusCode,retryable:res.statusCode===429||res.statusCode>=500}));const value=this.Buffer.concat(chunks).toString('utf8');if(text)return finish(null,value);try{finish(null,JSON.parse(value));}catch{finish(Error('插件服务返回了无效数据'));}});
     res.on('error',()=>finish(Object.assign(Error('插件连接中断'),{code:'PLUGIN_NETWORK_ERROR',retryable:true})));res.on('aborted',()=>finish(Object.assign(Error('插件连接中断'),{code:'PLUGIN_NETWORK_ERROR',retryable:true})));
    });
    request.on('error',()=>finish(Object.assign(Error('无法连接插件服务，请检查系统代理或网络后重试'),{code:'PLUGIN_NETWORK_ERROR',retryable:true})));
    request.end(body);
   })().catch(e=>finish(e));
  });
 }
 connectionMode(id,state=this.state()){return state.plugins[id]?.connectionMode==='codex'?'codex':'direct';}
 codexAccounts(id,state=this.state()){return state.plugins[id]?.codexAccounts||[];}
 codexAccount(id,state=this.state()){const p=state.plugins[id];return this.codexAccounts(id,state).find(a=>a.key===p?.activeCodexAccount)||null;}
 async codexUpdate(id,fn){this.id(id);if(!['github','google-drive'].includes(id))throw Error('不支持的 Codex 插件');return this.locked(async()=>{const s=this.state();s.plugins[id]??={};await fn(s.plugins[id]);await this.write('plugins.json',JSON.stringify(s,null,2));});}
 async setConnectionMode(id,mode){if(!['codex','direct'].includes(mode))throw Error('连接方式无效');await this.codexUpdate(id,p=>{p.connectionMode=mode;p.enabled=mode==='codex'?!!p.codexAccounts?.some(a=>a.key===p.activeCodexAccount):!!p.connected;});}
 async connectCodex(id,key,signal){
  const before=JSON.stringify(this.state().plugins[id]||{});const a=await this.codex.connect(id,key,signal);
  await this.codexUpdate(id,p=>{if(signal?.aborted)throw Object.assign(Error('已取消'),{name:'AbortError'});if(JSON.stringify(p)!==before)throw Error('插件设置已变更，请重新连接');
   const rows=p.codexAccounts||[],existing=rows.find(x=>x.key===a.key),account={key:a.key,connectorId:a.connectorId,providerId:a.providerId,account:a.account,avatar:a.avatar,codexAccountTag:a.codexAccountTag,checkedAt:a.checkedAt,label:existing?.label||''};
   p.codexAccounts=[...rows.filter(x=>x.key!==a.key&&x.codexAccountTag===a.codexAccountTag),account];p.activeCodexAccount=a.key;p.connectionMode='codex';p.enabled=true;p.removed=false;
  });return a.account;
 }
 async useCodexAccount(id,key){await this.codexUpdate(id,p=>{if(!p.codexAccounts?.some(a=>a.key===key))throw Error('账户已断开');p.activeCodexAccount=key;});}
 async disconnectCodex(id,key){await this.codexUpdate(id,p=>{p.codexAccounts=(p.codexAccounts||[]).filter(a=>a.key!==key);if(p.activeCodexAccount===key)p.activeCodexAccount=p.codexAccounts[0]?.key||null;if(!p.activeCodexAccount&&p.connectionMode==='codex')p.enabled=false;});}
 async renameCodexAccount(id,label,key){label=String(label).trim();if(!label||label.length>100)throw Error('账号名称须为 1–100 字');await this.codexUpdate(id,p=>{const a=p.codexAccounts?.find(a=>a.key===key);if(!a)throw Error('账户已断开');a.label=label;});}
 accounts(id,state=this.state()){const p=state.plugins[id];return p?.accounts|| (p?.connected?[{key:'legacy',account:p.account||'',label:p.accountLabel||'',avatar:''}]:[]);}
 accountKey(id,state=this.state()){const rows=this.accounts(id,state);return rows.find(a=>a.key===state.plugins[id]?.activeAccount)?.key||rows[0]?.key;}
 migrateAccounts(id,s,c){const rows=this.accounts(id,s);s.plugins[id]={...s.plugins[id],accounts:rows,activeAccount:this.accountKey(id,s)};if(c[id]&&!c[id].accounts)c[id]={accounts:rows.length?{[rows[0].key]:c[id]}:{}};return rows;}
 syncAccount(id,s){const p=s.plugins[id],rows=p.accounts||[],a=rows.find(a=>a.key===p.activeAccount)||rows[0];Object.assign(p,{activeAccount:a?.key||null,connected:!!a,account:a?.account||null,accountLabel:a?.label||null});if(!a)p.enabled=false;}
 credential(c,id,key){return c[id]?.accounts?c[id].accounts[key]:key==='legacy'?c[id]:null;}
 async saveAccount(id,user,credentials,reconnectKey,signal,clientId){await this.update((s,c)=>{if(signal?.aborted)throw Object.assign(Error('已取消'),{name:'AbortError'});if(clientId&&c[id==='github'?'githubConfig':'googleConfig']?.client_id!==clientId)throw Error('OAuth 配置已更换，请重新连接');const rows=this.migrateAccounts(id,s,c),same=a=>a.providerId?a.providerId===user.providerId:a.account.toLowerCase()===user.account.toLowerCase();let a=reconnectKey?rows.find(a=>a.key===reconnectKey):rows.find(same);if(reconnectKey&&(!a||!same(a)))throw Error('请选择原来的账户重新连接；添加其他账户请使用“连接另一个账户”');if(!a){a={key:this.crypto.randomUUID()};rows.push(a);}Object.assign(a,user,{checkedAt:new Date().toISOString()});c[id]??={accounts:{}};c[id].accounts[a.key]=credentials;s.plugins[id].activeAccount=reconnectKey?(s.plugins[id].activeAccount||a.key):a.key;s.plugins[id].enabled=true;this.syncAccount(id,s);});}
 async useAccount(id,key){this.id(id);await this.update((s,c)=>{if(!this.migrateAccounts(id,s,c).some(a=>a.key===key))throw Error('账户已断开');s.plugins[id].activeAccount=key;this.syncAccount(id,s);});}
 async connectGitHub(input,signal,reconnectKey){const token=String(input).trim();if(!token||token.length>1000||/\s/.test(token))throw Error('请输入有效的 GitHub 个人访问令牌');const user=await this.transport('https://api.github.com/user',{token,signal});if(!user.login||!user.id)throw Error('GitHub 账号验证失败');await this.saveAccount('github',{providerId:String(user.id),account:user.login,avatar:user.avatar_url||''},{token},reconnectKey,signal);return user.login;}
 static githubConfig(input){const c=typeof input==='string'?JSON.parse(input):input;if(!c||typeof c.client_id!=='string'||!/^[-\w.]{6,200}$/.test(c.client_id)||typeof c.client_secret!=='string'||!/^[-\w]{10,1000}$/.test(c.client_secret))throw Error('请填写 GitHub OAuth App 的 Client ID 和 Client secret');return {client_id:c.client_id,client_secret:c.client_secret,private_repositories:c.private_repositories===true};}
 async configureGitHub(input){const config=AIPlugins.githubConfig(input);await this.update((s,c)=>{const rows=this.migrateAccounts('github',s,c);if(c.githubConfig?.client_id!==config.client_id){s.plugins.github.accounts=rows.filter(a=>{const v=this.credential(c,'github',a.key);if(v?.authType!=='oauth')return true;delete c.github.accounts[a.key];return false;});this.syncAccount('github',s);}c.githubConfig=config;s.plugins.github.configured=true;});}
 async loginStep(progress,stage,fn){progress(stage);try{return await fn();}catch(e){if(e.name==='AbortError')throw e;throw Object.assign(Error('授权已收到，但'+({exchanging:'换取登录令牌',verifying:'验证账户',saving:'保存账户'}[stage])+'失败：'+e.message),{code:e.code,stage});}}
 async connectGitHubOAuth(open,{signal,timeout=180000,reconnectKey,onProgress}={}){
  const config=(await this.secrets()).githubConfig;if(!config)throw Error('请先配置 GitHub OAuth 应用');
  return authorize(this.req,open,{authorizeURL:'https://github.com/login/oauth/authorize',params:{client_id:config.client_id,scope:config.private_repositories?'read:user repo':'read:user',prompt:'select_account'},signal,timeout,onProgress},async({signal,progress,...form})=>{
   const tokens=await this.loginStep(progress,'exchanging',()=>this.transport('https://github.com/login/oauth/access_token',{signal,form:{client_id:config.client_id,client_secret:config.client_secret,...form}}));if(!tokens.access_token)throw Error('GitHub 授权失败，请检查 OAuth 应用配置并重试');
   if(config.private_repositories&&tokens.scope&&!tokens.scope.split(/[ ,]+/).includes('repo'))throw Error('未授予所选的私有仓库权限，请重新连接');
   const user=await this.loginStep(progress,'verifying',()=>this.transport('https://api.github.com/user',{token:tokens.access_token,signal}));if(!user.login||!user.id)throw Error('GitHub 账户验证失败');
   const credentials={...tokens,authType:'oauth',client_id:config.client_id,expiresAt:tokens.expires_in?Date.now()+Number(tokens.expires_in)*1000:null};
   await this.loginStep(progress,'saving',()=>this.saveAccount('github',{providerId:String(user.id),account:user.login,avatar:user.avatar_url||''},credentials,reconnectKey,signal,config.client_id));return user.login;
  });
 }
 static googleConfig(input){const s=typeof input==='string'?JSON.parse(input):input,c=s?.installed;if(!c||typeof c.client_id!=='string'||!/^[-\w.]+\.apps\.googleusercontent\.com$/.test(c.client_id))throw Error('请选择 Google Cloud 下载的“桌面应用”OAuth JSON');if(c.client_secret!=null&&(typeof c.client_secret!=='string'||c.client_secret.length>1000))throw Error('OAuth 配置无效');return {client_id:c.client_id,client_secret:c.client_secret||''};}
 async configureGoogle(input){const config=AIPlugins.googleConfig(input);await this.update((s,c)=>{if(c.googleConfig?.client_id!==config.client_id){delete c['google-drive'];delete c.googleBackup;s.plugins['google-drive']={...s.plugins['google-drive'],accounts:[],activeAccount:null,accountLabel:null,backupAccount:null,enabled:s.plugins['google-drive']?.connectionMode==='codex'&&s.plugins['google-drive']?.enabled===true,connected:false,account:null};}c.googleConfig=config;s.plugins['google-drive']={...s.plugins['google-drive'],configured:true};});}
 async connectGoogle(open,{signal,timeout=180000,reconnectKey,onProgress}={}){
  const config=(await this.secrets()).googleConfig;if(!config)throw Error('请先导入 Google 桌面应用 OAuth JSON');
  return authorize(this.req,open,{authorizeURL:'https://accounts.google.com/o/oauth2/v2/auth',params:{client_id:config.client_id,scope:'https://www.googleapis.com/auth/drive.readonly',access_type:'offline',prompt:'consent select_account'},signal,timeout,onProgress},async({signal,progress,...form})=>{
   const tokens=await this.loginStep(progress,'exchanging',()=>this.transport('https://oauth2.googleapis.com/token',{signal,form:{...config,...form,grant_type:'authorization_code'}}));if(!tokens.access_token||!tokens.refresh_token)throw Error('未取得完整授权，请重新登录并同意离线访问');
   if(tokens.scope&&!tokens.scope.split(' ').includes('https://www.googleapis.com/auth/drive.readonly'))throw Error('未授予 Drive 读取权限');
   const user=(await this.loginStep(progress,'verifying',()=>this.transport('https://www.googleapis.com/drive/v3/about?fields=user(displayName,emailAddress,permissionId,photoLink)',{token:tokens.access_token,signal}))).user;if(!user?.emailAddress)throw Error('Google 账户验证失败');
   await this.loginStep(progress,'saving',()=>this.saveAccount('google-drive',{providerId:String(user.permissionId||user.emailAddress).toLowerCase(),account:user.emailAddress,avatar:user.photoLink||''},{...tokens,expiresAt:Date.now()+Math.max(0,Number(tokens.expires_in)||0)*1000},reconnectKey,signal,config.client_id));return user.emailAddress;
  });
 }
 async token(id,signal,key=this.accountKey(id)){
  const c=await this.secrets(),v=this.credential(c,id,key),github=id==='github',name=github?'GitHub':'Google Drive',configKey=github?'githubConfig':'googleConfig';
  if(github&&v?.token)return v.token; // Preserve existing personal-access-token accounts.
  const valid=value=>value?.access_token&&(github&&value.expiresAt===null||value.expiresAt>Date.now()+60000);
  if(valid(v))return v.access_token;
  if(!v?.refresh_token||!c[configKey])throw Error('请先连接 '+name+' 账号或重新登录');
  const pending=this.refreshing;
  const refresh=(pending?pending.catch(()=>{}):Promise.resolve()).then(()=>this.locked(async()=>{
   const fresh=await this.secrets(),saved=this.credential(fresh,id,key),config=fresh[configKey];
   if(!saved?.refresh_token||!config)throw Error(name+' 已断开');
   if(valid(saved))return saved.access_token;
   if(saved.client_id&&saved.client_id!==config.client_id)throw Error('OAuth 配置已更换，请重新连接');
   const tokens=await this.transport(github?'https://github.com/login/oauth/access_token':'https://oauth2.googleapis.com/token',{signal,form:{client_id:config.client_id,client_secret:config.client_secret,refresh_token:saved.refresh_token,grant_type:'refresh_token'}});
   if(signal?.aborted)throw Object.assign(Error('已取消'),{name:'AbortError'});
   if(!tokens.access_token)throw Error(name+' 授权已失效，请重新登录');
   const value={...saved,...tokens,expiresAt:Date.now()+(Number(tokens.expires_in)||0)*1000};
   if(fresh[id].accounts)fresh[id].accounts[key]=value;else fresh[id]=value;
   await this.write('accounts.dpapi',await this.protect(JSON.stringify(fresh)));return tokens.access_token;
  }));this.refreshing=refresh;try{return await refresh;}finally{if(this.refreshing===refresh)this.refreshing=null;}
 }
 async disconnect(id,key){this.id(id);await this.update((s,c)=>{const rows=this.migrateAccounts(id,s,c);key??=this.accountKey(id,s);s.plugins[id].accounts=rows.filter(a=>a.key!==key);if(c[id]?.accounts)delete c[id].accounts[key];if(!s.plugins[id].accounts.length)delete c[id];this.syncAccount(id,s);});}
 async checkConnection(id,signal){this.id(id);if(this.connectionMode(id)==='codex'){const a=this.codexAccount(id);if(!a)throw Error('请先连接 Codex 账户');return (await this.codex.connect(id,a.key,signal)).account;}const token=await this.token(id,signal);const user=await this.transport(id==='github'?'https://api.github.com/user':'https://www.googleapis.com/drive/v3/about?fields=user(displayName,emailAddress)',{token,signal});return id==='github'?user.login:user.user?.emailAddress||user.user?.displayName;}
 async importData(root){
  const resolved=await this.fs.promises.realpath(root),manifest=JSON.parse(await this.fs.promises.readFile(this.path.join(resolved,'.codex-plugin','plugin.json'),'utf8'));if(manifest.name!=='data-analytics')throw Error('请选择 Codex Data 插件目录');
  const skillRoot=await this.fs.promises.realpath(this.path.join(resolved,'skills'));if(!this.data.within(resolved,skillRoot))throw Error('Data 技能目录指向插件外部');
  const files=await this.data.discover(skillRoot),installed=[];try{for(const file of files){const p=await this.data.preview(file);if(this.data.state().items.some(s=>s.name===p.name))continue;installed.push(await this.data.add(file,'copy'));}await this.locked(async()=>{const s=this.state();s.plugins.data={enabled:true,installed:true,removed:false,version:manifest.version||'',source:resolved,count:this.data.state().items.length};await this.write('plugins.json',JSON.stringify(s,null,2));});}catch(e){for(const row of installed)await this.data.uninstall(row.id);throw e;}return this.data.state().items.length;
 }
 async findData(){const cache=this.path.join(this.req('os').homedir(),'.codex','plugins','cache');const found=[];for(const market of await this.fs.promises.readdir(cache).catch(()=>[])){const base=this.path.join(cache,market,'data-analytics');for(const version of await this.fs.promises.readdir(base).catch(()=>[])){const root=this.path.join(base,version);try{const stat=await this.fs.promises.stat(this.path.join(root,'.codex-plugin','plugin.json'));found.push({root,time:stat.mtimeMs});}catch{}}}return found.sort((a,b)=>b.time-a.time)[0]?.root||null;}
 bundle(id){this.id(id);if(id==='data')return this.data;if(id.startsWith('local:')){const row=this.state().plugins[id];if(!/^[a-f0-9-]{36}$/.test(row.packageKey))throw Error('插件副本无效');return new Skills(this.req,this.path.join(this.dir,'package-skills',row.packageKey));}return new Skills(this.req,this.path.join(this.dir,'builtin-skills',id));}
 async skillRows(id){return this.bundle(id).list();}
 async enableSkill(id,key,enabled){this.bundle(id).enable(key,enabled);}
 async importBuiltin(id,root){this.id(id);const info=Catalog.find(p=>p.id===id);if(!info)throw Error('请选择内置插件');if(!root)root=await this.findBuiltin(id);if(!root)throw Error('未找到本机 Codex '+info.name+' 插件');const base=await this.fs.promises.realpath(root),manifest=JSON.parse(await this.fs.promises.readFile(this.path.join(base,'.codex-plugin','plugin.json'),'utf8'));if(manifest.name!==info.packageName)throw Error('插件目录与目标不符');const bundle=this.bundle(id),installed=[];try{const skillRoot=this.path.join(base,'skills');if(this.fs.existsSync(skillRoot)){const real=await this.fs.promises.realpath(skillRoot);if(!bundle.within(base,real))throw Error('插件技能目录越界');for(const file of await bundle.discover(real)){const p=await bundle.preview(file);if(bundle.state().items.some(s=>s.name.toLowerCase()===p.name.toLowerCase()))continue;installed.push(await bundle.add(file,'copy'));}}await this.locked(async()=>{const state=this.state();state.plugins[id]={...state.plugins[id],removed:false,installed:true,enabled:true,count:bundle.state().items.length,version:manifest.version,source:base};await this.write('plugins.json',JSON.stringify(state,null,2));});return bundle.state().items.length;}catch(e){for(const row of installed)await bundle.uninstall(row.id);throw e;}}
 async findBuiltin(id){const info=Catalog.find(p=>p.id===id);if(!info)return null;const cache=this.path.join(this.req('os').homedir(),'.codex','plugins','cache'),found=[];for(const market of await this.fs.promises.readdir(cache).catch(()=>[])){const base=this.path.join(cache,market,info.packageName);for(const v of await this.fs.promises.readdir(base,{withFileTypes:true}).catch(()=>[])){if(!v.isDirectory())continue;const root=this.path.join(base,v.name);try{const stat=await this.fs.promises.stat(this.path.join(root,'.codex-plugin','plugin.json'));found.push({root,time:stat.mtimeMs});}catch{}}}return found.sort((a,b)=>b.time-a.time)[0]?.root||null;}
 async uninstall(id){this.id(id);const row=this.state().plugins[id]||{};await this.update((s,c)=>{delete c[id];if(id==='google-drive'){delete c.googleConfig;delete c.googleBackup;}if(id==='github')delete c.githubConfig;s.plugins[id]={...s.plugins[id],removed:true,installed:false,enabled:false,connected:false,configured:false,account:null,accountLabel:null,backupAccount:null,accounts:[],activeAccount:null,codexAccounts:[],activeCodexAccount:null,count:0};});if(row.custom){await this.packages.removeOwned('packages',row.packageKey);await this.packages.removeOwned('package-skills',row.packageKey);}else{const bundle=this.bundle(id);for(const item of bundle.state().items)await bundle.uninstall(item.id);}}
 async renameAccount(id,label,key){this.id(id);label=String(label).trim();if(!label||label.length>100)throw Error('账号名称须为 1–100 字');await this.update((s,c)=>{const rows=this.migrateAccounts(id,s,c),a=rows.find(a=>a.key===(key||this.accountKey(id,s)));if(!a)throw Error('账号未连接');a.label=label;this.syncAccount(id,s);});}
 async execute(args,{signal,allowed=[]}={}){
  const {plugin:id,action}=args;if(!allowed.includes(id))throw Error('本轮未启用此插件');this.active(id);if(signal?.aborted)throw Object.assign(Error('已取消'),{name:'AbortError'});
  if(id==='data'||id==='plugin-creator'||id.startsWith('local:')||(['github','google-drive'].includes(id)&&['skills','skill','resource'].includes(action))){
   const bundle=this.bundle(id);
   if(action==='skills')return {skills:(await bundle.list()).filter(s=>s.enabled).map(s=>({name:s.name,description:s.description,error:s.error}))};
   if(action==='skill'){const s=await bundle.load(args.skill);return {name:s.name,instructions:s.body,resources:s.resources,adaptation:'当前宿主是 Typora，只有本轮实际列出的工具可用。SQL、连接器、Sites 和 Codex 专有工具不自动可用。创建文件和运行 Python 使用本机项目工具与现有审批；不得声称执行了未提供的工具。用户当前请求优先。'};}
   if(action==='resource')return bundle.resource(args.skill,args.path);
   throw Error('技能插件支持 skills、skill、resource');
  }
  if(this.connectionMode(id)==='codex'){
   const account=this.codexAccount(id);if(!account)throw Error('请先连接 Codex 账户');
   const stamp=JSON.stringify(account),guard=()=>{this.active(id);if(signal?.aborted)throw Object.assign(Error('已取消'),{name:'AbortError'});if(this.connectionMode(id)!=='codex'||JSON.stringify(this.codexAccount(id))!==stamp)throw Error('账户已切换，请重新执行请求');};
   const result=await this.codex.read(id,account,args,signal);guard();const serialized=JSON.stringify(result);
   return {untrusted_reference:true,plugin:id,action,connection:'codex',...(serialized.length>48000?{truncated:true,content:serialized.slice(0,48000)}:{data:result})};
  }
  let url,text=false,decodeFile=false;const segment=v=>{if(typeof v!=='string'||!/^[-\w.]+$/.test(v)||v==='.'||v==='..')throw Error('仓库名称无效');return encodeURIComponent(v);};
  if(id==='github'){
   if(action==='repos')url='https://api.github.com/user/repos?per_page=50&sort=updated';
   else if(action==='issues'){if(typeof args.query!=='string'||args.query.length>1000)throw Error('搜索词无效');url='https://api.github.com/search/issues?per_page=30&q='+encodeURIComponent(args.query);}
   else {const parts=String(args.repo||'').split('/');if(parts.length!==2)throw Error('仓库格式应为 owner/repo');const base='https://api.github.com/repos/'+parts.map(segment).join('/');
    if(action==='repo')url=base;
    else if(action==='file'){if(typeof args.path!=='string'||args.path.length>1000||args.path.split('/').some(p=>!p||p==='..'||p==='.')||/[\\\x00-\x1f]/.test(args.path))throw Error('文件路径无效');url=base+'/contents/'+args.path.split('/').map(encodeURIComponent).join('/')+(args.ref?'?ref='+encodeURIComponent(String(args.ref).slice(0,200)):'');decodeFile=true;}
    else if(action==='pull_request'){if(!Number.isInteger(args.number)||args.number<1)throw Error('PR 编号无效');url=base+'/pulls/'+args.number;}
    else throw Error('GitHub 支持 repos、repo、file、issues、pull_request');
   }
  }else{
   if(action==='search'){if(typeof args.query!=='string'||args.query.length>1000)throw Error('搜索词无效');const q="trashed = false"+(args.query?" and fullText contains '"+args.query.replace(/\\/g,'\\\\').replace(/'/g,"\\'")+"'":'');url='https://www.googleapis.com/drive/v3/files?'+new URLSearchParams({q,pageSize:'40',fields:'nextPageToken,files(id,name,mimeType,modifiedTime,webViewLink)',...(args.pageToken?{pageToken:String(args.pageToken).slice(0,2000)}:{})});}
   else if(action==='file'){if(typeof args.fileId!=='string'||!/^[-\w]{1,200}$/.test(args.fileId))throw Error('Drive 文件 ID 无效');url='https://www.googleapis.com/drive/v3/files/'+args.fileId+'?fields=id,name,mimeType,size,webViewLink';}
   else throw Error('Google Drive 支持 search、file');
  }
  const accountKey=this.accountKey(id),guardAccount=()=>{this.active(id);if(this.connectionMode(id)!=='direct'||this.accountKey(id)!==accountKey)throw Error('账户已切换，请重新执行请求');};const token=await this.token(id,signal,accountKey);guardAccount();let result=await this.transport(url,{token,signal,text});
  if(decodeFile&&!Array.isArray(result)&&result.encoding==='base64'){const bytes=this.Buffer.from(result.content||'','base64');if(bytes.includes(0))throw Error('此文件为二进制，无法作为文本读取');result={path:result.path,url:result.html_url,content:bytes.toString('utf8')};}
  if(id==='google-drive'&&action==='file'){
   guardAccount();const meta=result,mime=meta.mimeType||'',base='https://www.googleapis.com/drive/v3/files/'+args.fileId;let bodyURL;
   if(mime==='application/vnd.google-apps.document')bodyURL=base+'/export?mimeType=text%2Fplain';
   else if(mime==='application/vnd.google-apps.spreadsheet')bodyURL=base+'/export?mimeType=text%2Fcsv';
   else if(/^text\//.test(mime)||['application/json','application/x-ipynb+json','application/xml'].includes(mime)){if(Number(meta.size)>2*1024**2)throw Error('文件超过 2 MiB，请拆分后读取');bodyURL=base+'?alt=media';}
   else return {untrusted_reference:true,...meta,note:'当前仅支持文本、Google Docs 和 Sheets 内容读取'};
   result={...meta,content:await this.transport(bodyURL,{token,signal,text:true}),...(mime.includes('spreadsheet')?{note:'CSV 导出只包含第一个工作表'}:{})};
  }
  guardAccount();const serialized=JSON.stringify(result);return {untrusted_reference:true,plugin:id,action,...(serialized.length>48000?{truncated:true,content:serialized.slice(0,48000)}:{data:result})};
 }
}
module.exports=AIPlugins;
