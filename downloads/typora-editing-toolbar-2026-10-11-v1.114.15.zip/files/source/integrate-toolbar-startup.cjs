const fs = require('node:fs'), path = require('node:path');
module.exports = code => {
    const replace = (from, to) => {
        if (!code.includes(from)) throw Error('Missing toolbar startup integration: ' + from.slice(0, 80));
        code = code.replace(from, to);
    };
    replace('        this._injectCSS();\n        this._removeStaleNodes();', `        if (this.ready) return this.ready;
        this.ready = this._injectCSS().then(loaded => {
            if (loaded) this._mountToolbarUI();
        }).catch(error => console.warn('[EditingToolbar] Toolbar initialization failed:', error));
        return this.ready;
    }

    _mountToolbarUI() {
        this._removeStaleNodes();`);
    replace('        this._updateFloatingToolbarToggleButtons();\n    }', `        this._updateFloatingToolbarToggleButtons();
        performance.mark('et-toolbar-mounted');
    }`);
    replace(`        if (document.getElementById("editing-toolbar-style")) return;
        const link = document.createElement("link");
        link.id = "editing-toolbar-style";
        link.rel = "stylesheet";
        link.href = this._getAssetDir() + "/editing-toolbar.css";
        document.head.insertBefore(link, document.getElementById("et-theme-palette-overrides"));`,
        '        return ensureEditingToolbarStyle(this._getAssetDir() + "/editing-toolbar.css");');
    const pos = code.lastIndexOf('(function () {');
    if (pos < 0) throw Error('Missing toolbar boot');
    return code.slice(0, pos) + fs.readFileSync(path.join(__dirname, 'toolbar-style-loader.js'), 'utf8') + '\n' + code.slice(pos);
};
