class EditingToolbarDocumentSelection {
 constructor(toolbar){this.toolbar=toolbar;}
  bodyItem() {
    if(File.isFileLoading?.()||File.editor?.sourceView?.inSourceMode)return null;
    const selection=getSelection(),range=selection?.rangeCount?selection.getRangeAt(0):null;
    if(!range||range.collapsed||!this.toolbar._selectionInEditor(range))return null;
    const text=this.rangeText(range,selection.toString()).trim();if(!text)return null;if(text.length>100000)throw Error('选中文字超过 10 万字符，请缩小选区');
    const file=String(File.bundle?.filePath||'untitled:'+File.bundle?.untitledId);return{text,file,source:'正文 · '+(file.startsWith('untitled:')?'未命名文档':reqnode('path').basename(file))};
  }
  rangeText(range,fallback) {
    const fragment=range.cloneContents(),selector='[data-note-math][data-tex],.md-math-block,[md-inline="inline_math"]';
    const element=n=>n?.nodeType===1?n:n?.parentElement,inside=element(range.startContainer)?.closest(selector);
    const mathText=math=>{const native=this.toolbar.researchMaterials;const tex=math.dataset.tex??native?.mathText(math);if(!tex)return null;const display=math.dataset.noteMath==='display'||math.matches('.md-math-block');return display?'$$\n'+tex+'\n$$':'$'+tex+'$';};
    if(inside&&inside===element(range.endContainer)?.closest(selector))return mathText(inside)||fallback;
    let changed=false;for(const math of fragment.querySelectorAll(selector)){const text=mathText(math);if(text){math.replaceWith(document.createTextNode(text));changed=true;}}
    if(!changed)return fallback;
    for(const block of fragment.querySelectorAll('p,div,li,h1,h2,h3,h4,blockquote,pre,tr'))block.append(document.createTextNode('\n'));for(const br of fragment.querySelectorAll('br'))br.replaceWith(document.createTextNode('\n'));
    return fragment.textContent.replace(/\n{3,}/g,'\n\n').trim();
  }
  static insertableMarkdown(text) {
    // Code examples remain literal code. Outside fences, model HTML stays text.
    let fence = null, math = false;
    return String(text).split('\n').map(line => {
      const match = line.match(/^\s{0,3}(`{3,}|~{3,})/);
      if (match) { if (!fence) fence = match[1]; else if (match[1][0] === fence[0] && match[1].length >= fence.length) fence = null; return line; }
      if (fence) return line;
      if (/^\s*\$\$\s*$/.test(line)) { math = !math; return line; }
      if (math) return line;
      return line.split(/(`+[^`]*`+|\${1,2}[^$\n]+\${1,2}|\\\([^\n]*?\\\))/g).map(part => /^(?:`|\$|\\\()/.test(part) ? part : part.replace(/<(?=\/?[A-Za-z][^<>]*>|!)/g, '&lt;').replace(/!\[([^\]]*)\]\(https?:\/\/[^\s)]*(?:\s+"[^"]*")?\)/gi, '[$1]')).join('');
    }).join('\n');
  }
}
