const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const Client=require('./ai-client.cjs');
function fixture(realScope=false){
  const state={file:'A.md',loading:false,saved:[],requests:[],notices:[],draft:{text:'Question',folded:'',quotes:[]}};
  const storage=new Map();const sandbox={File:{isFileLoading:()=>state.loading},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},ETAIClient:Client,ETAIExecution:require('./ai-execution.cjs'),AbortController,reqnode:require,setTimeout,clearTimeout,console,performance:{now:()=>state.now||0},setInterval,clearInterval};
  vm.createContext(sandbox);vm.runInContext(fs.readFileSync(require.resolve('./ai-turn-timing.js'),'utf8')+'\n'+fs.readFileSync(require.resolve('./ai-assistant.js'),'utf8')+'\n'+fs.readFileSync(require.resolve('./ai-message-queue.js'),'utf8')+'\nglobalThis.Queue=EditingToolbarAIMessageQueue;globalThis.AI=EditingToolbarAI;',sandbox);
  const a=Object.create(sandbox.AI.prototype);
  Object.assign(a,{context:{file:'A.md',markdown:'SOURCE_A'},file:()=>state.file,turns:[],scope:{value:'document'},status:{hidden:true},panel:{hidden:false},prompt:{focus(){}},empty:{},messages:{querySelectorAll:()=>[]},resetCopyFeedback(){},notice:m=>state.notices.push(m),updateContext(){},renderTurn(){},scheduleRender(){},mountTurn:t=>{t.article={remove(){}};t.actions={children:[]};},profile:()=>({model:'fixture',url:'https://example.invalid/v1',protocol:'openai-chat'}),keyFor:async()=>'',request:async(p,k,m)=>{state.requests.push(m);return{text:'ANSWER_'+state.file};},capture(){this.context={file:state.file,markdown:'SOURCE_'+state.file[0]};return true;}});
  a.composerUI={command:null,sourceDraft:null,hasSourceDraft(){return !!(this.sourceDraft||this.sourceChanged);},restoreSource(){if(this.sourceDraft){a.context=this.sourceDraft.context;this.sourceDraft=null;}},closeMenu(){},refresh(){},sync(){},draft:{snapshot:()=>({...state.draft}),clear:()=>state.draft={text:'',folded:'',quotes:[]},restore:d=>state.draft={text:d?.text||'',folded:d?.folded||'',quotes:d?.quotes||[]},quotes:{snapshot:()=>state.draft.quotes,reference:()=>state.draft.quotes.map(q=>q.text).join('\n')}},request:()=>({question:state.draft.text,displayQuestion:state.draft.text}),consumed(){this.command=null;this.restoreSource();this.draft.clear();}};
  a.attachments={selected:[],pending:false,frozen:null,reset(){this.selected=[];this.frozen=null;},async prepare(base){return this.frozen||base;},freeze(r){this.frozen=r;}};
  a.promptsManager={reference:()=>a.attachments.frozen||{text:a.scope.value==='none'?'':a.context.markdown,label:a.context.file}};
  a.conversations={library:{update(){}},record:null,saveError:false,flush(){if(state.failSave)return false;if(a.turns.length)state.saved.push({file:a.context.file,turns:a.turns.map(t=>({...t}))});return true;},beforeNew(){if(!this.flush())return false;this.record=null;return true;},reset(){},schedule(){},refreshTitle(){}};
  a.busyState=function(v){this.busy=v;this.checkDocument();};
  if(realScope){
    for(const [file,name] of [['ai-composer.js','EditingToolbarAIComposer'],['ai-prompt-manager.js','EditingToolbarPromptManager'],['ai-attachments.js','EditingToolbarAIAttachments']])vm.runInContext(fs.readFileSync(require.resolve('./'+file),'utf8')+';globalThis.'+name+'='+name+';',sandbox);
    for(const name of ['hasSourceDraft','markSourceChanged','changeScope','stageSource','restoreSource','snapshot','restore','consumed'])a.composerUI[name]=sandbox.EditingToolbarAIComposer.prototype[name];a.composerUI.ai=a;
    a.promptsManager={ai:a,reference:sandbox.EditingToolbarPromptManager.prototype.reference,renderContextTools(){}};
    a.attachments.ai=a;a.attachments.prepare=sandbox.EditingToolbarAIAttachments.prototype.prepare;
    a.config={prompts:[]};a.context.selected='SELECTED_A';
  }
  return {a,state,sandbox};
}

function setup(){
 const f=fixture(true),{a,state,sandbox}=f;a.scope.value='none';a.editUI={enabled:false,sync(){},change(){return null;}};a.config.profiles=[{id:'mock',model:'fixture',url:'https://example.invalid/v1',protocol:'openai-chat',secret:'never-store-this',reasoningEffort:'high'}];a.profile=()=>a.config.profiles[0];a.queue=new sandbox.Queue(a);a.queue.schedule=()=>{};
 a.prompt={focus(){}};a.composerUI.draft.media={items:[],snapshot(){return this.items;}};
 a.conversations.flush=()=>{state.savedQueue=JSON.parse(JSON.stringify(a.queue.snapshot()));return !state.failSave;};
 return f;
}
function busy(a){a.busy=true;a.requestSource={ready:true};}
async function add(a,state,text){state.draft.text=text;await a.send();}
const tick=()=>new Promise(r=>setImmediate(r));
test('enqueue snapshots source, images, quotes and model options without credentials',async()=>{
 const {a,state}=setup();busy(a);a.scope.value='selection';a.composerUI.sourceChanged=true;a.context.selected='SNAPSHOT';state.draft.quotes=[{text:'QUOTE',file:'A.md',source:'正文'}];a.composerUI.draft.media.items=[{data:'data:image/png;base64,YQ==',name:'one.png'}];
 await add(a,state,'queued');assert.equal(state.requests.length,0);assert.equal(a.queue.items.length,1);assert.equal(state.draft.text,'');const item=a.queue.items[0];assert.equal(item.input.requestContext.text,'SNAPSHOT\n\nQUOTE');assert.equal(item.input.requestContext.images[0].name,'one.png');assert.equal(item.profile.reasoningEffort,'high');assert.ok(!JSON.stringify(state.savedQueue).includes('never-store-this'));
 a.context.selected='CHANGED';a.composerUI.draft.media.items[0].name='changed.png';assert.equal(item.input.requestContext.images[0].name,'one.png');assert.ok(!item.input.requestContext.text.includes('CHANGED'));
});
test('queued send appends completed history in FIFO order and preserves unsent draft',async()=>{
 const {a,state}=setup();let release;a.request=async(p,k,m)=>{state.requests.push(m);if(m.at(-1).content==='Question')await new Promise(r=>release=r);return{text:'answer '+m.at(-1).content};};
 const running=a.send();await tick();await add(a,state,'second');await add(a,state,'third');assert.equal(state.requests.length,1);state.draft.text='unsent fourth';release();await running;await a.queue.drain();await a.queue.drain();assert.equal(state.requests.length,3);assert.equal(state.requests[1].at(-3).content,'Question');assert.equal(state.requests[2].at(-3).content,'second');assert.equal(state.draft.text,'unsent fourth');assert.equal(a.queue.items.length,0);
});
test('stop and provider failure pause remaining messages; explicit resume can send',async()=>{
 const {a,state}=setup();busy(a);await add(a,state,'second');await add(a,state,'third');a.busy=false;a.request=async()=>{throw Error('provider offline');};await a.queue.drain();assert.equal(a.turns[0].status,'error');assert.equal(a.queue.paused,true);assert.equal(a.queue.items.length,1);await a.queue.drain();assert.equal(a.turns.length,1);a.request=async()=>({text:'ok'});a.queue.resume();await a.queue.drain();assert.equal(a.turns[1].question,'third');
 busy(a);await add(a,state,'after stop');a.controller=new AbortController();await a.act('stop');assert.equal(a.controller.signal.aborted,true);assert.equal(a.queue.paused,true);
});
test('invalid preflight retains queued item, and subsequent config repair allows retry',async()=>{
 const {a,state}=setup();busy(a);await add(a,state,'keep me');a.busy=false;a.config.profiles=[];await a.queue.drain();assert.equal(a.queue.items.length,1);assert.equal(a.queue.paused,true);assert.equal(a.turns.length,0);assert.ok(state.notices.at(-1).includes('模型配置'));a.config.profiles=[{...a.queue.items[0].profile}];a.queue.resume();await a.queue.drain();assert.equal(a.turns.length,1);assert.equal(a.queue.items.length,0);
});
test('restored queues are paused, editable data roundtrips and wrong-file entries are rejected',async()=>{
 const {a,state}=setup();busy(a);await add(a,state,'saved');const saved=JSON.parse(JSON.stringify(a.queue.snapshot()));a.queue.clear();a.busy=false;a.queue.restore(saved);assert.equal(a.queue.items[0].request.question,'saved');assert.equal(a.queue.paused,true);await a.queue.drain();assert.equal(state.requests.length,0);state.file='B.md';a.queue.restore(saved);assert.equal(a.queue.items.length,0);
});
test('document switch and hidden panel never dispatch the old queue',async()=>{
 for(const hidden of [true,false]){const {a,state}=setup();busy(a);await add(a,state,'old');a.busy=false;if(hidden)a.panel.hidden=true;else state.file='B.md';await a.queue.drain();assert.equal(state.requests.length,0);assert.equal(a.queue.paused,true);assert.equal(a.queue.items.length,1);}
});
test('failed/cancelled preparation preserves the input and never adds a partial item',async()=>{
 const {a,state}=setup();busy(a);a.attachments.prepare=async()=>{throw Error('missing file');};await add(a,state,'keep draft');assert.equal(state.draft.text,'keep draft');assert.equal(a.queue.items.length,0);assert.equal(a.queue.preparing,false);
 let resolve;a.attachments.prepare=()=>new Promise(r=>resolve=r);const pending=a.send();await tick();a.queue.suspend();resolve({text:'old'});await pending;assert.equal(state.draft.text,'keep draft');assert.equal(a.queue.items.length,0);
});
test('double submit while capture is pending cannot duplicate a queued message',async()=>{
 const {a,state}=setup();busy(a);let resolve;a.attachments.prepare=()=>new Promise(r=>resolve=r);const first=add(a,state,'once');await tick();await a.send();resolve({text:'',label:'none'});await first;assert.equal(a.queue.items.length,1);
});
test('remove, reorder and persistence failure retain safe queue state',async()=>{
 const {a,state}=setup();busy(a);await add(a,state,'one');await add(a,state,'two');a.queue.move(a.queue.items[1],-1);assert.equal(a.queue.items[0].request.question,'two');a.queue.remove(a.queue.items[1].id);assert.equal(a.queue.items.length,1);state.failSave=true;a.queue.changed();assert.equal(a.queue.paused,true);assert.equal(a.queue.items[0].request.question,'two');
});
test('queue ceiling leaves the extra draft intact',async()=>{
 const {a,state}=setup();busy(a);for(let i=0;i<11;i++)await add(a,state,'q'+i);assert.equal(a.queue.items.length,10);assert.equal(state.draft.text,'q10');
});

test('automatic draining runs one request at a time and survives typing between turns',async()=>{
 const {a,state,sandbox}=setup();a.queue.schedule=sandbox.Queue.prototype.schedule;let release,overlap=0,max=0;a.request=async(p,k,m)=>{overlap++;max=Math.max(max,overlap);state.requests.push(m);if(m.at(-1).content==='Question')await new Promise(r=>release=r);await tick();overlap--;return{text:'ok'};};
 const first=a.send();await tick();await add(a,state,'auto one');await add(a,state,'auto two');state.draft.text='do not consume';release();await first;
 const end=Date.now()+1000;while((a.queue.items.length||a.busy)&&Date.now()<end)await new Promise(r=>setTimeout(r,20));assert.equal(max,1);assert.equal(state.requests.length,3);assert.equal(a.queue.items.length,0);assert.equal(state.draft.text,'do not consume');clearTimeout(a.queue.timer);
});
test('queue persists through the actual session store without API credentials',()=>{
 const Store=require('./ai-session-store.cjs'),os=require('node:os'),path=require('node:path'),base=path.join(os.homedir(),'Downloads','codex-temp'),dir=(fs.mkdirSync(base,{recursive:true}),fs.mkdtempSync(path.join(base,'ai-queue-')));try{const store=new Store(require,dir),id=store.id(),item={id:'one',file:'A.md',request:{question:'saved'},profile:{id:'mock',model:'fixture'},input:{reference:{text:'snapshot',images:[{data:'data:image/png;base64,YQ=='}]}}};const saved=store.write({id,title:'queue',file:'A.md',turns:[],draftComposer:{text:'unsent',queue:{items:[item],paused:false}}},null,{context:{file:'A.md'}});const read=store.read(id);assert.deepEqual(read.draftComposer.queue.items,[item]);assert.equal(read.draftComposer.text,'unsent');assert.equal(saved.revision,read.revision);}finally{fs.rmSync(dir,{recursive:true,force:true});}
});

test('saved queue snapshots do not alias later edits or appends',async()=>{
 const {a,state}=setup();busy(a);await add(a,state,'before');const snapshot=a.queue.snapshot();a.queue.items[0].request.question='after';await add(a,state,'another');assert.equal(snapshot.items.length,1);assert.equal(snapshot.items[0].request.question,'before');
});
test('stream commits reuse queued attachments and only committed queue edits are visible',()=>{
 const Store=require('./ai-session-store.cjs'),store=new Store(require,'.'),id=store.id(),q={items:[{id:'q',request:{question:'before'},input:{reference:{text:'large attachment '.repeat(1000)}}}],paused:false};
 const record={id,version:2,revision:store.id(),created:new Date().toISOString(),updated:new Date().toISOString(),turns:[],draftComposer:{queue:q}},one=store.encode(record,null,null,true),next={...record,revision:store.id()};const two=store.encode(next,record,null,false);assert.ok(two.length<1000);assert.ok(!two.includes('large attachment'));assert.deepEqual(store.parse(Buffer.from(one+two),id).record.draftComposer.queue,q);
 const edit={...next,revision:store.id(),draftComposer:{queue:{...q,items:[{...q.items[0],request:{question:'after'}}]}}},three=store.encode(edit,next,null,false);assert.equal(store.parse(Buffer.from(one+two+three),id).record.draftComposer.queue.items[0].request.question,'after');assert.equal(store.parse(Buffer.from(one+two+three.slice(0,three.lastIndexOf('\n'))),id).record.draftComposer.queue.items[0].request.question,'before');
 const cleared={...edit,revision:store.id(),draftComposer:{queue:null}},four=store.encode(cleared,edit,null,false);assert.equal(store.parse(Buffer.from(one+two+three+four),id).record.draftComposer.queue,null);
});

test('editing a restored queue cannot mutate the saved record',async()=>{const {a,state}=setup();busy(a);await add(a,state,'original');const saved=a.queue.snapshot();a.queue.restore(saved);a.queue.items[0].request.question='edited';assert.equal(saved.items[0].request.question,'original');});


test('queued edits capture the explicit default, and later sends use the changed default instead of browsing',async()=>{const {a,state}=setup(),A={id:'A',root:'C:/A',name:'A',trusted:true},B={id:'B',root:'C:/B',name:'B',trusted:true};let selected=A;const manager={items:[A,B],active:()=>B};a.webUI={defaultProject:()=>({...selected}),project:()=>manager,sync(){}};a.editUI.enabled=true;const bound=[];a.editUI.run=async(p)=>{bound.push(p.project.id);return {text:'done'};};busy(a);await add(a,state,'queued A');assert.equal(a.queue.items[0].project.id,'A');selected=B;a.busy=false;await a.queue.drain();assert.deepEqual(bound,['A'],JSON.stringify({notices:state.notices,turns:a.turns,queue:a.queue.snapshot()}));state.draft.text='new B';await a.send();assert.deepEqual(bound,['A','B']);});

test('queued dispatch and retries retain the original question submission time',async()=>{
 const {a,state}=setup();busy(a);await add(a,state,'timed question');const submitted='2026-10-01T00:53:00.000Z';a.queue.items[0].time=submitted;a.busy=false;await a.queue.drain();assert.equal(a.turns[0].time,submitted);
 a.turns[0].status='error';a.turns[0].article={remove(){}};await a.send(a.turns[0]);assert.equal(a.turns[0].time,submitted);
});

test('queued shell calls retain their grant and cannot auto-enable after revoke or restart',async()=>{
 const {a,state}=setup(),project={id:'P',root:'C:\\P',trusted:true};let token='grant-one';a.webUI={defaultProject:()=>project,project:()=>({items:[project]})};a.shellUI={enabled:true,capture:()=>token,sanitizer:()=>s=>s};a.editUI.run=async()=>{throw Error('must not dispatch');};
 busy(a);await add(a,state,'queued shell');assert.equal(a.queue.items[0].shellGrant,'grant-one');const saved=a.queue.snapshot();a.busy=false;token=null;a.queue.restore(saved);a.queue.resume();await a.queue.drain();assert.equal(a.queue.items.length,1);assert.equal(a.turns.length,0);assert.ok(state.notices.some(s=>s.includes('Shell 权限已失效')));token='grant-two';a.queue.resume();await a.queue.drain();assert.equal(a.turns.length,0);
});
