'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
function fixture(){
 const Shell=require('./ai-shell.cjs'),Execution=require('./ai-execution.cjs');
 const UI=vm.runInNewContext(fs.readFileSync(require.resolve('./ai-shell.js'),'utf8')+';EditingToolbarAIShell',{AbortController,window:{addEventListener(){}},ETAIExecution:Execution,ETAIShell:Shell,reqnode:require});
 const state={project:{id:'one',root:'C:\\项目 空格',trusted:true},profile:{model:'gpt-6.1-sol'}};
 const manager={get items(){return [state.project];},core:{check:async()=>{}},read(){}};
 const ai={profile:()=>state.profile,editUI:{enabled:true},keys:new Map(),webUI:{defaultProject:()=>state.project,project:()=>manager},composerUI:{closeMenu(){}},notice(){},selectionUI:{temporary:{profile:()=>state.profile}}};
 return {state,ai,ui:new UI(ai)};
}
test('GPT editing defaults on for API and ChatGPT profiles, never for ask or other models',()=>{
 const {ui,ai,state}=fixture();assert.equal(ui.enabled,true);
 state.profile={model:'GPT-6-Astra',authType:'chatgpt'};assert.equal(ui.enabled,true);
 for(const model of ['deepseek-flash','o3','not-gpt','']){state.profile={model};assert.equal(ui.enabled,false);}
 state.profile={model:'gpt-6.1-sol'};ai.editUI.enabled=false;assert.equal(ui.enabled,false);
 ai.editUI.enabled=true;state.project.trusted=false;assert.equal(ui.enabled,false);
});
test('manual off survives repeated sync and mode/model changes; toggle creates a fresh grant',()=>{
 const {ui,ai,state}=fixture(),old=ui.capture();ui.revoke();ui.sync();assert.equal(ui.enabled,false);
 ai.editUI.enabled=false;state.profile={model:'deepseek-flash'};ui.sync();ai.editUI.enabled=true;state.profile={model:'gpt-6.1-sol'};assert.equal(ui.enabled,false);
 ui.toggle();assert.equal(ui.enabled,true);assert.notEqual(ui.capture(),old);
});
test('temporary Shell is independent, close clears its grant and stops only its commands',()=>{
 const {ui}=fixture(),formal=ui.capture(),tempProfile=ui.context('temporary');assert.equal(ui.capture(undefined,tempProfile),null);
 const a=new AbortController(),b=new AbortController();ui.jobs.set(a,'formal');ui.jobs.set(b,'temporary');
 ui.toggle('temporary');const temp=ui.capture(undefined,tempProfile);assert.ok(temp);assert.notEqual(temp,formal);
 ui.closeTemporary();assert.equal(ui.capture(undefined,tempProfile),null);assert.equal(b.signal.aborted,true);assert.equal(a.signal.aborted,false);assert.equal(ui.capture(),formal);
 ui.revoke();assert.equal(a.signal.aborted,true);
});
test('execution uses the captured GPT edit profile, not a later composer model, and rechecks revocation',async()=>{
 const {ui,state,ai}=fixture(),profile={...state.profile,documentEdit:true,project:{...state.project},shellEnabled:true};profile.shellGrant=ui.capture(profile.project,profile);
 let ran=0;ui.io.run=async()=>{ran++;return {exitCode:0};};state.profile={model:'deepseek-flash'};ai.editUI.enabled=false;
 await ui.execute(profile,{arguments:'{}'},{},{},{});assert.equal(ran,1);
 ui.revoke();await assert.rejects(ui.execute(profile,{arguments:'{}'},{},{},{}),/权限/);assert.equal(ran,1);
});
test('new window applies requested default but never revives a saved queue token',async()=>{
 const first=fixture(),profile={...first.state.profile,documentEdit:true,project:{...first.state.project},shellEnabled:true};profile.shellGrant=first.ui.capture();
 const next=fixture();assert.equal(next.ui.enabled,true);assert.notEqual(next.ui.capture(),profile.shellGrant);
 let ran=false;next.ui.io.run=async()=>{ran=true;};await assert.rejects(next.ui.execute(profile,{arguments:'{}'},{},{},{}),/权限/);assert.equal(ran,false);
});
