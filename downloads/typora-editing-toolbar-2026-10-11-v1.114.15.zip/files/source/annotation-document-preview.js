// Opt-in document preview vocabulary. HTML stays disabled in the shared parser;
// only image data and empty anchor names are rebuilt, never arbitrary markup.
export function installDocumentPreview(md) {
 md.inline.ruler.before('note_safe_formats','document_preview',(state,silent)=>{
  if(!state.env?.documentPreview)return false;
  const source=state.src.slice(state.pos),br=/^<br\s*\/?>/i.exec(source);
  if(br){if(!silent)state.push('hardbreak','br',0);state.pos+=br[0].length;return true;}
  const image=/^<img\b(?:[^<>"']|"[^"]*"|'[^']*')*>/i.exec(source),anchor=/^<(a|span)\b(?:[^<>"']|"[^"]*"|'[^']*')*>\s*<\/\1\s*>/i.exec(source);
  const match=image||anchor;if(!match)return false;
  const template=document.createElement('template');template.innerHTML=match[0];const element=template.content.firstElementChild;
  if(image){
   const src=element?.getAttribute('src');if(!src)return false;
   if(!silent){const t=state.push('note_image','img',0),size=value=>{const m=/^(\d+(?:\.\d+)?)(px|%)?$/.exec(value||'');return m&&+m[1]>0&&+m[1]<=(m[2]==='%'?100:12000)?m[1]+(m[2]||'px'):null;};
    const zoom=/^(\d+(?:\.\d+)?)(%)?$/.exec(element.style.zoom||''),scale=zoom?+zoom[1]/(zoom[2]?100:1):1;
    t.meta={src,alt:element.getAttribute('alt')||'图片',title:element.getAttribute('title'),previewStyle:{width:size(element.style.width||element.getAttribute('width')),height:size(element.style.height||element.getAttribute('height')),scale:scale>=.01&&scale<=10?scale:1}};
   }
  }else{
   const id=element?.getAttribute('id')||element?.getAttribute('name');if(!id||id.length>250||/[\s<>]/.test(id))return false;
   if(!silent){const t=state.push('note_preview_anchor','span',0);t.meta={id};}
  }
  state.pos+=match[0].length;return true;
 });
}

export function sizeDocumentImage(img,style){
 if(!style)return;
 const scale=style.scale||1;
 const apply=()=>{
  if(style.width)img.style.width=parseFloat(style.width)*scale+(style.width.endsWith('%')?'%':'px');
  else if(scale!==1&&img.naturalWidth)img.style.width=img.naturalWidth*scale+'px';
  if(style.height)img.style.height=parseFloat(style.height)*scale+(style.height.endsWith('%')?'%':'px');
 };
 apply();img.addEventListener('load',apply,{once:true});
}
