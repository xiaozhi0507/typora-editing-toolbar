const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const Client=require('./ai-client.cjs');
const source=fs.readFileSync(__dirname+'/ai-chatgpt.js','utf8')+'\nEditingToolbarAIChatGPT;';
const UI=vm.runInNewContext(source,{window:{addEventListener(){}},ETAIClient:Client,Map,Set,Promise,Date});
const account={id:'account-a',email:'test@example.test',enabled:true};
const initial={id:'existing-sol',name:'old',model:'gpt-6.1-sol',authType:'chatgpt',chatgptAccount:account.id,reasoningEffort:'xhigh'};
const models=[{id:'gpt-6.1-sol',name:'GPT-6.1-Sol',reasoningEfforts:['low','medium','high','xhigh']},{id:'gpt-6-astra',name:'GPT-6 Astra',reasoningEfforts:['low','high'],defaultReasoningEffort:'high'}];
const plain=x=>JSON.parse(JSON.stringify(x));
function setup(){
 const ai={config:{profiles:[{id:'api',model:'deepseek-flash',extra:'{}'},structuredClone(initial)],active:initial.id},persist(){this.saves=(this.saves||0)+1;},profile(){return this.config.profiles.find(p=>p.id===this.config.active);}};
 const ui=new UI(ai);ui.accounts=[{...account}];ui.refreshPickers=()=>{};ui.render=()=>{};ui.status=()=>{};return {ui,ai};
}
test('whole authorized catalog is added in server order, with API profile and active choice retained',()=>{
 const {ui,ai}=setup();ui.syncAccountModels(account,models);
 assert.deepEqual(ai.config.profiles.map(p=>p.model),['deepseek-flash','gpt-6.1-sol','gpt-6-astra']);assert.equal(ai.config.active,initial.id);
 assert.equal(ai.profile().reasoningEffort,'xhigh');assert.equal(ai.config.profiles[2].reasoningEffort,'high');
 assert.deepEqual(ai.config.profiles[0],{id:'api',model:'deepseek-flash',extra:'{}'});
});
test('repeated and duplicate entries do not multiply profiles or reset per-model effort',()=>{
 const {ui,ai}=setup();ui.syncAccountModels(account,models);ai.config.profiles[2].reasoningEffort='low';
 ui.syncAccountModels(account,[...models,models[0]]);ui.syncAccountModels(account,models);
 assert.equal(ai.config.profiles.length,3);assert.equal(ai.config.profiles[2].reasoningEffort,'low');assert.equal(ai.profile().id,initial.id);
});
test('capability changes clamp unsupported preference and remove stale metadata when absent',()=>{
 const {ui,ai}=setup();ui.syncAccountModels(account,[{...models[0],reasoningEfforts:['high']}]);
 assert.deepEqual(plain(ai.profile().reasoningEfforts),['high']);assert.equal(ai.profile().reasoningEffort,'high');
 ui.syncAccountModels(account,[{id:models[0].id,name:'renamed'}]);assert.equal(ai.profile().reasoningEfforts,undefined);assert.equal(ai.profile().modelLabel,'renamed');
});
test('temporarily missing models are disabled without losing their preference, then recover',()=>{
 const {ui,ai}=setup();ui.syncAccountModels(account,[]);assert.equal(ai.profile().chatgptAvailable,false);assert.equal(ai.profile().reasoningEffort,'xhigh');
 ui.syncAccountModels(account,models);assert.equal(ai.profile().chatgptAvailable,true);assert.equal(ai.profile().reasoningEffort,'xhigh');
});
test('same model on different accounts keeps separate IDs and preferences',()=>{
 const {ui,ai}=setup(),other={...account,id:'account-b'};ui.syncAccountModels(account,models);ui.syncAccountModels(other,models);
 assert.equal(new Set(ai.config.profiles.map(p=>p.id)).size,5);assert.equal(ai.config.profiles.filter(p=>p.chatgptAccount==='account-a').length,2);assert.equal(ai.config.profiles.filter(p=>p.chatgptAccount==='account-b').length,2);
});
test('concurrent catalog callers share request and cached calls do not refetch',async()=>{
 const {ui,ai}=setup();let resolve,count=0;ui.call=()=>{count++;return new Promise(r=>resolve=r);};
 const first=ui.accountModels(account),second=ui.accountModels(account);assert.equal(first,second);resolve(models);await first;await ui.accountModels(account);
 assert.equal(count,1);assert.equal(ai.config.profiles.length,3);
});
test('late model response after account invalidation cannot re-add profiles',async()=>{
 const {ui,ai}=setup();let resolve;ui.call=()=>new Promise(r=>resolve=r);const pending=ui.accountModels(account);
 ui.invalidateCatalog(account.id);ui.accounts=[];ai.config.profiles=ai.config.profiles.filter(p=>p.authType!=='chatgpt');resolve(models);
 assert.equal(await pending,null);assert.equal(ai.config.profiles.length,1);assert.equal(ui.catalogs.size,0);
});
test('picker refresh automatically migrates existing one-model config and uses cache',async()=>{
 const {ui,ai}=setup(),calls=[];ui.call=async(method)=>{calls.push(method);return method==='list'?[account]:models;};
 await ui.ensurePickerModels();await ui.ensurePickerModels();assert.deepEqual(calls,['list','models']);assert.equal(ai.config.profiles.length,3);assert.equal(ui.pickerLoading,false);assert.equal(ui.pickerError,'');
});
test('failure keeps existing configuration and permits later retry',async()=>{
 const {ui,ai}=setup();ui.call=async method=>{if(method==='list')return [account];throw Error('offline');};
 await ui.ensurePickerModels();assert.equal(ai.config.profiles.length,2);assert.equal(ui.pickerError,'offline');assert.equal(ui.pickerLoading,false);
 ui.pickerRefreshAt=0;ui.call=async method=>method==='list'?[account]:models;await ui.ensurePickerModels();assert.equal(ai.config.profiles.length,3);assert.equal(ui.pickerError,'');
});
test('one unavailable account does not prevent syncing another account',async()=>{
 const {ui,ai}=setup(),other={...account,id:'account-b'};ui.call=async(method,data)=>{if(method==='list')return [account,other];if(data.account===account.id)throw Error('expired');return models;};
 await ui.ensurePickerModels();assert.equal(ai.config.profiles.filter(p=>p.chatgptAccount===other.id).length,2);assert.equal(ui.pickerError,'expired');assert.equal(ai.config.active,initial.id);
});
test('in-flight account list cannot restore data after signout invalidation',async()=>{
 const {ui,ai}=setup();let resolve;ui.call=()=>new Promise(r=>resolve=r);const pending=ui.ensurePickerModels();ui.invalidateCatalog(account.id);ui.accounts=[];ai.config.profiles=ai.config.profiles.filter(p=>p.authType!=='chatgpt');resolve([account]);await pending;
 assert.equal(ui.accounts.length,0);assert.equal(ai.config.profiles.length,1);assert.equal(ui.pickerLoading,false);
});
test('API-only setup does not start ChatGPT helper or contact accounts',async()=>{
 const {ui,ai}=setup();ai.config.profiles=ai.config.profiles.filter(p=>p.authType!=='chatgpt');ui.accounts=[];ui.call=()=>{throw Error('must not call');};await ui.ensurePickerModels();assert.equal(ui.pickerLoading,undefined);
});

test('ChatGPT bridge carries explicit Shell permission without changing model or effort',()=>{const {ui}=setup();let payload;ui.call=(method,data)=>{payload=data;};ui.request({...initial,shellEnabled:true,documentEdit:true,project:{trusted:true}},[],{});assert.equal(payload.profile.shellEnabled,true);assert.equal(payload.profile.model,initial.model);assert.equal(payload.profile.reasoningEffort,'xhigh');ui.request({...initial,shellEnabled:false},[],{});assert.equal(payload.profile.shellEnabled,false);});


test('ChatGPT renderer bridge preserves minimal attachment scope in edit and ask requests',async()=>{
 const {ui}=setup();let sent;ui.call=async(method,params)=>{assert.equal(method,'request');sent=plain(params);return {text:'ok'};};
 const codeFiles=[{file:'C:\\project\\main.py',text:'private draft',projectRoot:'private root',grant:true},{file:'C:\\project\\paper.pdf',kind:'pdf'}];
 for(const documentEdit of [true,false]){
  await ui.request({...initial,codeFiles,documentEdit},[{role:'user',content:'检查附件'}],{});
  assert.deepEqual(sent.profile.codeFiles,[{file:codeFiles[0].file},{file:codeFiles[1].file,kind:'pdf'}]);
  assert.deepEqual(Client.tools(sent.profile).map(t=>t.name),documentEdit?['read_code_file','edit_code_file','run_python_file']:['read_code_file']);
 }
 await ui.request(initial,[],{});assert.deepEqual(sent.profile.codeFiles,[]);assert.equal(Client.tools(sent.profile).length,0);
});
test('ChatGPT renderer rejects invalid attachment metadata before sending a request',async()=>{
 const {ui}=setup();let calls=0;ui.call=async()=>{calls++;};
 for(const codeFiles of [{},[null],[{file:''}],[{file:'bad\0name'}],[{file:'a.py',kind:'shell'}],Array.from({length:11},()=>({file:'a.py'}))])
  assert.throws(()=>ui.request({...initial,codeFiles},[],{}),/关联文件信息无效/);
 assert.equal(calls,0);
});
