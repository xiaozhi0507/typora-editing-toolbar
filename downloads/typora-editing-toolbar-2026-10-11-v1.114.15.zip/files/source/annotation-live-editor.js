import {Schema, Slice} from 'prosemirror-model';
import {EditorState, Selection, TextSelection, NodeSelection, Plugin} from 'prosemirror-state';
import {EditorView, Decoration, DecorationSet} from 'prosemirror-view';
import {baseKeymap, chainCommands, exitCode, createParagraphNear, liftEmptyBlock, splitBlock} from 'prosemirror-commands';
import {keymap} from 'prosemirror-keymap';
import {InputRule, inputRules, wrappingInputRule, textblockTypeInputRule, undoInputRule} from 'prosemirror-inputrules';
import {schema as markdownSchema, defaultMarkdownParser, MarkdownParser, MarkdownSerializer, defaultMarkdownSerializer} from 'prosemirror-markdown';
import {splitListItem, sinkListItem, liftListItem} from 'prosemirror-schema-list';
import {history, undo, redo, closeHistory} from 'prosemirror-history';
import {tableNodes, tableEditing, goToNextCell} from 'prosemirror-tables';
import {noteTableNodes,NoteTableView,NoteTableRowView,noteTablePlugins,emptyTableDelete,tableArrowExit,serializeRichTable,installRichTables} from './annotation-tables.js';
import MarkdownIt from 'markdown-it';
import {installMathRules} from './annotation-math.cjs';
import {renderNotePreview} from './annotation-note-preview.js';
import {installDocumentPreview} from './annotation-document-preview.js';
import {formatMarks,installFormatRules,formatTokens,formatMarkSerializers,escapeAttr,serializeNoteImage} from './annotation-live-formats.js';
import {imageLayoutPlugin,imageLayout,imageRotation} from './annotation-image-layout.js';
import {createNoteToolbar} from './annotation-note-toolbar-full.js';
import {imageNodeView} from './annotation-image-view.js';
import {noteBlockEnter,noteArrowExit,leaveNoteMath,mathSourceBoundary} from './annotation-input-behavior.js';
import {resetExhaustedCode} from './annotation-code-reset.js';
import {inlineCodePlaceholder,pendingInlineCode} from './annotation-inline-code-placeholder.js';
import {noteAfterInput} from './annotation-after-input.js';
import {researchActions} from './annotation-research.js';
import {noteBlockTools,emptyNoteBlockDelete,removeEmptyNoteBlock} from './annotation-block-tools.js';
import {extraNodes,layoutAttrs,blockDOM,installStructureRules,structureTokens,structureSerializers,appendDefinitions} from './annotation-note-structure.js';

const mathSpec=inline=>({group:inline?'inline':'block',inline,atom:true,selectable:true,attrs:{tex:{default:''},display:{default:!inline}},
 toDOM:node=>[inline?'span':'div',{'data-note-math':node.attrs.display?'block':'inline','data-tex':node.attrs.tex,style:inline&&node.attrs.display?'display:block':null},node.attrs.tex],
 parseDOM:[{tag:(inline?'span':'div')+'[data-note-math]',getAttrs:el=>({tex:el.getAttribute('data-tex')||'',display:el.getAttribute('data-note-math')==='block'})}]});
let nodes=markdownSchema.spec.nodes.append({math_inline:mathSpec(true),math_block:mathSpec(false)});
nodes=nodes.update('paragraph',{...nodes.get('paragraph'),attrs:layoutAttrs,parseDOM:[{tag:'p',getAttrs:e=>({alignment:['left','center','right','justify'].includes(e.style.textAlign)?e.style.textAlign:null,indent:Math.max(0,Math.min(12,parseFloat(e.style.paddingLeft)/2||0))})}],toDOM:n=>blockDOM('p',n)});
nodes=nodes.update('heading',{...nodes.get('heading'),attrs:{...nodes.get('heading').attrs,...layoutAttrs},toDOM:n=>blockDOM('h'+n.attrs.level,n)});
nodes=nodes.update('bullet_list',{...nodes.get('bullet_list'),attrs:{task:{default:false}},toDOM:n=>['ul',{class:n.attrs.task?'note-task-list':''},0]});
nodes=nodes.update('ordered_list',{...nodes.get('ordered_list'),attrs:{...nodes.get('ordered_list').attrs,task:{default:false}}});
nodes=nodes.update('list_item',{...nodes.get('list_item'),attrs:{checked:{default:null}},toDOM:n=>n.attrs.checked===null?['li',0]:['li',{class:'note-task-item'},['input',{type:'checkbox',checked:n.attrs.checked?'':null,contenteditable:'false','aria-label':'完成任务'}],['div',0]]});
nodes=nodes.append(extraNodes);
nodes=nodes.update('image',{...nodes.get('image'),attrs:{...nodes.get('image').attrs,width:{default:null},wrap:{default:'inline'},side:{default:'left'},rotation:{default:0}},parseDOM:[{tag:'img[src]',getAttrs:el=>({src:el.getAttribute('src'),alt:el.getAttribute('alt'),title:el.getAttribute('title'),width:/^\d+$/.test(el.getAttribute('width')||'')?Math.max(32,Math.min(12000,+el.getAttribute('width'))):null,...imageLayout({wrap:el.dataset.noteWrap,side:el.dataset.noteSide}),rotation:imageRotation(el.dataset.noteRotation)})}],toDOM:n=>['img',{src:n.attrs.src,alt:n.attrs.alt,width:n.attrs.width,'data-note-wrap':n.attrs.wrap,'data-note-side':n.attrs.side,'data-note-rotation':n.attrs.rotation}]});
nodes=nodes.update('image',{...nodes.get('image'),attrs:{...nodes.get('image').attrs,previewStyle:{default:null}}});
nodes=nodes.append({note_preview_anchor:{inline:true,group:'inline',atom:true,attrs:{id:{}},toDOM:n=>['span',{'data-preview-anchor':n.attrs.id}]}});
nodes=nodes.append(tableNodes({tableGroup:'block',cellContent:'paragraph+',cellAttributes:{align:{default:null,getFromDOM:el=>el.style.textAlign||null,setDOMAttr:(value,attrs)=>{if(value)attrs.style='text-align:'+value}}}}));
nodes=noteTableNodes(nodes);
nodes=nodes.update('note_footnote',{...nodes.get('note_footnote'),parseDOM:[{tag:'sup[data-footnote]',priority:60,getAttrs:e=>({id:e.dataset.footnote,text:e.title||''})}]});
const schema=new Schema({nodes,marks:markdownSchema.spec.marks.update('link',{...markdownSchema.spec.marks.get('link'),parseDOM:[{tag:'a[href]',getAttrs:e=>({href:e.getAttribute('href'),title:e.getAttribute('title'),ref:e.getAttribute('ref')})}],attrs:{...markdownSchema.spec.marks.get('link').attrs,ref:{default:null}}}).append({strike:{parseDOM:[{tag:'s'},{tag:'del'}],toDOM:()=>['s',0]},...formatMarks})});
const tokenizer=new MarkdownIt('commonmark',{html:false}).enable(['table','strikethrough']);
installFormatRules(tokenizer);
installDocumentPreview(tokenizer);
installStructureRules(tokenizer);
installMathRules(tokenizer);
const parser=new MarkdownParser(schema,tokenizer,{...defaultMarkdownParser.tokens,...formatTokens,...structureTokens,
 s:{mark:'strike'},note_preview_anchor:{node:'note_preview_anchor',getAttrs:t=>t.meta},note_math:{node:'math_inline',getAttrs:t=>({tex:t.content,display:!!t.meta?.display})},note_math_block:{node:'math_block',getAttrs:t=>({tex:t.content})},
 table:{block:'table'},thead:{ignore:true},tbody:{ignore:true},tr:{block:'table_row'},th:{block:'table_header',getAttrs:t=>({align:(t.attrGet('style')||'').replace('text-align:','')||null})},td:{block:'table_cell',getAttrs:t=>({align:(t.attrGet('style')||'').replace('text-align:','')||null})}
});
tokenizer.core.ruler.after('inline','note_table_paragraphs',state=>{const tokens=[];for(let i=0;i<state.tokens.length;i++){const t=state.tokens[i];if(t.type==='inline'&&['td_open','th_open'].includes(state.tokens[i-1]?.type)){tokens.push(new state.Token('paragraph_open','p',1),t,new state.Token('paragraph_close','p',-1));}else tokens.push(t);}state.tokens=tokens;});
const serializer=new MarkdownSerializer({...defaultMarkdownSerializer.nodes,...structureSerializers(defaultMarkdownSerializer),
 image:(s,n)=>serializeNoteImage(s,n,defaultMarkdownSerializer.nodes.image),
 math_inline:(s,n)=>{const delimiter=n.attrs.display?'$$':'$';s.write(delimiter+n.attrs.tex+delimiter)},math_block:(s,n)=>{s.write('$$\n'+n.attrs.tex+'\n$$');s.closeBlock(n)},
 table:(s,n)=>{n.forEach((row,_,i)=>{const cells=[];row.forEach(cell=>cells.push(serializer.serialize(cell).trim().replace(/\n+/g,' ').replace(/\|/g,'\\|')));s.write('| '+cells.join(' | ')+' |\n');if(i===0){const rules=[];row.forEach(cell=>rules.push(cell.attrs.align==='center'?':---:':cell.attrs.align==='right'?'---:':cell.attrs.align==='left'?':---':'---'));s.write('| '+rules.join(' | ')+' |\n');}});s.closeBlock(n);},
 table_row:(s,n)=>s.renderContent(n),table_cell:(s,n)=>s.renderContent(n),table_header:(s,n)=>s.renderContent(n)
},{...defaultMarkdownSerializer.marks,...formatMarkSerializers,strike:{open:'~~',close:'~~',mixable:true,expelEnclosingWhitespace:true},link:{...defaultMarkdownSerializer.marks.link,open:(s,m,p,i)=>m.attrs.ref?'[':defaultMarkdownSerializer.marks.link.open(s,m,p,i),close:(s,m,p,i)=>m.attrs.ref?']['+m.attrs.ref+']':defaultMarkdownSerializer.marks.link.close(s,m,p,i)}},{escapeExtraCharacters:/\$/g});
const writeMarkdown=doc=>appendDefinitions(doc,serializer.serialize(doc));
export function renderPreview(host, markdown, options) { return renderNotePreview(host, markdown, schema, parser, options); }
const plainTableSerializer=serializer.nodes.table;
serializer.nodes.table=(s,n)=>{if(!serializeRichTable(s,n,schema))plainTableSerializer(s,n);};
installRichTables(tokenizer,parser,schema);

function markRule(regex,type){return new InputRule(regex,(state,match,start,end)=>{
 const text=match[1],marks=type.create().addToSet(state.storedMarks||state.selection.$from.marks());
 const tr=state.tr.replaceWith(start,end,schema.text(text,marks));tr.removeStoredMark(type);return tr;
});}
const rules=[
 wrappingInputRule(/^\s*>\s$/,schema.nodes.blockquote),wrappingInputRule(/^\s*([-+*])\s$/,schema.nodes.bullet_list),
 wrappingInputRule(/^(\d+)\.\s$/,schema.nodes.ordered_list,m=>({order:+m[1]}),(m,node)=>node.childCount+node.attrs.order===+m[1]),
 textblockTypeInputRule(/^(#{1,6})\s$/,schema.nodes.heading,m=>({level:m[1].length})),
 textblockTypeInputRule(/^```([\w-]*)\s$/,schema.nodes.code_block,m=>({params:m[1]})),
 markRule(/\*\*([^*\n]+)\*\*$/,schema.marks.strong),markRule(/__([^_\n]+)__$/,schema.marks.strong),
 markRule(/(?<!\*)\*([^*\n]+)\*$/,schema.marks.em),markRule(/(?<!_)_([^_\n]+)_$/,schema.marks.em),
 markRule(/`([^`\n]+)`$/,schema.marks.code),markRule(/~~([^~\n]+)~~$/,schema.marks.strike),
 new InputRule(/(?<![\\$])\$([^$\n]+)\$ $/,(state,m,start,end)=>{if(/^\s|\s$/.test(m[1])||state.doc.rangeHasMark(start,end,schema.marks.code))return null;const marks=state.doc.resolve(start).marks(),tr=state.tr.replaceWith(start,end,[schema.nodes.math_inline.create({tex:m[1]},null,marks),schema.text(' ',marks)]);return tr.setSelection(TextSelection.create(tr.doc,start+2));}),
 new InputRule(/^\$\$$/,(state,m,start,end)=>{const from=state.selection.$from.before(),tr=state.tr.replaceWith(from,state.selection.$from.after(),schema.nodes.math_block.create());return tr.setSelection(NodeSelection.create(tr.doc,from));})
];

export function create(host,options){
 let view,toolbar,readonly=false,documentKey=null,lastMarkdown='',live=true,changed=false;
 const savedStates=new Map();let restoreFrame=0,pendingView=null;
 const captureView=()=>({selection:view.state.selection.toJSON(),x:pendingView?.x??scrollX,y:pendingView?.y??scrollY,tables:pendingView?.tables??[...host.querySelectorAll('.note-table-scroll')].map(e=>e.scrollLeft)});
 // Focus/blur may flush before the next frame paints a restored scroll position.
 const restoreView=snapshot=>{if(!snapshot)return;try{const selection=Selection.fromJSON(view.state.doc,snapshot.selection);view.updateState(view.state.apply(view.state.tr.setSelection(selection)));}catch(_){}cancelAnimationFrame(restoreFrame);pendingView=snapshot;restoreFrame=requestAnimationFrame(()=>{window.scrollTo(snapshot.x||0,snapshot.y||0);host.querySelectorAll('.note-table-scroll').forEach((e,i)=>e.scrollLeft=snapshot.tables?.[i]||0);pendingView=null;restoreFrame=0;});};
 const sourceViews=new Set();
 const report=()=>{if(!changed)return;changed=false;const markdown=writeMarkdown(view.state.doc);if(markdown!==lastMarkdown){lastMarkdown=markdown;options.onChange(markdown);}};
 const flush=()=>{for(const item of sourceViews)item.commit();report();};
 class MathView {
  constructor(node,v,getPos){
   this.node=node;this.view=v;this.getPos=getPos;this.serial=0;this.destroyed=false;
   this.dom=document.createElement(node.isInline?'span':'div');this.dom.className='note-math '+(node.isInline?'note-math-inline':'note-math-block');this.dom.contentEditable='false';this.dom.tabIndex=0;
   this.render=document.createElement(node.isInline?'span':'div');this.render.className='note-math-render';this.render.title='点击编辑公式';
   this.source=document.createElement('textarea');this.source.className='note-math-source';this.source.setAttribute('aria-label',node.isInline?'行内公式源码':'公式块源码');this.source.spellcheck=false;this.source.hidden=true;this.source.value=node.attrs.tex;this.dom.append(this.render,this.source);sourceViews.add(this);
   this.render.addEventListener('mousedown',e=>{e.preventDefault();this.open()});this.dom.addEventListener('keydown',e=>{if(e.target!==this.dom||e.isComposing||e.ctrlKey||e.metaKey||e.altKey||e.shiftKey)return;if(e.key==='Enter'){e.preventDefault();this.open()}else if(e.key==='ArrowRight'||e.key==='ArrowDown'){e.preventDefault();this.close(true,e.key==='ArrowDown'?'down':'right')}});
   this.source.addEventListener('input',()=>{this.commit();this.resize()});this.source.addEventListener('blur',()=>this.close(false));
   const removeEmpty=e=>{if(readonly||e.isComposing||e.keyCode===229||!['Backspace','Delete'].includes(e.key)||e.ctrlKey||e.metaKey||e.altKey||e.shiftKey||this.source.value.length)return;const pos=this.getPos();if(pos!=null&&removeEmptyNoteBlock(v.state,v.dispatch,pos,this.node)){e.preventDefault();e.stopImmediatePropagation();v.focus();}};
   this.source.addEventListener('keydown',removeEmpty);this.dom.addEventListener('keydown',e=>{if(e.target===this.dom)removeEmpty(e);});
   this.source.addEventListener('keydown',e=>{if(e.isComposing||e.keyCode===229)return;if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'){e.preventDefault();(e.shiftKey?redo:undo)(v.state,v.dispatch);return;}if(!e.ctrlKey&&!e.metaKey&&!e.altKey&&!e.shiftKey&&mathSourceBoundary(this.source,e.key)){e.preventDefault();this.close(true,e.key==='ArrowDown'?'down':'right');return;}if(e.key==='Escape'||(e.key==='Enter'&&(node.isInline||e.ctrlKey||e.metaKey))){e.preventDefault();this.close(true)}});
   this.reposition=()=>this.positionPreview();window.addEventListener('scroll',this.reposition);window.addEventListener('resize',this.reposition);
   this.paint();if(!node.attrs.tex)setTimeout(()=>this.open(),0);
  }
  open(){if(readonly||this.destroyed)return;toolbar?.hide();this.source.hidden=false;this.dom.classList.add('editing');this.source.value=this.node.attrs.tex;this.resize();this.source.focus();this.source.setSelectionRange(this.source.value.length,this.source.value.length);}
  resize(){if(this.node.isInline){const lines=this.source.value.split('\n'),width=Math.min(innerWidth-48,Math.max(68,Math.max(...lines.map(x=>x.length))*8.4+24));this.source.style.width=width+'px';this.source.rows=1;}this.source.style.height='auto';this.source.style.height=Math.min(180,Math.max(this.node.isInline?29:45,this.source.scrollHeight))+'px';this.positionPreview();}
  positionPreview(){if(this.destroyed||!this.node.isInline||this.source.hidden)return;const r=this.source.getBoundingClientRect(),p=this.render.getBoundingClientRect();let top=r.bottom+6;if(top+p.height>innerHeight-8)top=r.top-p.height-6;this.render.style.left=Math.max(8,Math.min(r.left,innerWidth-p.width-8))+'px';this.render.style.top=Math.max(8,Math.min(top,innerHeight-p.height-8))+'px';}
  commit(){if(readonly||this.destroyed||this.source.hidden||this.source.value===this.node.attrs.tex)return;const pos=this.getPos();if(pos==null||this.view.state.doc.nodeAt(pos)?.type!==this.node.type)return;this.view.dispatch(this.view.state.tr.setNodeMarkup(pos,null,{...this.node.attrs,tex:this.source.value}));}
  close(focus,direction='right'){if(this.destroyed)return;this.commit();this.source.hidden=true;this.dom.classList.remove('editing');if(focus&&!readonly){const pos=this.getPos();if(pos!=null){leaveNoteMath(this.view,pos,this.node,direction);this.view.focus();}}}
  paint(){clearTimeout(this.timer);const serial=++this.serial,tex=this.node.attrs.tex;this.timer=setTimeout(async()=>{if(!tex){this.render.textContent='输入公式';this.dom.classList.add('incomplete');return;}try{const html=await options.renderMath(tex,this.node.attrs.display);if(!this.destroyed&&serial===this.serial){this.render.innerHTML=html;this.dom.classList.remove('incomplete');this.positionPreview();}}catch(_){if(!this.destroyed&&serial===this.serial){this.render.textContent='$'+tex+'$';this.dom.classList.add('incomplete');}}},100);}
  update(node){if(node.type!==this.node.type)return false;const changed=node.attrs.tex!==this.node.attrs.tex||node.attrs.display!==this.node.attrs.display;this.node=node;if(changed){if(this.source.value!==node.attrs.tex)this.source.value=node.attrs.tex;this.paint();}return true;}
  selectNode(){this.dom.classList.add('ProseMirror-selectednode')}
  deselectNode(){this.dom.classList.remove('ProseMirror-selectednode')}
  stopEvent(){return true}
  ignoreMutation(){return true}
  destroy(){this.destroyed=true;clearTimeout(this.timer);window.removeEventListener('scroll',this.reposition);window.removeEventListener('resize',this.reposition);sourceViews.delete(this)}
 }
 const enter=noteBlockEnter(schema);
 const plugins=[inputRules({rules}),history(),resetExhaustedCode(schema),inlineCodePlaceholder(),noteAfterInput(),noteBlockTools(),imageLayoutPlugin(),...noteTablePlugins(),keymap({
  'Mod-Home':(state,dispatch)=>{if(dispatch)dispatch(state.tr.setSelection(TextSelection.atStart(state.doc)).scrollIntoView());return true;},
  'Mod-End':(state,dispatch)=>{if(dispatch)dispatch(state.tr.setSelection(TextSelection.atEnd(state.doc)).scrollIntoView());return true;},
  'Mod-z':undo,'Mod-y':redo,'Mod-Shift-z':redo,'Backspace':chainCommands(emptyTableDelete,emptyNoteBlockDelete,undoInputRule,baseKeymap.Backspace),'Delete':chainCommands(emptyTableDelete,emptyNoteBlockDelete,baseKeymap.Delete),
  'Enter':chainCommands(enter,splitListItem(schema.nodes.list_item),baseKeymap.Enter),
  'ArrowRight':noteArrowExit(schema,'right'),'ArrowDown':chainCommands(tableArrowExit,noteArrowExit(schema,'down')),
  'Mod-Enter':chainCommands(exitCode,createParagraphNear,liftEmptyBlock,splitBlock),
  'Tab':chainCommands(goToNextCell(1),sinkListItem(schema.nodes.list_item)),
  'Shift-Tab':chainCommands(goToNextCell(-1),liftListItem(schema.nodes.list_item)),
  'Shift-Enter':(state,dispatch)=>{if(dispatch)dispatch(state.tr.replaceSelectionWith(schema.nodes.hard_break.create()).scrollIntoView());return true;}
 }),keymap(baseKeymap),tableEditing(),new Plugin({props:{decorations:state=>{if(options.placeholder&&!pendingInlineCode(state)&&state.doc.childCount===1&&state.doc.firstChild.type===schema.nodes.paragraph&&!state.doc.firstChild.content.size)return DecorationSet.create(state.doc,[Decoration.node(0,state.doc.firstChild.nodeSize,{'data-placeholder':options.placeholder,class:'note-placeholder'})]);return null;}}})];
 view=new EditorView(host,{
  state:EditorState.create({schema,doc:parser.parse(''),plugins}),editable:()=>!readonly,
  attributes:{'aria-label':(options.label||'注释')+'内容','role':'textbox','aria-multiline':'true','spellcheck':'false'},
  nodeViews:{table_row:n=>new NoteTableRowView(n),table:(n,v,pos)=>new NoteTableView(n,v,pos),math_inline:(...args)=>new MathView(...args),math_block:(...args)=>new MathView(...args),image:(n,v,pos)=>imageNodeView(n,v,pos,options),note_video:n=>{const dom=document.createElement('div');dom.className='note-video';const video=document.createElement('video');video.controls=true;video.preload='metadata';const asset=options.videoAsset(n.attrs.src);let url;if(asset){url=URL.createObjectURL(new Blob([asset.bytes],{type:asset.mime}));video.src=url;dom.append(video);}else dom.textContent='视频文件未找到';return{dom,stopEvent:()=>true,ignoreMutation:()=>true,destroy(){if(url)URL.revokeObjectURL(url);}};}},
  dispatchTransaction(tr){const next=this.state.applyTransaction(tr);this.updateState(next.state);if(next.transactions.some(t=>t.docChanged)){changed=true;report();}toolbar?.update();},
  handlePaste(v,event){
   const files=[...event.clipboardData.files].filter(f=>/^image\//.test(f.type));if(files.length){event.preventDefault();options.onFiles(files);return true;}
   if([...event.clipboardData.types].some(t=>/^image\//.test(t))){event.preventDefault();options.onNativeImage();return true;}
   const text=event.clipboardData.getData('text/plain');if(!text)return false;
   event.preventDefault();const doc=parser.parse(text);v.dispatch(v.state.tr.replaceSelection(Slice.maxOpen(doc.content)).scrollIntoView());return true;
  },
  handleDrop(v,event){if([...event.dataTransfer.types].includes('application/x-et-materials')){event.preventDefault();try{const markdown=options.dropMaterial?.(event);if(markdown){const hit=v.posAtCoords({left:event.clientX,top:event.clientY});if(hit)v.dispatch(v.state.tr.setSelection(TextSelection.near(v.state.doc.resolve(hit.pos))));v.dispatch(closeHistory(v.state.tr).replaceSelection(Slice.maxOpen(parser.parse(markdown).content)).scrollIntoView());v.dispatch(closeHistory(v.state.tr));}return true;}catch(e){options.notice?.(e.message);return true;}}const files=[...event.dataTransfer.files].filter(f=>/^image\//.test(f.type));if(!files.length)return false;event.preventDefault();const hit=v.posAtCoords({left:event.clientX,top:event.clientY});if(hit)v.dispatch(v.state.tr.setSelection(TextSelection.near(v.state.doc.resolve(hit.pos))));options.onFiles(files);return true;},
  clipboardTextSerializer:slice=>writeMarkdown(schema.nodes.doc.create(null,slice.content)),
  handleClick(v,pos,event){const foot=event.target.closest('.note-footnote');if(foot){event.preventDefault();const at=v.posAtDOM(foot,0),node=v.state.doc.nodeAt(at);if(node?.type===schema.nodes.note_footnote)toolbar.editFootnote(node,at,foot);return true;}const checkbox=event.target.closest('.note-task-item input');if(checkbox){event.preventDefault();const at=v.posAtDOM(checkbox.closest('li'),0),r=v.state.doc.resolve(at);for(let d=r.depth;d>0;d--)if(r.node(d).type===schema.nodes.list_item){v.dispatch(closeHistory(v.state.tr).setNodeMarkup(r.before(d),null,{checked:!r.node(d).attrs.checked}));break;}return true;}const a=event.target.closest('a'),source=a&&/^#et-source-([a-f0-9-]{36})$/.exec(a.getAttribute('href'));if(source){event.preventDefault();options.notice?.('来源跳转已停用，原有摘录内容仍保留。');return true;}if(a&&(event.ctrlKey||event.metaKey)){event.preventDefault();if(/^(https?:\/\/|mailto:|zotero:\/\/(?:open-pdf|select)\/)/i.test(a.href))options.openLink(a.href);return true;}return false;},
  handleDOMEvents:{focus:()=>{options.onFocus?.();return false;},blur:()=>{setTimeout(()=>{if(live){flush();options.onBlur?.();}},0);return false;}}
 });
 const research=researchActions(view,{parse:text=>parser.parse(text),serialize:writeMarkdown});
 options.collectSelection=()=>{const packet=research.capture();if(packet)options.onCollect?.(packet);};
 toolbar=createNoteToolbar(view,schema,options,{parse:text=>parser.parse(text),serialize:writeMarkdown});
 return {
  setMarkdown(markdown,key,disabled=false){readonly=disabled;if(documentKey===key&&lastMarkdown===markdown){view.setProps({editable:()=>!readonly});return;}toolbar.hide();cancelAnimationFrame(restoreFrame);if(options.retainStates&&documentKey!==null){const state=view.state.apply(closeHistory(view.state.tr));savedStates.set(documentKey,{markdown:writeMarkdown(state.doc),state,view:captureView()});}pendingView=null;restoreFrame=0;const cached=options.retainStates?savedStates.get(key):null;documentKey=key;lastMarkdown=markdown;changed=false;view.updateState(cached?.markdown===markdown?cached.state:EditorState.create({schema,doc:parser.parse(markdown),plugins}));view.setProps({editable:()=>!readonly});if(cached?.markdown===markdown)restoreView(cached.view);else if(options.retainStates)window.scrollTo(0,0);},
  appendMarkdown:research.append,captureMaterial:research.capture,
  captureView,restoreView,forgetState(key){savedStates.delete(key);},
  markdown:()=>writeMarkdown(view.state.doc),flush,
  focus(){view.focus()},blur(){toolbar.hide();view.dom.blur();for(const item of sourceViews)item.close(false)},
  insertImage(src){if(readonly)return;view.dispatch(view.state.tr.replaceSelectionWith(schema.nodes.image.create({src,alt:'图片'})).scrollIntoView());view.focus();},
  insertVideo(src){toolbar.run('note-video-insert',src);view.focus()},
  destroy(){live=false;cancelAnimationFrame(restoreFrame);savedStates.clear();toolbar.destroy();view.destroy()},
  getJSON:()=>view.state.doc.toJSON()
 };
}
