const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
function fixture(){
  const document={activeElement:null};
  const node=(tag,cls='',text='')=>({tag,className:cls,textContent:text,dataset:{},attrs:{},children:[],events:{},isConnected:true,append(...children){this.children.push(...children)},setAttribute(k,v){this.attrs[k]=v},addEventListener(k,f){this.events[k]=f},showModal(){this.open=true},close(){this.open=false;this.events.close?.()},remove(){this.isConnected=false},focus(){document.activeElement=this},select(){this.selected=true}});
  document.body=node('body');const previous=node('button');previous.focus();const box={document};vm.createContext(box);
  vm.runInContext(fs.readFileSync(require.resolve('./ai-conversations.js'),'utf8')+';globalThis.Conversations=EditingToolbarAIConversations;',box);
  const c=Object.assign(Object.create(box.Conversations.prototype),{ai:{node,bindSurface(){}},error(e){throw e}});
  return {c,document,previous,event:(target,extra={})=>({target,key:'Enter',prevented:false,preventDefault(){this.prevented=true},...extra})};
}
test('destructive confirmation respects focused buttons instead of a global Enter shortcut',async()=>{
  const {c,document,previous,event}=fixture(),result=c.ask('删除对话','永久删除',undefined,{danger:true,confirmLabel:'删除对话',subject:'自己的测试会话'}),d=c.confirm;
  assert.equal(document.activeElement,d);const initial=event(d);d.onkeydown(initial);assert.equal(initial.prevented,false);assert.equal(d.open,true);
  const cancel=d.children.at(-1).children[0],key=event(cancel);cancel.focus();d.onkeydown(key);assert.equal(key.prevented,false);assert.equal(d.open,true);
  await cancel.onclick();assert.equal(await result,null);assert.equal(c.confirm,null);assert.equal(document.activeElement,previous);
});
test('explicit confirmation resolves true once and external close resolves cancel',async()=>{
  const {c}=fixture();const result=c.ask('删除','永久删除',undefined,{danger:true,confirmLabel:'删除对话'}),d=c.confirm;
  await d.children.at(-1).children[1].onclick();assert.equal(await result,true);assert.equal(d.isConnected,false);assert.equal(c.confirm,null);
  const second=c.ask('删除','永久删除');c.confirm.close();assert.equal(await second,null);assert.equal(c.confirm,null);
});
test('rename input supports Enter but rejects blank and composing input',async()=>{
  const {c,event}=fixture(),result=c.ask('改名','填写名称','原名'),d=c.confirm,input=d.children.find(n=>n.tag==='input');
  input.value='   ';d.onkeydown(event(input));assert.equal(d.open,true);
  input.value='新名称';d.onkeydown(event(input,{isComposing:true}));assert.equal(d.open,true);d.onkeydown(event(input,{keyCode:229}));assert.equal(d.open,true);
  input.value=' 新名称 ';d.onkeydown(event(input));assert.equal(await result,'新名称');
});
test('only one confirmation opens; Escape cancels without confirming either operation',async()=>{
  const {c}=fixture(),result=c.ask('删除','永久删除');assert.equal(await c.ask('删除第二条','永久删除'),null);
  let prevented=false;c.confirm.events.cancel({preventDefault(){prevented=true}});assert.equal(prevented,true);assert.equal(await result,null);
});
