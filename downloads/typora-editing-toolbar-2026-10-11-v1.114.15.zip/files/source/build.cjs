const fs=require('node:fs'),path=require('node:path');
const editorBuild=require('esbuild').buildSync({entryPoints:[path.join(__dirname,'annotation-live-editor.js')],bundle:true,format:'iife',globalName:'ETNoteLive',minify:true,write:false,nodePaths:[path.join(__dirname,'node_modules'),...(process.env.NODE_PATH||'').split(path.delimiter).filter(Boolean)]});

const base=path.join(__dirname,'base');
let code=fs.readFileSync(path.join(base,'editing-toolbar.js'),'utf8').replace(/\r\n/g,'\n');
let css=fs.readFileSync(path.join(base,'editing-toolbar.css'),'utf8');
const replace=(a,b)=>{if(!code.includes(a))throw Error('Missing annotation integration '+a.slice(0,80));code=code.replace(a,b);};
const placementStart=code.indexOf('            const bar=this.toolbar.getBoundingClientRect(),width=innerWidth,height=innerHeight;');
const placementEnd=code.indexOf('            this.toolbar.style.left=left+"px";',placementStart);
if(placementStart<0||placementEnd<0)throw Error('Missing selection popup placement');
code=code.slice(0,placementStart)+'            const {left,top}=this._selectionToolbarPosition(rect,this.toolbar.getBoundingClientRect());\n'+code.slice(placementEnd);
replace('    _getSelectionRect(selection) {',fs.readFileSync(path.join(__dirname,'selection-popup-placement.js'),'utf8')+'\n    _getSelectionRect(selection) {');
const hexMethods=new Function(fs.readFileSync(path.join(__dirname,'toolbar-hex-color.js'),'utf8')+';return ToolbarHexColor.prototype;')();
const paletteSource=fs.readFileSync(path.join(__dirname,'palette-picker.js'),'utf8').replace('export function','function');
replace('const BUTTON_DEFINITIONS = {',paletteSource+'\nconst BUTTON_DEFINITIONS = {');
replace('        panel.hidden = false;', '        panel.hidden = false;\n        panel._resetColorSelection?.();');
replace('        this.activePopover.hidden = true;', '        this.activePopover._paletteTools?.cancel();\n        this.activePopover.hidden = true;');
replace('    _buildColorPicker(kind) {','    '+hexMethods._appendHexColorInput.toString()+'\n\n    _buildColorPicker(kind) {');
replace('            if (event.target.closest?.(".et-top-chrome")) return;','            if (event.target.closest?.(".et-top-chrome,input,textarea,select")) return;');
replace('        this._bindEvents();','        this._bindEvents();\n        this._initAnnotations();');
replace('document.documentElement.clientWidth-bounds.width-8','(this.annotations&&!this.annotations.panel.hidden?this.annotations.panel.getBoundingClientRect().left:document.documentElement.clientWidth)-bounds.width-8');
replace('    _onSelectionChange() {','    _onSelectionChange() {\n        if(this.annotations?.panel.contains(document.activeElement)){this.hide();return;}');
replace('    show(selection) {','    show(selection) {\n        if(this.annotations?.panel.contains(document.activeElement)){this.hide();return;}');
replace('        requestAnimationFrame(()=>{\n            if (this.settingsDialog', '        requestAnimationFrame(()=>{\n            if(this.annotations?.panel.contains(document.activeElement)){this.hide();return;}\n            if (this.settingsDialog');
replace('    _injectCSS() {',`    _initAnnotations() {
        if(this.annotations)return;
        if(typeof reqnode!=="function"||!window.File?.editor||!window.File?.option?.userDataPath||typeof window.File?.saveAsUseNode!=="function"){
            if((this.annotationWait=(this.annotationWait||0)+1)<120)setTimeout(()=>this._initAnnotations(),this.annotationWait<20?40:250);
            return;
        }
        try {this.annotations=new EditingToolbarAnnotations(this);} catch(error) {this.annotationError=error.message;console.warn("[EditingToolbar] Annotations unavailable:",error);}
    }

    _injectCSS() {`);
replace('return ["undo","redo","heading-menu","paragraph-menu","math-menu","common-menu","insert-menu","more-menu","toolbar-settings"];','return ["undo","redo","heading-menu","paragraph-menu","math-menu","common-menu","insert-menu","annotation","more-menu","toolbar-settings"];');
replace('"font-color","bg-color","fullscreen","floating-toolbar-toggle","toolbar-settings"','"font-color","bg-color","annotation","fullscreen","floating-toolbar-toggle","toolbar-settings"');
replace('return {version:1,layoutRevision:3,topLayout:"compact"','return {version:1,layoutRevision:3,annotationRevision:1,topLayout:"compact"');
replace('"clear-format","font-color","bg-color"],\n            size:', '"clear-format","font-color","bg-color","annotation"],\n            size:');
replace('        const top = topLayout === "classic"', '        if (!input.annotationRevision) {\n            if(!compact.order.includes("annotation"))compact.order.splice(Math.max(0,compact.order.indexOf("more-menu")),0,"annotation");\n            if(!classic.buttons.includes("annotation"))classic.buttons.splice(Math.max(0,classic.buttons.indexOf("toolbar-settings")),0,"annotation");\n            if(!floating.includes("annotation"))floating.push("annotation");\n        }\n        const top = topLayout === "classic"');
replace('return {version:1,layoutRevision:3,topLayout,','return {version:1,layoutRevision:3,annotationRevision:1,topLayout,');
replace('controls:["undo","redo","more-menu","toolbar-settings"],buttons:["undo","redo",','controls:["undo","redo","annotation","more-menu","toolbar-settings"],buttons:["undo","redo","annotation",');
replace('        if (action === "toolbar-settings") return this._openToolbarSettings();','        if (action === "annotation") {if(this.annotations)return this.annotations.openFromSelection();this._showToolbarNotice("笔记注释未能加载，请重新打开 Typora。");return;}\n        if (action === "toolbar-settings") return this._openToolbarSettings();\n        if(this.annotations?.panel.contains(document.activeElement)){this._showToolbarNotice("正在编辑注释，请在注释框使用 Markdown，或先点击正文。");return;}');
replace('const BUTTON_DEFINITIONS = {','const BUTTON_DEFINITIONS = {\n    "annotation": {icon:\'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 4h14a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-8l-5 3v-3H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z"/><path d="M7 8h10M7 12h7"/></svg>\',title:"笔记注释"},');
const annotation=fs.readFileSync(path.join(__dirname,'annotation-hover-preview.js'),'utf8')+'\n'+fs.readFileSync(path.join(__dirname,'annotation-manager.js'),'utf8');
const pos=code.lastIndexOf('(function () {');if(pos<0)throw Error('Missing boot');
const editorBundle=editorBuild.outputFiles[0].text;
const editorCSS=['annotation-live-editor.css','annotation-note-toolbar-full.css','annotation-block-tools.css','annotation-image-layout.css'].map(name=>fs.readFileSync(path.join(__dirname,name),'utf8')).join('\n');
code=code.slice(0,pos)+'// Offline editor dependencies: see files/docs/THIRD_PARTY.md.\nconst ET_NOTE_LIVE_BUNDLE='+JSON.stringify(editorBundle)+';\nconst ET_NOTE_LIVE_CSS='+JSON.stringify(editorCSS)+';\n'+annotation+'\n'+code.slice(pos);
css+='\n'+fs.readFileSync(path.join(__dirname,'annotation-panel.css'),'utf8');
css+='\n'+fs.readFileSync(path.join(__dirname,'annotation-hover-preview.css'),'utf8');
css+='\n'+fs.readFileSync(path.join(__dirname,'toolbar-hex-color.css'),'utf8');
code=require('./integrate-document-notes.cjs')(code);
code=require('./integrate-manual-marks.cjs')(code);
code=require('./integrate-research-materials.cjs')(code);
code=require('./integrate-reading-tools.cjs')(code);
code=require('./integrate-theme-palette.cjs')(code);
code=require('./integrate-paragraph-spacing.cjs')(code);
css+='\n'+fs.readFileSync(path.join(__dirname,'paragraph-spacing.css'),'utf8');
code=require('./integrate-toolbar-startup.cjs')(code);
code=require('./integrate-reading-copy.cjs')(code);
code=require('./integrate-knowledge-library.cjs')(code);
code=require('./integrate-ai-assistant.cjs')(code);
code=require('./integrate-terminal.cjs')(code);
code=require('./integrate-document-split.cjs')(code);
code=require('./integrate-code-editor.cjs')(code);
code=require('./integrate-notebook.cjs')(code);


css+='\n'+fs.readFileSync(path.join(__dirname,'document-split.css'),'utf8');

css+='\n'+['ai-plugins.css','ai-skills.css','ai-execution.css','knowledge-library-backup.css'].map(f=>fs.readFileSync(path.join(__dirname,f),'utf8')).join('\n');
css+='\n'+fs.readFileSync(path.join(__dirname,'knowledge-library-quick-menu.css'),'utf8');
css=css.replaceAll('#et-annotation-panel',':is(#et-annotation-panel,#et-document-note-panel,#et-manual-mark-panel)');
css+='\n'+fs.readFileSync(path.join(__dirname,'document-note-tabs.css'),'utf8');
css+='\n'+fs.readFileSync(path.join(__dirname,'manual-marks.css'),'utf8');
css+='\n'+fs.readFileSync(path.join(__dirname,'research-materials.css'),'utf8');
css+='\n'+fs.readFileSync(path.join(__dirname,'reading-tools.css'),'utf8');
css+='\n'+fs.readFileSync(path.join(__dirname,'body-citation-preview.css'),'utf8');
for(const f of ['body-reading-mode.css','body-image-scale.css','image-markup.css','preview-copy.css'])css+='\n'+fs.readFileSync(path.join(__dirname,f),'utf8');
css+='\n'+fs.readFileSync(path.join(__dirname,'research-sidebar.css'),'utf8');
css+='\n'+['document-tabs.css','sidebar-dialog.css'].map(f=>fs.readFileSync(path.join(__dirname,f),'utf8')).join('\n');
css+='\n'+fs.readFileSync(path.join(__dirname,'theme-palette.css'),'utf8');
css+='\n'+fs.readFileSync(path.join(__dirname,'preferences-dialogs.css'),'utf8');
css+='\n'+fs.readFileSync(path.join(__dirname,'theme-appearance.css'),'utf8');
const workspacePos=code.lastIndexOf('(function () {');
code=code.slice(0,workspacePos)+fs.readFileSync(path.join(__dirname,'panel-workspace.js'),'utf8')+'\n'+code.slice(workspacePos);
css+='\n'+fs.readFileSync(path.join(__dirname,'panel-workspace.css'),'utf8');
code=require('./integrate-top-toolbar-motion.cjs')(code);
css+='\n'+fs.readFileSync(path.join(__dirname,'top-toolbar-motion.css'),'utf8');
css+='\n'+fs.readFileSync(path.join(__dirname,'sidebar-motion.css'),'utf8');
css+='\n'+fs.readFileSync(path.join(__dirname,'drag-motion.css'),'utf8');
css+='\n'+fs.readFileSync(path.join(__dirname,'viewport-performance.css'),'utf8');
code=require('./integrate-feature-modules.cjs')(code);
css+='\n'+fs.readFileSync(path.join(__dirname,'feature-modules.css'),'utf8');
new Function(code);
const dest=path.resolve(__dirname,'../plugin');
fs.mkdirSync(dest,{recursive:true});
fs.copyFileSync(path.join(__dirname,'notebook-kernel.py'),path.join(dest,'editing-toolbar.notebook.py'));
for(const ext of ['js','css'])for(const name of ['editing-toolbar.','editing-toolbar.runtime.'])fs.writeFileSync(path.join(dest,name+ext),ext==='js'?code:css);
fs.writeFileSync(path.join(dest,'editing-toolbar.theme-bootstrap.js'),require('./build-theme-bootstrap.cjs')());
require('esbuild').buildSync({entryPoints:[path.join(__dirname,'ai-chatgpt-worker.cjs')],bundle:true,platform:'node',target:'node18',outfile:path.join(dest,'editing-toolbar.chatgpt.cjs')});
require('node:child_process').execFileSync('C:/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe',['/nologo','/target:winexe','/optimize+','/r:System.Web.Extensions.dll','/out:'+path.join(dest,'editing-toolbar.open.exe'),path.join(__dirname,'document-open-launcher.cs')],{windowsHide:true});
require('./build-code-editor.cjs')();
console.log('Annotation candidate built and syntax checked.');
require('node:child_process').execFileSync('C:/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe',['/nologo','/target:winexe','/optimize+','/r:System.Web.Extensions.dll','/out:'+path.join(dest,'editing-toolbar.terminal.exe'),path.join(__dirname,'terminal-host.cs')],{windowsHide:true});




// Workspace engines belong to the independently updatable AI module.
const moduleAssets=path.join(dest,'editing-toolbar.modules','ai-reading-assistant','assets');fs.mkdirSync(moduleAssets,{recursive:true});
for(const name of ['editing-toolbar.code.js','editing-toolbar.code.css','editing-toolbar.code.LICENSE.txt','editing-toolbar.notebook.py','editing-toolbar.terminal.exe'])fs.copyFileSync(path.join(dest,name),path.join(moduleAssets,name));
