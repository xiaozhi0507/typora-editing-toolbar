// Dialog geometry is independent of sidebar/floating assistant layout.
class EditingToolbarAIConversationMotion {
  constructor(owner,header) {this.owner=owner;this.ai=owner.ai;this.panel=owner.dialog;this.header=header;}
  state() {return this.ai.config.conversationWindow||{};}
  rect() {const r=this.panel.getBoundingClientRect();return {left:r.left,top:r.top,width:r.width,height:r.height};}
  clamp(g) {
    const maxW=Math.max(1,innerWidth-16),maxH=Math.max(1,innerHeight-16),minW=Math.min(360,maxW),minH=Math.min(300,maxH);
    const width=Math.min(maxW,Math.max(minW,Number(g.width)||1080)),height=Math.min(maxH,Math.max(minH,Number(g.height)||760));
    const left=Number.isFinite(g.left)?g.left:(innerWidth-width)/2,top=Number.isFinite(g.top)?g.top:(innerHeight-height)/2;
    return {left:Math.max(8,Math.min(left,innerWidth-width-8)),top:Math.max(8,Math.min(top,innerHeight-height-8)),width,height};
  }
  apply(g) {for(const [key,value] of Object.entries(g))this.panel.style[key]=value+'px';}
  layout() {if(this.panel.open&&!this.drag)this.apply(this.clamp(this.state()));}
  save(g) {this.ai.config.conversationWindow={...g};try{this.ai.persist();}catch(e){this.owner.error(e);}}
  mount() {
    const d=this.panel,title=this.header.querySelector('h2');title.tabIndex=0;title.title='拖动标题栏移动窗口；聚焦标题后用方向键移动';title.setAttribute('aria-label','侧边栏对话，方向键移动窗口');
    const bind=handle=>{
      handle.addEventListener('pointerdown',e=>this.start(e,handle));
      handle.addEventListener('pointermove',e=>{if(this.drag?.handle===handle&&e.pointerId===this.drag.id)this.queue(e);});
      handle.addEventListener('pointerup',e=>{if(this.drag?.handle===handle&&e.pointerId===this.drag.id){this.queue(e);this.finish(false);}});
      handle.addEventListener('pointercancel',()=>{if(this.drag?.handle===handle)this.finish(true);});
      handle.addEventListener('lostpointercapture',()=>{if(this.drag?.handle===handle)this.finish(true);});
    };
    bind(this.header);
    for(const edge of ['n','s','e','w','ne','nw','se','sw']){
      const h=this.owner.node('div','et-ai-manager-resize');h.dataset.edge=edge;h.tabIndex=edge==='se'?0:-1;h.setAttribute('role','separator');h.setAttribute('aria-label','调整会话窗口大小 '+edge);if(edge==='se')h.title='拖动缩放，或用方向键调整大小';d.append(h);bind(h);
      if(edge==='se')h.onkeydown=e=>this.keyboard(e,true);
    }
    title.onkeydown=e=>this.keyboard(e,false);
    window.addEventListener('keydown',e=>{if(e.key==='Escape'&&this.drag){e.preventDefault();e.stopImmediatePropagation();this.finish(true);}},true);
    window.addEventListener('blur',()=>this.finish(true));
    window.addEventListener('resize',()=>{this.finish(true);cancelAnimationFrame(this.layoutFrame);this.layoutFrame=requestAnimationFrame(()=>this.layout());});
    d.addEventListener('close',()=>this.finish(true));
  }
  keyboard(e,resize) {
    if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key))return;e.preventDefault();e.stopPropagation();
    const g=this.rect(),step=e.shiftKey?40:12,dx=e.key==='ArrowRight'?step:e.key==='ArrowLeft'?-step:0,dy=e.key==='ArrowDown'?step:e.key==='ArrowUp'?-step:0;
    if(resize){g.width=Math.min(g.width+dx,innerWidth-g.left-8);g.height=Math.min(g.height+dy,innerHeight-g.top-8);}else{g.left+=dx;g.top+=dy;}
    const next=this.clamp(g);this.apply(next);this.save(next);
  }
  start(e,handle) {
    if(e.button!==0||!e.isPrimary||this.drag||e.target.closest('button,input,textarea,select,a')||!this.panel.open)return;
    const edge=handle.dataset.edge||'',g=this.rect();this.drag={handle,id:e.pointerId,edge,start:g,x:e.clientX,y:e.clientY,dx:0,dy:0,w:innerWidth,h:innerHeight};
    this.panel.classList.add('et-ai-manager-moving');this.panel.style.setProperty('--et-manager-cursor',edge?edge+'-resize':'grabbing');
    try{handle.setPointerCapture(e.pointerId);}catch{this.finish(true);return;}e.preventDefault();e.stopPropagation();
  }
  queue(e) {const d=this.drag;d.dx=e.clientX-d.x;d.dy=e.clientY-d.y;if(!this.frame)this.frame=requestAnimationFrame(()=>{this.frame=0;this.paint();});}
  paint() {
    const d=this.drag;if(!d)return;const g=d.start;
    if(!d.edge){d.next=this.clamp({...g,left:g.left+d.dx,top:g.top+d.dy});this.panel.style.transform='translate3d('+(d.next.left-g.left)+'px,'+(d.next.top-g.top)+'px,0)';return;}
    let left=g.left,top=g.top,right=g.left+g.width,bottom=g.top+g.height;
    const minW=Math.min(360,d.w-16),minH=Math.min(300,d.h-16);
    if(d.edge.includes('w'))left=Math.max(8,Math.min(g.left+d.dx,right-minW));
    if(d.edge.includes('e'))right=Math.min(d.w-8,Math.max(right+d.dx,left+minW));
    if(d.edge.includes('n'))top=Math.max(8,Math.min(g.top+d.dy,bottom-minH));
    if(d.edge.includes('s'))bottom=Math.min(d.h-8,Math.max(bottom+d.dy,top+minH));
    d.next={left,top,width:right-left,height:bottom-top};this.apply(d.next);
  }
  finish(cancel) {
    const d=this.drag;if(!d)return;cancelAnimationFrame(this.frame);this.frame=0;if(!cancel)this.paint();this.drag=null;
    this.panel.style.transform='';this.panel.classList.remove('et-ai-manager-moving');this.panel.style.removeProperty('--et-manager-cursor');
    const g=cancel?d.start:d.next||d.start;this.apply(this.clamp(g));if(d.handle.hasPointerCapture(d.id))d.handle.releasePointerCapture(d.id);if(!cancel&&d.next)this.save(g);
  }
}
