// Integrate with Typora's native menu so hover, keyboard navigation and dismissal agree.
class EditingToolbarMarkdownLinks {
 constructor(toolbar){
  this.toolbar=toolbar;
  this.installFileLinkCompatibility();
  window.addEventListener('click',event=>{
   if(!toolbar.readingMode?.enabled||event.button!==0||event.altKey||event.shiftKey)return;
   const link=event.target.closest?.('#write a[href]');
   if(!link||!this.localMarkdownTarget(link.getAttribute('href')))return;
   event.preventDefault();event.stopImmediatePropagation();
   File.editor.tryOpenUrl(link.getAttribute('href'));
  },true);
  const menu=document.getElementById('context-menu');if(!menu)return;
  this.menu=menu;
  const parent=document.createElement('li');
  parent.className='et-markdown-link-context has-extra-menu hide';
  parent.dataset.key='et-copy-markdown-link';
  parent.innerHTML='<a role="menuitem" aria-haspopup="menu" aria-expanded="false" aria-controls="et-markdown-link-menu"><span>复制 Markdown 链接</span><i class="fa fa-caret-right"></i></a>';
  this.parent=parent;this.anchor=parent.firstElementChild;
  const center=menu.querySelector('.et-center-context');
  if(center)center.after(parent);else menu.prepend(parent);
  const submenu=document.createElement('ul');
  submenu.id='et-markdown-link-menu';submenu.className='dropdown-menu context-menu ext-context-menu';submenu.setAttribute('role','menu');
  for(const [mode,label,hint] of [['absolute','绝对链接','复制当前文件的完整路径链接'],['relative','相对链接','以当前文件所在文件夹为基准']]){
   const item=document.createElement('li'),a=document.createElement('a');
   item.dataset.key='et-copy-markdown-'+mode;item.dataset.etLinkMode=mode;
   a.setAttribute('role','menuitem');a.textContent=label;a.title=hint;item.append(a);submenu.append(item);
  }
  document.body.append(submenu);this.submenu=submenu;
  const stop=e=>{e.preventDefault();e.stopPropagation();};
  parent.addEventListener('mousedown',stop);submenu.addEventListener('mousedown',stop);
  // Typora uses jQuery mouseenter/click triggers for keyboard-driven menu actions.
  $(menu).on('mouseenter.etMarkdownLinks','li',e=>{
   if(e.currentTarget.parentElement!==menu)return;
   if(e.currentTarget===parent)this.open();else this.close();
  });
  $(parent).on('click.etMarkdownLinks',e=>{stop(e);this.open();});
  $(submenu).on('click.etMarkdownLinks','[data-et-link-mode]',e=>{
   stop(e);this.copy(e.currentTarget.dataset.etLinkMode);
  });
  document.addEventListener('contextmenu',e=>{
   this.close();this.contextFile=File.bundle?.filePath||'';
   parent.classList.toggle('hide',!document.getElementById('write')?.contains(e.target));
   const enabled=this.available();parent.classList.toggle('disabled',!enabled);
   this.anchor.setAttribute('aria-disabled',String(!enabled));
   this.anchor.title=enabled?'复制当前 Markdown 文件的链接':'请先保存文件，待加载完成后复制链接';
  },true);
  new MutationObserver(()=>{
   if(!menu.classList.contains('show')||!parent.classList.contains('active'))this.close();
  }).observe(menu,{subtree:true,attributes:true,attributeFilter:['class']});
  new MutationObserver(()=>{
   this.anchor.setAttribute('aria-expanded',String(submenu.classList.contains('show')));
  }).observe(submenu,{attributes:true,attributeFilter:['class']});
 }
 installFileLinkCompatibility(){
  const editor=File.editor,original=editor.tryOpenUrl,links=this;
  if(!File.isWin||typeof original!=='function'||original.etFileUrlCompatible)return;
  // Typora 1.14's native file opener removes only two slashes after file: and
  // uses decodeURI, leaving /C:/ and encoded # characters in the OS path.
  // Adapt at the opening boundary; copied/stored Markdown retains standard URIs.
  function open(url,...args){
   const target=links.localMarkdownTarget(url);
   if(target){links.openMarkdownHere(target,original,this);return;}
   return original.call(this,links.nativeFileUrl(url),...args);
  }
  open.etFileUrlCompatible=true;editor.tryOpenUrl=open;
 }
 localMarkdownTarget(value){
  if(typeof value!=='string'||!File.bundle?.filePath)return null;
  const text=value.trim().replace(/^<|>$/g,'');
  if(!text||text.startsWith('#'))return null;
  try{
   const path=reqnode('path');let file,anchor='';
   if(/^file:\/\//i.test(text)){
    const url=new URL(text);if(url.search)return null;
    anchor=url.hash;file=reqnode('url').fileURLToPath(url);
   }else{
    if(/^[a-z][a-z\d+.-]*:/i.test(text)&&!path.isAbsolute(text))return null;
    if(text.includes('?')||File.isTextBundle?.()||File.isTextPack?.())return null;
    // A custom root may change native link resolution; leave that case native.
    if(!path.isAbsolute(text)&&File.editor.docMenu.getLocalRootUrl())return null;
    const split=text.indexOf('#');
    anchor=split<0?'':text.slice(split);
    const name=decodeURIComponent(split<0?text:text.slice(0,split));
    file=path.resolve(path.dirname(File.bundle.filePath),name);
   }
   if(!/\.(md|markdown|mdown)$/i.test(file)||!reqnode('fs').statSync(file).isFile())return null;
   return {file:path.normalize(file),anchor};
  }catch(error){return null;}
 }
 openMarkdownHere(target,original,editor){
  const path=reqnode('path'),same=()=>path.resolve(File.bundle?.filePath||'.').toLowerCase()===target.file.toLowerCase();
  const jump=()=>{
   if(!same()||!target.anchor)return;
   this.toolbar.readingPosition?.cancelRestore();
   original.call(editor,target.anchor);
  };
  if(same()){jump();return;}
  if(File.isFileLoading?.()||File._onFileSwitching)return;
  // Native same-window switching saves/snapshots or asks before leaving a dirty
  // document. Never replace editor contents or bypass its cancellation path.
  this.toolbar.readingPosition?.cancelRestore();
  File.editor.library.openFile(target.file,jump);
 }
 nativeFileUrl(value){
  if(typeof value!=='string')return value;
  const text=value.trim().replace(/^<|>$/g,'');
  try{
   if(!/^file:\/\//i.test(text)){
    // Newly copied relative links address a sibling note. Resolve their encoded
    // filename once; Typora's normal path branch can misread %23 / %25 as anchors.
    // Keep custom root URLs, other relative paths and missing-file prompts native.
    if(!/^\.\/[^/]+$/.test(text)||!/%[\da-f]{2}/i.test(text)||/[?#]/.test(text)||!File.bundle?.filePath||File.editor.docMenu.getLocalRootUrl())return value;
    const path=reqnode('path'),name=decodeURIComponent(text.slice(2));
    if(path.basename(name)!==name)return value;
    const file=path.join(path.dirname(File.bundle.filePath),name);
    return reqnode('fs').existsSync(file)?'file://'+encodeURI(file.replace(/\\/g,'/')):value;
   }
   const url=new URL(text);
   // Keep native fragment/query handling outside this plain-file compatibility fix.
   if(url.hash||url.search)return value;
   const file=reqnode('url').fileURLToPath(url.href).replace(/\\/g,'/');
   // encodeURI keeps a filename's literal # while escaping %, spaces and Unicode;
   // the native opener then decodes exactly once to the original Windows path.
   return 'file://'+encodeURI(file);
  }catch(error){return value;}
 }
 available(){
  return Boolean(this.contextFile&&reqnode('path').isAbsolute(this.contextFile)&&!File.isFileLoading?.());
 }
 open(){
  if(!this.menu.classList.contains('show')||!this.available()||this.contextFile!==(File.bundle?.filePath||''))return;
  this.parent.classList.add('active');this.submenu.classList.add('show');
  const rect=this.parent.getBoundingClientRect(),box=this.submenu.getBoundingClientRect(),gap=4;
  const left=rect.right+box.width+gap<=innerWidth?rect.right+gap:rect.left-box.width-gap;
  this.submenu.style.left=Math.max(gap,Math.min(left,innerWidth-box.width-gap))+'px';
  this.submenu.style.top=Math.max(gap,Math.min(rect.top,innerHeight-box.height-gap))+'px';
 }
 close(){
  this.submenu.classList.remove('show');
  this.submenu.querySelectorAll('.active').forEach(n=>n.classList.remove('active'));
 }
 markdown(file,mode){
  // Numeric entities also work around Typora's escaped-bracket link-label parser.
  const path=reqnode('path'),name=path.basename(file),label=path.parse(file).name.replace(/[&\\`*_{}\[\]<>!~]/g,c=>'&#'+c.charCodeAt(0)+';');
  // A relative link is resolved from the document it is pasted into, not from a library root.
  const url=(mode==='absolute'?reqnode('url').pathToFileURL(file).href:'./'+encodeURIComponent(name)).replace(/[()]/g,c=>'%'+c.charCodeAt(0).toString(16).toUpperCase());
  return '['+label+']('+url+')';
 }
 copy(mode){
  if(!this.available()||this.contextFile!==(File.bundle?.filePath||'')){
   this.close();this.toolbar._showToolbarNotice('请在当前已保存的文件中重新打开右键菜单。');return;
  }
  try{
   reqnode('electron').clipboard.writeText(this.markdown(this.contextFile,mode));
   File.editor.contextMenu.hide();this.close();
   this.toolbar._showToolbarNotice(mode==='absolute'?'已复制 Markdown 绝对链接。':'已复制 Markdown 相对链接（以当前文件所在文件夹为基准）。');
  }catch(error){this.toolbar._showToolbarNotice('复制链接失败，请重试。');}
 }
}
