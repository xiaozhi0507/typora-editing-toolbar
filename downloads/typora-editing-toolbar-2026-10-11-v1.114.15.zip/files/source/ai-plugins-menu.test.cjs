const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {JSDOM}=require('jsdom'),tick=()=>new Promise(r=>setImmediate(r));
function setup(t){
 const dom=new JSDOM('<body><div id="back"><section id="prefs"><div id="skills" hidden></div><div id="plugins"></div></section></div></body>',{runScripts:'outside-only'}),w=dom.window;t.after(()=>w.close());
 w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};w.HTMLDialogElement.prototype.close=function(){this.open=false;this.dispatchEvent(new w.Event('close'));};
 const calls={opens:[],exports:[],notices:[],dialogs:[],previews:[],installs:[]};let picker=async()=>({canceled:true,filePaths:[]});w.reqnode=n=>n==='electron'?{shell:{openPath:async p=>{calls.opens.push(p);return '';}}}:require(n);w.JSBridge={invoke:async(method,args)=>{calls.dialogs.push({method,args});return picker();}};
 const Skills=vm.runInContext(fs.readFileSync(path.join(__dirname,'ai-skills.js'),'utf8')+'\nEditingToolbarAISkills',dom.getInternalVMContext()),Plugins=vm.runInContext(fs.readFileSync(path.join(__dirname,'ai-plugins.js'),'utf8')+'\nEditingToolbarAIPlugins',dom.getInternalVMContext());
 const node=(tag,cls,text)=>{const n=w.document.createElement(tag);if(cls)n.className=cls;if(text)n.textContent=text;return n;},ai={node,bindSurface:()=>{},notice:(...args)=>calls.notices.push(args),preferences:w.document.querySelector('#prefs'),preferencesBackdrop:w.document.querySelector('#back'),toolbar:{}};
 ai.skillsUI=new Skills(ai);ai.skillsUI.panel=w.document.querySelector('#skills');const ui=new Plugins(ai);Object.assign(ui,{panel:w.document.querySelector('#plugins'),list:node('div'),count:node('span'),search:{value:''},errorNode:node('p'),menu:node('div')});ui.panel.append(ui.list,ui.errorNode);ui.errorNode.hidden=true;
 ui.rows=[{id:'github',name:'GitHub',description:'repos'},{id:'local:demo',name:'Demo',description:'test',packageName:'demo'}];ui.store={list:()=>ui.rows,packages:{previews:new Map(),location:async id=>({root:'C:/bundles/'+id.replace(':','-')}),exportZip:async(...args)=>{calls.exports.push(args);return {path:'C:/out/demo.zip',files:2};},preview:async file=>{calls.previews.push(file);const p={token:'preview-'+calls.previews.length,name:'Demo',description:'test',skills:[],files:2,unsupported:[]};ui.store.packages.previews.set(p.token,{});return p;},install:async token=>{calls.installs.push(token);return 'local:demo';}}};ui.details=async()=>{};ui.render();
 return {w,ui,calls,picker:fn=>picker=fn,menu:()=>ai.skillsUI.menu,row:i=>ui.list.children[i],rightClick:i=>ui.list.children[i].dispatchEvent(new w.MouseEvent('contextmenu',{bubbles:true,cancelable:true,clientX:60,clientY:80})),form:()=>w.document.querySelector('dialog'),input:()=>w.document.querySelector('[aria-label="插件压缩包路径"]'),button:text=>[...w.document.querySelectorAll('button')].find(n=>n.getAttribute('aria-label')===text)};
}
test('add menu exposes builtin, creation and upload without marketplace management entries',t=>{
 const f=setup(t),a=f.ui.ai;a.nav=a.node('nav');a.preferencesStatus=a.node('p');a.preferences.append(a.nav,a.preferencesStatus);f.ui.init=async()=>{};f.ui.mount();assert.deepEqual([...f.ui.menu.children].map(b=>b.textContent),['添加内置插件','创建插件','上传插件压缩包']);
});
test('plugin context menu stays open with skills tab hidden, opens correct directory, and closes on tab change',async t=>{
 const f=setup(t);f.rightClick(1);await tick();assert.deepEqual([...f.menu().children].map(n=>n.textContent),['查看目录','一键打包…']);f.menu().children[0].click();await tick();assert.deepEqual(f.calls.opens,['C:/bundles/local-demo']);
 f.row(0).dispatchEvent(new f.w.KeyboardEvent('keydown',{key:'F10',shiftKey:true,bubbles:true,cancelable:true}));assert(f.menu());f.ui.panel.hidden=true;await tick();assert.equal(f.menu(),null);
});
test('plugin export picker cancellation and duplicate clicks write nothing, success stays silent, errors surface',async t=>{
 const f=setup(t);let resolve;f.picker(()=>new Promise(r=>resolve=r));const pending=f.ui.packagePlugin(f.ui.rows[1]);await f.ui.packagePlugin(f.ui.rows[1]);assert.equal(f.calls.dialogs.length,1);resolve({canceled:true});await pending;assert.equal(f.calls.exports.length,0);
 f.picker(async()=>({filePaths:['C:/chosen']}));f.rightClick(1);f.menu().children[1].click();await tick();assert.deepEqual(f.calls.exports,[['local:demo','C:/chosen']]);assert.equal(f.calls.notices.length,0);assert.equal(f.ui.errorNode.hidden,true);assert(!f.row(1).hasAttribute('aria-busy'));
 f.ui.store.packages.exportZip=async()=>{throw Error('磁盘已满');};f.rightClick(1);f.menu().children[1].click();await tick();assert.equal(f.ui.errorNode.textContent,'磁盘已满');assert.equal(f.ui.errorNode.hidden,false);assert(!f.row(1).hasAttribute('aria-busy'));
});
test('inline folder button previews selection and path edits invalidate old install token',async t=>{
 const f=setup(t);f.ui.importDialog();const input=f.input(),browse=f.button('选择插件压缩包');assert.equal(browse.parentNode,input.parentNode);assert(!f.button('读取路径'));
 f.picker(async()=>({filePaths:['C:/demo.zip']}));browse.click();await tick();assert.equal(input.value,'C:/demo.zip');assert.deepEqual(f.calls.previews,['C:/demo.zip']);assert.equal(f.button('添加插件').disabled,false);
 input.value='C:/different.zip';input.dispatchEvent(new f.w.Event('input'));assert.equal(f.button('添加插件').disabled,true);assert.equal(f.ui.store.packages.previews.size,0);assert.equal(f.form().querySelector('.et-plugin-preview').textContent,'');f.button('添加插件').click();await tick();assert.equal(f.calls.installs.length,0);
 input.dispatchEvent(new f.w.KeyboardEvent('keydown',{key:'Enter'}));await tick();assert.deepEqual(f.calls.previews,['C:/demo.zip','C:/different.zip']);f.button('添加插件').click();await tick();assert.deepEqual(f.calls.installs,['preview-2']);
});
test('empty path Enter and canceled browse do not call preview or display filesystem errors',async t=>{
 const f=setup(t);f.ui.importDialog();f.input().value='  ';f.input().dispatchEvent(new f.w.KeyboardEvent('keydown',{key:'Enter'}));await tick();assert.equal(f.calls.previews.length,0);assert(f.form().querySelector('.et-plugin-error').hidden);f.button('选择插件压缩包').click();await tick();assert.equal(f.calls.previews.length,0);assert(f.button('添加插件').disabled);
});
test('closing while native file picker is open ignores its later result',async t=>{
 const f=setup(t);f.ui.importDialog();let resolve;f.picker(()=>new Promise(r=>resolve=r));f.button('选择插件压缩包').click();await tick();f.form().close();resolve({filePaths:['C:/demo.zip']});await tick();assert.equal(f.calls.previews.length,0);
});
test('closing during preview discards the result and leaves no reusable token',async t=>{
 const f=setup(t);f.ui.importDialog();let resolve;f.ui.store.packages.preview=file=>new Promise(r=>resolve=r);f.input().value='C:/demo.zip';f.input().dispatchEvent(new f.w.KeyboardEvent('keydown',{key:'Enter'}));assert(f.input().disabled);f.form().close();f.ui.store.packages.previews.set('late',{});resolve({token:'late',name:'Demo',skills:[],files:2,unsupported:[]});await tick();assert.equal(f.ui.store.packages.previews.size,0);assert.equal(f.calls.installs.length,0);
});

test('empty and searched plugin lists have distinct messages and accurate added counts',t=>{
 const f=setup(t);f.ui.rows=[];f.ui.render();assert.equal(f.ui.count.textContent,'0');assert.match(f.ui.list.textContent,/尚未添加插件/);assert.equal(f.ui.list.querySelectorAll('[data-plugin]').length,0);
 f.ui.rows=[{id:'github',name:'GitHub'}];f.ui.search.value='absent';f.ui.render();assert.equal(f.ui.count.textContent,'1');assert.match(f.ui.count.getAttribute('aria-label'),/已添加/);assert.equal(f.ui.list.textContent,'没有匹配的插件');
});
test('browsing or closing builtin catalog does not add cards; choosing a plugin adds only it and opens details once',async t=>{
 const f=setup(t),catalog=[{id:'github',name:'GitHub',description:'Repos'},{id:'data',name:'Data',description:'Skills'}],added=[],details=[];f.ui.rows=[];f.ui.init=async()=>{};f.ui.store.list=all=>all?catalog:added;f.ui.store.addBuiltin=async id=>{added.push({...catalog.find(p=>p.id===id),enabled:false});};f.ui.details=async id=>details.push(id);
 await f.ui.builtinDialog();assert.equal(added.length,0);f.button('关闭添加内置插件').click();assert.equal(added.length,0);assert.equal(details.length,0);
 await f.ui.builtinDialog();const add=f.button('添加 GitHub');add.click();add.click();await tick();assert.deepEqual(added.map(p=>p.id),['github']);assert.deepEqual(details,['github']);assert.equal(f.ui.count.textContent,'1');assert.equal(added[0].enabled,false);
 await f.ui.builtinDialog();assert.equal(f.button('添加 GitHub').disabled,true);assert.equal(f.button('添加 Data').disabled,false);
});
test('builtin add failure remains in catalog with a retryable action and no phantom card',async t=>{
 const f=setup(t);f.ui.rows=[];f.ui.init=async()=>{};f.ui.store.list=all=>all?[{id:'github',name:'GitHub'}]:[];f.ui.store.addBuiltin=async()=>{throw Error('磁盘已满');};await f.ui.builtinDialog();f.button('添加 GitHub').click();await tick();assert.match(f.form().querySelector('.et-plugin-error').textContent,/磁盘已满/);assert.equal(f.button('添加 GitHub').disabled,false);assert.equal(f.ui.rows.length,0);
});
