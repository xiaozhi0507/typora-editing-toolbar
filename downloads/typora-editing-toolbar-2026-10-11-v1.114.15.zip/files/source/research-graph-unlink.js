import MarkdownIt from 'markdown-it';
import linkRule from 'markdown-it/lib/rules_inline/link.mjs';
import htmlRule from 'markdown-it/lib/rules_inline/html_inline.mjs';
import autoLinkRule from 'markdown-it/lib/rules_inline/autolink.mjs';
const parser=new MarkdownIt({html:true,linkify:false});
const validate=parser.validateLink;parser.validateLink=url=>/^file:/i.test(url)||validate(url);
const capture=state=>state.env.graphCapture?.text===state.src?state.env.graphCapture:null;
parser.inline.ruler.at('autolink',(state,silent)=>{
 const start=state.pos,before=state.tokens.length;if(!autoLinkRule(state,silent))return false;const c=capture(state),open=state.tokens.slice(before).find(t=>t.type==='link_open');
 if(!silent&&c&&open&&c.matches(open.attrGet('href')))c.edits.push({start,end:state.pos,text:state.src.slice(start+1,state.pos-1)});return true;
});
parser.inline.ruler.at('link',(state,silent)=>{
 const start=state.pos,labelEnd=state.src[start]==='['?state.md.helpers.parseLinkLabel(state,start,true):-1,before=state.tokens.length;
 if(!linkRule(state,silent))return false;
 const c=capture(state),open=state.tokens.slice(before).find(t=>t.type==='link_open');
 if(!silent&&c&&open&&c.matches(open.attrGet('href')))c.edits.push({start,end:state.pos,text:state.src.slice(start+1,labelEnd)});
 return true;
});
parser.inline.ruler.before('link','graph_wiki',(state,silent)=>{
 const start=state.pos,embed=state.src.startsWith('![[',start),offset=embed?3:2;
 if(!embed&&!state.src.startsWith('[[',start))return false;
 const end=state.src.indexOf(']]',start+offset);if(end<0)return false;
 const inner=state.src.slice(start+offset,end);if(!inner||inner.includes('\n'))return false;
 const split=inner.indexOf('|'),target=(split<0?inner:inner.slice(0,split)).trim(),label=split<0?inner:inner.slice(split+1);
 if(!silent){const c=capture(state);if(c&&c.matches(target))c.edits.push({start,end:end+2,text:label});state.push('text','',0).content=state.src.slice(start,end+2);}
 state.pos=end+2;return true;
});
parser.inline.ruler.before('escape','graph_math',(state,silent)=>{
 if(state.src[state.pos]!=='$')return false;const start=state.pos,mark=state.src.startsWith('$$',start)?'$$':'$';let end=start+mark.length;
 while((end=state.src.indexOf(mark,end))>=0){if(state.src[end-1]!=='\\')break;end+=mark.length;}
 if(end<0)return false;if(!silent)state.push('text','',0).content=state.src.slice(start,end+mark.length);state.pos=end+mark.length;return true;
});
parser.inline.ruler.at('html_inline',(state,silent)=>{
 const start=state.pos;if(!htmlRule(state,silent))return false;const c=capture(state);if(!silent&&c){const tag=state.src.slice(start,state.pos);
  if(/^<a\b/i.test(tag)){const match=/\bhref\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i.exec(tag);c.html.push({start,end:state.pos,match:match&&c.matches(parser.utils.unescapeAll(match[1]??match[2]??match[3]))});}
  else if(/^<\/a\s*>/i.test(tag)){const open=c.html.pop();if(open?.match)c.edits.push({start:open.start,end:state.pos,text:state.src.slice(open.end,start)});}
 }return true;
});

export function linkEnvironment(markdown){const env={};parser.parse(markdown,env);return{references:env.references||{}};}
export function unlinkInline(text,matches,environment={}){
 const c={text,matches,edits:[],html:[]};parser.parseInline(text,{...environment,graphCapture:c});
 const edits=c.edits.sort((a,b)=>a.start-b.start||b.end-a.end).filter((e,i,all)=>!all.slice(0,i).some(p=>p.start<=e.start&&p.end>=e.end));
 let next='',at=0;for(const e of edits){if(e.start<at)throw Error('链接范围重叠');next+=text.slice(at,e.start)+e.text;at=e.end;}next+=text.slice(at);
 return{text:next,count:edits.length,mapOffset(offset){let delta=0;for(const e of edits){if(offset<e.start)break;if(offset<=e.end)return e.start+delta+Math.min(offset-e.start,e.text.length);delta+=e.text.length-(e.end-e.start);}return offset+delta;}};
}
export function fileLinkKey(target,path){const resolved=path.resolve(target);return(resolved+(path.extname(resolved)?'':'.md')).replace(/\\/g,'/').toLowerCase();}
export function linkPath(raw,file,path){
 let target=String(raw||'').split('#')[0].split('?')[0].trim();if(!target)return null;
 if(/^file:/i.test(target)){try{const url=new URL(target);target=url.hostname?'//'+url.hostname+decodeURIComponent(url.pathname):decodeURIComponent(url.pathname).replace(/^\/([a-z]:)/i,'$1');}catch{return null;}}
 else{try{target=decodeURIComponent(target);}catch{}if(/^[a-z][\w+.-]*:/i.test(target)&&!path.isAbsolute(target))return null;}
 return fileLinkKey(path.resolve(path.dirname(file),target),path);
}

export class GraphLinkRemoval {
 constructor(sidebar){this.sidebar=sidebar;}
 enabled(){return !File.editor.sourceView?.inSourceMode&&!File.isLocked&&!File.bundle?.isLocked&&!File.isReadonlyMode&&!File.isFileLoading?.();}
 plan(target){
  const file=File.bundle?.filePath;if(!file||!target?.path||target.exists||!this.enabled())return null;
  const editor=File.editor,path=this.sidebar.path,goal=fileLinkKey(target.path,path),env=linkEnvironment(editor.getMarkdown()),changes=new Map(),roots=new Map();let count=0;
  for(const block of document.querySelectorAll('#write p[cid],#write h1[cid],#write h2[cid],#write h3[cid],#write h4[cid],#write h5[cid],#write h6[cid],#write .td-span[cid]')){
   if(block.closest('pre,.md-fences,.md-math-block'))continue;const node=editor.getNode(block.getAttribute('cid')),text=node?.get('text');if(typeof text!=='string')continue;
   const change=unlinkInline(text,raw=>linkPath(raw,file,path)===goal,env);if(!change.count)continue;
   if(block.rawText?.(true)!==text)throw Error('正文正在更新，请稍后重试');changes.set(node.cid,change);count+=change.count;
   let root=node;while(['table_row','table'].includes(root.get('parent')?.get('type')))root=root.get('parent');roots.set(root.cid,root);
  }return{file,changes,roots,count};
 }
 async remove(target,expectedFile){
  const sidebar=this.sidebar,file=File.bundle?.filePath;if(!target?.path||target.exists||file!==expectedFile||sidebar.file!==file||!this.enabled())return sidebar.notify('文档已切换或不可编辑，请重新右键操作。');
  const candidates=[target.path,...(!sidebar.path.extname(target.path)?[target.path+'.md',target.path+'.markdown']:[])];
  for(const candidate of candidates){try{await sidebar.fs.promises.stat(candidate);sidebar.refresh();return sidebar.notify('目标文件现在已存在，未移除链接。');}catch(e){if(e.code!=='ENOENT'&&e.code!=='ENOTDIR')throw e;}}
  if(File.bundle?.filePath!==file||!this.enabled())return;
  const editor=File.editor;editor.undo.endSnap(true);const plan=this.plan(target);if(!plan?.count)return sidebar.notify('当前正文中没有可直接移除的链接，可选择“从图谱隐藏”。');
  const cursor=editor.selection.buildUndo(),command={undo:cursor?[cursor]:[],redo:[]},scroll=document.querySelector('content'),top=scroll?.scrollTop;
  const transform=json=>{const change=plan.changes.get(json.id);if(change)json.content.text=change.text;if(json.content.type==='table')delete json.content.userText;for(const child of json.children||[])transform(child);return json;};
  sidebar.toolbar.readingPosition?.cancelRestore();editor.brush.pause(true);
  try{
   for(const root of plan.roots.values()){const redo={type:'replace',id:root.cid,json:transform(JSON.parse(JSON.stringify(root.storeToJson())))};command.undo.push(editor.undo.buildReplaceUndo(root));editor.undo.exeCommand(redo);command.redo.push(redo);}
   if(cursor){const mapped={...cursor};for(const [field,id]of [['start',cursor.startId||cursor.id],['end',cursor.endId||cursor.id]])if(plan.changes.has(id)&&Number.isFinite(mapped[field]))mapped[field]=plan.changes.get(id).mapOffset(mapped[field]);editor.undo.exeCommand(mapped);command.redo.push(mapped);}
   editor.undo.register(command);editor.refresh();sidebar.toolbar.tableColumns?.scan();if(scroll)scroll.scrollTop=top;
   sidebar.refresh();sidebar.notify('已移除当前文档中的 '+plan.count+' 处失效链接，文字已保留；Ctrl+Z 可撤销。');
  }catch(error){for(const undo of command.undo.slice().reverse())editor.undo.exeCommand(undo);editor.refresh();sidebar.refresh();throw error;}
  finally{editor.brush.resume();}
 }
}
