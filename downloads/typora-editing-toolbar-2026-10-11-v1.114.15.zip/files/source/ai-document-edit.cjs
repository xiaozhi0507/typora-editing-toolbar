'use strict';
// Document editing needs real image/layout HTML; ordinary answer insertion keeps
// its stricter text-only policy. Preserve validated tags byte-for-byte.
class AIDocumentEditMarkup {
  static decode(value){return value.replace(/&(?:#(\d+)|#x([\da-f]+)|(amp|quot|apos|lt|gt|colon|tab|newline));?/gi,(all,decimal,hex,name)=>{
    if(name)return {amp:'&',quot:'"',apos:"'",lt:'<',gt:'>',colon:':',tab:'\t',newline:'\n'}[name.toLowerCase()];
    const code=parseInt(decimal||hex,decimal?10:16);return code>0&&code<=0x10ffff?String.fromCodePoint(code):'\0';
  });}
  static imageSource(raw){
    const value=this.decode(raw).trim();
    if(!value||/[\x00-\x1f\x7f<>]/.test(value)||/&(?:#\w+|[a-z]+);/i.test(value)||/^[\\/]{2}/.test(value))return false;
    if(/^data:/i.test(value))return /^data:image\/(?:png|jpe?g|gif|webp|avif|bmp);base64,[a-z\d+/=\s]+$/i.test(value);
    if(/^file:/i.test(value))return /^file:\/\/\/[a-z]:\//i.test(value);
    return !/^[a-z][a-z\d+.-]*:/i.test(value)||/^https?:\/\/[^/\s]/i.test(value)||/^[a-z]:[\\/]/i.test(value);
  }
  static style(raw){
    const number='(?:\\d+(?:\\.\\d+)?|\\.\\d+)',length='(?:0|'+number+'(?:px|%|em|rem|vw|vh))';
    return this.decode(raw).split(';').every(part=>{
      if(!part.trim())return true;const match=part.trim().match(/^([a-z-]+)\s*:\s*(.*?)\s*$/i);if(!match)return false;
      const key=match[1].toLowerCase(),value=match[2].toLowerCase();
      if(key==='zoom')return new RegExp('^'+number+'%?$').test(value)&&parseFloat(value)>0;
      if(/^(?:(?:min|max)-)?(?:width|height)$/.test(key))return new RegExp('^(?:auto|'+length+')$').test(value);
      if(/^(?:margin|padding)(?:-(?:left|right|top|bottom))?$/.test(key))return value.split(/\s+/).length<=4&&value.split(/\s+/).every(v=>new RegExp('^(?:auto|'+length+')$').test(v));
      if(key==='display')return /^(?:block|inline|inline-block)$/.test(value);
      if(key==='text-align')return /^(?:left|right|center|justify)$/.test(value);
      if(key==='vertical-align')return /^(?:top|middle|bottom|baseline|text-top|text-bottom)$/.test(value);
      if(key==='float')return /^(?:left|right|none)$/.test(value);
      return false;
    });
  }
  static tag(token){
    const match=token.match(/^<(\/?)([a-z][a-z\d]*)([\s\S]*?)>$/i);if(!match)return false;
    const name=match[2].toLowerCase(),containers=['p','div','span','center','sup','sub','strong','em','b','i','u','s','del','mark','small','code','kbd'];
    if(!['img','br','hr',...containers].includes(name))return false;
    if(match[1])return containers.includes(name)&&!match[3].trim();
    const tail=match[3].replace(/\s*\/\s*$/,''),attrs=new Map(),pattern=/\s+([a-z][\w:-]*)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+))/iy;let at=0;
    while(at<tail.length){if(!tail.slice(at).trim())break;pattern.lastIndex=at;const a=pattern.exec(tail);if(!a)return false;at=pattern.lastIndex;const key=a[1].toLowerCase(),value=a[2]??a[3]??a[4];if(attrs.has(key))return false;attrs.set(key,value);}
    for(const [key,value]of attrs){
      if(['alt','title'].includes(key))continue;
      if(key==='src'&&name==='img'){if(!this.imageSource(value))return false;continue;}
      if(['width','height'].includes(key)&&name==='img'){if(!/^\d+(?:\.\d+)?(?:px|%)?$/i.test(this.decode(value)))return false;continue;}
      if(key==='align'){if(!/^(?:left|right|center|middle|top|bottom)$/i.test(this.decode(value)))return false;continue;}
      if(key==='style'){if(!this.style(value))return false;continue;}
      return false;
    }
    return name!=='img'||attrs.has('src');
  }
  static sanitize(value){
    const text=String(value);let out='',at=0,fence=null;
    while(at<text.length){
      if(at===0||text[at-1]==='\n'){
        const end=text.indexOf('\n',at),line=text.slice(at,end<0?text.length:end);let marker=line.match(/^ {0,3}(`{3,}|~{3,})(.*)$/);if(marker&&!fence&&marker[1][0]==='`'&&marker[2].includes('`'))marker=null;
        if(fence||marker){
          if(marker){if(!fence)fence=marker[1];else if(marker[1][0]===fence[0]&&marker[1].length>=fence.length&&!marker[2].trim())fence=null;}
          const next=end<0?text.length:end+1;out+=text.slice(at,next);at=next;continue;
        }
      }
      // Literal Markdown code and math are not HTML. Match complete delimiters.
      let delimiter=null,close=null,slashes=0;if(text[at]==='`'||text[at]==='$'||text.startsWith('\\(',at)||text.startsWith('\\[',at))for(let i=at-1;i>=0&&text[i]==='\\';i--)slashes++;const escaped=slashes%2!==0;
      if(!escaped&&text[at]==='`'){delimiter=text.slice(at).match(/^`+/)[0];close=delimiter;}
      else if(!escaped&&(text.startsWith('\\(',at)||text.startsWith('\\[',at))){delimiter=text.slice(at,at+2);close=delimiter==='\\('? '\\)':'\\]';}
      else if(!escaped&&text[at]==='$'){delimiter=text.startsWith('$$',at)?'$$':'$';close=delimiter;}
      if(delimiter){
        let end=text.indexOf(close,at+delimiter.length);
        if(delimiter[0]==='`')while(end>=0&&(text[end-1]==='`'||text[end+close.length]==='`'))end=text.indexOf(close,end+close.length);
        if(end>=0&&(delimiter!=='$'||!text.slice(at,end).includes('\n'))){out+=text.slice(at,end+close.length);at=end+close.length;continue;}
      }
      if(text[at]==='<'&&/^[a-z!/?]/i.test(text[at+1]||'')){
        let quote='',end=at+1;for(;end<text.length;end++){const ch=text[end];if(quote){if(ch===quote)quote='';}else if(ch==='"'||ch==="'")quote=ch;else if(ch==='>')break;}
        if(end<text.length){const token=text.slice(at,end+1);out+=this.tag(token)?token:token.replace(/</g,'&lt;');at=end+1;continue;}
        out+=text.slice(at).replace(/</g,'&lt;');break;
      }
      out+=text[at++];
    }
    return out;
  }
}
class AIDocumentEdit {
  static markdown(text){return AIDocumentEditMarkup.sanitize(text);}
  static apply(before,args,sanitize=s=>s){
    if(!args||typeof args.summary!=='string'||!Array.isArray(args.edits)||!args.edits.length||args.edits.length>32)throw Error('编辑指令格式不正确，需提供说明和 1–32 处修改');
    const spans=args.edits.map(e=>{
      if(!e||typeof e.old_text!=='string'||typeof e.new_text!=='string')throw Error('替换内容必须是文本');
      if(e.old_text===''){if(before.trim())throw Error('非空文档必须提供准确原文');return{start:0,end:before.length,text:sanitize(e.new_text)};}
      const start=before.indexOf(e.old_text);if(start<0)throw Error('未找到要替换的原文，请从当前文档逐字复制');
      if(before.indexOf(e.old_text,start+1)>=0)throw Error('原文出现多次，请增加上下文以确定唯一位置');
      return{start,end:start+e.old_text.length,text:sanitize(e.new_text)};
    }).sort((a,b)=>a.start-b.start);
    for(let i=1;i<spans.length;i++)if(spans[i].start<spans[i-1].end||spans[i].start===spans[i-1].start)throw Error('修改范围重叠，请合并为一处替换');
    let after=before;for(const e of [...spans].reverse())after=after.slice(0,e.start)+e.text+after.slice(e.end);
    if(after.length>100000)throw Error('修改后的文档超过 10 万字符，请缩小修改范围');
    return after;
  }
  static lines(text){const rows=text.split('\n');if(rows.at(-1)==='')rows.pop();return rows;}
  static diff(before,after){
    const a=this.lines(before),b=this.lines(after),n=a.length,m=b.length,trace=[],v=new Map([[1,0]]);let work=0;
    for(let d=0;d<=n+m;d++){
      trace.push(new Map(v));
      for(let k=-d;k<=d;k+=2){
        if(++work>1000000)return this.number([...a.map(text=>({type:'delete',text})),...b.map(text=>({type:'add',text}))]);
        let x=k===-d||k!==d&&(v.get(k-1)??-1)<(v.get(k+1)??-1)?v.get(k+1)||0:(v.get(k-1)||0)+1,y=x-k;
        while(x<n&&y<m&&a[x]===b[y]){x++;y++;}v.set(k,x);
        if(x>=n&&y>=m){const rows=[];for(let depth=d;depth>=0;depth--){const prev=trace[depth],key=x-y,pk=key===-depth||key!==depth&&(prev.get(key-1)??-1)<(prev.get(key+1)??-1)?key+1:key-1,px=prev.get(pk)||0,py=px-pk;while(x>px&&y>py){rows.push({type:'same',text:a[--x]});y--;}if(depth){if(x===px)rows.push({type:'add',text:b[--y]});else rows.push({type:'delete',text:a[--x]});}}return this.number(rows.reverse());}
      }
    }
  }
  static number(rows){let old=0,next=0;return rows.map(r=>({...r,old:r.type==='add'?null:++old,next:r.type==='delete'?null:++next}));}
  static hunks(rows){const visible=new Set();rows.forEach((r,i)=>{if(r.type!=='same')for(let j=Math.max(0,i-3);j<=Math.min(rows.length-1,i+3);j++)visible.add(j);});const out=[];let previous=-1;for(const i of [...visible].sort((a,b)=>a-b)){if(i>previous+1)out.push({type:'gap',text:'⋯'});out.push(rows[i]);previous=i;}return out;}
}
module.exports=AIDocumentEdit;
