'use strict';
// Classify documents using managed copies, while keeping the source intact.
class KnowledgeLibraryQuickFile {
  constructor(store, { Importer = require('./knowledge-library-import.cjs'), Metadata = require('./knowledge-library-metadata.cjs'), Managed = require('./knowledge-library-managed.cjs') } = {}) {
    this.store = store; this.Importer = Importer; this.Metadata = Metadata;
    this.importer = new Importer(store); this.metadata = new Metadata(store);
    this.managed = new Managed(store);
  }
  async fileKey(file) {
    if (typeof file !== 'string' || !this.store.path.isAbsolute(file) || !this.importer.markdown(file)) throw new Error('请先保存当前 Markdown，再将它加入知识库。');
    if (!(await this.store.io.stat(file)).isFile()) throw new Error('当前 Markdown 文件不存在。');
    return this.importer.key(file);
  }
  async findItem(data, key) {
    const matches = [];
    for (const item of data?.items || []) {
      for (const file of item.files) {
        if (file.linkType === 'url') continue;
        const target = this.store.resolveFile(file);
        if (this.importer.markdown(target) && (await this.importer.key(target) === key || file.sourcePath && await this.importer.key(file.sourcePath) === key)) { matches.push(item); break; }
      }
    }
    const active = matches.filter(item => !item.deleted);
    if (active.length > 1) throw new Error('当前文件关联了多个条目，请在知识库中选择要调整的条目。');
    if (!active.length && matches.length) throw new Error('当前文件的条目已在回收站，请先恢复条目。');
    return active[0] || null;
  }
  async inspect(file) {
    const key = await this.fileKey(file), result = await this.store.read();
    return { file, key, data: result?.data || null, item: await this.findItem(result?.data, key), warning: result?.warning || '' };
  }
  async assign(snapshot, target, mode, isCurrent = () => true) {
    const checkCurrent = () => { if (!isCurrent()) throw new Error('当前文档或知识库已切换，请重新右键选择。'); };
    checkCurrent();
    if (!['add', 'move'].includes(mode)) throw new Error('未知分类操作。');
    const current = await this.inspect(snapshot.file);
    if (current.key !== snapshot.key || snapshot.data && current.data?.libraryId !== snapshot.data.libraryId) throw new Error('文档或知识库已被替换，请重新右键选择。');
    const data = current.data || (await this.store.open()).data;
    const collection = data.collections.find(c => c.id === target);
    if (target && !collection) throw new Error('目标文件夹已不存在，请重新选择。');
    const next = this.store.constructor.clone(data); let item = current.item && next.items.find(i => i.id === current.item.id), warnings = [];
    const created = !item;let prepared;
    if (!item) {
      const file = prepared = await this.managed.prepare(this.store.fileRef(snapshot.file, 'Markdown'));
      item = { id: this.store.crypto.randomUUID(), type: 'paper', title: this.store.path.basename(snapshot.file, this.store.path.extname(snapshot.file)), author: '', year: '', summary: '', tags: [], status: 'unread', star: false, related: [], collections: [], files: [file], defaultFile: file.id, added: new Date().toISOString(), last: 0 };
      try { const record = await this.metadata.readFile(file); if (record) { item = this.Metadata.apply(item, record); warnings = record.warnings || []; } }
      catch (error) { warnings.push(error.message); }
      next.items.push(item);
    }
    item.collections = mode === 'move' ? (target ? [target] : []) : [...new Set([...item.collections, ...(target ? [target] : [])])];
    let saved;try{checkCurrent();
    saved = await this.store.commit(data, next, async live => {
      checkCurrent();
      if (await this.fileKey(snapshot.file) !== snapshot.key) throw new Error('当前文档已变化，请重新右键选择。');
      if (target && !live.collections.some(c => c.id === target)) throw new Error('目标文件夹已不存在，请重新选择。');
      const owner = await this.findItem(live, snapshot.key);
      if ((owner?.id || null) !== (current.item?.id || null)) throw new Error('当前文件的文库条目已变化，请重新右键选择。');
      checkCurrent();
    });}catch(error){if(prepared)await this.managed.rollback([prepared]);throw error;}
    return { saved, itemID: item.id, created, changed: saved.revision !== data.revision, collectionName: collection?.name || '我的文库', warningCount: warnings.length };
  }
}
module.exports = KnowledgeLibraryQuickFile;
