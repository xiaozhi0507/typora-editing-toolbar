// Transfer newly created shell-open windows only after an older editor accepts the file.
// The native editor owns Save / Discard / Cancel; this never clears a dirty flag.
class EditingToolbarDocumentOpenRouter {
  constructor(manager){
    this.manager=manager;this.id=reqnode('crypto').randomUUID();this.started=performance.timeOrigin;this.focused=document.hasFocus()?Date.now():0;this.intentsKey='et-document-window-intents-v1';this.queue=[];this.handled=new Set();
    const profile=reqnode('crypto').createHash('sha256').update(String(File.option.userDataPath)).digest('hex');
    this.channel=new BroadcastChannel('et-document-open-v1:'+profile);this.channel.onmessage=e=>this.receive(e.data);
    try{this.localOpen=new EditingToolbarDocumentOpenPipe(this);}catch(error){console.warn('[EditingToolbar] Direct open unavailable:',error.message);}
    window.addEventListener('focus',()=>{this.focused=Date.now();this.localOpen?.publish();});window.addEventListener('unload',()=>this.dispose(),{once:true});
    setTimeout(()=>void this.start().catch(()=>{this.outgoing=null;}),250);
  }
  post(type,data={}){if(!this.disposed)this.channel.postMessage({version:1,type,from:this.id,started:this.started,...data});}
  pause(ms){return new Promise(resolve=>setTimeout(resolve,ms));}
  loading(){return !!File.isFileLoading?.()||!!this.manager.toolbar.readingPosition?.loading();}
  current(){return this.manager.key(File.bundle?.filePath);}
  fingerprint(){const e=File.editor;return reqnode('crypto').createHash('sha256').update(String(e.sourceView?.inSourceMode?e.sourceView.cm.getValue():e.getMarkdown())).digest('hex');}
  safeSource(snapshot){return !this.disposed&&!this.loading()&&!File.isDocumentEdited?.()&&this.current()===snapshot.key&&this.fingerprint()===snapshot.fingerprint;}
  intents(){let rows;try{rows=JSON.parse(localStorage.getItem(this.intentsKey));}catch{}return(Array.isArray(rows)?rows:[]).filter(r=>typeof r.key==='string'&&Number.isFinite(r.expires)&&r.expires>Date.now()).slice(-40);}
  allowNewWindow(file){if(!this.manager.supported(file))return;try{const rows=this.intents();rows.push({key:this.manager.key(file),expires:Date.now()+15000});localStorage.setItem(this.intentsKey,JSON.stringify(rows));}catch{}}
  consumeIntent(key){try{const rows=this.intents(),i=rows.findIndex(r=>r.key===key);if(i<0)return false;rows.splice(i,1);localStorage.setItem(this.intentsKey,JSON.stringify(rows));return true;}catch{return false;}}
  older(message){return Number.isFinite(message.started)&&(message.started<this.started||message.started===this.started&&message.from<this.id);}
  static choose(offers){return [...offers].sort((a,b)=>Number(b.current)-Number(a.current)||Number(b.hasTab)-Number(a.hasTab)||b.focused-a.focused||a.started-b.started||a.from.localeCompare(b.from))[0];}
  async start(){
    const deadline=Date.now()+20000;while(this.loading()&&Date.now()<deadline&&!this.disposed)await this.pause(100);
    if(this.disposed||this.loading())return;
    const file=File.bundle?.filePath;if(!this.manager.supported(file)||File.isDocumentEdited?.())return;
    const snapshot={key:this.current(),fingerprint:this.fingerprint()};if(this.consumeIntent(snapshot.key))return;
    const request=this.outgoing={id:reqnode('crypto').randomUUID(),file,snapshot,offers:new Map(),waiting:new Set()};
    // Only newer windows retry while older renderers finish startup. The oldest
    // becomes available first, so simultaneous opens cannot all wait on one another.
    for(let attempt=0;attempt<4&&!request.offers.size;attempt++){this.post('probe',{request:request.id,file});await this.pause(attempt?750:450);if(!this.safeSource(snapshot)){this.outgoing=null;return;}if(!request.waiting.size)break;}
    const target=EditingToolbarDocumentOpenRouter.choose(request.offers.values());if(!target){this.outgoing=null;return;}
    request.target=target.from;
    this.post('transfer',{request:request.id,to:target.from,file});
    request.timer=setTimeout(()=>{if(this.outgoing===request)this.outgoing=null;},45000);
  }
  receive(message){
    if(this.disposed||!message||message.version!==1||message.from===this.id||typeof message.from!=='string'||typeof message.request!=='string'||!Number.isFinite(message.started))return;
    if(message.to&&message.to!==this.id)return;
    if(message.type==='probe'){
      if(!this.manager.supported(message.file)||!(message.started>this.started||message.started===this.started&&message.from>this.id))return;
      if(this.outgoing||this.loading()){this.post('waiting',{to:message.from,request:message.request});return;}
      const key=this.manager.key(message.file);this.post('offer',{to:message.from,request:message.request,current:this.current()===key,hasTab:this.manager.tabs.some(t=>this.manager.key(t.path)===key),focused:this.focused});
    }else if(message.type==='waiting'){
      const request=this.outgoing;if(request&&request.id===message.request&&this.older(message))request.waiting.add(message.from);
    }else if(message.type==='offer'){
      const request=this.outgoing;if(!request||request.id!==message.request||request.target||!this.older(message)||!Number.isFinite(message.focused))return;request.offers.set(message.from,message);
    }else if(message.type==='transfer'){
      if(!message.to||this.outgoing||!this.manager.supported(message.file)||message.started<this.started||this.handled.has(message.request))return;
      this.handled.add(message.request);if(this.handled.size>200)this.handled.delete(this.handled.values().next().value);this.queue.push(message);void this.drain();
    }else if(message.type==='result'){
      const request=this.outgoing;if(!request||request.id!==message.request||request.target!==message.from)return;
      clearTimeout(request.timer);this.outgoing=null;if(message.ok&&this.safeSource(request.snapshot))void JSBridge.invoke('window.close').catch(()=>{});
    }
  }
  async focus(){try{if(await JSBridge.invoke('window.isMinimized'))await JSBridge.invoke('window.restore');await JSBridge.invoke('window.focus');}catch{window.focus();}}
  async drain(){
    if(this.draining)return;this.draining=true;
    try{while(this.queue.length&&!this.disposed){const request=this.queue.shift();let ok=false;try{ok=await this.open(request.file);}catch{}if(!request.local)this.post('result',{to:request.from,request:request.request,ok});}}
    finally{this.draining=false;}
  }
  async open(file){
    const m=this.manager,key=m.key(file),deadline=Date.now()+30000;
    while((m.pending||this.loading())&&!this.disposed&&Date.now()<deadline)await this.pause(100);
    if(this.disposed||m.pending||this.loading()||!(await m.fs.promises.stat(file)).isFile())return false;
    await this.focus();if(this.current()===key){m.setFilter('all');m.sync();return true;}
    await m.activate(file);
    while(!this.disposed&&Date.now()<deadline){
      if(!this.loading()&&this.current()===key){m.setFilter('all');m.sync();return m.tabs.some(t=>m.key(t.path)===key);}
      if(!m.pending&&!this.loading())return false;
      await this.pause(100);
    }
    return false;
  }
  dispose(){this.disposed=true;this.localOpen?.dispose();clearTimeout(this.outgoing?.timer);this.channel.close();}
}
