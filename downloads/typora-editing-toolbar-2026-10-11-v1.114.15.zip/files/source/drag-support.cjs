'use strict';
// Geometry and input ownership stay in each controller. This helper adds no listeners.
module.exports={
 version:1,
 frame(paint,request,cancel){
  let pending=0;
  return {
   queue(){if(!pending)pending=request(()=>{pending=0;paint();});},
   cancel(){if(pending){cancel(pending);pending=0;}}
  };
 },
 shield(document,className){
  const node=document.createElement('div');node.className=className;
  node.setAttribute('aria-hidden','true');node.tabIndex=-1;document.body.append(node);return node;
 }
};
