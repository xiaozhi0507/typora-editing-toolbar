const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {JSDOM}=require('jsdom'),bundle=require('esbuild').buildSync({entryPoints:[path.join(__dirname,'annotation-live-editor.js')],bundle:true,format:'iife',globalName:'Editor',platform:'browser',write:false}).outputFiles[0].text;
function renderer(){const w=new JSDOM('<div id="preview"></div>',{runScripts:'outside-only',pretendToBeVisual:true}).window;w.eval(bundle);return {w,host:w.document.getElementById('preview'),render:(md,o={})=>w.Editor.renderPreview(w.document.getElementById('preview'),md,{documentHTML:true,imageURL:s=>'file:///safe/'+encodeURIComponent(s),...o})};}
test('document preview rebuilds HTML images and scale without attaching arbitrary HTML attributes; code stays literal',()=>{
 const {w,host,render}=renderer();render('<span style="text-align:center"><IMG alt="图一" src="_assets/图 1.jpg" style="zoom:25%;position:fixed;background:url(https://bad.test)" onerror="bad()"></span>\n\n`<img src="code.png">`\n\n```html\n<img src="fenced.png">\n```\n\n<script>bad()</script>');
 const img=host.querySelector('img');assert.equal(host.querySelectorAll('img').length,1);assert.equal(img.alt,'图一');assert.match(img.src,/_assets/);Object.defineProperty(img,'naturalWidth',{value:800});img.dispatchEvent(new w.Event('load'));assert.equal(img.style.width,'200px');assert.equal(host.querySelector('[onerror],script,iframe'),null);assert.equal(img.style.position,'');assert.equal(img.style.background,'');assert.match(host.querySelector('pre').textContent,/fenced.png/);w.close();
});
test('inert image vocabulary is opt-in and changing document context rebinds identical relative image paths',()=>{
 const {w,host,render}=renderer(),md='<img src="same.png" width="240" height="120">';
 render(md,{contextKey:'a',imageURL:s=>'file:///a/'+s});assert.equal(host.querySelector('img').style.width,'240px');const first=host.querySelector('img');render(md,{contextKey:'b',imageURL:s=>'file:///b/'+s});assert.notEqual(host.querySelector('img'),first);assert.equal(host.querySelector('img').src,'file:///b/same.png');
 w.Editor.renderPreview(host,md,{});assert.equal(host.querySelector('img'),null);assert.match(host.textContent,/<img/);w.close();
});
test('empty anchor IDs remain pane-local data, and local links can opt into pane navigation',()=>{
 const {w,host,render}=renderer();render('<a id="ref-1" onclick="bad()"></a>Reference\n\n[Figure](#fig-1)',{decorateLink:(a,url)=>{a.setAttribute('href',url);return true;}});
 assert.equal(host.querySelector('[data-preview-anchor]').dataset.previewAnchor,'ref-1');assert.equal(host.querySelector('[id], [onclick]'),null);assert.equal(host.querySelector('a').getAttribute('href'),'#fig-1');w.close();
});
test('document table line breaks render as breaks while inline code preserves the literal HTML',()=>{
 const {w,host,render}=renderer();render('| Formula |\n| --- |\n| $a$<br>$b$<br />text |\n\n`<br>`');assert.equal(host.querySelectorAll('td br').length,2);assert.equal(host.querySelector('code').textContent,'<br>');w.close();
});

function citations(){
 const w=new JSDOM('<content><div id="write"><p cid="p">Primary citation record sufficiently long for locating.</p><a href="#ref-1">Primary</a></div></content><div id="side"><p>Secondary citation record sufficiently long for locating.</p><a href="#ref-1">Secondary</a><p><img></p><p>图 1. 副栏图注。</p></div>',{pretendToBeVisual:true}).window,d=w.document;
 let sideFile='C:\\side\\paper.md',active=true,waitRead=null;const nativeFile='C:\\main\\paper.md',reads=[];
 const data=file=>({schema:'xref-sidecar-v2',path_base:'markdown-directory',documents:[{markdown:'paper.md',targets:[{id:'ref-1',kind:'reference'},{id:'fig-1',kind:'figure',content:'![图](image.png)\n\n图 1. 副栏图注。'}],bibliography:[{id:'ref-1',text:(file.includes('main')?'Primary':'Secondary')+' citation record sufficiently long for locating.',urls:[]}]}]});
 const fakeFS={stat:async()=>({isFile:()=>true,size:1200,mtimeMs:1}),readFile:async file=>{reads.push(file);if(waitRead)await waitRead;return JSON.stringify(data(file));}};
 const C=vm.runInNewContext(['body-xref-links.js','body-xref-media.js','body-citation-preview.js'].map(n=>fs.readFileSync(path.join(__dirname,n),'utf8')).join('\n')+';EditingToolbarCitationPreview',{
  window:w,document:d,URL:w.URL,Node:w.Node,CSS:{},innerWidth:1200,innerHeight:800,MutationObserver:w.MutationObserver,ResizeObserver:class{observe(){}},File:{bundle:{filePath:nativeFile},editor:{sourceView:{},contextMenu:{hide(){}},tryOpenUrl(){throw Error('Unexpected native navigation');}}},
  reqnode:n=>n==='fs'?{promises:fakeFS}:n==='path'?path.win32:require(n),getSelection:()=>w.getSelection(),setInterval:w.setInterval.bind(w),clearInterval:w.clearInterval.bind(w),setTimeout:w.setTimeout.bind(w),clearTimeout:w.clearTimeout.bind(w)
 });
 const toolbar={hide(){},_showToolbarNotice(){},tableColumns:{scan(){}}},scroller=d.getElementById('side');scroller.scrollTo=o=>{scroller._scroll=o.top;};const mainScroller=d.querySelector('content');mainScroller.scrollTo=()=>{throw Error('Wrong pane scroll');};
 const primary=toolbar.citationPreview=new C(toolbar),side=new C(toolbar,{file:()=>sideFile,root:()=>scroller,valid:()=>active,scroller:()=>scroller,openLink(){}});toolbar.splitView={citationPreview:side};
 return{w,d,primary,side,scroller,reads,setFile:f=>sideFile=f,setActive:v=>active=v,defer:promise=>waitRead=promise,close(){w.close();}};
}
test('each pane resolves identical reference IDs from its own index and navigates only its own DOM',async()=>{
 const h=citations();await h.primary.load();await h.side.load();assert.match(h.primary.records.get('ref-1').text,/Primary/);assert.match(h.side.records.get('ref-1').text,/Secondary/);
 assert.equal(h.primary.link(h.d.querySelector('#side a')),null);assert.equal(h.side.link(h.d.querySelector('#write a')),null);
 assert.equal(h.side.locate(h.side.records.get('ref-1')),h.scroller.querySelector('p'));h.side.navigate('ref-1',h.side.file);assert.equal(typeof h.scroller._scroll,'number');assert.equal(h.side.media.locate(h.side.records.get('fig-1')).querySelector('img').tagName,'IMG');
 h.primary.show(h.primary.records.get('ref-1'),h.d.querySelector('#write a'));h.side.show(h.side.records.get('ref-1'),h.scroller.querySelector('a'));assert.equal(h.primary.popup.hidden,true);assert.equal(h.side.popup.hidden,false);assert.equal(h.side.popup.id,'et-split-citation-preview');h.close();
});
test('a pending index read cannot populate the next document, and closing the pane invalidates hover',async()=>{
 const h=citations();let release;h.defer(new Promise(r=>release=r));const pending=h.side.load();h.setFile('C:\\other\\paper.md');h.side.bind();release();await pending;assert.equal(h.side.records.size,0);h.defer(null);await h.side.load();assert.equal(h.side.records.size,2);h.setActive(false);h.side.bind();assert.equal(h.side.valid(),false);assert.equal(h.side.anchor,null);h.close();
});
test('click awaiting an index does not navigate after changing the split document',async()=>{
 const h=citations();let release;h.defer(new Promise(r=>release=r));let navigations=0;h.side.navigate=()=>navigations++;const pending=h.side.click({target:h.scroller.querySelector('a'),button:0,preventDefault(){},stopImmediatePropagation(){}});h.setFile('C:\\other\\paper.md');h.side.bind();release();await pending;assert.equal(navigations,0);h.close();
});
