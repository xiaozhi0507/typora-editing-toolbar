'use strict';
// Store an independent document bundle. Source documents are never rewritten or removed.
class KnowledgeLibraryManaged {
  constructor(store) { this.store=store;this.io=store.io;this.path=store.path;this.storage=this.path.join(store.root,'storage'); }
  inside(parent,file) { const r=this.path.relative(parent,file);return r===''||r!=='..'&&!r.startsWith('..'+this.path.sep)&&!this.path.isAbsolute(r); }
  async regular(file) {
    const stat=await this.io.lstat(file);
    if(stat.isSymbolicLink())throw Error('托管导入不跟随链接目录或文件：'+file);
    const real=await this.io.realpath(file),normalized=this.path.resolve(file);
    if(real.toLowerCase()!==normalized.toLowerCase())throw Error('托管资源经过了链接目录：'+file);
    return stat;
  }
  static links(markdown) {
    const result=[],text=markdown.replace(/^ {0,3}(`{3,}|~{3,})[^\n]*\n[\s\S]*?^ {0,3}\1[^\n]*$/gm,'');
    for(const m of text.matchAll(/\]\(/g)){
      let at=m.index+2,end=at,depth=1;
      if(text[at]==='<'){end=text.indexOf('>',at+1);if(end>=0)result.push(text.slice(at+1,end));continue;}
      for(;end<text.length;end++){const c=text[end];if(c==='\\'){end++;continue;}if(c==='(')depth++;if(c===')'&&!--depth)break;if(/\s/.test(c)&&depth===1)break;}
      if(end>at)result.push(text.slice(at,end).replace(/\\([() ])/g,'$1'));
    }
    for(const m of text.matchAll(/^ {0,3}\[[^\]\n]+\]:\s*(?:<([^>\n]+)>|([^\s]+))/gm))result.push(m[1]||m[2]);
    for(const m of text.matchAll(/<(?:img|source|video|audio)\b[^>]*?\bsrc\s*=\s*['"]([^'"]+)['"]/gi))result.push(m[1].replace(/&amp;/g,'&'));
    return [...new Set(result)];
  }
  localLink(link,directory) {
    if(!link||link.startsWith('#')||/^(?:https?:|data:|mailto:|tel:|zotero:|typora:|\/\/)/i.test(link))return null;
    if(/^[a-z][\w+.-]*:/i.test(link)||this.path.isAbsolute(link))throw Error('发现绝对本地链接，请先改为相对链接再托管：'+link);
    let value=link.split(/[?#]/)[0];try{value=decodeURIComponent(value);}catch(_){}
    return value?this.path.resolve(directory,value):null;
  }
  async plan(ref,{signal,bookRoot,includeNotes=true}={}) {
    if(bookRoot)bookRoot=this.path.resolve(bookRoot);
    const source=this.store.resolveFile(ref),files=new Map(),queue=[],documents=new Set();let bytes=0;
    const check=()=>{if(signal?.aborted){const e=Error('已取消导入');e.name='AbortError';throw e;}};
    const add=async(file,optional=false)=>{
      check();file=this.path.resolve(file);if(files.has(file))return;
      if(bookRoot&&!this.inside(bookRoot,file))throw Error('书籍链接指向所选文件夹之外，请先将资源整理到书籍目录内：'+file);
      let stat;try{stat=await this.regular(file);}catch(e){if(optional&&e.code==='ENOENT')return;throw e;}
      if(!stat.isFile())throw Error('文档资源不是普通文件：'+file);
      bytes+=stat.size;if(bytes>1024*1024*1024||files.size>=10000)throw Error('单个托管文档包超过 1 GB 或一万个文件，请拆分后导入。');
      files.set(file,{file,bytes:stat.size,mtime:stat.mtimeMs});
      if(/\.(md|markdown|mdown|txt)$/i.test(file))queue.push(file);
    };
    const tree=async directory=>{
      let st;try{st=await this.regular(directory);}catch(e){if(e.code==='ENOENT')return;throw e;}
      if(!st.isDirectory())throw Error('配套资源目录格式错误：'+directory);
      for(const e of await this.io.readdir(directory,{withFileTypes:true})){
        if(bookRoot&&(e.name.startsWith('.')||e.name==='node_modules'))continue;
        check();const file=this.path.join(directory,e.name);if(e.isSymbolicLink())throw Error('配套目录中存在链接文件：'+file);
        if(e.isDirectory())await tree(file);else await add(file);
      }
    };
    await add(source);
    if(bookRoot)await tree(bookRoot);
    while(queue.length){
      const md=queue.shift();if(documents.has(md))continue;documents.add(md);check();
      if(files.get(md).bytes>16*1024*1024)throw Error('Markdown 超过 16 MB，请拆分后导入。');
      const directory=this.path.dirname(md),stem=this.path.basename(md,this.path.extname(md)),raw=await this.io.readFile(md,'utf8');
      for(const link of KnowledgeLibraryManaged.links(raw)){const target=this.localLink(link,directory);if(target)await add(target);}
      // Sidecar documents are already included recursively; do not search for sidecars of sidecar notes.
      if(!/\.(?:资料|笔记|注释|标注)[\\/]/.test(md)){
        await tree(this.path.join(directory,'_xref',stem));
        if(includeNotes)for(const suffix of ['.资料','.笔记','.注释','.标注'])await tree(md+suffix);
      }
    }
    let base=bookRoot||this.path.dirname(source);
    for(const file of files.keys())while(!this.inside(base,file)){
      const parent=this.path.dirname(base);if(parent===base)throw Error('资源跨越磁盘，请将资源放到文档附近后导入。');base=parent;
    }
    return {source,base,files:[...files.values()],bytes};
  }
  async prepare(ref,options={}) {
    if(ref.linkType==='url'||! /\.(md|markdown|mdown)$/i.test(ref.path))return {...ref};
    const source=this.store.resolveFile(ref);
    if(this.inside(this.storage,source)){await this.regular(source);return {...ref,managed:true};}
    const plan=await this.plan(ref,options);
    await this.io.mkdir(this.storage,{recursive:true});await this.regular(this.storage);
    const key=this.store.crypto.randomBytes(4).toString('hex').toUpperCase(),folder=this.path.join(this.storage,key);
    await this.io.mkdir(folder);const manifest=[];
    try{
      for(const f of plan.files){
        if(options.signal?.aborted){const e=Error('已取消导入');e.name='AbortError';throw e;}
        const relative=this.path.relative(plan.base,f.file),target=this.path.join(folder,relative);
        if(!this.inside(folder,target))throw Error('资源目标超出托管目录');
        await this.io.mkdir(this.path.dirname(target),{recursive:true});
        const before=await this.regular(f.file);if(before.size!==f.bytes||before.mtimeMs!==f.mtime)throw Error('导入期间资源已修改，请重试：'+f.file);
        await this.io.copyFile(f.file,target,this.store.fs.constants.COPYFILE_EXCL);
        const [a,b]=await Promise.all([this.io.readFile(f.file),this.io.readFile(target)]);
        const hash=value=>this.store.crypto.createHash('sha256').update(value).digest('hex');
        if(hash(a)!==hash(b))throw Error('资源复制校验失败：'+f.file);
        manifest.push({path:relative.replaceAll('\\','/'),bytes:b.length,sha256:hash(b),source:f.file});
      }
      const target=this.path.join(folder,this.path.relative(plan.base,source));
      await this.io.writeFile(this.path.join(folder,'.managed.json'),JSON.stringify({version:1,source,created:new Date().toISOString(),files:manifest},null,2),{flag:'wx'});
      return {...this.store.fileRef(target,ref.kind),id:ref.id,managed:true,storageKey:key,sourcePath:ref.sourcePath||source};
    }catch(e){await this.removeFolder(folder).catch(()=>{});throw e;}
  }
  async removeFolder(folder) {
    const full=this.path.resolve(folder);
    if(this.path.dirname(full)!==this.storage||! /^[A-F0-9]{8}$/.test(this.path.basename(full)))throw Error('拒绝删除非本次托管目录');
    await this.regular(full);await this.io.rm(full,{recursive:true,force:false});
  }
  async rollback(refs) {
    const current=await this.store.read(),used=(current?.data.items||[]).flatMap(i=>i.files).filter(f=>f.linkType!=='url').map(f=>this.store.resolveFile(f));
    for(const ref of refs){if(!ref.storageKey||!ref.sourcePath)continue;const folder=this.path.join(this.storage,ref.storageKey);if(used.some(f=>this.inside(folder,f)))continue;await this.removeFolder(folder).catch(()=>{});}
  }
}
module.exports=KnowledgeLibraryManaged;
