'use strict';
// Read ZIPs without extracting during preview. Validate both headers and actual bytes.
class SkillZip {
 constructor(req){this.fs=req('fs').promises;this.path=req('path');this.crypto=req('crypto');this.zlib=req('zlib');this.Buffer=req('buffer').Buffer;}
 static safe(name){
  if(!name||name.length>1024||/[\\:\x00-\x1f]/.test(name)||name.startsWith('/'))throw Error('ZIP 包含不安全路径');
  const clean=name.replace(/\/$/,'');
  if(clean.split('/').some(p=>!p||p==='.'||p==='..'||/[. ]$/.test(p)||/^(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\.|$)/i.test(p)))throw Error('ZIP 包含不安全路径：'+name);
  return clean;
 }
 static crc(bytes){if(!this.crcTable)this.crcTable=Uint32Array.from({length:256},(_,n)=>{let c=n;for(let i=0;i<8;i++)c=(c>>>1)^((c&1)?0xedb88320:0);return c>>>0;});let crc=0xffffffff;for(const b of bytes)crc=(crc>>>8)^this.crcTable[(crc^b)&255];return (crc^0xffffffff)>>>0;}
 async pack(files,options={}){
  const Buffer=this.Buffer,max=options.plugin?100:32,maxFiles=options.plugin?10000:4000,single=options.plugin?32:16,totalMax=options.plugin?256:64;
  // Native asynchronous compression keeps the renderer responsive; UTF-8 names
  // and classic ZIP headers round-trip through the same validated importer.
  if(!files.size||files.size>maxFiles)throw Error('压缩包不能为空或超过 '+maxFiles+' 个文件');
  const chunks=[],index=[],names=new Set();let offset=0,total=0;
  for(const [name,bytes] of files){
   SkillZip.safe(name);const key=name.toLowerCase();if(names.has(key))throw Error('技能资源名称冲突：'+name);names.add(key);
   if(bytes.length>single*1024**2||(total+=bytes.length)>totalMax*1024**2)throw Error('压缩包超过单文件 '+single+' MiB 或总计 '+totalMax+' MiB');
   const compressed=await new Promise((resolve,reject)=>this.zlib.deflateRaw(bytes,{level:6},(e,b)=>e?reject(e):resolve(b)));
   const method=compressed.length<bytes.length?8:0,body=method?compressed:bytes,label=Buffer.from(name,'utf8'),crc=SkillZip.crc(bytes);
   const local=Buffer.alloc(30);local.writeUInt32LE(0x04034b50);local.writeUInt16LE(20,4);local.writeUInt16LE(0x800,6);local.writeUInt16LE(method,8);local.writeUInt16LE(33,12);local.writeUInt32LE(crc,14);local.writeUInt32LE(body.length,18);local.writeUInt32LE(bytes.length,22);local.writeUInt16LE(label.length,26);
   const central=Buffer.alloc(46);central.writeUInt32LE(0x02014b50);central.writeUInt16LE(20,4);central.writeUInt16LE(20,6);central.writeUInt16LE(0x800,8);central.writeUInt16LE(method,10);central.writeUInt16LE(33,14);central.writeUInt32LE(crc,16);central.writeUInt32LE(body.length,20);central.writeUInt32LE(bytes.length,24);central.writeUInt16LE(label.length,28);central.writeUInt32LE(offset,42);
   chunks.push(local,label,body);index.push(central,label);offset+=local.length+label.length+body.length;
   if(offset>max*1024**2)throw Error('压缩包超过 '+max+' MiB，无法通过导入校验');
  }
  const directory=Buffer.concat(index),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(files.size,8);end.writeUInt16LE(files.size,10);end.writeUInt32LE(directory.length,12);end.writeUInt32LE(offset,16);
  if(offset+directory.length+end.length>max*1024**2)throw Error('压缩包超过 '+max+' MiB，无法通过导入校验');
  return Buffer.concat([...chunks,directory,end]);
 }
 async read(file,expected,options={}){
  const max=options.plugin?100:32, maxFiles=options.plugin?10000:4000;
  const stat=await this.fs.stat(file);if(!stat.isFile()||stat.size>max*1024**2)throw Error('ZIP 不能超过 '+max+' MiB');
  const data=await this.fs.readFile(file);if(data.length>max*1024**2)throw Error('ZIP 超过大小限制');
  const digest=this.crypto.createHash('sha256').update(data).digest('hex');if(expected&&digest!==expected)throw Error('ZIP 在预览后已改变，请重新选择');
  let end=-1;for(let i=data.length-22;i>=Math.max(0,data.length-65557);i--)if(data.readUInt32LE(i)===0x06054b50&&i+22+data.readUInt16LE(i+20)===data.length){end=i;break;}
  if(end<0)throw Error('ZIP 损坏或格式不受支持');
  const count=data.readUInt16LE(end+10),size=data.readUInt32LE(end+12),start=data.readUInt32LE(end+16);
  if(data.readUInt16LE(end+4)||data.readUInt16LE(end+6)||data.readUInt16LE(end+8)!==count||count>maxFiles||start+size!==end)throw Error('不支持分卷、ZIP64 或超过 '+maxFiles+' 文件的包');
  const records=[],keys=new Map();let at=start,total=0;
  for(let i=0;i<count;i++){
   if(at+46>end||data.readUInt32LE(at)!==0x02014b50)throw Error('ZIP 文件索引损坏');
   const flags=data.readUInt16LE(at+8),method=data.readUInt16LE(at+10),crc=data.readUInt32LE(at+16),packed=data.readUInt32LE(at+20),length=data.readUInt32LE(at+24),nl=data.readUInt16LE(at+28),el=data.readUInt16LE(at+30),cl=data.readUInt16LE(at+32),offset=data.readUInt32LE(at+42);
   if(at+46+nl+el+cl>end)throw Error('ZIP 文件索引损坏');
   const name=data.subarray(at+46,at+46+nl).toString('utf8'),clean=SkillZip.safe(name),key=clean.toLowerCase(),mode=(data.readUInt32LE(at+38)>>>16)&0xf000;
   if(name.includes('\ufffd')||(flags&1)||![0,8].includes(method)||data.readUInt16LE(at+34)||![0,0x4000,0x8000].includes(mode))throw Error('ZIP 含加密文件、链接或不支持的格式');
   if(keys.has(key))throw Error('ZIP 文件路径重复：'+name);keys.set(key,name.endsWith('/'));
   if(length>(options.plugin?32:16)*1024**2||(total+=length)>(options.plugin?256:64)*1024**2)throw Error('解压后超过单文件或总计大小限制');
   if(offset+30>start||data.readUInt32LE(offset)!==0x04034b50||data.readUInt16LE(offset+6)!==flags||data.readUInt16LE(offset+8)!==method)throw Error('ZIP 文件头损坏');
   const localNameLength=data.readUInt16LE(offset+26),localExtra=data.readUInt16LE(offset+28),body=offset+30+localNameLength+localExtra;
   if(body+packed>start||data.subarray(offset+30,offset+30+localNameLength).toString('utf8')!==name)throw Error('ZIP 文件路径或内容不一致');
   records.push({name,clean,directory:name.endsWith('/'),crc,packed,length,method,body,offset});at+=46+nl+el+cl;
  }
  if(at!==end)throw Error('ZIP 文件索引长度不一致');
  for(const r of records){const parts=r.clean.toLowerCase().split('/');parts.pop();while(parts.length){if(keys.get(parts.join('/'))===false)throw Error('ZIP 文件与目录路径冲突');parts.pop();}}
  const sorted=[...records].sort((a,b)=>a.offset-b.offset);for(let i=1;i<sorted.length;i++)if(sorted[i].offset<sorted[i-1].body+sorted[i-1].packed)throw Error('ZIP 文件内容重叠');
  const files=new Map();
  for(const r of records){
   const packed=data.subarray(r.body,r.body+r.packed);let bytes;
   if(r.method===0)bytes=packed;else bytes=await new Promise((resolve,reject)=>this.zlib.inflateRaw(packed,{maxOutputLength:Math.max(1,r.length)},(e,v)=>e?reject(Error('ZIP 解压失败或实际内容超限')):resolve(v)));
   if(bytes.length!==r.length||SkillZip.crc(bytes)!==r.crc)throw Error('ZIP 文件校验失败：'+r.name);
   if(!r.directory&&!r.name.startsWith('__MACOSX/')&&!r.name.split('/').some(x=>x.startsWith('._')))files.set(r.name,bytes);
  }
  const entries=[...files.keys()].filter(n=>/(^|\/)skill\.md$/i.test(n));if(options.plugin)return {file,digest,files,entries};if(!entries.length)throw Error('ZIP 中未找到 SKILL.md');if(entries.length>100)throw Error('一次最多导入 100 个技能');
  for(const entry of entries){const root=entry.slice(0,entry.lastIndexOf('/')+1);if(entries.some(other=>other!==entry&&other.startsWith(root)))throw Error('ZIP 中的技能目录不能互相嵌套');}
  return {file,digest,files,entries};
 }
 static token(zip,entry){return 'skill-zip:'+encodeURIComponent(zip.file)+'#'+zip.digest+'#'+encodeURIComponent(entry);}
 static parse(token){const m=String(token).match(/^skill-zip:([^#]+)#([a-f0-9]{64})#([^#]+)$/);if(!m)throw Error('无效 ZIP 技能条目');return {file:decodeURIComponent(m[1]),digest:m[2],entry:decodeURIComponent(m[3])};}
 async selected(token){const ref=SkillZip.parse(token),zip=await this.read(ref.file,ref.digest);if(!zip.entries.includes(ref.entry))throw Error('ZIP 中的技能条目不存在');return {...zip,entry:ref.entry,prefix:ref.entry.slice(0,ref.entry.lastIndexOf('/')+1)};}
}
module.exports=SkillZip;
