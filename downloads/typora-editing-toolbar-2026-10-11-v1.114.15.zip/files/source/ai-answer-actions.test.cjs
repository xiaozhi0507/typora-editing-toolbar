const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
function fixture(){
  let loading=false,copied='',saved=0,retried=0,favorited=0;
  const notes={ctx:{notes:[]},_ui:()=>({opened:[]}),_blankNote:()=>({id:'n'}),_save:()=>{saved++;return true;},tabs:{reveal(){}},...Object.fromEntries(['_switchDocument','_flushEditor','_touch','_saveUI','open','_renderList','_showSelected'].map(k=>[k,()=>{}]))};
  const box={File:{isFileLoading:()=>loading},ETAIClient:{insertableMarkdown:s=>s},reqnode:()=>({clipboard:{writeText:s=>copied=s}})};vm.createContext(box);
  vm.runInContext(fs.readFileSync(require.resolve('./ai-assistant.js'),'utf8')+';globalThis.AI=EditingToolbarAI;',box);
  const library={update(){},toggle(){favorited++;}},a=Object.assign(Object.create(box.AI.prototype),{busy:true,file:()=>'/same.md',toolbar:{documentNotes:notes,_showToolbarNotice(){}},notice(){},resetCopyFeedback(){},send:()=>retried++,conversations:{library},turns:[]});
  const turn=(status,answer)=>{const children=['copy','note','favorite','retry'].map(action=>({dataset:{answerAction:action}}));const t={status,answer,file:'/same.md',question:'问题',model:'mock',reference:'原文',actions:{children,querySelector(){return null;}}};a.turns.push(t);return t;};
  return {a,turn,notes,loading:v=>loading=v,state:()=>({copied,saved,retried,favorited})};
}
test('current thinking and streaming answer actions are hidden; previous answer actions stay usable',()=>{
  const {a,turn}=fixture(),old=turn('done','旧答案'),running=turn('running','');a.syncTurnActions(old);a.syncTurnActions(running);
  assert.equal(old.actions.hidden,false);assert.ok(old.actions.children.slice(0,3).every(b=>!b.disabled));assert.equal(running.actions.hidden,true);assert.ok(running.actions.children.every(b=>b.disabled));
  running.answer='正在输出';a.syncTurnActions(running);assert.equal(running.actions.hidden,true);
  running.status='done';a.busy=false;a.syncTurnActions(running);assert.equal(running.actions.hidden,false);assert.ok(running.actions.children.slice(0,3).every(b=>!b.disabled));
});
test('completed answer copy, note and favorite execute during another generation',async()=>{
  const {a,turn,state,notes}=fixture(),old=turn('done','旧答案');turn('running','');
  for(const action of ['copy','note','favorite'])await a.answerAction(old,action);
  assert.equal(state().copied,'旧答案');assert.equal(state().favorited,1);assert.equal(notes.ctx.notes.length,1);assert.match(notes.ctx.notes[0].markdown,/旧答案/);assert.equal(state().saved,2);assert.equal(a.busy,true);
});
test('running actions and busy retries cannot run; partial stopped/error answers can be saved',async()=>{
  const {a,turn,state,notes}=fixture(),running=turn('running','草稿');for(const action of ['copy','note','favorite','retry'])await a.answerAction(running,action);
  assert.deepEqual(state(),{copied:'',saved:0,retried:0,favorited:0});
  running.status='error';a.syncTurnActions(running);assert.equal(running.actions.hidden,false);assert.equal(running.actions.children[3].disabled,true);await a.answerAction(running,'retry');assert.equal(state().retried,0);
  await a.answerAction(running,'note');assert.match(notes.ctx.notes[0].markdown,/未完整生成/);
  a.busy=false;a.syncTurnActions(running);assert.equal(running.actions.children[3].disabled,false);await a.answerAction(running,'retry');assert.equal(state().retried,1);
});
test('note saving still rejects document switches and loading',async()=>{
  const {a,turn,loading,notes}=fixture(),old=turn('done','旧答案');old.file='/other.md';a.syncTurnActions(old);assert.equal(old.actions.children[1].disabled,true);await assert.rejects(a.answerAction(old,'note'),/回到提问时的文档/);
  old.file='/same.md';loading(true);a.syncTurnActions(old);assert.equal(old.actions.children[1].disabled,true);await assert.rejects(a.answerAction(old,'note'),/回到提问时的文档/);assert.equal(notes.ctx.notes.length,0);
});
