// Current-document heading nodes are a view overlay, never part of the file index.
const selector='h1[cid],h2[cid],h3[cid]';
export class ResearchGraphOutline {
 constructor(sidebar){this.sidebar=sidebar;this.depth=0;this.observer=new MutationObserver(records=>{
  if(records.some(r=>r.target.parentElement?.closest(selector)||r.target.matches?.(selector)||[...r.addedNodes,...r.removedNodes].some(n=>n.nodeType===1&&(n.matches(selector)||n.querySelector(selector)))))this.schedule();
 });}
 ready(){const s=this.sidebar;return s.options.scope==='local'&&s.file&&s.file===File.bundle?.filePath&&!File.isFileLoading?.()&&!File.editor.sourceView?.inSourceMode;}
 reset(){this.depth=0;this.observer.disconnect();this.write=null;clearTimeout(this.timer);}
 schedule(){if(!this.depth)return;clearTimeout(this.timer);this.timer=setTimeout(()=>{if(this.ready())this.sidebar.renderGraph();},120);}
 observe(){
  const write=this.depth&&this.ready()?document.getElementById('write'):null;
  if(write===this.write)return;this.observer.disconnect();this.write=write;
  if(write)this.observer.observe(write,{subtree:true,childList:true,characterData:true});
 }
 headings(){
  if(!this.ready())return[];
  const s=this.sidebar,root=s.key(s.file),headings=[],parents=[root];
  for(const element of document.getElementById('write')?.querySelectorAll(selector)||[]){
   if(!element.matches('[mdtype="heading"],.md-heading')||element.closest('.md-toc,.md-fences,.md-htmlblock'))continue;
   const cid=element.getAttribute('cid'),level=Number(element.tagName[1]),id='heading:'+root+'#'+cid,copy=element.cloneNode(true);
   copy.querySelectorAll('.md-entity').forEach(n=>n.replaceWith(document.createTextNode(n.getAttribute('data-content')||'')));
   copy.querySelectorAll('.md-meta,.md-before,.md-after,script,style').forEach(n=>n.remove());
   const title=copy.textContent.replace(/\s+/g,' ').trim()||'未命名标题';
   parents.length=level;const parentId=parents.slice().reverse().find(Boolean)||root;
   headings.push({id,label:title,title,kind:'heading',headingLevel:level,headingOrder:headings.length,headingCid:cid,headingFile:s.file,parentId,exists:true,current:false,connectionCount:0});
   parents[level]=id;
  }
  return headings;
 }
 cycle(){
  const s=this.sidebar;if(!this.ready()){s.notify('请在正文加载完成、退出源代码模式后展开标题。');return;}
  this.depth=(this.depth+1)%4;this.observe();s.nodeMenu.close();s.renderGraph();s.graph.fit();
  if(this.depth&&!s.graph.data?.headingCount)s.notify(s.graph.data?.omittedHeadings?'图谱已达节点上限，请在图谱设置中调高“最多显示节点”。':this.depth<3?'当前层级没有标题；再次点击本文档节点可展开下一级。':'本文档没有一级、二级或三级标题。');
 }
 collapse(){this.reset();this.sidebar.renderGraph();this.sidebar.graph.fit();}
 decorate(data){
  this.observe();if(!this.ready())return data;
  const s=this.sidebar,current=data.nodes.find(n=>n.current);if(!current)return data;
  current.currentAction=['点击展开一级标题','点击继续展开二级标题','点击继续展开三级标题','点击收起文档标题'][this.depth];
  if(!this.depth)return data;
  // Expanded headings are a document-only view. Keep file relations in the
  // index and side lists so collapsing can restore the original graph.
  const all=this.headings().filter(n=>n.headingLevel<=this.depth),capacity=Math.max(0,(s.options.maxNodes||500)-1);
  // Preserve ancestors before descendants when a graph reaches its node limit.
  const chosen=new Set(all.slice().sort((a,b)=>a.headingLevel-b.headingLevel||a.headingOrder-b.headingOrder).slice(0,capacity).map(n=>n.id));
  const headings=all.filter(n=>chosen.has(n.id)),ids=new Set([current.id,...chosen]);
  const edges=headings.map(n=>({source:ids.has(n.parentId)?n.parentId:current.id,target:n.id,kind:'heading'}));
  current.outlineExpanded=true;
  return{...data,nodes:[current,...headings],edges,isolated:headings.length?0:1,omitted:0,omittedEdges:0,headingCount:headings.length,headingDepth:this.depth,omittedHeadings:all.length-headings.length};
 }
 jump(node){
  const s=this.sidebar;if(!this.ready()||node.headingFile!==s.file)return s.notify('文档已切换或仍在加载，请重新选择标题。');
  const element=[...document.getElementById('write')?.querySelectorAll(selector)||[]].find(el=>el.getAttribute('cid')===node.headingCid);
  if(!element){s.renderGraph();return s.notify('这个标题已更改或删除，图谱已更新。');}
  s.toolbar.readingPosition?.cancelRestore();s.nodeMenu.close();
  const minimap=s.toolbar.chapterMinimap;
  minimap.bind();minimap.rebuild();const index=minimap.items.findIndex(item=>item.el===element);
  if(index>=0)minimap.jump(index);else File.editor.selection.scrollAdjust(element,10);
 }
}
