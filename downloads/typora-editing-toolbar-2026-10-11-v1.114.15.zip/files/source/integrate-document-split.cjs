const fs=require('node:fs'),path=require('node:path');
module.exports=code=>{
 const replace=(a,b)=>{if(!code.includes(a))throw Error('Missing split integration: '+a);code=code.replace(a,b);};
 const icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M12 4v16"/></svg>';
 replace('const BUTTON_DEFINITIONS = {','const BUTTON_DEFINITIONS = {\n"split-view":{icon:'+JSON.stringify(icon)+',title:"双栏模式"},');
 code=code.replaceAll('"terminal","theme-palette"','"terminal","split-view","theme-palette"').replaceAll('terminalRevision:1,','terminalRevision:1,splitRevision:1,');
 replace('        const top = topLayout === "classic"',`        if(!input.splitRevision){for(const ids of [compact.order,classic.buttons])if(!ids.includes('split-view')){const at=ids.indexOf('theme-palette');ids.splice(at<0?ids.length:at,0,'split-view');}}
        const top = topLayout === "classic"`);
 replace('    _mountToolbarUI() {','    _mountToolbarUI() {\n        this.splitView ||= new EditingToolbarDocumentSplit(this);');
 replace('    _executeAction(action) {','    _executeAction(action) {\n        if(action === "split-view") {this.splitView?.showMenu();return;}');
 replace('    _editingNotePanel(){return ','    _editingNotePanel(){return this.splitView?.panel?.contains(document.activeElement)||');
 const pos=code.lastIndexOf('(function () {');
 return code.slice(0,pos)+'\nconst ETSplitStore=(()=>{const module={exports:{}};'+fs.readFileSync(path.join(__dirname,'document-split-store.cjs'),'utf8')+';return module.exports;})();\n'+fs.readFileSync(path.join(__dirname,'document-split.js'),'utf8')+'\n'+code.slice(pos);
};
