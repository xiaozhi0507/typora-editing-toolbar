// Column widths are sidecar preferences; native pipe tables remain editable Markdown.
class EditingToolbarTableColumns {
 constructor(toolbar){
  this.toolbar=toolbar;this.store=toolbar.annotations;this.path=this.store.path;this.fs=this.store.fs;this.file='';this.records=[];this.bindings=new Map();this.applied=new WeakMap();this.raf=0;this.drag=null;
  this.line=document.createElement('div');this.line.className='et-table-column-guide';this.line.hidden=true;this.line.setAttribute('aria-hidden','true');document.body.append(this.line);
  document.addEventListener('mousemove',e=>this.move(e),true);document.addEventListener('mousedown',e=>this.down(e),true);document.addEventListener('mouseup',e=>{if(this.drag&&e.button===0)this.finish(false);},true);
  document.addEventListener('keydown',e=>{if(this.drag&&e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();this.finish(true);}},true);
  document.addEventListener('dblclick',e=>{const hit=this.hit(e);if(hit){e.preventDefault();e.stopPropagation();this.reset(hit.table);}},true);
  window.addEventListener('blur',()=>{this.finish(true);this.hide();});window.addEventListener('resize',()=>{this.finish(true);this.hide();});
  document.addEventListener('scroll',()=>{if(!this.drag)this.hide();},true);
  document.addEventListener('et-document-leaving',()=>{this.finish(true);this.hide();});
  document.addEventListener('et-document-loaded',()=>this.switchFile(true));document.addEventListener('et-document-saved-as',e=>this.saveAs(e.detail));
  this.observer=new MutationObserver(records=>{if(records.some(r=>r.type==='characterData'||r.type==='childList'&&![...r.addedNodes,...r.removedNodes].every(n=>n.nodeType===1&&n.matches('colgroup[data-et-columns],col')))){clearTimeout(this.scanTimer);this.scanTimer=setTimeout(()=>this.scan(),150);}});
  const undo=File.editor.undo,original=undo.exeCommand,self=this;
  undo.exeCommand=function(command,...args){if(['et-table-columns','et-table-alignment','et-table-three-line'].includes(command?.type)){if(command.file===self.file)self.applyCommand(command);return false;}return original.call(this,command,...args);};
  this.poll=setInterval(()=>this.switchFile(),500);this.switchFile();
 }
 dataFile(file=this.file){return file?this.path.join(this.path.dirname(file),this.path.basename(file)+'.资料','正文表格.json'):null;}
 read(file=this.file){const name=this.dataFile(file);if(!name||!this.fs.existsSync(name))return[];const data=JSON.parse(this.fs.readFileSync(name,'utf8'));if(data.version!==1||!Array.isArray(data.tables))throw Error('不支持的正文表格设置');return data.tables.filter(x=>x&&typeof x.id==='string'&&Array.isArray(x.widths)&&x.widths.length<=100&&x.widths.every(w=>Number.isFinite(w)&&w>=48&&w<=2400));}
 notice(text){console.warn('[EditingToolbar] '+text);if(typeof EditHelper!=='undefined')EditHelper.showNotification(text);}
 persist(record,strict=false){
  if(!this.file||this.readonly){if(strict)throw Error('请先保存文档并确认表格设置可写');return;}try{const data=this.read(),at=data.findIndex(x=>x.id===record.id);if(at<0)data.push(record);else data[at]=record;this.store._atomic(this.dataFile(),JSON.stringify({version:1,tables:data},null,2)+'\n');}
  catch(e){if(strict)throw e;this.notice('列宽已暂时应用，保存失败：'+e.message);}
 }
 switchFile(force=false){
  if(File.isFileLoading?.())return;const file=File.bundle?.filePath||'',write=document.getElementById('write');if(!write||!force&&file===this.file&&write===this.write)return;
  this.finish(true);this.hide();this.file=file;this.write=write;this.bindings.clear();this.applied=new WeakMap();this.readonly=false;
  try{this.records=this.read();}catch(e){this.records=[];this.readonly=true;this.notice('正文表格设置未读取，已保留原文件：'+e.message);}
  this.observer.disconnect();this.observer.observe(write,{subtree:true,childList:true,characterData:true});this.scan();
 }
 tables(){return [...this.write.querySelectorAll('figure[mdtype="table"]>table.md-table')];}
 describe(table,tables=this.tables()){
  const count=table.rows[0]?.cells.length||0,text=e=>(e.textContent||'').replace(/\s+/g,' ').trim(),header=[...table.rows[0].cells].map(text).join('\u001f'),hash=this.store._hash(text(table));
  const peers=tables.filter(t=>t.rows[0]?.cells.length===count&&[...t.rows[0].cells].map(text).join('\u001f')===header);
  return{columns:count,header,content:hash,occurrence:peers.indexOf(table),peers:peers.length,copies:peers.filter(t=>this.store._hash(text(t))===hash).length};
 }
 find(table,desc){
  const cid=table.parentElement.getAttribute('cid'),bound=this.bindings.get(cid);if(bound&&bound.columns===desc.columns)return bound;
  const available=this.records.filter(r=>![...this.bindings].some(([id,b])=>id!==cid&&b===r&&this.tables().some(t=>t.parentElement.getAttribute('cid')===id)));
  const exact=available.filter(r=>r.columns===desc.columns&&r.content===desc.content),matches=exact.length?exact:available.filter(r=>r.columns===desc.columns&&r.header===desc.header);
  const unique=exact.length?desc.copies===1:desc.peers===1,record=matches.length===1&&unique?matches[0]:matches.filter(r=>r.occurrence===desc.occurrence).sort((a,b)=>(b.updated||0)-(a.updated||0))[0];if(record)this.bindings.set(cid,record);return record;
 }
 scan(){
  if(!this.write?.isConnected||this.drag||File.isFileLoading?.()||this.file!==(File.bundle?.filePath||''))return;
  const tables=this.tables();for(const table of tables){if(!table.rows.length)continue;const desc=this.describe(table,tables),record=this.find(table,desc);if(!record){this.apply(table,[]);continue;}
   if(record.content!==desc.content||record.header!==desc.header||record.occurrence!==desc.occurrence){Object.assign(record,desc,{updated:Date.now()});this.persist(record);}
   this.apply(table,record.widths);
  }
  this.scanImportedTables();
 }
 scanImportedTables(){
  // Typora sanitizes class attributes from rendered HTML tables. Reapply the
  // indexed table's display style without changing its source or merged cells.
  const cp=this.toolbar.citationPreview,matched=new Set(),documentStyle=cp?.file===this.file&&cp.tableStyle==='three-line';
  if(cp?.file===this.file)for(const record of cp.records.values()){
   if(record.kind!=='table'||!record.threeLine)continue;
   const caption=cp.media.locate(record),block=caption?.nextElementSibling;
   if(!block?.matches('.md-htmlblock'))continue;
   const tables=[...block.querySelectorAll('.md-htmlblock-container>table')];
   if(tables.length===1)matched.add(tables[0]);
  }
  for(const table of this.write.querySelectorAll('.md-htmlblock-container>table')){
   if(documentStyle||matched.has(table)){table.classList.add('et-table-three-line');table.dataset.etImportedTable='true';table.parentElement.classList.add('et-imported-table-scroll');const columns=Math.max(0,...[...table.rows].map(r=>[...r.cells].reduce((n,c)=>n+c.colSpan,0)));table.style.setProperty('--et-imported-table-min-width',Math.min(columns,14)*6+'em');}
   else if(table.dataset.etImportedTable){table.classList.remove('et-table-three-line');delete table.dataset.etImportedTable;table.style.removeProperty('--et-imported-table-min-width');table.parentElement.classList.remove('et-imported-table-scroll');}
  }
 }
 apply(table,widths){
  table.classList.toggle('et-table-three-line',this.isThreeLine(table));
  const centered=this.bindings.get(table.parentElement.getAttribute('cid'))?.alignment==='center';
  if(table.classList.contains('et-table-centered')!==centered)table.classList.toggle('et-table-centered',centered);
  const signature=JSON.stringify(widths);if(this.applied.get(table)===signature&&(!widths.length||table.querySelector('colgroup[data-et-columns]')))return;
  this.applied.set(table,signature);let cols=table.querySelector('colgroup[data-et-columns]');
  if(!widths.length){cols?.remove();table.classList.remove('et-table-sized');table.style.removeProperty('--et-table-width');table.parentElement.classList.remove('et-table-scroll');return;}
  if(!cols){cols=document.createElement('colgroup');cols.dataset.etColumns='true';table.prepend(cols);}
  if(cols.children.length!==widths.length)cols.replaceChildren(...widths.map(()=>document.createElement('col')));
  widths.forEach((w,i)=>cols.children[i].style.width=w+'px');table.style.setProperty('--et-table-width',widths.reduce((a,b)=>a+b,0)+'px');table.classList.add('et-table-sized');table.parentElement.classList.add('et-table-scroll');
 }
 hit(e){
  if(document.body.classList.contains('typora-sourceview-on')||File.isReadonlyMode||File.isLocked)return null;
  const cell=e.target.closest?.('th,td'),table=cell?.closest('table.md-table');if(!table||!this.write?.contains(table)||!table.matches('figure[mdtype="table"]>table')||cell.parentElement!==table.rows[0])return null;
  if([...table.rows[0].cells].some(c=>c.colSpan!==1||c.rowSpan!==1))return null;
  const r=cell.getBoundingClientRect();let index=cell.cellIndex;if(Math.abs(e.clientX-r.right)<=7)return{table,index};if(index>0&&Math.abs(e.clientX-r.left)<=7)return{table,index:index-1};return null;
 }
 hide(){if(!this.hot&&this.line.hidden)return;this.hot=null;this.line.hidden=true;document.body.classList.remove('et-table-column-ready');}
 paint(table,index){const r=table.rows[0].cells[index]?.getBoundingClientRect(),box=table.getBoundingClientRect(),clip=table.parentElement.getBoundingClientRect();if(!r||r.right<clip.left||r.right>clip.right+1)return this.hide();this.line.hidden=false;Object.assign(this.line.style,{left:(r.right-1)+'px',top:r.top+'px',height:Math.min(box.bottom,innerHeight-12)-r.top+'px'});}
 move(e){
  if(this.drag){this.drag.x=e.clientX;if(!this.raf)this.raf=requestAnimationFrame(()=>{this.raf=0;this.preview();});e.preventDefault();return;}
  const hit=this.hit(e);if(!hit)return this.hide();this.hot=hit;if(!document.body.classList.contains('et-table-column-ready'))document.body.classList.add('et-table-column-ready');this.paint(hit.table,hit.index);
 }
 down(e){
  if(e.button!==0)return;const hit=this.hit(e);if(!hit||this.readonly)return;e.preventDefault();e.stopImmediatePropagation();this.toolbar.hide();this.toolbar.readingPosition?.cancelRestore();
  const table=hit.table,desc=this.describe(table),record=this.find(table,desc),widths=[...table.rows[0].cells].map(c=>Math.max(48,c.getBoundingClientRect().width));
  File.editor.undo.endSnap(true);this.drag={...hit,startX:e.clientX,x:e.clientX,widths,before:record?.widths.slice()||[],record,desc,file:this.file};
  document.body.classList.add('et-table-column-dragging');this.apply(table,widths);this.paint(table,hit.index);
 }
 preview(){
  const d=this.drag;if(!d)return;if(!d.table.isConnected||d.file!==File.bundle?.filePath)return this.finish(true);
  const widths=d.widths.slice();widths[d.index]=Math.round(Math.max(48,Math.min(2400,d.widths[d.index]+d.x-d.startX)));d.current=widths;this.apply(d.table,widths);this.paint(d.table,d.index);
 }
 finish(cancel){
  const d=this.drag;if(!d)return;if(this.raf)cancelAnimationFrame(this.raf);this.raf=0;
  if(!cancel)this.preview();if(!this.drag)return;this.drag=null;document.body.classList.remove('et-table-column-dragging');this.hide();
  if(cancel||Math.abs(d.x-d.startX)<1||!d.table.isConnected){if(d.table.isConnected)this.apply(d.table,d.before);return;}
  const record=d.record||{id:this.store._id(),...d.desc,widths:[]};if(!d.record)this.records.push(record);this.bindings.set(d.table.parentElement.getAttribute('cid'),record);
  this.commit(record,d.before,d.current||d.widths,d.table);
 }
 commit(record,before,after,table){
  record.widths=after.slice();Object.assign(record,this.describe(table),{updated:Date.now()});this.persist(record);this.apply(table,after);
  const command=widths=>({type:'et-table-columns',file:this.file,id:record.id,widths:widths.slice()});File.editor.undo.register({undo:[command(before)],redo:[command(after)],cursorOnly:true,date:new Date});
 }
 isThreeLine(table){
  const preference=this.bindings.get(table.parentElement.getAttribute('cid'))?.threeLine;if(typeof preference==='boolean')return preference;
  const cp=this.toolbar.citationPreview;if(!cp||cp.file!==this.file)return false;
  if(cp.tableStyle==='three-line')return true;
  const caption=table.parentElement.previousElementSibling;if(!caption)return false;
  return [...cp.records.values()].some(r=>r.kind==='table'&&r.threeLine&&cp.media.locate(r)===caption);
 }
 setThreeLine(table,value){
  this.switchFile();if(!table?.isConnected||!this.tables().includes(table)||!this.file||this.readonly)throw Error('当前表格无法保存样式');
  this.finish(true);File.editor.undo.endSnap(true);
  const desc=this.describe(table);let record=this.find(table,desc),fresh=!record;if(fresh)record={id:this.store._id(),...desc,widths:[]};
  const before=typeof record.threeLine==='boolean'?record.threeLine:null,previous={...record};record.threeLine=!!value;Object.assign(record,desc,{updated:Date.now()});
  try{this.persist(record,true);}catch(e){Object.keys(record).forEach(k=>delete record[k]);Object.assign(record,previous);throw e;}
  if(fresh)this.records.push(record);this.bindings.set(table.parentElement.getAttribute('cid'),record);this.apply(table,record.widths);
  const command=threeLine=>({type:'et-table-three-line',file:this.file,id:record.id,threeLine});
  File.editor.undo.register({undo:[command(before)],redo:[command(!!value)],cursorOnly:true,date:new Date});
 }
 applyCommand(command){const record=this.records.find(r=>r.id===command.id);if(!record)return;
  if(command.type==='et-table-three-line'){const previous={...record};if(typeof command.threeLine==='boolean')record.threeLine=command.threeLine;else delete record.threeLine;try{this.persist(record,true);}catch(e){Object.keys(record).forEach(k=>delete record[k]);Object.assign(record,previous);this.notice('表格样式未改变：'+e.message);return;}}
  else {if(command.type==='et-table-alignment'){if(command.alignment==='center')record.alignment='center';else delete record.alignment;}else record.widths=command.widths.slice();this.persist(record);}
  for(const table of this.tables())if(this.bindings.get(table.parentElement.getAttribute('cid'))===record)this.apply(table,record.widths);
 }
 reset(table){const record=this.find(table,this.describe(table));if(record?.widths.length)this.commit(record,record.widths,[],table);}
 saveAs({from,to}){
  this.finish(true);const previous=this.records.map(r=>({...r,widths:r.widths.slice()}));this.file=to;this.readonly=false;
  try{this.records=this.read(to);for(const old of previous){if(!this.records.some(r=>r.id===old.id)){this.records.push(old);this.persist(old);}}}catch(e){this.readonly=true;this.notice('另存为的正文列宽未复制：'+e.message);}
  this.bindings.clear();this.scan();
 }
}
