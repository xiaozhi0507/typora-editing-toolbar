const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),Client=require('./ai-client.cjs');
function fixture(){
  const values=new Map(),storage={getItem:k=>values.get(k)||null,setItem:(k,v)=>values.set(k,v)};
  const box={localStorage:storage,ETAIClient:Client};vm.createContext(box);vm.runInContext(fs.readFileSync(require.resolve('./ai-assistant.js'),'utf8')+';globalThis.AI=EditingToolbarAI;',box);
  const initial={profiles:[{id:'ds',model:'deepseek-flash',reasoningEffort:'high'},{id:'gpt',model:'gpt-6.1-sol',reasoningEffort:'xhigh'}],active:'ds'};
  const create=()=>Object.assign(Object.create(box.AI.prototype),{configKey:'test-ai',config:JSON.parse(storage.getItem('test-ai')||JSON.stringify(initial))});
  return{values,storage,create};
}
test('last chosen model and effort survive reopening and a stale window saving settings',()=>{
  const {create}=fixture(),old=create(),a=create();a.config.active='gpt';a.rememberModel(a.config.profiles[1]);a.persist();
  old.config.width=520;old.persist();const reopened=create();assert.equal(reopened.profile().id,'gpt');assert.equal(reopened.profile().reasoningEffort,'xhigh');
  const p=reopened.profile();p.reasoningEffort='low';reopened.rememberModel(p);reopened.persist();
  assert.equal(create().profile().reasoningEffort,'low');
});
test('selection is retained before any send and even when the account is temporarily unavailable',()=>{const {create}=fixture(),a=create();const p=a.config.profiles[1];a.rememberModel(p);p.chatgptAvailable=false;a.persist();assert.equal(create().profile().id,'gpt');});
test('removed or replaced profile falls back without selecting a different account by model name',()=>{const {create}=fixture(),a=create();a.rememberModel(a.config.profiles[1]);a.config.profiles[1].id='other-account';a.persist();assert.equal(create().profile().id,'ds');});
test('capability changes clamp saved effort and corrupt preference does not break loading',()=>{const {create,storage}=fixture(),a=create();a.rememberModel(a.config.profiles[1]);a.config.profiles[1].reasoningEfforts=['low','high'];a.persist();assert.equal(create().profile().reasoningEffort,'high');storage.setItem('test-ai:last-model','invalid');assert.ok(create().profile());});
test('preference stores only selection, no credentials or document data',()=>{const {create,values}=fixture(),a=create();a.rememberModel({...a.config.profiles[0],secret:'SECRET',url:'https://secret.invalid',system:'PRIVATE'});assert.deepEqual(Object.keys(JSON.parse(values.get('test-ai:last-model'))).sort(),['effort','id','model']);});
