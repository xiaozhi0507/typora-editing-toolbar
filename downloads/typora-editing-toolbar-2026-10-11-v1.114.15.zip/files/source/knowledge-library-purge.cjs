'use strict';
// Stage files on the same volume, commit the library, then permanently remove the staged data.
class KnowledgeLibraryPurge {
  constructor(store,{Managed,blockedPaths=()=>[]}={}) {
    this.store=store;this.io=store.io;this.path=store.path;this.Managed=Managed||require('./knowledge-library-managed.cjs');this.blockedPaths=blockedPaths;
    this.stage=this.path.join(store.root,'.delete-staging');
  }
  inside(parent,file){const r=this.path.relative(parent,file);return !r||r!=='..'&&!r.startsWith('..'+this.path.sep)&&!this.path.isAbsolute(r);}
  key(file){return this.path.resolve(file).toLowerCase();}
  async exists(file){try{return await this.io.lstat(file);}catch(e){if(e.code==='ENOENT')return null;throw e;}}
  async safe(file,tree=false){
    file=this.path.resolve(file);if(file===this.store.root||!this.inside(this.store.root,file))throw Error('拒绝删除知识库目录之外的文件');
    for(let at=file;;at=this.path.dirname(at)){
      const s=await this.exists(at);if(s?.isSymbolicLink())throw Error('删除目标经过链接目录，请先检查：'+at);
      if(at===this.store.root)break;
    }
    const stat=await this.exists(file);if(!stat)return null;
    if(tree&&stat.isDirectory())for(const e of await this.io.readdir(file,{withFileTypes:true}))await this.safe(this.path.join(file,e.name),true);
    return stat;
  }
  contentPath(file){
    const r=this.path.relative(this.store.root,file),first=r.split(this.path.sep)[0];
    if(!r||!this.inside(this.store.root,file)||first.startsWith('.')||/^(?:library\.json(?:\..*)?|metrics-cache\.json)$/i.test(first))throw Error('拒绝删除知识库配置或索引文件');
    if(file===this.path.join(this.store.root,'storage'))throw Error('不能删除整个 storage 目录');
    return file;
  }
  async dependencies(ref,seen=new Set()){
    if(ref.linkType==='url')return [];
    const source=this.store.resolveFile(ref),queue=[],found=[];
    const add=file=>{file=this.path.resolve(file);if(seen.has(this.key(file)))return;seen.add(this.key(file));found.push(file);if(/\.(md|markdown|mdown)$/i.test(file))queue.push(file);};
    const tree=async folder=>{const st=await this.exists(folder);if(!st)return;add(folder);if(st.isSymbolicLink())return;if(st.isDirectory())for(const e of await this.io.readdir(folder,{withFileTypes:true}))await tree(this.path.join(folder,e.name));};
    add(source);
    while(queue.length){
      const md=queue.shift(),st=await this.exists(md);if(!st||!st.isFile()||st.isSymbolicLink())continue;
      if(st.size>16*1024*1024)throw Error('文档过大，无法安全检查共享资源：'+md);
      for(const link of this.Managed.links(await this.io.readFile(md,'utf8'))){
        if(!link||link.startsWith('#')||/^(?:https?:|data:|mailto:|tel:|zotero:|typora:|\/\/)/i.test(link))continue;
        let value=link.split(/[?#]/)[0];try{value=decodeURIComponent(value);}catch(_){}
        if(/^[a-z][\w+.-]*:/i.test(value)&&!this.path.isAbsolute(value))continue;
        add(this.path.resolve(this.path.dirname(md),value));
      }
      if(!/\.(?:资料|笔记|注释|标注)[\\/]/.test(md)){
        await tree(this.path.join(this.path.dirname(md),'_xref',this.path.basename(md,this.path.extname(md))));
        for(const suffix of ['.资料','.笔记','.注释','.标注'])await tree(md+suffix);
      }
      if(found.length>30000)throw Error('资源过多，无法安全完成共享检查。');
    }
    return found;
  }
  next(base,request){
    if(request.collectionId||!Array.isArray(request.itemIds))throw Error('请先将条目移入回收站，再执行永久删除。');
    const next=JSON.parse(JSON.stringify(base)),ids=new Set(request.itemIds);
    for(const id of ids){const i=base.items.find(i=>i.id===id);if(!i||!i.deleted)throw Error('只能永久删除回收站中的条目，请刷新后重试。');}
    next.items=next.items.filter(i=>!ids.has(i.id));
    for(const i of next.items){i.related=i.related.filter(id=>!ids.has(id));if(i.relatedOut)i.relatedOut=i.relatedOut.filter(id=>!ids.has(id));}
    return {next,ids};
  }
  async plan(live,next,ids){
    const protectedPaths=new Set(),candidates=new Set(),visited=new Set();let external=0,shared=0;
    for(const i of next.items)for(const f of i.files)for(const dep of await this.dependencies(f,visited)){
      protectedPaths.add(this.key(dep));try{protectedPaths.add(this.key(await this.io.realpath(dep)));}catch(e){if(e.code!=='ENOENT')throw e;}
    }
    for(const i of live.items.filter(i=>ids.has(i.id)))for(const ref of i.files){
      if(ref.linkType==='url')continue;const file=this.store.resolveFile(ref);
      if(!this.inside(this.store.root,file)){external++;continue;}
      this.contentPath(file);
      const relative=this.path.relative(this.store.root,file).split(this.path.sep),folder=this.path.join(this.store.root,...relative.slice(0,2));
      const owned=relative[0]==='storage'&&/^(?:[A-Fa-f0-9]{8}|[a-f0-9-]{36})$/.test(relative[1]||'')&&relative.length>2&&(await this.exists(this.path.join(folder,'.managed.json'))||await this.exists(this.path.join(folder,'.connector.json')));
      if(owned)candidates.add(folder);
      else for(const dep of await this.dependencies(ref))if(this.inside(this.store.root,dep))candidates.add(this.contentPath(dep));
    }
    const paths=[];
    for(const file of [...candidates].sort((a,b)=>a.length-b.length)){
      if(paths.some(parent=>this.inside(parent,file)))continue;
      // Protect folders as a whole if any remaining item (including trash) uses their content.
      if([...protectedPaths].some(p=>this.inside(this.key(file),p))){shared++;continue;}
      if(!await this.safe(file,true))continue;
      const editing=(await this.blockedPaths()).find(p=>p&&this.inside(file,this.path.resolve(p)));
      if(editing)throw Error('请先关闭正在编辑的文档或笔记，再删除：'+this.path.basename(editing));
      paths.push(file);
    }
    return {paths,external,shared};
  }
  async restore(tx,journal){
    for(let i=journal.paths.length-1;i>=0;i--){const row=journal.paths[i],from=this.contentPath(this.path.resolve(this.store.root,row.source)),to=this.path.join(tx,row.slot);await this.safe(to,true);
      if(await this.exists(to)){if(await this.exists(from))throw Error('恢复删除失败：原位置已被占用，请保留 '+tx);await this.io.mkdir(this.path.dirname(from),{recursive:true});await this.safe(from);await this.io.rename(to,from);}
    }
  }
  async clean(tx){
    if(this.path.dirname(tx)!==this.stage||! /^[a-f0-9-]{36}$/.test(this.path.basename(tx)))throw Error('无效的删除事务目录');
    await this.safe(tx,true);
    // Keep the recovery journal until every staged payload has been removed.
    // A recursive removal of tx could delete the journal before a locked file fails.
    for(const entry of await this.io.readdir(tx))if(entry!=='journal.json'){
      const file=this.path.join(tx,entry);await this.safe(file,true);await this.io.rm(file,{recursive:true,force:true});
    }
    try{await this.io.unlink(this.path.join(tx,'journal.json'));}catch(e){if(e.code!=='ENOENT')throw e;}
    await this.io.rmdir(tx);
    try{await this.io.rmdir(this.stage);}catch(e){if(!['ENOTEMPTY','ENOENT','EEXIST'].includes(e.code))throw e;}
  }
  async recover(){
    return this.store.locked(async()=>{
      if(!await this.exists(this.stage))return;await this.safe(this.stage);
      const live=await this.store.read(),warnings=[];if(!live)throw Error('无法读取待恢复的知识库');
      for(const e of await this.io.readdir(this.stage,{withFileTypes:true})){
        if(!e.isDirectory()||! /^[a-f0-9-]{36}$/.test(e.name))throw Error('发现未知删除暂存目录，请检查 '+this.stage);
        const tx=this.path.join(this.stage,e.name);await this.safe(tx,true);const raw=await this.store.readOptional(this.path.join(tx,'journal.json'));
        if(!raw){if((await this.io.readdir(tx)).length===0){await this.clean(tx);continue;}throw Error('删除恢复记录缺失：'+tx);}
        const j=JSON.parse(raw);if(j.version!==1||j.libraryId!==live.data.libraryId||!Array.isArray(j.paths)||!Array.isArray(j.ids))throw Error('删除恢复记录不匹配：'+tx);
        for(const [index,row] of j.paths.entries())if(row.slot!==String(index)||typeof row.source!=='string')throw Error('删除恢复路径无效：'+tx);
        if(j.ids.some(id=>live.data.items.some(i=>i.id===id)))await this.restore(tx,j);
        try{await this.clean(tx);}catch(e){warnings.push('部分已删除文件仍在等待清理：'+e.message);}
      }
      return warnings.join('；');
    });
  }
  async remove(base,request){
    const {next,ids}=this.next(base,request);await this.recover();let tx,journal,plan,committed=false;
    try{
      const saved=await this.store.commit(base,next,async live=>{
        const merged=this.store.constructor.merge(base,next,live);this.store.validate(merged);
        plan=await this.plan(live,merged,ids);if(!plan.paths.length)return;
        await this.io.mkdir(this.stage,{recursive:true});await this.safe(this.stage);tx=this.path.join(this.stage,this.store.crypto.randomUUID());await this.io.mkdir(tx);
        journal={version:1,libraryId:live.libraryId,ids:[...ids],paths:plan.paths.map((p,i)=>({source:this.path.relative(this.store.root,p),slot:String(i)}))};
        await this.store.atomic(this.path.join(tx,'journal.json'),JSON.stringify(journal));
        for(const row of journal.paths){const from=this.contentPath(this.path.resolve(this.store.root,row.source)),to=this.path.join(tx,row.slot);await this.safe(from,true);await this.safe(to);await this.io.rename(from,to);}
      });
      committed=true;let warning='';
      if(tx)try{await this.clean(tx);}catch(e){warning='条目已删除，部分文件清理失败；重新打开此知识库时会继续清理。'+e.message;}
      return {data:saved,removed:ids.size,deletedPaths:plan.paths.length,external:plan.external,shared:plan.shared,warning};
    }catch(e){
      if(!committed&&tx){try{if(journal)await this.restore(tx,journal);await this.clean(tx);}catch(restoreError){throw Error(e.message+'；'+restoreError.message+'。重新打开知识库将尝试恢复。');}}
      throw e;
    }
  }
}
module.exports=KnowledgeLibraryPurge;
