// A lightweight navigation list. File contents and save prompts remain owned by Typora.
class EditingToolbarDocumentTabs {
  constructor(toolbar){
    this.toolbar=toolbar;this.path=reqnode('path');this.fs=reqnode('fs');this.storageKey='et-document-tabs-v1';this.current='';this.filter='all';this.rows=new Map();this.tabs=[];this.fileSelection=new Map();this.selectionAnchor=null;
    this.preferences=this.readPreferences();this.favoritesData=this.preferences.favorites;this.mtimes=new Map();
    // Open tabs belong to this window. Only explicit favorites, pins and view preferences persist.
    try{localStorage.setItem(this.storageKey,JSON.stringify(this.preferences));}catch{}
    this.sidebar=document.getElementById('typora-sidebar');this.host=document.getElementById('sidebar-content');if(!this.sidebar||!this.host)return;
    this.build();this.bind();this.sync();
    try{this.openRouter=new EditingToolbarDocumentOpenRouter(this);}catch(error){console.warn("[EditingToolbar] Window handoff unavailable:",error.message);}
  }
  key(file){return file?this.path.resolve(file).replace(/\\/g,'/').toLowerCase():'';}
  notice(text){if(!this.message){this.toolbar?._showToolbarNotice?.(text);return;}this.message.textContent=String(text||'');this.message.hidden=!text;clearTimeout(this.noticeTimer);if(text)this.noticeTimer=setTimeout(()=>{this.message.hidden=true;},4500);}
  supported(file){return typeof file==='string'&&this.path.isAbsolute(file)&&/\.(md|markdown|mdown|mkd|mkdn)$/i.test(file);}
  normalize(items){const seen=new Set();return(Array.isArray(items)?items:[]).filter(item=>{if(typeof item?.path!=='string'||!this.path.isAbsolute(item.path))return false;const key=this.key(item.path);if(seen.has(key))return false;seen.add(key);return true;}).map(item=>({path:this.path.normalize(item.path),...(typeof item.sectionId==='string'&&item.sectionId?{sectionId:item.sectionId}:{})}));}
  normalizeSections(items){const seen=new Set();return(Array.isArray(items)?items:[]).filter(s=>s&&typeof s.id==='string'&&/^[a-z0-9_-]{1,90}$/i.test(s.id)&&['pinned','favorites'].includes(s.collection)&&typeof s.name==='string'&&s.name.trim()&&!seen.has(s.id)&&seen.add(s.id)).map(s=>({id:s.id,collection:s.collection,name:s.name.trim().slice(0,60),collapsed:!!s.collapsed}));}
  collectionSections(collection){return(this.preferences.collectionSections||[]).filter(s=>s.collection===collection);}
  saveCollectionSection(collection,name,{id,file}={}){
    if(!['pinned','favorites'].includes(collection))return;name=String(name||'').trim();if(!name||name.length>60)throw Error('请输入 1–60 字的分区名称');
    this.change(db=>{db.collectionSections??=[];if(db.collectionSections.some(s=>s.collection===collection&&s.id!==id&&s.name===name))throw Error('已有同名分区');
      if(id){const section=db.collectionSections.find(s=>s.id===id&&s.collection===collection);if(section)section.name=name;}
      else{id='collection-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8);db.collectionSections.push({id,collection,name,collapsed:false});const item=db[collection].find(t=>this.key(t.path)===this.key(file));if(item)item.sectionId=id;}
    });return id;
  }
  moveToCollectionSection(collection,file,id){this.change(db=>{const item=db[collection]?.find(t=>this.key(t.path)===this.key(file));if(!item)return;const section=(db.collectionSections||[]).find(s=>s.id===id&&s.collection===collection);if(section){item.sectionId=section.id;section.collapsed=false;}else delete item.sectionId;});}
  removeCollectionSection(collection,id){this.change(db=>{db.collectionSections=(db.collectionSections||[]).filter(s=>!(s.id===id&&s.collection===collection));for(const item of db[collection])if(item.sectionId===id)delete item.sectionId;});}
  collectionMenu(collection,file){const current=this.preferences[collection].find(t=>this.key(t.path)===this.key(file))?.sectionId;return [{id:'collection-root',label:collection==='pinned'?'置顶':'收藏',checked:!current,run:()=>this.moveToCollectionSection(collection,file,null)},...this.collectionSections(collection).map(s=>({id:s.id,label:s.name,checked:s.id===current,run:()=>this.moveToCollectionSection(collection,file,s.id)}))];}
  collectionDialog(collection,file=null,existing=null){
    const d=this.modal(existing?'重命名分区':'新建分区','et-section-dialog'),form=this.node('form'),input=this.node('input'),error=this.node('p','et-project-error'),foot=this.node('div','et-project-footer'),cancel=this.node('button','','取消'),submit=this.node('button','primary',existing?'保存':'创建分区');input.placeholder='分区名称';input.setAttribute('aria-label','分区名称');input.maxLength=60;input.required=true;input.value=existing?.name||'';input.autocomplete='off';cancel.type='button';submit.type='submit';cancel.onclick=()=>d.close();error.setAttribute('role','alert');input.oninput=()=>{submit.disabled=!input.value.trim();error.textContent='';};foot.append(cancel,submit);form.append(input,error,foot);d.append(form);form.onsubmit=e=>{e.preventDefault();try{this.saveCollectionSection(collection,input.value,{id:existing?.id,file});d.close();}catch(e){error.textContent=e.message;input.focus();}};submit.disabled=!input.value.trim();d.showModal();input.focus();if(existing)input.select();
  }
  renderCollection(collection,items,host){
    const sections=this.collectionSections(collection),ids=new Set(sections.map(s=>s.id)),rowOptions=collection==='pinned'?{pinGroup:true}:{favoriteGroup:true};
    for(const item of items)if(!ids.has(item.sectionId))host.append(this.fileRow({...item,sectionId:''},rowOptions));
    for(const s of sections){const group=this.section(s.id,s.name,s.collapsed,()=>this.change(db=>{const item=db.collectionSections.find(x=>x.id===s.id);if(item)item.collapsed=!item.collapsed;}),host);group.section.classList.add('et-dt-collection-section');const more=this.button('分区操作 '+s.name,'more');more.setAttribute('aria-haspopup','menu');const menu=point=>this.showMenu([{id:'collection-new',label:'新建分区…',run:()=>this.collectionDialog(collection)},{id:'collection-rename',label:'重命名分区',run:()=>this.collectionDialog(collection,null,s)},null,{id:'collection-remove',label:'移除分区',run:()=>this.removeCollectionSection(collection,s.id)}],point,more,'分区操作');more.onclick=()=>{const r=more.getBoundingClientRect();menu({x:r.right,y:r.bottom+4,align:'end'});};group.head.oncontextmenu=e=>{e.preventDefault();e.stopPropagation();menu({x:e.clientX,y:e.clientY});};group.head.append(more);if(!s.collapsed)for(const item of items)if(item.sectionId===s.id)group.body.append(this.fileRow(item,rowOptions));}
  }
  readPreferences(){let db;try{db=JSON.parse(localStorage.getItem(this.storageKey));}catch{}return{version:5,collectionSections:this.normalizeSections(db?.collectionSections),favorites:this.normalize(db?.favorites),pinned:this.normalize(db?.pinned),pinSort:db?.pinSort==='updated_at'?'updated_at':'manual',pinCollapsed:!!db?.pinCollapsed,favoritesCollapsed:!!db?.favoritesCollapsed};}
  read(){return{...this.preferences,tabs:[...this.tabs],favorites:[...this.favoritesData],pinned:[...this.preferences.pinned]};}
  change(edit){const saved=this.readPreferences(),db={...saved,collectionSections:saved.collectionSections.map(s=>({...s})),favorites:saved.favorites.map(t=>({...t})),pinned:saved.pinned.map(t=>({...t})),tabs:[...this.tabs]};edit(db);this.tabs=this.normalize(db.tabs);const {tabs,...preferences}=db;preferences.favorites=this.normalize(db.favorites);preferences.pinned=this.normalize(db.pinned);this.preferences=preferences;this.favoritesData=preferences.favorites;if(JSON.stringify(preferences)!==JSON.stringify(saved))try{localStorage.setItem(this.storageKey,JSON.stringify(preferences));}catch{this.notice('标签页设置暂时无法保存，请检查本机存储空间');}this.render();}
  togglePin(file){const key=this.key(file);this.change(db=>{const i=db.pinned.findIndex(t=>this.key(t.path)===key);if(i<0){db.pinned.push({path:file});db.pinCollapsed=false;}else db.pinned.splice(i,1);});void this.refreshModified();}
  sortedPins(){const pins=[...this.preferences.pinned];if(this.preferences.pinSort==='updated_at')pins.sort((a,b)=>(this.mtimes.get(this.key(b.path))||0)-(this.mtimes.get(this.key(a.path))||0));return pins;}
  async refreshModified(){if(this.preferences.pinSort!=='updated_at'){this.modifiedVersion=(this.modifiedVersion||0)+1;return;}const version=this.modifiedVersion=(this.modifiedVersion||0)+1;const results=await Promise.all(this.preferences.pinned.map(async t=>{try{return[this.key(t.path),(await this.fs.promises.stat(t.path)).mtimeMs];}catch{return[this.key(t.path),0];}}));if(version!==this.modifiedVersion)return;this.mtimes=new Map(results);this.render();}
  movePin(key,target,after=false){this.change(db=>{const i=db.pinned.findIndex(t=>this.key(t.path)===key);if(i<0||key===target)return;const [item]=db.pinned.splice(i,1),j=db.pinned.findIndex(t=>this.key(t.path)===target);if(j<0||(item.sectionId||'')!==(db.pinned[j].sectionId||'')){db.pinned.splice(i,0,item);return;}db.pinned.splice(j+(after?1:0),0,item);db.pinSort='manual';});this.rows.get(key)?.querySelector('.et-dt-open')?.focus();}
  replacePath(from,to){this.replacePaths([{from,to}]);}
  replacePaths(moves,{allFiles=false}={}){this.toolbar?.aiAssistant?.codeUI?.relocate(moves);const paths=new Map();for(const {from,to}of moves){if(!from||(!allFiles&&!this.supported(to)&&!this.toolbar?.codeEditor?.supported(to))||from===to)continue;this.toolbar?.codeEditor?.relocate(from,to);paths.set(this.key(from),to);}if(!paths.size)return;this.change(db=>{for(const field of ['tabs','favorites','pinned'])db[field]=db[field].map(t=>paths.has(this.key(t.path))?{...t,path:paths.get(this.key(t.path))}:t);});void this.refreshModified();}
  node(tag,cls,text){const n=document.createElement(tag);if(cls)n.className=cls;if(text!=null)n.textContent=text;return n;}
  icon(name){const paths={file:'<path d="M6 3h8l4 4v14H6zM14 3v5h4M9 12h6M9 16h6"/>',star:'<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9z"/>',close:'<path d="m7 7 10 10M17 7 7 17"/>',plus:'<path d="M12 5v14M5 12h14"/>',pin:'<path d="m15 3 6 6-3 1-4 4v4l-2 2-3-5-5-3 2-2h4l4-4zM8 16l-5 5"/>',chevron:'<path d="m8 10 4 4 4-4"/>',more:'<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',check:'<path d="m5 12 4 4L19 6"/>'};return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+paths[name]+'</svg>';}
  modal(title,cls=''){const previous=document.activeElement,d=this.node('dialog','et-project-dialog '+cls),head=this.node('div','et-project-head'),h=this.node('h3','',title),close=this.button('关闭'+title,'close');d.setAttribute('aria-label',title);head.append(h,close);d.append(head);close.onclick=()=>d.close();d.onclose=()=>{d.remove();if(previous?.isConnected)previous.focus({preventScroll:true});};for(const type of ['keydown','mousedown','click','input','paste'])d.addEventListener(type,e=>e.stopPropagation());document.body.append(d);return d;}
  workspaceFile(file){return /\.(pyw?|ipynb|html?|[cm]?[jt]sx?|css|json|csv|tsv|txt|ya?ml|toml|ini|xml|sh|ps1|bat|cmd|r|m|sql)$/i.test(file||'');}
  fileIcon(file){
    if(/\.ipynb$/i.test(file))return '<svg data-file-kind="notebook" viewBox="0 0 24 24" fill="none" stroke="#d68a43" stroke-width="1.7" aria-hidden="true"><rect x="5" y="3" width="16" height="18" rx="2"/><path d="M3 7h4M3 12h4M3 17h4m7-9-3 4 3 4m2-8 3 4-3 4"/></svg>';
    const ext=this.path.extname(file).toLowerCase(),name=this.path.basename(file).toLowerCase();
    if(/\.pyw?$/.test(ext))return '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#3776ab" stroke="none" d="M12 2c-7 0-6 1-6 6h7v1H4C0 9 0 17 4 17h2v-4c0-2 1-3 3-3h6c2 0 3-1 3-3V4c0-2-3-2-6-2Z"/><path fill="#ffd343" stroke="none" d="M12 22c7 0 6-1 6-6h-7v-1h9c4 0 4-8 0-8h-2v4c0 2-1 3-3 3H9c-2 0-3 1-3 3v3c0 2 3 2 6 2Z"/><circle cx="9" cy="5" r="1" fill="white"/><circle cx="15" cy="19" r="1" fill="white"/></svg>';
    const kind=ext==='.pdf'?'pdf':/\.(?:csv|tsv|xls|xlsx|ods)$/.test(ext)?'table':ext==='.svg'?'vector':/\.(?:png|jpe?g|gif|webp|bmp|ico|tiff?)$/.test(ext)?'image':/\.(?:json|jsonc|jsonl)$/.test(ext)?'json':/\.(?:md|markdown|mdown|mkd|mkdn|rst)$/.test(ext)||/^readme(?:\.|$)/.test(name)?'markdown':/\.(?:html?|xml|vue|jsx|tsx)$/.test(ext)?'markup':/\.(?:css|scss|sass|less)$/.test(ext)?'style':/\.(?:js|mjs|cjs)$/.test(ext)?'javascript':ext==='.ts'?'typescript':ext==='.r'?'r':ext==='.m'?'matlab':/\.(?:c|cpp|cc|h|hpp|cs|java|go|rs|rb|php|sh|ps1|bat|sql|jl|lua)$/.test(ext)?'code':/\.(?:yaml|yml|toml|ini|cfg)$/.test(ext)?'config':'file';
    const shapes={
      table:['#3a9471','<rect x="4" y="3" width="16" height="18" rx="1.5"/><path d="M4 9h16M4 15h16M10 9v12"/>'],
      pdf:['#d45c60','<path d="M5 3h9l5 5v13H5zM14 3v6h5M8 17c3-2 5-6 3-7-2 0 0 7 5 6-1-2-4-1-8 1Z"/>'],
      image:['#428daf','<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8" cy="9" r="1.5"/><path d="m4 18 6-6 4 4 3-3 4 4"/>'],
      vector:['#9773c1','<path d="m12 3 8 9-8 9-8-9zM4 12h16M12 3v18"/>'],
      json:['#b88a3e','<path d="M8 4H6v6l-3 2 3 2v6h2M16 4h2v6l3 2-3 2v6h-2"/><circle cx="12" cy="9" r=".8"/><circle cx="12" cy="15" r=".8"/>'],
      markdown:['#5b8ec5','<rect x="3" y="5" width="18" height="14" rx="1.5"/><path d="M6 15V9l3 3 3-3v6m4-6v6m-2-2 2 2 2-2"/>'],
      markup:['#cb8254','<path d="m8 6-6 6 6 6m8-12 6 6-6 6M14 3l-4 18"/>'],
      style:['#967ac8','<path d="M5 3h14l-2 16-5 2-5-2zM8 7h8l-1 5H9l1 4 3 1 2-1"/>'],
      javascript:['#b59732','<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M10 8v8c0 2-3 2-3 0m11-7c-4-3-6 2-2 3 4 1 2 6-2 3"/>'],
      typescript:['#4d91c6','<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M6 9h6m-3 0v9m9-8c-4-3-6 2-2 3 4 1 2 6-2 3"/>'],
      r:['#5689ba','<ellipse cx="12" cy="12" rx="10" ry="8"/><path d="M9 18V7h4a3 3 0 0 1 0 6H9m4 0 4 5"/>'],
      matlab:['#c88449','<path d="m3 17 6-5 5-9 7 16-8-4-4-3-1 7"/>'],
      code:['#7595ab','<path d="m8 6-6 6 6 6m8-12 6 6-6 6M14 3l-4 18"/>'],
      config:['#87929b','<path d="M4 6h16M4 12h16M4 18h16"/><path d="M8 3v6m8 0v6m-6 0v6"/>']
    };
    if(!shapes[kind])return this.icon('file');const [color,body]=shapes[kind];
    return '<svg data-file-kind="'+kind+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+body+'</svg>';
  }
  button(label,icon){const b=this.node('button','et-dt-icon');b.type='button';b.title=label;b.setAttribute('aria-label',label);b.innerHTML=this.icon(icon);return b;}
  build(){
    this.sidebar.classList.add('et-document-tabs-enabled');
    for(const label of this.sidebar.querySelectorAll('#info-panel-tab-outline .info-panel-tab-title,#sidepanel-segmented-input-outline')){label.removeAttribute('data-localize');label.textContent='标签页';}
    this.toolbar.researchSidebar?.splitter.setAttribute('aria-label','调整文件标签与图谱的高度');
    this.panel=this.node('section','et-document-tabs');this.panel.id='et-document-tabs';this.panel.setAttribute('aria-label','Markdown 文件标签页');
    this.list=this.node('div','et-dt-list');this.list.setAttribute('role','tablist');this.list.setAttribute('aria-orientation','vertical');this.list.setAttribute('aria-label','文件标签');
    this.empty=this.node('div','et-dt-empty');this.message=this.node('div','et-dt-message');this.message.setAttribute('role','status');this.message.hidden=true;
    this.scroll=this.node("div","et-dt-scroll");this.scroll.append(this.list,this.empty);this.panel.append(this.scroll,this.message);this.host.append(this.panel);
    for(const type of ['mousedown','click','dblclick','keydown','contextmenu'])this.panel.addEventListener(type,e=>e.stopPropagation());
    this.list.addEventListener('keydown',e=>{if(!e.target.matches('.et-dt-open'))return;const row=e.target.closest('.et-dt-row'),key=row.dataset.key;
      if(e.key==='ContextMenu'||(e.shiftKey&&e.key==='F10')){e.preventDefault();const rect=row.getBoundingClientRect();this.rowMenu(row.dataset.path,{x:rect.left+12,y:rect.bottom},e.target);return;}
      if(e.key==='F2'&&row.dataset.path){e.preventDefault();this.renameDialog(row.dataset.path);return;}
      if(e.altKey&&['ArrowUp','ArrowDown'].includes(e.key)&&row.dataset.pinned==='true'){e.preventDefault();if(this.preferences.pinSort!=='manual'){this.notice('请在置顶菜单中选择“手动排序”后调整顺序。');return;}const pins=this.preferences.pinned.filter(t=>(t.sectionId||'')===(row.dataset.collectionSection||'')),i=pins.findIndex(t=>this.key(t.path)===key),target=pins[i+(e.key==='ArrowDown'?1:-1)];if(target)this.movePin(key,this.key(target.path),e.key==='ArrowDown');return;}
      if(!['ArrowUp','ArrowDown','Home','End','Delete'].includes(e.key))return;e.preventDefault();const buttons=[...this.list.querySelectorAll('.et-dt-open')],i=buttons.indexOf(e.target);if(e.key==='Delete'){if(row.classList.contains('et-project-file-row')){if(!this.fileSelection.has(key))this.selectProjectFile(row,{});void this.fileAction(()=>this.deleteFiles([...this.fileSelection.values()])).catch(error=>this.notice(error.message));}else this.close(key);return;}const next=e.key==='Home'?0:e.key==='End'?buttons.length-1:Math.max(0,Math.min(buttons.length-1,i+(e.key==='ArrowDown'?1:-1)));buttons[next]?.focus();});
    document.addEventListener('pointerdown',e=>{if(this.menu&&!this.menu.contains(e.target)&&!this.submenu?.contains(e.target))this.closeMenu(false);},true);
    window.addEventListener('resize',()=>this.closeMenu(false));this.scroll.addEventListener('scroll',()=>{if(this.menu&&(Math.abs(this.scroll.scrollTop-this.menuScrollTop)>.5||Math.abs(this.scroll.scrollLeft-this.menuScrollLeft)>.5))this.closeMenu(false);});
  }
  bind(){
    // Keep Typora's heading model and document TOC; skip only the hidden sidebar DOM.
    const outline=File.editor.library.outline,manager=this;
    for(const method of ['updateOutlineHtml','highlightVisibleHeader']){const original=outline?.[method];if(typeof original==='function')outline[method]=function(...args){if(manager.sidebar.classList.contains('et-document-tabs-enabled'))return;return original.apply(this,args);};}
    // Typora's Windows sidebar can retain aria-hidden after becoming visible.
    const accessibilityHost=this.sidebar.closest('header'),originalHidden=accessibilityHost?.getAttribute('aria-hidden');
    const visibility=()=>{const shown=File.editor.library.isSidebarShown();this.sidebar.setAttribute('aria-hidden',String(!shown));if(accessibilityHost){if(shown)accessibilityHost.setAttribute('aria-hidden','false');else if(originalHidden===null)accessibilityHost.removeAttribute('aria-hidden');else accessibilityHost.setAttribute('aria-hidden',originalHidden);}};
    this.visibility=new MutationObserver(visibility);this.visibility.observe(document.body,{attributes:true,attributeFilter:['class']});this.visibility.observe(this.sidebar,{attributes:true,attributeFilter:['class']});visibility();
    document.addEventListener('et-document-loaded',()=>this.sync());
    document.addEventListener('et-document-saved-as',e=>{const {from,to}=e.detail||{};this.replacePath(from,to);this.schedule();});
    window.addEventListener('storage',e=>{if(e.key===this.storageKey){this.preferences=this.readPreferences();this.favoritesData=this.preferences.favorites;this.closeMenu(false);this.render();void this.refreshModified();}});
    const ipc=reqnode('electron').ipcRenderer;
    ipc.on('didRename',(_e,data)=>{if(!data?.oldPath||this.projects?.handledMoves?.has(data.etMoveToken))return;this.projects?.invalidateFiles();if(data.newPath){if(data.etFolderRename)this.projects?.relocateFolder(data.oldPath,data.newPath);else this.replacePath(data.oldPath,data.newPath);}else if(data.newPath==='')this.change(db=>{for(const field of ['tabs','favorites','pinned'])db[field]=db[field].filter(t=>this.key(t.path)!==this.key(data.oldPath));});this.schedule();});
    ipc.on('didSave',()=>void this.refreshModified());
    window.addEventListener('blur',()=>{this.windowWasBlurred=!document.hasFocus();});
    window.addEventListener('focus',()=>{if(this.toolbar?.codeEditor?.panel&&!this.windowWasBlurred)return;this.windowWasBlurred=false;this.projects?.invalidateFiles();this.signature='';this.sync();void this.refreshModified();});void this.refreshModified();
    const changed=File.updateChangeCount,invoke=JSBridge.invoke;
    // Native save cancellation does not invoke library.openFile completion.
    JSBridge.invoke=function(name,...args){if((name==='app.openFile'||name==='app.openFileOrFolder')&&args[1]?.forceCreateWindow)manager.openRouter?.allowNewWindow(args[0]);const result=invoke.call(this,name,...args);if(name==='app.cancelQuit'&&manager.pending){manager.clearPending();manager.render();}return result;};
    const nativeNewWindow=File.editor.library.openFileInNewWindow;
    File.editor.library.openFileInNewWindow=function(file,isFolder){if(!isFolder&&manager.supported(file))return manager.openNewWindow(file).catch(error=>manager.notice(error.message));return nativeNewWindow.apply(this,arguments);};
    File.updateChangeCount=function(...args){const result=changed.apply(this,args);manager.schedule();return result;};
  }
  schedule(){if(!this.frame)this.frame=requestAnimationFrame(()=>{this.frame=0;this.sync();});}
  sync(){
    if(File.isFileLoading?.()||this.toolbar.readingPosition?.loading())return;
    const file=File.bundle?.filePath||'',key=this.key(file),changed=key!==this.current;this.current=key;this.file=file;
    if(this.supported(file)){const db=this.read();if(!db.tabs.some(t=>this.key(t.path)===key))this.change(d=>d.tabs.push({path:file}));}
    if(this.pending&&this.key(this.pending.path)===key){const closing=this.pending.closing;this.clearPending();if(closing&&closing!==key)this.change(db=>db.tabs=db.tabs.filter(t=>this.key(t.path)!==closing));}
    this.render();if(changed)this.rows.get(key)?.scrollIntoView({block:'nearest'});this.toolbar.splitView?.syncMain();
  }
  setFilter(){this.signature='';this.render();}
  toggleFavorite(file){const key=this.key(file);this.change(db=>{const i=db.favorites.findIndex(t=>this.key(t.path)===key);if(i>=0)db.favorites.splice(i,1);else {db.favorites.push({path:file});db.favoritesCollapsed=false;}});}
  openEntry(file){if(this.toolbar?.codeEditor?.supported(file))return this.toolbar?.codeEditor.open(file);if(this.supported(file))return this.activate(file);if(!this.toolbar?.codeEditor&&this.workspaceFile(file))return this.notice('请在插件市场启用 AI 阅读助手后打开此文件');if(file)return this.fileAction(async()=>{if(!(await this.fs.promises.stat(file)).isFile())throw Error('文件不存在');const error=await reqnode('electron').shell.openPath(this.path.normalize(file));if(error)throw Error(String(error));}).catch(e=>this.notice(e.message));}
  section(id,label,collapsed,onToggle,host=this.renderHost||this.list){
    const section=this.node('section','et-dt-group');section.dataset.section=id;section.setAttribute('aria-label',label);const head=this.node('div','et-dt-section'),toggle=this.node('button','et-dt-section-toggle');toggle.type='button';toggle.append(this.node('span','',label));toggle.insertAdjacentHTML('beforeend',this.icon('chevron'));toggle.setAttribute('aria-expanded',String(!collapsed));toggle.setAttribute('aria-label',(collapsed?'展开':'收起')+label+'分区');toggle.onclick=()=>{onToggle();this.list.querySelector('[data-section="'+id+'"] .et-dt-section-toggle')?.focus({preventScroll:true});};head.append(toggle);const body=this.node('div','et-dt-group-body');body.hidden=collapsed;section.append(head,body);host.append(section);return {section,head,body,toggle};
  }
  render(){
    if(this.projectMoveDepth||this.projects?.fileDrag){this.renderDeferred=true;return;}this.renderDeferred=false;
    this.openRouter?.localOpen?.publish();if(!this.panel)return;
    const db=this.read(),p=this.projects,dirty=!!File.isDocumentEdited?.(),sortedPins=this.sortedPins();
    const signature=JSON.stringify([db,sortedPins,this.toolbar?.codeEditor?.visibleKey(),this.current,dirty,this.pending?.path,this.busy,p?.items,p?.groupsCollapsed,p?.sections,p?.defaultFolder,p?.fileRevision]);if(signature===this.signature)return;this.signature=signature;this.rowState=this.createRowState(db,dirty);
    const control=document.activeElement,focused=control?.closest('.et-dt-row'),focusKey=focused?.dataset.key,focusKind=control?.dataset.dtControl,scroll=this.scroll.scrollTop;
    this.groupViews??=new Map();const next=[],seen=new Set(),projectKey=[p?.defaultFolder,p?.fileRevision],projectState=items=>items?.map(({expandedFolders,...item})=>item);this.empty.hidden=true;
    const group=(id,state,build)=>{seen.add(id);const key=JSON.stringify(state),cached=this.groupViews.get(id);let nodes=cached?.key===key?cached.nodes:null;if(!nodes){this.renderHost=document.createDocumentFragment();try{build();nodes=[...this.renderHost.childNodes];}finally{this.renderHost=null;}this.groupViews.set(id,{key,nodes});}next.push(...nodes);};
    group('pinned',[db.pinned,sortedPins,db.pinCollapsed,db.pinSort,this.collectionSections('pinned'),projectState(p?.items.filter(x=>x.pinned)),projectKey],()=>{
      const pinned=this.section('pinned','置顶',db.pinCollapsed,()=>this.change(d=>d.pinCollapsed=!d.pinCollapsed));
      const more=this.button('置顶排序','more');more.setAttribute('aria-haspopup','menu');more.onclick=()=>{const r=more.getBoundingClientRect();this.sortMenu({x:r.left,y:r.bottom+4},more);};pinned.head.append(more);
      if(!db.pinCollapsed){this.renderCollection('pinned',sortedPins,pinned.body);p?.renderProjects(pinned.body,true);}
    });
    if(p)group('projects',[p?.groupsCollapsed.projects,projectState(p?.items.filter(x=>!x.pinned&&!x.sectionId)),projectKey],()=>{const projects=this.section('projects','项目',!!p?.groupsCollapsed.projects,()=>p?.toggleGroup('projects'));if(p){p.renderHeader(projects.head);if(!p.groupsCollapsed.projects)p.renderProjects(projects.body,false);}});
    if(p)group('project-sections',[p?.sections,projectState(p?.items.filter(x=>!x.pinned&&x.sectionId)),projectKey],()=>p?.renderSections());
    group('favorites',[db.favorites,db.favoritesCollapsed,this.collectionSections('favorites')],()=>{const favorites=this.section('favorites','收藏',db.favoritesCollapsed,()=>this.change(d=>d.favoritesCollapsed=!d.favoritesCollapsed));if(!db.favoritesCollapsed)this.renderCollection('favorites',db.favorites,favorites.body);});
    const loose=db.tabs.filter(t=>p||!this.workspaceFile(t.path));if(!this.file)loose.push({path:'',name:'未命名文档'});
    // Reconcile open tabs in their connected container; adding or closing one tab
    // must not detach its neighbors or restart project directory reads.
    const opened=this.openedView ||= this.node('div','et-dt-loose-files');opened.setAttribute('aria-label','打开的文件');
    const old=new Map([...opened.children].map(row=>[row.dataset.key,row])),rows=loose.map(entry=>{const row=old.get(this.key(entry.path));return row&&this.path.normalize(row.dataset.path)===this.path.normalize(entry.path)&&row.dataset.name===(entry.name||this.path.basename(entry.path))?row:this.fileRow(entry);});
    const retained=new Set(rows);for(const row of [...opened.children])if(!retained.has(row))row.remove();
    rows.forEach((row,i)=>{if(opened.children[i]!==row)opened.insertBefore(row,opened.children[i]||null);});if(rows.length)next.push(opened);
    // Keep unchanged sections connected: folder lists, selections and scroll do not restart.
    next.forEach((node,i)=>{if(this.list.children[i]!==node)this.list.insertBefore(node,this.list.children[i]||null);});while(this.list.children.length>next.length)this.list.lastElementChild.remove();for(const id of this.groupViews.keys())if(!seen.has(id))this.groupViews.delete(id);
    this.rows.clear();for(const row of this.list.querySelectorAll('.et-dt-row')){this.paintRowState(row,this.rowState);if(!this.rows.has(row.dataset.key)||row.classList.contains('active')||row.closest('.et-dt-loose-files'))this.rows.set(row.dataset.key,row);}
    this.scroll.scrollTop=scroll;if(focusKey!==undefined&&!control?.isConnected)this.rows.get(focusKey)?.querySelector('[data-dt-control="'+focusKind+'"]')?.focus({preventScroll:true});
  }
  createRowState(db=this.read(),dirty=!!File.isDocumentEdited?.()){return{pinned:new Set(db.pinned.map(t=>this.key(t.path))),favorites:new Set(db.favorites.map(t=>this.key(t.path))),opened:new Set(db.tabs.map(t=>this.key(t.path))),tabCount:db.tabs.length,dirty};}
  paintRowState(row,state=this.rowState||this.createRowState()){
    const {key,path:file,name}=row.dataset,project=row.classList.contains('et-project-file-row'),visible=this.toolbar?.codeEditor?.visibleKey(),active=file?key===(visible||this.current):!this.file;
    const pinned=state.pinned.has(key),favorite=state.favorites.has(key),dirty=!!this.toolbar?.codeEditor?.hasDirty(file)||active&&!visible&&state.dirty,open=row.querySelector('.et-dt-open');
    const attr=(node,key,value)=>{value=String(value);if(node.getAttribute(key)!==value)node.setAttribute(key,value);};
    const flag=(name,on)=>{if(row.classList.contains(name)!==!!on)row.classList.toggle(name,!!on);};
    flag('active',active);flag('pending',!!this.pending&&this.key(this.pending.path)===key);attr(row,'data-pinned',row.dataset.collection==='pinned'&&pinned);
    attr(open,'aria-label',name+(dirty?'，未保存':''));if(project)this.paintSelectedRow(row,open);else attr(open,'aria-selected',active);
    const dot=open.querySelector('.et-dt-dirty');if(dirty&&!dot){const n=this.node('span','et-dt-dirty');n.title='有未保存的修改';open.append(n);}else if(!dirty)dot?.remove();
    for(const [kind,selected,label]of [['pin',pinned,'置顶'],['star',favorite,'收藏']]){const button=row.querySelector('[data-dt-control="'+kind+'"]'),text=(selected?'取消':'')+label+' '+name;attr(button,'aria-pressed',selected);attr(button,'aria-label',text);attr(button,'title',text);}
    const close=row.querySelector('.et-dt-close'),hidden=project||!!file&&!state.opened.has(key);if(close.hidden!==hidden)close.hidden=hidden;attr(close,'title',active&&state.tabCount<2?'关闭最后一个标签及当前窗口':'关闭标签 '+name);
  }
  fileRow(entry,{pinGroup=false,project=false,favoriteGroup=false}={}){
    const state=this.rowState||this.createRowState(),key=this.key(entry.path),active=!!entry.path?key===(this.toolbar?.codeEditor?.visibleKey()||this.current):!this.file,name=entry.name||this.path.basename(entry.path),pinned=state.pinned.has(key),favorite=state.favorites.has(key),opened=state.opened.has(key),row=this.node('div','et-dt-row'+(project?' et-project-file-row':''));
    row.dataset.key=key;row.dataset.path=entry.path;row.dataset.name=name;row.dataset.collection=pinGroup?'pinned':favoriteGroup?'favorites':'';row.dataset.collectionSection=entry.sectionId||'';row.dataset.pinned=String(pinGroup&&pinned);row.classList.toggle('active',active);row.classList.toggle('pending',!!this.pending&&this.key(this.pending.path)===key);
    const open=this.node('button','et-dt-open');open.type='button';open.dataset.dtControl='open';open.setAttribute('role','tab');open.setAttribute('aria-selected',String(active));open.setAttribute('aria-label',name+(active&&File.isDocumentEdited?.()?'，未保存':''));open.title=entry.path||name;
    const fileIcon=this.node('span','et-dt-file-icon');fileIcon.innerHTML=this.fileIcon(entry.path);fileIcon.dataset.language=/\.pyw?$/i.test(entry.path)?'python':'document';const text=this.node('span','et-dt-text'),title=this.node('span','et-dt-name',name.replace(/\.(md|markdown|mdown|mkd|mkdn)$/i,''));text.append(title);open.append(fileIcon,text);if(this.toolbar?.codeEditor?.hasDirty(entry.path)||active&&!this.toolbar?.codeEditor?.visibleKey()&&File.isDocumentEdited?.()){const dot=this.node('span','et-dt-dirty');dot.title='有未保存的修改';open.append(dot);}if(project){row.dataset.projectId=String(project);open.setAttribute('role','option');open.title='';open.onclick=e=>this.selectProjectFile(row,e);open.ondblclick=e=>{if(!e.ctrlKey&&!e.metaKey&&!e.shiftKey)this.openEntry(entry.path);};open.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();e.stopPropagation();this.openEntry(entry.path);}else if(e.key===' '){e.preventDefault();this.selectProjectFile(row,e);}else if(e.key==='Escape'){e.preventDefault();this.fileSelection.clear();this.selectionAnchor=null;this.paintFileSelection();}};this.paintSelectedRow(row,open);}else open.onclick=()=>this.openEntry(entry.path);
    const pin=this.button((pinned?'取消置顶 ':'置顶 ')+name,'pin');pin.dataset.dtControl='pin';pin.classList.add('et-dt-pin');pin.setAttribute('aria-pressed',String(pinned));pin.disabled=!entry.path;pin.onclick=()=>this.togglePin(entry.path);
    const star=this.button((favorite?'取消收藏 ':'收藏 ')+name,'star');star.dataset.dtControl='star';star.classList.add('et-dt-star');star.setAttribute('aria-pressed',String(favorite));star.disabled=!entry.path;star.onclick=()=>this.toggleFavorite(entry.path);
    const close=this.button('关闭标签 '+name,'close');close.dataset.dtControl='close';close.classList.add('et-dt-close');close.hidden=project||!!entry.path&&!opened;if(active&&state.tabCount<2)close.title='关闭最后一个标签及当前窗口';close.onclick=()=>this.close(key);
    row.append(open,pin,star,close);this.paintRowState(row,state);row.oncontextmenu=e=>{e.preventDefault();e.stopPropagation();if(project&&!this.fileSelection.has(key))this.selectProjectFile(row,{});this.rowMenu(entry.path,{x:e.clientX,y:e.clientY},open);};if(pinGroup)this.bindDrag(row);if(favoriteGroup)this.bindSort(row,{kind:"favorite",group:'favorites:'+(entry.sectionId||''),key,move:(...args)=>this.moveFavorite(...args)});if(!this.rows.has(key)||active)this.rows.set(key,row);this.toolbar.splitView?.bindTab(row);this.bindReferenceDrag(row);return row;
  }
  paintSelectedRow(row,button=row.querySelector('.et-dt-open')){const selected=this.fileSelection?.has(row.dataset.key)||false;if(row.classList.contains('selected')!==selected)row.classList.toggle('selected',selected);if(button?.getAttribute('aria-selected')!==String(selected))button?.setAttribute('aria-selected',String(selected));}
  paintFileSelection(){for(const row of this.list.querySelectorAll('.et-project-file-row'))this.paintSelectedRow(row);}
  selectProjectFile(row,event={}){
    const key=row.dataset.key,additive=event.ctrlKey||event.metaKey,rows=event.shiftKey?[...this.list.querySelectorAll('.et-project-file-row')].filter(r=>r.dataset.projectId===row.dataset.projectId&&r.getClientRects().length):[],anchor=rows.findIndex(r=>r.dataset.key===this.selectionAnchor),target=rows.indexOf(row);
    if(event.shiftKey&&anchor>=0&&target>=0){if(!additive)this.fileSelection.clear();for(const r of rows.slice(Math.min(anchor,target),Math.max(anchor,target)+1))this.fileSelection.set(r.dataset.key,r.dataset.path);}
    else {if(!additive)this.fileSelection.clear();if(additive&&this.fileSelection.has(key))this.fileSelection.delete(key);else this.fileSelection.set(key,row.dataset.path);this.selectionAnchor=key;}
    this.paintFileSelection();
  }
  moveFavorite(key,target,after=false){this.change(db=>{const i=db.favorites.findIndex(t=>this.key(t.path)===key),j=db.favorites.findIndex(t=>this.key(t.path)===target);if(i<0||j<0||i===j||(db.favorites[i].sectionId||'')!==(db.favorites[j].sectionId||''))return;const [item]=db.favorites.splice(i,1);db.favorites.splice(db.favorites.findIndex(t=>this.key(t.path)===target)+(after?1:0),0,item);});}
  bindDrag(row){this.bindSort(row,{kind:'pinned',group:'pinned:'+(row.dataset.collectionSection||''),key:row.dataset.key,enabled:this.preferences.pinSort==='manual',move:(key,target,after)=>this.movePin(key,target,after)});}
  bindReferenceDrag(row){
    const file=row.dataset.path,code=!!this.toolbar.codeEditor?.supported(file);if(!file||(!this.supported(file)&&!code)||(row._etReferenceDrag&&row._etReferenceDrag===row.ondragstart))return;
    row.draggable=true;const previous=row.ondragstart;row.ondragstart=row._etReferenceDrag=e=>{if(e.target.closest('button:not(.et-dt-open)')){e.preventDefault();return;}previous?.(e);if(e.defaultPrevented)return;e.dataTransfer.setData(code?'application/x-et-code-file':'application/x-et-document-tab',file);e.dataTransfer.effectAllowed='copyMove';};
  }
  bindSort(row,{kind,group,key,move,enabled=true}){
    row.draggable=enabled||!!row.dataset.path&&(this.supported(row.dataset.path)||!!this.toolbar.codeEditor?.supported(row.dataset.path));row.dataset.sortKind=kind;
    row.ondragstart=e=>{if(!row.draggable||e.target.closest('.et-dt-pin,.et-dt-star,.et-dt-close,.et-project-more')){e.preventDefault();return;}this.sortDrag=enabled?{kind,group,key}:null;e.dataTransfer.effectAllowed=enabled?'move':'copy';if(enabled)e.dataTransfer.setData('application/x-et-sidebar-order',key);if(this.toolbar.codeEditor?.supported(row.dataset.path)){e.dataTransfer.effectAllowed='copyMove';e.dataTransfer.setData('application/x-et-code-file',row.dataset.path);}row.classList.add('dragging');e.stopPropagation();};
    const accepts=()=>enabled&&row.draggable&&this.sortDrag?.kind===kind&&this.sortDrag.group===group&&this.sortDrag.key!==key;
    row.ondragover=e=>{if(!accepts())return;e.preventDefault();e.stopPropagation();e.dataTransfer.dropEffect='move';const after=e.clientY>row.getBoundingClientRect().top+row.offsetHeight/2;if(this.dropMarker?.row!==row||this.dropMarker.after!==after){this.dropMarker?.row.classList.remove('drop-before','drop-after');row.classList.remove('drop-before','drop-after');row.classList.add(after?'drop-after':'drop-before');this.dropMarker={row,after};}const scroll=this.scroll||this.list,rect=scroll.getBoundingClientRect();if(e.clientY<rect.top+28)scroll.scrollTop-=12;else if(e.clientY>rect.bottom-28)scroll.scrollTop+=12;};
    row.ondrop=e=>{if(!accepts())return;e.preventDefault();e.stopPropagation();const source=this.sortDrag.key,after=e.clientY>row.getBoundingClientRect().top+row.offsetHeight/2;this.clearDrag();move(source,key,after);};
    row.ondragend=()=>this.clearDrag();this.toolbar.splitView?.bindTab(row);this.bindReferenceDrag(row);
  }
  clearDrag(){this.sortDrag=null;this.dropMarker=null;for(const row of this.list.querySelectorAll('.dragging,.drop-before,.drop-after'))row.classList.remove('dragging','drop-before','drop-after');}
  closeSubmenu(restore=false){if(!this.submenu)return;this.submenu.remove();this.submenu=null;this.submenuAnchor?.setAttribute('aria-expanded','false');if(restore)this.submenuAnchor?.focus({preventScroll:true});this.submenuAnchor=null;}
  closeMenu(restore=true){this.closeSubmenu();if(!this.menu)return;this.menu.remove();this.menu=null;this.menuAnchor?.setAttribute('aria-expanded','false');if(restore&&this.menuAnchor?.isConnected)this.menuAnchor.focus();this.menuAnchor=null;}
  fillMenu(menu,items,child=false){
    for(const item of items){
      if(!item){const divider=this.node('div','et-dt-separator');divider.setAttribute('role','separator');menu.append(divider);continue;}
      const b=this.node('button','et-dt-menu-item');b.type='button';b.setAttribute('role',item.checked===undefined?'menuitem':'menuitemradio');if(item.checked!==undefined)b.setAttribute('aria-checked',String(item.checked));b.disabled=!!item.disabled;b.dataset.action=item.id;b.classList.toggle('danger',!!item.danger);
      if(item.icon){const icon=this.node('span','et-dt-menu-icon');icon.innerHTML=item.icon;b.append(icon);}b.append(this.node('span','et-dt-menu-label',item.label));if(item.checked)b.insertAdjacentHTML('beforeend',this.icon('check'));if(item.hint)b.append(this.node('span','et-dt-shortcut',item.hint));
      if(item.children){b.setAttribute('aria-haspopup','menu');b.setAttribute('aria-expanded','false');const arrow=this.node('span','et-dt-submenu-arrow');arrow.innerHTML=this.icon('chevron');b.append(arrow);b.onmouseenter=()=>this.openSubmenu(item,b);b.onclick=()=>this.openSubmenu(item,b,true);b.onkeydown=e=>{if(e.key==='ArrowRight'){e.preventDefault();e.stopPropagation();this.openSubmenu(item,b,true);}};}
      else {b.onclick=()=>{this.closeMenu();void Promise.resolve().then(item.run).catch(error=>this.notice('操作失败：'+(error.message||error)));};if(!child)b.onmouseenter=()=>this.closeSubmenu();}
      menu.append(b);
    }
    for(const type of ['pointerdown','mousedown','click','contextmenu'])menu.addEventListener(type,e=>{e.stopPropagation();if(type==='contextmenu')e.preventDefault();});
    menu.onkeydown=e=>{e.stopPropagation();const buttons=[...menu.querySelectorAll('button:not(:disabled)')],i=buttons.indexOf(document.activeElement);if(child&&(e.key==='ArrowLeft'||e.key==='Escape')){e.preventDefault();this.closeSubmenu(true);}else if(e.key==='Escape'||e.key==='Tab'){e.preventDefault();this.closeMenu();}else if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){e.preventDefault();buttons[e.key==='Home'?0:e.key==='End'?buttons.length-1:(i+(e.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length]?.focus();}};
  }
  openSubmenu(item,anchor,focus=false){
    if(!this.menu?.isConnected||!anchor.isConnected)return;
    if(this.submenuAnchor===anchor&&this.submenu?.isConnected){if(focus)this.submenu.querySelector('button:not(:disabled)')?.focus();return;}
    this.closeSubmenu();const submenu=this.node('div','et-dt-menu et-project-menu et-dt-submenu');submenu.setAttribute('role','menu');submenu.setAttribute('aria-label',item.label);this.submenu=submenu;this.submenuAnchor=anchor;anchor.setAttribute('aria-expanded','true');this.fillMenu(submenu,typeof item.children==='function'?item.children():item.children,true);document.body.append(submenu);
    const parent=this.menu.getBoundingClientRect(),a=anchor.getBoundingClientRect(),r=submenu.getBoundingClientRect(),x=parent.right+3+r.width<=innerWidth-8?parent.right+3:parent.left-r.width-3;submenu.style.left=Math.max(8,Math.min(x,innerWidth-r.width-8))+'px';submenu.style.top=Math.max(8,Math.min(a.top-5,innerHeight-r.height-8))+'px';if(focus)submenu.querySelector('button:not(:disabled)')?.focus({preventScroll:true});
  }
  showMenu(items,point,anchor,label,cls=''){
    this.closeMenu(false);const menu=this.node('div','et-dt-menu '+cls);menu.setAttribute('role','menu');menu.setAttribute('aria-label',label);this.menu=menu;this.menuAnchor=anchor;this.menuScrollTop=this.scroll.scrollTop;this.menuScrollLeft=this.scroll.scrollLeft;anchor?.setAttribute('aria-expanded','true');this.fillMenu(menu,items);
    document.body.append(menu);const rect=menu.getBoundingClientRect(),a=anchor?.getBoundingClientRect();let x=point.align==='end'&&a?a.right-rect.width:point.x;if(point.align==='end'&&a&&x<8&&a.left+rect.width<=innerWidth-8)x=a.left;if(cls.includes('et-project-row-menu')&&a&&x+rect.width>innerWidth-8)x=a.right-rect.width;menu.style.left=Math.max(8,Math.min(x,innerWidth-rect.width-8))+'px';menu.style.top=Math.max(8,Math.min(point.y+rect.height>innerHeight-8?(a?.top??point.y)-rect.height-4:point.y,innerHeight-rect.height-8))+'px';menu.querySelector('button:not(:disabled)')?.focus({preventScroll:true});
  }
  sortMenu(point,anchor){this.showMenu([{id:'recent',label:'最近更新',checked:this.preferences.pinSort==='updated_at',run:()=>{this.change(db=>db.pinSort='updated_at');void this.refreshModified();}},{id:'manual',label:'手动排序',checked:this.preferences.pinSort==='manual',run:()=>this.change(db=>db.pinSort='manual')}],point,anchor,'置顶排序','et-project-row-menu et-pin-sort-menu');}
  rowMenu(file,point,anchor){
    const selected=anchor?.closest('.et-project-file-row')&&this.fileSelection.has(this.key(file))?[...this.fileSelection.values()]:[file];if(selected.length>1){this.showMenu([{id:'delete',label:'删除 '+selected.length+' 个文件',danger:true,disabled:!!this.busy||!!this.pending,run:()=>this.fileAction(()=>this.deleteFiles(selected))}],point,anchor,'文件操作');return;}
    const key=this.key(file),pinned=this.preferences.pinned.some(t=>this.key(t.path)===key),disabled=!file||!!this.busy||!!this.pending,items=[
      {id:'open',label:'打开',disabled,run:()=>this.openEntry(file)},
      {id:'new-window',label:'在新窗口中打开',disabled:disabled||!this.supported(file),run:()=>this.openNewWindow(file)},null,
      {id:'pin',label:pinned?'取消置顶':'置顶',disabled:!file,run:()=>this.togglePin(file)}];
    const illustrator=typeof ETIllustratorLauncher!=='undefined'&&ETIllustratorLauncher.supports(file);if(illustrator)items.splice(1,0,{id:'illustrator',label:'使用 Adobe Illustrator 打开',disabled,run:()=>this.fileAction(()=>this.openInIllustrator(file))});
    if(pinned&&this.preferences.pinSort==='manual'){const section=this.preferences.pinned.find(t=>this.key(t.path)===key)?.sectionId||'',pins=this.preferences.pinned.filter(t=>(t.sectionId||'')===section),i=pins.findIndex(t=>this.key(t.path)===key);items.push({id:'up',label:'上移',hint:'Alt+↑',disabled:i===0,run:()=>this.movePin(key,this.key(pins[i-1].path))},{id:'down',label:'下移',hint:'Alt+↓',disabled:i===pins.length-1,run:()=>this.movePin(key,this.key(pins[i+1].path),true)});}
    items.push({id:'favorite',label:this.favoritesData.some(t=>this.key(t.path)===key)?'取消收藏':'收藏',disabled:!file,icon:this.icon('star'),run:()=>this.toggleFavorite(file)},null,{id:'rename',label:'重命名',hint:'F2',disabled:disabled||!(this.supported(file)||this.toolbar?.codeEditor?.supported(file)&&this.projects?.contains(file)),run:()=>this.renameDialog(file)},{id:'duplicate',label:'创建副本',disabled:disabled||!this.supported(file),run:()=>this.fileAction(()=>this.duplicate(file))},{id:'delete',label:'删除',danger:true,disabled:disabled||!(this.supported(file)||this.projects?.contains(file)),run:()=>this.fileAction(()=>this.deleteFile(file))},null,{id:'copy-path',label:'复制文件路径',disabled:!file,run:async()=>{await navigator.clipboard.writeText(this.path.normalize(file));this.notice('已复制文件路径');}},{id:'reveal',label:'打开文件位置',disabled:!file,run:()=>JSBridge.showInFinder(this.path.normalize(file))});
    const collection=anchor?.closest('.et-dt-row')?.dataset.collection;if(['pinned','favorites'].includes(collection)){items.splice(items.findIndex(item=>item?.id==='pin'),0,{id:'collection-new',label:'新建分区…',run:()=>this.collectionDialog(collection,file)},{id:'collection-move',label:'移至分区',children:()=>this.collectionMenu(collection,file)},null);}
    this.showMenu(items,point,anchor,'标签页操作',illustrator?'et-dt-illustrator-menu':'');
  }
  async openInIllustrator(file){
    const launcher=this.illustrator??=new ETIllustratorLauncher(reqnode),storageKey='et-illustrator-2026-executable-v1';
    const checkDraft=()=>{const editor=this.toolbar?.codeEditor,r=editor?.records.get(this.key(file));if(r&&editor.dirty(r))throw Error('此文件有未保存的修改，请先保存后再用 Illustrator 打开');};
    checkDraft();await launcher.file(file);let saved='';try{saved=localStorage.getItem(storageKey)||'';}catch{}
    let exe=saved&&await launcher.executable(saved)?saved:saved?'':await launcher.discover();
    const choose=async()=>{
      for(;;){const result=await JSBridge.invoke('dialog.showOpenDialog',{title:saved?'Illustrator 路径已失效，请选择 Illustrator.exe':'选择 Adobe Illustrator 的 Illustrator.exe',defaultPath:saved?this.path.dirname(saved):undefined,properties:['openFile'],filters:[{name:'Illustrator 可执行程序',extensions:['exe']}]});
        if(result?.canceled||!result?.filePaths?.[0])return '';
        const selected=result.filePaths[0];if(await launcher.executable(selected))return selected;
        const retry=await JSBridge.invoke('dialog.showMessageBox',{type:'error',title:'请选择 Illustrator 程序',message:'请选择 Adobe Illustrator 安装目录中的 Illustrator.exe。',detail:'通常位于 Support Files → Contents → Windows 文件夹中。',buttons:['重新选择','取消'],defaultId:0,cancelId:1,noLink:true});if(retry?.response!==0)return '';
      }
    };
    if(!exe)exe=await choose();if(!exe)return false;checkDraft();
    try{await launcher.launch(exe,file);}catch(error){
      if(!['ENOENT','ET_ILLUSTRATOR_PATH'].includes(error.code))throw Error('无法启动 Illustrator：'+error.message);
      // A missing document must not be mistaken for a moved application.
      await launcher.file(file);saved=exe;exe=await choose();if(!exe)return false;checkDraft();await launcher.launch(exe,file);
    }
    try{localStorage.setItem(storageKey,exe);}catch{this.notice('已发送到 Illustrator，但程序路径未能保存；下次可能需要重新选择。');return true;}
    this.notice('已发送到 Adobe Illustrator');return true;
  }
  async fileAction(action){if(this.busy||this.pending)return;this.busy=true;try{return await action();}finally{this.busy=false;this.schedule();}}
  async requireFile(file,allowProject=false){if(!this.supported(file)){const p=allowProject&&this.projects?.items.find(p=>p.trusted&&this.key(file).startsWith(this.key(p.root).replace(/\/$/,'')+'/'));if(!p)throw Error('文件不存在或不是 Markdown 文件');await this.projects.core.existingFile(p,file);}const stat=await this.fs.promises.lstat(file);if(!stat.isFile()||stat.isSymbolicLink())throw Error('文件不存在或不是普通文件');return stat;}
  async openNewWindow(file){await this.requireFile(file);await File.backupDocumentSnap();await JSBridge.invoke('app.openFileOrFolder',this.path.normalize(file),{forceCreateWindow:true,mountFolder:File.getMountFolder()});}
  renameDialog(file){
    if(this.renameWindow||this.busy||this.pending)return;const dialog=this.node('dialog','et-dt-rename'),form=this.node('form'),heading=this.node('h3','','重命名'),input=this.node('input'),error=this.node('div','et-dt-rename-error'),footer=this.node('div','et-dt-rename-footer'),cancel=this.node('button','','取消'),save=this.node('button','primary','保存');
    heading.id='et-dt-rename-title';dialog.setAttribute('aria-labelledby',heading.id);input.value=this.path.basename(file);input.setAttribute('aria-label','文件名');input.autocomplete='off';input.spellcheck=false;error.setAttribute('role','alert');cancel.type='button';save.type='submit';footer.append(cancel,save);form.append(heading,input,error,footer);dialog.append(form);this.renameWindow=dialog;const anchor=this.rows.get(this.key(file))?.querySelector('.et-dt-open');const close=()=>{if(this.busy)return;dialog.close();dialog.remove();this.renameWindow=null;(this.rows.get(this.current)?.querySelector('.et-dt-open')||anchor)?.focus();};cancel.onclick=close;dialog.oncancel=e=>{e.preventDefault();close();};for(const type of ['mousedown','keydown','click','contextmenu'])dialog.addEventListener(type,e=>e.stopPropagation());
    form.onsubmit=async e=>{e.preventDefault();if(this.busy)return;save.disabled=true;cancel.disabled=true;input.disabled=true;error.textContent='';try{await this.fileAction(()=>this.rename(file,input.value));close();}catch(e){error.textContent=e.message||String(e);input.disabled=false;input.focus();}finally{save.disabled=false;cancel.disabled=false;input.disabled=false;}};
    document.body.append(dialog);dialog.showModal();input.focus();input.setSelectionRange(0,Math.max(0,input.value.length-this.path.extname(input.value).length));
  }
  async rename(file,name){
    name=name.trim();if(!name||/[\\/:*?"<>|\x00-\x1f]/.test(name)||/[. ]$/.test(name)||/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(name))throw Error('请输入有效的文件名，不含路径或特殊字符。');
    if(!this.path.extname(name))name+=this.path.extname(file);if(!this.supported(file)&&this.toolbar?.codeEditor?.supported(file)){if(!this.toolbar.codeEditor.supported(name=this.path.join(this.path.dirname(file),name)))throw Error('请保留受支持的代码文件扩展名');return this.renameCode(file,this.path.basename(name));}const target=this.path.join(this.path.dirname(file),name);if(!this.supported(target))throw Error('请保留 Markdown 扩展名，如 .md');if(target===this.path.normalize(file))return;
    await this.requireFile(file);if(this.key(file)!==this.key(target)){try{await this.fs.promises.lstat(target);throw Error('已有同名文件，请换一个名称。');}catch(e){if(e.code!=='ENOENT')throw e;}}
    const library=File.editor.library;library.pauseOnChange();await JSBridge.invoke('app.sendEvent','willRename',{oldPath:this.path.normalize(file)});let renamed=false;
    try{await reqnode('fs-extra').move(file,target,{overwrite:false});renamed=true;this.replacePath(file,target);await JSBridge.invoke('filesOp.registerUndo',target,file,'重命名 '+this.path.basename(file));}
    finally{await JSBridge.invoke('app.sendEvent','didRename',{oldPath:this.path.normalize(file),newPath:renamed?target:this.path.normalize(file)});library.resumeOnChange();this.schedule();}
    this.notice('已重命名为 '+name);
  }
  async renameCode(file,name){
    const p=this.projects,code=this.toolbar.codeEditor;p.read();const project=ETCodeWorkspace.owner(reqnode,p.items,file);if(!project?.trusted)throw Error('请在所属项目中重命名');const library=File.editor.library;library.pauseOnChange();let result;
    try{await JSBridge.invoke('app.sendEvent','willRename',{oldPath:file});result=await p.core.renameFile(project,file,name);this.replacePath(result.from,result.to);await JSBridge.invoke('filesOp.registerUndo',result.to,result.from,'重命名 '+name).catch(()=>{});}
    finally{await JSBridge.invoke('app.sendEvent','didRename',{oldPath:file,newPath:result?.to||file}).catch(()=>{});library.resumeOnChange();p.invalidateFiles(project.id);this.schedule();}this.notice('已重命名为 '+name);return result;
  }
  async duplicate(file){
    await this.requireFile(file);const ext=this.path.extname(file),base=this.path.basename(file,ext),folder=this.path.dirname(file);let target;
    for(let n=1;n<=9999;n++){target=this.path.join(folder,base+' - 副本'+(n===1?'':' '+n)+ext);try{await this.fs.promises.copyFile(file,target,this.fs.constants.COPYFILE_EXCL);break;}catch(e){if(e.code!=='EEXIST'||n===9999)throw e;}}
    this.change(db=>db.tabs.push({path:target}));this.filter='all';this.render();this.notice('已创建 '+this.path.basename(target)+(this.key(file)===this.current&&File.isDocumentEdited()?'（使用磁盘上已保存的内容）':''));return target;
  }
  async deleteFile(file){return this.deleteFiles([file]);}
  async deleteFiles(files){
    files=[...new Map(files.filter(Boolean).map(file=>[this.key(file),file])).values()];if(!files.length)return false;
    if([...this.toolbar?.notebook?.records.values()||[]].some(r=>r.running&&files.some(f=>this.key(f)===this.key(r.file))))throw Error('请先中断 Notebook 运行后再删除');
    const dirty=()=>files.some(file=>this.toolbar?.codeEditor?.hasDirty(file)||this.key(file)===this.key(File.bundle?.filePath)&&File.isDocumentEdited());if(dirty()){this.notice('当前文档有未保存的修改，请先保存后再删除。');return false;}
    const before=await Promise.all(files.map(file=>this.requireFile(file,true))),label=files.length===1?'“'+this.path.basename(files[0])+'”':files.length+' 个文件';
    const options={type:'warning',title:'删除文件',message:'将'+label+'移到回收站？',buttons:['移到回收站','取消'],defaultId:1,cancelId:1,noLink:true};
    if(files.length>1)options.detail=files.slice(0,12).map(file=>this.path.basename(file)).join('\n')+(files.length>12?'\n…':'');
    const result=await JSBridge.invoke('dialog.showMessageBox',options);if(result?.response!==0||dirty())return false;
    // Recheck the complete selection before deleting any file after the confirmation.
    for(let i=0;i<files.length;i++){const current=await this.requireFile(files[i],true),old=before[i];if(current.ino!==old.ino||current.size!==old.size||current.mtimeMs!==old.mtimeMs)throw Error('文件已发生变化，请重新确认删除');}
    const removed=[],failures=[];
    for(const file of files){try{if(!await JSBridge.invoke('shell.trashItem',this.path.normalize(file)))throw Error('无法移到回收站');removed.push(file);}catch(error){failures.push(this.path.basename(file)+'：'+error.message);}}
    for(const file of removed){this.fileSelection?.delete(this.key(file));try{await JSBridge.invoke('app.sendEvent','didRename',{oldPath:this.path.normalize(file),newPath:''});if(this.key(File.bundle?.filePath)===this.key(file))window.doApplyRename?.(null);await JSBridge.invoke('app.sendEvent','updateQuickOpenCache',{toDel:this.path.normalize(file)});}catch(error){failures.push(this.path.basename(file)+'：刷新失败，'+error.message);}}
    if(removed.length){await this.toolbar?.codeEditor?.forgetFiles(f=>removed.some(file=>this.key(file)===this.key(f)));const keys=new Set(removed.map(file=>this.key(file)));this.signature='';this.change(db=>{for(const field of ['tabs','favorites','pinned'])db[field]=db[field].filter(t=>!keys.has(this.key(t.path)));});this.schedule();}
    if(failures.length)throw Error((removed.length?'已移到回收站 '+removed.length+' 个文件；':'')+failures.join('；'));
    this.notice(files.length===1?'文件已移到回收站。':files.length+' 个文件已移到回收站。');return true;
  }
  clearPending(){clearTimeout(this.pendingTimer);this.pending=null;}
  async activate(file,closing){
    this.toolbar?.codeEditor?.hide();
    if(!file||this.key(file)===this.current||this.pending)return;
    const request={path:file,closing};this.pending=request;this.render();
    this.pendingTimer=setTimeout(()=>{this.clearPending();this.sync();},30000);
    try{
      if(!(await this.fs.promises.stat(file)).isFile())throw Error('不是文件');
      if(this.pending!==request)return;
      // Use the native switch so unsaved edits keep Typora's Save / Cancel behavior.
      File.editor.library.openFile(this.path.normalize(file),()=>{setTimeout(()=>{this.sync();if(this.pending===request){this.clearPending();this.render();}},0);});
    }catch{if(this.pending!==request)return;this.clearPending();this.render();this.notice('无法打开文件，可能已移动或删除：'+this.path.basename(file));}
  }
  lastTab(file){const key=this.key(file),paths=[...this.read().tabs.map(t=>t.path),...[...this.toolbar?.codeEditor?.records.values()||[]].map(r=>r.file),...[...this.toolbar?.notebook?.records.values()||[]].map(r=>r.file)];return paths.every(f=>this.key(f)===key);}
  closeWindow(){return JSBridge.invoke('window.close');}
  close(key){
    const nb=this.toolbar.notebook,nr=[...nb?.records.values()||[]].find(r=>this.key(r.file)===key);if(nr)return nb.close(nr);
    const code=this.toolbar?.codeEditor,entry=this.read().tabs.find(t=>this.key(t.path)===key);if(entry&&code?.supported(entry.path)){const r=code.records.get(code.key(entry.path));if(r)return code.close(r);if(this.lastTab(entry.path))return this.closeWindow();this.change(db=>db.tabs=db.tabs.filter(t=>this.key(t.path)!==key));return;}
    const tabs=this.read().tabs,i=tabs.findIndex(t=>this.key(t.path)===key);if(this.pending)return;
    if(key===this.current){const next=tabs[i+1]||tabs[i-1];if(next)this.activate(next.path,key);else void JSBridge.invoke('window.close');return;}
    if(i<0)return;
    this.change(db=>db.tabs=db.tabs.filter(t=>this.key(t.path)!==key));
  }
  async createFile(){
    if(this.creating||this.pending)return;this.creating=true;this.add.disabled=true;
    try{
      const folder=this.projects?.active()?.root||this.toolbar.knowledgeLibrary?.rootPath||(this.file?this.path.dirname(this.file):File.getMountFolder?.());
      const result=await JSBridge.invoke('dialog.showSaveDialog',{title:'创建文件',defaultPath:folder?this.path.join(folder,'未命名'):'未命名',properties:['saveFile'],filters:[{name:'所有文件',extensions:['*']}]});
      if(result?.canceled||!result?.filePath)return;
      const file=result.filePath;
      // Exclusive creation never truncates an existing document, even if the picker confirms replacement.
      const handle=await this.fs.promises.open(file,'wx');await handle.close();
      this.notice('已创建 '+this.path.basename(file));if(this.supported(file)){this.filter='all';this.change(db=>db.tabs.push({path:file}));await this.activate(file);}
    }catch(error){this.notice(error.code==='EEXIST'?'这个文件已存在，请换一个新文件名。':'无法新建文件：'+(error.message||'请检查保存位置'));}
    finally{this.creating=false;this.add.disabled=false;}
  }
}
