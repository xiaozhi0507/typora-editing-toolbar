const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const W=require('./code-workspace.cjs'),Projects=require('./document-projects.cjs'),{TerminalSession}=require('./terminal-session.cjs');
const enabled=process.platform==='win32'&&process.env.ET_TERMINAL_NATIVE_TEST==='1'&&!!process.env.ET_TERMINAL_PYTHON_EXE;
const scratch=process.env.ET_TERMINAL_TEST_DIR||'C:/Users/xiaozhi/Downloads/codex-temp/terminal-native-tests';
const until=async fn=>{const end=Date.now()+15000;while(!fn()){if(Date.now()>end)throw Error('Python terminal timed out');await new Promise(r=>setTimeout(r,30));}};
for(const mode of ['success','error','input','stop'])test('Python workspace native execution: '+mode,{skip:!enabled,timeout:25000},async t=>{
 fs.mkdirSync(scratch,{recursive:true});const root=fs.mkdtempSync(path.join(scratch,'workspace-')),project={id:root,root,trusted:true,outputFolder:'results'},file=path.join(root,"中文 ' $代码.py"),dest=path.join(root,'results');fs.mkdirSync(dest);
 fs.writeFileSync(file,mode==='error'?'raise RuntimeError("EXPECTED_FAILURE")':mode==='input'?'print("INPUT_READY", flush=True)\nx=input()\nprint("REPLY="+x, flush=True)':mode==='stop'?'import time\nprint("STOP_READY", flush=True)\ntime.sleep(100)':'import os,json,pathlib\npathlib.Path("result.json").write_text(json.dumps(dict(cwd=os.getcwd(),root=os.environ["ET_PROJECT_ROOT"],script=os.environ["ET_SCRIPT_DIR"])))\nprint("RESULT_READY",flush=True)');
 let output='';const errors=[],s=new TerminalSession(require,{onData:(b,ack)=>{output+=b.toString('utf8');ack();},onError:e=>errors.push(e.message)});
 t.after(async()=>{s.stop();await until(()=>!s.child||s.state==='exited');assert(path.resolve(root).startsWith(path.resolve(scratch)+path.sep));fs.rmSync(root,{recursive:true,force:true});});
 const plan=await W.context(require,Projects,[project],file);await s.start({host:path.resolve(__dirname,'../plugin/editing-toolbar.terminal.exe'),profile:'powershell',cwd:plan.cwd,cols:160,rows:30,environment:{...process.env,...plan.env},command:W.pythonCommand(process.env.ET_TERMINAL_PYTHON_EXE,file)});
 if(mode==='input'){await until(()=>output.includes('INPUT_READY'));s.write('回答内容\r');}
 if(mode==='stop'){await until(()=>output.includes('STOP_READY'));s.stop();}
 await until(()=>s.state==='exited');assert.deepEqual(errors,[]);
 if(mode==='success'){assert.equal(s.exitCode,0);const actual=JSON.parse(fs.readFileSync(path.join(dest,'result.json'),'utf8'));assert.equal(actual.cwd,dest);assert.equal(actual.root,root);assert.equal(actual.script,root);assert(!fs.existsSync(path.join(root,'result.json')));}
 if(mode==='error'){assert.notEqual(s.exitCode,0);assert.match(output,/EXPECTED_FAILURE/);}
 if(mode==='input'){assert.equal(s.exitCode,0);assert.match(output,/REPLY=回答内容/);}
});
