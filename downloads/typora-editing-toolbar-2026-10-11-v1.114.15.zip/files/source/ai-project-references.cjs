'use strict';
// Read-only project references; editable text continues through AICodeFiles.
class ProjectReferences {
 constructor(req,attachments,pdf){this.fs=req('fs').promises;this.path=req('path');this.Buffer=req('buffer').Buffer;this.attachments=attachments;this.pdf=pdf;}
 static kind(file,supported){if(supported(file))return 'editable';if(/\.(png|jpe?g|webp)$/i.test(file))return 'image';if(/\.pdf$/i.test(file))return 'pdf';if(/\.(md|markdown|mdown|mkd|mkdn)$/i.test(file))return 'text';return '';}
 guard(signal){if(signal?.aborted)throw Object.assign(Error('已停止读取文件'),{name:'AbortError'});}
 async read(target,signal){
  this.guard(signal);const file=target.file,name=this.path.basename(file),kind=ProjectReferences.kind(file,()=>false);
  if(!kind)throw Error(name+'：此文件不能作为阅读参考');
  if(kind==='pdf'){
   const handle=await this.fs.open(file,'r');let bytes;
   try{const stat=await handle.stat();if(!stat.isFile()||stat.size>10*1024*1024)throw Error(name+'：PDF 超过 10 MB');bytes=this.Buffer.alloc(stat.size+1);let bytesRead=0;while(bytesRead<bytes.length){this.guard(signal);const read=await handle.read(bytes,bytesRead,bytes.length-bytesRead,bytesRead);if(!read.bytesRead)break;bytesRead+=read.bytesRead;}const end=await handle.stat();if(bytesRead!==stat.size||end.mtimeMs!==stat.mtimeMs||end.size!==stat.size)throw Error(name+'：读取期间文件已变化');bytes=bytes.subarray(0,bytesRead);}finally{await handle.close();}
   this.guard(signal);if(!bytes.subarray(0,1024).includes(this.Buffer.from('%PDF-')))throw Error(name+'：不是有效 PDF');
   const text=await this.pdf(new Uint8Array(bytes),signal);this.guard(signal);return {kind,name,text};
  }
  const entry=await this.attachments.describe(file,'项目参考');const result=await this.attachments.read(entry);this.guard(signal);return result;
 }
}
module.exports=ProjectReferences;
