const {test}=require('node:test'),assert=require('node:assert/strict');
const PT=require('./ai-paper-translation.cjs'),Execution=require('./ai-execution.cjs');
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};};
const tick=()=>new Promise(resolve=>setImmediate(resolve));
test('chunks run strictly one at a time with the immediately preceding completed translation',async()=>{
 const gates=Array.from({length:5},deferred),calls=[],states=[];let active=0,peak=0;
 const job=PT.runChunks([0,1,2,3,4],async(value,n,{previous})=>{calls.push({n,previous});peak=Math.max(peak,++active);await gates[n].promise;active--;return 'part'+value;},{onProgress:s=>states.push(s)});
 for(let n=0;n<5;n++){
  assert.deepEqual(calls.map(x=>x.n),Array.from({length:n+1},(_,i)=>i));
  assert.deepEqual(calls[n].previous,Array.from({length:n},(_,i)=>'part'+i));
  await tick();assert.equal(calls.length,n+1);gates[n].resolve();await tick();
 }
 assert.deepEqual(await job,['part0','part1','part2','part3','part4']);assert.equal(peak,1);assert.equal(states.at(-1).completed,5);assert.deepEqual(states.at(-1).active,[]);assert(states.every(s=>s.active.length<=1&&s.concurrency===1));
});
test('rate limiting stops serial translation without starting later chunks or resending completed chunks',async()=>{
 const calls=[],states=[],limited=Object.assign(Error('rate limited'),{status:429});
 await assert.rejects(PT.runChunks([0,1,2],async(value,n)=>{calls.push(n);if(n===1)throw limited;return value;},{onProgress:s=>states.push(s)}),e=>e===limited);
 assert.deepEqual(calls,[0,1]);assert.equal(states.at(-1).completed,1);assert.deepEqual(states.at(-1).active,[]);
});
test('failed validation blocks all later chunks',async()=>{
 const gate=deferred(),calls=[];
 const job=PT.runChunks([0,1,2],async(value,n)=>{calls.push(n);await gate.promise;throw Error('invalid translation');});
 gate.resolve();await assert.rejects(job,/invalid translation/);assert.deepEqual(calls,[0]);
});
test('user stop cancels the current request and prevents every later chunk',async()=>{
 const controller=new AbortController(),calls=[],cancelled=[];
 const job=PT.runChunks([0,1,2],(value,n,{signal})=>{calls.push(n);return new Promise((resolve,reject)=>signal.addEventListener('abort',()=>{cancelled.push(n);reject(Object.assign(Error('stopped'),{name:'AbortError'}));},{once:true}));},{signal:controller.signal});
 controller.abort();await assert.rejects(job,{name:'AbortError'});assert.deepEqual(calls,[0]);assert.deepEqual(cancelled,[0]);
 await assert.rejects(PT.runChunks([0],()=>{throw Error('must not start');},{signal:controller.signal}),{name:'AbortError'});
});
test('streamed summaries render before completion, deduplicate callbacks and hide translation JSON',async()=>{
 const turn={},emit=e=>Execution.put(turn,e),gate=deferred();let callbacks;
 const job=PT.streamRequest(async c=>{callbacks=c;c.onEvent({id:'r',type:'reasoning',kind:'summary',text:'先核对图注',encrypted_content:'SECRET'});c.onReasoning('先核对图注','summary');c.onText('{"translations":[{"id":"L1","text":"⟦ET0⟧');await gate.promise;return {text:'VALIDATED LATER',reasoning:'先核对图注',reasoningKind:'summary'};},{id:'chunk1',label:'第 1 / 2 段',emit});
 assert.equal(turn.execution.filter(e=>e.type==='reasoning').length,1);assert.equal(turn.execution.find(e=>e.type==='reasoning').text,'先核对图注');assert(turn.execution.find(e=>e.type==='progress').text.includes('已接收'));assert(!JSON.stringify(turn.execution).includes('SECRET'));assert(!JSON.stringify(turn.execution).includes('⟦ET0⟧'));assert(!JSON.stringify(turn.execution).includes('translations'));assert.equal(turn.answer,undefined);
 gate.resolve();assert.equal((await job).text,'VALIDATED LATER');assert(turn.execution.every(e=>e.status==='success'));const snapshot=JSON.stringify(turn.execution);callbacks.onReasoning('LATE','summary');callbacks.onText('LATE');assert.equal(JSON.stringify(turn.execution),snapshot);
 const saved=Execution.snapshot(turn.execution);assert.equal(saved.find(e=>e.type==='reasoning').description,'第 1 / 2 段');
});
test('concurrent identical provider event IDs stay distinct and fallback summaries are supported',async()=>{
 const turn={},emit=e=>Execution.put(turn,e);
 await Promise.all([0,1].map(n=>PT.streamRequest(async c=>{c.onEvent({id:'same',type:'reasoning',kind:'summary',text:'片段'+n});return {text:'json'};},{id:'part'+n,label:'第 '+n+' 段',emit})));
 assert.equal(turn.execution.filter(e=>e.type==='reasoning').length,2);
 await PT.streamRequest(async c=>{c.onReasoning('兼容摘要','summary');return {text:'json',reasoning:'兼容摘要',reasoningKind:'summary'};},{id:'callback-only',label:'片段',emit});
 await PT.streamRequest(async()=>({text:'json',reasoning:'完成时才返回',reasoningKind:'summary'}),{id:'final-only',label:'片段',emit});
 assert.deepEqual(turn.execution.filter(e=>e.type==='reasoning').map(e=>e.text),['片段0','片段1','兼容摘要','完成时才返回']);
});
test('interfaces without summaries report their absence and never fabricate reasoning',async()=>{
 const events=[];await PT.streamRequest(async c=>{c.onEvent({type:'status',text:'接口不支持思考摘要'});c.onText('json');return {text:'json'};},{id:'none',label:'第 1 段',emit:e=>events.push(e)});
 assert.equal(events.filter(e=>e.type==='reasoning').length,0);assert(events.at(-1).text.includes('接口未返回可显示的思考摘要'));
});
test('stopping a stream preserves partial summaries and ignores late output',async()=>{
 const controller=new AbortController(),turn={};let callbacks;
 const job=PT.streamRequest(c=>{callbacks=c;c.onReasoning('已返回部分摘要','summary');return new Promise((resolve,reject)=>c.signal.addEventListener('abort',()=>reject(Object.assign(Error('stop'),{name:'AbortError'})),{once:true}));},{id:'stop',label:'第 1 段',signal:controller.signal,emit:e=>Execution.put(turn,e)});
 controller.abort();await assert.rejects(job,{name:'AbortError'});assert.equal(turn.execution.find(e=>e.type==='reasoning').status,'cancelled');const before=JSON.stringify(turn.execution);callbacks.onReasoning('late','summary');assert.equal(JSON.stringify(turn.execution),before);
});
