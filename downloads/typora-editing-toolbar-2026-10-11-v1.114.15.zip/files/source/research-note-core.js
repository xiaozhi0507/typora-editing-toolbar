import MarkdownIt from 'markdown-it';
import {parseDocument} from 'yaml';
const markdown=new MarkdownIt({html:true,linkify:false});
const validateLink=markdown.validateLink;markdown.validateLink=url=>/^file:/i.test(url)||validateLink(url);
export function frontmatter(source){const match=/^\uFEFF?---[ \t]*\r?\n([\s\S]*?)\r?\n(?:---|\.\.\.)[ \t]*(?:\r?\n|$)/.exec(source);return match?{raw:match[1],length:match[0].length}:null;}
export function parseNote(source){
 const fm=frontmatter(source),links=[],tags=new Set(),aliases=[];let yamlError='';
 const wiki=text=>{for(const m of String(text).matchAll(/(!?)\[\[([^\]\n]+)\]\]/g))links.push({target:m[2].split('|')[0].trim(),wiki:true,embed:!!m[1]});};
 if(fm)try{const doc=parseDocument(fm.raw,{uniqueKeys:true});if(doc.errors.length)throw doc.errors[0];const data=doc.toJS({maxAliasCount:100});if(data!=null&&(!data||typeof data!=='object'||Array.isArray(data)))throw Error('属性区必须是键值映射');for(const [name,value]of Object.entries(data||{})){if(name==='tags')for(const tag of (Array.isArray(value)?value:String(value||'').split(/[,\s]+/)))if(tag)tags.add(String(tag).replace(/^#/,''));if(name==='aliases')aliases.push(...(Array.isArray(value)?value:[value]).filter(v=>typeof v==='string'));}
  const scan=(v,depth=0)=>{if(depth>20)return;if(typeof v==='string')wiki(v);else if(v&&typeof v==='object')Object.values(v).slice(0,1000).forEach(x=>scan(x,depth+1));};scan(data);
 }catch(e){yamlError=e.message;}
 const sourceBody=source.slice(fm?.length||0).replace(/<!--[\s\S]*?-->/g,'');const tokens=markdown.parse(sourceBody,{});
 const html=text=>{for(const m of text.matchAll(/<(a|img)\b[^>]*?\b(href|src)\s*=\s*(?:"([^"]*)"|'([^']*)')/gi))links.push({target:(m[3]??m[4]).replace(/&amp;/g,'&'),wiki:false,embed:m[1].toLowerCase()==='img'});};
 let inTableHeader=false;
 for(const token of tokens){
  if(token.type==='thead_open')inTableHeader=true;
  if(token.type==='thead_close')inTableHeader=false;
  if(token.type==='html_block')html(token.content);
  if(token.type!=='inline')continue;
  for(const child of token.children||[]){
   if(child.type==='link_open')links.push({target:child.attrGet('href'),wiki:false});
   else if(child.type==='image')links.push({target:child.attrGet('src'),wiki:false,embed:true});
   else if(child.type==='html_inline')html(child.content);
   else if(child.type==='text'){
    wiki(child.content);
    // Research table headers use # for counts, such as #CAT and #Params.
    // Keep their links, but only infer hashtags outside the header row.
    if(!inTableHeader)for(const m of child.content.matchAll(/(?:^|[\s(（])#([\p{L}\p{N}_/-]+)/gu))if(!/^\d+$/.test(m[1]))tags.add(m[1]);
   }
  }
 }
 return{links,tags:[...tags],aliases,yamlError};
}
export function matchQuery(node,query){
 const parts=String(query||'').match(/(?:[^\s"]+|"[^"]*")+/g)||[];
 return parts.every(part=>{const negative=part.startsWith('-');if(negative)part=part.slice(1);let ok;const at=part.indexOf(':'),kind=at<0?'':part.slice(0,at).toLowerCase(),value=(at<0?part:part.slice(at+1)).replace(/^"|"$/g,'').toLowerCase();
  if(kind==='path')ok=String(node.relative||node.path||'').toLowerCase().includes(value);else if(kind==='tag')ok=(node.tags||[]).some(t=>t.toLowerCase().includes(value.replace(/^#/,'')));else if(kind==='file')ok=String(node.label||'').toLowerCase().includes(value);else ok=(node.label+' '+(node.relative||'')).toLowerCase().includes(part.replace(/^"|"$/g,'').toLowerCase());return negative?!ok:ok;});
}
export function localGraph(index,current,options){
 const all=new Map(index.nodes.map(n=>[n.id,n])),out=new Map(),incoming=new Map();for(const e of index.edges){if(!out.has(e.source))out.set(e.source,[]);if(!incoming.has(e.target))incoming.set(e.target,[]);out.get(e.source).push(e);incoming.get(e.target).push(e);}
 const global=options.scope==='global',root=String(index.root||'').replace(/\\/g,'/').replace(/\/+$/,'').toLowerCase(),inScope=n=>!global||!root||!!n.libraryItemId||String(n.path||'').replace(/\\/g,'/').toLowerCase().startsWith(root+'/');
 const attachments=typeof options.excludeNonMarkdown==='boolean'?!options.excludeNonMarkdown:!!options.attachments;
 const relationship=n=>n&&n.kind!=='tag'&&(attachments||n.kind!=='attachment');
 const hidden=new Set(options.hiddenNodes||[]),accept=n=>n&&inScope(n)&&(n.id===current||(!hidden.has(n.id)&&(attachments||n.kind!=='attachment')&&(options.tags||n.kind!=='tag')&&(!options.existingOnly||n.exists)&&matchQuery(n,options.search)));
 // Count unique neighbors across the index so local/global switches do not change importance.
 const counts=new Map();for(const n of index.nodes)if(relationship(n)&&inScope(n))counts.set(n.id,new Set());
 for(const e of index.edges)if(e.source!==e.target&&counts.has(e.source)&&counts.has(e.target)){counts.get(e.source).add(e.target);counts.get(e.target).add(e.source);}
 const visited=new Set(global?[]:[current]),traversed=new Set(),distances=new Map([[current,0]]);
 if(global){for(const n of index.nodes)if(accept(n))visited.add(n.id);}
 else{let frontier=[current];for(let depth=0;depth<options.depth;depth++){const next=[];for(const id of frontier){for(const e of [...(options.outgoing?out.get(id)||[]:[]),...(options.incoming?incoming.get(id)||[]:[])]){const other=e.source===id?e.target:e.source;if(!accept(all.get(other)))continue;if(!visited.has(other)){visited.add(other);distances.set(other,depth+1);next.push(other);}if(Math.abs(distances.get(id)-distances.get(other))===1)traversed.add(e.source+'\u0000'+e.target);}}frontier=next;}}
 const ids=[...visited].filter(id=>all.has(id)),limit=options.maxNodes||500;if(global){ids.sort();const at=ids.indexOf(current);if(at>=limit){ids.splice(at,1);ids.unshift(current);}}
 const shown=new Set(ids.slice(0,limit)),nodes=ids.slice(0,limit).map(id=>({...all.get(id),current:id===current,connectionCount:counts.get(id)?.size||0}));
 const edges=index.edges.filter(e=>shown.has(e.source)&&shown.has(e.target)&&(global||options.interlinks||traversed.has(e.source+'\u0000'+e.target)));
 return{nodes,edges:edges.slice(0,6000),isolated:nodes.filter(n=>!n.connectionCount).length,omittedEdges:Math.max(0,edges.length-6000),omitted:Math.max(0,ids.length-limit),incoming:(incoming.get(current)||[]).map(e=>all.get(e.source)).filter(relationship),outgoing:(out.get(current)||[]).map(e=>all.get(e.target)).filter(relationship)};
}
