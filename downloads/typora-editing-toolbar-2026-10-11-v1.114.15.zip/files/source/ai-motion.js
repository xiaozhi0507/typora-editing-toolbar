// Keep pointer-frequency work separate from document/toolbars and persistent state.
class EditingToolbarAIMotion {
  constructor(ai, settings=false) { this.frame=ETDragSupport.frame(()=>this.paint(),requestAnimationFrame,cancelAnimationFrame); this.ai=ai;this.settings=settings;this.minWidth=settings?360:320;this.minHeight=settings?340:300; }
  get panel() {return this.settings?this.ai.preferences:this.ai.panel;}
  get state() {
    if(!this.settings)return this.ai.config;
    const saved=this.ai.config.settingsWindow;
    if(!saved||typeof saved!=='object'||Array.isArray(saved))this.ai.config.settingsWindow={};
    return this.ai.config.settingsWindow;
  }
  layout() {if(this.settings)this.ai.settingsUI.layoutWindow();else this.ai.layout();}
  bindHandle(handle) {
    handle.onpointerdown=e=>this.start(e,handle);
    handle.onpointermove=e=>{if(this.drag?.handle===handle&&e.pointerId===this.drag.pointerId)this.queue(e);};
    handle.onpointerup=e=>{if(this.drag?.handle===handle&&e.pointerId===this.drag.pointerId){this.queue(e);this.finish(false);}};
    handle.onpointercancel=()=>{if(this.drag?.handle===handle)this.finish(true);};
    handle.onlostpointercapture=()=>{if(this.drag?.handle===handle)this.finish(false);};
  }
  mount() {
    const a = this.ai;
    for(const handle of [this.panel.querySelector('.et-ai-header'),...this.panel.querySelectorAll('.et-ai-resize')])this.bindHandle(handle);
    window.addEventListener('keydown', e => { if (e.key === 'Escape' && this.drag) { e.preventDefault(); e.stopPropagation(); this.finish(true); } }, true);
    window.addEventListener('blur', () => this.finish(true));
    this.panel.querySelector('[data-edge=se]').onkeydown = e => {
      if (!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)) return;
      e.preventDefault(); const r = this.panel.getBoundingClientRect();
      const g=this.state;g.position={x:r.left,y:r.top};
      if(!this.settings){a.layoutMode=g.layout='float';a.position=g.position;}
      g.width=r.width+(e.key==='ArrowRight'?20:e.key==='ArrowLeft'?-20:0);
      g.height=r.height+(e.key==='ArrowDown'?20:e.key==='ArrowUp'?-20:0);
      this.layout();a.persist();
    };
  }
  start(e, handle) {
    const a = this.ai, edge = handle.dataset.edge || '';
    if(e.button!==0||!e.isPrimary||e.target.closest('button')||this.drag||(this.settings?a.preferencesBackdrop.hidden:!a.preferencesBackdrop.hidden)||(!edge&&this.panel.dataset.layout!=='float'))return;
    a.composerUI.closeMenu();a.settingsUI.closeMenu(); a.settingsUI.hideHelp();
    const r=this.panel.getBoundingClientRect(),dock=!this.settings&&this.panel.dataset.layout==='dock',g=this.state;
    this.drag = { handle, edge, dockWidth:dock && edge === 'w', pointerId:e.pointerId, x:e.clientX, y:e.clientY, dx:0, dy:0,
      left:r.left, top:r.top, width:r.width, height:r.height, viewportWidth:innerWidth, viewportHeight:innerHeight, maxDockWidth:a.maxDockWidth(),
      saved:{width:g.width,height:g.height,layout:g.layout,position:g.position},
      layoutMode:a.layoutMode, position:a.position };
    if (dock && edge !== 'w') {
      a.layoutMode = 'float'; a.config.height = r.height; a.position = { x:r.left, y:r.top }; a.layout();
      // Clamping during detachment can change the starting rectangle.
      const detached = this.panel.getBoundingClientRect();
      Object.assign(this.drag,{left:detached.left,top:detached.top,width:detached.width,height:detached.height});
    }
    this.panel.classList.add('et-ai-moving');if(this.drag.dockWidth){
      this.drag.live=[...document.querySelectorAll('content')].map(node=>({node,prop:'right'}));
      const host=document.querySelector('#editing-toolbar-top-host[data-placement=floating]');if(host)this.drag.live.push({node:host,prop:'max-width'});
      for(const item of this.drag.live){item.value=item.node.style.getPropertyValue(item.prop);item.priority=item.node.style.getPropertyPriority(item.prop);}
      document.body.classList.add('et-ai-sizing');
    }
    handle.setPointerCapture(e.pointerId); e.preventDefault();
    if(this.drag.dockWidth){this.drag.shield=ETDragSupport.shield(document,'et-sidebar-drag-shield');}
  }
  queue(e) {
    this.drag.dx = e.clientX - this.drag.x; this.drag.dy = e.clientY - this.drag.y;
    this.frame.queue();
  }
  paint() {
    const d = this.drag; if (!d) return;
    const a = this.ai, s = this.panel.style;
    const set = (key, value) => { if (s[key] !== value) s[key] = value; };
    if (!d.edge) {
      d.next = {left:Math.max(8,Math.min(d.left+d.dx,d.viewportWidth-d.width-8)),top:Math.max(8,Math.min(d.top+d.dy,d.viewportHeight-d.height-8)),width:d.width,height:d.height};
      set('transform',`translate3d(${d.next.left-d.left}px,${d.next.top-d.top}px,0)`);
      return;
    }
    if (d.dockWidth) {
      d.next = {width:Math.max(this.minWidth,Math.min(d.maxDockWidth,d.width-d.dx))};
      // Share the same frame with the editor; persistence and toolbar work stay at release.
      set('width',d.next.width+'px');for(const {node,prop} of d.live)node.style.setProperty(prop,prop==='right'?d.next.width+'px':'calc(100vw - '+d.next.width+'px - 16px)','important');return;
    }
    let left=d.left, top=d.top, right=left+d.width, bottom=top+d.height;
    const minW=Math.min(this.minWidth,d.viewportWidth-16), minH=Math.min(this.minHeight,d.viewportHeight-16);
    if(d.edge.includes('w')) left=Math.max(8,Math.min(left+d.dx,right-minW));
    if(d.edge.includes('e')) right=Math.min(d.viewportWidth-8,Math.max(right+d.dx,left+minW));
    if(d.edge.includes('n')) top=Math.max(8,Math.min(top+d.dy,bottom-minH));
    if(d.edge.includes('s')) bottom=Math.min(d.viewportHeight-8,Math.max(bottom+d.dy,top+minH));
    d.next={left,top,width:right-left,height:bottom-top};
    for(const [key,value] of Object.entries(d.next)) set(key,value+'px');
  }
  finish(cancel) {
    const d=this.drag; if(!d) return;
    this.frame.cancel();
    if(!cancel) this.paint();
    const a=this.ai,g=this.state;this.drag=null;
    if(cancel){Object.assign(g,d.saved);if(!this.settings){a.position=d.position;a.layoutMode=d.layoutMode;}}
    else if(d.next){
      g.width=d.next.width;
      if(!d.dockWidth){g.height=d.next.height;g.position={x:d.next.left,y:d.next.top};if(!this.settings)a.position=g.position;}
      if(!this.settings)g.layout=a.layoutMode;
    }
    for(const {node,prop,value,priority} of d.live||[]){if(value)node.style.setProperty(prop,value,priority);else node.style.removeProperty(prop);}
    d.shield?.remove();this.panel.style.transform='';this.panel.classList.remove('et-ai-moving');document.body.classList.remove('et-ai-sizing');
    if(d.handle.hasPointerCapture(d.pointerId))d.handle.releasePointerCapture(d.pointerId);
    this.layout();if(!cancel)a.persist();
  }
}
