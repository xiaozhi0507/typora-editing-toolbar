// Project metadata stays separate from folders and their contents.
class EditingToolbarProjects {
 constructor(tabs){
  this.tabs=tabs;this.core=new ETDocumentProjects(reqnode);this.key='et-document-projects-v1';this.read();this.host=tabs.list;tabs.projects=this;this.render();
  window.addEventListener('storage',e=>{if(e.key===this.key){this.read();this.render();this.syncAI();}});
  window.addEventListener('dragend',()=>this.clearDropFeedback());window.addEventListener('blur',()=>this.clearDropFeedback());window.addEventListener('keydown',e=>{if(e.key==='Escape')this.clearDropFeedback();},true);
 }
 static paths={rename:'M4 8V4h16v4M12 4v16m-4 0h8',trash:'M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7',filePlus:'M14 3H5v18h14V8l-5-5v5h5M8 14h8m-4-4v8',output:'M3 7V5h6l2 2h10v13H3zM12 10v7m-3-3 3 3 3-3',folder:'M3 7V5a1 1 0 0 1 1-1h5l2 3h9a1 1 0 0 1 1 1v11H3z',folderOpen:'M3 10V5h6l2 2h8v3M3 10h19l-4 10H3z',folderPlus:'M3 7V5a1 1 0 0 1 1-1h5l2 3h9a1 1 0 0 1 1 1v5M3 7v12h9m6-5v8m-4-4h8',edit:'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8Zm-2-5h4l1 3 3 1 3 3v4l-3 1-1 3-3 3h-4l-1-3-3-1-3-3v-4l3-1 1-3z',chevron:'m9 5 7 7-7 7',pin:'m15 3 6 6-3 1-4 4v4l-2 2-3-5-5-3 2-2h4l4-4zM8 16l-5 5',close:'m6 6 12 12M18 6 6 18',default:'M3 7V5h6l2 2h10v12H3zM8 13l3 3 5-6',refresh:'M20 7a9 9 0 1 0 1 9M20 3v5h-5',expand:'m7 8 5-5 5 5M7 16l5 5 5-5',collapse:'m7 3 5 5 5-5M7 21l5-5 5 5',sections:'M8 5h13M8 12h13M8 19h13M3 5h.01M3 12h.01M3 19h.01'};
 icon(name){return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="'+EditingToolbarProjects.paths[name]+'"/></svg>';}
 read(){let db;try{db=JSON.parse(localStorage.getItem(this.key));}catch{}this.activeId=db?.activeId;this.items=(Array.isArray(db?.items)?db.items:[]).filter(p=>p?.trusted&&typeof p.id==='string'&&typeof p.name==='string'&&this.tabs.path.isAbsolute(p.root||'')).map(p=>({...p,outputFolder:typeof p.outputFolder==='string'&&p.outputFolder.length<=240?p.outputFolder:'',fileOrder:p.fileOrder&&typeof p.fileOrder==='object'?Object.fromEntries(Object.entries(p.fileOrder).filter(([k,v])=>Array.isArray(v)).map(([k,v])=>[k,v.filter(x=>typeof x==='string').slice(0,10000)])):{},pinned:!!p.pinned,collapsed:typeof p.collapsed==='boolean'?p.collapsed:p.id!==this.activeId,expandedFolders:Array.isArray(p.expandedFolders)?p.expandedFolders.filter(f=>typeof f==='string').slice(0,500):[]}));this.groupsCollapsed={pinned:!!db?.groupsCollapsed?.pinned,projects:!!db?.groupsCollapsed?.projects};const ids=new Set();this.sections=(Array.isArray(db?.sections)?db.sections:[]).filter(s=>{if(!s||typeof s.id!=='string'||typeof s.name!=='string'||!s.name.trim()||ids.has(s.id))return false;ids.add(s.id);return true;}).map(s=>({id:s.id,name:s.name.trim(),collapsed:!!s.collapsed}));for(const p of this.items)if(!ids.has(p.sectionId))p.sectionId=null;this.defaultFolder=db?.defaultFolder&&typeof db.defaultFolder.id==='string'&&typeof db.defaultFolder.root==='string'?{id:db.defaultFolder.id,root:db.defaultFolder.root}:null;}
 save(render=true){localStorage.setItem(this.key,JSON.stringify({items:this.items,activeId:this.activeId,groupsCollapsed:this.groupsCollapsed,sections:this.sections,defaultFolder:this.defaultFolder}));if(render){this.render(false);this.syncAI();}}
 syncAI(){this.tabs.toolbar.aiAssistant?.webUI?.sync();}
 active(){return this.items.find(p=>p.id===this.activeId)||null;}
 defaultProject(){this.read();const p=this.items.find(p=>p.id===this.defaultFolder?.id&&this.tabs.key(p.root)===this.tabs.key(this.defaultFolder?.root));return p?{id:p.id,name:p.name,root:p.root,trusted:p.trusted}:null;}
 async setDefault(id){this.read();const p=this.items.find(p=>p.id===id);if(!p)throw Error('项目已移除，请重新选择');await this.core.check(p);this.read();const current=this.items.find(x=>x.id===id&&x.root===p.root);if(!current)throw Error('项目文件夹已变化，请重新选择');this.defaultFolder={id:current.id,root:current.root};this.save();this.tabs.notice?.('AI 新文件默认保存到 '+current.name);}
 contains(file){const target=this.tabs.key(file);return this.items.some(p=>target.startsWith(this.tabs.key(p.root).replace(/\/$/,'')+'/'));}
 update(id,patch){this.read();const p=this.items.find(p=>p.id===id);if(!p)return;Object.assign(p,typeof patch==='function'?patch(p):patch);this.save();return p;}
 select(p){this.read();const current=this.items.find(x=>x.id===p.id);if(!current)return;this.activeId=p.id;current.collapsed=false;this.groupsCollapsed[current.pinned?'pinned':'projects']=false;const section=this.sections.find(s=>s.id===current.sectionId);if(section)section.collapsed=false;this.save();}
 toggleProject(id){this.read();const p=this.items.find(p=>p.id===id);if(!p)return;this.activeId=id;p.collapsed=!p.collapsed;if(!p.collapsed)this.fileViews?.delete(id);this.save();this.host.querySelector('[data-project-id="'+CSS.escape(id)+'"] .et-project-open')?.focus({preventScroll:true});}
 toggleGroup(group){this.read();this.groupsCollapsed[group]=!this.groupsCollapsed[group];this.save();this.host.querySelector('[data-section="'+group+'"] .et-dt-section-toggle')?.focus({preventScroll:true});}
 pin(id){this.update(id,p=>{this.groupsCollapsed[p.pinned?'projects':'pinned']=false;const section=this.sections.find(s=>s.id===p.sectionId);if(section)section.collapsed=false;return {pinned:!p.pinned};});if(this.items.find(p=>p.id===id)?.pinned)this.tabs.change?.(db=>db.pinCollapsed=false);}
 remove(id){this.read();this.items=this.items.filter(p=>p.id!==id);if(this.activeId===id)this.activeId=null;if(this.defaultFolder?.id===id)this.defaultFolder=null;this.save();}
 invalidateFiles(id){if(id)this.fileViews?.delete(id);else this.fileViews?.clear();this.fileRevision=(this.fileRevision||0)+1;}
 render(refresh=true){if(this.disposed)return;if(refresh)this.invalidateFiles();this.tabs.signature='';this.tabs.render();}
 // Only directory structure/metadata invalidates a listing. Tab state is painted in place.
 fileViewSignature(p){return JSON.stringify([p.root,p.name,p.fileOrder,p.outputFolder]);}
 renderFileView(p,host){
  this.fileViews??=new Map();for(const [id,view]of this.fileViews)if(!this.items.some(item=>item.id===id&&item.root===view.root))this.fileViews.delete(id);
  const t=this.tabs,signature=this.fileViewSignature(p);let view=this.fileViews.get(p.id);
  if(!view||view.signature!==signature||!view.ready&&!view.loading){const files=t.node('div','et-project-files');files.dataset.projectFiles=p.id;files.setAttribute('role','listbox');files.setAttribute('aria-multiselectable','true');files.setAttribute('aria-label',p.name+'的文件');view={root:p.root,signature,files,loading:true,ready:false};this.fileViews.set(p.id,view);host.append(files);void this.list(p,files).finally(()=>{view.loading=false;view.ready=this.fileViews.get(p.id)===view;});}
  else{host.append(view.files);for(const row of view.files.querySelectorAll('.et-dt-row'))if(!t.rows.has(row.dataset.key)||row.classList.contains('active'))t.rows.set(row.dataset.key,row);}
 }

 renderHeader(head){const t=this.tabs,more=t.button('项目列表操作','more'),add=t.button('创建项目','plus');more.setAttribute('aria-haspopup','menu');more.onclick=()=>{const r=more.getBoundingClientRect();t.showMenu([{id:'projects-refresh',label:'刷新项目列表',icon:this.icon('refresh'),run:()=>{this.read();this.render();}},null,{id:'projects-expand',label:'展开全部项目',icon:this.icon('expand'),disabled:!this.items.length,run:()=>this.foldAll(false)},{id:'projects-collapse',label:'收起全部项目',icon:this.icon('collapse'),disabled:!this.items.length,run:()=>this.foldAll(true)}],{x:r.left,y:r.bottom+4},more,'项目列表操作','et-project-menu et-project-row-menu et-project-list-menu');};add.onclick=()=>this.createDialog();head.append(more,add);}
 foldAll(collapsed){this.read();for(const p of this.items)p.collapsed=collapsed;if(!collapsed){this.groupsCollapsed.projects=false;for(const section of this.sections)section.collapsed=false;this.tabs.change?.(db=>db.pinCollapsed=false);}this.save();}
 renderProjects(host,pinned,sectionId=null){
  const t=this.tabs;
  for(const p of this.items.filter(p=>p.pinned===pinned&&(pinned||p.sectionId===sectionId))){
   const row=t.node('div','et-project-row');row.dataset.projectId=p.id;
   const b=t.node('button','et-project-open');b.type='button';b.title=p.root;b.setAttribute('aria-label',(p.collapsed?'展开':'收起')+'项目 '+p.name);b.setAttribute('aria-expanded',String(!p.collapsed));b.innerHTML=this.icon(p.collapsed?'folder':'folderOpen');b.append(t.node('span','et-project-name-text',p.name));b.onclick=()=>this.toggleProject(p.id);
   const isDefault=this.defaultFolder?.id===p.id&&this.defaultFolder.root===p.root;if(isDefault){const mark=t.node('span','et-project-default','默认');mark.title='AI 新文件默认保存文件夹';row.classList.add('is-default');b.append(mark);row.append(b);}else row.append(b);
   const more=t.button('项目操作 '+p.name,'more');more.classList.add('et-project-more');more.setAttribute('aria-haspopup','menu');more.onclick=()=>this.openMenu(p,more);row.oncontextmenu=e=>{e.preventDefault();e.stopPropagation();this.openMenu(p,more,{x:e.clientX,y:e.clientY});};row.onkeydown=e=>{if(e.key==='F2'){e.preventDefault();e.stopPropagation();this.renameDialog(p);}if(e.key==='ArrowLeft'&&!p.collapsed||e.key==='ArrowRight'&&p.collapsed){e.preventDefault();this.toggleProject(p.id);}if(e.key==='ContextMenu'||(e.shiftKey&&e.key==='F10')){e.preventDefault();this.openMenu(p,more);}};
   this.tabs.bindSort(row,{kind:'project',group:p.pinned?'pinned':p.sectionId||'projects',key:p.id,move:(...args)=>this.moveProject(...args)});this.bindFolderDrop(row,p,'');row.append(more);host.append(row);if(!p.collapsed)this.renderFileView(p,host);
  }
 }
 openMenu(p,anchor,point){this.read();p=this.items.find(x=>x.id===p.id);if(!p)return;const t=this.tabs,r=anchor.getBoundingClientRect(),isDefault=this.defaultFolder?.id===p.id&&this.defaultFolder.root===p.root;t.showMenu([{id:'project-folder-new',label:'新建子文件夹…',icon:this.icon('folderPlus'),run:()=>this.folderDialog(p)},{id:'project-file-new',label:'新建文件',icon:this.icon('filePlus'),children:()=>this.fileMenu(p.root)},null,{id:'project-pin',label:p.pinned?'取消置顶':'置顶',icon:this.icon('pin'),run:()=>this.pin(p.id)},{id:'project-rename',label:'重命名…',hint:'F2',icon:this.icon('rename'),run:()=>this.renameDialog(p)},{id:'project-edit',label:'编辑',icon:this.icon('edit'),run:()=>this.createDialog(p)},null,{id:'project-section',label:'分区',icon:this.icon('sections'),children:()=>this.sectionMenu(p.id)},{id:'project-default',label:isDefault?'默认文件夹':'设置默认文件夹',checked:isDefault,icon:this.icon('default'),run:()=>this.setDefault(p.id)},{id:'project-reveal',label:'在资源管理器中打开',icon:this.icon('folder'),run:()=>JSBridge.showInFinder(p.root)},null,{id:'project-remove',label:'移除项目',icon:this.icon('close'),run:()=>this.remove(p.id)}],point||{x:r.left,y:r.bottom+4},anchor,'项目操作','et-project-menu et-project-row-menu');}
 sectionMenu(projectId){this.read();const current=this.items.find(p=>p.id===projectId);return [{id:'section-default',label:'项目',checked:!current?.sectionId,icon:this.icon('folder'),run:()=>this.moveToSection(projectId,null)},...this.sections.map(section=>({id:'section-'+section.id,label:section.name,checked:current?.sectionId===section.id,icon:this.icon('folder'),run:()=>this.moveToSection(projectId,section.id)})),null,{id:'section-new',label:'新建分区…',icon:this.icon('folderPlus'),run:()=>this.sectionDialog(projectId)}];}
 sectionName(value,except=null){const name=typeof value==='string'?value.trim():'';if(!name||name.length>60||/[\x00-\x1f]/.test(name))throw Error('请输入 1–60 个字符的分区名称');if(['置顶','项目','收藏'].includes(name)||this.sections.some(s=>s.id!==except&&s.name.toLocaleLowerCase()===name.toLocaleLowerCase()))throw Error('已有同名分区，请换一个名称');return name;}
 createSection(projectId,name){this.read();const p=this.items.find(p=>p.id===projectId);if(!p)throw Error('项目已移除，请重新选择');name=this.sectionName(name);const section={id:'section-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8),name,collapsed:false};this.sections.push(section);p.sectionId=section.id;p.pinned=false;this.save();return section;}
 moveToSection(projectId,sectionId){this.read();const p=this.items.find(p=>p.id===projectId),section=this.sections.find(s=>s.id===sectionId);if(!p||sectionId&&!section)throw Error('项目或分区已更改，请重新选择');p.sectionId=section?.id||null;p.pinned=false;if(section)section.collapsed=false;else this.groupsCollapsed.projects=false;this.save();}
 renameSection(id,name){this.read();const section=this.sections.find(s=>s.id===id);if(!section)throw Error('分区已移除');section.name=this.sectionName(name,id);this.save();}
 removeSection(id){this.read();this.sections=this.sections.filter(s=>s.id!==id);for(const p of this.items)if(p.sectionId===id)p.sectionId=null;this.groupsCollapsed.projects=false;this.save();}
 toggleSection(id){this.read();const section=this.sections.find(s=>s.id===id);if(!section)return;section.collapsed=!section.collapsed;this.save();}
 renderSections(){const t=this.tabs;for(const section of this.sections){const group=t.section(section.id,section.name,section.collapsed,()=>this.toggleSection(section.id)),more=t.button('分区操作 '+section.name,'more');more.setAttribute('aria-haspopup','menu');more.onclick=()=>{const r=more.getBoundingClientRect();t.showMenu([{id:'section-rename',label:'重命名分区',icon:this.icon('edit'),run:()=>this.sectionDialog(null,section)},null,{id:'section-remove',label:'移除分区',icon:this.icon('close'),run:()=>this.removeSection(section.id)}],{x:r.left,y:r.bottom+4},more,'分区操作','et-project-menu et-project-row-menu');};group.head.append(more);if(!section.collapsed)this.renderProjects(group.body,false,section.id);}}
 sectionDialog(projectId,existing=null){
  const t=this.tabs,d=this.modal(existing?'重命名分区':'新建分区','et-section-dialog'),form=t.node('form'),sub=t.node('p','et-section-subtitle','随心整理文件和项目'),input=t.node('input'),error=t.node('p','et-project-error'),foot=t.node('div','et-project-footer'),cancel=t.node('button','et-section-cancel','取消'),submit=t.node('button','primary',existing?'保存':'创建分区');input.placeholder='分区名称';input.setAttribute('aria-label','分区名称');input.maxLength=60;input.required=true;input.autocomplete='off';input.value=existing?.name||'';cancel.type='button';submit.type='submit';cancel.onclick=()=>d.close();error.setAttribute('role','alert');input.oninput=()=>{submit.disabled=!input.value.trim();error.textContent='';};foot.append(cancel,submit);form.append(input,error,foot);d.append(sub,form);form.onsubmit=e=>{e.preventDefault();try{if(existing)this.renameSection(existing.id,input.value);else this.createSection(projectId,input.value);d.close();}catch(e){error.textContent=e.message;input.focus();}};submit.disabled=!input.value.trim();d.showModal();input.focus();if(existing)input.select();
 }
 rememberFolder(id,root,relative,open){this.read();const p=this.items.find(p=>p.id===id&&p.root===root);if(!p)return;const expanded=new Set(p.expandedFolders);if(open)expanded.add(relative);else expanded.delete(relative);p.expandedFolders=[...expanded];this.save(false);}
 moveProject(id,target,after=false){this.read();const a=this.items.find(p=>p.id===id),b=this.items.find(p=>p.id===target);if(!a||!b||a===b||a.pinned!==b.pinned||(!a.pinned&&a.sectionId!==b.sectionId))return;this.items.splice(this.items.indexOf(a),1);this.items.splice(this.items.indexOf(b)+(after?1:0),0,a);this.save();}
 moveFile(id,relative,keys,source,target,after=false){
  this.read();const p=this.items.find(p=>p.id===id);if(!p||source===target||!keys.includes(source)||!keys.includes(target))return;
  const current=[...(p.fileOrder?.[relative]||[]).filter(k=>keys.includes(k)),...keys.filter(k=>!(p.fileOrder?.[relative]||[]).includes(k))],order=current.filter(k=>k!==source);order.splice(order.indexOf(target)+(after?1:0),0,source);p.fileOrder={...p.fileOrder,[relative]:order};
  const view=this.fileViews?.get(id),host=relative?view?.files.querySelector('[data-project-relative="'+CSS.escape(relative)+'"]'):view?.files;if(host){const rows=new Map([...host.children].filter(n=>n.classList.contains('et-project-file-row')).map(n=>[this.tabs.path.relative(p.root,n.dataset.path).split(this.tabs.path.sep).join('/'),n]));for(const key of order)if(rows.has(key))host.append(rows.get(key));view.signature=this.fileViewSignature(p);}this.save();
 }
 retainsFileHost(host){return [...(this.fileViews?.values()||[])].some(view=>view.files===host||view.files.contains(host));}
 async list(p,host,relative=''){
  host.dataset.projectRelative=relative;this.bindFolderDrop(host,p,relative);const generation=host._etListGeneration=(host._etListGeneration||0)+1;
  try{
   const entries=await this.core.list(p,relative);if(generation!==host._etListGeneration||!host.isConnected&&!this.retainsFileHost(host))return;
   const order=p.fileOrder?.[relative]||[],rank=new Map(order.map((key,i)=>[key,i]));entries.sort((a,b)=>Number(b.directory)-Number(a.directory)||(a.directory?0:(rank.get(a.relative)??Infinity)-(rank.get(b.relative)??Infinity)));
   const keys=entries.filter(f=>!f.directory).map(f=>f.relative),next=[],old=new Map([...host.children].map(n=>[n.dataset.projectDirectory||n.dataset.path,n]));
   for(const f of entries){
    if(f.directory){
     const existing=old.get(f.relative);if(existing){next.push(existing);continue;}
     const d=this.tabs.node('details','et-project-directory'),summary=this.tabs.node('summary'),child=this.tabs.node('div','et-project-files');d.dataset.projectDirectory=f.relative;child.dataset.projectRelative=f.relative;summary.innerHTML=this.icon('folder');summary.append(this.tabs.node('span','',f.name));summary.title=f.path;
     if(p.outputFolder===f.relative){summary.append(this.tabs.node('small','et-project-output-mark','输出'));summary.title+=' · 本项目默认输出目录';}
     this.bindFolderDrop(summary,p,f.relative);summary.oncontextmenu=e=>{e.preventDefault();e.stopPropagation();this.folderMenu(p,f,summary,{x:e.clientX,y:e.clientY});};summary.onkeydown=e=>{if(e.key==='F2'){e.preventDefault();e.stopPropagation();this.renameDialog(p,f.relative);}if(e.key==='ContextMenu'||e.shiftKey&&e.key==='F10'){e.preventDefault();e.stopPropagation();const r=summary.getBoundingClientRect();this.folderMenu(p,f,summary,{x:r.left,y:r.bottom});}};
     d.append(summary,child);d.open=p.expandedFolders?.includes(f.relative)||false;const load=()=>{if(d.open&&!d.dataset.loaded){d.dataset.loaded='true';void this.list(p,child,f.relative);}};d.ontoggle=()=>{if(!d.isConnected)return;this.rememberFolder(p.id,p.root,f.relative,d.open);load();};next.push(d);load();
    }else{
     if(this.tabs.toolbar.codeEditor?.supported(f.path))this.tabs.toolbar.codeEditor.warm();const row=old.get(f.path)||this.tabs.fileRow({path:f.path,name:f.name},{project:p.id});this.tabs.bindSort(row,{kind:'project-file',group:p.id+':'+relative,key:f.relative,move:(...args)=>this.moveFile(p.id,relative,keys,...args)});this.bindFileMove(row,p,f);this.bindFolderDrop(row,p,relative,true);next.push(row);
    }
   }
   next.forEach((node,i)=>{if(host.children[i]!==node)host.insertBefore(node,host.children[i]||null);});while(host.children.length>next.length)host.lastElementChild.remove();
  }catch(e){if(generation===host._etListGeneration&&(host.isConnected||this.retainsFileHost(host))){const error=this.tabs.node('div','et-project-list-error','无法读取文件夹，请检查项目路径');error.title=e.message;host.append(error);}}
 }
 async refreshFolders(p,relatives){
  const view=this.fileViews?.get(p.id);if(!view||view.root!==p.root){this.invalidateFiles(p.id);return;}
  for(const relative of [...new Set(relatives)].sort((a,b)=>a.length-b.length)){
   const host=relative?view.files.querySelector('[data-project-relative="'+CSS.escape(relative)+'"]'):view.files;if(!host)continue;
   if(host.parentElement?.tagName==='DETAILS'){host.parentElement.dataset.loaded='true';if(p.expandedFolders.includes(relative))host.parentElement.open=true;}
   await this.list(p,host,relative);
  }
  view.signature=this.fileViewSignature(p);view.ready=true;
 }
 async setOutputFolder(project,relative){
  this.read();const p=this.items.find(x=>x.id===project.id&&x.root===project.root);if(!p)throw Error('项目已更改，请重新选择');const folder=await this.core.directory(p,this.core.segments(relative));if(ETCodeWorkspace.owner(reqnode,this.items,this.tabs.path.join(folder,'__output__'))?.id!==p.id)throw Error('该文件夹属于另一个项目');const next=p.outputFolder===relative?'':relative;this.read();const live=this.items.find(x=>x.id===p.id&&x.root===p.root);if(!live)throw Error('项目已更改');live.outputFolder=next;this.invalidateFiles();this.save();this.tabs.notice(next?'本项目运行的相对路径使用输出目录：'+next:'已取消本项目的默认输出目录');this.tabs.toolbar.codeEditor?.status();
 }
 bindFileMove(row,p,f){
  const start=row.ondragstart,end=row.ondragend;row.ondragstart=e=>{start?.(e);if(e.defaultPrevented)return;const t=this.tabs;if(!t.fileSelection.has(t.key(f.path)))t.selectProjectFile(row,{});const files=[...t.fileSelection.values()].filter(file=>ETCodeWorkspace.owner(reqnode,this.items,file)?.id===p.id);this.fileDrag={id:p.id,root:p.root,files};e.dataTransfer.effectAllowed='copyMove';e.dataTransfer.setData('application/x-et-project-files',JSON.stringify(files));
   const ghost=t.node('div','et-project-drag-chip');ghost.innerHTML=t.icon('file');ghost.append(t.node('span','',files.length>1?files.length+' 个文件':f.name));document.body.append(ghost);this.dragGhost=ghost;e.dataTransfer.setDragImage(ghost,-12,-18);
  };
  row.ondragend=e=>{end?.(e);this.clearFileMove();};
 }
 clearDropFeedback(){clearTimeout(this.dropFeedbackTimer);clearTimeout(this.expandDropTimer);this.dropFolder?.classList.remove('et-folder-drop');this.dropFolder=null;this.dropHint?.remove();this.dropHint=null;}
 clearFileMove(){this.fileDrag=null;this.clearDropFeedback();this.dragGhost?.remove();this.dragGhost=null;if(this.tabs.renderDeferred)this.tabs.schedule();}
 isExternalDrop(e){return !this.fileDrag&&Array.from(e.dataTransfer?.types||[]).includes('Files');}
 droppedPaths(data){
  const files=Array.from(data?.files||[]);if(!files.length)throw Error('未能取得拖入的文件，请从资源管理器重新拖入');
  let webUtils;try{webUtils=reqnode('electron').webUtils;}catch{}
  return files.map(file=>{let path='';try{path=webUtils?.getPathForFile(file)||file.path||'';}catch{path=file.path||'';}if(!this.tabs.path.isAbsolute(path))throw Error('无法读取本机文件路径，请从资源管理器拖入已保存的文件');return path;});
 }
 showDropHint(e,p,relative,copy){
  // Explorer can cancel outside this renderer without delivering dragleave.
  clearTimeout(this.dropFeedbackTimer);this.dropFeedbackTimer=setTimeout(()=>this.clearDropFeedback(),1500);
  if(!this.dropHint){this.dropHint=this.tabs.node('div','et-project-drop-hint');this.dropHint.setAttribute('role','status');document.body.append(this.dropHint);}
  this.dropHint.textContent=(copy?'复制到 ':'移动到 ')+[p.name,relative].filter(Boolean).join(' / ')+(copy?'':' · Ctrl 复制');
  this.dropHint.style.left=Math.max(8,Math.min(e.clientX+16,innerWidth-290))+'px';this.dropHint.style.top=Math.max(8,Math.min(e.clientY+20,innerHeight-42))+'px';
 }
 bindFolderDrop(el,p,relative,externalOnly=false){
  el._etDrop={p,relative,externalOnly};el.dataset.etDropTarget='true';if(el._etDropBound)return;el._etDropBound=true;
  const accepts=e=>{if(e.target.closest?.('[data-et-drop-target]')!==el)return false;const {p,externalOnly}=el._etDrop;return this.isExternalDrop(e)||!externalOnly&&this.fileDrag?.id===p.id&&this.fileDrag.root===p.root&&this.fileDrag.files.length;};
  el.addEventListener('dragover',e=>{if(!accepts(e))return;const {p,relative}=el._etDrop;e.preventDefault();e.stopImmediatePropagation();e.dataTransfer.dropEffect=e.ctrlKey?'copy':'move';if(!el.classList.contains('et-folder-drop')){this.dropFolder?.classList.remove('et-folder-drop');this.tabs.dropMarker?.row.classList.remove('drop-before','drop-after');this.tabs.dropMarker=null;this.dropFolder=el;el.classList.add('et-folder-drop');clearTimeout(this.expandDropTimer);this.expandDropTimer=setTimeout(()=>{if(el.parentElement?.tagName==='DETAILS')el.parentElement.open=true;},550);}this.showDropHint(e,p,relative,e.ctrlKey);},true);
  el.addEventListener('dragleave',e=>{if(el.contains(e.relatedTarget)||this.dropFolder!==el)return;el.classList.remove('et-folder-drop');this.dropFolder=null;clearTimeout(this.expandDropTimer);this.dropHint?.remove();this.dropHint=null;});
  el.addEventListener('drop',e=>{if(!accepts(e))return;const {p,relative}=el._etDrop,external=this.isExternalDrop(e),copy=e.ctrlKey;e.preventDefault();e.stopImmediatePropagation();let files;try{files=external?this.droppedPaths(e.dataTransfer):[...this.fileDrag.files];}catch(error){this.tabs.notice(error.message);}this.clearFileMove();this.tabs.clearDrag();if(files)void this.tabs.fileAction(()=>external||copy?this.transferInto(p,files,relative,{copy}):this.moveInto(p,files,relative)).catch(error=>this.tabs.notice(error.message));},true);
 }
 async transferInto(project,files,relative='',{copy=false}={}){
  const t=this.tabs,code=t.toolbar.codeEditor,split=t.toolbar.splitView,ai=t.toolbar.aiAssistant,notebook=t.toolbar.notebook,keys=new Set(files.map(f=>t.key(f))),selected=f=>!!f&&keys.has(t.key(f));
  const validate=async()=>{
   this.read();const live=this.items.find(x=>x.id===project.id&&x.root===project.root);if(!live)throw Error('项目已移除或路径已变化，请重新拖入');
   const folder=await this.core.directory(live,relative?this.core.segments(relative):[]);if(ETCodeWorkspace.owner(reqnode,this.items,t.path.join(folder,'__destination__'))?.id!==live.id)throw Error('目标文件夹属于另一个项目，请拖到该项目中');
   if([...code?.records.values()||[]].some(r=>selected(r.file)&&(code.dirty(r)||r.writing||r.saving))||[...notebook?.records.values()||[]].some(r=>selected(r.file)&&(notebook.dirty(r)||r.writing||r.saving))||selected(File.bundle?.filePath)&&File.isDocumentEdited?.()||selected(split?.record?.file)&&split.dirty)throw Error('拖入的文件有未保存修改，请先保存');
   const destinations=new Set(files.map(f=>t.key(t.path.join(folder,t.path.basename(f)))));if([...code?.records.values()||[],...notebook?.records.values()||[]].some(r=>!selected(r.file)&&destinations.has(t.key(r.file))))throw Error('目标文件仍在编辑器中打开，请先关闭该目标标签');
   if(!copy&&ai?.codeUI?.targets?.some(target=>selected(target.file))&&new Set(ai.codeUI.targets.map(target=>selected(target.file)?live.id:target.projectId)).size>1)throw Error('移动后 AI 附件将分属不同项目，请先移除相关附件再移动');
   if(!copy&&(ai?.busy||ai?.codeUI?.attaching||ai?.queue?.preparing||ai?.queue?.items?.length))throw Error('请等待 AI 任务结束后再移动文件；按 Ctrl 拖入可复制');
   if(!copy&&([...notebook?.records.values()||[]].some(r=>selected(r.file)&&(r.running||r.kernel&&r.kernel.state!=='off'))||(t.toolbar.terminal?.sessions||[]).some(s=>selected(s.codeFile)&&['starting','running','stopping'].includes(s.backend?.state))))throw Error('文件正在运行，请先停止运行或按 Ctrl 拖入复制');
   return live;
  };
  const p=await validate(),library=File.editor.library,token=reqnode('crypto').randomUUID();
  this.handledMoves??=new Set();this.handledMoves.add(token);if(this.handledMoves.size>32)this.handledMoves.delete(this.handledMoves.values().next().value);
  t.projectMoveDepth=(t.projectMoveDepth||0)+1;library.pauseOnChange();let moved=[],failure;
  t.notice((copy?'正在复制':'正在移动')+' '+files.length+' 个文件…');
  try{
   if(!copy)await Promise.all(files.map(file=>JSBridge.invoke('app.sendEvent','willRename',{oldPath:file})));
   moved=await this.core.transferFiles(p,files,relative,{copy,validate});
  }catch(error){failure=error;if(!copy)moved=error.moves||[];}
  finally{
   try{
    if(!copy){
     t.replacePaths(moved);for(const item of moved)if(selected(split?.record?.file)&&t.key(item.from)===t.key(split.record.file))await split.open(item.to);
     await Promise.all(moved.map(item=>JSBridge.invoke('filesOp.registerUndo',item.to,item.from,'移动 '+t.path.basename(item.to)).catch(()=>{})));
     await Promise.all(files.map(file=>JSBridge.invoke('app.sendEvent','didRename',{oldPath:file,newPath:moved.find(m=>t.key(m.from)===t.key(file))?.to||file,etMoveToken:token}).catch(()=>{})));
    }
    this.read();for(const live of this.items){
     const affected=[];if(live.id===p.id&&live.root===p.root){live.collapsed=false;live.expandedFolders=[...new Set([...live.expandedFolders,...(relative?[relative]:[])])];affected.push(relative);}
     if(!copy)for(const file of files)if(this.core.contains(live.root,file))affected.push(t.path.relative(live.root,t.path.dirname(file)).split(t.path.sep).join('/'));
     if(affected.length){for(const key of affected)delete live.fileOrder[key];await this.refreshFolders(live,affected);}
    }
    this.save(false);t.fileSelection.clear();for(const {to}of moved)t.fileSelection.set(t.key(to),to);
   }finally{library.resumeOnChange();t.projectMoveDepth--;t.signature='';t.render();code?.sidebar();}
  }
  if(failure)throw failure;t.notice(moved.length?(copy?'已复制 ':'已移动 ')+moved.length+' 个文件到 '+(relative||p.name):'文件已在此文件夹');return moved;
 }
 async moveInto(project,files,relative){
  const t=this.tabs,code=t.toolbar.codeEditor,split=t.toolbar.splitView;this.read();const p=this.items.find(x=>x.id===project.id&&x.root===project.root);if(!p||files.some(f=>ETCodeWorkspace.owner(reqnode,this.items,f)?.id!==p.id))throw Error('只能移动同一项目中的文件');const folder=await this.core.directory(p,relative?this.core.segments(relative):[]);if(ETCodeWorkspace.owner(reqnode,this.items,t.path.join(folder,'__destination__'))?.id!==p.id)throw Error('目标文件夹属于另一个项目');
  if(files.some(f=>t.key(f)===t.key(File.bundle?.filePath)&&File.isDocumentEdited()))throw Error('正文有未保存修改，请先保存再移动');
  if(files.some(f=>split?.record&&t.key(f)===t.key(split.record.file))&&!split.save())throw Error('请先处理副栏中的未保存内容');
  const library=File.editor.library,token=reqnode('crypto').randomUUID(),affected=[relative,...files.map(f=>t.path.relative(p.root,t.path.dirname(f)).split(t.path.sep).join('/'))];
  this.handledMoves??=new Set();this.handledMoves.add(token);if(this.handledMoves.size>32)this.handledMoves.delete(this.handledMoves.values().next().value);
  t.projectMoveDepth=(t.projectMoveDepth||0)+1;library.pauseOnChange();let moved=[];const sourceRows=[...this.host.querySelectorAll('.et-project-file-row')].filter(r=>files.some(f=>t.key(f)===r.dataset.key));for(const row of sourceRows){row.classList.add('et-file-moving');row.setAttribute('aria-busy','true');}
  try{
   await Promise.all(files.map(file=>JSBridge.invoke('app.sendEvent','willRename',{oldPath:file})));
   moved=await this.core.moveFiles(p,files,relative);t.replacePaths(moved);
   for(const item of moved)if(split?.record&&t.key(item.from)===t.key(split.record.file))await split.open(item.to);
   await Promise.all(moved.map(item=>JSBridge.invoke('filesOp.registerUndo',item.to,item.from,'移动 '+t.path.basename(item.to)).catch(()=>{})));
  }finally{
   try{await Promise.all(files.map(file=>JSBridge.invoke('app.sendEvent','didRename',{oldPath:file,newPath:moved.find(m=>t.key(m.from)===t.key(file))?.to||file,etMoveToken:token}).catch(()=>{})));
    this.read();const live=this.items.find(x=>x.id===p.id&&x.root===p.root);if(live){live.collapsed=false;if(relative)live.expandedFolders=[...new Set([...live.expandedFolders,relative])];for(const key of affected)delete live.fileOrder[key];this.save(false);await this.refreshFolders(live,affected);}else this.invalidateFiles(p.id);
    t.fileSelection.clear();for(const {to}of moved)t.fileSelection.set(t.key(to),to);
   }finally{for(const row of sourceRows){row.classList.remove('et-file-moving');row.removeAttribute('aria-busy');}library.resumeOnChange();t.projectMoveDepth--;t.signature='';t.render();code?.sidebar();}
  }
  t.notice(moved.length?'已移动 '+moved.length+' 个文件到 '+(relative||p.name):'文件已在此文件夹');return moved;
 }
 folderMenu(p,f,anchor,point){this.tabs.showMenu([{id:'folder-new',label:'新建子文件夹…',icon:this.icon('folderPlus'),run:()=>this.folderDialog(p,f.relative)},{id:'folder-file',label:'新建文件',icon:this.icon('filePlus'),children:()=>this.fileMenu(f.path)},{id:'folder-rename',label:'重命名…',hint:'F2',icon:this.icon('rename'),run:()=>this.renameDialog(p,f.relative)},null,{id:'folder-output',label:p.outputFolder===f.relative?'取消默认输出文件夹':'设为默认输出文件夹',icon:this.icon('output'),checked:p.outputFolder===f.relative,run:()=>this.setOutputFolder(p,f.relative)},null,{id:'folder-reveal',label:'在资源管理器中打开',icon:this.icon('folder'),run:()=>JSBridge.showInFinder(f.path)},null,{id:'folder-delete',label:'删除…',icon:this.icon('trash'),danger:true,run:()=>this.deleteFolderDialog(p,f.relative)}],point,anchor,'文件夹操作','et-project-menu et-project-row-menu');}
 static fileTypes=[['Markdown','.md','未命名.md'],['Python','.py','main.py'],['HTML','.html','index.html'],['JavaScript','.js','app.js'],['Notebook','.ipynb','未命名.ipynb'],['TypeScript','.ts','main.ts'],['CSS','.css','style.css'],['JSON','.json','data.json'],['CSV','.csv','data.csv'],['文本','.txt','未命名.txt']].map(([label,extension,filename])=>({label,extension,filename}));
 fileMenu(folder){return EditingToolbarProjects.fileTypes.map(type=>({id:'new-file-'+type.extension.slice(1),label:type.label,hint:type.extension,icon:this.tabs.fileIcon(type.filename),run:()=>this.createFile(folder,type)}));}
 async renameDialog(project,relative=null){
  const t=this.tabs,isFolder=relative!==null;let before;
  try{if(isFolder)before=await this.folderDeletionPlan(project,relative,'重命名');}catch(e){t.notice(e.message);return;}
  const d=this.modal(isFolder?'重命名文件夹':'重命名项目','et-create-file-dialog'),form=t.node('form'),label=t.node('label','et-file-name-label',isFolder?'文件夹名称':'项目名称'),input=t.node('input'),error=t.node('p','et-project-error'),foot=t.node('div','et-project-footer'),cancel=t.node('button','','取消'),save=t.node('button','primary','保存');let working=false;
  input.value=isFolder?t.path.basename(before.path):project.name;input.setAttribute('aria-label',isFolder?'文件夹名称':'项目名称');input.autocomplete='off';input.spellcheck=false;input.maxLength=120;input.required=true;error.setAttribute('role','alert');cancel.type='button';save.type='submit';cancel.onclick=()=>d.close();label.append(input);foot.append(cancel,save);form.append(label,error,foot);d.append(form);
  const sync=()=>save.disabled=working||!input.value.trim();input.oninput=()=>{error.textContent='';sync();};
  form.onsubmit=async e=>{e.preventDefault();if(working||save.disabled)return;working=true;const controls=[input,cancel,save,d.querySelector('.et-project-head button')];controls.forEach(b=>b.disabled=true);try{if(isFolder&&(t.busy||t.pending))throw Error('请等待当前文件操作完成后再重命名');if(isFolder)await t.fileAction(()=>this.renameFolder(project,before,input.value));else await this.persistProject(input.value,project.root,project,()=>d.open);d.close();t.notice('已重命名为 '+input.value.trim());}catch(e){error.textContent=e.message;}finally{working=false;controls.forEach(b=>b.disabled=false);sync();}};
  d.oncancel=e=>{if(working)e.preventDefault();};sync();d.showModal();input.focus();input.select();
 }
 relocateFolder(from,to){
  if(from===to)return;const t=this.tabs,inside=file=>this.core.contains(from,file),map=file=>inside(file)?t.path.join(to,t.path.relative(from,file)):file;
  this.read();for(const p of this.items){if(!this.core.contains(p.root,from))continue;const old=t.path.relative(p.root,from).split(t.path.sep).join('/'),next=t.path.relative(p.root,to).split(t.path.sep).join('/'),remap=value=>typeof value==='string'&&(value.toLowerCase()===old.toLowerCase()||value.toLowerCase().startsWith(old.toLowerCase()+'/'))?next+value.slice(old.length):value;
   p.outputFolder=remap(p.outputFolder);p.expandedFolders=p.expandedFolders.map(remap);p.fileOrder=Object.fromEntries(Object.entries(p.fileOrder).map(([key,values])=>[remap(key),values.map(remap)]));this.invalidateFiles(p.id);
  }this.save(false);
  const db=t.read(),code=t.toolbar.codeEditor,nb=t.toolbar.notebook,ai=t.toolbar.aiAssistant,split=t.toolbar.splitView;
  const files=new Set([...['tabs','favorites','pinned'].flatMap(field=>(db[field]||[]).map(x=>x.path)),...[...code?.records.values()||[]].map(x=>x.file),...[...nb?.records.values()||[]].map(x=>x.file),...(ai?.codeUI?.targets||[]).map(x=>x.file),...[...t.fileSelection?.values()||[]],split?.record?.file,File.bundle?.filePath].filter(file=>inside(file)));
  t.replacePaths([...files].map(file=>({from:file,to:map(file)})),{allFiles:true});
  if(t.fileSelection)t.fileSelection=new Map([...t.fileSelection.values()].map(file=>[t.key(map(file)),map(file)]));t.selectionAnchor=null;if(inside(t.pending?.path))t.clearPending();
  if(inside(split?.record?.file))split.record.file=map(split.record.file);
  t.signature='';this.render(false);this.syncAI();return [...files].map(file=>({from:file,to:map(file)}));
 }
 async pauseFolderSearch(quick){
  if(!quick?.worker?.addEventListener||!quick.cacheFolder)return;
  await new Promise((resolve,reject)=>{const worker=quick.worker,finish=error=>{clearTimeout(timer);worker.removeEventListener('message',receive);error?reject(error):resolve();},receive=e=>{if(e.data?.type==='initFileCache'&&e.data.detail?.slice(0,3).every(values=>Array.isArray(values)&&!values.length))finish();},timer=setTimeout(()=>finish(Error('文件索引仍在使用此目录，请稍后重试')),3000);worker.addEventListener('message',receive);try{quick.cacheFolder(null);}catch(e){finish(e);}});
 }
 async renameFolder(project,before,name){
  await this.folderDeletionPlan(project,before.relative,'重命名');const p=this.items.find(x=>x.id===project.id&&x.root===project.root),t=this.tabs,library=File.editor.library,token='folder-'+Date.now()+'-'+Math.random().toString(36).slice(2);let result;
  this.handledMoves||=new Set();this.handledMoves.add(token);if(this.handledMoves.size>100)this.handledMoves.delete(this.handledMoves.values().next().value);
  library.pauseOnChange();t.projectMoveDepth=(t.projectMoveDepth||0)+1;const resumeGraph=t.toolbar.researchSidebar?.pausePathChange(),mount=File.getMountFolder?.(),watch=library.watchedFolder,quick=File.editor.quickOpenPanel;
  if(watch&&library.addFolderWatchByWin)library.addFolderWatchByWin(null);
  try{await this.pauseFolderSearch(quick);await JSBridge.invoke('app.sendEvent','willRename',{oldPath:before.path});result=await this.core.renameFolder(p,before,name);this.relocateFolder(result.from,result.to);}
  finally{try{await JSBridge.invoke('app.sendEvent','didRename',{oldPath:before.path,newPath:result?.to||before.path,etFolderRename:true,etMoveToken:token});}finally{try{const map=file=>result&&this.core.contains(result.from,file)?t.path.join(result.to,t.path.relative(result.from,file)):file;if(mount&&map(mount)!==mount)library.onRootChanged?.(map(mount));else if(watch)library.addFolderWatchByWin?.(map(watch));quick?.cacheFolder?.(map(mount)||null);resumeGraph?.(before.path,result?.to||before.path);}finally{library.resumeOnChange();t.projectMoveDepth--;this.invalidateFiles(p.id);t.schedule();}}}
  return result;
 }
 async deleteFolderDialog(project,relative){
  const t=this.tabs,before=await this.folderDeletionPlan(project,relative),d=this.modal('删除文件夹','et-folder-delete-dialog'),intro=t.node('p','','将此文件夹及其中的文件移到回收站？'),location=t.node('p','et-folder-delete-path',before.path),error=t.node('p','et-project-error'),foot=t.node('div','et-project-footer'),cancel=t.node('button','','取消'),remove=t.node('button','primary et-folder-delete-confirm','移到回收站');let working=false;
  location.title=before.path;error.setAttribute('role','alert');for(const b of [cancel,remove])b.type='button';cancel.onclick=()=>d.close();foot.append(cancel,remove);d.append(intro,location,error,foot);
  remove.onclick=async()=>{if(working)return;working=true;const controls=[cancel,remove,d.querySelector('.et-project-head button')];controls.forEach(b=>b.disabled=true);try{await t.fileAction(()=>this.deleteFolder(project,before));d.close();}catch(e){error.textContent=e.message;}finally{working=false;controls.forEach(b=>b.disabled=false);}};
  d.oncancel=e=>{if(working)e.preventDefault();};d.showModal();cancel.focus();
 }
 async folderDeletionPlan(project,relative,action='删除'){
  this.read();const p=this.items.find(x=>x.id===project.id&&x.root===project.root);if(!p)throw Error('项目已变化，请重新打开菜单');
  const before=await this.core.folderSnapshot(p,relative),inside=file=>this.core.contains(before.path,file),t=this.tabs,code=t.toolbar.codeEditor,split=t.toolbar.splitView,ai=t.toolbar.aiAssistant;
  if(this.items.some(x=>x.id!==p.id&&inside(x.root))||ETCodeWorkspace.owner(reqnode,this.items,t.path.join(before.path,'__delete__'))?.id!==p.id)throw Error('文件夹包含其他已添加的项目，请先处理该项目');
  if([...t.toolbar.notebook?.records.values()||[]].some(r=>inside(r.file)&&(t.toolbar.notebook.dirty(r)||r.saving||r.writing||r.kernel?.state!=='off'&&r.kernel)))throw Error('文件夹中的 Notebook 尚未保存或内核仍在运行，请先保存并关闭内核');
  if([...code?.records.values()||[]].some(r=>inside(r.file)&&(code.dirty(r)||r.saving||r.writing))||inside(File.bundle?.filePath)&&File.isDocumentEdited?.()||inside(split?.record?.file)&&split.dirty)throw Error('文件夹中有未保存的修改，请先保存后再'+action);
  if(ai?.busy||ai?.codeUI?.attaching||ai?.queue?.preparing||ai?.queue?.items?.length)throw Error('请等待 AI 任务结束，或清空待发送消息后再'+action+'文件夹');
  if(code?.preparingRun||t.toolbar.terminal?.creating||(t.toolbar.terminal?.sessions||[]).some(s=>['starting','running','stopping'].includes(s.backend?.state)&&(inside(s.cwd)||inside(s.codeFile))))throw Error('文件夹有正在运行的终端或脚本，请先结束该会话');
  return before;
 }
 async deleteFolder(project,before){
  await this.folderDeletionPlan(project,before.relative);const p=this.items.find(x=>x.id===project.id&&x.root===project.root),t=this.tabs,inside=file=>this.core.contains(before.path,file);
  await this.core.trashFolder(p,before,folder=>JSBridge.invoke('shell.trashItem',t.path.normalize(folder)));
  // Update paths only after the recycle-bin operation succeeded.
  this.read();const live=this.items.find(x=>x.id===project.id&&x.root===project.root),relative=before.relative.toLowerCase(),removedRel=value=>typeof value==='string'&&(value.toLowerCase()===relative||value.toLowerCase().startsWith(relative+'/'));
  if(live){if(removedRel(live.outputFolder))live.outputFolder='';live.expandedFolders=live.expandedFolders.filter(x=>!removedRel(x));live.fileOrder=Object.fromEntries(Object.entries(live.fileOrder).filter(([key])=>!removedRel(key)).map(([key,values])=>[key,values.filter(x=>!removedRel(x))]));this.save(false);}
  for(const [key,file]of t.fileSelection||[])if(inside(file))t.fileSelection.delete(key);t.selectionAnchor=null;if(inside(t.pending?.path))t.clearPending();
  const ai=t.toolbar.aiAssistant;if(ai?.codeUI){ai.codeUI.restore(ai.codeUI.snapshot().filter(x=>!inside(x.file)));ai.conversations.schedule();}
  const split=t.toolbar.splitView;if(inside(split?.record?.file)){split.close();split.record=null;}
  const warnings=[];try{await t.toolbar.codeEditor?.forgetFiles(inside);}catch(e){warnings.push(e.message);}
  try{if(inside(File.bundle?.filePath))window.doApplyRename?.(null);await JSBridge.invoke('app.sendEvent','didRename',{oldPath:t.path.normalize(before.path),newPath:''});await JSBridge.invoke('app.sendEvent','updateQuickOpenCache',{toDel:t.path.normalize(before.path)});}catch(e){warnings.push(e.message);}
  t.signature='';t.change(db=>{for(const field of ['tabs','favorites','pinned'])db[field]=db[field].filter(x=>!inside(x.path));});this.invalidateFiles(p.id);this.render(false);this.syncAI();t.toolbar.codeEditor?.status();t.schedule();t.notice('文件夹已移到回收站。'+(warnings.length?' 刷新提示：'+warnings.join('；'):''));return true;
 }
 folderDialog(project,relative=''){
  const t=this.tabs,d=this.modal('新建子文件夹','et-folder-create-dialog'),form=t.node('form'),intro=t.node('div','et-folder-create-intro'),icon=t.node('span','et-folder-create-icon'),location=t.node('div','et-folder-create-location'),input=t.node('input'),label=t.node('label','et-folder-create-label','文件夹名称'),preview=t.node('div','et-folder-create-preview'),error=t.node('p','et-project-error'),foot=t.node('div','et-project-footer'),cancel=t.node('button','','取消'),save=t.node('button','primary','创建文件夹');let working=false;
  icon.innerHTML=this.icon('folderPlus');location.append(t.node('strong','',project.name),t.node('span','',relative||'项目根目录'));location.title=t.path.join(project.root,relative);intro.append(icon,location);input.id='et-new-folder-name';input.placeholder='例如 results、data、scripts';input.setAttribute('aria-label','文件夹名称');input.autocomplete='off';input.maxLength=120;label.htmlFor=input.id;label.append(input);preview.setAttribute('aria-live','polite');error.setAttribute('role','alert');cancel.type='button';cancel.onclick=()=>d.close();save.type='submit';foot.append(cancel,save);form.append(intro,label,preview,error,foot);d.append(form);
  const sync=()=>{let name='';try{name=this.core.name(input.value);error.textContent='';}catch(e){error.textContent=input.value?e.message:'';}save.disabled=working||!name;preview.textContent=name?'将创建：'+[project.name,relative,name].filter(Boolean).join(' / '):'输入名称后，在当前目录创建一个子文件夹';preview.title=name?t.path.join(project.root,relative,name):'';};input.oninput=sync;
  form.onsubmit=async e=>{e.preventDefault();if(working||save.disabled)return;working=true;for(const b of [input,cancel,save,d.querySelector('.et-project-head button')])b.disabled=true;try{this.read();const p=this.items.find(p=>p.id===project.id&&p.root===project.root);if(!p)throw Error('项目已变化，请重新打开菜单');const f=await this.core.createFolder(p,relative,input.value);p.collapsed=false;p.expandedFolders=[...new Set([...(p.expandedFolders||[]),...(relative?[relative]:[]),f.relative])];this.invalidateFiles();this.save();d.close();t.notice('已创建 '+f.relative);}catch(e){error.textContent=e.message;}finally{working=false;for(const b of [input,cancel,save,d.querySelector('.et-project-head button')])if(b)b.disabled=false;}};
  d.oncancel=e=>{if(working)e.preventDefault();};sync();d.showModal();input.focus();
 }
 modal(title,cls=''){const t=this.tabs,previous=document.activeElement,d=t.node('dialog','et-project-dialog '+cls),head=t.node('div','et-project-head'),h=t.node('h3','',title),close=t.button('关闭'+title,'close');d.setAttribute('aria-label',title);head.append(h,close);d.append(head);close.onclick=()=>d.close();d.onclose=()=>{d.remove();(previous?.isConnected?previous:t.add).focus({preventScroll:true});};for(const type of ['keydown','mousedown','click','input','paste'])d.addEventListener(type,e=>e.stopPropagation());document.body.append(d);return d;}
 // Called only by the dialog's explicit submit. Merely choosing a folder does not trust it.
 async persistProject(name,folder,existing,stillOpen=()=>true){
  const t=this.tabs,plan=await this.core.plan(name,folder,t.toolbar.knowledgeLibrary.rootPath);if(!stillOpen())return null;this.read();
  const current=existing?this.items.find(p=>p.id===existing.id):null;
  if(existing&&(!current||current.name!==existing.name||t.key(current.root)!==t.key(existing.root)))throw Error('项目已在其他窗口更改，请重新打开编辑');
  if(this.items.some(p=>p.id!==current?.id&&t.key(p.root)===t.key(plan.root)))throw Error('此文件夹已添加为项目');
  const changedRoot=!current||t.key(current.root)!==t.key(plan.root);
  if(changedRoot&&(!await this.consent(plan.root)||!stillOpen()))return null;
  let trusted;if(changedRoot)trusted=await this.core.trust(plan);else{await this.core.check(current);trusted={...current,name:plan.name};}
  if(!stillOpen())return null;this.read();const latest=current&&this.items.find(p=>p.id===current.id);
  if(current&&(!latest||latest.name!==current.name||t.key(latest.root)!==t.key(current.root)))throw Error('项目已在其他窗口更改，请重新打开编辑');
  if(this.items.some(p=>p.id!==current?.id&&t.key(p.root)===t.key(trusted.root)))throw Error('此文件夹已添加为项目');
  const result={...trusted,name:plan.name,...(latest?{id:latest.id,pinned:latest.pinned,collapsed:latest.collapsed,sectionId:latest.sectionId,fileOrder:changedRoot?{}:latest.fileOrder,expandedFolders:changedRoot?[]:latest.expandedFolders,outputFolder:changedRoot?'':latest.outputFolder}:{pinned:false,collapsed:false,sectionId:null})};
  if(latest)this.items=this.items.map(p=>p.id===latest.id?result:p);else {this.items.push(result);this.activeId=result.id;this.groupsCollapsed.projects=false;}
  if(changedRoot&&latest&&this.defaultFolder?.id===latest.id)this.defaultFolder=null;this.save();return result;
 }
 async createDialog(existing=null){
  if(this.dialog?.open)return;const t=this.tabs,d=this.dialog=this.modal(existing?'编辑项目':'创建项目','et-project-setup'),form=t.node('form'),name=t.node('input'),nameField=t.node('label','et-project-name'),folderLabel=t.node('div','et-project-source-label','源文件夹'),area=t.node('div','et-project-folder'),folderRow=t.node('div','et-project-chosen'),folderButton=t.node('button','et-project-folder-path'),reset=t.button('移除所选文件夹','close'),location=t.node('details','et-project-location'),summary=t.node('summary'),menu=t.node('div','et-project-location-menu'),chooseLocal=t.node('button','','选择本机文件夹…'),useLibrary=t.node('button','','使用知识库文件夹'),choose=t.node('button','et-project-choose'),error=t.node('p','et-project-error'),foot=t.node('div','et-project-footer'),cancel=t.node('button','et-project-cancel','取消'),submit=t.node('button','primary',existing?'保存更改':'创建项目');let chosen=existing?.root||'',working=false;
  name.required=true;name.maxLength=120;name.placeholder='项目名称';name.setAttribute('aria-label','项目名称');name.value=existing?.name||'';name.autocomplete='off';nameField.innerHTML=this.icon('folder');nameField.append(name);
  summary.append(t.node('span','','在此电脑上添加文件夹'));summary.insertAdjacentHTML('beforeend',this.icon('chevron'));for(const b of [chooseLocal,useLibrary,choose,folderButton,reset,cancel])b.type='button';submit.type='submit';error.setAttribute('role','alert');folderButton.innerHTML=this.icon('folder');const path=t.node('span');folderButton.append(path);folderRow.append(folderButton,reset);choose.innerHTML=this.icon('folderPlus')+'<span>添加</span>';menu.append(chooseLocal,useLibrary);location.append(summary,menu);area.append(folderRow,location,choose);foot.append(cancel,submit);form.append(nameField,folderLabel,area,error,foot);d.append(form);
  const sync=()=>{folderRow.hidden=!chosen;path.textContent=chosen;folderButton.title=chosen;choose.querySelector('span').textContent=chosen?'更换':'添加';submit.disabled=working||!name.value.trim();};
  const picker=async()=>{if(working)return;location.open=false;choose.disabled=true;try{const result=await JSBridge.invoke('dialog.showOpenDialog',{title:'选择项目文件夹',properties:['openDirectory']});if(result?.canceled||!result?.filePaths?.[0]||!d.open)return;chosen=result.filePaths[0];if(!name.value.trim())name.value=t.path.basename(chosen);sync();}catch(e){error.textContent=e.message;}finally{choose.disabled=false;}};
  name.oninput=()=>{error.textContent='';sync();};choose.onclick=chooseLocal.onclick=folderButton.onclick=picker;reset.onclick=useLibrary.onclick=()=>{if(working)return;chosen='';location.open=false;sync();};cancel.onclick=()=>d.close();location.addEventListener('keydown',e=>{if(e.key==='Escape'&&location.open){e.preventDefault();e.stopPropagation();location.open=false;summary.focus();}});d.addEventListener('click',e=>{if(!location.contains(e.target))location.open=false;});
  form.onsubmit=async e=>{e.preventDefault();if(working||!name.value.trim())return;working=true;sync();error.textContent='';for(const input of [name,choose,chooseLocal,useLibrary,reset,folderButton,cancel,d.querySelector('.et-project-head button')])input.disabled=true;try{const project=await this.persistProject(name.value,chosen,existing,()=>d.open);if(project){d.close();t.notice((existing?'已更新项目 ':'已创建项目 ')+project.name);}}catch(e){error.textContent=e.message;}finally{working=false;for(const input of [name,choose,chooseLocal,useLibrary,reset,folderButton,cancel,d.querySelector('.et-project-head button')])input.disabled=false;sync();}};
  d.oncancel=e=>{if(working)e.preventDefault();};sync();d.showModal();name.focus();if(existing)name.select();
 }
 consent(root){return new Promise(resolve=>{const t=this.tabs,d=this.modal('信任此文件夹吗？','et-project-trust-dialog'),path=t.node('p','et-project-trust-path',root),text=t.node('p','et-project-description','信任后，AI 可在编辑模式下按你的要求创建文件。可通过项目菜单将此文件夹设为 AI 新文件的默认保存目录。请仅在你信任此文件夹时继续。'),confirm=t.node('button','primary et-project-trust','信任文件夹'),cancel=t.node('button','et-project-trust','取消');let ok=false;confirm.type=cancel.type='button';confirm.onclick=()=>{ok=true;d.close();};cancel.onclick=()=>d.close();d.append(path,text,confirm,cancel);d.addEventListener('close',()=>resolve(ok),{once:true});d.showModal();d.tabIndex=-1;d.focus();});}
 async manualDestination(folder){if(!folder||!this.tabs.path.isAbsolute(folder))throw Error('请点击右侧文件夹图标选择保存位置，或先设置默认项目文件夹');let root;try{root=await this.core.fs.realpath(folder);if(!(await this.core.fs.stat(root)).isDirectory())throw Error('not directory');}catch{throw Error('保存文件夹不可用，请点击右侧文件夹图标重新选择');}return {root,trusted:true};}
 async createManualFile(folder,relative,extension=''){const destination=await this.manualDestination(folder);relative=relative.trim();const name=this.tabs.path.basename(relative);if(extension&&!this.tabs.path.extname(name)&&!name.startsWith('.'))relative+=extension;const content=/\.ipynb$/i.test(relative)?JSON.stringify(ETNotebookStore.blank(()=>this.core.crypto.randomUUID()),null,1)+'\n':'';return this.core.createFile(destination,relative,content);}
 createFile(folder,type=null){
  const t=this.tabs,d=this.modal(type?'新建 '+type.label:'创建文件','et-create-file-dialog'),form=t.node('form'),input=t.node('input'),field=t.node('span','et-file-name-field'),choose=t.node('button','et-file-folder'),err=t.node('p','et-project-error'),foot=t.node('div','et-project-footer'),cancel=t.node('button','','取消'),save=t.node('button','primary','创建文件');let chosen=folder||this.defaultProject()?.root||'',working=false;
  input.required=true;input.value=type?.filename||'';input.placeholder='例如 main.py、app.js、index.html';input.setAttribute('aria-label','文件名称');input.autocomplete='off';input.spellcheck=false;choose.type='button';choose.setAttribute('aria-label','选择保存文件夹');choose.innerHTML=this.icon('folder');err.setAttribute('role','alert');cancel.type='button';cancel.onclick=()=>d.close();save.type='submit';field.append(input,choose);foot.append(cancel,save);const label=t.node('label','et-file-name-label','文件名');label.append(field);form.append(label,err,foot);d.append(form);
  const sync=()=>{choose.title=chosen?'保存到：'+chosen:'选择保存文件夹';choose.setAttribute('aria-description',choose.title);choose.classList.toggle('has-folder',!!chosen);save.disabled=working||!input.value.trim();};input.oninput=()=>{err.textContent='';sync();};
  choose.onclick=async()=>{if(working)return;working=true;choose.disabled=true;sync();try{const result=await JSBridge.invoke('dialog.showOpenDialog',{title:'选择保存文件夹',defaultPath:chosen||t.toolbar.knowledgeLibrary?.rootPath,properties:['openDirectory']});if(result?.canceled||!result?.filePaths?.[0]||!d.open)return;const destination=await this.manualDestination(result.filePaths[0]);if(!d.open)return;chosen=destination.root;err.textContent='';}catch(e){err.textContent=e.message;}finally{working=false;choose.disabled=false;sync();if(d.open)input.focus();}};
  form.onsubmit=async e=>{e.preventDefault();if(working)return;working=true;sync();for(const b of [input,choose,cancel,d.querySelector('.et-project-head button')])b.disabled=true;try{const f=await this.createManualFile(chosen,input.value,type?.extension||'');this.render();d.close();t.notice('已创建 '+f.relative);if(t.supported(f.path)||t.toolbar.codeEditor?.supported(f.path))await t.openEntry(f.path);}catch(e){err.textContent=e.message;}finally{working=false;for(const b of [input,choose,cancel,d.querySelector('.et-project-head button')])if(b)b.disabled=false;sync();}};
  d.oncancel=e=>{if(working)e.preventDefault();};sync();d.showModal();input.focus();if(type)input.setSelectionRange(0,input.value.length-type.extension.length);
 }
}
