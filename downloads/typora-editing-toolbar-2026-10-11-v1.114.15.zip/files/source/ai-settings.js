// Model settings presentation. Profiles are committed only by Save configuration.
class EditingToolbarAISettings {
  constructor(ai) { this.ai = ai; }
  static icon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 5.5c2.8-.8 5.2-.2 8 1.5 2.8-1.7 5.2-2.3 8-1.5v12c-2.8-.8-5.2-.2-8 1.5-2.8-1.7-5.2-2.3-8-1.5zM12 7v12"/><path d="m18 1 .7 1.8L20.5 3.5l-1.8.7L18 6l-.7-1.8-1.8-.7 1.8-.7z"/></svg>';
  mountWindow() {
    const a=this.ai,backdrop=a.node('div','et-ai-preferences-backdrop');backdrop.hidden=true;
    const dialog=a.node('section');dialog.id='et-ai-preferences';dialog.setAttribute('role','dialog');dialog.setAttribute('aria-modal','true');dialog.setAttribute('aria-labelledby','et-ai-preferences-title');
    dialog.dataset.layout='float';
    dialog.innerHTML=['n','s','e','w','ne','nw','se','sw'].map(edge=>'<div class="et-ai-resize" data-edge="'+edge+'" role="separator" aria-label="调整设置窗口大小 '+edge+'" tabindex="'+(edge==='se'?0:-1)+'"></div>').join('')+'<div class="et-ai-header"><strong id="et-ai-preferences-title">AI 助手设置</strong><div class="et-ai-header-actions"><button type="button" data-ai="close-settings" title="关闭设置" aria-label="关闭设置">×</button></div></div><nav class="et-ai-nav" role="tablist" aria-label="设置分类"><button role="tab" data-ai="settings" aria-selected="true">模型</button><button role="tab" data-ai="prompts" aria-selected="false" tabindex="-1">提示词</button></nav>'+this.html()+'<div class="et-ai-status" role="status" aria-live="polite">修改后点击保存</div>';
    backdrop.append(dialog);document.body.append(backdrop);
    a.preferencesBackdrop=backdrop;a.preferences=dialog;a.preferencesStatus=dialog.querySelector('.et-ai-status');a.settingsPanel=dialog.querySelector('.et-ai-settings');a.form=dialog.querySelector('form');a.nav=dialog.querySelector('.et-ai-nav');
    this.motion=new EditingToolbarAIMotion(a,true);this.motion.mount();
    window.addEventListener('resize',()=>{this.motion.finish(true);this.layoutWindow();});
    dialog.onkeydown=e=>{
      if(e.key==='Escape'){e.preventDefault();e.stopPropagation();if(!this.menu.hidden||!this.tip.hidden){this.closeMenu();this.hideHelp();}else this.closeWindow();return;}
      if(['ArrowLeft','ArrowRight'].includes(e.key)&&e.target.closest('[role=tablist]')){e.preventDefault();const buttons=[...a.nav.children],at=buttons.indexOf(document.activeElement),next=buttons[(at+(e.key==='ArrowRight'?1:-1)+buttons.length)%buttons.length];next.click();next.focus();}
      if(e.key==='Tab'){const nodes=[...dialog.querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex="0"]')].filter(n=>n.tabIndex>=0&&n.offsetParent!==null&&!n.closest('[inert]'));const first=nodes[0],last=nodes.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}}
    };
  }
  openWindow() {
    const a=this.ai;if(!a.preferencesBackdrop.hidden)return;
    this.windowReturnFocus=document.activeElement;a.preferencesBackdrop.hidden=false;a.panel.inert=true;if(a.selectionUI?.temporary.dialog)a.selectionUI.temporary.dialog.inert=true;this.layoutWindow();
    a.nav.querySelector('[aria-selected=true]')?.focus();
  }
  closeWindow(focus=true) {
    const a=this.ai;if(!a.preferences)return;
    this.motion.finish(true);this.closeEditor();this.closeMenu();this.hideHelp();a.preferencesBackdrop.hidden=true;a.panel.inert=false;if(a.selectionUI?.temporary.dialog)a.selectionUI.temporary.dialog.inert=false;
    if(a.settingsBusy)a.controller?.abort();a.chatgptUI?.controller?.abort();a.pluginsUI?.close();
    // Closing discards the form draft; credentials are only committed by Save.
    a.settingsInitialized=false;if(a.form)a.form.elements.key.value='';a.clearKey=false;
    if(focus&&this.windowReturnFocus?.isConnected)this.windowReturnFocus.focus();
  }
  layoutWindow() {
    const a=this.ai;if(a.preferencesBackdrop.hidden)return;
    this.closeMenu();this.hideHelp();
    const saved=this.motion.state,maxW=Math.max(180,innerWidth-16),maxH=Math.max(180,innerHeight-16);
    const width=Math.min(maxW,Math.max(360,Number(saved.width)||540)),height=Math.min(maxH,Math.max(340,Number(saved.height)||550));
    const x=Number.isFinite(saved.position?.x)?saved.position.x:(innerWidth-width)/2,y=Number.isFinite(saved.position?.y)?saved.position.y:(innerHeight-height)/2;
    const values={width:width+'px',height:height+'px',left:Math.max(8,Math.min(x,innerWidth-width-8))+'px',top:Math.max(8,Math.min(y,innerHeight-height-8))+'px'};
    for(const [key,value] of Object.entries(values))if(a.preferences.style[key]!==value)a.preferences.style[key]=value;
  }
  html() {
    return `<div class="et-ai-settings" hidden><form autocomplete="off"><div class="et-ai-model-fields"><div class="et-ai-profile-grid">
      <label>配置<select name="profile"><option value="new">＋ 新建配置</option></select></label>
      <label>配置名称<input name="name" maxlength="60"></label></div>
      <div class="et-ai-url-label"><label for="et-ai-api-url">API 地址</label><label class="et-ai-full-url"><input name="fullUrl" type="checkbox" checked>Full URL</label></div>
      <div class="et-ai-endpoint-control"><input id="et-ai-api-url" name="url" type="url" role="combobox" aria-expanded="false" aria-controls="et-ai-provider-menu" aria-label="API 地址" autocomplete="off" spellcheck="false"><button type="button" data-ai="providers" aria-label="选择服务商地址" title="选择服务商地址" aria-expanded="false"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="m4 6 4 4 4-4"/></svg></button></div>
      <input name="provider" type="hidden" value="custom"><small class="et-ai-endpoint-preview" hidden></small>
      <label for="et-ai-api-key">API Key</label>
      <div class="et-ai-key-control"><input id="et-ai-api-key" name="key" type="password" autocomplete="new-password" spellcheck="false"><button type="button" data-ai="clear-key" aria-label="清除密钥" title="清除密钥"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 10v7M14 10v7"/></svg></button></div>
      <div class="et-ai-key-row"><label><input name="remember" type="checkbox">加密记住密钥</label></div>
      <label>模型名称<div class="et-ai-model-control"><input name="model" spellcheck="false"><select name="deepseekModel" class="et-ai-deepseek-models" aria-label="DeepSeek 型号" hidden><option value="">自定义模型</option><option value="deepseek-flash">DeepSeek Flash</option><option value="deepseek-v4-pro">DeepSeek V4 Pro</option></select></div></label>
      <div class="et-ai-parameter-group"><div class="et-ai-param"><label><input type="checkbox" name="temperatureEnabled">Temperature</label><input aria-label="Temperature 数值" name="temperature" type="number" min="0" max="2" step="0.1" value="0.7"></div>
      <div class="et-ai-param"><label><input type="checkbox" name="maxTokensEnabled">Max Tokens</label><input aria-label="Max Tokens 数值" name="maxTokens" type="number" min="1" max="262144" value="4096"></div></div>
      <details class="et-ai-advanced"><summary>高级设置</summary>
        <div class="et-ai-setting-row"><label for="et-ai-protocol">Protocol</label><select id="et-ai-protocol" name="protocol">${Object.entries(ETAIClient.protocols).map(([value,label]) => `<option value="${value}">${label}</option>`).join('')}</select>${this.help('protocol','选择服务要求的接口协议。协议决定请求地址、消息格式与流式解析；Full URL 使用填写的完整地址，关闭后按协议补全。')}</div>
        <div class="et-ai-setting-row"><label>System Prompt</label><button type="button" data-ai="edit-system">Edit</button>${this.help('system','自定义系统提示词，随每次对话发送。留空使用中文学术阅读助手的默认提示词；编辑完成后需保存配置。')}</div>
        <div class="et-ai-setting-row"><label>Extra Params</label><button type="button" data-ai="edit-extra">Edit</button>${this.help('extra','以 JSON 对象填写模型支持的额外参数。不能覆盖消息、协议核心字段或启用工具调用。留空不附加参数；编辑完成后需保存配置。')}</div>
        <input type="hidden" name="system"><input type="hidden" name="extra">
      </details>
      </div><div class="et-ai-settings-actions"><button type="button" data-ai="delete-profile">删除配置</button><span></span><button type="button" data-ai="test">测试连接</button><button type="submit" class="et-ai-primary">保存配置</button></div>
    </form></div>`;
  }
  help(id, text) { return `<button type="button" class="et-ai-help" data-help="${id}" title="${text}" aria-label="${text}" aria-expanded="false"><svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="10" r="7.3"/><path d="M10 5.6v5.1M10 13.7v.2"/></svg></button>`; }
  mount() {
    const a = this.ai, f = a.form.elements;
    const menu = a.node('div','et-ai-provider-menu'); menu.id = 'et-ai-provider-menu'; menu.hidden = true; menu.setAttribute('role','listbox'); menu.setAttribute('aria-label','服务商地址'); a.preferences.append(menu); this.menu = menu;
    for (const provider of ETAIPrompts.providers.filter(x => x.url)) {
      const b = a.node('button'); b.type = 'button'; b.dataset.provider = provider.id; b.setAttribute('role','option');
      b.append(a.node('span','et-ai-provider-url',provider.url),a.node('span','et-ai-provider-tag',provider.name)); b.title = provider.url;
      b.onclick = () => this.choose(provider); menu.append(b);
    }
    const tip = a.node('div','et-ai-help-tooltip'); tip.hidden = true; tip.setAttribute('role','tooltip'); tip.id = 'et-ai-help-tooltip'; a.preferences.append(tip); this.tip = tip;
    for (const b of a.preferences.querySelectorAll('[data-help]')) {
      const show = () => this.showHelp(b);
      b.onclick = show;
      b.onmouseenter = show; b.onmouseleave = () => { if (document.activeElement !== b) this.hideHelp(); };
      b.onfocus = show; b.onblur = () => this.hideHelp();
    }
    a.preferences.addEventListener('pointerdown',e => { if (!e.target.closest('.et-ai-endpoint-control,.et-ai-provider-menu')) this.closeMenu(); if (!e.target.closest('[data-help],.et-ai-help-tooltip')) this.hideHelp(); });
    a.settingsPanel.querySelector('.et-ai-model-fields').addEventListener('scroll',() => {
      // Focus/scrollIntoView may dispatch a delayed scroll after a popup opens.
      // Dismiss only if its anchor actually moved since positioning it.
      for(const popup of [this.menu,this.tip]) if(!popup.hidden&&popup._anchor&&Math.abs(popup._anchor.getBoundingClientRect().top-popup._anchorTop)>1) {
        if(popup===this.menu)this.closeMenu();else this.hideHelp();
      }
    });
    f.url.addEventListener('input',() => { f.provider.value = 'custom'; this.preview();this.syncDeepSeek();this.syncKey(); });
    f.key.addEventListener('input',()=>this.syncKey());
    f.model.addEventListener('input',()=>this.syncDeepSeek());
    f.deepseekModel.onchange=()=>{if(!f.deepseekModel.value)return;f.model.value=f.deepseekModel.value;this.syncDeepSeek();};
    f.fullUrl.onchange = () => {
      try {
        if (f.url.value.trim()) {
          if (f.fullUrl.checked) f.url.value = ETAIClient.endpoint(f.url.value,f.protocol.value,false);
          else f.url.value = f.url.value.replace(/\/(?:chat\/completions|responses|messages)\/?$/, '');
        }
        this.preview();
      } catch(e) { a.notice(e.message,true); }
    };
    f.protocol.onchange = () => {
      const suffix = {'openai-chat':'/chat/completions','openai-responses':'/responses','anthropic-messages':'/messages'}[f.protocol.value];
      if (f.fullUrl.checked) f.url.value = f.url.value.replace(/\/(?:chat\/completions|responses|messages)\/?$/,suffix);
      f.provider.value = 'custom'; this.sync();
    };
    for (const name of ['temperatureEnabled','maxTokensEnabled']) f[name].onchange = () => this.sync();
    f.url.addEventListener('keydown',e => {
      if(e.key === 'ArrowDown') { e.preventDefault(); this.openMenu(); this.menu.querySelector('button')?.focus(); }
      if(e.key === 'Escape') this.closeMenu();
    });
    menu.onkeydown = e => {
      const buttons = [...menu.querySelectorAll('button')], at = buttons.indexOf(document.activeElement);
      if (['ArrowDown','ArrowUp','Home','End'].includes(e.key)) { e.preventDefault(); const index = e.key === 'Home' ? 0 : e.key === 'End' ? buttons.length-1 : (at+(e.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length; buttons[index].focus(); }
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); this.closeMenu(); f.url.focus(); }
      if (e.key === 'Tab') this.closeMenu();
    };
  }
  preview() {
    const f = this.ai.form.elements, n = this.ai.preferences.querySelector('.et-ai-endpoint-preview');
    n.hidden = f.fullUrl.checked || !f.url.value.trim();
    try { n.textContent = ETAIClient.endpoint(f.url.value,f.protocol.value,f.fullUrl.checked); } catch { n.textContent = ''; }
  }
  sync() {
    const a = this.ai, f = a.form.elements;
    f.temperature.disabled = a.settingsBusy || !f.temperatureEnabled.checked;
    f.maxTokens.disabled = a.settingsBusy || !f.maxTokensEnabled.checked;
    f.temperature.max = f.protocol.value === 'anthropic-messages' ? '1' : '2';
    f.protocol.title = ETAIClient.protocols[f.protocol.value];
    f.maxTokens.title = f.protocol.value === 'anthropic-messages' ? 'Anthropic 要求输出上限；未勾选时使用 4096。' : '勾选后发送输出上限';
    for (const key of ['system','extra']) {
      const b = a.preferences.querySelector('[data-ai="edit-'+key+'"]'); b.dataset.filled = String(!!f[key].value.trim()); b.setAttribute('aria-label','编辑'+(key==='system'?'系统提示词':'额外参数')+(f[key].value.trim()?'（已设置）':''));
    }
    this.preview();this.syncDeepSeek();this.syncKey();
  }
  syncKey(){
    const a=this.ai,f=a.form.elements,previous=a.config.profiles.find(p=>p.id===a.editingId);let same=false;
    try{same=new URL(previous?.url).origin===new URL(f.url.value).origin;}catch{}
    const stored=!!(!a.clearKey&&same&&(previous?.secret||a.keys.get(previous?.id)));
    // A visual mask only: never decrypt into the form or submit placeholder characters.
    f.key.placeholder=stored?'••••••••••••••••':'';f.key.dataset.keyStored=String(stored);
    f.key.title=stored?'已保存密钥；输入新密钥可替换':'填写 API Key，本机模型可留空';f.key.setAttribute('aria-label',stored?'API Key（已保存，输入可替换）':'API Key');
    a.preferences.querySelector('[data-ai=clear-key]').disabled=a.settingsBusy||(!stored&&!f.key.value);
  }
  syncDeepSeek(){
    const f=this.ai.form.elements,row=this.ai.preferences.querySelector('.et-ai-deepseek-models');let official=false;
    try{official=new URL(f.url.value).origin==='https://api.deepseek.com';}catch{}
    row.hidden=!official;if(!official)return;
    const model=f.model.value.trim();f.deepseekModel.value=['deepseek-flash','deepseek-v4-pro'].includes(model)?model:'';
  }
  positionPopup(element, anchor, width) {
    const a = this.ai.preferences.getBoundingClientRect(), r = anchor.getBoundingClientRect();
    element._anchor=anchor; element._anchorTop=r.top;
    element.style.width = Math.min(width,a.width-20) + 'px';
    element.style.left = Math.max(9,Math.min(r.left-a.left,a.width-element.offsetWidth-10))+'px';
    const below = a.bottom-r.bottom-12, above = r.top-a.top-12;
    element.style.maxHeight = Math.max(90,Math.min(350,Math.max(below,above)))+'px';
    const height = element.getBoundingClientRect().height;
    element.style.top = (below>=height||below>=above ? Math.min(r.bottom-a.top+5,a.height-height-8) : Math.max(8,r.top-a.top-height-5))+'px';
  }
  openMenu() {
    if (this.ai.settingsBusy) return;
    this.hideHelp(); this.menu.hidden = false;
    for(const b of this.menu.children) b.setAttribute('aria-selected',String(b.dataset.provider===this.ai.form.elements.provider.value));
    this.positionPopup(this.menu,this.ai.preferences.querySelector('.et-ai-endpoint-control'),440);
    for(const n of [this.ai.form.elements.url,this.ai.preferences.querySelector('[data-ai="providers"]')]) n.setAttribute('aria-expanded','true');
  }
  closeMenu() { if (!this.menu) return; this.menu.hidden = true; for(const n of [this.ai.form.elements.url,this.ai.preferences.querySelector('[data-ai="providers"]')]) n.setAttribute('aria-expanded','false'); }
  choose(p) {
    const a = this.ai, f = a.form.elements;
    let same = false; try { same = new URL(f.url.value).origin === new URL(p.url).origin; } catch {}
    f.provider.value=p.id; f.url.value=p.url; f.protocol.value=p.protocol || 'openai-chat'; f.fullUrl.checked=true;
    if (!f.name.value.trim()) f.name.value=p.name;
    if (!same) { f.model.value=''; f.key.value=''; a.clearKey=true; f.remember.checked=false; f.extra.value=''; f.temperatureEnabled.checked=f.maxTokensEnabled.checked=false; }
    this.closeMenu(); this.sync(); f.model.focus(); a.notice('已选择 '+p.name);
  }
  showHelp(b) { this.hideHelp(); this.tipButton=b; this.tip.textContent=b.title; this.tip.hidden=false; b.setAttribute('aria-expanded','true'); b.setAttribute('aria-describedby',this.tip.id); this.positionPopup(this.tip,b,310); }
  hideHelp() { if(this.tip) this.tip.hidden=true; if(this.tipButton) { this.tipButton.setAttribute('aria-expanded','false'); this.tipButton.removeAttribute('aria-describedby'); } this.tipButton=null; }
  edit(key) {
    const a=this.ai; if(a.settingsBusy||this.editor) return;
    this.closeMenu(); this.hideHelp(); this.returnFocus=document.activeElement;
    const layer=a.node('div','et-ai-editor-layer'); layer.setAttribute('role','dialog'); layer.setAttribute('aria-modal','true'); layer.setAttribute('aria-labelledby','et-ai-editor-title');
    layer.innerHTML='<div class="et-ai-editor-heading"><strong id="et-ai-editor-title"></strong><button type="button" aria-label="关闭编辑器" data-editor="cancel">×</button></div><textarea spellcheck="false"></textarea><div class="et-ai-editor-error" role="alert"></div><div class="et-ai-editor-actions"><button type="button" data-editor="cancel">取消</button><button type="button" class="et-ai-primary" data-editor="save">保存</button></div>';
    const title=key==='system'?'系统提示词':'额外参数 · JSON'; layer.querySelector('strong').textContent=title;
    const input=layer.querySelector('textarea'); input.value=a.form.elements[key].value; input.setAttribute('aria-label',title); input.maxLength=key==='system'?32000:16000;
    const save=() => { try { if(key==='extra') ETAIClient.extra(input.value); a.form.elements[key].value=input.value.trim(); this.closeEditor(); this.sync(); a.notice('编辑已保留，请保存模型配置'); } catch(e) { layer.querySelector('[role=alert]').textContent=e.message; input.focus(); } };
    layer.addEventListener('click',e => { const action=e.target.closest('[data-editor]')?.dataset.editor; if(action==='cancel') this.closeEditor(); if(action==='save') save(); });
    layer.onkeydown=e => {
      if(e.key==='Escape') { e.preventDefault(); e.stopPropagation(); this.closeEditor(); }
      if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)&&!e.isComposing) { e.preventDefault(); save(); }
      if(e.key==='Tab') { const nodes=[...layer.querySelectorAll('button,textarea')], first=nodes[0], last=nodes.at(-1); if(e.shiftKey&&document.activeElement===first) {e.preventDefault();last.focus();} else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();} }
    };
    this.editor=layer; a.preferences.append(layer); this.motion.bindHandle(layer.querySelector('.et-ai-editor-heading')); for(const el of [a.settingsPanel,a.promptsManager.panel,a.nav,a.preferences.querySelector('.et-ai-header')]) el.inert=true; input.focus();
  }
  closeEditor() {
    if(!this.editor) return; this.editor.remove(); this.editor=null;
    const a=this.ai; for(const el of [a.settingsPanel,a.promptsManager.panel,a.nav,a.preferences.querySelector('.et-ai-header')]) el.inert=false;
    if(this.returnFocus?.isConnected) this.returnFocus.focus();
  }
}
