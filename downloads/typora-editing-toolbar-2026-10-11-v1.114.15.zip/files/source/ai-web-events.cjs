'use strict';
// No preload, Node access or cross-origin messages. The host pulls a bounded
// public snapshot after a change; page mutations and matched SSE wake it early.
module.exports = async function webEvents(action,args={},createDecoder) {
  if(location.origin!=='https://chatgpt.com')throw Error('Unexpected website origin');
  const key='__etWebReplyEvents34',normalize=s=>String(s||'').replace(/\s+/g,' ').trim();
  const digest=async value=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value))),b=>b.toString(16).padStart(2,'0')).join('');
  const identityCookies=()=>document.cookie.split(';').map(x=>x.trim()).filter(x=>/^(?:(?:__Secure-|__Host-)?(?:next-auth\.|authjs\.)|oai-|chatgpt-|account(?:=|[-_])|workspace(?:=|[-_]))/i.test(x)).sort().join(';');
  if(action==='scope-hint'){window.__etWebScopeContext35 ||= Math.random().toString(36).slice(2);return {stamp:await digest(identityCookies()),documentId:window.__etWebScopeContext35};}
  if(action==='scope'){
    const before=identityCookies(),controller=new AbortController(),timer=setTimeout(()=>controller.abort(),800);
    try{
      const response=await fetch('/api/auth/session',{credentials:'same-origin',cache:'no-store',signal:controller.signal});
      if(!response.ok)return {status:'unavailable',reason:'request'};const session=await response.json();
      // Missing workspace identity disables persistent list/membership reuse.
      // Tokens remain in the website; only an opaque principal digest is returned.
      const user=session.user?.id,account=session.account?.id;
      if(!user||!account)return {status:'unavailable',reason:'incomplete'};
      if(before!==identityCookies())return {status:'unavailable',reason:'context'};
      return {status:'verified',key:await digest(JSON.stringify([user,account]))};
    }catch{return {status:'unavailable',reason:'request'};}finally{clearTimeout(timer);}
  }
  let state=window[key];
  if(action==='accept-scope'){if(state?.id===args.id)state.acceptScope();return null;}
  if(action==='dispose'){if(state?.id===args.id)state.dispose();return null;}
  if(action==='arm'){
    state?.dispose();const original=window.fetch;let initialCookie=document.cookie;
    state={id:args.id,revision:1,domRevision:1,disposed:false,decoder:null,reader:null,stream:false,failed:false,eof:false,started:Date.now(),firstTextAt:0,completeAt:0};
    const waiters=new Set();let timer,observed=false;
    const wake=()=>{clearTimeout(timer);timer=null;state.revision++;for(const end of [...waiters])end();};
    const changed=()=>{if(!timer)timer=setTimeout(wake,60);};
    const observer=new MutationObserver(records=>{if(records.some(r=>{const e=r.target.nodeType===1?r.target:r.target.parentElement;return e?.closest('main,[role="main"],[data-message-role],[data-message-author-role],[data-agent-activity]')||Array.from(r.addedNodes||[]).some(n=>n.nodeType===1&&n.matches('main,[role="main"],[data-testid="stop-button"]'));})){state.domRevision++;changed();}});
    observer.observe(document.body,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['disabled','hidden','aria-hidden','aria-busy','data-message-id','class']});
    const matches=async(input,init)=>{
      try{
        const url=new URL(typeof input==='string'?input:input.url,location.href),method=init?.method||input?.method||'GET';
        if(method.toUpperCase()!=='POST'||url.origin!==location.origin||!/^\/backend-api\/(?:f\/)?conversation$/.test(url.pathname))return false;
        const raw=typeof init?.body==='string'?init.body:input instanceof Request?await input.clone().text():'';
        if(!raw||raw.length>3*1024*1024)return false;const body=JSON.parse(raw);
        if(args.conversationId&&body.conversation_id!==args.conversationId)return false;
        const users=(body.messages||[]).filter(m=>m.author?.role==='user');
        return users.length===1&&Array.isArray(users[0].content?.parts)&&normalize(users[0].content.parts.filter(p=>typeof p==='string').join(''))===normalize(args.text);
      }catch{return false;}
    };
    const consume=async response=>{
      if(state.disposed||document.cookie!==initialCookie||!response.ok||!response.headers.get('content-type')?.includes('text/event-stream'))return;
      const reader=response.body.getReader(),decoder=state.decoder=createDecoder(),utf8=new TextDecoder();state.reader=reader;state.stream=true;wake();
      try{while(!state.disposed){const {done,value}=await reader.read();if(done){decoder.push(utf8.decode());decoder.end();state.eof=true;wake();break;}decoder.push(utf8.decode(value,{stream:true}));const s=decoder.state();if(s.text&&!state.firstTextAt)state.firstTextAt=Date.now();if(s.completed&&!state.completeAt)state.completeAt=Date.now();changed();}}
      catch{if(!state.disposed){state.failed=true;wake();}}
      finally{state.reader=null;try{reader.releaseLock();}catch{}}
    };
    const wrapper=function(input,init){
      // Start the original request immediately and return its unmodified response.
      const match=!observed&&!state.disposed&&!args.observeOnly?matches(input,init):Promise.resolve(false);
      return original.apply(this,arguments).then(response=>{
        // Clone before returning to the application, which can lock the original
        // body immediately. Never wait for decoding before returning its response.
        let copy;try{if(!observed&&!state.disposed&&response.headers.get('content-type')?.includes('text/event-stream'))copy=response.clone();}catch{}
        if(copy)void match.then(yes=>{if(yes&&!observed&&!state.disposed){observed=true;void consume(copy).catch(()=>{state.failed=true;wake();});}else void copy.body?.cancel().catch(()=>{});});return response;
      },error=>{state.failed=true;wake();throw error;});
    };
    if(!args.observeOnly)window.fetch=wrapper;
    state.dispose=()=>{if(state.disposed)return;state.disposed=true;observer.disconnect();clearTimeout(timer);if(window.fetch===wrapper)window.fetch=original;void state.reader?.cancel().catch(()=>{});wake();if(window[key]===state)delete window[key];};
    state.read=()=>({id:state.id,revision:state.revision,domRevision:state.domRevision,disposed:state.disposed,scopeChanged:document.cookie!==initialCookie,url:location.href,stream:state.stream,failed:state.failed,eof:state.eof,firstTextAt:state.firstTextAt,completeAt:state.completeAt,...(state.decoder?.state()||{})});
    state.acceptScope=()=>{initialCookie=document.cookie;};
    state.wait=async(revision,ms)=>{if(revision===state.revision&&!state.disposed)await new Promise(resolve=>{const end=()=>{clearTimeout(t);waiters.delete(end);resolve();},t=setTimeout(end,Math.min(2000,Math.max(0,ms)));waiters.add(end);});return state.read();};
    window[key]=state;return state.read();
  }
  if(action==='wait'){if(!state||state.id!==args.id)return null;return state.wait(args.revision,args.ms??2000);}
  throw Error('Unknown website event operation');
};
