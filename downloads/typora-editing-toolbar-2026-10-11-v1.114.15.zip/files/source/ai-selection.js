class EditingToolbarAISelection {
  constructor(ai) {
    this.ai=ai;this.temporary=new EditingToolbarAITemporary(ai);
    document.addEventListener('pointerdown',e=>{this.dragging=e.button===0;if(!this.bar?.contains(e.target))this.hide();},true);
    document.addEventListener('pointerup',e=>{this.dragging=false;if(!this.bar?.contains(e.target))this.queue();},true);
    document.addEventListener('selectionchange',()=>{if(!this.dragging)this.queue();});
    document.addEventListener('keydown',e=>{if(e.key==='Escape')this.hide();},true);
    document.addEventListener('scroll',()=>this.hide(),true);window.addEventListener('resize',()=>this.hide());window.addEventListener('blur',()=>this.hide());
  }
  queue() {if(this.frame)return;this.frame=requestAnimationFrame(()=>{this.frame=null;this.update();});}
  bodyItem() {
    if(File.isFileLoading?.()||File.editor?.sourceView?.inSourceMode)return null;
    const selection=getSelection(),range=selection?.rangeCount?selection.getRangeAt(0):null;
    if(!range||range.collapsed||!this.ai.toolbar._selectionInEditor(range))return null;
    const text=this.rangeText(range,selection.toString()).trim();if(!text)return null;if(text.length>100000)throw Error('选中文字超过 10 万字符，请缩小选区');
    const file=this.ai.file();return{text,file,source:'正文 · '+(file.startsWith('untitled:')?'未命名文档':reqnode('path').basename(file))};
  }
  rangeText(range,fallback) {
    const fragment=range.cloneContents(),selector='[data-note-math][data-tex],.md-math-block,[md-inline="inline_math"]';
    const element=n=>n?.nodeType===1?n:n?.parentElement,inside=element(range.startContainer)?.closest(selector);
    const mathText=math=>{const native=this.ai.toolbar.researchMaterials;const tex=math.dataset.tex??native?.mathText(math);if(!tex)return null;const display=math.dataset.noteMath==='display'||math.matches('.md-math-block');return display?'$$\n'+tex+'\n$$':'$'+tex+'$';};
    if(inside&&inside===element(range.endContainer)?.closest(selector))return mathText(inside)||fallback;
    let changed=false;for(const math of fragment.querySelectorAll(selector)){const text=mathText(math);if(text){math.replaceWith(document.createTextNode(text));changed=true;}}
    if(!changed)return fallback;
    for(const block of fragment.querySelectorAll('p,div,li,h1,h2,h3,h4,blockquote,pre,tr'))block.append(document.createTextNode('\n'));for(const br of fragment.querySelectorAll('br'))br.replaceWith(document.createTextNode('\n'));
    return fragment.textContent.replace(/\n{3,}/g,'\n\n').trim();
  }
  update() {
    if(this.dragging)return;const s=getSelection();if(!s?.rangeCount||s.isCollapsed)return this.hide();const range=s.getRangeAt(0),element=n=>n?.nodeType===1?n:n?.parentElement;
    const start=element(range.startContainer),end=element(range.endContainer),selector='.et-ai-answer,.et-ai-question,.et-ai-temp-question';const root=start?.closest(selector);
    if(!root||root!==end?.closest(selector)||start.closest('textarea,input')||root.closest('dialog:not([open])'))return this.hide();
    let text=s.toString().trim();const fragment=range.cloneContents();
    if(fragment.querySelector('[data-note-math][data-tex]')){for(const math of fragment.querySelectorAll('[data-note-math][data-tex]'))math.replaceWith(document.createTextNode((math.dataset.noteMath==='display'?'\\[':'\\(')+math.dataset.tex+(math.dataset.noteMath==='display'?'\\]':'\\)')));for(const block of fragment.querySelectorAll('p,div,li,h1,h2,h3,h4,blockquote,pre,tr'))block.append(document.createTextNode('\n'));for(const br of fragment.querySelectorAll('br'))br.replaceWith(document.createTextNode('\n'));text=fragment.textContent.trim();}
    if(!text||text.length>100000)return this.hide();
    const rects=[...range.getClientRects()].filter(r=>r.width&&r.height&&r.bottom>0&&r.top<innerHeight),rect=rects[0];if(!rect)return this.hide();
    const turn=this.ai.turns.find(t=>t.article?.contains(root))||this.temporary.turns.find(t=>t.article?.contains(root)),record=root.closest('.et-ai-conversation-manager')?this.ai.conversations.visible?.find(r=>r.id===this.ai.conversations.selected):null,file=turn?.file||record?.file||this.ai.file();
    this.item={text,file,source:(root.id==='write'?'正文':root.matches('.et-ai-question,.et-ai-temp-question')?'提问':'AI 回答')+' · '+(file.startsWith('untitled:')?'未命名文档':reqnode('path').basename(file))};
    if(!this.bar)this.mount();this.bar.showPopover();const b=this.bar.getBoundingClientRect();this.bar.style.left=Math.max(8,Math.min(rect.left,innerWidth-b.width-8))+'px';this.bar.style.top=Math.max(8,rect.top>b.height+10?rect.top-b.height-7:Math.min(rect.bottom+7,innerHeight-b.height-8))+'px';this.ai.toolbar.hide();
  }
  mount() {
    const a=this.ai,b=this.bar=a.node('div','et-ai-selection-toolbar');b.setAttribute('popover','manual');b.setAttribute('role','toolbar');b.setAttribute('aria-label','所选文字操作');
    for(const [label,action]of [['添加到对话',item=>{if(a.busy)throw Error('请等待当前回答完成');a.open();a.composerUI.draft.quotes.add(item);a.prompt.focus();}],['添加到笔记',item=>this.saveNote(item)],['在临时聊天提问',item=>this.temporary.open(item)]]){
      const button=a.node('button','',label);button.type='button';button.onclick=()=>{const item=this.item;if(!item)return;this.hide();getSelection()?.removeAllRanges();try{action(item);}catch(e){a.toolbar._showToolbarNotice(e.message);}};b.append(button);
    }
    b.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();});document.body.append(b);
  }
  hide() {if(this.frame){cancelAnimationFrame(this.frame);this.frame=null;}if(this.bar?.matches(':popover-open'))this.bar.hidePopover();}
  saveNote(item) {
    const a=this.ai;if(item.file!==a.file()||File.isFileLoading?.())throw Error('请回到选中文字时的文档后再添加笔记');
    const n=a.toolbar.documentNotes.appendMarkdown(ETAIClient.insertableMarkdown(item.text)+'\n\n> 来源：'+item.source.replace(/[\r\n]/g,' '));a.toolbar._showToolbarNotice('已追加到笔记「'+n.title+'」');
  }
}
