const {test}=require('node:test'),assert=require('node:assert/strict');
const {TerminalTranscript}=require('./terminal-transcript.cjs');
function fixture(){
 const jobs=new Map(),acks=[],writes=[];let serial=0,resets=0,screen='',alive=true;
 const term={buffer:{active:{baseY:10,viewportY:10}},reset(){resets++;screen='';},write(text,ack){writes.push(text);acks.push(()=>{screen+=text;ack();});},scrollLines(){}};
 const writer=new TerminalTranscript(term,{connected:()=>alive,schedule:fn=>{jobs.set(++serial,fn);return serial},cancel:id=>jobs.delete(id)});
 const frame=()=>{const list=[...jobs.values()];jobs.clear();for(const fn of list)fn();};
 const drain=()=>{for(let n=0;jobs.size||acks.length;n++){assert(n<100);frame();acks.shift()?.();}};
 return {writer,frame,drain,acks,writes,term,disconnect:()=>alive=false,get screen(){return screen},get resets(){return resets}};
}
test('streamed snapshots append once without resetting or queueing every update',async()=>{
 const f=fixture();f.writer.update('first\n');f.frame();
 for(let i=1;i<=200;i++)f.writer.update('first\n'+'next\n'.repeat(i));
 assert.equal(f.acks.length,1);assert.equal(f.writes.length,1);
 const done=f.writer.flush();f.drain();await done;
 assert.equal(f.screen,'first\r\n'+'next\r\n'.repeat(200));assert.equal(f.resets,0);assert.equal(f.writes.join(''),f.screen);
});
test('redaction replacement and truncated snapshots replace stale output, including in-flight writes',async()=>{
 const f=fixture();f.writer.update('token prefix [已隐藏]');f.frame();f.writer.update('new head\n… 输出已截断 …\nnew tail');f.drain();
 assert.equal(f.screen,'new head\r\n… 输出已截断 …\r\nnew tail');assert.equal(f.resets,1);await f.writer.flush();
});
test('large output yields between bounded writes and preserves Unicode, CRLF and final tail',async()=>{
 const f=fixture(),text='x'.repeat(16383)+'😀\n'+'中文'.repeat(20000)+'FINAL';f.writer.update(text);
 const done=f.writer.flush();f.frame();assert.equal(f.acks.length,1);assert(f.writes.every(s=>s.length<=16384));f.drain();await done;
 assert.equal(f.screen,text.replace(/\n/g,'\r\n'));assert(f.writes.length>=3);assert(f.writes.every(s=>!/[\uD800-\uDBFF\r]$/.test(s)));
});
test('closing or disconnecting a terminal releases pending final flush without further writes',async()=>{
 const f=fixture();f.writer.update('data');f.frame();const done=f.writer.flush();f.writer.dispose();await done;f.drain();f.writer.update('ignored');f.drain();assert.equal(f.writes.length,1);
 const g=fixture();g.writer.update('data');const stopped=g.writer.flush();g.disconnect();g.drain();await stopped;assert.equal(g.writes.length,0);
});
test('replacement restores a scrolled viewport only after the complete chunked snapshot',()=>{
 const f=fixture(),scroll=[];f.term.scrollLines=n=>scroll.push(n);f.writer.update('old');f.drain();f.term.buffer.active.viewportY=3;
 f.writer.update('new'.repeat(15000));f.frame();f.acks.shift()();assert.deepEqual(scroll,[]);f.drain();assert.deepEqual(scroll,[-7]);
});
