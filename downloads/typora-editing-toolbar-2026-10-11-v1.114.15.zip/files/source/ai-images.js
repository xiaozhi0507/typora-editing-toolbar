class EditingToolbarAIImages {
  constructor(ai) {this.ai=ai;this.scanner=new ETAIDocumentImages(reqnode);this.job=0;this.items=[];this.count=12;}
  static htmlImages(html) {
    const template=document.createElement('template');template.innerHTML=html;
    return [...template.content.querySelectorAll('img[src]')].filter(img=>!img.closest('pre,code,script,style,textarea,template')).map(img=>({src:img.getAttribute('src'),label:img.getAttribute('alt')||img.getAttribute('title')||''}));
  }
  cancel() {this.job++;this.loading=false;this.signature=null;for(const entry of [...this.items,...this.ai.attachments.selected])entry.reading=false;}
  reset() {this.cancel();this.items=[];this.count=12;this.root=null;}
  mount(root) {
    this.root=root;root.hidden=false;root.classList.add('et-ai-image-tools');root.replaceChildren();const a=this.ai;
    const head=a.node('div','et-ai-images-heading'),back=a.node('button','et-ai-images-back','‹ 资料范围'),refresh=a.node('button','et-ai-images-refresh');
    back.type=refresh.type='button';back.dataset.imageReadonly='true';back.onclick=()=>a.composerUI.showScopeChoices();refresh.title='重新扫描当前 Markdown';refresh.setAttribute('aria-label',refresh.title);refresh.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M20 7v5h-5M4 17v-5h5M5.5 8a7 7 0 0 1 11.8-2L20 9M4 15l2.7 3A7 7 0 0 0 18.5 16"/></svg>';refresh.onclick=()=>this.activate(true);
    head.append(back,refresh);root.append(head);
    const title=a.node('div','et-ai-images-title');title.append(a.node('strong','','文档图片'));this.counter=a.node('span');title.append(this.counter);root.append(title);
    const picker=a.node('button','et-ai-images-picker');picker.type='button';picker.innerHTML=EditingToolbarAIAttachments.icon('clip');picker.append(a.node('span','','从电脑选择图片'),a.node('small','','PNG / JPG / WebP'));picker.onclick=()=>a.attachments.chooseFiles(true);root.append(picker);
    this.message=a.node('div','et-ai-images-message');this.message.setAttribute('role','status');root.append(this.message);
    this.grid=a.node('div','et-ai-images-grid');this.grid.setAttribute('aria-label','当前文档引用的图片');root.append(this.grid);
    this.more=a.node('button','et-ai-images-more','显示更多图片');this.more.type='button';this.more.dataset.imageReadonly='true';this.more.onclick=()=>{this.count+=12;this.render();this.loadThumbnails(this.job,this.ai.context);(this.more.hidden?this.root.querySelector('.et-ai-images-back'):this.more).focus({preventScroll:true});};root.append(this.more);
    this.foot=a.node('div','et-ai-images-foot');root.append(this.foot);this.render();
  }
  async activate(force=false) {
    const a=this.ai;if(!this.root?.isConnected||a.scope.value!=='image')return;
    if(!a.followDocument()||!this.root?.isConnected)return;
    if(a.attachments.locked()){this.render();return;}
    let markdown;try{markdown=a.source();}catch(e){this.message.textContent=e.message;return;}const file=a.file();let fallback='';try{fallback=File.editor.localSettingBridge?.getSetting('typora-root-url')||'';}catch{}
    const signature=file+'\0'+fallback+'\0'+markdown;
    if(!force&&this.signature===signature&&this.scanContext===a.context){this.render();this.loadThumbnails(this.job,a.context);return;}
    this.signature=signature;this.scanContext=a.context;this.loading=true;this.scanError='';this.count=12;this.items=[];const job=++this.job,context=a.context,current=()=>job===this.job&&context===a.context&&file===a.file()&&!a.panel.hidden;
    this.render();
    try{
      const scan=await this.scanner.scan(markdown,file,fallback,EditingToolbarAIImages.htmlImages,(p,location)=>a.attachments.io.describe(p,location),current);
      if(!scan||!current())return;this.items=scan.items;this.references=scan.references;this.truncated=scan.truncated;
    }catch(e){if(current()){this.items=[];this.scanError=e.message;}}
    finally{if(current()){this.loading=false;this.render();this.loadThumbnails(job,context);}else if(job===this.job){this.loading=false;this.signature=null;}}
  }
  rows() {const rows=[...this.items],ids=new Set(rows.map(x=>x.id));for(const f of this.ai.attachments.selected)if(f.kind==='image'&&!ids.has(f.id)){f.external=true;rows.push(f);};return rows;}
  render() {
    if(!this.grid?.isConnected)return;const a=this.ai;this.grid.replaceChildren();this.cards=new Map();const rows=this.rows();
    if(!rows.length){const empty=a.node('div','et-ai-images-empty');empty.innerHTML=EditingToolbarAIAttachments.icon('image');empty.append(a.node('strong','',this.loading?'正在扫描文档图片…':this.scanError||'这篇文档还没有引用图片'));if(!this.loading&&!this.scanError)empty.append(a.node('span','','可以从电脑添加图片，或在文档中插入图片后重新扫描。'));this.grid.append(empty);}
    for(const entry of rows.slice(0,this.count)){
      const card=a.node('div','et-ai-image-card'),select=a.node('button','et-ai-image-select');select.type='button';select.setAttribute('aria-label','选择图片 '+entry.name);select.title=(entry.label?entry.label+'\n':'')+(entry.path||entry.src);select.onclick=()=>this.toggle(entry);
      const thumb=a.node('span','et-ai-image-thumb');if(entry.thumbnail){const img=a.node('img');img.src=entry.thumbnail;img.alt='';thumb.append(img);}else thumb.innerHTML=EditingToolbarAIAttachments.icon('image');
      const check=a.node('span','et-ai-image-check','✓');check.setAttribute('aria-hidden','true');thumb.append(check);select.append(thumb,a.node('span','et-ai-image-name',entry.name));
      const detail=a.node('small','et-ai-image-detail',entry.error||entry.info||(entry.external?'本机添加':'正在读取预览…'));select.append(detail);card.append(select);
      const preview=a.node('button','et-ai-image-preview','预览');preview.type='button';preview.dataset.imageReadonly='true';preview.setAttribute('aria-label','预览图片 '+entry.name);preview.onclick=()=>a.attachments.showPreview(entry,()=>a.composerUI.openScope());card.append(preview);
      this.grid.append(card);this.cards.set(entry.id,{entry,card,select,thumb,detail,preview});
    }
    this.more.hidden=rows.length<=this.count;this.sync();this.reposition();
  }
  async loadThumbnails(job,context) {
    const current=()=>job===this.job&&context===this.ai.context&&context?.file===this.ai.file()&&!this.ai.panel.hidden;
    const rows=this.rows().slice(0,this.count).filter(e=>!e.error&&!e.thumbnail&&!e.reading);for(const e of rows)e.reading=true;
    const work=async()=>{while(rows.length&&current()){const entry=rows.shift();try{
      const data=await this.ai.attachments.load(entry);if(!current())return;
      const img=new Image();img.src=data.data;await img.decode();if(!current())return;
      const scale=Math.min(1,240/img.naturalWidth,180/img.naturalHeight),canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);
      entry.thumbnail=canvas.toDataURL('image/png');entry.info=data.width+' × '+data.height+(entry.occurrences>1?' · 引用 '+entry.occurrences+' 次':'');
    }catch(e){if(current())entry.error=e.message;}finally{entry.reading=false;}
    if(current()){const ui=this.cards?.get(entry.id);if(ui){ui.entry=entry;ui.detail.textContent=entry.error||entry.info;if(entry.thumbnail){const img=this.ai.node('img');img.src=entry.thumbnail;img.alt='';ui.thumb.querySelector('svg')?.replaceWith(img);}this.sync();}}
    }};
    await Promise.all([work(),work()]);
    if(job===this.job&&!current()){this.signature=null;for(const entry of this.rows())entry.reading=false;}
  }
  toggle(entry) {
    const a=this.ai;if(a.attachments.locked()||entry.error||(!entry.thumbnail&&!entry.external)||a.context?.file!==a.file())return;
    const index=a.attachments.selected.findIndex(f=>f.id===entry.id);
    if(index>=0)a.attachments.selected.splice(index,1);
    else{
      if(a.attachments.selected.filter(f=>f.kind==='image').length+(a.context.image?1:0)>=4){this.message.textContent='最多选择 4 张图片，请先取消一张。';return;}
      if(a.attachments.selected.length>=ETAIAttachments.maxFiles){this.message.textContent='最多添加 20 个文件，请先移除一个附件。';return;}
      const {thumbnail,reading,info,...descriptor}=entry;a.attachments.selected.push(descriptor);
    }
    a.composerUI.markSourceChanged();this.message.textContent='';a.attachments.renderChips();a.composerUI.sync();a.conversations.schedule();
  }
  sync() {
    if(!this.root?.isConnected)return;const a=this.ai,locked=a.attachments.locked()||a.context?.file!==a.file(),selected=new Set(a.attachments.selected.filter(f=>f.kind==='image').map(f=>f.id));
    this.counter.textContent='已选 '+selected.size+' / 4';
    for(const {entry,card,select,preview} of this.cards?.values()||[]){select.setAttribute('aria-pressed',String(selected.has(entry.id)));select.disabled=locked||!!entry.error||(!entry.thumbnail&&!entry.external);card.dataset.unavailable=String(!!entry.error);preview.disabled=!!entry.error||(!entry.thumbnail&&!entry.external);}
    for(const b of this.root.querySelectorAll('.et-ai-images-picker,.et-ai-images-refresh'))b.disabled=locked;
    this.foot.textContent=this.loading?'扫描当前编辑内容，不修改文档':(this.truncated?'仅展示前 200 张 · ':'')+'每张最大 5 MB · 仅发送勾选的图片';
  }
  reposition() {if(this.ai.composerUI.menu===this.ai.composerUI.scopeMenu)this.ai.composerUI.positionMenu();}
}
