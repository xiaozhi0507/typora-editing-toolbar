import {NodeSelection} from 'prosemirror-state';
import {closeHistory} from 'prosemirror-history';
import {imageLayout,imageContours,imageRotation} from './annotation-image-layout.js';

export function imageNodeView(node,view,getPos,options){
 let current=node,drag=null,dead=false,selected=false,raf=0,parent=null,parentWidth=0,geometry=null;
 const contours=new Map();
 const dom=document.createElement('span');dom.className='note-image';dom.contentEditable='false';
 const img=document.createElement('img');img.alt=node.attrs.alt||'图片';img.draggable=false;
 const frame=document.createElement('span');frame.className='note-image-frame';dom.append(frame);
 const url=options.imageURL(node.attrs.src);
 if(url){img.src=url;dom.prepend(img);}else{dom.classList.add('error');dom.append(document.createTextNode('[图片未找到]'));}
 const select=document.createElement('button');select.type='button';select.className='note-image-select';select.textContent='▧';select.title='选中图片，调整环绕、大小或旋转';select.setAttribute('aria-label','选中叠放图片');dom.append(select);
 const rotate=document.createElement('button');rotate.type='button';rotate.className='note-image-rotate';rotate.hidden=true;
 rotate.setAttribute('aria-label','拖动旋转图片');rotate.title='拖动旋转图片；Shift 按 15° 吸附；双击恢复 0°';
 rotate.innerHTML='<svg viewBox="0 0 20 20" aria-hidden="true" fill="none"><path d="M15.6 7.3A6 6 0 1 0 16 12M16 3v5h-5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>';
 const line=document.createElementNS('http://www.w3.org/2000/svg','svg');line.classList.add('note-image-rotation-line');line.setAttribute('aria-hidden','true');line.style.display='none';
 const connector=document.createElementNS(line.namespaceURI,'line');line.append(connector);
 const angleLabel=document.createElement('output');angleLabel.className='note-image-angle';angleLabel.hidden=true;
 document.body.append(line,rotate,angleLabel);
 const angle=()=>imageRotation(drag?.kind==='rotate'?drag.value:current.attrs.rotation);
 const shape=rotation=>{const key=String(rotation);if(!contours.has(key)){if(contours.size>10)contours.clear();contours.set(key,imageContours(img,rotation));}return contours.get(key);};
 const choose=()=>{const pos=getPos();if(pos==null||dead)return;view.dispatch(view.state.tr.setSelection(NodeSelection.create(view.state.doc,pos)));view.focus();};
 const positionHandle=()=>{
  const r=dom.getBoundingClientRect(),dock=document.querySelector('.note-editor-dock')?.getBoundingClientRect().bottom||0;
  const show=drag?.kind!=='size'&&selected&&view.editable&&url&&img.naturalWidth&&dom.isConnected&&r.bottom>dock&&r.top<innerHeight;
  rotate.hidden=!show;line.style.display=show?'':'none';angleLabel.hidden=!show||drag?.kind!=='rotate';if(!show||!geometry)return;
  const a=angle()*Math.PI/180,x=r.left+r.width/2+Math.sin(a)*geometry.height/2,y=r.top+r.height/2-Math.cos(a)*geometry.height/2;
  const hx=Math.max(13,Math.min(innerWidth-13,x+Math.sin(a)*27)),hy=Math.max(dock+14,Math.min(innerHeight-14,y-Math.cos(a)*27));
  Object.assign(rotate.style,{left:hx-11+'px',top:hy-11+'px'});connector.setAttribute('x1',x);connector.setAttribute('y1',y);connector.setAttribute('x2',hx);connector.setAttribute('y2',hy);
  angleLabel.textContent=angle()+'°';Object.assign(angleLabel.style,{left:Math.max(3,Math.min(innerWidth-54,hx+15))+'px',top:Math.max(dock+2,Math.min(innerHeight-23,hy-10))+'px'});
 };
 const render=()=>{
  raf=0;if(dead)return;
  // Resize the flow box and its children together once per frame. Cached
  // geometry avoids a write/read layout cycle and keeps the top-left fixed.
  if(drag?.kind==='size'){
   const scale=drag.value/drag.startWidth;
   dom.style.width=drag.boxWidth*scale+'px';dom.style.height=drag.boxHeight*scale+'px';
   if(drag.floatRight)dom.style.marginRight=drag.marginRight+drag.boxWidth*(1-scale)+'px';
   for(const el of [img,frame]){el.style.width=drag.value+'px';el.style.height=drag.value*drag.ratio+'px';}
   dom.dataset.imageWidth=drag.value.toFixed(3);return;
  }
  // Keep the drag pivot still; reflow text and recompute contours on release.
  if(drag?.kind==='rotate'&&geometry){
   dom.dataset.rotation=angle();
   for(const el of [img,frame])el.style.transform='translate(-50%, -50%) rotate('+angle()+'deg)';
   positionHandle();return;
  }
  const {wrap,side}=imageLayout(current.attrs),rotation=angle(),a=rotation*Math.PI/180,ratio=img.naturalWidth?img.naturalHeight/img.naturalWidth:.6;
  const width=(drag?.kind==='size'?drag.value:current.attrs.width)||img.naturalWidth||180;
  const c=Math.abs(Math.cos(a)),s=Math.abs(Math.sin(a)),bw=Math.max(1,width*(c+s*ratio)),bh=Math.max(1,width*(s+c*ratio));
  dom.dataset.wrap=wrap;dom.dataset.side=side;dom.dataset.rotation=rotation;dom.dataset.readonly=String(!view.editable);
  dom.style.width=bw+'px';const scale=Math.min(1,(dom.getBoundingClientRect().width||bw)/bw),w=width*scale,h=w*ratio;
  dom.style.height=bh*scale+'px';dom.dataset.imageWidth=w.toFixed(3);geometry={width:w,height:h};
  for(const el of [img,frame])Object.assign(el.style,{width:w+'px',height:h+'px',transform:'translate(-50%, -50%) rotate('+rotation+'deg)'});
  dom.style.shapeOutside='';img.style.clipPath='';
  if((wrap==='tight'||wrap==='through')&&img.complete&&img.naturalWidth){const rotated=shape(rotation),source=shape(0),outline=wrap==='tight'?rotated?.tight:rotated?.[side];if(outline)dom.style.shapeOutside=outline;const clip=wrap==='tight'?source?.tight:source?.outline;if(clip)img.style.clipPath=clip.replace(' border-box','');}
  if(parent!==dom.parentElement){observer.disconnect();parent=dom.parentElement;parentWidth=parent?.clientWidth||0;if(parent)observer.observe(parent);}
  positionHandle();
 };
 const schedule=()=>{if(!dead&&!raf)raf=requestAnimationFrame(render);};
 const observer=new ResizeObserver(()=>{if(parent&&parent.clientWidth!==parentWidth){parentWidth=parent.clientWidth;schedule();}});
 const commit=attrs=>{const pos=getPos();if(dead||pos==null||!view.editable)return;const at=view.state.doc.nodeAt(pos);if(at?.type!==current.type||at.attrs.src!==current.attrs.src)return;
  if(Object.keys(attrs).every(k=>attrs[k]===at.attrs[k]))return;
  let tr=closeHistory(view.state.tr).setNodeMarkup(pos,null,{...at.attrs,...attrs});tr.setSelection(NodeSelection.create(tr.doc,pos));view.dispatch(tr);view.dispatch(closeHistory(view.state.tr));view.focus();
 };
 const finish=save=>{if(!drag)return;const d=drag;drag=null;dom.style.cssText=d.originalStyle;dom.classList.remove('resizing','rotating');rotate.classList.remove('dragging');cancelAnimationFrame(raf);raf=0;
  const anchor=document.documentElement.style;if(d.scrollAnchor.value)anchor.setProperty('overflow-anchor',d.scrollAnchor.value,d.scrollAnchor.priority);else anchor.removeProperty('overflow-anchor');
  if(d.handle.hasPointerCapture(d.pointerId))d.handle.releasePointerCapture(d.pointerId);
  if(save&&!dead){if(d.kind==='rotate')commit({rotation:imageRotation(d.value)});else commit({width:Math.max(32,Math.round(Number(dom.dataset.imageWidth)||d.value))});}render();
  d.scrollSpace?.remove();
 };
 const begin=(e,kind,handle,corner)=>{
  if(e.button!==0||!view.editable||dead||!url)return;e.preventDefault();e.stopPropagation();if(drag)finish(false);choose();render();
  const r=dom.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;
  const ratio=geometry.height/geometry.width,a=imageRotation(current.attrs.rotation)*Math.PI/180,sx=corner?.endsWith('e')?1:-1,sy=corner?.startsWith('s')?1:-1;
  const maxRule=getComputedStyle(dom).maxWidth;
  const maxBox=maxRule==='none'?12000:Math.max(r.width,parent?.clientWidth||r.width);
  const floatInset=['square','tight','through'].includes(imageLayout(current.attrs).wrap)?parseFloat(getComputedStyle(dom).fontSize)*7:0;
  drag={kind,handle,pointerId:e.pointerId,x:e.clientX,y:e.clientY,cx,cy,startPointer:Math.atan2(e.clientY-cy,e.clientX-cx),startRotation:imageRotation(current.attrs.rotation),startWidth:geometry.width,value:kind==='rotate'?imageRotation(current.attrs.rotation):geometry.width,maxWidth:Math.max(32,(maxBox-floatInset)*geometry.width/r.width),ux:sx*Math.cos(a)-sy*ratio*Math.sin(a),uy:sx*Math.sin(a)+sy*ratio*Math.cos(a)};
  const computed=getComputedStyle(dom),anchor=document.documentElement.style;
  Object.assign(drag,{originalStyle:dom.style.cssText,boxWidth:r.width,boxHeight:r.height,ratio,floatRight:computed.cssFloat==='right',marginRight:parseFloat(computed.marginRight)||0,scrollAnchor:{value:anchor.getPropertyValue('overflow-anchor'),priority:anchor.getPropertyPriority('overflow-anchor')}});
  if(kind==='size'){anchor.setProperty('overflow-anchor','none');dom.style.transition='none';if(computed.display==='block'&&computed.cssFloat==='none'){dom.style.marginLeft=computed.marginLeft;dom.style.marginRight=computed.marginRight;}}
  if(kind==='size'){const scroller=document.scrollingElement,spare=scroller.scrollHeight-scroller.clientHeight-scroller.scrollTop,needed=Math.max(0,r.height*(1-Math.min(1,32/geometry.width))-spare);if(needed>0){drag.scrollSpace=document.createElement('div');drag.scrollSpace.setAttribute('aria-hidden','true');drag.scrollSpace.style.cssText='height:'+Math.ceil(needed+2)+'px;pointer-events:none;';document.body.append(drag.scrollSpace);}}
  dom.classList.add(kind==='rotate'?'rotating':'resizing');if(kind==='rotate')rotate.classList.add('dragging');handle.setPointerCapture(e.pointerId);positionHandle();
  if(kind==='size'){rotate.hidden=true;line.style.display='none';angleLabel.hidden=true;}
 };
 const move=e=>{if(!drag||e.pointerId!==drag.pointerId)return;e.preventDefault();
  if(drag.kind==='rotate'){let value=drag.startRotation+(Math.atan2(e.clientY-drag.cy,e.clientX-drag.cx)-drag.startPointer)*180/Math.PI;if(e.shiftKey)value=Math.round(value/15)*15;drag.value=imageRotation(value);}
  else{const delta=((e.clientX-drag.x)*drag.ux+(e.clientY-drag.y)*drag.uy)/(drag.ux*drag.ux+drag.uy*drag.uy);drag.value=Math.max(32,Math.min(drag.maxWidth,drag.startWidth+delta));}schedule();
 };
 const wire=handle=>{handle.addEventListener('pointermove',move);handle.addEventListener('pointerup',e=>{if(drag){move(e);if(raf){cancelAnimationFrame(raf);render();}finish(true);}});handle.addEventListener('pointercancel',()=>finish(false));handle.addEventListener('lostpointercapture',()=>finish(false));};
 img.addEventListener('load',()=>{contours.clear();schedule();});
 img.addEventListener('mousedown',e=>{e.preventDefault();choose();});
 select.addEventListener('mousedown',e=>e.preventDefault());select.addEventListener('click',e=>{e.preventDefault();choose();});
 for(const corner of ['nw','ne','sw','se']){const handle=document.createElement('button');handle.type='button';handle.className='note-image-handle '+corner;handle.dataset.corner=corner;handle.setAttribute('aria-label','拖动调整图片大小');handle.tabIndex=-1;frame.append(handle);handle.addEventListener('pointerdown',e=>begin(e,'size',handle,corner));wire(handle);}
 rotate.addEventListener('mousedown',e=>e.preventDefault());rotate.addEventListener('pointerdown',e=>begin(e,'rotate',rotate));wire(rotate);
 rotate.addEventListener('dblclick',e=>{e.preventDefault();finish(false);commit({rotation:0});});
 rotate.addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight','Home'].includes(e.key)||!view.editable)return;e.preventDefault();e.stopPropagation();choose();commit({rotation:e.key==='Home'?0:imageRotation(current.attrs.rotation+(e.key==='ArrowLeft'?-1:1)*(e.shiftKey?15:1))});rotate.focus({preventScroll:true});});
 const cancel=()=>finish(false),keydown=e=>{if(drag&&e.key==='Escape'){e.preventDefault();e.stopPropagation();finish(false);}};
 window.addEventListener('scroll',positionHandle);window.addEventListener('resize',schedule);window.addEventListener('blur',cancel);document.addEventListener('keydown',keydown,true);
 schedule();
 return {dom,update(next){if(next.type!==current.type||next.attrs.src!==current.attrs.src)return false;if(drag&&next!==current)finish(false);current=next;img.alt=next.attrs.alt||'图片';render();return true;},selectNode(){selected=true;dom.classList.add('ProseMirror-selectednode');schedule();},deselectNode(){selected=false;dom.classList.remove('ProseMirror-selectednode');positionHandle();},stopEvent:e=>e.target.closest?.('.note-image-handle,.note-image-select')||e.type==='mousedown',ignoreMutation:()=>true,destroy(){dead=true;finish(false);cancelAnimationFrame(raf);observer.disconnect();rotate.remove();line.remove();angleLabel.remove();window.removeEventListener('scroll',positionHandle);window.removeEventListener('resize',schedule);window.removeEventListener('blur',cancel);document.removeEventListener('keydown',keydown,true);}};
}
