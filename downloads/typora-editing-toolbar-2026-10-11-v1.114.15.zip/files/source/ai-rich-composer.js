import {Schema,DOMSerializer} from 'prosemirror-model';
import {EditorState,TextSelection} from 'prosemirror-state';
import {EditorView} from 'prosemirror-view';
import {schema as baseSchema,MarkdownParser,defaultMarkdownParser,defaultMarkdownSerializer} from 'prosemirror-markdown';
import {toggleMark,setBlockType,baseKeymap} from 'prosemirror-commands';
import {wrapInList,liftListItem} from 'prosemirror-schema-list';
import {history,undo,redo} from 'prosemirror-history';
import {keymap} from 'prosemirror-keymap';
import MarkdownIt from 'markdown-it';

export function safeLink(value){
  const text=String(value||'').trim();if(!text||/[\s<>]/.test(text))return null;
  const href=/^[a-z][a-z0-9+.-]*:/i.test(text)?text:'https://'+text;
  try{const u=new URL(href);return ['https:','http:','mailto:'].includes(u.protocol)&&!u.username&&!u.password?u.href:null;}catch{return null;}
}
const linkSpec={...baseSchema.spec.marks.get('link'),toDOM:m=>['a',{href:safeLink(m.attrs.href)||'',title:m.attrs.href,rel:'noopener noreferrer'},0]};
const schema=new Schema({nodes:baseSchema.spec.nodes.remove('image').update('paragraph',{...baseSchema.spec.nodes.get('paragraph'),content:'inline*'}).update('heading',{...baseSchema.spec.nodes.get('heading'),content:'inline*'}),marks:baseSchema.spec.marks.update('link',linkSpec)});
const tokens={...defaultMarkdownParser.tokens};delete tokens.image;
const md=new MarkdownIt('commonmark',{html:false});md.disable('image');
const parser=new MarkdownParser(schema,md,tokens);
const styles=[['paragraph','正文'],['heading1','标题 1'],['heading2','标题 2'],['heading3','标题 3'],['ordered_list','编号列表'],['bullet_list','项目符号列表']];
const icons={link:'M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-2 2M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l2-2',open:'M15 3h6v6m0-6-12 12M11 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-6',edit:'m15 4 5 5M4 20l4-1L21 6l-5-5L3 14z',check:'m5 12 4 4L19 6'};
export function renderMessage(node,text,openLink){node.replaceChildren(DOMSerializer.fromSchema(schema).serializeFragment(parser.parse(text).content));node.classList.add('et-ai-rich-question');node.addEventListener('click',e=>{const a=e.target.closest('a');if(a){e.preventDefault();const url=safeLink(a.getAttribute('href'));if(url)openLink(url);}});}
export function mount(ai,textarea){return new RichComposer(ai,textarea);}
class RichComposer {
  constructor(ai,textarea){
    this.ai=ai;this.locked=false;this.disabled=false;this.kind=null;this.raw='';this.cached='';this.changed=false;
    const host=document.createElement('div');textarea.replaceWith(host);
    this.view=new EditorView(host,{state:EditorState.create({schema,doc:parser.parse(''),plugins:[history(),keymap({'Mod-b':toggleMark(schema.marks.strong),'Mod-i':toggleMark(schema.marks.em),'Mod-z':undo,'Mod-y':redo,'Mod-Shift-z':redo}),keymap(baseKeymap)]}),
      attributes:{class:'et-ai-prompt et-ai-rich-prompt',role:'textbox','aria-label':'输入问题','aria-multiline':'true','data-placeholder':'问点什么…'},
      editable:()=>!this.locked&&!this.disabled,
      dispatchTransaction:tr=>{this.view.updateState(this.view.state.apply(tr));if(tr.docChanged){this.changed=true;this.cached=defaultMarkdownSerializer.serialize(this.view.state.doc);this.close();this.input.dispatchEvent(new Event('input',{bubbles:true}));}this.schedule();},
      handleClick:(view,pos,event)=>{const a=event.target.closest('a');if(!a)return false;event.preventDefault();this.linkAt(pos);return true;},
      handlePaste:(view,event)=>{if(event.defaultPrevented)return true;return false;}
    });
    this.input=this.view.dom;host.replaceWith(this.input);ai.prompt=this.input;this.input.richEditor=this;
    Object.defineProperties(this.input,{
      value:{get:()=>this.changed?this.cached:this.raw,set:value=>this.set(String(value||''))},
      readOnly:{get:()=>this.locked,set:value=>{this.locked=!!value;this.view.setProps({editable:()=>!this.locked&&!this.disabled});if(this.locked)this.close();}},
      disabled:{get:()=>this.disabled,set:value=>{this.disabled=!!value;this.view.setProps({editable:()=>!this.locked&&!this.disabled});if(this.disabled)this.close();}},
      placeholder:{get:()=>this.input.dataset.placeholder,set:value=>{const text=String(value||'');if(this.view.props.attributes['data-placeholder']!==text)this.view.setProps({attributes:{...this.view.props.attributes,'data-placeholder':text}});}},
      selectionStart:{get:()=>this.offset(this.view.state.selection.from)},selectionEnd:{get:()=>this.offset(this.view.state.selection.to)}
    });
    this.input.setSelectionRange=(from,to)=>{const max=this.view.state.doc.content.size;this.view.dispatch(this.view.state.tr.setSelection(TextSelection.near(this.view.state.doc.resolve(from>=this.input.value.length?max:Math.min(max,from+1)))));if(to!==from&&from===0)this.view.dispatch(this.view.state.tr.setSelection(TextSelection.create(this.view.state.doc,1,Math.max(1,max-1))));};
    this.input.setRangeText=text=>this.insertText(text);
    this.popup=ai.node('div','et-ai-format-popup');this.popup.setAttribute('popover','manual');this.popup.setAttribute('role','toolbar');this.popup.setAttribute('aria-label','输入文字格式');ai.panel.append(this.popup);
    this.popup.addEventListener('pointerdown',e=>{if(e.target.closest('button'))e.preventDefault();});
    this.popup.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();this.close();this.view.focus();}if(['ArrowDown','ArrowUp','ArrowLeft','ArrowRight'].includes(e.key)&&e.target.tagName==='BUTTON'){e.preventDefault();const buttons=[...this.popup.querySelectorAll('button')],i=buttons.indexOf(e.target),step=['ArrowDown','ArrowRight'].includes(e.key)?1:-1;buttons[(i+step+buttons.length)%buttons.length].focus();}});
    this.input.addEventListener('click',e=>{const a=e.target.closest('a');if(a){e.preventDefault();e.stopPropagation();this.linkAt(this.view.posAtDOM(a,0));}});
    this.input.addEventListener('mouseup',()=>this.schedule());this.input.addEventListener('keyup',()=>this.schedule());
    this.input.addEventListener('keydown',e=>{if(e.shiftKey&&['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'].includes(e.key))this.dismissed=false;if(e.key==='Escape'&&this.kind){e.preventDefault();e.stopImmediatePropagation();this.dismissed=true;this.close();}if(e.key==='Tab'&&this.kind==='format'){e.preventDefault();this.popup.querySelector('button')?.focus();}if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'&&!this.view.state.selection.empty){e.preventDefault();this.saved=this.textSelection();this.link=null;this.form('url');}},true);
    document.addEventListener('selectionchange',()=>this.schedule());document.addEventListener('pointerdown',e=>{if(!this.popup.contains(e.target)&&!this.input.contains(e.target)){this.close();}else if(this.input.contains(e.target))this.dismissed=false;});
    this.input.addEventListener('blur',()=>setTimeout(()=>{if(!this.popup.contains(document.activeElement))this.close();},0));
    this.input.addEventListener('scroll',()=>this.position());window.addEventListener('resize',()=>this.position());window.addEventListener('blur',()=>this.close());
  }
  set(text){this.close();this.raw=text;this.cached=text;this.changed=false;this.view.updateState(EditorState.create({schema,doc:parser.parse(text),plugins:this.view.state.plugins}));}
  offset(pos){return this.view.state.doc.textBetween(0,pos,'\n').length;}
  insertText(text){this.view.dispatch(this.view.state.tr.insertText(text));}
  newline(){this.view.dispatch(this.view.state.tr.replaceSelectionWith(schema.nodes.hard_break.create()).scrollIntoView());}
  schedule(){if(this.frame)return;this.frame=requestAnimationFrame(()=>{this.frame=null;this.sync();});}
  textSelection(){const s=this.view.state.selection;if(s.$from.depth&&s.$to.depth)return s;let first,last;this.view.state.doc.descendants((n,pos)=>{if(n.isTextblock){first??=pos+1;last=pos+n.nodeSize-1;}});return first!=null?TextSelection.create(this.view.state.doc,first,last):s;}
  activeStyle(){const p=this.textSelection().$from;for(let d=p.depth;d>0;d--){const n=p.node(d);if(['ordered_list','bullet_list'].includes(n.type.name))return n.type.name;}return p.parent.type.name==='heading'?'heading'+p.parent.attrs.level:'paragraph';}
  sync(){
    if(this.kind&&this.kind!=='format')return;
    const sel=this.textSelection();if(this.locked||this.disabled||this.dismissed||sel.empty||!this.view.hasFocus()||this.view.composing||this.ai.panel.hidden){if(!this.popup.contains(document.activeElement))this.close();return;}
    this.saved=sel;this.kind='format';this.popup.dataset.kind='format';this.popup.replaceChildren();
    this.button('插入链接','link',()=>{this.link=null;this.form('url');});
    for(const [label,mark,text] of [['加粗','strong','B'],['斜体','em','I']]){const b=this.button(label,null,()=>{this.restore();toggleMark(schema.marks[mark])(this.view.state,this.view.dispatch,this.view);this.view.focus();},text);b.classList.add(mark);b.setAttribute('aria-pressed',String(this.view.state.doc.rangeHasMark(sel.from,sel.to,schema.marks[mark])));}
    this.button('文本样式',null,()=>this.styleMenu(),styles.find(s=>s[0]===this.activeStyle())?.[1]+' ⌄');this.show();
  }
  button(label,icon,action,text){const b=this.ai.node('button');b.type='button';b.title=label;b.setAttribute('aria-label',label);if(icon)b.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="'+icons[icon]+'"/></svg>';if(text)b.append(this.ai.node('span','',text));b.onclick=action;this.popup.append(b);return b;}
  restore(){if(this.saved)this.view.dispatch(this.view.state.tr.setSelection(this.saved));}
  styleMenu(){if(this.kind==='styles'){this.close();this.view.focus();this.sync();return;}const bar=this.ai.node('div','et-ai-format-inline');bar.append(...this.popup.children);const options=this.ai.node('div','et-ai-format-style-options');this.kind='styles';this.popup.dataset.kind='styles';this.popup.setAttribute('role','menu');this.popup.replaceChildren();for(const [value,label] of styles){const b=this.button(label,null,()=>this.applyStyle(value),label);b.setAttribute('role','menuitemradio');b.setAttribute('aria-checked',String(value===this.activeStyle()));b.append(this.ai.node('span','et-ai-format-check',value===this.activeStyle()?'✓':''));options.append(b);}this.popup.append(options,bar);this.show();}
  applyStyle(style){
    this.restore();const v=this.view,inList=['ordered_list','bullet_list'].includes(this.activeStyle()),targetList=['ordered_list','bullet_list'].includes(style);
    if(inList&&targetList){let tr=v.state.tr;v.state.doc.nodesBetween(v.state.selection.from,v.state.selection.to,(n,pos)=>{if(['ordered_list','bullet_list'].includes(n.type.name))tr=tr.setNodeMarkup(pos,schema.nodes[style]);});v.dispatch(tr);}
    else{if(inList)liftListItem(schema.nodes.list_item)(v.state,v.dispatch);if(targetList){setBlockType(schema.nodes.paragraph)(v.state,v.dispatch);wrapInList(schema.nodes[style])(v.state,v.dispatch);}else setBlockType(style==='paragraph'?schema.nodes.paragraph:schema.nodes.heading,style==='paragraph'?null:{level:Number(style.slice(-1))})(v.state,v.dispatch);}
    this.close();v.focus();this.schedule();
  }
  linkAt(pos){
    if(this.locked||this.disabled)return false;
    const v=this.view,spans=[];
    v.state.doc.descendants((node,start)=>{if(node.isText)spans.push({from:start,to:start+node.nodeSize,href:node.marks.find(m=>m.type===schema.marks.link)?.attrs.href});});
    const i=spans.findIndex(s=>s.href&&pos>=s.from&&pos<s.to);if(i<0)return false;
    const found={...spans[i]};
    // A single link can contain several differently formatted adjacent text nodes.
    for(let j=i-1;j>=0&&spans[j].href===found.href&&spans[j].to===found.from;j--)found.from=spans[j].from;
    for(let j=i+1;j<spans.length&&spans[j].href===found.href&&spans[j].from===found.to;j++)found.to=spans[j].to;
    this.link=found;this.saved=TextSelection.create(v.state.doc,found.from,found.to);this.kind='link';this.popup.dataset.kind='link';this.popup.replaceChildren();
    this.button('打开链接','open',()=>{const href=safeLink(found.href);if(href)void this.ai.openComposerLink(href);},'打开链接');this.button('编辑文本','edit',()=>this.form('text'),'编辑文本');this.button('编辑链接','link',()=>this.form('url'),'编辑链接');this.show();return true;
  }
  form(mode){
    this.kind=mode;this.popup.dataset.kind='form';this.popup.setAttribute('role','dialog');this.popup.replaceChildren();
    const input=this.ai.node('input');input.type='text';input.setAttribute('aria-label',mode==='text'?'链接文本':'链接地址');input.placeholder=mode==='text'?'链接文本':'输入或粘贴链接';input.value=mode==='text'?this.view.state.doc.textBetween(this.saved.from,this.saved.to):this.link?.href||'';this.popup.append(input);
    const save=()=>{const value=input.value.trim(),href=mode==='url'?safeLink(value):safeLink(this.link?.href);if(!value||!href){input.setAttribute('aria-invalid','true');input.title=mode==='url'?'请输入有效的 http、https 或 mailto 链接':'请输入链接文本';input.focus();return;}this.restore();const v=this.view;let tr=v.state.tr;if(mode==='text'){const marks=v.state.doc.resolve(this.saved.from).nodeAfter?.marks||[];tr=tr.replaceWith(this.saved.from,this.saved.to,schema.text(value,[...marks.filter(m=>m.type!==schema.marks.link),schema.marks.link.create({href})]));}else tr=tr.addMark(this.saved.from,this.saved.to,schema.marks.link.create({href}));v.dispatch(tr);this.close();v.focus();};
    this.button('确认','check',save);input.oninput=()=>input.removeAttribute('aria-invalid');input.onkeydown=e=>{if(e.key==='Enter'&&!e.isComposing){e.preventDefault();e.stopPropagation();save();}};this.show();input.focus();input.select();
  }
  show(){if(!this.popup.matches(':popover-open'))this.popup.showPopover();this.position();}
  position(){if(!this.kind)return;let r;try{const sel=this.saved||this.view.state.selection,a=this.view.coordsAtPos(sel.from),b=this.view.coordsAtPos(sel.to);r={left:Math.min(a.left,b.left),right:Math.max(a.right,b.right),top:Math.min(a.top,b.top),bottom:Math.max(a.bottom,b.bottom)};}catch{r=this.input.getBoundingClientRect();}
    const pr=this.ai.panel.getBoundingClientRect(),width=Math.min(this.kind==='styles'?210:this.kind==='url'||this.kind==='text'?380:this.kind==='link'?340:220,innerWidth-20,pr.width-20);this.popup.style.maxWidth=width+'px';this.popup.style.width=['url','text','styles'].includes(this.kind)?width+'px':'max-content';const p=this.popup.getBoundingClientRect();this.popup.style.left=Math.max(10,pr.left+10,Math.min((r.left+r.right-p.width)/2,pr.right-p.width-10,innerWidth-p.width-10))+'px';this.popup.style.top=Math.max(10,r.top>=p.height+14?r.top-p.height-8:Math.min(r.bottom+8,innerHeight-p.height-10))+'px';
  }
  close(){if(this.popup?.matches(':popover-open'))this.popup.hidePopover();this.kind=null;this.popup?.setAttribute('role','toolbar');}
}
