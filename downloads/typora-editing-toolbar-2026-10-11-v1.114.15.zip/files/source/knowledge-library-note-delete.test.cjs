'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),{JSDOM}=require('jsdom');
const source=fs.readFileSync(__dirname+'/knowledge-library-ui.js','utf8');
function fixture(t){
  const dom=new JSDOM('<main><button data-child-note="a" data-note-id="same" data-note-kind="笔记" data-note-file="fa">A note</button><div data-menu hidden></div><form data-form><button data-do="confirm"></button></form></main>');
  t.after(()=>dom.window.close());
  const document=dom.window.document,items=[{id:'a',files:[{id:'fa',path:'a.md'}]},{id:'b',files:[{id:'fb',path:'b.md'}]}],calls=[],events=[];
  const env={document,state:{selected:'b'},byID:id=>items.find(i=>i.id===id),noteCache:new Map(items.map(i=>[i.id,{notes:[{id:'same',kind:'笔记',fileId:i.files[0].id,title:i.id+' note'}]}])),noteRequests:new Map(),clone:x=>JSON.parse(JSON.stringify(x)),libraryGeneration:1,noteMenu:null,noteMenuFocus:null,noteRemoval:null,noteDeleting:false,attachmentMenu:null,detailSignature:'old',modal:null,previousFocus:null,q:s=>document.querySelector(s),qa:s=>[...document.querySelectorAll(s)],icon:()=>'',updateIcons(){},positionCollectionMenu(){},closeCollectionMenu(){env.noteMenu=null;env.noteMenuFocus=null;},closeModal(){env.modal=null;},renderDetail(){events.push('detail');},loadVisibleNotes(){events.push('notes');},refreshExpandedNotes(){events.push('children');},notify(){},bridge:{deleteNote:async(...args)=>calls.push(args)},showCompactConfirmation(title,question){env.confirmation={title,question};document.querySelector('[data-form]').innerHTML='<footer><button data-do="confirm"></button><button data-do="cancel"></button></footer>';}};
  const api=vm.runInNewContext(source.slice(source.indexOf('    function noteTarget('),source.indexOf('function renderDetail('))+';({noteTarget,showNoteMenu,showNoteRemoval,commitNoteRemoval})',env);
  return {env,api,items,calls,events,card:document.querySelector('[data-child-note]')};
}
test('child context menu resolves owner and file even with another selected item and duplicate note IDs',t=>{
  const {api,env,card}=fixture(t);assert.equal(api.showNoteMenu(card,10,20),true);assert.equal(env.noteMenu.owner,'a');assert.equal(env.noteMenu.file.id,'fa');assert.equal(env.state.selected,'b');
  api.showNoteRemoval();assert.equal(env.noteRemoval.owner,'a');assert.match(env.confirmation.question,/a note/);assert.equal(env.previousFocus,card);assert.equal(env.noteMenu,null);
});
test('stale child identity never falls back to the selected item or a matching ID in another file',t=>{
  const {api,card,env}=fixture(t);card.dataset.noteFile='fb';assert.equal(api.showNoteMenu(card,0,0),false);assert.equal(env.noteMenu,null);
  card.dataset.noteFile='fa';card.dataset.noteId='missing';assert.equal(api.showNoteMenu(card,0,0),false);
});
test('detail notes still resolve by selected item; annotations and recycled items have no delete action',t=>{
  const {api,items,env,card}=fixture(t);assert.equal(api.noteTarget(0).owner,'b');items[0].deleted=true;assert.equal(api.showNoteMenu(card,0,0),false);
  items[0].deleted=false;env.noteCache.get('a').notes[0].kind='注释';card.dataset.noteKind='注释';assert.equal(api.showNoteMenu(card,0,0),false);
});
test('confirm deletes captured note without switching owner and refreshes every shared-document view',async t=>{
  const {api,env,card,calls,events}=fixture(t);api.showNoteMenu(card,0,0);api.showNoteRemoval();await api.commitNoteRemoval();
  assert.equal(calls.length,1);assert.equal(calls[0][0].path,'a.md');assert.equal(calls[0][1],'笔记');assert.equal(calls[0][2],'same');assert.equal(env.state.selected,'b');assert.equal(env.noteCache.size,0);assert.deepEqual(events,['detail','notes','children']);assert.equal(env.noteDeleting,false);
});
test('library switches and attachment replacement block a stale confirmation before deletion',async t=>{
  const {api,env,card,calls,items}=fixture(t);api.showNoteMenu(card,0,0);api.showNoteRemoval();env.libraryGeneration++;
  await assert.rejects(api.commitNoteRemoval(),/已变化/);env.libraryGeneration--;items[0].files[0].path='replacement.md';await assert.rejects(api.commitNoteRemoval(),/已变化/);assert.equal(calls.length,0);
});
test('duplicate confirmations cannot delete twice and persistence errors retain the dialog',async t=>{
  const {api,env,card,events}=fixture(t);api.showNoteMenu(card,0,0);api.showNoteRemoval();let reject,count=0;env.bridge.deleteNote=()=>{count++;return new Promise((_,r)=>reject=r);};
  const pending=api.commitNoteRemoval();await api.commitNoteRemoval();assert.equal(count,1);reject(Error('write failed'));await assert.rejects(pending,/write failed/);assert.equal(env.modal,'remove-note');assert.equal(env.noteRemoval.owner,'a');assert.equal(env.noteDeleting,false);assert.ok(events.includes('children'));
});
test('deleting the active note closes its docked editor only after persistence succeeds',async t=>{
  const {api,env,card,events}=fixture(t);env.leaveNotePane=()=>events.push('close editor');env.bridge.deleteNote=async()=>({closePane:true});api.showNoteMenu(card,0,0);api.showNoteRemoval();await api.commitNoteRemoval();assert.equal(events[0],'close editor');
});
test('host closes only the deleted note editor, including the same file linked by another item',async()=>{
  const Host=vm.runInNewContext(fs.readFileSync(__dirname+'/knowledge-library-host.js','utf8')+';EditingToolbarKnowledgeLibrary',{}),host=Object.create(Host.prototype),calls=[];
  const manager={ctx:{key:'C:\\Library\\A.md',selected:'active'},deleteStoredNote:(...args)=>calls.push(args)};
  host.store={resolveFile:file=>file.path};host.toolbar={documentNotes:manager};host.notePane={manager};
  assert.equal((await host.deleteNote({path:'c:\\library\\a.md'},'笔记','active')).closePane,true);
  assert.equal((await host.deleteNote({path:'C:\\Library\\A.md'},'笔记','other')).closePane,false);
  assert.equal((await host.deleteNote({path:'C:\\Library\\B.md'},'笔记','active')).closePane,false);
  manager.deleteStoredNote=()=>{throw Error('write failed');};await assert.rejects(host.deleteNote({path:'C:\\Library\\A.md'},'笔记','active'),/write failed/);
  assert.equal(calls.length,3);
});
