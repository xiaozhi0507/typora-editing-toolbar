const fs=require('node:fs'),path=require('node:path'),esbuild=require('esbuild');
module.exports=()=>{
 const dest=path.resolve(__dirname,'../plugin');
 const worker=esbuild.buildSync({entryPoints:[require.resolve('monaco-editor/editor/editor.worker.js')],bundle:true,format:'iife',minify:true,write:false}).outputFiles[0].text;
 esbuild.buildSync({entryPoints:[path.join(__dirname,'code-editor-runtime.js')],bundle:true,format:'iife',minify:true,target:'chrome112',outfile:path.join(dest,'editing-toolbar.code.js'),loader:{'.ttf':'dataurl'},define:{ET_CODE_WORKER:JSON.stringify(worker)},legalComments:'eof'});
 fs.writeFileSync(path.join(dest,'editing-toolbar.code.LICENSE.txt'),fs.readFileSync(path.join(__dirname,'node_modules/monaco-editor/LICENSE'),'utf8')+'\n\n'+fs.readFileSync(path.join(__dirname,'node_modules/monaco-editor/ThirdPartyNotices.txt'),'utf8'));
};
