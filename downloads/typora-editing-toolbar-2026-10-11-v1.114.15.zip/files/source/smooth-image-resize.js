// Preview size and document flow together; commit through native undo only on release.
{
 const proto=EditingToolbarPlugin.prototype,start=proto._startImageResize,cancel=proto._cancelImageResize,position=proto._positionImageResizeHandle,commit=proto._commitImageResize;
 proto._startImageResize=function(e){
  if(e.button!==0)return;const originalStyle=this.activeImage?.getAttribute('style');start.call(this,e);const s=this.imageResizeState;if(!s)return;s.originalStyle=originalStyle;this.hide();
  const r=s.overlay.getBoundingClientRect();s.left=r.left;s.top=r.top;s.startY=e.clientY;s.frame=0;
  s.block=s.image.closest('[cid]');s.cid=s.block?.getAttribute('cid');s.index=[...(s.block?.querySelectorAll('img,video')||[])].indexOf(s.image);
  const block=s.block?.getBoundingClientRect();s.maxWidth=Math.max(s.startWidth,(block?.right||innerWidth)-r.left);s.zoom=parseFloat(getComputedStyle(s.image).zoom)||1;
  const scroller=s.image.closest('content');s.scrollTop=scroller?.scrollTop||0;s.scroller=scroller;
  if(scroller){s.scrollAnchor={value:scroller.style.getPropertyValue('overflow-anchor'),priority:scroller.style.getPropertyPriority('overflow-anchor')};scroller.style.setProperty('overflow-anchor','none');}
  // Near the document end, keep enough temporary scroll range for shrinking.
  // Otherwise the browser clamps scrollTop and holds the caption in place.
  const spare=scroller?scroller.scrollHeight-scroller.clientHeight-scroller.scrollTop:Infinity;
  const needed=Math.max(0,s.startHeight*(1-Math.min(1,48/s.startWidth))-spare);
  if(needed>0){s.scrollSpace=document.createElement('div');s.scrollSpace.setAttribute('aria-hidden','true');s.scrollSpace.className='et-image-scroll-space';s.scrollSpace.style.cssText='height:'+Math.ceil(needed+2)+'px;pointer-events:none;';scroller.append(s.scrollSpace);}
  s.image.style.setProperty('transition','none','important');
 };
 proto._paintImageResize=function(){
  const s=this.imageResizeState;if(!s)return;s.frame=0;
  const scale=s.previewWidth/s.startWidth;s.overlay.style.transform='scale('+scale+')';
  // The original stays invisible but participates in normal flow. Updating its
  // box in the same frame moves captions and all subsequent blocks continuously.
  s.image.style.setProperty('width',s.previewWidth/s.zoom+'px','important');
  s.image.style.setProperty('height',s.previewHeight/s.zoom+'px','important');
  this._positionImageResizeHandle();
 };
 proto._restoreImageResizeFlow=function(s){
  if(s.originalStyle==null)s.image.removeAttribute('style');else s.image.setAttribute('style',s.originalStyle);
  if(s.scroller&&s.scrollAnchor){const a=s.scrollAnchor;if(a.value)s.scroller.style.setProperty('overflow-anchor',a.value,a.priority);else s.scroller.style.removeProperty('overflow-anchor');}
 };
 proto._positionImageResizeHandle=function(){
  const s=this.imageResizeState;if(!s||s.left==null)return position.call(this);
  if(!this.imageResizeHandle)return;this.imageResizeHandle.hidden=false;
  this.imageResizeHandle.style.left=(s.left+s.previewWidth-7)+'px';this.imageResizeHandle.style.top=(s.top+s.previewHeight-7)+'px';
 };
 proto._updateImageResize=function(e){
  const s=this.imageResizeState;if(!s?.image?.isConnected||e.buttons===0){this._cancelImageResize();return;}e.preventDefault();
  const ratio=s.startHeight/s.startWidth,dx=e.clientX-s.startX,dy=e.clientY-s.startY;
  const delta=(dx+dy*ratio)/(1+ratio*ratio);
  s.previewWidth=Math.min(s.maxWidth,Math.max(48,s.startWidth+delta));s.previewHeight=s.previewWidth*ratio;
  if(!s.frame)s.frame=requestAnimationFrame(()=>this._paintImageResize());
 };
 proto._commitImageResize=function(image,width,naturalWidth){
  if(!(image instanceof HTMLImageElement)||!this._resizeCommit)return commit.call(this,image,width,naturalWidth);
  const native=window.File?.editor?.imgEdit;if(!native?.addStyle)return false;
  try{native.addStyle(image,'width',Math.round(width/this._resizeCommit.zoom*100)/100+'px');return true;}catch(error){console.warn('[EditingToolbar] Image width save failed:',error);return false;}
 };
 proto._finishImageResize=function(){
  const s=this.imageResizeState;if(!s)return;cancelAnimationFrame(s.frame);this._paintImageResize();if(Math.abs(s.previewWidth-s.startWidth)<.5)return this._cancelImageResize();
  this.imageResizeState=null;document.body.classList.remove('et-image-resizing');this._restoreImageResizeFlow(s);this._resizeCommit=s;
  try{
   const committed=this._commitImageResize(s.image,s.previewWidth,s.naturalWidth);
   if(!committed&&s.image.isConnected){Object.assign(s.image.style,{width:Math.round(s.previewWidth)+'px',height:'auto',maxWidth:'none'});}
   // Native image edits replace the wrapper. Resolve within this exact block,
   // so repeated uses of the same image never select/realign the first copy.
   const block=s.block?.isConnected?s.block:document.querySelector('#write [cid="'+CSS.escape(s.cid||'')+'"]');
   const target=s.image.isConnected?s.image:block?.querySelectorAll('img,video')[s.index];
   if(target){this._restoreImageAlignment(target,s.alignmentState);this._showImageResizeHandle(target);}else this._hideImageResizeHandle();
  }finally{this._resizeCommit=null;this._teardownImageResizeOverlay(s);s.scrollSpace?.remove();this.hide();}
 };
 proto._cancelImageResize=function(){const s=this.imageResizeState;if(s){cancelAnimationFrame(s.frame);this._restoreImageResizeFlow(s);}cancel.call(this);s?.scrollSpace?.remove();};
 // Cancel a preview if the window loses capture/focus, rather than leaving it stuck.
 window.addEventListener('blur',()=>window.__editingToolbar?._cancelImageResize());
 document.addEventListener('keydown',e=>{const t=window.__editingToolbar;if(e.key==='Escape'&&t?.imageResizeState){e.preventDefault();e.stopPropagation();t._cancelImageResize();}},true);
}
