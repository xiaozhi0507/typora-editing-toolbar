class EditingToolbarAIChatGPT {
  constructor(ai){this.ai=ai;this.pending=new Map();this.accounts=[];this.models=[];this.catalogs=new Map();this.catalogJobs=new Map();this.catalogEpochs=new Map();this.accountRevision=0;this.pickerRefreshAt=0;window.addEventListener('unload',()=>this.shutdown());}
  async start(){
    if(this.child)return;if(this.startJob)return this.startJob;
    const generation=this.startGeneration||0,job=this.launch(generation);this.startJob=job;
    try{await job;}finally{if(this.startJob===job)this.startJob=null;}
  }
  async findNode(env){
    const path=reqnode('path'),cp=reqnode('child_process'),fs=reqnode('fs');
    const run=(file,args)=>new Promise(resolve=>{try{cp.execFile(file,args,{env,windowsHide:true,timeout:3000,maxBuffer:16384,encoding:'utf8'},(error,stdout)=>resolve(error?'':String(stdout).trim()));}catch{resolve('');}});
    const found=await run(path.join(env.SystemRoot||'C:\\Windows','System32','where.exe'),['node.exe']);
    // Standard install locations also work before Typora inherits the updated PATH.
    const paths=[this.nodePath,...found.split(/\r?\n/),...['ProgramW6432','ProgramFiles','ProgramFiles(x86)'].map(k=>env[k]&&path.join(env[k],'nodejs','node.exe')),env.LOCALAPPDATA&&path.join(env.LOCALAPPDATA,'Programs','nodejs','node.exe')];
    for(const file of [...new Set(paths.filter(p=>p&&path.isAbsolute(p)&&fs.existsSync(p)))].slice(0,12)){
      const version=await run(file,['-p','process.versions.node']);if(/^\d+\.\d+\.\d+(?:[-+].*)?$/.test(version)&&Number(version.split('.')[0])>=18)return file;
    }
    throw Object.assign(Error('未检测到 Node.js 18+。请安装 LTS 版后重新检测。'),{code:'NODE_REQUIRED'});
  }
  async launch(generation){
    if(this.child)return;const path=reqnode('path'),proc=reqnode('process'),file=this.ai.moduleRoot?path.join(this.ai.moduleRoot,'chatgpt.cjs'):path.join(proc.resourcesPath,'editing-toolbar.chatgpt.cjs');
    if(!reqnode('fs').existsSync(file))throw Error('ChatGPT 登录组件未安装，请重新安装新版阅读助手');
    const cp=reqnode('child_process'),env={...proc.env};delete env.ELECTRON_RUN_AS_NODE;delete env.NODE_OPTIONS;delete env.NODE_PATH;
    try{this.nodePath=await this.findNode(env);this.nodeMissing=false;}catch(e){if(e.code==='NODE_REQUIRED')this.nodeMissing=true;throw e;}
    if(generation!==(this.startGeneration||0))throw Object.assign(Error('已取消'),{name:'AbortError'});
    const child=this.child=cp.spawn(this.nodePath,[file,path.join(File.option.userDataPath,'editing-toolbar-chatgpt')],{env,windowsHide:true,stdio:['pipe','pipe','pipe']});
    let buffer='';child.stdout.setEncoding('utf8');child.stderr.resume();child.stdin.on('error',()=>{});
    child.stdout.on('data',chunk=>{buffer+=chunk;if(buffer.length>12*1024*1024){this.shutdown();return;}let at;while((at=buffer.indexOf('\n'))>=0){const line=buffer.slice(0,at);buffer=buffer.slice(at+1);let m;try{m=JSON.parse(line);}catch{continue;}const p=this.pending.get(m.id);if(!p)continue;
      if(m.event==='authorize'){
        this.authorize(m.data,m.id).catch(error=>{if(this.pending.get(m.id)!==p)return;this.pending.delete(m.id);p.cleanup();p.abort();p.reject(error);});continue;
      }
      if(m.event==='execution'){p.onEvent?.(m.data);continue;}if(m.event==='text'){p.onText?.(m.data);continue;}if(m.event==='reasoning'){p.onReasoning?.(m.data.text,m.data.kind);continue;}
      this.pending.delete(m.id);p.cleanup();if(m.error)p.reject(Object.assign(Error(m.error.message),{name:m.error.name||'Error',code:m.error.code,status:m.error.status}));else p.resolve(m.result);
    }});
    const ended=()=>{if(this.child!==child)return;this.child=null;for(const [id,p]of this.pending){p.cleanup();p.reject(Error('ChatGPT 本机连接已关闭，请重新操作'));this.pending.delete(id);}};
    child.on('exit',ended);child.on('error',ended);
  }
  async call(method,data={},options={}){
    if(options.signal?.aborted)return Promise.reject(Object.assign(Error('已取消'),{name:'AbortError'}));
    try{await this.start();}catch(e){if(options.signal?.aborted)throw Object.assign(Error('已取消'),{name:'AbortError'});throw e;}if(options.signal?.aborted)throw Object.assign(Error('已取消'),{name:'AbortError'});
    return new Promise((resolve,reject)=>{const id=reqnode('crypto').randomUUID();const abort=()=>{this.child?.stdin.write(JSON.stringify({id,method:'cancel'})+'\n');};const cleanup=()=>{options.signal?.removeEventListener('abort',abort);if(this.authorization?.id===id){this.authorization=null;this.render();}};this.pending.set(id,{resolve,reject,abort,cleanup,onText:options.onText,onReasoning:options.onReasoning,onEvent:options.onEvent});options.signal?.addEventListener('abort',abort,{once:true});this.child.stdin.write(JSON.stringify({id,method,...data})+'\n');});
  }
  async authorize(value,id){
    let url;try{url=new URL(value);if(url.origin!=='https://auth.openai.com'||url.pathname!=='/api/accounts/authorize'||url.username||url.password||url.searchParams.has('id_token_hint'))throw Error();}catch{throw Error('登录地址无效，请重新连接。');}
    this.authorization={id,url:url.toString()};this.render();
    try{await reqnode('electron').shell.openExternal(url.toString());if(this.authorization?.id===id)this.status('请在浏览器完成登录。');}
    catch{if(this.authorization?.id===id)this.status('无法打开浏览器，请点击“打开登录页”重试。',true);}
  }
  async downloadNode(){
    this.download.disabled=true;
    try{await reqnode('electron').shell.openExternal('https://nodejs.org/en/download');this.status('已打开官网。安装 LTS 版后点击“重新检测”。');}
    catch{this.status('无法打开浏览器，请复制下方地址访问。',true);this.downloadAddress.hidden=false;this.downloadAddress.focus();this.downloadAddress.select();}
    finally{this.download.disabled=false;}
  }
  usagePage(){return this.usageBrowser ||= new EditingToolbarAIUsageBrowser(this.ai);}
  readWebUsage(profile,visible=false){return visible?this.usagePage().open(profile):this.usagePage().refresh(profile);}
  shutdown(){this.startGeneration=(this.startGeneration||0)+1;this.usageBrowser?.close();this.child?.stdin.end();this.child?.kill();this.child=null;for(const p of this.pending.values()){p.cleanup();p.reject(Error('ChatGPT 连接已关闭'));}this.pending.clear();}
  request(profile,messages,options){return this.call('request',{profile:{model:profile.model,chatgptAccount:profile.chatgptAccount,reasoningEffort:ETAIClient.effortValue(profile),codeFiles:ETAIClient.attachedFiles(profile),documentEdit:profile.documentEdit===true,webSearch:profile.webSearch===true,shellEnabled:profile.shellEnabled===true,skillsEnabled:profile.skillsEnabled===true,pluginsEnabled:profile.pluginsEnabled,skillScripts:profile.skillScripts===true,project:profile.project?{trusted:profile.project.trusted}:null},messages},options);}
  mount(){
    const a=this.ai,b=a.node('button','','ChatGPT');b.type='button';b.dataset.ai='chatgpt';b.setAttribute('role','tab');b.setAttribute('aria-selected','false');b.tabIndex=-1;a.nav.children[0].after(b);
    const panel=this.panel=a.node('section','et-ai-chatgpt-settings');panel.hidden=true;
    const content=a.node('div','et-ai-chatgpt-content'),heading=a.node('div','et-ai-chatgpt-heading');
    heading.append(a.node('strong','','连接 ChatGPT'));
    this.connection=a.node('span','et-ai-chatgpt-connection');this.connection.setAttribute('role','status');heading.append(this.connection);
    const button=(text,fn,cls='')=>{const b=a.node('button',cls,text);b.type='button';b.onclick=fn;return b;};
    const accountCard=a.node('div','et-ai-chatgpt-card'),label=a.node('label','et-ai-chatgpt-field','账号');
    this.account=a.node('select');this.account.setAttribute('aria-label','ChatGPT 账号');label.append(this.account);
    this.account.onchange=()=>{this.models=[];this.modelAccount=null;this.status('');this.render();if(this.selected()?.enabled)this.loadModels();};
    const actions=a.node('div','et-ai-chatgpt-actions');
    this.login=button('Continue with ChatGPT',()=>this.signIn(),'et-ai-chatgpt-login');
    this.cancel=button('取消登录',()=>this.controller?.abort());this.cancel.hidden=true;
    this.browserLogin=button('打开登录页',()=>this.authorization&&this.authorize(this.authorization.url,this.authorization.id),'et-ai-chatgpt-quiet');this.browserLogin.hidden=true;
    this.logout=button('退出账号',()=>this.disconnect(),'et-ai-chatgpt-quiet');
    this.manage=button('管理额度',()=>reqnode('electron').shell.openExternal('https://chatgpt.com/settings/usage'),'et-ai-chatgpt-quiet');
    actions.append(this.login,this.browserLogin,this.cancel,this.manage,this.logout);accountCard.append(label,actions);
    const modelCard=a.node('div','et-ai-chatgpt-card'),modelHead=a.node('div','et-ai-chatgpt-model-head');
    const modelLabel=a.node('label','','可用模型');modelLabel.htmlFor='et-ai-chatgpt-model';
    this.refresh=button('',()=>this.loadModels(),'et-ai-chatgpt-refresh');this.refresh.setAttribute('aria-label','刷新模型');
    this.refresh.innerHTML='<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M16 7a6.5 6.5 0 1 0 .3 5M16 3v4h-4"/></svg>';
    this.refreshText=a.node('span','','刷新');this.refresh.append(this.refreshText);modelHead.append(modelLabel,this.refresh);
    this.model=a.node('select');this.model.id='et-ai-chatgpt-model';this.model.setAttribute('aria-label','ChatGPT 可用模型');this.model.onchange=()=>{this.status('');this.render();};
    const modelActions=a.node('div','et-ai-chatgpt-model-actions');
    this.use=button('使用此模型',()=>this.useModel(),'et-ai-primary et-ai-chatgpt-use');modelActions.append(this.use);
    modelCard.append(modelHead,this.model,modelActions);
    this.message=a.node('p','et-ai-chatgpt-message');this.message.hidden=true;this.message.setAttribute('role','status');this.message.setAttribute('aria-live','polite');
    this.nodeHelp=a.node('div','et-ai-chatgpt-node-help');this.nodeHelp.hidden=true;
    const nodeActions=a.node('div','et-ai-chatgpt-actions');this.download=button('下载 Node.js',()=>this.downloadNode(),'et-ai-chatgpt-login');this.recheck=button('重新检测',()=>this.open());nodeActions.append(this.download,this.recheck);
    this.downloadAddress=a.node('input');this.downloadAddress.type='text';this.downloadAddress.readOnly=true;this.downloadAddress.value='https://nodejs.org/en/download';this.downloadAddress.setAttribute('aria-label','Node.js 官方下载地址');this.downloadAddress.hidden=true;
    this.nodeHelp.append(nodeActions,a.node('p','','仍未检测到？请完全退出并重新打开 Typora。'),this.downloadAddress);
    content.append(heading,accountCard,this.message,this.nodeHelp,modelCard);panel.append(content);a.preferencesStatus.before(panel);this.render();
  }
  selected(){return this.accounts.find(a=>a.id===this.account.value);}
  status(text,error=false){this.message.textContent=text;this.message.hidden=!text;this.message.dataset.error=String(error);}
  render(){
    if(!this.panel)return;const selected=this.account.value,active=this.ai.profile();this.account.replaceChildren();
    for(const a of this.accounts){
      const name=a.email||a.name||'ChatGPT 账号',duplicate=this.accounts.filter(x=>(x.email||x.name||'ChatGPT 账号')===name).length>1;
      this.account.append(new Option(name+(duplicate?' · '+a.id.slice(-8):'')+(!a.connected?' · 已退出':!a.enabled?' · 待授权':''),a.id));
    }
    this.account.append(new Option(this.accounts.length?'＋ 连接其他账号或工作区':'连接 ChatGPT 账号','new'));
    this.account.value=this.accounts.some(a=>a.id===selected)?selected:'new';const a=this.selected();
    this.connection.textContent=this.signingIn?'正在授权':a?.enabled?'已连接':a?.connected?'待授权':a?'已退出':'未连接';
    this.connection.dataset.connected=String(!!a?.enabled);this.connection.dataset.pending=String(!!this.signingIn);
    this.login.textContent=a?'重新授权':'Continue with ChatGPT';this.login.dataset.connected=String(!!a?.enabled);
    this.login.hidden=!!this.signingIn;this.login.disabled=!!this.busy;this.account.disabled=!!this.busy;this.cancel.hidden=!this.signingIn;
    this.browserLogin.hidden=!this.signingIn||!this.authorization;this.nodeHelp.hidden=!this.nodeMissing;this.recheck.disabled=!!this.busy;
    this.logout.hidden=!a?.connected||!!this.signingIn;this.logout.disabled=!!this.busy;
    this.manage.hidden=!a?.connected||!!this.signingIn;
    this.refresh.disabled=!!this.busy||!a?.enabled;this.refresh.dataset.loading=String(!!this.loadingModels);this.refreshText.textContent=this.loadingModels?'刷新中':'刷新';
    const model=this.model.value;this.model.replaceChildren();
    this.models=this.models.filter(m=>!/^gpt[- ]?5\.5(?:$|[- ])/i.test(m.id));
    for(const m of this.models)this.model.append(new Option(m.name,m.id));
    if(this.models.some(m=>m.id===model))this.model.value=model;
    else if(active?.chatgptAccount===a?.id&&this.models.some(m=>m.id===active.model))this.model.value=active.model;
    if(!this.models.length)this.model.append(new Option(this.loadingModels?'正在获取模型…':a?.enabled?'暂无可用模型':'连接账号后选择模型',''));
    this.model.disabled=!!this.busy||!this.models.length;
    const applied=!!a?.enabled&&active?.authType==='chatgpt'&&active.chatgptAccount===a.id&&active.model===this.model.value;
    this.use.textContent=applied?'✓ 正在使用':'使用此模型';this.use.dataset.applied=String(applied);
    this.use.disabled=!!this.busy||!this.models.length||!a?.enabled||applied;
  }
  modelProfile(account,model,previous={}){
    const p={...previous,id:previous.id||'chatgpt-'+account.id+'-'+model.id,name:'ChatGPT · '+(account.email||account.name||account.id.slice(-8)),model:model.id,modelLabel:model.name||model.id,authType:'chatgpt',chatgptAccount:account.id,protocol:'openai-responses',url:'https://api.openai.com/v1/responses',fullUrl:true,chatgptAvailable:true};
    delete p.reasoningEfforts;delete p.defaultReasoningEffort;delete p.contextWindow;if(model.contextWindow)p.contextWindow=model.contextWindow;
    if(Array.isArray(model.reasoningEfforts)){p.reasoningEfforts=[...model.reasoningEfforts];p.defaultReasoningEffort=model.defaultReasoningEffort;}
    p.reasoningEffort=ETAIClient.effortValue(p);return p;
  }
  syncAccountModels(account,models){
    const a=this.ai,old=a.config.profiles,belongs=p=>p.authType==='chatgpt'&&p.chatgptAccount===account.id;
    const previous=old.filter(belongs),seen=new Set(),rows=[];
    for(const m of models.filter(m=>!/^gpt[- ]?5\.5(?:$|[- ])/i.test(m?.id||''))){
      if(!m||typeof m.id!=='string'||!m.id.trim()||seen.has(m.id))continue;seen.add(m.id);
      const p=previous.find(p=>p.model===m.id&&p.id===a.config.active)||previous.find(p=>p.model===m.id);
      rows.push(this.modelProfile(account,m,p));
    }
    // Keep preferences for temporarily unavailable models, but never offer them as selectable.
    rows.push(...previous.filter(p=>!seen.has(p.model)).map(p=>({...p,chatgptAvailable:false})));
    const first=old.findIndex(belongs),others=old.filter(p=>!belongs(p)),index=first<0?others.length:old.slice(0,first).filter(p=>!belongs(p)).length;
    others.splice(index,0,...rows);a.config.profiles=others;a.persist();a.settingsInitialized=false;this.refreshPickers();
  }
  refreshPickers(){
    const a=this.ai,main=a.composerUI,temp=a.selectionUI?.temporary;
    main?.syncModelButton();temp?.sync();
    for(const [menu,profile,refresh]of [[main?.modelMenu,a.profile(),()=>main.refreshModels()],[temp?.modelMenu,temp?.profile(),()=>temp.renderModels()]]){
      if(!menu)continue;
      const opened=menu.matches(':popover-open');
      if(opened&&menu.dataset.pickerView==='effort'&&menu.dataset.profileSignature===EditingToolbarAIEffort.signature(profile))continue;
      const focused=menu.contains(document.activeElement)?{profile:document.activeElement.dataset.profile,model:document.activeElement.dataset.model,label:document.activeElement.getAttribute('aria-label')}:null;
      refresh();
      if(opened&&focused){const target=EditingToolbarAIEffort.controls(menu).find(e=>focused.profile?e.dataset.profile===focused.profile&&e.dataset.model===focused.model:focused.label&&e.getAttribute('aria-label')===focused.label);if(target)target.focus({preventScroll:true});else EditingToolbarAIEffort.focus(menu);}
    }
  }
  invalidateCatalog(id){
    this.accountRevision++;this.pickerRefreshAt=0;this.catalogEpochs.set(id,(this.catalogEpochs.get(id)||0)+1);this.catalogs.delete(id);this.catalogJobs.delete(id);
  }
  accountModels(account,force=false){
    const cached=this.catalogs.get(account.id);if(!force&&cached&&Date.now()-cached.at<300000){const models=cached.models.filter(m=>!/^gpt[- ]?5\.5(?:$|[- ])/i.test(m?.id||''));this.syncAccountModels(account,models);return Promise.resolve(models);}
    if(this.catalogJobs.has(account.id))return this.catalogJobs.get(account.id);
    const epoch=this.catalogEpochs.get(account.id)||0;
    const job=this.call('models',{account:account.id}).then(models=>{
      if((this.catalogEpochs.get(account.id)||0)!==epoch||!this.accounts.some(a=>a.id===account.id&&a.enabled))return null;
      if(!Array.isArray(models))throw Error('账号未返回有效的模型列表');
      models=models.filter(m=>!/^gpt[- ]?5\.5(?:$|[- ])/i.test(m?.id||''));
      this.catalogs.set(account.id,{models,at:Date.now()});this.syncAccountModels(account,models);return models;
    }).finally(()=>{if(this.catalogJobs.get(account.id)===job)this.catalogJobs.delete(account.id);});
    this.catalogJobs.set(account.id,job);return job;
  }
  schedulePickerModels(){
    // Let the cached picker paint before any catalog work or synchronous IPC.
    clearTimeout(this.pickerRefreshTimer);cancelAnimationFrame(this.pickerRefreshFrame);
    this.pickerRefreshFrame=requestAnimationFrame(()=>{this.pickerRefreshFrame=null;this.pickerRefreshTimer=setTimeout(()=>{this.pickerRefreshTimer=null;this.ensurePickerModels();},0);});
  }
  ensurePickerModels(){
    if(this.pickerJob)return this.pickerJob;
    if(this.busy||this.signingIn||Date.now()-(this.pickerRefreshAt||0)<(this.pickerError?15000:300000))return Promise.resolve();
    if(!this.ai.config.profiles.some(p=>p.authType==='chatgpt')&&!this.accounts.some(a=>a.enabled))return Promise.resolve();
    const revision=this.accountRevision;this.pickerLoading=true;this.pickerError='';this.refreshPickers();
    const job=(async()=>{
      try{
        const accounts=await this.call('list');if(revision!==this.accountRevision)return;this.accounts=accounts;
        for(const p of this.ai.config.profiles.filter(p=>p.authType==='chatgpt'))if(!accounts.some(a=>a.id===p.chatgptAccount&&a.enabled))p.chatgptAvailable=false;
        this.ai.persist();
        const results=await Promise.allSettled(accounts.filter(a=>a.enabled).map(a=>this.accountModels(a)));
        if(revision!==this.accountRevision)return;
        const failed=results.find(r=>r.status==='rejected');if(failed)throw failed.reason;
      }catch(e){if(revision===this.accountRevision)this.pickerError=e.message;}
      finally{
        if(revision===this.accountRevision)this.pickerRefreshAt=Date.now();
        this.pickerLoading=false;this.refreshPickers();
      }
    })().finally(()=>{if(this.pickerJob===job)this.pickerJob=null;});this.pickerJob=job;return job;
  }
  async fetchModels(){
    const account=this.selected();if(!account?.enabled)return;this.loadingModels=true;this.render();
    try{
      const models=await this.accountModels(account,true);if(!models||this.account.value!==account.id)return;
      this.models=models;this.modelAccount=account.id;this.pickerError='';this.status(models.length?'':'当前账号没有返回可选模型。');
    }catch(e){if(this.account.value===account.id){this.models=[];this.status(e.message,true);}}
    finally{this.loadingModels=false;this.render();}
  }
  async open(){
    if(this.busy)return;this.busy=true;this.status('正在检测登录环境…');this.render();
    try{
      const active=this.ai.profile()?.chatgptAccount;this.accounts=await this.call('list');this.status('');this.render();
      if(active&&this.accounts.some(a=>a.id===active))this.account.value=active;else if(this.accounts.length&&this.account.value==='new')this.account.value=this.accounts[0].id;
      if(this.modelAccount!==this.account.value||!this.selected()?.enabled)this.models=[];
      this.render();if(this.selected()?.enabled&&!this.models.length)await this.fetchModels();
    }catch(e){this.status(e.message,true);}finally{this.busy=false;this.render();}
  }
  async signIn(){
    if(this.busy)return;this.busy=true;this.signingIn=true;this.controller=new AbortController();this.status('正在启动登录…');this.render();
    try{
      if(this.selected()?.id)this.invalidateCatalog(this.selected().id);else this.accountRevision++;const a=await this.call('signIn',{account:this.selected()?.id},{signal:this.controller.signal});this.accounts=await this.call('list');this.render();this.account.value=a.id;this.models=[];this.modelAccount=null;
      this.status(a.enabled?'':'账号已登录，但未授权套餐使用；可重新授权。');if(a.enabled)await this.fetchModels();
    }
    catch(e){this.status(e.name==='AbortError'?'':e.message,e.name!=='AbortError');if(e.code!=='NODE_REQUIRED'&&e.name!=='AbortError')try{const before=new Set(this.accounts.map(a=>a.id));this.accounts=await this.call('list');this.render();const pending=this.accounts.find(a=>!before.has(a.id));if(pending)this.account.value=pending.id;}catch{}}
    finally{this.busy=false;this.signingIn=false;this.controller=null;this.render();}
  }
  async loadModels(){if(this.busy||!this.selected()?.enabled)return;this.busy=true;this.status('');this.render();try{await this.fetchModels();}finally{this.busy=false;this.render();}}
  useModel(){
    const account=this.selected(),model=this.models.find(m=>m.id===this.model.value);if(this.busy||!account?.enabled||!model)return;
    const a=this.ai,previous=a.config.profiles.find(p=>p.authType==='chatgpt'&&p.chatgptAccount===account.id&&p.model===model.id),p=this.modelProfile(account,model,previous);
    if(previous)a.config.profiles=a.config.profiles.map(row=>row.id===previous.id?p:row);else a.config.profiles.push(p);
    a.config.active=p.id;a.rememberModel(p);a.persist();a.syncProfiles();a.settingsInitialized=false;this.status('');this.render();
  }

  async disconnect(){
    if(this.busy||!this.selected())return;this.busy=true;this.status('');this.render();
    try{
      const id=this.account.value,temp=this.ai.selectionUI?.temporary;this.invalidateCatalog(id);if(temp?.profile()?.chatgptAccount===id)temp.controller?.abort();
      const result=await this.call('disconnect',{account:id});this.accounts=await this.call('list');this.models=[];this.modelAccount=null;
      const a=this.ai;a.config.profiles=a.config.profiles.filter(p=>p.chatgptAccount!==id);if(!a.config.profiles.some(p=>p.id===a.config.active))a.config.active=a.config.profiles[0]?.id||'';
      a.persist();a.syncProfiles();temp?.sync();this.status(result.revoked?'':'本机凭据已清除；未确认远端撤销，请到 ChatGPT 设置中断开应用。',!result.revoked);
    }catch(e){this.status(e.message,true);}finally{this.busy=false;this.render();}
  }
}
