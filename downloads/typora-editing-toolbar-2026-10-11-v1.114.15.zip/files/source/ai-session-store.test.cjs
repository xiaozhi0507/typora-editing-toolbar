const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const Store=require('./ai-session-store.cjs'),Legacy=require('./ai-conversation-store.cjs');
function fixture(t){
  const base=path.join(os.homedir(),'Downloads','codex-temp');fs.mkdirSync(base,{recursive:true});
  const directory=fs.mkdtempSync(path.join(base,'ai-session-test-'));
  t.after(()=>{const target=path.resolve(directory);if(!target.startsWith(path.resolve(base)+path.sep))throw Error('Unsafe test cleanup');fs.rmSync(target,{recursive:true,force:true});});
  const legacy=new Legacy(require,path.join(directory,'legacy')),store=new Store(require,path.join(directory,'sessions'),{legacy});return {directory,legacy,store};
}
const input=s=>({id:s.id(),created:new Date(2026,8,30,23,59,59).toISOString(),title:'阅读会话',file:'C:/books/第一章.md',turns:[{id:s.id(),question:'解释公式 $x^2$\n及图像',answer:'你好',status:'running',model:'test-model'}],draft:''});
const snapshot={context:{markdown:'原始文档'},reference:{text:'原始资料',images:[{name:'figure.png',data:'data:image/png;base64,dGVzdA=='}]}};
const events=file=>fs.readFileSync(file,'utf8').trim().split('\n').map(JSON.parse);

test('web attachments are written once during streaming and restore across restart, edits and deletion',t=>{
 const {store:s}=fixture(t),data=input(s),payload={text:'Question',files:[{name:'image.png',type:'image/png',base64:'QUJD'.repeat(250000)}]};data.turns[0].webChat={input:payload,submitted:false};
 let r=s.write(data,null,snapshot);for(let i=0;i<12;i++)r=s.write({...r,turns:[{...r.turns[0],answer:r.turns[0].answer+' chunk',webChat:{...r.turns[0].webChat,submitted:true,url:'https://chatgpt.com/c/test'}}]},r.revision);
 const file=s.locate(r.id);assert.ok(fs.statSync(file).size<1100000);let reopened=new Store(require,s.directory),loaded=reopened.read(r.id);assert.deepEqual(loaded.turns[0].webChat.input,payload);assert.equal(loaded.turns[0].webChat.submitted,true);
 loaded.turns[0].webChat.input.files[0].base64='changed';r=reopened.write(loaded,loaded.revision);assert.equal(new Store(require,s.directory).read(r.id).turns[0].webChat.input.files[0].base64,'changed');
 const pending={...r,revision:s.id(),turns:[{...r.turns[0],webChat:{...r.turns[0].webChat,input:payload}}]};fs.appendFileSync(file,reopened.encode(pending,r,null,false).split('\n').filter(line=>line&&!line.includes('session_commit')).join('\n')+'\n');assert.equal(new Store(require,s.directory).read(r.id).turns[0].webChat.input.files[0].base64,'changed');
 reopened.remove(r);assert.ok(!fs.readFileSync(file,'utf8').includes('QUJD'));assert.equal(new Store(require,s.directory).read(r.id).turns.length,0);
});

test('thinking persists as separate incremental events, survives reload and never pollutes answers',t=>{
  const {store:s}=fixture(t),data=input(s);data.turns[0].reasoning='先检查';data.turns[0].reasoningKind='summary';
  let r=s.write(data,null,snapshot);r=s.write({...r,turns:[{...r.turns[0],reasoning:'先检查条件，然后验证'}]},r.revision);
  const file=s.locate(r.id),lines=events(file);assert.equal(lines.find(e=>e.payload.type==='reasoning_delta').payload.text,'条件，然后验证');
  assert.ok(lines.filter(e=>e.type==='session_commit').every(e=>e.payload.turns.every(x=>!Object.hasOwn(x,'reasoning'))));
  r=s.write({...r,turns:[{...r.turns[0],status:'done',answer:'独立正文'}]},r.revision);
  assert.deepEqual(new Store(require,s.directory).read(r.id),r);
  fs.appendFileSync(file,JSON.stringify({tx:s.id(),type:'event_msg',payload:{type:'reasoning_delta',turn_id:r.turns[0].id,text:'未提交'}})+'\n');
  assert.equal(new Store(require,s.directory).read(r.id).turns[0].reasoning,'先检查条件，然后验证');
  r=s.write({...r,turns:[{...r.turns[0],reasoning:'重试后的过程'}]},r.revision);assert.equal(new Store(require,s.directory).read(r.id).turns[0].reasoning,'重试后的过程');
  assert.equal(r.turns[0].answer,'独立正文');
});

test('date partition, one stable file, structured messages and streamed deltas survive reload',async t=>{
  const {store:s}=fixture(t);let r=s.write(input(s),null,snapshot);const file=s.locate(r.id),prefix=fs.readFileSync(file,'utf8');
  assert.equal(path.relative(s.directory,file),path.join('2026','09','30','rollout-2026-09-30T23-59-59-'+r.id+'.jsonl'));
  r=s.write({...r,turns:[{...r.turns[0],answer:'你好，世界'}]},r.revision);
  assert.ok(fs.readFileSync(file,'utf8').startsWith(prefix));assert.equal(events(file).find(e=>e.type==='event_msg').payload.text,'，世界');
  r=s.write({...r,title:'重命名',turns:[{...r.turns[0],answer:'你好，世界\n完整回答',status:'done'}]},r.revision);
  const reopened=new Store(require,s.directory),read=reopened.read(r.id);assert.equal(reopened.locate(r.id),file);assert.deepEqual(read,r);assert.deepEqual(reopened.context(read),snapshot);
  const lines=events(file);assert.equal(lines.filter(e=>e.type==='turn_context').length,1);assert.equal(lines[0].type,'session_meta');
  assert.deepEqual(lines.filter(e=>e.type==='response_item').map(e=>e.payload.role),['user','assistant','assistant']);assert.equal((await reopened.list()).records.length,1);
});
test('unfinished transaction and partial UTF-8 tail recover from last committed state',t=>{
  const {store:s}=fixture(t);let r=s.write(input(s),null,snapshot);const file=s.locate(r.id),valid=fs.readFileSync(file);
  fs.appendFileSync(file,JSON.stringify({timestamp:new Date().toISOString(),type:'event_msg',tx:s.id(),payload:{type:'assistant_delta',turn_id:r.turns[0].id,text:'不应提交'}})+'\n{"截断');
  const reopened=new Store(require,s.directory);assert.deepEqual(reopened.read(r.id),r);
  r=reopened.write({...r,title:'已恢复'},r.revision);assert.ok(fs.readFileSync(file).subarray(0,valid.length).equals(valid));assert.ok(!fs.readFileSync(file,'utf8').includes('不应提交'));assert.equal(new Store(require,s.directory).read(r.id).title,'已恢复');
});
test('legacy history reads unchanged; first edit embeds its snapshot and old bytes stay untouched',async t=>{
  const {store:s,legacy}=fixture(t),old=legacy.write(input(s),null,snapshot),oldFile=path.join(legacy.folder(old.id),'state.json'),bytes=fs.readFileSync(oldFile);
  assert.equal((await s.list()).records[0].id,old.id);assert.deepEqual(s.context(s.read(old.id)),snapshot);
  const next=s.write({...s.read(old.id),title:'继续阅读'},old.revision);assert.equal(next.version,2);assert.deepEqual(s.context(next),snapshot);assert.ok(fs.readFileSync(oldFile).equals(bytes));assert.equal((await s.list()).records.length,1);
  s.remove(next);assert.equal((await s.list()).records.length,0);assert.ok(fs.readFileSync(oldFile).equals(bytes));assert.equal(new Store(require,s.directory,{legacy}).read(old.id).deleted,true);
});
test('unfinished first migration does not hide a readable legacy session',async t=>{
  const {store:s,legacy}=fixture(t),old=legacy.write(input(s),null,snapshot),file=s.newPath(old);fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,'{"partial');
  assert.equal((await s.list()).records[0].id,old.id);const saved=s.write({...old,title:'迁移恢复'},old.revision);assert.equal(s.read(saved.id).title,'迁移恢复');assert.deepEqual(s.context(saved),snapshot);
});
test('optimistic revisions, active locks and crashed-process locks protect concurrent writes',t=>{
  const {store:s}=fixture(t),old=s.write(input(s),null),other=new Store(require,s.directory),fresh=other.write({...old,title:'另一个窗口'},old.revision);
  assert.throws(()=>s.write({...old,title:'覆盖'},old.revision),{code:'CHAT_CONFLICT'});assert.equal(s.read(old.id).title,'另一个窗口');
  const lock=s.lockPath(old.id);fs.writeFileSync(lock,JSON.stringify({pid:process.pid}));assert.throws(()=>s.write(fresh,fresh.revision),/另一个窗口/);assert.ok(fs.existsSync(lock));fs.unlinkSync(lock);
  fs.writeFileSync(lock,JSON.stringify({pid:2147483647}));const recovered=s.write({...fresh,title:'恢复锁'},fresh.revision);assert.equal(recovered.title,'恢复锁');assert.ok(!fs.existsSync(lock));
});
test('clear and delete remove previous message and context bytes; deleted sessions stay hidden',async t=>{
  const {store:s}=fixture(t),r=s.write(input(s),null,snapshot),file=s.locate(r.id);const cleared=s.write({...r,turns:[],draft:''},r.revision,null);
  assert.equal(s.context(cleared),null);assert.ok(!fs.readFileSync(file,'utf8').includes('原始资料'));assert.ok(!fs.readFileSync(file,'utf8').includes('你好'));
  const deleted=s.remove(cleared);assert.equal(deleted.deleted,true);assert.equal((await s.list()).records.length,0);assert.throws(()=>s.write(r,r.revision),{code:'CHAT_CONFLICT'});
});
test('corruption and duplicate IDs cannot silently overwrite valid files',async t=>{
  const {store:s}=fixture(t),r=s.write(input(s),null),file=s.locate(r.id);fs.appendFileSync(file,'broken\n');const broken=fs.readFileSync(file);
  assert.equal((await s.list()).errors,1);assert.throws(()=>s.write(r,r.revision),/损坏/);assert.ok(fs.readFileSync(file).equals(broken));
  const q=s.write(input(s),null),copy=path.join(s.directory,'2026','10','01',path.basename(s.locate(q.id)));fs.mkdirSync(path.dirname(copy),{recursive:true});fs.copyFileSync(s.locate(q.id),copy);
  const listed=await s.list();assert.equal(listed.records.length,0);assert.throws(()=>s.write(q,q.revision),/重复/);assert.throws(()=>new Store(require,s.directory).read(q.id),/重复/);
});
test('knowledge roots and favorites are independent; main list excludes favorites',async t=>{
  const {store:s,directory}=fixture(t),r=s.write(input(s),null,snapshot),other=new Store(require,path.join(directory,'other-library','sessions'));
  assert.equal((await other.list()).records.length,0);other.write({...input(other),title:'其它知识库'},null);assert.equal((await s.list()).records.length,1);
  const favorites=new Store(require,path.join(s.directory,'favorites')),favorite=favorites.write({...r,id:s.stableId('answer:'+r.turns[0].id),kind:'favorite',originId:r.id},null,null);
  assert.equal((await s.list()).records.length,1);s.remove(r);assert.equal((await s.list()).records.length,0);assert.equal(favorites.read(favorite.id).turns[0].answer,'你好');assert.equal((await favorites.list()).records.length,1);
});

test('per-turn reference and folded draft survive reload without repeating reference on streamed commits',t=>{
  const {store:s}=fixture(t),next=input(s),reference={text:'这一轮选中的段落',label:'第二节',quotes:[{id:'quote-1',text:'这一轮选中的段落\n$x^2$ <b>原始文字</b>',source:'正文 · 第二节.md',file:'C:/books/第二节.md'}],images:[{data:'data:image/png;base64,dHVybg=='}]};
  next.turns[0].requestContext=reference;next.draftComposer={text:'补充要求',folded:'长草稿\n'.repeat(300),commandId:'translate',source:{scope:'selection',context:{selected:'新选区'}}};
  let r=s.write(next,null,snapshot);
  r=s.write({...r,turns:[{...r.turns[0],answer:'你好，流式内容'}]},r.revision);
  const reopened=new Store(require,s.directory),loaded=reopened.read(r.id),lines=events(s.locate(r.id));
  assert.deepEqual(loaded.turns[0].requestContext,reference);assert.deepEqual(loaded.draftComposer,next.draftComposer);assert.deepEqual(reopened.context(loaded),snapshot);
  assert.equal(lines.filter(e=>e.type==='turn_context'&&e.payload.turn_id).length,1);
  assert.ok(lines.filter(e=>e.type==='session_commit').every(e=>!e.payload.turns[0].requestContext));
  // An uncommitted replacement must never change the committed reference.
  fs.appendFileSync(s.locate(r.id),JSON.stringify({type:'turn_context',tx:s.id(),payload:{turn_id:r.turns[0].id,reference:{text:'未提交'}}})+'\n');
  assert.deepEqual(new Store(require,s.directory).read(r.id).turns[0].requestContext,reference);
  reopened.remove(loaded);const bytes=fs.readFileSync(s.locate(r.id),'utf8');assert.ok(!bytes.includes('长草稿'));assert.ok(!bytes.includes('这一轮选中'));assert.ok(!bytes.includes('新选区'));
});

test('clearing and deleting a conversation erase its compacted summary bytes too',t=>{const {store:s}=fixture(t);const data={...input(s),contextState:{version:1,summary:'PRIVATE_SUMMARY_MARKER',covered:[]}};let r=s.write(data,null,snapshot);r=s.write({...r,turns:[],draft:''},r.revision,null);assert.equal(s.read(r.id).contextState,null);assert.ok(!fs.readFileSync(s.locate(r.id),'utf8').includes('PRIVATE_SUMMARY_MARKER'));const other=s.write({...data,id:s.id()},null,snapshot);s.remove(other);assert.equal(s.read(other.id).contextState,null);assert.ok(!fs.readFileSync(s.locate(other.id),'utf8').includes('PRIVATE_SUMMARY_MARKER'));});

test('in-place created file results are detached from saved and cached baselines',t=>{const {store:s}=fixture(t),data=input(s);data.turns[0].requestContext={text:'source',createdFiles:[]};let r=s.write(data,null,snapshot);data.turns[0].requestContext.createdFiles.push({path:'C:/project/main.py',relative:'main.py'});assert.equal(r.turns[0].requestContext.createdFiles.length,0);r=s.write({...r,turns:data.turns},r.revision);const restored=new Store(require,s.directory).read(r.id);assert.equal(restored.turns[0].requestContext.createdFiles[0].relative,'main.py');const live=s.read(r.id);live.turns[0].requestContext.createdFiles.push({path:'C:/project/app.js',relative:'app.js'});assert.equal(s.read(r.id).turns[0].requestContext.createdFiles.length,1);r=s.write(live,live.revision);assert.equal(new Store(require,s.directory).read(r.id).turns[0].requestContext.createdFiles.length,2);});
test('caller changes to nested draft and context snapshot cannot mutate committed cache',t=>{const {store:s}=fixture(t),data={...input(s),draftComposer:{queue:{items:[{question:'initial'}]}},contextState:{version:1,summary:'saved',covered:[]}},snap=JSON.parse(JSON.stringify(snapshot));const r=s.write(data,null,snap);data.draftComposer.queue.items[0].question='changed';data.contextState.summary='changed';snap.context.markdown='changed';assert.equal(s.read(r.id).draftComposer.queue.items[0].question,'initial');assert.equal(s.read(r.id).contextState.summary,'saved');assert.equal(s.context(r).context.markdown,'原始文档');const ref=s.context(r);ref.context.markdown='changed again';assert.equal(s.context(r).context.markdown,'原始文档');});
