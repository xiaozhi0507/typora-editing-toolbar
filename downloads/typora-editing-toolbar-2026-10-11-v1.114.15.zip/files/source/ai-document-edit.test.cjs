'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),http=require('node:http'),fs=require('node:fs'),vm=require('node:vm');
const Edit=require('./ai-document-edit.cjs'),Client=require('./ai-client.cjs');
const patch=(old_text,new_text)=>({summary:'改写',edits:[{old_text,new_text}]});
test('atomic replacements preserve unrelated math, links and relative images',()=>{
  const before='# 标题\n\n甲段。\n\n$$\nx^2<3\n$$\n\n乙段。\n\n![图](./img/a.png)\n';
  const after=Edit.apply(before,{summary:'两段',edits:[{old_text:'乙段。',new_text:'乙段改好。'},{old_text:'甲段。',new_text:'甲段改好。'}]},Client.insertableMarkdown);
  assert.equal(after,before.replace('甲段。','甲段改好。').replace('乙段。','乙段改好。'));
  assert.equal(Edit.apply('abc',patch('b','')), 'ac');assert.equal(Edit.apply('',patch('','# 新文档\n')),'# 新文档\n');
});
test('invalid, ambiguous, overlapping and oversized edits fail atomically',()=>{
  for(const args of [patch('missing','a'),patch('a','b'),patch('','a'),{summary:'x',edits:[]},{summary:'x',edits:[{old_text:'ab',new_text:'x'},{old_text:'b',new_text:'y'}]}])assert.throws(()=>Edit.apply('aba',args));
  assert.throws(()=>Edit.apply('x',patch('x','y'.repeat(100001))),/10 万/);
});
test('new active HTML is escaped; fenced examples remain literal Markdown',()=>{
  assert.equal(Edit.apply('x',patch('x','<script>alert(1)</script>'),Client.insertableMarkdown),'&lt;script>alert(1)&lt;/script>');
  assert.equal(Edit.apply('x',patch('x','```html\n<b>x</b>\n```'),Client.insertableMarkdown),'```html\n<b>x</b>\n```');
});
test('line diffs reconstruct both documents and use minimum edits for repeated lines',()=>{
  const documents=[''];for(let n=1;n<=5;n++)for(let bits=0;bits<2**n;bits++)documents.push(Array.from({length:n},(_,i)=>(bits>>i)&1?'甲':'乙').join('\n')+'\n');
  for(const a of documents)for(const b of documents){const rows=Edit.diff(a,b),aa=Edit.lines(a),bb=Edit.lines(b);assert.deepEqual(rows.filter(r=>r.type!=='add').map(r=>r.text),aa);assert.deepEqual(rows.filter(r=>r.type!=='delete').map(r=>r.text),bb);
    const dp=Array.from({length:aa.length+1},()=>Array(bb.length+1).fill(0));for(let i=1;i<=aa.length;i++)for(let j=1;j<=bb.length;j++)dp[i][j]=aa[i-1]===bb[j-1]?dp[i-1][j-1]+1:Math.max(dp[i-1][j],dp[i][j-1]);
    assert.equal(rows.filter(r=>r.type!=='same').length,aa.length+bb.length-2*dp[aa.length][bb.length]);
  }
});
test('hunks keep nearby context and old/new line numbers around separated edits',()=>{
  const a=Array.from({length:30},(_,i)=>'line '+i).join('\n'),b=a.replace('line 4','changed4').replace('line 24','changed24');
  const rows=Edit.diff(a,b),hunks=Edit.hunks(rows);assert.equal(hunks.filter(r=>r.type==='gap').length,2);assert.equal(rows.find(r=>r.type==='delete').old,5);assert.equal(rows.find(r=>r.type==='add').next,5);
});
const argumentsJSON=JSON.stringify(patch('原文','新文'));const call={id:'call-1',name:'edit_current_document',arguments:argumentsJSON};
const packets={
  'openai-chat':[{choices:[{delta:{reasoning_content:'检查',tool_calls:[{index:0,id:call.id,type:'function',function:{name:call.name,arguments:argumentsJSON.slice(0,14)}}]}}]},{choices:[{delta:{tool_calls:[{index:0,function:{arguments:argumentsJSON.slice(14)}}]},finish_reason:'tool_calls'}]},'[DONE]'],
  'openai-responses':[{type:'response.output_item.added',item:{type:'function_call',id:'fc1',call_id:call.id,name:call.name,arguments:''}},{type:'response.function_call_arguments.delta',item_id:'fc1',delta:argumentsJSON.slice(0,14)},{type:'response.function_call_arguments.delta',item_id:'fc1',delta:argumentsJSON.slice(14)},{type:'response.completed',response:{status:'completed',output:[{type:'reasoning',id:'r1',summary:[],encrypted_content:'opaque-reasoning'},{type:'function_call',id:'fc1',call_id:call.id,name:call.name,arguments:argumentsJSON,status:'completed'}]}}],
  'anthropic-messages':[{type:'content_block_start',index:0,content_block:{type:'thinking',thinking:'检查',signature:''}},{type:'content_block_delta',index:0,delta:{type:'signature_delta',signature:'opaque-signature'}},{type:'content_block_stop',index:0},{type:'content_block_start',index:1,content_block:{type:'tool_use',id:call.id,name:call.name,input:{}}},{type:'content_block_delta',index:1,delta:{type:'input_json_delta',partial_json:argumentsJSON.slice(0,14)}},{type:'content_block_delta',index:1,delta:{type:'input_json_delta',partial_json:argumentsJSON.slice(14)}},{type:'content_block_stop',index:1},{type:'message_delta',delta:{stop_reason:'tool_use'}},{type:'message_stop'}]
};
async function serverFor(t,protocol,data){const received=[];const server=http.createServer((req,res)=>{let raw='';req.on('data',b=>raw+=b);req.on('end',()=>{received.push(JSON.parse(raw));res.setHeader('Content-Type','text/event-stream');const bytes=Buffer.from(data.map(p=>'data: '+(typeof p==='string'?p:JSON.stringify(p))+'\n\n').join(''));for(let i=0;i<bytes.length;i+=7)res.write(bytes.subarray(i,i+7));res.end();});});await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>{server.closeAllConnections();server.close();});return {received,client:new Client(require),profile:{url:'http://127.0.0.1:'+server.address().port,protocol,model:'test',documentEdit:true}};}
for(const protocol of Object.keys(packets))test(protocol+' streamed tool-only response and protocol-specific continuation',async t=>{
  const f=await serverFor(t,protocol,packets[protocol]),messages=[{role:'system',content:'system'},{role:'user',content:'改写'}],result=await f.client.request(f.profile,'',messages,{});
  assert.deepEqual(result.toolCalls,[call]);const initial=f.received[0];assert.equal(initial.tools.length,2);const continuation=Client.body(f.profile,Client.continueTools(messages,result,[{applied:true}]));
  if(protocol==='openai-chat'){assert.equal(continuation.messages.at(-2).reasoning_content,'检查');assert.equal(continuation.messages.at(-1).tool_call_id,call.id);assert.equal(continuation.messages.at(-1).content,'{"applied":true}');}
  if(protocol==='openai-responses'){assert.equal(continuation.input.at(-1).type,'function_call_output');assert.equal(continuation.input.at(-1).call_id,call.id);assert.ok(continuation.input.some(x=>x.encrypted_content==='opaque-reasoning'));assert.equal(continuation.store,false);}
  if(protocol==='anthropic-messages'){assert.equal(continuation.messages.at(-2).content[0].signature,'opaque-signature');assert.deepEqual(continuation.messages.at(-2).content[1].input,patch('原文','新文'));assert.equal(continuation.messages.at(-1).content[0].tool_use_id,call.id);}
});
test('incomplete and truncated tool streams never return executable calls',async t=>{
  for(const protocol of Object.keys(packets)){let p=structuredClone(packets[protocol]);if(protocol==='openai-chat')p.splice(1,2,{choices:[{delta:{},finish_reason:'length'}]},'[DONE]');if(protocol==='openai-responses')p[p.length-1]={type:'response.incomplete',response:{status:'incomplete',incomplete_details:{reason:'max_output_tokens'}}};if(protocol==='anthropic-messages')p[p.length-2]={type:'message_delta',delta:{stop_reason:'max_tokens'}};const f=await serverFor(t,protocol,p);await assert.rejects(f.client.request(f.profile,'',[{role:'user',content:'x'}]),/未完整/);}
  const f=await serverFor(t,'openai-chat',packets['openai-chat'].slice(0,1));await assert.rejects(f.client.request(f.profile,'',[{role:'user',content:'x'}]),/提前结束/);
});
test('ordinary chat does not expose tools or private continuation fields',()=>{
  for(const protocol of Object.keys(packets))assert.equal(Client.body({protocol,model:'x'},[{role:'user',content:'x'}]).tools,undefined);
});
test('authorized headerless SSE retains streamed reasoning and tool items when final output is empty',async t=>{
  const reasoning={type:'reasoning',id:'r',summary:[],encrypted_content:'opaque'},item={type:'function_call',id:'f',call_id:call.id,name:call.name,arguments:argumentsJSON,status:'completed'};
  const server=http.createServer((req,res)=>{req.resume();const text=req.url.includes('bad')?'{}':[{type:'response.output_item.done',output_index:0,item:reasoning},{type:'response.output_item.done',output_index:1,item},{type:'response.completed',response:{status:'completed',output:[]}}].map(x=>'event: '+x.type+'\ndata: '+JSON.stringify(x)+'\n\n').join('');for(const byte of Buffer.from(text))res.write(Buffer.from([byte]));res.end();});await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>{server.closeAllConnections();server.close();});
  const client=new Client(require),p={url:'http://127.0.0.1:'+server.address().port+'/responses',fullUrl:true,protocol:'openai-responses',model:'x',documentEdit:true,authType:'chatgpt'},m=[{role:'user',content:'改写'}],result=await client.request(p,'',m);
  assert.deepEqual(result.toolCalls,[call]);const input=Client.body(p,Client.continueTools(m,result,[{applied:true}])).input;assert.equal(input.at(-2).call_id,call.id);assert.equal(input.at(-1).call_id,call.id);assert.equal(input.find(x=>x.type==='reasoning').encrypted_content,'opaque');await assert.rejects(client.request({...p,url:p.url+'/bad'},'',m),/事件流/);
});
function controller(autoRead=true){let text='原文',file='A.md',writes=0,flushes=0;const host={File:{isLocked:false,isFileLoading:()=>false},ETAIDocumentEdit:Edit,ETAIExecution:require('./ai-execution.cjs'),ETAIClient:Client,Error,JSON,Date};vm.createContext(host);vm.runInContext(fs.readFileSync(__dirname+'/ai-document-edit.js','utf8')+'\nthis.Controller=EditingToolbarAIDocumentEdit;',host);const ai={file:()=>file,source:()=>text,conversations:{flush:()=>flushes++}},ui=new host.Controller(ai);ui.render=()=>{};ui.write=t=>(writes++,text=t);let responder,read=false;Object.defineProperty(ai,'request',{set:fn=>responder=fn,get:()=>async(p,k,m,o)=>{if(autoRead&&p.documentEdit&&!read){read=true;assert.ok(!m.some(x=>String(x.content).includes(text)));return {toolCalls:[{id:'read-fixture',name:'read_current_document',arguments:'{}'}]};}return responder(p,k,m,o);}});return {host,ai,ui,turn:{file},input:[{role:'system',content:'系统'},{role:'user',content:'改写'}],get text(){return text;},get writes(){return writes;},get flushes(){return flushes;},set text(v){text=v;},set file(v){file=v;}};}
test('edit controller executes one atomic patch, then reports tool result and aggregates subsequent edits',async()=>{
  const f=controller();let n=0;f.ai.request=async(p,key,m)=>{assert.equal(p.documentEdit,true);if(n++===0){assert.ok(m.some(x=>x.content.includes('原文')));return {toolCalls:[call],text:''};}assert.equal(JSON.parse(m.at(-1).content).applied,true);return n===2?{toolCalls:[{...call,arguments:JSON.stringify(patch('新文','终稿'))}]}:{text:'已完成'};};
  assert.equal((await f.ui.run({},'',f.input,{},f.turn)).text,'已完成');assert.equal(f.text,'终稿');assert.equal(f.writes,2);assert.equal(f.flushes,2);assert.equal(f.turn.requestContext.documentEdit.before,'原文');assert.equal(f.turn.requestContext.documentEdit.after,'终稿');
});
test('document switch, concurrent typing, readonly and cancellation block editing',async()=>{
  for(const kind of ['switch','type','readonly','abort']){const f=controller(),signal=new AbortController();f.ai.request=async()=>{if(kind==='switch')f.file='B.md';if(kind==='type')f.text='手动输入';if(kind==='readonly')f.host.File.isLocked=true;if(kind==='abort')signal.abort();return {toolCalls:[call]};};await assert.rejects(f.ui.run({},'',f.input,{signal:signal.signal},f.turn));assert.equal(f.writes,0);}
});
test('invalid patch is returned to model; a corrected call can succeed without partial writes',async()=>{
  const f=controller();let n=0;f.ai.request=async(p,k,m)=>{if(n++===0)return {toolCalls:[{...call,arguments:JSON.stringify(patch('找不到','替换'))}]};if(n===2){assert.equal(f.writes,0);assert.equal(JSON.parse(m.at(-1).content).applied,false);return {toolCalls:[call]};}return {text:'完成'};};await f.ui.run({},'',f.input,{},f.turn);assert.equal(f.writes,1);assert.equal(f.text,'新文');
});
test('failed final response leaves a saved, undoable record of applied changes',async()=>{
  const f=controller();let n=0;f.ai.request=async()=>{if(n++===0)return {toolCalls:[call]};throw Error('网络断开');};await assert.rejects(f.ui.run({},'',f.input,{},f.turn),/网络/);assert.equal(f.turn.requestContext.documentEdit.after,f.text);assert.equal(f.flushes,1);
});
test('native refresh failure after a write still saves an undoable change record',async()=>{
  const f=controller();f.ai.request=async()=>({toolCalls:[call]});f.ui.write=t=>{f.text=t;throw Error('refresh failed');};await assert.rejects(f.ui.run({},'',f.input,{},f.turn),/可查看变更或撤销/);assert.equal(f.turn.requestContext.documentEdit.before,'原文');assert.equal(f.turn.requestContext.documentEdit.after,'新文');assert.equal(f.flushes,1);
});

test('editing continues beyond five rounds and accepts a final answer before the new limit',async()=>{
  const f=controller();let requests=0;f.ai.request=async()=>{
    const n=++requests;if(n===9)return {text:'已完成八处修改'};
    return {toolCalls:[{...call,id:'call-'+n,arguments:JSON.stringify(patch(n===1?'原文':'第'+(n-1)+'版','第'+n+'版'))}]};
  };
  const result=await f.ui.run({},'',f.input,{},f.turn);
  assert.equal(requests,9);assert.equal(f.writes,8);assert.equal(f.text,'第8版');assert.equal(result.text,'已完成八处修改');assert.equal(f.turn.requestContext.documentEdit.before,'原文');assert.equal(f.turn.requestContext.documentEdit.after,'第8版');
});

test('twenty-round boundary stops further requests and does not falsely claim completion',async()=>{
  for(const valid of [true,false]){
    const f=controller();let requests=0;f.ai.request=async()=>{const n=++requests;return {toolCalls:[{...call,id:'call-'+n,arguments:JSON.stringify(patch(valid?(n===1?'原文':'第'+(n-1)+'版'):'缺失原文','第'+n+'版'))}]};};
    const result=await f.ui.run({},'',f.input,{},f.turn);
    assert.equal(requests,19);assert.equal(f.writes,valid?19:0);assert.match(result.text,/20 轮编辑上限/);assert.match(result.text,/可能尚未完成/);assert.ok(!result.text.includes('已完成'));
    assert.equal(f.text,valid?'第19版':'原文');assert.match(result.text,valid?/已保留本次应用的修改/:/未修改文档/);
  }
});

test('edit controller writes renderable image HTML and can repair previously escaped markup',async()=>{
  const f=controller(),before='&lt;img src="assets/a.png" style="zoom:150%;" />',after='<img src="assets/a.png" style="zoom:150%;" />';f.text=before;let n=0;f.ai.request=async()=>n++?{text:'已修复图片'}:{toolCalls:[{...call,arguments:JSON.stringify(patch(before,after))}]};
  await f.ui.run({},'',f.input,{},f.turn);assert.equal(f.text,after);assert.equal(f.writes,1);assert.equal(f.turn.requestContext.documentEdit.before,before);assert.equal(f.turn.requestContext.documentEdit.after,after);
});

for(const protocol of Object.keys(packets))test(protocol+' web-only tool stream preserves calls without document edit permission',async t=>{const data=JSON.parse(JSON.stringify(packets[protocol]).replaceAll('edit_current_document','web_search'));const f=await serverFor(t,protocol,data);f.profile.documentEdit=false;f.profile.webSearch=true;const result=await f.client.request(f.profile,'',[{role:'user',content:'search'}],{});assert.equal(result.toolCalls[0].name,'web_search');assert.equal(f.received[0].tools.length,2);});
test('web-only loop never supplies live Markdown or applies an edit tool',async()=>{const f=controller();let round=0,prepared=0;f.ai.webUI={prepare:async(p,m)=>{prepared++;return m;},execute:async()=>({sources:[{url:'https://example.com'}]})};f.ai.request=async(p,k,m)=>{assert.ok(!m.some(x=>String(x.content).includes('原文')));if(round++===0)return {toolCalls:[call]};assert.equal(JSON.parse(m.at(-1).content).applied,false);return {text:'网页回答'};};assert.equal((await f.ui.run({documentEdit:false,webSearch:true},'',f.input,{},f.turn)).text,'网页回答');assert.equal(prepared,1);assert.equal(f.writes,0);});
test('file creation survives a failed final answer and does not claim the current document was edited',async()=>{const f=controller();let round=0;f.ai.webUI={prepare:async(p,m)=>m,execute:async(p,c,o,t)=>{t.requestContext={createdFiles:[{path:'root/a.py',relative:'a.py'}]};return {created:true};}};f.ai.request=async()=>round++===0?{toolCalls:[{id:'f',name:'create_project_file',arguments:'{}'}]}:{text:'Created a.py'};const result=await f.ui.run({documentEdit:true,project:{trusted:true}},'',f.input,{},f.turn);assert.equal(f.writes,0);assert.equal(f.turn.requestContext.createdFiles.length,1);assert.equal(result.text,'Created a.py');});


test('unread edit is rejected before any write; reading then retrying succeeds',async()=>{
 const f=controller(false);let round=0;f.ai.request=async(p,k,m)=>{round++;if(round===1)return {toolCalls:[call]};if(round===2){assert.equal(f.writes,0);assert.match(m.at(-1).content,/read_current_document/);return {toolCalls:[{id:'r',name:'read_current_document',arguments:'{}'}]};}if(round===3){assert.equal(JSON.parse(m.at(-1).content).markdown,'原文');return {toolCalls:[call]};}return {text:'done'};};await f.ui.run({documentEdit:true},'',f.input,{},f.turn);assert.equal(f.text,'新文');
});
test('file-only first request has no whole Markdown; huge unrelated documents do not block file creation',async()=>{
 const f=controller(false);f.text='PRIVATE_MARKER'.repeat(20000);f.ai.webUI={prepare:async(p,m)=>m,execute:async(p,c,o,t)=>{t.requestContext={createdFiles:[{path:'root/a.py',relative:'a.py'}]};return {created:true};}};let n=0;f.ai.request=async(p,k,m)=>{assert.ok(!JSON.stringify(m).includes('PRIVATE_MARKER'));return n++?{text:'created'}:{toolCalls:[{id:'f',name:'create_project_file',arguments:'{}'}]};};await f.ui.run({documentEdit:true,project:{trusted:true}},'',f.input,{},f.turn);assert.equal(f.writes,0);assert.equal(f.turn.requestContext.createdFiles.length,1);
});
