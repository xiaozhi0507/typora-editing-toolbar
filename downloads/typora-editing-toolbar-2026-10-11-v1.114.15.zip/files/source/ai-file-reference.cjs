'use strict';
// Paths and labels are data. No shell command is built from a referenced path.
class AIFileReference {
 constructor(req=require){this.fs=req('fs');this.path=req('path');this.cp=req('child_process');this.env=req('process').env;this.platform=req('process').platform;}
 static web(value){try{const u=new URL(value);return ['http:','https:'].includes(u.protocol)&&!u.username&&!u.password?u.href:null;}catch{return null;}}
 static local(value){
  if(typeof value!=='string'||!value.trim()||/[\x00-\x1f<>"|?*]/.test(value))return null;let text=value.trim();
  if(/^file:/i.test(text)){try{const u=new URL(text);if(u.hostname&&u.hostname!=='localhost')return null;text=decodeURIComponent(u.pathname);if(u.hash||u.search)return null;}catch{return null;}}
  else {try{text=decodeURIComponent(text);}catch{return null;}}
  text=text.replace(/^\/(?=[a-z]:[\/\\])/i,'');if(/^[\\/]{2}|^\\\\[?.]|[\x00-\x1f<>"|?*]/.test(text))return null;
  // Reject arbitrary URI schemes, drive-relative paths, alternate streams and device names.
  if(/^[a-z][a-z0-9+.-]*:/i.test(text)&&!(/^[a-z]:[\\/]/i.test(text)))return null;
  if(text.replace(/^[a-z]:/i,'').includes(':')||text.split(/[\\/]/).some(p=>/^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(p)))return null;
  return text;
 }
 resolve(value,{file,createdFiles=[],references=[]}={},label){
  const local=AIFileReference.local(value);if(!local||local.startsWith('#'))return null;
  const path=this.path,win=path.win32,isAbs=win.isAbsolute(local)||path.isAbsolute(local),norm=s=>String(s).replace(/\\/g,'/').toLowerCase();
  const rows=[...createdFiles,...references].filter(r=>r&&typeof r.path==='string');
  const aliases=rows.filter(r=>[r.relative,r.name,r.path].some(x=>x&&norm(x)===norm(local)));
  const unique=[...new Map(aliases.map(r=>[norm(r.path),r])).values()];let target;
  if(unique.length===1)target=unique[0].path;
  else if(isAbs)target=local;
  else if(unique.length>1)return null;
  else if(file&&!file.startsWith('untitled:')){const p=/^[a-z]:/i.test(file)?win:path;target=p.resolve(p.dirname(file),local);}
  if(!target||!AIFileReference.local(target))return null;
  const p=/^[a-z]:/i.test(target)?win:path;target=p.normalize(target);
  const name=p.basename(target),created=createdFiles.some(r=>norm(r.path)===norm(target));
  return {path:target,name,displayName:String(label||unique[0]?.displayName||name),created};
 }
 created(file){const ref=this.resolve(file?.path||'',{createdFiles:[file]},file?.displayName||file?.relative||file?.name);return ref?{...ref,name:file.name||ref.name,relative:file.relative||ref.name,created:true}:null;}
 async stat(ref){try{const s=await this.fs.promises.stat(ref.path);return {exists:s.isFile(),size:s.size,reason:s.isFile()?'':'不是普通文件'};}catch(e){return {exists:false,reason:e.code==='ENOENT'?'文件不存在或已移动':e.message};}}
 async requireFile(ref){const s=await this.stat(ref);if(!s.exists)throw Error(s.reason);return s;}
 async text(ref){
  const s=await this.requireFile(ref);if(/\.(?:pdf|docx?|xlsx?|pptx?|odt|ods|odp|png|jpe?g|gif|webp|ico|bmp|tiff?|mp3|mp4|wav|ogg|webm|zip|gz|7z|rar|exe|dll)$/i.test(ref.path))throw Error('二进制文件不支持复制文本内容');if(s.size>2*1024*1024)throw Error('文本文件超过 2 MB，请打开文件查看');
  const handle=await this.fs.promises.open(ref.path,'r');let bytes;try{const b=Buffer.alloc(s.size+1);const n=(await handle.read(b,0,b.length,0)).bytesRead;if(n>s.size)throw Error('文件已变化，请重试');bytes=b.subarray(0,n);}finally{await handle.close();}
  let text;if(bytes[0]===255&&bytes[1]===254)text=new TextDecoder('utf-16le',{fatal:true}).decode(bytes);else if(bytes[0]===254&&bytes[1]===255)text=new TextDecoder('utf-16be',{fatal:true}).decode(bytes);else {if(bytes.includes(0))throw Error('二进制文件不支持复制文本内容');try{text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);}catch{try{text=new TextDecoder('gb18030',{fatal:true}).decode(bytes);}catch{throw Error('无法解码文本文件');}}}
  if(/[\x00-\x08\x0e-\x1f]/.test(text))throw Error('二进制文件不支持复制文本内容');return text;
 }
 async copy(ref,destination){await this.requireFile(ref);if(this.path.resolve(destination).toLowerCase()===this.path.resolve(ref.path).toLowerCase())throw Error('另存为位置与原文件相同');await this.fs.promises.copyFile(ref.path,destination,this.fs.constants.COPYFILE_EXCL);return destination;}
 launch(exe,args,options={}){return new Promise((resolve,reject)=>{const child=this.cp.spawn(exe,args,{shell:false,detached:true,stdio:'ignore',windowsHide:false,...options});child.once('error',reject);child.once('spawn',()=>{child.unref();resolve({pid:child.pid});});});}
 systemPath(...parts){return this.path.join(this.env.SystemRoot||'C:\\Windows',...parts);}
 capabilities(){return {terminal:this.platform==='win32'&&this.fs.existsSync(this.systemPath('System32','WindowsPowerShell','v1.0','powershell.exe')),openWith:this.platform==='win32'};}
 async terminal(ref){
  await this.requireFile(ref);if(!this.capabilities().terminal)throw Error('当前环境不支持打开终端');
  const exe=this.systemPath('System32','WindowsPowerShell','v1.0','powershell.exe');
  // Fixed bootstrap: the path travels in the environment, never in PowerShell source.
  // Start-Process allocates a real interactive console instead of inheriting stdin=NUL.
  const script='$ErrorActionPreference="Stop"; $ProgressPreference="SilentlyContinue"; $p=Start-Process -FilePath $env:ET_REFERENCE_TERMINAL -WorkingDirectory $env:ET_REFERENCE_DIRECTORY -ArgumentList @("-NoLogo","-NoProfile","-NoExit") -WindowStyle Normal -PassThru; $p.Id';
  return new Promise((resolve,reject)=>this.cp.execFile(exe,['-NoLogo','-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(script,'utf16le').toString('base64')],{windowsHide:true,timeout:15000,env:{...this.env,ET_REFERENCE_TERMINAL:exe,ET_REFERENCE_DIRECTORY:this.path.dirname(ref.path)}},(error,out)=>error?reject(Error('打开终端失败：'+error.message)):resolve({pid:Number(String(out).trim())})));
 }
 async openWith(ref,application){await this.requireFile(ref);if(!this.capabilities().openWith)throw Error('当前环境不支持打开方式');const exe=application||this.systemPath('System32','notepad.exe');if(!this.path.isAbsolute(exe)||this.path.extname(exe).toLowerCase()!=='.exe'||!(await this.fs.promises.stat(exe)).isFile())throw Error('请选择有效的应用程序（.exe）');return this.launch(exe,[ref.path]);}
}
module.exports=AIFileReference;
