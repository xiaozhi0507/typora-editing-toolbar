const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),{JSDOM}=require('jsdom');
function fixture(t){
 const dom=new JSDOM('<section id="et-ai-panel"><div id="et-ai-model-menu"></div></section>',{url:'https://fixture.local',runScripts:'outside-only'}),w=dom.window,d=w.document;t.after(()=>w.close());
 w.ETAIClient=require('./ai-client.cjs');w.ETAIUsagePage=require('./ai-usage-page.cjs');
 w.eval(['ai-web-session','ai-web-chat-browser','ai-web-projects','ai-web-translation','ai-web-chat','ai-usage-browser','ai-effort'].map(file=>fs.readFileSync(__dirname+'/'+file+'.js','utf8')).join('\n')+';Object.assign(window,{Session:EditingToolbarAIWebSession,Browser:EditingToolbarWebChatBrowser,Web:EditingToolbarAIWebChat,Usage:EditingToolbarAIUsageBrowser,Effort:EditingToolbarAIEffort});');
 const ai={config:{webChat:{mode:'Extra High',version:'Latest'}},node:(tag,cls,text)=>{const e=d.createElement(tag);if(cls)e.className=cls;if(text)e.textContent=text;return e;},notice(){},composerUI:{closeMenu(){}},profile:()=>ai.webChat.profile};
 ai.webChat=new w.Web(ai);ai.webChat.browser.capabilities={versions:['Latest','GPT-5.6 Sol','GPT-5.5'].map(label=>({label})),modes:['Instant','Medium','High','Extra High','6 Pro'].map((label,value)=>({label,value}))};ai.webChat.browser.status='已连接';
 return {w,d,ai,web:ai.webChat,b:ai.webChat.browser,menu:d.querySelector('#et-ai-model-menu')};
}
test('web provider opens a nested actual-version menu and commits the chosen version',t=>{
 const {w,menu,ai,b}=fixture(t);let chosen,refreshes=0;b.refresh=async()=>refreshes++;
 w.Effort.render(ai,menu,{profiles:[ai.webChat.profile],profile:ai.profile(),view:'models',onModel:p=>chosen=p});
 const group=menu.querySelector('[data-group="GPT 网页"]');assert.equal(group.getAttribute('aria-haspopup'),'menu');group.click();assert.equal(group.getAttribute('aria-expanded'),'true');
 assert.deepEqual([...menu.querySelectorAll('[data-web-version]')].map(e=>e.textContent),['Latest','GPT-5.6 Sol']);
 menu.querySelector('[data-web-version="GPT-5.6 Sol"]').click();assert.equal(chosen.webVersion,'GPT-5.6 Sol');assert.equal(chosen.authType,'chatgpt-web');assert.equal(refreshes,0);
 menu._openGroup('GPT 网页');assert.equal(refreshes,0,'cached picker must not resync on reopen');
});
test('compact web picker has status and settings in header, no version field or footer actions',async t=>{
 const {menu,web,b,ai}=fixture(t);let opened=0,closed=0,selected=[];b.show=()=>opened++;ai.composerUI.closeMenu=()=>closed++;b.select=async(...args)=>selected.push(args);
 web.renderPicker(menu,{onView(){}});assert.equal(menu.querySelector('select'),null);assert.equal(menu.querySelector('.et-ai-web-chat-picker-actions'),null);assert.equal(menu.querySelector('.et-ai-effort-head [role=status]').textContent,'已连接');
 const slider=menu.querySelector('input');slider.value='4';slider.dispatchEvent(new menu.ownerDocument.defaultView.Event('input'));assert.equal(selected.length,0);slider.dispatchEvent(new menu.ownerDocument.defaultView.Event('change'));assert.equal(selected[0][0],'mode');assert.equal(selected[0][1].label,'6 Pro');
 menu.querySelector('[aria-label="GPT 网页设置"]').click();assert.equal(opened,1);assert.equal(closed,1);
});
test('unavailable versions stay disabled and unknown capabilities are not invented',t=>{
 const {menu,web,b}=fixture(t);b.capabilities.versions[1].disabled=true;web.renderVersions(menu,{onModel(){throw Error('disabled');}});assert.equal(menu.querySelector('[data-web-version="GPT-5.6 Sol"]').disabled,true);assert.equal(menu.querySelector('[data-web-version="GPT-5.5"]'),null);
 menu.replaceChildren();b.capabilities.versions=[];b.status='请在 GPT 网页登录后重试';web.renderVersions(menu,{onModel(){}});assert.equal(menu.querySelector('[data-web-version]'),null);assert.match(menu.textContent,/登录/);assert.match(menu.textContent,/打开 GPT 网页/);
});
test('both website surfaces mount the existing chat partition with isolated guests and no account-specific session',t=>{
 const {w,ai,b}=fixture(t);b.mount();const u=new w.Usage(ai),one=u.mount({chatgptAccount:'first'},false);assert.equal(b.view.getAttribute('partition'),'persist:et-chatgpt-web-v1');assert.equal(one.view.getAttribute('partition'),b.view.getAttribute('partition'));assert.match(one.view.getAttribute('webpreferences'),/sandbox=yes,nodeIntegration=no/);u.close();
 const two=u.mount({chatgptAccount:'second'},true);assert.equal(two.view.getAttribute('partition'),b.view.getAttribute('partition'));assert.match(two.panel.textContent,/与 GPT 网页共用登录/);u.close();b.destroy();
});
test('usage cache follows the shared webpage session instead of claiming per-API-account quotas',t=>{
 const {w,ai,d}=fixture(t);ai.chatgptUI={readWebUsage(){throw Error('render must be inert');}};
 for(const account of ['a','b'])w.Effort.quota(ai,d.createElement('div'),d.createElement('div'),{model:'gpt-6.1-sol',chatgptAccount:account});
 assert.equal(ai.manualUsageCache.size,1);assert.equal(ai.manualUsageCache.has(w.Session.usageKey),true);
});
