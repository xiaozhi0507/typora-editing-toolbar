import {TextSelection,NodeSelection} from 'prosemirror-state';
import {closeHistory} from 'prosemirror-history';

export function noteBlockEnter(schema){return (state,dispatch,view)=>{
 const sel=state.selection,p=sel.$from.parent;
 if(view?.composing||!sel.empty||p.type!==schema.nodes.paragraph||sel.$from.parentOffset!==p.content.size)return false;
 const fence=/^ {0,3}(?:`{3,}|~{3,})([\w.+#-]*)[ \t]*$/.exec(p.textContent),rule=/^ {0,3}(?:-{3,}|\*{3,}|_{3,})[ \t]*$/.test(p.textContent);
 if((!fence&&!rule)||state.doc.rangeHasMark(sel.$from.start(),sel.$from.end(),schema.marks.code))return false;
 if(dispatch){const from=sel.$from.before(),to=sel.$from.after(),content=fence?[schema.nodes.code_block.create({params:fence[1]})]:[schema.nodes.horizontal_rule.create(),schema.nodes.paragraph.create()];let tr=closeHistory(state.tr).replaceWith(from,to,content);tr.setSelection(TextSelection.create(tr.doc,from+(fence?1:2)));dispatch(tr.scrollIntoView());}
 return true;
};}

function afterBlock(state,dispatch,after){
 const at=state.doc.resolve(after),next=at.nodeAfter,paragraph=state.schema.nodes.paragraph;
 let tr=state.tr;
 if(next?.isTextblock&&!next.type.spec.code)tr.setSelection(TextSelection.create(tr.doc,after+1));
 else{if(!at.parent.canReplaceWith(at.index(),at.index(),paragraph))return false;tr=closeHistory(tr).insert(after,paragraph.create());tr.setSelection(TextSelection.create(tr.doc,after+1));}
 tr.setStoredMarks([]);if(dispatch)dispatch(tr.scrollIntoView());return true;
}

export function leaveNoteMath(view,pos,node,direction='right'){
 let state=view.state,after=pos+node.nodeSize;
 // An unfilled inline placeholder has no unambiguous Markdown representation.
 // Leaving it cancels that placeholder, while keeping all surrounding text.
 if(node.isInline&&!node.attrs.tex.trim()){view.dispatch(state.tr.delete(pos,after));state=view.state;after=pos;}
 const at=state.doc.resolve(after);
 if(!node.isInline)return afterBlock(state,view.dispatch,after);
 if(direction==='down'&&at.parentOffset===at.parent.content.size)return afterBlock(state,view.dispatch,at.after());
 const marks=state.schema.marks.code.removeFromSet(at.marks());
 view.dispatch(state.tr.setSelection(TextSelection.create(state.doc,after)).setStoredMarks(marks).scrollIntoView());return true;
}

// A textarea can wrap a single TeX line. Measure its last visual line rather
// than using the last newline alone, so Down still navigates long formulas.
export function mathSourceBoundary(source,key){
 const start=source.selectionStart,end=source.selectionEnd,text=source.value;
 if(start!==end)return false;
 if(key==='ArrowRight')return end===text.length;
 if(key!=='ArrowDown'||text.indexOf('\n',end)>=0)return false;
 if(end===text.length)return true;
 const doc=source.ownerDocument,css=doc.defaultView.getComputedStyle(source),mirror=doc.createElement('div');
 mirror.style.cssText='position:fixed;left:-100000px;top:0;visibility:hidden;pointer-events:none;white-space:pre-wrap;overflow-wrap:break-word;box-sizing:border-box;';
 for(const name of ['font','line-height','letter-spacing','word-spacing','padding','tab-size','text-indent','word-break'])mirror.style.setProperty(name,css.getPropertyValue(name));
 mirror.style.width=source.clientWidth+'px';const caret=doc.createElement('span'),tail=doc.createElement('span');caret.textContent=tail.textContent='\u200b';
 mirror.append(doc.createTextNode(text.slice(0,end)),caret,doc.createTextNode(text.slice(end)),tail);doc.body.append(mirror);
 try{return Math.abs(caret.getBoundingClientRect().top-tail.getBoundingClientRect().top)<1;}finally{mirror.remove();}
}

export function noteArrowExit(schema,direction){return (state,dispatch,view)=>{
 if(!view?.editable||view.composing)return false;
 let sel=state.selection;
 if(sel instanceof NodeSelection){
  if(sel.node.type===schema.nodes.math_inline){if(dispatch)leaveNoteMath(view,sel.from,sel.node,direction);return true;}
  if(['code_block','math_block','blockquote','note_card'].includes(sel.node.type.name))return afterBlock(state,dispatch,sel.to);
  return false;
 }
 const domSelection=view.dom.ownerDocument.getSelection();
 if(!sel.empty||(domSelection&&!domSelection.isCollapsed)||!sel.$from.parent.isTextblock)return false;
 // Home/End and native cursor moves may precede ProseMirror's asynchronous
 // selectionchange. Resolve the current caret before testing a boundary.
 if(domSelection?.focusNode&&view.dom.contains(domSelection.focusNode)){
  const pos=view.posAtDOM(domSelection.focusNode,domSelection.focusOffset);
  if(pos!==sel.from&&state.doc.resolve(pos).parent.isTextblock){state=state.apply(state.tr.setSelection(TextSelection.create(state.doc,pos)));sel=state.selection;}
 }
 const at=sel.$from,atEnd=at.parentOffset===at.parent.content.size;
 const boundary=direction==='right'?atEnd:view.endOfTextblock('down',state);
 if(at.parent.type===schema.nodes.code_block)return boundary?afterBlock(state,dispatch,at.after()):false;
 const code=schema.marks.code,marks=state.storedMarks||at.marks();
 if(code.isInSet(marks)){
  if(direction==='down')return boundary?afterBlock(state,dispatch,at.after()):false;
  if(!code.isInSet(at.nodeAfter?.marks||[])){if(dispatch)dispatch(state.tr.setStoredMarks(code.removeFromSet(marks)));return true;}
 }
 if(!boundary)return false;
 for(let depth=at.depth-1;depth>0;depth--){
  if(at.index(depth)!==at.node(depth).childCount-1)break;
  if(['blockquote','note_card'].includes(at.node(depth).type.name))return afterBlock(state,dispatch,at.after(depth));
 }
 if(direction==='down'&&atEnd&&at.nodeBefore?.type===schema.nodes.math_inline)return afterBlock(state,dispatch,at.after());
 return false;
};}
