'use strict';
const ISBN=typeof ETKnowledgeISBN!=='undefined'?ETKnowledgeISBN:require('./knowledge-library-isbn.cjs');
// S2 has no ISBN identifier endpoint. Resolve the edition in a book catalogue,
// then match its metadata against S2 Book records; never invent ISBN:<id> URLs.
class KnowledgeLibraryBookMetrics {
  static isbn(value){return ISBN.normalize(value);}
  static normalize(value){return String(value||'').normalize('NFKC').toLowerCase().replace(/[\p{P}\p{S}\s]/gu,'');}
  static authors(value){return String(value||'').split(/[;；\n、]/).map(s=>s.trim()).filter(Boolean);}
  static authorMatches(a,b){
    if(this.normalize(a)===this.normalize(b))return true;
    const tokens=name=>{
      const parts=String(name).normalize('NFKD').replace(/\p{M}/gu,'').toLowerCase().split(',');
      const ordered=parts.length===2?parts[1]+' '+parts[0]:parts.join(' ');
      return ordered.match(/[a-z]+/g)||[];
    };
    // Full names and initials may differ, but require the same surname and
    // compatible given names. Non-Latin names require exact normalization.
    if(/[^\x00-\x7f]/.test(a+b))return false;
    const x=tokens(a),y=tokens(b);if(x.length<2||y.length<2||x.at(-1)!==y.at(-1))return false;
    const given=(short,long)=>short.slice(0,-1).every((v,i)=>v===long[i]||v[0]===long[i]?.[0]&&(v.length===1||long[i]?.length===1));
    return x.length<=y.length?given(x,y):given(y,x);
  }
  static catalogue(result,isbn){
    const f=result?.fields;
    if(this.isbn(f?.isbn)!==isbn)throw Error('ISBN 书目返回的书号不匹配，未采用');
    const title=String(f.title||'').trim(),authors=this.authors(f.author),year=String(f.date||'').match(/\b(?:1[5-9]|20)\d{2}\b/)?.[0];
    if(!title||title.length>500||!authors.length||!year)throw Error('ISBN 书目缺少书名、作者或出版年份，暂无法可靠匹配 Semantic Scholar');
    return {isbn,title,authors,year,source:result.source||f.libraryCatalog||'ISBN 书目'};
  }
  static matches(book,paper){
    if(!paper||!/^[a-f\d]{40}$/i.test(paper.paperId||''))return false;
    if(!Array.isArray(paper.publicationTypes)||!paper.publicationTypes.includes('Book')||paper.publicationTypes.some(t=>['BookSection','Review'].includes(t)))return false;
    if(this.normalize(paper.title)!==this.normalize(book.title)||String(paper.year)!==book.year)return false;
    const names=Array.isArray(paper.authors)?paper.authors.map(a=>a?.name).filter(n=>typeof n==='string'&&n.trim()):[];
    if(names.length!==book.authors.length)return false;
    // Pair authors one-to-one, rather than allowing a repeated initial to match twice.
    const available=[...names];
    for(const name of book.authors){const at=available.findIndex(other=>this.authorMatches(name,other));if(at<0)return false;available.splice(at,1);}
    return true;
  }
  static select(book,response){
    if(!Array.isArray(response?.data)||!Number.isSafeInteger(response.total)||response.total<0||response.total<response.data.length)throw Error('Semantic Scholar 书籍搜索响应无效');
    if(response.next!=null||response.total>response.data.length)throw Error('Semantic Scholar 书籍候选结果不完整，无法排除同名版本，未采用');
    const matches=new Map();
    for(const row of response.data)if(this.matches(book,row)){
      const old=matches.get(row.paperId);
      if(old&&JSON.stringify(old)!==JSON.stringify(row))throw Error('Semantic Scholar 同一书籍返回冲突数据，未采用');
      matches.set(row.paperId,row);
    }
    if(matches.size!==1)throw Error(matches.size?'Semantic Scholar 找到多个同名同年书籍，无法确认对应 ISBN，未采用':'Semantic Scholar 未找到与该 ISBN 书目相符的书籍（书名、作者、年份及类型）；已有指标保留');
    return [...matches.values()][0];
  }
  static async lookup(isbn,{lookupISBN,request,stopped=()=>false}){
    if(!isbn||this.isbn(isbn)!==isbn)throw Error('书籍需要有效 ISBN（10 或 13 位）才能查询 Semantic Scholar');
    if(typeof lookupISBN!=='function')throw Error('ISBN 书目查询环境未就绪');
    const book=this.catalogue(await lookupISBN(isbn),isbn);
    if(stopped())throw Error('已停止指标查询');
    const params=new URLSearchParams({query:book.title.replace(/[-‐‑–—]/g,' '),year:book.year,publicationTypes:'Book',limit:'100',fields:'title,year,authors,publicationTypes,citationCount,influentialCitationCount'});
    const response=await request('https://api.semanticscholar.org/graph/v1/paper/search?'+params);
    return {book,paper:this.select(book,response)};
  }
}
module.exports=KnowledgeLibraryBookMetrics;
