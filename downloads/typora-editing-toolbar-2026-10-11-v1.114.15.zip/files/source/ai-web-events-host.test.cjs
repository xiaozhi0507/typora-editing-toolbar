const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
function fixture(){let clock=10000;const box={window:{addEventListener(){}},URL,Date:{now:()=>clock},ETAIWebChatFormat:{markdown:html=>html},setTimeout,clearTimeout};vm.createContext(box);vm.runInContext(fs.readFileSync(require.resolve('./ai-web-chat-browser.js'),'utf8')+';globalThis.B=EditingToolbarWebChatBrowser',box);const b=new box.B({}),url='https://chatgpt.com/c/c1',base={url,userCount:0,answerCount:0};let disposed=0,reads=0;b.armEvents=async()=>({id:'task',revision:0});b.events=async(action)=>{assert.equal(action,'dispose');disposed++;};b.call=async()=>{reads++;return {url,lastUser:'Question',lastUserId:'u1',userCount:1,answerCount:1,answerId:'a1',replyAfterUser:true,complete:true,busy:false,answerHTML:'<p>Answer</p>'};};const run=extra=>b.receive({text:'Question',base,onText(){},onProgress(){},onBinding(){},...extra});return {b,run,tick:ms=>clock+=ms,now:()=>clock,disposed:()=>disposed,reads:()=>reads};}
test('semantic finish still waits for final DOM and delayed file link reconciliation',async()=>{
 const f=fixture(),{b}=f;let ticks=0,texts=[];b.waitEvents=async()=>{f.tick(180);ticks++;return {revision:ticks,supported:true,text:'Answer [Download](sandbox:/mnt/data/result.zip)',messageId:'a1',conversationId:'c1',completed:true};};const read=b.call;b.call=async()=>({...await read(),answerHTML:ticks>=5?'<p>Answer <a href="#et-web-file/result.zip">result.zip</a></p>':'<p>Answer</p>'});const r=await f.run({onText:t=>texts.push(t)});assert.match(r.text,/et-web-file/);assert.equal(ticks,6);assert.equal(f.disposed(),1);assert.equal(b.timings.fileLinksReadyMs>=0,true);
});
test('event wake returns final text without fixed 500ms polling and reconciles changed Markdown',async()=>{
 const f=fixture();let ticks=0;f.b.waitEvents=async()=>{f.tick(180);return {revision:++ticks,supported:true,text:'Answer',messageId:'a1',conversationId:'c1',completed:true};};assert.equal((await f.run()).text,'<p>Answer</p>');assert.equal(ticks,2);assert.equal(f.now()-10000,360);assert.equal(f.disposed(),1);
});
test('DOM-only fallback retains the longer settle window for late file cards',async()=>{
 const f=fixture();let ticks=0;f.b.waitEvents=async()=>{f.tick(180);return {revision:++ticks};};const read=f.b.call;f.b.call=async()=>({...await read(),answerHTML:ticks>=5?'<p>Answer <a href="#et-web-file/late.zip">late.zip</a></p>':'<p>Answer</p>'});const r=await f.run();assert.match(r.text,/late.zip/);assert.ok(ticks>=11);
});
test('public stream updates reuse the verified unchanged DOM until a mutation or health check',async()=>{
 const f=fixture();let tick=0,rendered=0;f.b.waitEvents=async()=>{f.tick(180);return {revision:++tick,domRevision:tick<15?1:2,url:'https://chatgpt.com/c/c1',supported:true,text:'Answer '+tick,messageId:'a1',conversationId:'c1',completed:tick>=15};};const read=f.b.call;f.b.call=async()=>({...await read(),complete:tick>=15,busy:tick<15});await f.run({onText(){rendered++;}});assert.ok(rendered>=15);assert.ok(f.reads()<=5,'stream fragments should not re-scrape unchanged DOM');
});
test('wrong public stream conversation never replaces the bound DOM answer',async()=>{
 const f=fixture(),texts=[];f.b.waitEvents=async()=>{f.tick(180);return {revision:1,supported:true,text:'Wrong private reply',conversationId:'other',completed:true};};await f.run({onText:t=>texts.push(t)});assert.deepEqual(texts,['<p>Answer</p>']);
});
test('changing identity or cancelling reception disposes watcher without calling send',async()=>{
 const f=fixture();f.b.armEvents=async()=>({id:'task',revision:0,scope:'A'});f.b.scope=async()=> 'B';f.b.waitEvents=async()=>({scopeChanged:true});await assert.rejects(f.run(),/登录身份/);assert.equal(f.disposed(),1);assert.equal(f.reads(),0);
 const c=fixture();c.b.waitEvents=async()=>{throw Object.assign(Error('cancel'),{name:'AbortError'});};await assert.rejects(c.run(),e=>e.name==='AbortError');assert.equal(c.disposed(),1);
});


test('matched final public stream finishes a rendered answer even without a hover action bar',async()=>{
 const f=fixture();let ticks=0;f.b.waitEvents=async()=>{f.tick(180);return {revision:++ticks,supported:true,text:'Answer',messageId:'a1',conversationId:'c1',completed:true};};const read=f.b.call;f.b.call=async()=>({...await read(),complete:false});assert.equal((await f.run()).text,'<p>Answer</p>');assert.equal(ticks,2);assert.equal(f.disposed(),1);
});

test('different or missing message identity cannot use stream completion to finish the DOM',async()=>{
 for(const id of ['other','']){const f=fixture();let ticks=0;f.b.waitEvents=async()=>{f.tick(180);if(++ticks>4)throw Object.assign(Error('cancel'),{name:'AbortError'});return {revision:ticks,supported:true,text:'Answer',messageId:'a1',conversationId:'c1',completed:true};};const read=f.b.call;f.b.call=async()=>({...await read(),answerId:id,complete:false});await assert.rejects(f.run(),e=>e.name==='AbortError');assert.equal(f.disposed(),1);}
});
