'use strict';

// Node HTTPS does not inherit Windows browser proxy settings. Resolve only the
// official service origin; OAuth codes and tokens never enter the resolver.
class PluginNetwork {
 constructor(req,{resolveProxy}={}){this.req=req;this.resolveProxy=resolveProxy||this.systemProxy.bind(this);this.cache=new Map();}
 invalidate(){this.cache.clear();}
 static supported(version){const [major,minor]=version.split('.').map(Number);return major>=25||major===24&&minor>=5||major===22&&minor>=21;}
 static validate(proxy){let u;try{u=new URL(proxy);}catch{throw Error('代理地址无效，请检查网络代理设置');}if(!['http:','https:'].includes(u.protocol)||u.pathname!=='/'||u.search||u.hash)throw Error('插件登录需要 HTTP(S) 代理，请检查系统或环境代理设置');return u.href;}
 async agent(url,signal){
  if(signal?.aborted)throw Object.assign(Error('已取消插件请求'),{name:'AbortError'});
  const process=this.req('process'),env=process.env,explicit=env.https_proxy||env.HTTPS_PROXY||env.http_proxy||env.HTTP_PROXY||env.all_proxy||env.ALL_PROXY;
  let proxyEnv;
  if(explicit)proxyEnv={HTTPS_PROXY:PluginNetwork.validate(explicit),NO_PROXY:env.no_proxy??env.NO_PROXY??''};
  else if(process.platform==='win32'){
   const origin=new URL(url).origin,cached=this.cache.get(origin);let proxy;
   if(cached&&cached.until>Date.now())proxy=cached.proxy;
   else {proxy=await this.resolveProxy(origin,signal);if(signal?.aborted)throw Object.assign(Error('已取消插件请求'),{name:'AbortError'});this.cache.set(origin,{proxy,until:Date.now()+30000});}
   if(proxy)proxyEnv={HTTPS_PROXY:PluginNetwork.validate(proxy),NO_PROXY:env.no_proxy??env.NO_PROXY??''};
  }
  if(proxyEnv&&!PluginNetwork.supported(process.versions.node))throw Error('当前 Typora 的网络运行时不支持系统代理，请升级 Typora 后重试');
  // Supplying an empty proxyEnv also isolates this request from global agents.
  return new (this.req('https').Agent)({proxyEnv:proxyEnv||{},keepAlive:false});
 }
 systemProxy(origin,signal){
  const script="$ErrorActionPreference='Stop';try{$u=[Uri][Console]::In.ReadToEnd();$p=[Net.WebRequest]::GetSystemWebProxy();$v=$p.GetProxy($u);if($v -and $v.AbsoluteUri -ne $u.AbsoluteUri){[Console]::Out.Write($v.AbsoluteUri)}}catch{exit 1}";
  return new Promise((resolve,reject)=>{
   let child,done=false;const finish=(error,value)=>{if(done)return;done=true;signal?.removeEventListener('abort',abort);error?reject(error):resolve(value);};
   const abort=()=>{child?.kill();finish(Object.assign(Error('已取消插件请求'),{name:'AbortError'}));};
   if(signal?.aborted)return abort();signal?.addEventListener('abort',abort,{once:true});
   try{child=this.req('child_process').execFile('powershell.exe',['-NoProfile','-NonInteractive','-Command',script],{windowsHide:true,timeout:8000,maxBuffer:8192},(error,out)=>finish(error?Error('无法读取系统代理设置，请检查代理软件后重试'):null,out?.trim()||null));child.stdin.on('error',()=>{});child.stdin.end(origin);}catch{finish(Error('无法读取系统代理设置，请检查代理软件后重试'));}
  });
 }
}
module.exports=PluginNetwork;
