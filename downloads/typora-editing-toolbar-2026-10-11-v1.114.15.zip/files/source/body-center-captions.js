// Batch formatting uses native model transactions, preserving editable Markdown.
class EditingToolbarCenterCaptions {
 constructor(toolbar){
  this.toolbar=toolbar;const menu=document.getElementById('context-menu');if(!menu)return;
  const li=document.createElement('li'),a=document.createElement('a');li.className='et-center-context';li.dataset.key='et-center-captions';li.hidden=true;a.textContent='一键居中';a.setAttribute('role','menuitem');li.append(a);menu.prepend(li);
  li.addEventListener('mousedown',e=>{e.preventDefault();e.stopPropagation();});
  $(li).on('click.etCenterCaptions',e=>{e.preventDefault();e.stopImmediatePropagation();menu.classList.remove('show');if(this.contextFile===(File.bundle?.filePath||''))this.run();});
  const styleItem=document.createElement('li'),styleLink=document.createElement('a');styleItem.className='et-three-line-context';styleItem.dataset.key='et-three-line-table';styleItem.hidden=true;styleLink.setAttribute('role','menuitem');styleItem.append(styleLink);li.after(styleItem);
  styleItem.addEventListener('mousedown',e=>{e.preventDefault();e.stopPropagation();});
  $(styleItem).on('click.etCenterCaptions',e=>{e.preventDefault();e.stopImmediatePropagation();menu.classList.remove('show');const table=this.contextTable;if(this.contextFile!==(File.bundle?.filePath||'')||!this.enabled()||!table?.isConnected)return;try{const columns=this.toolbar.tableColumns;columns.setThreeLine(table,this.contextThreeLine);this.toolbar.citationPreview?.hide();this.notice(this.contextThreeLine?'已设为三线表，可按 Ctrl+Z 撤销。':'已恢复普通表格，可按 Ctrl+Z 撤销。');}catch(error){this.notice('表格样式未改变：'+error.message+'。');}});
  document.addEventListener('contextmenu',e=>{this.contextFile=File.bundle?.filePath||'';li.hidden=!document.getElementById('write')?.contains(e.target)||!this.enabled();this.contextTable=this.tableAt(e.target);styleItem.hidden=li.hidden||!this.contextTable;li.classList.toggle('hide',li.hidden);styleItem.classList.toggle('hide',styleItem.hidden);this.contextThreeLine=this.contextTable?!this.toolbar.tableColumns.isThreeLine(this.contextTable):true;styleLink.textContent=this.contextThreeLine?'设为三线表':'恢复普通表格';},true);
 }
 tableAt(target){
  const columns=this.toolbar.tableColumns;columns.switchFile();const direct=target.closest?.('figure[mdtype="table"]>table.md-table,figure[mdtype="table"]');if(direct){const table=direct.matches('table')?direct:direct.querySelector('table.md-table');if(columns.tables().includes(table))return table;}
  const block=target.closest?.('#write p[cid]');if(block&&this.caption(block)){const next=block.nextElementSibling;const table=next?.matches('figure[mdtype="table"]')?next.querySelector('table.md-table'):null;if(columns.tables().includes(table))return table;}
  return null;
 }
 enabled(){return !File.editor.sourceView?.inSourceMode&&!File.isLocked&&!File.bundle?.isLocked&&!File.isReadonlyMode&&!File.isFileLoading?.();}
 notice(text){this.toolbar._showToolbarNotice(text);}
 caption(block){
  if(block.closest('li,table,pre,.md-fences,.md-alert')||block.querySelector('img,.md-image,[md-inline="alert_text"]'))return false;
  const copy=block.cloneNode(true);copy.querySelectorAll('[md-inline="code"],[md-inline="inline_math"]').forEach(n=>n.replaceWith(document.createTextNode('\uFFFC')));copy.querySelectorAll('.md-meta,.md-content').forEach(n=>n.remove());const text=copy.textContent.trim();
  // Match a label at the start of a standalone paragraph, never an inline reference.
  const match=/^(图|表|Figure\.?|Fig\.?|Table)\s*([A-Z]?\d+(?:[.．\-–—]\d+)*[a-z]?|[一二三四五六七八九十百]+)(?=$|\s|[：:、.．\-–—(（\u3400-\u9fff])/i.exec(text);
  if(!match)return false;const tail=text.slice(match[0].length).trim();
  if(/^(?:中|所示|显示|表明|说明|可见|给出|为|是|的|和|与|以及|分别|可知|表示|展示|列出|shows?\b|illustrates?\b|presents?\b|lists?\b|is\b|are\b)/i.test(tail))return false;
  return true;
 }
 newId(Model){const n=new Model({type:'blockquote'}),id=n.cid;n.remove();return id;}
 imageSource(block){
  const images=[...block.querySelectorAll('.md-image')].filter(n=>n.querySelector(':scope>img'));if(!images.length)return null;
  const withoutImages=element=>{const copy=element.cloneNode(true);copy.querySelectorAll('.md-image,.md-meta,.md-content').forEach(n=>n.remove());return copy.textContent.trim();};
  if(!withoutImages(block))return{...this.toolbar._alignedBlockSource(block,'center',0),images:images.length};
  const raw=n=>n.nodeType===1&&typeof n.rawText==='function'?n.rawText(true):n.textContent||'',source=raw(block),targets=new Set();
  for(const image of images){
   // Preserve ordinary text alignment; give each inline image its own full-width line.
   let centered=false;for(let p=image.parentElement;p&&p!==block;p=p.parentElement){const info=this.toolbar._alignmentTag(p);if(info?.tag.style.textAlign==='center'){centered=true;break;}}
   if(centered)continue;const link=image.closest('[md-inline="link"]');targets.add(link&&block.contains(link)&&!withoutImages(link)?link:image);
  }
  const edits=[...targets].map(target=>{let start=0;for(let n=target;n!==block;n=n.parentNode){if(!n?.parentNode)throw Error('图片正在更新');for(let p=n.previousSibling;p;p=p.previousSibling)start+=raw(p).length;}
   const original=raw(target);if(source.slice(start,start+original.length)!==original)throw Error('图片源码正在更新');return{start,end:start+original.length,text:this.toolbar._alignedBlockSource(target,'center',0).text};
  }).sort((a,b)=>a.start-b.start);
  let text='',position=0;for(const edit of edits){if(edit.start<position)throw Error('图片选区重叠');text+=source.slice(position,edit.start)+edit.text;position=edit.end;}text+=source.slice(position);
  const mapOffset=offset=>{let delta=0;for(const edit of edits){if(offset<edit.start)break;if(offset<=edit.end)return edit.start+delta+Math.min(offset-edit.start,edit.text.length);delta+=edit.text.length-(edit.end-edit.start);}return offset+delta;};
  return{text,mapOffset,images:images.length};
 }
 split(json,changes,Model,unquote,tableAlignments){
  const change=changes.get(json.id);if(change){json.content.text=change.text;return[json];}
  if(json.content.type!=='blockquote'){
   if(['table','table_row'].includes(json.content.type)){
    const affected=n=>changes.has(n.id)||(n.children||[]).some(affected);
    // Typora serializes untouched tables from userText; invalidate that cache
    // inside the same undo snapshot when a cell image gains an alignment span.
    if(json.content.type==='table'){
     if(affected(json)||tableAlignments.has(json.id))delete json.content.userText;
     const count=tableAlignments.get(json.id);if(count){
      json.content.align=Array(count).fill('center');
      json.content.alignText=Array.from({length:count},(_,i)=>':'+('-'.repeat(Math.max(3,(json.content.alignText?.[i]?.match(/-/g)||[]).length)))+':');
     }
    }
    json.children=json.children.flatMap(child=>this.split(child,changes,Model,unquote,tableAlignments));
   }
   return[json];
  }
  const parts=json.children.flatMap(child=>this.split(child,changes,Model,unquote,tableAlignments));
  if(!parts.some(p=>unquote.has(p.id)))return[{...json,children:parts}];
  const result=[];let group=[],used=false;
  const flush=()=>{if(!group.length)return;const q={...json,content:{...json.content},id:used?this.newId(Model):json.id,children:group};delete q.content.userIndent;result.push(q);used=true;group=[];};
  for(const part of parts){if(unquote.has(part.id)){flush();result.push(part);}else group.push(part);}flush();return result;
 }
 relate(nodes,parent,before=null,after=null){nodes.forEach((n,i)=>{n.relation={parent_id:parent,before_id:i?nodes[i-1].id:before,after_id:i+1<nodes.length?nodes[i+1].id:after};n.is_top=!parent;this.relate(n.children||[],n.id);});}
 run(){
  if(!this.enabled())return;const editor=File.editor,columns=this.toolbar.tableColumns,write=document.getElementById('write');
  editor.undo.endSnap(true);this.toolbar.readingPosition?.cancelRestore();columns.finish(true);columns.switchFile();
  const changes=new Map(),captions=new Set(),roots=new Map(),tableAlignments=new Map(),changedCellTables=new Set();let imageCount=0;
  const addRoot=node=>{let root=node;while(['blockquote','table_row','table'].includes(root.get('parent')?.get('type')))root=root.get('parent');roots.set(root.cid,root);};
  try{
   for(const block of write.querySelectorAll('p[cid],h1[cid],h2[cid],h3[cid],h4[cid],h5[cid],h6[cid],.td-span[cid]')){
    const caption=this.caption(block),layout=block.matches('.td-span')?this.toolbar._getBlockLayout(block):null;
    // Existing toolbar paragraph wrappers can otherwise override native column alignment.
    const result=caption||layout?.alignment&&layout.alignment!=='center'?this.toolbar._alignedBlockSource(block,'center',0):this.imageSource(block);if(!result)continue;
    const node=editor.getNode(block.getAttribute('cid'));if(!node||block.rawText?.(true)!==node.get('text'))throw Error('段落正在更新');
    if(result.text===node.get('text')&&!(caption&&block.closest('blockquote')))continue;
    changes.set(node.cid,result);if(caption)captions.add(node.cid);else imageCount+=result.images||0;addRoot(node);
    const table=block.closest('figure[mdtype="table"]');if(table)changedCellTables.add(table.getAttribute('cid'));
   }
   for(const table of columns.tables()){
    const node=editor.getNode(table.parentElement.getAttribute('cid')),count=table.rows[0]?.cells.length||0,align=node?.get('align')||[];
    if(node&&count&&Array.from({length:count},(_,i)=>align[i]).some(a=>a!=='center')){tableAlignments.set(node.cid,count);addRoot(node);}
   }
   if(columns.readonly&&columns.tables().length)throw Error('正文表格设置无法读取，请先检查设置文件');
  }catch(error){this.notice('暂未居中：'+error.message+'。');return;}
  const cursor=editor.selection.buildUndo(),command={undo:cursor?[cursor]:[],redo:[]},scroll=document.querySelector('content'),top=scroll?.scrollTop;
  editor.brush.pause(true);
  try{
   for(const root of roots.values()){
    const original=root.storeToJson(),json=JSON.parse(JSON.stringify(original)),transformed=this.split(json,changes,root.constructor,captions,tableAlignments);
    if(root.get('type')!=='blockquote'){
     const redo={type:'replace',id:root.cid,json:transformed[0]};command.undo.push(editor.undo.buildReplaceUndo(root));editor.undo.exeCommand(redo);command.redo.push(redo);continue;
    }
    // Read boundaries from the live tree: adjacent quotes may already have split.
    const before=root.get('before')?.cid||null,after=root.get('after')?.cid||null,parent=root.get('parent')?.cid||null;
    this.relate(transformed,parent,before,after);this.relate([original],parent,before,after);
    const remove={type:'remove',idArray:[root.cid]},insert={type:'insert',json:transformed,before,after};
    command.undo.push({type:'insert',json:[original],before,after},{type:'remove',idArray:transformed.map(n=>n.id)});
    editor.undo.exeCommand(remove);editor.undo.exeCommand(insert);command.redo.push(remove,insert);
   }
   columns.scan();const centeredTables=new Set([...tableAlignments.keys(),...changedCellTables]);
   for(const table of columns.tables()){
    const desc=columns.describe(table);let record=columns.find(table,desc);if(record?.alignment==='center')continue;
    if(!record){record={id:columns.store._id(),...desc,widths:[]};columns.records.push(record);columns.bindings.set(table.parentElement.getAttribute('cid'),record);}
    const make=alignment=>({type:'et-table-alignment',file:columns.file,id:record.id,alignment});command.undo.push(make(record.alignment||null));const redo=make('center');editor.undo.exeCommand(redo);command.redo.push(redo);centeredTables.add(table.parentElement.getAttribute('cid'));
   }
   if(!command.redo.length){this.notice('未发现需要调整的图片、图名、表名或表格。');return;}
   if(cursor){const mapped={...cursor};for(const [field,id] of [['start',cursor.startId||cursor.id],['end',cursor.endId||cursor.id]])if(changes.has(id)&&Number.isFinite(mapped[field]))mapped[field]=changes.get(id).mapOffset(mapped[field]);editor.undo.exeCommand(mapped);command.redo.push(mapped);}
   command.cursorOnly=!roots.size;editor.undo.register(command);editor.refresh();columns.scan();if(scroll)scroll.scrollTop=top;
   this.notice('已居中 '+imageCount+' 张图片、'+captions.size+' 个图名/表名、'+centeredTables.size+' 个表格，可按 Ctrl+Z 撤销。');
  }catch(error){for(const undo of command.undo.slice().reverse())editor.undo.exeCommand(undo);editor.refresh();columns.scan();console.error('[EditingToolbar] Center captions rolled back',error);this.notice('居中未完成，已恢复原文。');}
  finally{editor.brush.resume();}
 }
}
