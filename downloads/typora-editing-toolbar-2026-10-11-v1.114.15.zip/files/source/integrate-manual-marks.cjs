const fs=require('node:fs'),path=require('node:path');
module.exports=code=>{
 const replace=(a,b)=>{if(!code.includes(a))throw Error('Missing manual mark integration '+a.slice(0,100));code=code.replace(a,b);};
 const icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h12v18l-6-4-6 4Z"/></svg>';
 replace('const BUTTON_DEFINITIONS = {',`const BUTTON_DEFINITIONS = {\n"manual-mark":{icon:${JSON.stringify(icon)},title:'标注'},"add-mark":{icon:${JSON.stringify(icon)},title:'加入标注'},`);
 replace('this.documentNotes=new EditingToolbarDocumentNotes(this);','this.documentNotes=new EditingToolbarDocumentNotes(this);this.manualMarks=new EditingToolbarManualMarks(this);');
 code=code.replaceAll('[this.annotations,this.documentNotes]','[this.annotations,this.documentNotes,this.manualMarks]');
 replace('if(this.documentNotes?.panel.contains(document.activeElement))','if(this.documentNotes?.panel.contains(document.activeElement)||this.manualMarks?.panel.contains(document.activeElement))');
 replace('if (action === "document-note")','if (action === "manual-mark") {this.manualMarks?.open();return;}\n        if (action === "add-mark") {this.manualMarks?.addSelection();return;}\n        if (action === "document-note")');


 code=code.replaceAll('documentNotesRevision:1,','documentNotesRevision:1,manualMarksRevision:1,');
 replace('        const top = topLayout === "classic"',`        if(!input.manualMarksRevision){for(const ids of [compact.order,classic.buttons])if(!ids.includes('manual-mark')){const at=ids.indexOf('document-note');ids.splice(at>=0?at+1:ids.length,0,'manual-mark');}if(!floating.includes('add-mark'))floating.push('add-mark');}
        const top = topLayout === "classic"`);
 code=code.replaceAll('"document-note","more-menu"','"document-note","manual-mark","more-menu"');
 code=code.replaceAll('"annotation","document-note","fullscreen"','"annotation","document-note","manual-mark","fullscreen"');
 replace('"bg-color","annotation"],\n            size:', '"bg-color","annotation","add-mark"],\n            size:');
 replace('buttons:["undo","redo","annotation","document-note",','buttons:["undo","redo","annotation","document-note","manual-mark","add-mark",');
 // The floating toolbar adds the selected excerpt; the top toolbar opens the panel.
 // Use a separate allowlist so normalization does not discard add-mark on save/reload.
 replace('    _flatToolbarButtons(ids) {',`    _floatingToolbarActionIds() {
        return this._toolbarActionIds().map(id => id === "manual-mark" ? "add-mark" : id);
    }

    _flatFloatingToolbarButtons(ids) {
        const allowed = new Set(this._floatingToolbarActionIds());
        return [...new Set((Array.isArray(ids) ? ids : []).flatMap(id => this._menuActionIds(id).length ? this._menuActionIds(id) : [id])
            .map(id => id === "manual-mark" ? "add-mark" : id).filter(id => allowed.has(id)))];
    }

    _flatToolbarButtons(ids) {`);
 if(code.split('this._flatToolbarButtons(input.floating)').length!==3)throw Error('Missing floating mark normalization');
 code=code.replaceAll('this._flatToolbarButtons(input.floating)','this._flatFloatingToolbarButtons(input.floating)');
 replace('this._toolbarActionIds().filter(id=>!category||category.buttons.includes(id))','(key==="floating"?this._floatingToolbarActionIds():this._toolbarActionIds()).filter(id=>!category||category.buttons.includes(id))');
 replace("this.isDocumentNote?'笔记.md':'阅读笔记.md'","this.isManualMark?'标注摘录.md':this.isDocumentNote?'笔记.md':'阅读笔记.md'");
 replace(')).filter(item=>item.icon)',")).filter(item=>item.icon&&!['manual-mark','add-mark'].includes(item.id))");
 const pos=code.lastIndexOf('(function () {');if(pos<0)throw Error('Missing boot');
 return code.slice(0,pos)+fs.readFileSync(path.join(__dirname,'manual-marks.js'),'utf8')+'\n'+code.slice(pos);
};
