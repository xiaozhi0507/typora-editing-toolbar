'use strict';
// One in-flight xterm write, with only the newest sanitized snapshot waiting.
// A snapshot can shrink/change after secret redaction or bounded-output truncation.
class TerminalTranscript {
 constructor(term,{connected=()=>true,schedule=fn=>setTimeout(fn,16),cancel=clearTimeout}={}){
  this.term=term;this.connected=connected;this.schedule=schedule;this.cancel=cancel;
  this.shown='';this.latest='';this.waiters=[];this.busy=false;this.closed=false;this.timer=null;
 }
 update(text){if(this.closed)return;this.latest=String(text).replace(/\r?\n/g,'\r\n');this.queue();}
 queue(){if(this.closed||this.busy||this.timer!==null)return;if(this.shown===this.latest){this.settle();return;}this.timer=this.schedule(()=>{this.timer=null;this.write();});}
 write(){
  if(this.closed||!this.connected()){this.dispose();return;}
  if(this.shown===this.latest){this.settle();return;}
  const snapshot=this.latest,replace=!snapshot.startsWith(this.shown),buffer=this.term.buffer.active;
  const offset=buffer.baseY-buffer.viewportY;
  if(replace){this.restoreOffset??=offset;this.term.reset();this.shown='';}
  let end=Math.min(snapshot.length,this.shown.length+16384);
  // Do not split UTF-16 pairs or CRLF across writes.
  if(end<snapshot.length&&(/[\uD800-\uDBFF]/.test(snapshot[end-1])||snapshot[end-1]==='\r'))end--;
  const chunk=snapshot.slice(this.shown.length,end);this.busy=true;
  this.term.write(chunk,()=>{
   if(this.closed)return;this.shown=snapshot.slice(0,end);this.busy=false;
   if(end===snapshot.length&&this.restoreOffset!==undefined){if(this.restoreOffset>0)this.term.scrollLines(-this.restoreOffset);this.restoreOffset=undefined;}
   this.queue();
  });
 }
 settle(){for(const done of this.waiters.splice(0))done();}
 flush(){if(this.closed||!this.busy&&this.shown===this.latest)return Promise.resolve();return new Promise(resolve=>{this.waiters.push(resolve);this.queue();});}
 dispose(){if(this.closed)return;this.closed=true;if(this.timer!==null)this.cancel(this.timer);this.timer=null;this.settle();}
}
module.exports={TerminalTranscript};
