'use strict';
// Self-contained: serialized into the sandboxed website. Only public assistant
// text leaves this decoder; unsupported shapes fall back to the rendered page.
module.exports = function createWebStreamDecoder() {
  let line='', data=[], skipLF=false, frameSize=0, lastPath='', lastOp='append';
  let message=null, hidden=false, text='', completed=false, supported=true, ended=false, conversationId='';
  const limit=2*1024*1024;
  const publicMessage=()=>message?.author?.role==='assistant'&&(!message.channel||message.channel==='final')&&(!message.author?.recipient||message.author.recipient==='all')&&(!message.recipient||message.recipient==='all')&&!hidden;
  function update(){
    if(message?.metadata?.is_visually_hidden_from_conversation||message?.channel&&message.channel!=='final'||message?.metadata?.channel&&message.metadata.channel!=='final')hidden=true;
    if(!publicMessage()){text='';completed=false;return;}
    const parts=message.content?.parts;
    if(message.content?.content_type!=='text'||!Array.isArray(parts)||parts.some(p=>typeof p!=='string')){text='';completed=false;return;}
    text=parts.join('');if(text.length>limit)throw Error('Public reply too large');
    // A finished tool/commentary message is not the end of the assistant turn.
    completed=!!text&&message.end_turn===true;
  }
  function full(m){
    if(!m||typeof m!=='object')return;
    const same=message?.id&&message.id===m.id;
    hidden=same?hidden:false;message=JSON.parse(JSON.stringify(m));lastPath='';lastOp='append';update();
  }
  function patch(d){
    if(!d||typeof d!=='object')return;
    if(typeof d.conversation_id==='string')conversationId=d.conversation_id;
    if(d.message){full(d.message);return;}
    if(d.v?.message){if(typeof d.v.conversation_id==='string')conversationId=d.v.conversation_id;full(d.v.message);return;}
    if(d.o==='patch'&&Array.isArray(d.v)){for(const item of d.v)patch(item);return;}
    if(d.type)return; // Transport EOF/stream-complete signals alone are insufficient.
    const p=d.p===undefined?lastPath:d.p,o=d.o||lastOp;lastPath=p;lastOp=o;
    if(p==='/message'&&(o==='add'||o==='replace')){full(d.v);return;}
    if(!p?.startsWith('/message/')||!message)return;
    const keys=p.slice(9).split('/').map(k=>k.replace(/~1/g,'/').replace(/~0/g,'~'));
    if(keys.some(k=>['__proto__','prototype','constructor'].includes(k)))throw Error('Invalid stream path');
    if(!['content','author','recipient','channel','metadata','status','end_turn','id'].includes(keys[0]))return;
    let target=message;for(const k of keys.slice(0,-1)){if(!target[k]||typeof target[k]!=='object'){supported=false;return;}target=target[k];}
    const key=keys.at(-1);
    if(o==='append'&&typeof target[key]==='string'&&typeof d.v==='string')target[key]+=d.v;
    else if(o==='append'&&Array.isArray(target[key])&&Array.isArray(d.v))target[key].push(...d.v);
    else if(o==='replace'||o==='add')target[key]=d.v;
    else if(o==='remove')delete target[key];else {supported=false;return;}
    update();
  }
  function newline(){
    if(!line){const body=data.join('\n');data=[];frameSize=0;if(body&&body!=='[DONE]'){try{patch(JSON.parse(body));}catch{supported=false;}}}
    else if(line.startsWith('data:'))data.push(line.slice(5).replace(/^ /,''));
    line='';
  }
  return {
    push(chunk){if(ended)return;for(const c of String(chunk)){if(skipLF){skipLF=false;if(c==='\n')continue;}if(++frameSize>limit)throw Error('SSE frame too large');if(c==='\r'){newline();skipLF=true;}else if(c==='\n')newline();else line+=c;}},
    end(){ended=true;},
    state(){return {text:supported?text:'',messageId:message?.id||'',conversationId,completed:supported&&completed,ended,supported};}
  };
};
