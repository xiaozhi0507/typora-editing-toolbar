const fs=require('node:fs'),path=require('node:path');
module.exports=code=>{
 const replace=(from,to)=>{if(!code.includes(from))throw Error('Missing paragraph spacing integration: '+from);code=code.replace(from,to);};
 const icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4v16m-3-3 3 3 3-3M1 7l3-3 3 3M11 5h11M11 12h11M11 19h11"/></svg>';
 replace('const BUTTON_DEFINITIONS = {','const BUTTON_DEFINITIONS = {\n"paragraph-spacing":{icon:'+JSON.stringify(icon)+',title:"行段间距",spacingPicker:true},');
 replace('"align-justify","|","ordered-list"','"align-justify","|","paragraph-spacing","|","ordered-list"');
 replace('const top = topLayout === "classic"',`if(!input.paragraphSpacingRevision){const ids=compact.menus['paragraph-menu'];if(!ids.includes('paragraph-spacing'))ids.splice(Math.max(0,ids.indexOf('align-justify')+1),0,'paragraph-spacing');}
        const top = topLayout === "classic"`);
 code=code.replaceAll('return {version:1,layoutRevision:3,','return {version:1,layoutRevision:3,paragraphSpacingRevision:1,');
 replace('def.actions || def.menuItems || def.colorPicker || def.emojiPicker','def.actions || def.menuItems || def.colorPicker || def.emojiPicker || def.spacingPicker');
 replace('const content = def.colorPicker ?','const content = def.spacingPicker ? this.paragraphSpacing.buildPanel() : def.colorPicker ?');
 replace('} else if (definition.colorPicker) {','} else if (definition.spacingPicker) {\n                container.appendChild(this.paragraphSpacing.createControl(buttonId,definition,location));\n            } else if (definition.colorPicker) {');
 replace('definition.actions || definition.menuItems || definition.colorPicker || definition.emojiPicker','definition.actions || definition.menuItems || definition.colorPicker || definition.emojiPicker || definition.spacingPicker');
 replace('    _positionPopover(panel, location) {\n        if (panel.hidden || !panel.parentElement) return;\n        const padding = 8;', '    _positionPopover(panel, location) {\n        if (panel.hidden || !panel.parentElement) return;\n        const padding = panel.querySelector(".et-spacing-controls") ? 16 : 8;');
 // Arrow keys belong to the range/number controls; Tab cycles within this panel.
 replace('            if (event.target.closest?.(".et-top-chrome,input,textarea,select")) return;',`            if(event.target.closest?.('.et-spacing-controls')){
                event.stopImmediatePropagation();
                if(event.key==='Tab'){const panel=this.activePopover,controls=[...panel.querySelectorAll('button:not(:disabled),input')];const index=controls.indexOf(event.target);event.preventDefault();controls[(index+(event.shiftKey?-1:1)+controls.length)%controls.length]?.focus();}
                if(event.key==='Enter'&&event.target.matches('input[type=number]')){event.preventDefault();event.target.dispatchEvent(new Event('change'));}
                return;
            }
            if (event.target.closest?.(".et-top-chrome,input,textarea,select")) return;`);
 // Must exist before the toolbar renders a saved standalone spacing control.
 replace('        this.activePopover = null;','        this.activePopover = null;\n        this.paragraphSpacing = new EditingToolbarParagraphSpacing(this);');
 // Embedded note editors have their own layout; this action controls the main document.
 replace('controls:()=>this.toolbar.uiSettings.floating.map','controls:()=>this.toolbar.uiSettings.floating.filter(id=>id!=="paragraph-spacing").map');
 replace('definition:id=>BUTTON_DEFINITIONS[id],','definition:id=>id==="paragraph-menu"?{...BUTTON_DEFINITIONS[id],actions:BUTTON_DEFINITIONS[id].actions.filter(id=>id!=="paragraph-spacing")}:BUTTON_DEFINITIONS[id],');
 const pos=code.lastIndexOf('(function () {');if(pos<0)throw Error('Missing paragraph spacing boot');
 return code.slice(0,pos)+'const ETParagraphSpacing=(()=>{const module={exports:{}};'+fs.readFileSync(path.join(__dirname,'paragraph-spacing.cjs'),'utf8')+';return module.exports;})();\n'+fs.readFileSync(path.join(__dirname,'paragraph-spacing.js'),'utf8')+'\n'+code.slice(pos);
};
