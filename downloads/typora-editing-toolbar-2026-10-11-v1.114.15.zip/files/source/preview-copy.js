class EditingToolbarPreviewCopy {
    constructor(toolbar) {
        this.toolbar = toolbar;
        this.selector = '.et-citation-preview:not([hidden]),#et-annotation-preview:not([hidden])';
        window.addEventListener('contextmenu', event => {
            const popup = this.popupFor(event.target);
            if (!popup || event.target.closest?.('.et-preview-copy-menu')) return;
            event.preventDefault(); event.stopImmediatePropagation();
            this.open(popup, event);
        }, true);
        window.addEventListener('pointerdown', event => {
            if (this.menu?.contains(event.target)) return;
            this.close();
            const popup = this.popupFor(event.target);
            if (event.button === 2 && popup && this.selection(popup)) event.preventDefault();
        }, true);
        window.addEventListener('keydown', event => {
            if (this.menu && event.key === 'Escape') {
                event.preventDefault(); event.stopImmediatePropagation(); this.close(true); return;
            }
            if (!(event.ctrlKey || event.metaKey) || event.altKey || event.key.toLowerCase() !== 'c') return;
            const popup = this.popupFor(getSelection()?.anchorNode);
            const payload = popup && this.selection(popup);
            if (!payload) return;
            event.preventDefault(); event.stopImmediatePropagation();
            this.copy(payload); this.close();
        }, true);
        window.addEventListener('copy', event => {
            const popup = this.popupFor(getSelection()?.anchorNode);
            const payload = popup && this.selection(popup);
            if (!payload || !event.clipboardData) return;
            event.clipboardData.setData('text/plain', payload.text);
            event.clipboardData.setData('text/html', payload.html);
            event.preventDefault(); event.stopImmediatePropagation();
        }, true);
        window.addEventListener('resize', () => this.close());
        window.addEventListener('blur', () => this.close());
        document.addEventListener('scroll', event => {
            if (!this.popup?.contains(event.target)) this.close();
        }, true);
    }
    popupFor(node) {
        return (node?.nodeType === 1 ? node : node?.parentElement)?.closest?.(this.selector);
    }
    payload(fragment, text) {
        const wrapper = document.createElement('div');
        wrapper.append(fragment);
        wrapper.querySelectorAll('script,style,button,input,textarea,.et-preview-copy-menu,mjx-assistive-mml').forEach(node => node.remove());
        wrapper.querySelectorAll('*').forEach(node => {
            for (const attr of [...node.attributes]) {
                // MathJax SVG glyph references need their local definition IDs.
                const duplicateID = attr.name === 'id' && node.namespaceURI !== 'http://www.w3.org/2000/svg';
                if (/^on/i.test(attr.name) || duplicateID || ['contenteditable','tabindex'].includes(attr.name)) node.removeAttribute(attr.name);
            }
        });
        return { text: text.trim(), html: wrapper.innerHTML };
    }
    selection(popup) {
        const selection = getSelection();
        if (!selection?.rangeCount || selection.isCollapsed) return null;
        const range = selection.getRangeAt(0);
        if (!popup.contains(range.startContainer) || !popup.contains(range.endContainer)) return null;
        const text = selection.toString();
        return text.trim() ? this.payload(range.cloneContents(), text) : null;
    }
    content(popup, target) {
        const node = target.closest?.('table') || popup.querySelector('.et-citation-body,.et-preview-content');
        if (!node) return null;
        const text = node.tagName === 'TABLE'
            ? [...node.rows].map(row => [...row.cells].map(cell => cell.innerText.trim()).join('\t')).join('\n')
            : node.innerText;
        return text.trim() ? this.payload(node.cloneNode(true), text) : null;
    }
    copy(payload) {
        try { reqnode('electron').clipboard.write(payload); return true; }
        catch (error) { console.warn('[EditingToolbar] Preview copy failed:', error); return false; }
    }
    copyImage(image) {
        try {
            const url = new URL(image.src); if (url.protocol !== 'file:') return false;
            url.search = ''; url.hash = '';
            const {clipboard, nativeImage} = reqnode('electron');
            const data = nativeImage.createFromPath(reqnode('url').fileURLToPath(url));
            if (data.isEmpty()) return false;
            clipboard.writeImage(data); return true;
        } catch (error) { console.warn('[EditingToolbar] Preview image copy failed:', error); return false; }
    }
    open(popup, event) {
        this.close();
        const payload = this.selection(popup) || this.content(popup, event.target);
        const image = event.target.closest?.('img');
        const menu = document.createElement('div');
        menu.className = 'et-preview-copy-menu'; menu.setAttribute('role', 'menu'); menu.setAttribute('aria-label', '复制');
        const add = (label, shortcut, action, disabled) => {
            const button = document.createElement('button'); button.type = 'button'; button.setAttribute('role','menuitem');
            const name = document.createElement('span'); name.textContent = label;
            const key = document.createElement('span'); key.className = 'et-preview-copy-shortcut'; key.textContent = shortcut;
            button.append(name,key); button.disabled = disabled;
            button.addEventListener('mousedown', e => e.preventDefault());
            button.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); action(); this.close(); });
            menu.append(button);
        };
        add('复制', 'Ctrl+C', () => this.copy(payload), !payload);
        if (image?.src?.startsWith('file:')) add('复制图片', '', () => this.copyImage(image), false);
        menu.addEventListener('keydown', e => {
            if (!['ArrowDown','ArrowUp','Home','End'].includes(e.key)) return;
            e.preventDefault(); e.stopPropagation();
            const items = [...menu.querySelectorAll('button:not(:disabled)')];
            if (!items.length) return;
            let index = items.indexOf(document.activeElement);
            index = e.key === 'Home' ? 0 : e.key === 'End' ? items.length-1 : (index + (e.key === 'ArrowUp' ? -1 : 1) + items.length) % items.length;
            items[index].focus({preventScroll:true});
        });
        this.popup = popup; this.menu = menu; popup.append(menu);
        clearTimeout((popup.etCitationOwner||this.toolbar.citationPreview)?.leaveTimer);
        const rect = menu.getBoundingClientRect();
        const anchor = popup.getBoundingClientRect();
        const x = event.clientX || anchor.left + 12, y = event.clientY || anchor.top + 12;
        Object.assign(menu.style, {left: Math.max(8,Math.min(x,innerWidth-rect.width-8))+'px',top: Math.max(8,Math.min(y,innerHeight-rect.height-8))+'px'});
        menu.querySelector('button:not(:disabled)')?.focus({preventScroll:true});
        this.observer = new MutationObserver(() => { if (popup.hidden || !popup.isConnected) this.close(); });
        this.observer.observe(popup,{attributes:true,attributeFilter:['hidden']});
    }
    close(restoreFocus = false) {
        if ((restoreFocus || this.menu?.contains(document.activeElement)) && this.popup && !this.popup.hidden) {
            this.popup.tabIndex = -1; this.popup.focus({preventScroll:true});
        }
        this.observer?.disconnect(); this.observer = null;
        this.menu?.remove(); this.menu = null; this.popup = null;
    }
}
