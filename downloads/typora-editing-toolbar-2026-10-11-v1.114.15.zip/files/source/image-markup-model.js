// Image-space geometry shared by the live SVG and the exported annotation layer.
class ETImageMarkupModel {
 static points(op){
  if(op.kind==='pen')return op.points;
  const {x,y,x2,y2}=op,l=Math.min(x,x2),r=Math.max(x,x2),t=Math.min(y,y2),b=Math.max(y,y2),cx=(l+r)/2,cy=(t+b)/2,w=r-l,h=b-t;
  if(op.kind==='line')return [[x,y],[x2,y2]];
  if(op.kind==='arrow'){const a=Math.atan2(y2-y,x2-x),s=Math.min(Math.hypot(x2-x,y2-y)*.4,Math.max(12,op.size*4));return [[x,y],[x2,y2],[x2-s*Math.cos(a-.5),y2-s*Math.sin(a-.5)],[x2,y2],[x2-s*Math.cos(a+.5),y2-s*Math.sin(a+.5)]];}
  if(op.kind==='rect')return [[l,t],[r,t],[r,b],[l,b],[l,t]];
  if(op.kind==='triangle')return [[cx,t],[r,b],[l,b],[cx,t]];
  if(op.kind==='diamond')return [[cx,t],[r,cy],[cx,b],[l,cy],[cx,t]];
  if(op.kind==='star'){const p=Array.from({length:10},(_,i)=>{const a=-Math.PI/2+i*Math.PI/5,f=i%2?.43:1;return[cx+Math.cos(a)*w/2*f,cy+Math.sin(a)*h/2*f]});return [...p,p[0]];}
  if(op.kind==='ellipse')return Array.from({length:65},(_,i)=>{const a=i*Math.PI/32;return[cx+w/2*Math.cos(a),cy+h/2*Math.sin(a)]});
  if(op.kind==='heart')return Array.from({length:81},(_,i)=>{const a=i*Math.PI/40;return[cx+w/32*16*Math.sin(a)**3,t+h*(13-(13*Math.cos(a)-5*Math.cos(2*a)-2*Math.cos(3*a)-Math.cos(4*a)))/30]});
  return [];
 }
 static svg(op){
  const ns='http://www.w3.org/2000/svg',n=document.createElementNS(ns,op.kind==='text'?'text':'path');
  if(op.kind==='text'){
   n.setAttribute('fill',op.color);n.setAttribute('font-size',op.size);n.setAttribute('font-family','Arial, Microsoft YaHei, sans-serif');n.setAttribute('font-weight',op.bold?'700':'400');
   for(const [i,line]of op.text.split('\n').entries()){const s=document.createElementNS(ns,'tspan');s.setAttribute('x',op.x);s.setAttribute('y',op.y+op.size*(1+i*1.3));s.textContent=line||' ';n.append(s);}
  }else{
   const points=this.points(op),d=points.length===1?'M'+points[0].join(' ')+'l.01 0':points.map((p,i)=>(i?'L':'M')+p.join(' ')).join(' ');
   n.setAttribute('d',d);n.setAttribute('fill','none');n.setAttribute('stroke',op.color);n.setAttribute('stroke-width',op.size);n.setAttribute('stroke-linecap','round');n.setAttribute('stroke-linejoin','round');
  }
  return n;
 }
 static hit(op,p,radius){
  if(op.kind==='text'){const ctx=this.ctx||(this.ctx=document.createElement('canvas').getContext('2d'));ctx.font=(op.bold?'bold ':'')+op.size+'px Arial, Microsoft YaHei, sans-serif';const w=Math.max(...op.text.split('\n').map(s=>ctx.measureText(s).width)),h=op.text.split('\n').length*op.size*1.3;return p[0]>=op.x-radius&&p[0]<=op.x+w+radius&&p[1]>=op.y-radius&&p[1]<=op.y+h+radius;}
  const points=this.points(op),d=radius+op.size/2;
  if(points.length===1)return Math.hypot(p[0]-points[0][0],p[1]-points[0][1])<=d;
  return points.slice(1).some((b,i)=>{const a=points[i],dx=b[0]-a[0],dy=b[1]-a[1],f=Math.max(0,Math.min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy||1)));return Math.hypot(p[0]-a[0]-f*dx,p[1]-a[1]-f*dy)<=d;});
 }
}
