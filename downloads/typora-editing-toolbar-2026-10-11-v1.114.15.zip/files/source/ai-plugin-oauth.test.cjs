'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),http=require('http'),crypto=require('crypto');
const Plugins=require('./ai-plugins.cjs');
const base=path.join(process.env.USERPROFILE,'Downloads','codex-temp','plugin-oauth-tests');fs.mkdirSync(base,{recursive:true});
const githubConfig={client_id:'typora-test-client',client_secret:'test-client-secret'};
function setup(t,transport){const root=fs.mkdtempSync(path.join(base,'case-'));t.after(()=>fs.rmSync(root,{recursive:true,force:true}));return new Plugins(require,root,{protect:async(v,d)=>d?Buffer.from(v,'base64').toString():Buffer.from(v).toString('base64'),transport});}
function get(url,options={}){return new Promise((resolve,reject)=>{const r=http.request(url,options,res=>{let body='';res.on('data',b=>body+=b);res.on('end',()=>resolve({status:res.statusCode,body}));});r.on('error',reject);r.end();});}
function callback(url,extra=''){const u=new URL(url);return u.searchParams.get('redirect_uri')+'?state='+u.searchParams.get('state')+(extra||'&code=test-code');}
test('GitHub browser OAuth requests own client with PKCE, validates callback and saves only verified identity',async t=>{
 let auth,form;
 const store=setup(t,async(url,o)=>{if(url.includes('/access_token')){form=o.form;return {access_token:'ACCESS',scope:'read:user'};}assert.equal(url,'https://api.github.com/user');assert.equal(o.token,'ACCESS');return {login:'alice',id:123,avatar_url:'https://avatars.githubusercontent.com/u/123'};});
 await store.configureGitHub({...githubConfig,authorize_url:'https://invalid.test'});
 const result=await store.connectGitHubOAuth(async url=>{
  auth=new URL(url);assert.equal(auth.origin,'https://github.com');assert.equal(auth.pathname,'/login/oauth/authorize');assert.equal(auth.searchParams.get('client_id'),githubConfig.client_id);assert.equal(auth.searchParams.get('prompt'),'select_account');assert.equal(auth.searchParams.get('scope'),'read:user');
  assert.equal(auth.searchParams.get('code_challenge_method'),'S256');assert.ok(!url.includes(githubConfig.client_secret));
  const target=callback(url);
  assert.equal((await get(target.replace(/state=[^&]+/,'state=bad'))).status,400);
  assert.equal((await get(target+'&state=duplicate')).status,400);
  assert.equal((await get(target+'&code=duplicate')).status,400);
  assert.equal((await get(target,{headers:{Host:'other.test'}})).status,404);
  assert.equal((await get(target,{method:'POST'})).status,404);
  assert.equal((await get(target)).status,200);
 });
 assert.equal(result,'alice');assert.equal(form.code,'test-code');assert.equal(form.client_secret,githubConfig.client_secret);
 assert.equal(crypto.createHash('sha256').update(form.code_verifier).digest('base64url'),auth.searchParams.get('code_challenge'));
 assert.equal(form.redirect_uri,auth.searchParams.get('redirect_uri'));assert.equal(await store.token('github'),'ACCESS');
 assert.equal(store.accounts('github')[0].providerId,'123');assert.ok(!JSON.stringify(store.list()).includes('ACCESS'));
 assert.ok(!fs.readFileSync(path.join(store.dir,'accounts.dpapi'),'utf8').includes('ACCESS'));
 await assert.rejects(get(callback(auth.href)));
});
test('missing configuration does not open a generic login or create a connection',async t=>{
 const store=setup(t);let opened=false;
 await assert.rejects(store.connectGitHubOAuth(()=>opened=true),/先配置/);await assert.rejects(store.connectGoogle(()=>opened=true),/先导入/);
 assert.equal(opened,false);assert.equal(store.accounts('github').length,0);
 await assert.rejects(store.configureGitHub({client_id:'id',client_secret:'secret'}),/Client/);
});
test('OAuth denial, invalid token and identity failure leave prior account untouched',async t=>{
 const store=setup(t,async()=>({login:'prior',id:1}));await store.connectGitHub('prior-token');await store.configureGitHub(githubConfig);
 const before=fs.readFileSync(path.join(store.dir,'plugins.json'),'utf8');
 await assert.rejects(store.connectGitHubOAuth(url=>get(callback(url,'&error=access_denied'))),/授权已取消/);
 store.transport=async()=>({error:'bad_verification_code',error_description:'untrusted details'});
 await assert.rejects(store.connectGitHubOAuth(url=>get(callback(url))),/授权失败/);
 store.transport=async url=>url.includes('/access_token')?{access_token:'token'}:{};
 await assert.rejects(store.connectGitHubOAuth(url=>get(callback(url))),/账户验证失败/);
 assert.equal(await store.token('github'),'prior-token');assert.equal(fs.readFileSync(path.join(store.dir,'plugins.json'),'utf8'),before);
});
test('OAuth reconnect cannot replace the selected identity and same account preserves label',async t=>{
 let id=1;const store=setup(t,async url=>url.includes('/access_token')?{access_token:'token-'+id}:{login:'user-'+id,id});
 await store.configureGitHub(githubConfig);await store.connectGitHubOAuth(url=>get(callback(url)));const key=store.accountKey('github');await store.renameAccount('github','Work');
 id=2;await assert.rejects(store.connectGitHubOAuth(url=>get(callback(url)),{reconnectKey:key}),/原来的账户/);
 assert.equal(await store.token('github'),'token-1');id=1;await store.connectGitHubOAuth(url=>get(callback(url)),{reconnectKey:key});assert.equal(store.accounts('github').length,1);assert.equal(store.accounts('github')[0].label,'Work');
});
test('changing GitHub client invalidates OAuth connections but preserves legacy PAT accounts',async t=>{
 const store=setup(t,async()=>({login:'pat',id:1}));await store.connectGitHub('pat-token');await store.configureGitHub(githubConfig);
 store.transport=async url=>url.includes('/access_token')?{access_token:'oauth-token'}:{login:'oauth',id:2};
 await store.connectGitHubOAuth(url=>get(callback(url)));assert.equal(store.accounts('github').length,2);
 await store.configureGitHub({...githubConfig,client_id:'another-client'});assert.equal(store.accounts('github').length,1);assert.equal(await store.token('github'),'pat-token');
 await assert.rejects(store.connectGitHubOAuth(async url=>{await store.configureGitHub(githubConfig);await get(callback(url));}),/配置已更换/);
 assert.equal(store.accounts('github').length,1);
});
test('explicit private-repository choice is reflected in consent and checked after token exchange',async t=>{
 const store=setup(t,async()=>({access_token:'t',scope:'read:user'}));await store.configureGitHub({...githubConfig,private_repositories:true});
 await assert.rejects(store.connectGitHubOAuth(url=>{assert.equal(new URL(url).searchParams.get('scope'),'read:user repo');return get(callback(url));}),/私有仓库权限/);
 assert.equal(store.accounts('github').length,0);
});
test('cancellation and timeout close owned callback without saving an account',async t=>{
 const store=setup(t);await store.configureGitHub(githubConfig);let target;
 const controller=new AbortController();await assert.rejects(store.connectGitHubOAuth(url=>{target=callback(url);controller.abort();},{signal:controller.signal}),{name:'AbortError'});await assert.rejects(get(target));
 await assert.rejects(store.connectGitHubOAuth(url=>{target=callback(url);},{timeout:30}),/超时/);await assert.rejects(get(target));
 await assert.rejects(store.connectGitHubOAuth(()=>{throw Error('shell failed');}),/无法打开/);
 assert.equal(store.accounts('github').length,0);
});
test('login deadline also cancels token exchange and forbids late identity persistence',async t=>{
 const store=setup(t,async(url,{signal})=>new Promise((resolve,reject)=>{signal.addEventListener('abort',()=>reject(signal.reason),{once:true});}));
 await store.configureGitHub(githubConfig);await assert.rejects(store.connectGitHubOAuth(url=>get(callback(url)),{timeout:40}),/超时/);assert.equal(store.accounts('github').length,0);
});
test('expiring GitHub OAuth credentials refresh per account with no secret in metadata',async t=>{
 const used=[],store=setup(t,async(url,{form})=>{assert.equal(url,'https://github.com/login/oauth/access_token');assert.equal(form.client_secret,githubConfig.client_secret);assert.equal(form.grant_type,'refresh_token');used.push(form.refresh_token);return {access_token:'new-'+form.refresh_token,refresh_token:'rotated-'+form.refresh_token,expires_in:3600};});
 await store.configureGitHub(githubConfig);
 for(const n of ['a','b'])await store.saveAccount('github',{providerId:n,account:n},{authType:'oauth',client_id:githubConfig.client_id,access_token:'old',refresh_token:n,expiresAt:0});
 const [a,b]=store.accounts('github');assert.deepEqual(await Promise.all([store.token('github',undefined,a.key),store.token('github',undefined,b.key),store.token('github',undefined,a.key)]),['new-a','new-b','new-a']);assert.deepEqual(used.slice().sort(),['a','b']);
 assert.equal(store.list()[0].account,'b');assert.ok(!JSON.stringify(store.list()).includes(githubConfig.client_secret));await store.uninstall('github');assert.equal((await store.secrets()).githubConfig,undefined);
});
test('github.com transport permits only token form POST, never bearer tokens or other routes',t=>{
 const store=setup(t);
 for(const [url,options]of [['https://github.com/user',{}],['https://github.com/login/oauth/access_token',{}],['https://github.com/login/oauth/access_token',{token:'secret',form:{a:'b'}}],['https://github.com/login/oauth/access_token?x=1',{form:{a:'b'}}]])assert.throws(()=>store.request(url,options),/拒绝/);
});
