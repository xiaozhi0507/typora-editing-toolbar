class DocumentDiff {
  static lines(text){const rows=text.split('\n');if(rows.at(-1)==='')rows.pop();return rows;}
  static diff(before,after){
    const a=this.lines(before),b=this.lines(after),n=a.length,m=b.length,trace=[],v=new Map([[1,0]]);let work=0;
    for(let d=0;d<=n+m;d++){
      trace.push(new Map(v));
      for(let k=-d;k<=d;k+=2){
        if(++work>1000000)return this.number([...a.map(text=>({type:'delete',text})),...b.map(text=>({type:'add',text}))]);
        let x=k===-d||k!==d&&(v.get(k-1)??-1)<(v.get(k+1)??-1)?v.get(k+1)||0:(v.get(k-1)||0)+1,y=x-k;
        while(x<n&&y<m&&a[x]===b[y]){x++;y++;}v.set(k,x);
        if(x>=n&&y>=m){const rows=[];for(let depth=d;depth>=0;depth--){const prev=trace[depth],key=x-y,pk=key===-depth||key!==depth&&(prev.get(key-1)??-1)<(prev.get(key+1)??-1)?key+1:key-1,px=prev.get(pk)||0,py=px-pk;while(x>px&&y>py){rows.push({type:'same',text:a[--x]});y--;}if(depth){if(x===px)rows.push({type:'add',text:b[--y]});else rows.push({type:'delete',text:a[--x]});}}return this.number(rows.reverse());}
      }
    }
  }
  static number(rows){let old=0,next=0;return rows.map(r=>({...r,old:r.type==='add'?null:++old,next:r.type==='delete'?null:++next}));}
  static hunks(rows){const visible=new Set();rows.forEach((r,i)=>{if(r.type!=='same')for(let j=Math.max(0,i-3);j<=Math.min(rows.length-1,i+3);j++)visible.add(j);});const out=[];let previous=-1;for(const i of [...visible].sort((a,b)=>a-b)){if(i>previous+1)out.push({type:'gap',text:'⋯'});out.push(rows[i]);previous=i;}return out;}
}
module.exports=DocumentDiff;
