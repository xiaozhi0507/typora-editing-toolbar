'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os');
const Store=require('./knowledge-library-store.cjs'),Managed=require('./knowledge-library-managed.cjs'),Archive=require('./knowledge-library-archive.cjs'),Backup=require('./knowledge-library-backup.cjs'),Zip=require('fflate');
async function fixture(t){
  const root=await fs.mkdtemp(path.join(os.tmpdir(),'kb-backup-'));t.after(()=>fs.rm(root,{recursive:true,force:true}));
  const store=new Store(path.join(root,'library')),base=(await store.open()).data,destination=path.join(root,'drive');await fs.mkdir(destination);
  const folder=path.join(store.root,'文献'),md=path.join(folder,'论文.md');await fs.mkdir(folder+'/images',{recursive:true});
  await fs.writeFile(md,'# 论文\n![图片](images/plot.png)');await fs.writeFile(folder+'/images/plot.png',new Uint8Array([0,1,2,255]));
  await fs.mkdir(md+'.笔记',{recursive:true});await fs.writeFile(md+'.笔记/index.json','{"notes":[]}');
  const ref=store.fileRef(md);await store.commit(base,{...base,items:[{id:'one',type:'paper',title:'论文',status:'unread',files:[ref],tags:['test'],collections:[],related:[]}]});
  const make=(s=store,d=destination)=>new Backup(s,{Managed,Archive,Zip,destination:d});return {root,store,destination,folder,md,make,b:make()};
}
test('first backup verifies bytes; unchanged repeat writes no objects or new snapshot',async t=>{
  const x=await fixture(t),p=await x.b.plan();assert.equal(p.summary.copyFiles,3);const r=await x.b.run(p);assert.equal(r.copied,3);
  const before=await fs.stat(r.snapshot),again=await x.make().plan();assert.equal(again.summary.copyFiles,0);assert.equal(again.summary.unchanged,3);assert.equal((await x.b.run(again)).unchanged,true);
  assert.equal((await fs.stat(r.snapshot)).mtimeMs,before.mtimeMs);assert.equal((await fs.readdir(x.b.root+'/snapshots')).length,1);
});
test('one changed document copies one blob and preserves old snapshot for lossless restore',async t=>{
  const x=await fixture(t),original=await fs.readFile(x.md),first=await x.b.run(await x.b.plan());await fs.writeFile(x.md,'# 新正文\n![图片](images/plot.png)');
  const p=await x.b.plan();assert.equal(p.summary.modified,1);assert.equal(p.summary.copyFiles,1);await x.b.run(p);
  const target=new Store(x.root+'/restore');await target.open();const out=await x.make(target).exportSnapshot(first.snapshot,x.root),r=await new Archive(target,{Managed,Zip}).import(out.path);
  assert.deepEqual(await fs.readFile(target.resolveFile(r.data.items[0].files[0])),original);
  assert.deepEqual(await fs.readFile(path.join(path.dirname(target.resolveFile(r.data.items[0].files[0])),'images/plot.png')),Buffer.from([0,1,2,255]));
  assert.equal((await fs.readdir(x.b.root+'/snapshots')).length,2);
});
test('metadata-only edits publish snapshot without copying file contents',async t=>{
  const x=await fixture(t);await x.b.run(await x.b.plan());const base=(await x.store.read()).data,next=structuredClone(base);next.items[0].title='重命名';await x.store.commit(base,next);
  const plan=await x.b.plan();assert.equal(plan.summary.metadataChanged,true);assert.equal(plan.summary.copyFiles,0);const r=await x.b.run(plan);assert.equal(r.copied,0);assert.equal((await x.b.latest()).library.items[0].title,'重命名');
});
test('removed local items leave older file objects and snapshot recoverable',async t=>{
  const x=await fixture(t),r=await x.b.run(await x.b.plan()),old=await x.b.latest(),base=(await x.store.read()).data;await x.store.commit(base,{...base,items:[]});await fs.unlink(x.md);
  const p=await x.b.plan();assert.equal(p.summary.removed,3);await x.b.run(p);for(const f of old.files)assert.ok((await fs.stat(x.b.object(f.sha256))).isFile());
  assert.ok((await fs.stat((await x.b.exportSnapshot(r.snapshot,x.root)).path)).isFile());
});
test('cancelled copy leaves last successful snapshot unchanged and can resume verified objects',async t=>{
  const x=await fixture(t),before=await x.b.run(await x.b.plan());await fs.writeFile(x.md,'# changed');const p=await x.b.plan(),c=new AbortController();
  await assert.rejects(x.b.run(p,{signal:c.signal,onProgress:(text,stage)=>{if(stage==='copying')c.abort();}}),{name:'AbortError'});
  assert.equal((await x.b.latest()).packageId,p.previousId);assert.equal(await x.b.exists(x.b.root+'/backup.lock'),null);
  const r=await x.b.run(await x.b.plan());assert.equal(r.copied,1);assert.notEqual(r.snapshot,before.snapshot);
});
test('missing and corrupted backup blobs are detected and repaired, not silently skipped',async t=>{
  const x=await fixture(t);await x.b.run(await x.b.plan());const snapshot=await x.b.latest();await fs.unlink(x.b.object(snapshot.files[0].sha256));await fs.writeFile(x.b.object(snapshot.files[1].sha256),'corrupt');
  const p=await x.b.plan();assert.equal(p.summary.copyFiles,2);await x.b.run(p);assert.equal((await x.b.plan()).summary.copyFiles,0);
});
test('edited input after preview and concurrent library changes refuse stale plans',async t=>{
  const x=await fixture(t),p=await x.b.plan();await fs.writeFile(x.md,'new content');await assert.rejects(x.b.run(p),/变化/);
  const next=await x.b.plan(),base=(await x.store.read()).data;await x.store.commit(base,{...base,items:[]});await assert.rejects(x.b.run(next),/更新/);
  assert.equal(await x.b.exists(x.b.root+'/latest.json'),null);
});
test('concurrent destination updates and locks fail without replacing the committed snapshot',async t=>{
  const x=await fixture(t),p=await x.b.plan();await x.b.run(p);await assert.rejects(x.b.run(p),/其他窗口/);
  await fs.writeFile(x.b.root+'/backup.lock','locked');await assert.rejects(x.b.run(await x.b.plan()),/已有任务/);assert.equal(await fs.readFile(x.b.root+'/backup.lock','utf8'),'locked');
});
test('nested backup directories and symbolic links are refused',async t=>{
  const x=await fixture(t);await assert.rejects(x.make(x.store,x.store.root).plan(),/不能/);
  const link=x.root+'/linked-drive';await fs.symlink(x.destination,link,'junction');await assert.rejects(x.make(x.store,link).plan(),/链接/);
});
test('corrupted snapshots, missing source attachments and unsafe restore paths fail closed',async t=>{
  const x=await fixture(t),r=await x.b.run(await x.b.plan()),s=await x.b.latest();s.files[0].path='../escape';await fs.writeFile(r.snapshot,JSON.stringify(s));await assert.rejects(x.b.exportSnapshot(r.snapshot,x.root),/不安全/);
  await fs.unlink(x.folder+'/images/plot.png');await assert.rejects(x.b.plan(),/ENOENT/);
});
test('failure before committing latest preserves previous version; empty libraries are restorable',async t=>{
  const x=await fixture(t);await x.b.run(await x.b.plan());const base=(await x.store.read()).data;await x.store.commit(base,{...base,items:[]});const p=await x.b.plan(),original=x.b.atomic.bind(x.b);
  x.b.atomic=async(file,text)=>{if(file.endsWith('latest.json'))throw Error('disk unavailable');return original(file,text);};await assert.rejects(x.b.run(p),/disk unavailable/);assert.equal((await x.b.latest()).packageId,p.previousId);
  const fresh=x.make(),r=await fresh.run(await fresh.plan()),out=await fresh.exportSnapshot(r.snapshot,x.root),target=new Store(x.root+'/empty-restore');await target.open();assert.equal((await new Archive(target,{Managed,Zip}).import(out.path)).data.items.length,0);
});

test('dead process locks recover after restart while live process locks remain protected',async t=>{
 const x=await fixture(t);await x.b.mkdir(x.b.root);const actual=x.store.process;
 x.store.process={pid:actual.pid,kill:(pid)=>{if(pid===2147483000)throw Object.assign(Error('dead'),{code:'ESRCH'});return actual.kill(pid,0);}};
 await fs.writeFile(x.b.root+'/backup.lock',JSON.stringify({pid:2147483000}));const release=await x.b.lock();assert.equal(JSON.parse(await fs.readFile(x.b.root+'/backup.lock')).pid,actual.pid);
 await assert.rejects(x.b.lock(),/已有任务/);await release();assert.equal(await x.b.exists(x.b.root+'/backup.lock.recover'),null);
});

test('background metrics and reading caches do not invalidate captured files; newer metadata is backed up next time',async t=>{
 const x=await fixture(t),fingerprint=x.b.fingerprint.bind(x.b);let changed=false;
 x.b.fingerprint=async(file,options)=>{const result=await fingerprint(file,options);if(!changed&&file===x.md){changed=true;const data=(await x.store.read()).data,next=structuredClone(data);next.items[0].metrics={citations:{value:42}};next.items[0].last=Date.now();next.items[0].lastFile=next.items[0].files[0].id;await x.store.commit(data,next);}return result;};
 const first=await x.b.plan();await x.b.run(first);assert.equal((await x.b.latest()).library.items[0].metrics,undefined);
 const next=await x.b.plan();assert.equal(next.summary.metadataChanged,true);assert.equal(next.summary.copyFiles,0);await x.b.run(next);assert.equal((await x.b.latest()).library.items[0].metrics.citations.value,42);
});
test('title edits still invalidate the captured library and expose a rescan error code',async t=>{
 const x=await fixture(t),plan=await x.b.plan(),data=(await x.store.read()).data,next=structuredClone(data);next.items[0].title='真实修改';await x.store.commit(data,next);
 await assert.rejects(x.b.run(plan),{code:'BACKUP_SOURCE_CHANGED'});assert.equal(await x.b.exists(x.b.root+'/latest.json'),null);
});
