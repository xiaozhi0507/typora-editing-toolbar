'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),Usage=require('./ai-usage-page.cjs');
const snapshot=text=>({url:'https://chatgpt.com/#settings/Usage',usage:true,text});
test('explicit remaining/used quotas retain window labels and reset text',()=>{
 const r=Usage.parse(snapshot('Usage\n5 hour limit\n88% remaining\nResets at 20:00\nWeekly usage\nUsed 30%\nResets on Monday'));
 assert.equal(r.available,true);assert.deepEqual(r.metrics.map(x=>[x.label,x.remainingPercent,x.usedPercent]),[['5 hour limit',88,12],['Weekly usage',70,30]]);assert.equal(r.metrics[0].resetText,'Resets at 20:00');
 const cn=Usage.parse(snapshot('用量\n每 5 小时\n剩余 86.5%\n明天重置'));assert.equal(cn.metrics[0].remainingPercent,86.5);assert.equal(cn.metrics[0].label,'每 5 小时');
 assert.equal(Usage.parse(snapshot('Usage\nUsed 30%\n88%')).metrics.length,1,'a different naked percentage cannot borrow a labelled percentage');
});
test('naked percentages, budget controls, token counts and invalid values never become quota',()=>{
 for(const text of ['Usage\n50%','Usage\nSet maximum used 50%','Usage\n预算 已用 50%','Usage\n123456 tokens','Usage\n101% remaining','Usage\n-1% remaining','Usage\nUnused 50%','Usage\n积分 1200']){const r=Usage.parse(snapshot(text));assert.equal(r.available,false,text);assert.equal(r.metrics.length,0);}
});
test('Chinese settings screenshot yields weekly remaining quota with preceding reset, not app cap or credits',()=>{
 const result=Usage.parse(snapshot('使用情况\n套餐限额\n每周限额\n6 天 8 小时后重置\n剩余 84%\n额度\n剩余额度：62,491\n当前余额\n应用用量限制\nTypora AI 阅读助手\n30%'));
 assert.equal(result.available,true);assert.deepEqual(result.metrics,[{label:'每周限额',remainingPercent:84,usedPercent:16,resetText:'6 天 8 小时后重置',basis:'remaining'}]);
 assert.equal(Usage.parse(snapshot('应用用量限制\n每周限额\n剩余 30%')).available,false);
 assert.equal(Usage.parse(snapshot('剩余额度：62,491\n30%')).available,false);
});
test('separate windows keep their own reset labels regardless of label order',()=>{
 const result=Usage.parse(snapshot('Usage\n5 hour limit\nResets in 2 hours\nRemaining\n75%\nWeekly limit\nUsed 16%\nResets on Friday'));
 assert.deepEqual(result.metrics.map(m=>[m.label,m.remainingPercent,m.resetText]),[['5 hour limit',75,'Resets in 2 hours'],['Weekly limit',84,'Resets on Friday']]);
});
test('login, challenge, foreign origin and unrelated page cannot return a balance',()=>{
 assert.equal(Usage.parse({...snapshot('88% remaining'),login:true}).status,'login_required');
 assert.equal(Usage.parse({...snapshot('88% remaining'),challenge:true}).status,'verification_required');
 assert.equal(Usage.parse({...snapshot('88% remaining'),url:'https://evil.example/settings/usage'}).available,false);
 assert.equal(Usage.parse({...snapshot('88% remaining'),usage:false}).available,false);
 for(const url of ['https://chatgpt.com','https://auth.openai.com/log-in','about:blank'])assert.equal(Usage.allowed(url),true);
 for(const url of ['http://chatgpt.com','https://chatgpt.com.evil.example','file:///C:/x','https://user:pass@chatgpt.com'])assert.equal(Usage.allowed(url),false);
});
function browser(){const stored=new Map(),context={ETAIUsagePage:Usage,URL,Date,setTimeout,clearTimeout,window:{addEventListener(){}},reqnode:require,localStorage:{getItem:k=>stored.get(k),setItem:(k,v)=>stored.set(k,v)}};const C=vm.runInNewContext(fs.readFileSync(__dirname+'/ai-usage-browser.js','utf8')+';EditingToolbarAIUsageBrowser',context);return {ui:new C({}),stored};}
test('official login can appear at the home URL inside main without exposing form values',()=>{
 const context={document:{title:'ChatGPT',body:{innerText:'ChatGPT\n登录或注册\n使用 Google 账户继续'},querySelector:s=>['main','input[type="email"]'].includes(s)?{}:null},location:{href:'https://chatgpt.com/?mweb_fallback=1',origin:'https://chatgpt.com'}};
 const result=vm.runInNewContext('('+Usage.snapshot.toString().replace(/^snapshot\(/,'function(')+')()',context);
 assert.equal(result.login,true);assert.equal(result.usage,false);assert.equal(result.text,'');
});
test('first explicit refresh uses the shared login without a separate usage-login marker',async()=>{
 const {ui,stored}=browser();let mounts=0;ui.mount=()=>{mounts++;return ui.active={panel:{remove(){}}};};ui.inspect=async()=>snapshot('每周限额\n剩余 52%');const result=await ui.refresh({chatgptAccount:'a'});assert.equal(result.metrics[0].remainingPercent,52);assert.equal(mounts,1);assert.equal(stored.size,0);
});
test('manual background refresh disposes guest after success or failure and never opens login UI',async()=>{
 const {ui}=browser(),profile={chatgptAccount:'a'};let removed=0,mounts=0;ui.mount=(_p,visible)=>{assert.equal(visible,false);mounts++;return ui.active={ready:true,panel:{remove(){removed++;}}};};ui.inspect=async()=>snapshot('用量\n每周\n已使用 10%');
 const result=await ui.refresh(profile);assert.equal(result.metrics[0].remainingPercent,90);assert.equal(mounts,1);assert.equal(removed,1);assert.equal(ui.active,null);
 ui.inspect=async()=>({...snapshot(''),login:true});assert.equal((await ui.refresh(profile)).status,'login_required');assert.equal(removed,2);
 ui.mount=()=>ui.active={failed:true,panel:{remove(){removed++;}}};ui.inspect=async()=>{throw Error('guest unavailable');};await assert.rejects(ui.refresh(profile),/加载失败/);assert.equal(removed,3);
});
test('readable quota is immediate even while a resource navigation left ready false',async()=>{
 const {ui}=browser();ui.active={ready:false};let inspections=0;ui.inspect=async()=>{inspections++;return snapshot('每周限额\n6 天后重置\n剩余 84%');};
 const start=Date.now(),r=await ui.readPage(ui.active);assert.equal(r.metrics[0].remainingPercent,84);assert.equal(inspections,1);assert.ok(Date.now()-start<500);assert.equal(ui.active.authenticated,true);
});
test('failed visible read keeps page and session; success completes same request exactly once',async()=>{
 const {ui,stored}=browser(),profile={chatgptAccount:'a'};let resolved=0,removed=0;
 const state=ui.active={profile,authenticated:true,read:{disabled:false},message:{textContent:''},panel:{remove(){removed++;}},resolve(){resolved++;}};
 ui.readPage=async()=>ui.result('unavailable','暂未显示百分比');await ui.finish(state);
 assert.equal(ui.active,state);assert.equal(removed,0);assert.equal(resolved,0);assert.equal(state.read.disabled,false);assert.equal(state.message.textContent,'暂未显示百分比');assert.equal(stored.size,0);
 ui.readPage=async()=>Usage.parse(snapshot('每周限额\n剩余 84%'));await ui.finish(state);assert.equal(removed,1);assert.equal(resolved,1);assert.equal(ui.active,null);
});
test('closing visible login resolves pending request and cancels outstanding local checks',()=>{
 const {ui}=browser();let result,removed=0,cancelled=0;ui.active={panel:{remove(){removed++;}},cancelRead(){cancelled++;},resolve:r=>result=r};ui.close();assert.equal(result.status,'cancelled');assert.equal(removed,1);assert.equal(cancelled,1);assert.equal(ui.active,null);
});


function observeFixture(initial,timeout=5000){
 let current=initial,now=0,id=0,checks=0,mutate,disconnected=false;const timers=new Map(),listeners=new Map();
 const context={document:{},location:{href:initial.url},window:{addEventListener:(k,f)=>listeners.set(k,f),removeEventListener:k=>listeners.delete(k)},MutationObserver:class{constructor(f){mutate=f;}observe(){}disconnect(){disconnected=true;}},setTimeout:(f,ms)=>{timers.set(++id,{f,at:now+ms});return id;},clearTimeout:i=>timers.delete(i),snapshot:()=>{checks++;return current;},parse:Usage.parse,timeout};
 const result=vm.runInNewContext('('+Usage.observe.toString().replace(/^observe\(/,'function(')+')(snapshot,parse,timeout)',context);
 const advance=ms=>{const end=now+ms;for(;;){const next=[...timers].filter(([,t])=>t.at<=end).sort((a,b)=>a[1].at-b[1].at)[0];if(!next)break;now=next[1].at;timers.delete(next[0]);next[1].f();}now=end;};
 return {result,advance,update:x=>{current=x;mutate();},leave:()=>listeners.get('pagehide')?.(),stats:()=>({checks,disconnected,timers:timers.size,listeners:listeners.size})};
}
test('guest observer responds to quota DOM changes without polling and releases every observer/timer',async()=>{
 const f=observeFixture({url:Usage.url,usage:false,text:''});f.advance(600);assert.equal(f.stats().checks,1,'idle guest does not keep inspecting');
 f.update(snapshot('每周限额\n剩余 81%'));f.advance(16);assert.equal(Usage.parse(await f.result).metrics[0].remainingPercent,81);assert.deepEqual(f.stats(),{checks:2,disconnected:true,timers:0,listeners:0});
});
test('already visible quota, login and challenge resolve the guest observation immediately',async()=>{
 for(const data of [snapshot('每周限额\n剩余 84%'),{...snapshot(''),login:true},{...snapshot(''),challenge:true}]){const f=observeFixture(data);assert.equal(await f.result,data);assert.equal(f.stats().checks,1);assert.equal(f.stats().timers,0);assert.equal(f.stats().disconnected,true);}
});
test('guest observation bounds unsupported pages and navigation without leaving background checks',async()=>{
 const pending=observeFixture({url:Usage.url,usage:false,text:''},200);pending.advance(200);assert.equal((await pending.result).usage,false);assert.equal(pending.stats().timers,0);
 const noQuota=observeFixture(snapshot('每周限额'));noQuota.advance(3000);assert.equal(Usage.parse(await noQuota.result).available,false);assert.equal(noQuota.stats().disconnected,true);
 const navigating=observeFixture({url:Usage.url,usage:false,text:''});navigating.leave();assert.equal((await navigating.result).usage,false);assert.equal(navigating.stats().timers,0);assert.equal(navigating.stats().listeners,0);
});
test('quota arriving during the bounded unsupported-page wait wins over the grace timeout',async()=>{
 const f=observeFixture(snapshot('每周限额'));f.advance(1500);f.update(snapshot('每周限额\n剩余 80%'));f.advance(16);assert.equal(Usage.parse(await f.result).metrics[0].remainingPercent,80);assert.equal(f.stats().timers,0);
});
test('closing during an outstanding guest read settles immediately and cannot deliver a stale result',async()=>{
 const {ui}=browser();let resolveGuest,removed=0;const state=ui.active={panel:{remove(){removed++;}},view:{executeJavaScript(code){new vm.Script(code);return new Promise(resolve=>resolveGuest=resolve);}}};const job=ui.readPage(state);ui.close();assert.equal((await job).status,'cancelled');resolveGuest(snapshot('剩余 99%'));assert.equal(ui.active,null);assert.equal(removed,1);
});
