import {Plugin,TextSelection} from 'prosemirror-state';
import {Decoration,DecorationSet} from 'prosemirror-view';
import {closeHistory} from 'prosemirror-history';
import {pendingInlineCode} from './annotation-inline-code-placeholder.js';

function inputLabel(node,pos,state){
 if(node.type.name==='table')return '表格';
 if(node.type.name==='code_block')return '代码块';
 if(node.type.name==='math_block')return '公式块';
 if(!node.isTextblock)return null;
 let code=pendingInlineCode(state)&&state.selection.$from.before()===pos,math=false;
 node.forEach(child=>{
  if(child.isText&&state.schema.marks.code.isInSet(child.marks))code=true;
  if(child.type.name==='math_inline')math=true;
 });
 return code&&math?'代码与公式所在段落':code?'行内代码':math?'行内公式':null;
}

export function ordinaryInputParagraph(node){
 if(node?.type.name!=='paragraph')return false;
 let special=false;node.forEach(child=>{
  if(child.type.name==='math_inline'||child.marks.some(mark=>mark.type.name==='code'))special=true;
 });
 return !special;
}

function cancelEmptyInlineMath(tr,node,pos){
 if(!node.isTextblock)return;
 const empty=[];node.forEach((child,offset)=>{
  if(child.type.name==='math_inline'&&!child.attrs.tex.trim())empty.push({from:pos+1+offset,size:child.nodeSize});
 });
 for(const item of empty.reverse())tr.delete(item.from,item.from+item.size);
}

function enterAbove(view,start){
 if(!view.editable||view.composing||start==null)return;
 const state=view.state,at=state.doc.resolve(start),node=at.nodeAfter,paragraph=state.schema.nodes.paragraph;
 if(!node||!inputLabel(node,start,state)||!at.parent.canReplaceWith(at.index(),at.index(),paragraph))return;
 const tr=closeHistory(state.tr);
 cancelEmptyInlineMath(tr,node,start);
 let caret=start-1;
 if(!ordinaryInputParagraph(at.nodeBefore)){tr.insert(start,paragraph.create());caret=start+1;}
 tr.setSelection(TextSelection.create(tr.doc,caret)).setStoredMarks([]);
 view.dispatch(tr.scrollIntoView());view.dispatch(closeHistory(view.state.tr));view.focus();
}

function enterBelow(view,end){
 if(!view.editable||view.composing||end==null)return;
 const state=view.state,at=state.doc.resolve(end),node=at.nodeBefore,paragraph=state.schema.nodes.paragraph;
 if(!node||!inputLabel(node,end-node.nodeSize,state))return;
 if(!at.parent.canReplaceWith(at.index(),at.index(),paragraph))return;
 let tr=closeHistory(state.tr);
 // Match the existing arrow-key exit: an untouched inline formula is only
 // an editing placeholder and has no unambiguous Markdown representation.
 cancelEmptyInlineMath(tr,node,end-node.nodeSize);
 end=tr.mapping.map(end,-1);
 if(!ordinaryInputParagraph(tr.doc.resolve(end).nodeAfter))tr.insert(end,paragraph.create());
 tr.setSelection(TextSelection.create(tr.doc,end+1)).setStoredMarks([]);
 view.dispatch(tr.scrollIntoView());view.dispatch(closeHistory(view.state.tr));view.focus();
}

function inputWidget(pos,label,before){
 return Decoration.widget(pos,(view,getPos)=>{
  const gap=view.dom.ownerDocument.createElement('div');
  gap.className=before?'note-before-input':'note-after-input';gap.setAttribute('role','button');gap.tabIndex=0;
  gap.setAttribute('aria-label','在'+label+(before?'上方':'下方')+'输入');
  const activate=event=>{event.preventDefault();event.stopPropagation();(before?enterAbove:enterBelow)(view,getPos());};
  gap.addEventListener('mousedown',event=>{if(event.button===0)activate(event);});
  gap.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' ')activate(event);});
  return gap;
 },{side:before?1:-1,marks:[],key:(before?'before':'after')+'-input-'+label+'-'+pos,stopEvent:event=>event.type==='mousedown'||event.type==='keydown'});
}

export function noteAfterInput(){
 return new Plugin({props:{decorations(state){
  const items=[];
  state.doc.descendants((node,pos)=>{
   const label=inputLabel(node,pos,state);
   if(!label)return;
   const end=pos+node.nodeSize,startAt=state.doc.resolve(pos),endAt=state.doc.resolve(end),paragraph=state.schema.nodes.paragraph;
   if(startAt.parent.canReplaceWith(startAt.index(),startAt.index(),paragraph)){
    const previous=startAt.nodeBefore;
    items.push(Decoration.node(pos,end,{class:'note-has-before-input'}));
    // Consecutive special blocks share the preceding block's lower guide.
    if(!previous||!inputLabel(previous,pos-previous.nodeSize,state)){
     items.push(inputWidget(pos,label,true));
     if(previous?.isTextblock)items.push(Decoration.node(pos-previous.nodeSize,pos,{class:'note-before-input-neighbor'}));
    }
   }
   // Tables retain their native lower guide and resizing node view.
   if(node.type.name!=='table'&&endAt.parent.canReplaceWith(endAt.index(),endAt.index(),paragraph)){
    items.push(Decoration.node(pos,end,{class:'note-has-after-input'}));
    items.push(inputWidget(end,label,false));
   }
  });
  return DecorationSet.create(state.doc,items);
 }}});
}
