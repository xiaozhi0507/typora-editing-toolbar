// Used by both the Typora palette and the isolated note editor.
export function attachPalettePicker({host,row,input,apply,capture,valid,eyeDropper,message,screenPicker=true}){
 const doc=host.ownerDocument,well=doc.createElement('input'),eye=doc.createElement('button');
 well.type='color';well.value='#295bba';well.className='et-palette-well';well.setAttribute('aria-label','手动选择颜色');well.title='手动选择颜色';
 eye.type='button';eye.className='et-palette-eye';eye.title='从屏幕取色';eye.setAttribute('aria-label','从屏幕取色');
 eye.innerHTML='<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m14 5 5 5M13 6l5 5-9 9H4v-5ZM14 5l2-2a2.1 2.1 0 0 1 3 0l2 2a2.1 2.1 0 0 1 0 3l-2 2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>';
 row.prepend(well);if(screenPicker)row.insertBefore(eye,apply);
 let pending=null,disposed=false,nativeActive=false;
 const liveHost=()=>row.closest('.et-color-picker,.et-actions-detail,.note-child-panel')||host;
 const current=()=>!disposed&&row.isConnected&&!liveHost().hidden&&valid();
 const prepare=()=>{liveHost()._paletteTools=api;capture();};
 const busy=value=>{eye.disabled=value;well.disabled=value;apply.disabled=value;eye.setAttribute('aria-busy',String(value));};
 const accept=value=>{if(!current()||!/^#[\da-f]{6}$/i.test(value))return;input.value=value.toUpperCase();well.value=value.toLowerCase();input.removeAttribute('aria-invalid');message('已选颜色，点击“应用”着色。');};
 const sync=()=>{const value=input.value.trim().replace(/^#?/,'#');if(/^#[\da-f]{6}$/i.test(value)){well.value=value;input.removeAttribute('aria-invalid');message('');}};input.addEventListener('input',sync);
 well.addEventListener('mousedown',e=>{prepare();nativeActive=true;e.stopPropagation();});well.addEventListener('click',()=>{prepare();nativeActive=true;});
 well.addEventListener('input',()=>accept(well.value));well.addEventListener('change',()=>{nativeActive=false;accept(well.value);});
 const focus=e=>{if(e.target!==well)nativeActive=false;};row.addEventListener('focusin',focus);
 eye.addEventListener('mousedown',e=>{e.preventDefault();e.stopPropagation();prepare();});
 eye.addEventListener('click',async e=>{
  e.preventDefault();e.stopPropagation();if(pending||disposed)return;prepare();nativeActive=false;
  const Eye=eyeDropper();if(typeof Eye!=='function'){message('当前版本不支持屏幕取色，可点击左侧色块选色。',true);return;}
  const controller=new AbortController();pending=controller;busy(true);message('点击屏幕上的颜色；按 Esc 取消。');
  try{const result=await new Eye().open({signal:controller.signal});if(pending===controller&&current()){accept(result.sRGBHex);input.focus({preventScroll:true});}}
  catch(error){if(pending===controller&&current())message(error.name==='AbortError'?'已取消取色。':'取色未完成，请重试或点击左侧色块选色。',error.name!=='AbortError');}
  finally{if(pending===controller){pending=null;busy(false);}}
 });
 const cancel=()=>{const controller=pending;pending=null;nativeActive=false;controller?.abort();busy(false);};
 const api={get busy(){return Boolean(pending)||nativeActive;},cancel,dispose(){cancel();disposed=true;row.removeEventListener('focusin',focus);input.removeEventListener('input',sync);}};return api;
}
