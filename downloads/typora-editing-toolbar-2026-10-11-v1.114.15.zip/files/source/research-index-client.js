export async function readIndexFile(fs,request){
 const name=request.args?.[0];if(typeof name!=='string')throw Error('Invalid index path');
 if(request.method==='readdir')return(await fs.promises.readdir(name,{withFileTypes:true})).map(e=>({name:e.name,link:e.isSymbolicLink(),directory:e.isDirectory(),file:e.isFile()}));
 if(request.method==='stat'){const s=await fs.promises.stat(name);return{mtimeMs:s.mtimeMs,size:s.size,file:s.isFile()};}
 if(request.method==='readFile'){const s=await fs.promises.stat(name);if(s.size>8*1024*1024)throw Error('文件超过 8 MB');return fs.promises.readFile(name,'utf8');}
 throw Error('Unsupported index operation');
}
export class ResearchIndexClient {
 constructor(source,fs){const url=URL.createObjectURL(new Blob([source],{type:'text/javascript'}));this.worker=new Worker(url);URL.revokeObjectURL(url);this.listeners={};this.worker.onmessage=async({data:m})=>{if(m.fsRequest){try{this.worker.postMessage({fsReply:m.fsRequest,value:await readIndexFile(fs,m)});}catch(e){this.worker.postMessage({fsReply:m.fsRequest,error:{message:e.message,code:e.code}});}return;}this.listeners.message?.(m);};this.worker.onerror=e=>this.listeners.error?.(e);}
 on(event,fn){this.listeners[event]=fn;}
 postMessage(value){this.worker.postMessage(value);}
 terminate(){this.worker.terminate();}
}
