'use strict';
// Translate prose only. File names, destinations and Markdown structure are never model output.
class PaperTranslation {
  static skill='paper-pdf-to-chinese-markdown';
  static normalize(text){return String(text).replace(/^\uFEFF/,'').replace(/\r\n?/g,'\n');}
  static english(text){
    const sample=this.normalize(text).split(/^#{1,6}\s+(?:References|Bibliography)\s*$/im)[0].replace(/```[\s\S]*?```|<[^>]*>|https?:\/\/\S+|\$[^$]*\$/g,' ');
    const words=sample.match(/\b[a-z]{2,}\b/gi)||[],han=sample.match(/[\u3400-\u9fff]/g)||[];
    const common=sample.match(/\b(?:the|and|of|to|with|is|for|from|this|we|was|are|were|that|by|using|which|these)\b/gi)||[];
    return words.length>=35 && common.length>=5 && common.length/words.length>.07 && han.length<words.length*.3;
  }
  static protect(line,referenceIds=new Set()){
    const values=[],token=value=>{const id='⟦ET'+values.length+'⟧';values.push(value);return id;};
    if(line.includes('⟦ET'))throw Error('原文包含保留标记，无法安全翻译');
    // Inline code/math, HTML tags, links, images, escapes, and formatting delimiters.
    const pattern=/!?\[\[[^\]\n]+\]\]|!?\[[^\]\n]*\]\[[^\]\n]*\]|\[\^[^\]\n]+\]|!\[[^\]\n]*\]\((?:[^()\n]|\([^()\n]*\))*\)|\[[^\]\n]*\]\((?:<?#(?:ref|bib)[^\s)]*>?)\)|`+[^`]*`+|\$\$[^$]*\$\$|(?<!\\)\$(?:\\.|[^$\n])+?\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]|<[^>\n]+>|\]\((?:[^()\n]|\([^()\n]*\))*\)|https?:\/\/[^\s<>]+|\\.|&(?:\w+|#\d+);|\*+|_+|\|+|\[|\]|~{2}|\b\d+(?:[.,]\d+)*\b|[#$]/g;
    const prefix=line.match(/^ {0,3}\[\^[^\]\n]+\]:\s*/)?.[0]||line.match(/^(?:\s*(?:#{1,6}\s+|>\s*|[-+*]\s+|\d+[.)]\s+))+/)?.[0]||line.match(/^\s+/)?.[0]||'';
    const start=prefix?token(prefix):'';
    const body=line.slice(prefix.length).replace(/!?\[([^\]\n]+)\](?![([])/g,(all,id)=>referenceIds.has(id.trim().toLowerCase())?token(all):all).replace(pattern,token);
    let trailing='';const text=start+body.replace(/ {2,}$/,value=>(trailing=token(value)));
    return {text,values,leading:start,trailing};
  }
  static plan(markdown){
    const source=this.normalize(markdown),lines=source.split('\n'),units=[],referenceIds=new Set([...source.matchAll(/^ {0,3}\[([^\]\n]+)\]:/gm)].map(m=>m[1].trim().toLowerCase()));let fence='',math=false,front=false,refs=0,htmlBlock='',listIndent=null,indentedCode=false;
    for(let n=0;n<lines.length;n++){
      const line=lines[n],trim=line.trim();
      const list=line.match(/^(\s*)(?:[-+*]|\d+[.)])\s+/);if(list)listIndent=list[0].length;else if(trim&&!/^\s/.test(line)&&!lines[n-1]?.trim())listIndent=null;
      if(/^ {0,3}\[\^[^\]]+\]:/.test(line))listIndent=4;
      const indent=line.match(/^ */)[0].length;if(trim){if(indent<4)indentedCode=false;else if(listIndent===null?(!lines[n-1]?.trim()||indentedCode):indent>=listIndent+4)indentedCode=true;}
      if(n===0&&trim==='---'){front=true;continue;}if(front){if(/^(---|\.\.\.)$/.test(trim))front=false;continue;}
      const f=trim.match(/^(`{3,}|~{3,})/);if(f){if(!fence)fence=f[1];else if(f[1][0]===fence[0]&&f[1].length>=fence.length)fence='';continue;}if(fence)continue;
      if(/^\$\$/.test(trim)){if(trim==='$$')math=!math;continue;}if(math)continue;
      if(/^<(?:pre|script|style|math)\b/i.test(trim))htmlBlock=trim.match(/^<(\w+)/)[1];if(htmlBlock){if(new RegExp('</'+htmlBlock+'>','i').test(line))htmlBlock='';continue;}
      const h=line.match(/^\s*(#{1,6})\s+(.+?)\s*#*$/);if(h){if(refs&&h[1].length<=refs)refs=0;if(/^(?:\d+[.\s]+)?(?:References|Bibliography|参考文献)$/i.test(h[2]))refs=h[1].length;}
      if(refs||indentedCode||/^\s*\[(?!\^)[^\]]+\]:/.test(line)||/^\s*[-:|\s]+$/.test(line)||/^\s*(?:\*\*)?Authors?:/i.test(line))continue;
      if(line.length>16000)throw Error('原文单段超过 16000 字符，请先按段落拆分后重试');
      const protectedLine=this.protect(line,referenceIds);
      if(!/[a-z]{2}/i.test(protectedLine.text.replace(/⟦ET\d+⟧/g,'')))continue;
      units.push({id:'L'+(n+1),line:n,original:line,...protectedLine});
    }
    if(front||fence||math||htmlBlock)throw Error('原文包含未闭合的代码、公式或元数据块，请先修复再翻译');
    if(!units.length)throw Error('没有找到可翻译的英文正文');
    return {source,lines,units};
  }
  static chunks(units,limit=6500){const chunks=[];let group=[],size=0;for(const u of units){if(group.length&&size+u.text.length>limit){chunks.push(group);group=[];size=0;}group.push(u);size+=u.text.length;}if(group.length)chunks.push(group);return chunks;}
  static async runChunks(chunks,run,{signal,onProgress=()=>{}}={}){
    const controller=new AbortController(),abort=()=>controller.abort(),results=[];let active=[];
    const report=()=>onProgress({completed:results.length,total:chunks.length,active:[...active],concurrency:1});
    signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)abort();
    try{
      for(let n=0;n<chunks.length;n++){
        this.check(controller.signal);active=[n];report();
        try{
          // The preceding chunk must be validated before its context is used by the next.
          const value=await run(chunks[n],n,{signal:controller.signal,previous:[...results]});
          this.check(controller.signal);results.push(value);
        }finally{active=[];report();}
      }
      return results;
    }finally{controller.abort();signal?.removeEventListener('abort',abort);}
  }
  static async streamRequest(perform,{id,label,signal,emit=()=>{}}={}){
    let live=true,eventReasoning=false,received=0,lastProgress='';const reasons=new Map();
    const publish=e=>{if(live&&!signal?.aborted)emit({round:0,description:label,...e});};
    const progress=(text,status='running')=>{if(text===lastProgress&&status==='running')return;lastProgress=text;publish({id:id+':stream',type:'progress',status,text:label+' · '+text});};
    const reasoning=(key,text,kind,status='running')=>{if(typeof text!=='string'||!text.trim()||(!reasons.has(key)&&reasons.size>=32))return;const row={id:id+':reasoning:'+key,type:'reasoning',kind:kind==='summary'?'summary':'thinking',text:text.slice(0,16000),status};reasons.set(key,row);publish(row);};
    const output=text=>{received=String(text||'').length;if(received)progress('正在接收译文 · 已接收 '+received.toLocaleString()+' 字符');};
    progress('等待接口响应');
    try{
      const result=await perform({signal,onText:output,onReasoning:(text,kind)=>{if(!eventReasoning){reasoning('returned',text,kind);if(!received)progress('正在接收模型返回的'+(kind==='summary'?'思考摘要':'思考内容'));}},onEvent:e=>{
        if(e.type==='reasoning'){eventReasoning=true;reasoning(e.id||'returned',e.text,e.kind,e.status);if(!received)progress('正在接收模型返回的'+(e.kind==='summary'?'思考摘要':'思考内容'));}
        else if(e.type==='status'&&e.text)progress(e.text);
      }});
      this.check(signal);if(!reasons.size&&result.reasoning)reasoning('returned',result.reasoning,result.reasoningKind);
      for(const row of reasons.values())publish({...row,status:'success'});
      progress('译文已接收，正在校验'+(reasons.size?'':' · 接口未返回可显示的思考摘要'),'success');return result;
    }catch(e){
      // Preserve partial summaries on stop without accepting any late callbacks.
      for(const row of reasons.values())emit({round:0,description:label,...row,status:e.name==='AbortError'?'cancelled':'failed'});
      emit({id:id+':stream',round:0,type:'progress',status:e.name==='AbortError'?'cancelled':'failed',text:label+' · '+(e.name==='AbortError'?'已停止':'本段未完成')});throw e;
    }finally{live=false;}
  }
  static validationError(message,issues=[],accepted=new Map()){
    return Object.assign(Error(message),{code:'PAPER_TRANSLATION_VALIDATION',issues,accepted});
  }
  static input(units){
    return {segments:units.map(u=>({id:u.id,text:u.text,locked:u.values.map((value,n)=>({id:'⟦ET'+n+'⟧',value}))}))};
  }
  static proseError(prose){
    if(!prose.trim())return '译文缺少正文文字';
    if(/[<>`|\[\]*_\\#$]|https?:\/\//.test(prose)||/⟦|⟧/.test(prose))return '译文包含未授权的格式或链接';
    // Length and language ratios cannot establish whether a translation is complete.
    return '';
  }
  static markerLayout(unit){
    const order=unit.text.match(/⟦ET\d+⟧/g)||[],nodes=new Map(),stack=[];let boundary='';
    for(const id of order){
      const value=unit.values[Number(id.slice(3,-1))];let key='',close=false;
      if(id!==unit.leading&&id!==unit.trailing){
        if(value==='[')key='link';else if(/^\](?:\(|$)/.test(value)){key='link';close=true;}
        else if(/^(?:\*+|_+|~~)$/.test(value)){key=value;close=stack.at(-1)?.key===key;}
        else if(/^<\/[a-z][\w:-]*\s*>$/i.test(value)){key='html:'+value.match(/^<\/([\w:-]+)/)[1].toLowerCase();close=true;}
        else if(/^<[a-z][\w:-]*\b/i.test(value)&&!/^<(?:area|base|br|col|embed|hr|img|input|link|meta|param|source|track|wbr)\b/i.test(value)&&!/\/\s*>$/.test(value))key='html:'+value.match(/^<([\w:-]+)/)[1].toLowerCase();
      }
      let mate='';
      if(close){if(stack.at(-1)?.key!==key)return {order,strict:true};mate=stack.pop().id;}
      const node={parent:stack.at(-1)?.id||'',boundary,kind:key?(close?'close':'open'):/^\|+$/.test(value)?'boundary':'atom',mate,key};nodes.set(id,node);
      if(key&&!close)stack.push({id,key});
      if(node.kind==='boundary')boundary=id;
    }
    return {order,nodes,strict:stack.length>0};
  }
  static structureError(unit,text){
    if(unit.leading&&!text.startsWith(unit.leading))return '标题、列表或缩进标记离开了行首';
    if(unit.trailing&&!text.endsWith(unit.trailing))return '原文换行标记离开了行尾';
    const layout=this.markerLayout(unit),actual=text.match(/⟦ET\d+⟧/g)||[];
    // Ambiguous/unclosed source markup is kept in its existing order; do not guess repairs.
    if(layout.strict)return JSON.stringify(layout.order)===JSON.stringify(actual)?'':'原文格式未闭合，不能调整其标记顺序';
    const stack=[];let boundary='';
    for(const id of actual){
      const node=layout.nodes.get(id);
      if(node.kind==='close'){if(stack.pop()!==node.mate)return '链接、HTML 或强调标记未按原文配对闭合';}
      if(node.parent!==(stack.at(-1)||'')||node.boundary!==boundary)return '标记跨越了原有格式层级或表格单元格';
      if(node.kind==='open')stack.push(id);
      if(node.kind==='boundary')boundary=id;
    }
    return stack.length?'格式标记未闭合':'';
  }
  static markerError(expected,actual){
    const missing=expected.filter(t=>!actual.includes(t)),extra=actual.filter(t=>!expected.includes(t)),duplicate=[...new Set(actual.filter((t,n)=>actual.indexOf(t)!==n))];
    const details=[missing.length?'缺少 '+missing.slice(0,6).join('、'):'',extra.length?'未知 '+extra.slice(0,6).join('、'):'',duplicate.length?'重复 '+duplicate.slice(0,6).join('、'):''].filter(Boolean);
    return details.length?'译文缺失或重复图片、公式、引用或格式标记（'+details.join('；')+'）':'';
  }
  static async translateChunk(units,request,{signal,onRepair=()=>{}}={}){
    const accepted=new Map();let pending=units,feedback='';
    for(let attempt=0;attempt<3;attempt++){
      this.check(signal);
      try{
        const result=await request(pending,{attempt,feedback});this.check(signal);
        for(const [id,text] of result)accepted.set(id,text);
        return new Map(units.map(unit=>[unit.id,accepted.get(unit.id)]));
      }catch(e){
        this.check(signal);if(e.code!=='PAPER_TRANSLATION_VALIDATION')throw e;
        for(const [id,text] of e.accepted)accepted.set(id,text);
        pending=units.filter(unit=>!accepted.has(unit.id));feedback=e.message;
        if(attempt===2)throw this.validationError('重试 2 次后返回内容仍不完整或存在结构问题。'+feedback,e.issues);
        onRepair({attempt:attempt+1,remaining:pending.length,accepted:accepted.size,total:units.length,feedback});
      }
    }
  }
  static accept(units,response){
    let value;try{value=JSON.parse(String(response).trim().replace(/^```(?:json)?\s*\n([\s\S]*?)\n```$/,'$1'));}catch(_){throw this.validationError('译文返回格式不完整，请返回完整的 JSON');}
    if(!Array.isArray(value?.translations))throw this.validationError('译文缺少 translations 数组');
    const rows=new Map(),ids=new Set(units.map(u=>u.id));
    for(const row of value.translations){
      if(!ids.has(row?.id)||rows.has(row.id))throw this.validationError('译文段落标识重复或不匹配，请严格返回本次提供的 id');
      rows.set(row.id,row);
    }
    const result=new Map(),issues=[];
    for(const unit of units){
      const row=rows.get(unit.id),fail=(reason,code)=>issues.push({id:unit.id,line:unit.line+1,reason,...(code?{code}:{})});
      if(!row){fail('译文段落数量不完整，缺少此片段');continue;}
      if(typeof row.text!=='string'||!row.text.trim()||/[\r\n]/.test(row.text)){fail('译文为空或换行不匹配');continue;}
      const expected=unit.text.match(/⟦ET\d+⟧/g)||[],actual=row.text.match(/⟦ET\d+⟧/g)||[];
      const markerError=this.markerError(expected,actual)||this.structureError(unit,row.text);
      if(markerError){fail(markerError,'markers');continue;}
      const prose=row.text.replace(/⟦ET\d+⟧/g,'');
      const error=this.proseError(prose);if(error){fail(error);continue;}
      result.set(row.id,row.text.replace(/⟦ET(\d+)⟧/g,(_,i)=>unit.values[Number(i)]));
    }
    if(issues.length)throw this.validationError('译文校验未通过：'+issues.slice(0,6).map(issue=>'第 '+issue.line+' 行（'+issue.id+'）'+issue.reason).join('；')+(issues.length>6?'；另有 '+(issues.length-6)+' 个段落需重试':''),issues,result);
    return result;
  }
  static render(plan,translations){const lines=[...plan.lines];for(const u of plan.units){if(!translations.has(u.id))throw Error('全文翻译尚未完成，未保存');lines[u.line]=translations.get(u.id);}return lines.join('\n');}
  static indexFingerprint(text){
    const unescape=value=>value.replace(/\\([!"#$%&'()*+,\-./:;<=>?@[\]\\^_`{|}~])/g,'$1');
    const entities=value=>value.replace(/&(#x[\da-f]+|#\d+|amp|quot|apos|lt|gt|nbsp);/gi,(all,key)=>{
      if(key[0]!=='#')return {amp:'&',quot:'"',apos:"'",lt:'<',gt:'>',nbsp:'\u00a0'}[key.toLowerCase()];
      const n=key[1].toLowerCase()==='x'?parseInt(key.slice(2),16):Number(key.slice(1));return n>0&&n<=0x10ffff?String.fromCodePoint(n):all;
    });
    const image=(src,alt='',title='')=>'\u0000image:'+JSON.stringify([src,alt,title])+'\u0000';
    return this.normalize(text)
      // Only remove the presentation wrapper generated by one-click centering.
      .replace(/<span\s+style=(["'])display:inline-block;width:100%;text-align:center;text-indent:0;\1>([\s\S]*?)<\/span>/gi,'$2')
      .replace(/!\[((?:\\.|[^\]\\\n])*)\]\(\s*(<[^>\n]*>|(?:\\.|[^\s()\\]|\([^()\n]*\))+)(?:\s+("[^"\n]*"|'[^'\n]*'|\([^()\n]*\)))?\s*\)|<img\b(?:[^>"']|"[^"]*"|'[^']*')*>/gi,(all,alt,url,title)=>{
        if(url!==undefined)return image(entities(unescape(url.replace(/^<([\s\S]*)>$/,'$1'))),entities(unescape(alt)),entities(unescape(title?title.slice(1,-1):'')));
        const attrs={},body=all.replace(/^<img\b/i,'').replace(/\/?\s*>$/,'');let offset=0;
        const pattern=/\s+([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+))/g;let match;
        while((match=pattern.exec(body))){
          const key=match[1].toLowerCase();if(match.index!==offset||Object.hasOwn(attrs,key)||!['src','alt','title','style','width','height'].includes(key))return all;
          attrs[key]=entities(match[2]??match[3]??match[4]);offset=pattern.lastIndex;
        }
        if(body.slice(offset).trim()||!attrs.src)return all;
        return image(attrs.src,attrs.alt,attrs.title);
      })
      .replace(/^\s*\|[\s:|\-]+\|\s*$/gm,'|---|')
      .replace(/\s(?:style|width|height)\s*=\s*(?:"[^"]*"|'[^']*')/gi,'').replace(/\s+/g,' ').trim();
  }
  static index(index,sourceName,targetName,plan,translated,hash){
    if(index.schema!=='xref-sidecar-v2'||index.path_base!=='markdown-directory')throw Error('引用索引格式不受支持，原文未修改');
    const docs=index.documents.filter(d=>d.markdown===sourceName);if(docs.length!==1)throw Error('引用索引未匹配当前文献');
    const doc=JSON.parse(JSON.stringify(docs[0])),lines=translated.split('\n');
    const fingerprint=text=>this.indexFingerprint(text);
    for(const t of doc.targets||[]){
      const content=this.normalize(t.content||'');if(!content)continue;
      const expected=fingerprint(content);let start=Number(t.start_line)-1,end=Number(t.end_line);
      if(!Number.isInteger(start)||!Number.isInteger(end)||start<0||end<=start||end>plan.lines.length||fingerprint(plan.lines.slice(start,end).join('\n'))!==expected){
        // Offsets can move after edits. Relocate only a unique complete matching block.
        const length=content.split('\n').length,matches=[];
        for(let n=0;n+length<=plan.lines.length;n++)if(fingerprint(plan.lines.slice(n,n+length).join('\n'))===expected){matches.push(n);if(matches.length>1)break;}
        if(matches.length!==1){if(['figure','table'].includes(t.kind))throw Error('图表索引与原文不一致，请先修复索引：'+t.id);continue;}
        start=matches[0];end=start+length;
      }
      t.start_line=start+1;t.end_line=end;t.content=lines.slice(start,end).join('\n');
    }
    doc.markdown=targetName;doc.sha256=hash;doc.metadata={...doc.metadata,language:'zh',title_zh:lines.find(l=>/^#\s/.test(l))?.replace(/^#\s+/,'')||doc.metadata?.title_zh||''};
    return {...index,documents:[doc]};
  }
  static check(signal){if(signal?.aborted)throw Object.assign(Error('全文翻译已停止'),{name:'AbortError'});}
  static async locate(store,file,source){
    const snapshot=await store.read();if(!snapshot)throw Error('请先将英文文献加入知识库');
    const matches=[];for(const item of snapshot.data.items)for(const ref of item.files||[])if(ref.linkType!=='url'&&store.path.resolve(store.resolveFile(ref)).toLowerCase()===store.path.resolve(file).toLowerCase())matches.push({item,ref});
    if(matches.length!==1||!['paper','thesis'].includes(matches[0].item.type))throw Error('仅支持当前打开的知识库英文文献 Markdown 附件');
    if(!/\.(?:md|markdown|mdown)$/i.test(file)||!this.english(source))throw Error('当前正文不是英文文献');
    return {...matches[0],libraryId:snapshot.data.libraryId,file,source};
  }
  static async save(store,managed,candidate,plan,translated,{signal,assert,profile}={}){
    const path=store.path,io=store.io,hash=b=>store.crypto.createHash('sha256').update(b).digest('hex');
    const check=async()=>{this.check(signal);await assert?.();if(this.normalize(await io.readFile(candidate.file,'utf8'))!==plan.source)throw Error('翻译期间英文原稿已修改，请重新翻译');};
    await check();const resources=await managed.plan(candidate.ref,{signal,includeNotes:false});
    const stem=path.parse(candidate.file).name,outputStem=stem.replace(/(?:[_ -]English)$/i,'')+'_中文翻译';
    const existing=(await store.read()).data.items.find(i=>i.id===candidate.item.id)?.files||[];
    let targetName=outputStem+'.md',version=2;while(existing.some(f=>f.name.toLowerCase()===targetName.toLowerCase()))targetName=outputStem+'_'+(version++)+'.md';
    const oldIndex=path.join(path.dirname(candidate.file),'_xref',stem,'xref-index.json');let nextIndex=null;
    try{const st=await io.stat(oldIndex);if(st.size>8*1024*1024)throw Error('引用索引超过 8 MB');nextIndex=this.index(JSON.parse((await io.readFile(oldIndex,'utf8')).replace(/^\uFEFF/,'')),path.basename(candidate.file),targetName,plan,translated,hash(translated));}catch(e){if(e.code!=='ENOENT')throw e;}
    const key=store.crypto.randomBytes(4).toString('hex').toUpperCase(),folder=path.join(managed.storage,key);let committed=false;
    await io.mkdir(managed.storage,{recursive:true});await managed.regular(managed.storage);await io.mkdir(folder);
    try{
      const manifest=[];for(const f of resources.files){this.check(signal);await managed.regular(f.file);const current=await io.stat(f.file);if(current.size!==f.bytes||current.mtimeMs!==f.mtime)throw Error('翻译资源已修改，请重试');
        const relative=path.relative(resources.base,f.file),target=path.join(folder,relative);if(!managed.inside(folder,target))throw Error('资源路径越界');await io.mkdir(path.dirname(target),{recursive:true});
        await io.copyFile(f.file,target,store.fs.constants.COPYFILE_EXCL);const [a,b]=await Promise.all([io.readFile(f.file),io.readFile(target)]);if(hash(a)!==hash(b))throw Error('资源复制校验失败');manifest.push({path:relative.replaceAll('\\','/'),sha256:hash(b),bytes:b.length});
      }
      const directory=path.join(folder,path.relative(resources.base,path.dirname(candidate.file))),target=path.join(directory,targetName);
      await io.writeFile(target,translated,{flag:'wx'});manifest.push({path:path.relative(folder,target).replaceAll('\\','/'),sha256:hash(translated),bytes:store.fs.readFileSync(target).length});
      if(nextIndex){const xref=path.join(directory,'_xref',path.parse(targetName).name);await io.mkdir(xref,{recursive:true});await io.writeFile(path.join(xref,'xref-index.json'),JSON.stringify(nextIndex,null,2),{flag:'wx'});}
      await io.writeFile(path.join(folder,'.managed.json'),JSON.stringify({version:1,source:candidate.file,created:new Date().toISOString(),translation:{model:profile?.model,reasoningEffort:profile?.reasoningEffort,skill:this.skill},files:manifest},null,2),{flag:'wx'});
      await check();const current=await store.read();if(current.data.libraryId!==candidate.libraryId)throw Error('知识库已切换，未保存');
      const local=JSON.parse(JSON.stringify(current.data)),item=local.items.find(i=>i.id===candidate.item.id);if(!item)throw Error('原文献条目已删除');
      const ref={...store.fileRef(target,'markdown'),managed:true,storageKey:key,sourcePath:candidate.file};item.files.push(ref);
      await store.commit(current.data,local,live=>{this.check(signal);const parent=live.items.find(i=>i.id===candidate.item.id);if(!parent||!['paper','thesis'].includes(parent.type)||!parent.files.some(f=>f.id===candidate.ref.id&&f.path===candidate.ref.path))throw Error('原文献附件已变更，未保存');});committed=true;
      return {file:target,ref,itemId:item.id,title:item.title,index:!!nextIndex};
    }finally{if(!committed)await managed.removeFolder(folder).catch(()=>{});}
  }
}
module.exports=PaperTranslation;
