'use strict';
// Transport only. The panel owns presentation; hiding it never stops this session.
class TerminalSession {
  constructor(requireNode, options={}) {
    this.node=requireNode;this.options=options;this.state='idle';this.pendingOutput=0;
  }
  static profile(requireNode, name) {
    const path=requireNode('path'),root=requireNode('process').env.SystemRoot||'C:\\Windows';
    if(name==='powershell')return {name:'PowerShell',exe:path.join(root,'System32','WindowsPowerShell','v1.0','powershell.exe'),args:['-NoLogo','-NoProfile']};
    if(name==='cmd')return {name:'CMD',exe:path.join(root,'System32','cmd.exe'),args:['/d']};
    throw Error('未知终端类型');
  }
  async start({host,profile='powershell',cwd,cols=80,rows=24,environment,command}) {
    if(this.state!=='idle')throw Error('终端会话已启动');
    const fs=this.node('fs'),path=this.node('path'),proc=this.node('process');
    if(proc.platform!=='win32')throw Error('当前内置终端仅支持 Windows 10 1809 及更新版本');
    const selected=TerminalSession.profile(this.node,profile);
    if(command!==undefined){if(profile!=='powershell'||typeof command!=='string'||command.length>10000)throw Error('AI 终端命令格式无效');selected.args.push('-NonInteractive','-OutputFormat','Text','-EncodedCommand',this.node('buffer').Buffer.from(command,'utf16le').toString('base64'));}
    try{if(!path.isAbsolute(cwd||'')||!(await fs.promises.stat(cwd)).isDirectory())throw Error();this.cwd=await fs.promises.realpath(cwd);}
    catch{throw Error('工作目录不存在或无法访问，请重新选择文件夹');}
    if(!fs.existsSync(host))throw Error('终端组件缺失，请重新安装工具栏');
    this.state='starting';
    const env={...(environment||proc.env),TERM:'xterm-256color',COLORTERM:'truecolor'};delete env.ELECTRON_RUN_AS_NODE;
    this.child=this.node('child_process').spawn(host,[],{cwd:this.cwd,env,windowsHide:true,stdio:['pipe','pipe','pipe']});
    const child=this.child;child.stdout.setEncoding('utf8');child.stderr.resume();child.stdin.on('error',()=>{});
    let buffer='';
    this.ready=new Promise((resolve,reject)=>{this.resolveReady=resolve;this.rejectReady=reject;});
    this.ready.catch(()=>{});
    this.startTimer=setTimeout(()=>{this.fail(Error('终端启动超时，请检查命令行程序'));this.stop();},15000);
    child.stdout.on('data',chunk=>{
      buffer+=chunk;let at;
      try{while((at=buffer.indexOf('\n'))>=0){const line=buffer.slice(0,at);buffer=buffer.slice(at+1);if(line)this.receive(JSON.parse(line));}if(buffer.length>128*1024)throw Error('终端数据格式无效');}
      catch(error){this.fail(error);this.stop();}
    });
    child.on('error',error=>{this.fail(error);this.ended(-1);});
    // close occurs after stdout has drained, preserving final output and exit status.
    child.on('close',code=>this.ended(this.exitCode??code??-1));
    this.send({type:'start',...selected,cwd:this.cwd,cols,rows,ownerPid:proc.pid});
    return this.ready;
  }
  receive(message){
    if(message.type==='ready'){this.pid=message.pid;if(this.state==='starting')this.state='running';clearTimeout(this.startTimer);this.resolveReady?.(this);this.options.onState?.(this.state);}
    if(message.type==='error')this.fail(Error(message.message||'终端异常'));
    if(message.type==='exit')this.exitCode=message.code;
    if(message.type==='data'){
      const bytes=this.node('buffer').Buffer.from(message.data,'base64');this.pendingOutput+=bytes.length;
      if(this.pendingOutput>=256*1024)this.child?.stdout.pause();
      let acked=false;const ack=()=>{if(acked)return;acked=true;this.pendingOutput-=bytes.length;if(this.pendingOutput<64*1024)this.child?.stdout.resume();};
      if(this.options.onData)this.options.onData(bytes,ack);else ack();
    }
  }
  send(message){if(!this.child?.stdin.writable)return false;this.child.stdin.write(JSON.stringify(message)+'\n');return true;}
  write(text){
    if(this.state!=='running')return false;
    const Buffer=this.node('buffer').Buffer,bytes=Buffer.from(text,'utf8');
    if(bytes.length>256*1024||this.child.stdin.writableLength>1024*1024){this.options.onError?.(Error('输入过长或终端繁忙，请分段粘贴'));return false;}
    return this.send({type:'input',data:bytes.toString('base64')});
  }
  resize(cols,rows){if(this.state==='running')this.send({type:'resize',cols,rows});}
  fail(error){this.error=error;clearTimeout(this.startTimer);this.rejectReady?.(error);this.options.onError?.(error);}
  ended(code){
    if(this.state==='exited')return;clearTimeout(this.startTimer);clearTimeout(this.killTimer);
    this.state='exited';this.exitCode=code;this.rejectReady?.(this.error||Error('终端在启动完成前退出'));
    this.options.onState?.('exited',code);
  }
  stop(){
    if(!this.child||this.state==='exited'||this.state==='stopping')return;
    this.state='stopping';this.child.stdout.resume();this.send({type:'stop'});this.child.stdin.end();
    // Killing the helper closes its Job Object, including the shell's descendants.
    this.killTimer=setTimeout(()=>this.child?.kill(),3000);this.killTimer.unref?.();
  }
}
module.exports={TerminalSession};
