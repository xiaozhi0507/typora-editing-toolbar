// Read-only reference, figure and table previews from a sibling _xref index.
class EditingToolbarCitationPreview {
 constructor(toolbar,context=null) {
  this.toolbar=toolbar;this.context=context;this.popupId=context?'et-split-citation-preview':'et-citation-preview';this.markKey=context?'et-split-citation-target':'et-citation-target';this.fs=reqnode('fs').promises;this.path=reqnode('path');this.records=new Map();this.generation=0;this.serial=0;
  this.media=new EditingToolbarXrefMedia(this);
  this.observer=new MutationObserver(()=>{this.blockCache=null;if(this.anchor&&(!this.anchor.isConnected||this.anchor.getAttribute('href')!==this.anchorHref))this.hide();});
  document.addEventListener('pointerover',e=>{if(e.buttons||e.pointerType==='touch')return;const a=this.link(e.target);if(a)this.hover(a);},true);
  document.addEventListener('pointerout',e=>{
   if(this.anchor?.contains(e.target)&&!this.anchor.contains(e.relatedTarget))this.leave();
  },true);
  document.addEventListener('pointerdown',e=>{
   this.down={x:e.clientX,y:e.clientY,file:File.bundle?.filePath};
   if(!this.popup?.contains(e.target))this.hide();
  },true);
  document.addEventListener('pointermove',e=>{if(e.buttons){if(!this.popup?.contains(e.target))this.hide();}else if(e.pointerType!=='touch'){const a=this.link(e.target);if(a)this.hover(a);}},true);
  window.addEventListener('click',e=>this.click(e),true);
  document.addEventListener('focusin',e=>{const a=this.link(e.target);if(a)this.hover(a);},true);
  document.addEventListener('keydown',e=>{if(e.key==='Escape')this.hide();},true);
  document.addEventListener('selectionchange',()=>{if(!getSelection()?.isCollapsed&&!this.popup?.contains(getSelection().anchorNode))this.hide();});
  document.addEventListener('scroll',e=>{if(!this.popup?.contains(e.target))this.hide();},true);
  window.addEventListener('resize',()=>this.hide());window.addEventListener('blur',()=>this.hide());
  this.poll=setInterval(()=>this.bind(),750);this.bind();
 }
 sourceFile(){return this.context?this.context.file():File.bundle?.filePath||'';}
 valid(file=this.file) {return Boolean(file&&file===this.sourceFile()&&(this.context?this.context.valid():!File.isFileLoading?.()&&!File.editor.sourceView?.inSourceMode));}
 bind() {
  const file=this.sourceFile(),write=this.context?this.context.root():document.getElementById('write');
  if(file!==this.file) {
   this.hide();this.clearMark();this.generation++;this.file=file;this.records=new Map();this.tableStyle='';this.links=null;this.pending=null;this.signature='';this.loadedAt=0;
   clearTimeout(this.warmup);if(file)this.warmup=setTimeout(()=>{if(this.valid())this.load();},1000);
  }
  if(write!==this.write) {this.observer.disconnect();this.write=write;this.blockCache=null;if(write)this.observer.observe(write,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['href','id']});}
  if(!this.valid())this.hide();
 }
 async load() {
  this.bind();if(!this.valid())return;
  if(this.pending)return this.pending;if(Date.now()-this.loadedAt<2000)return;
  const file=this.file,generation=this.generation,index=this.path.join(this.path.dirname(file),'_xref',this.path.parse(file).name,'xref-index.json');
  this.pending=(async()=>{
   try {
    const stat=await this.fs.stat(index);if(!stat.isFile()||stat.size>8*1024*1024)throw Error('Invalid citation index size');
    const signature=stat.mtimeMs+':'+stat.size;if(signature===this.signature)return;
    const data=JSON.parse((await this.fs.readFile(index,'utf8')).replace(/^\uFEFF/,''));
    if(data?.schema!=='xref-sidecar-v2'||data.path_base!=='markdown-directory'||!Array.isArray(data.documents))throw Error('Unsupported citation index');
    const name=this.path.basename(file),docs=data.documents.filter(d=>d?.markdown===name);
    if(docs.length!==1)throw Error('Citation index does not identify this document');
    const doc=docs[0],records=new Map(),duplicate=new Set(),targets=new Map();
    for(const t of (Array.isArray(doc.targets)?doc.targets:[]).slice(0,20000))if(t?.kind==='reference'&&this.validId(t.id))targets.set(t.id,t);
    for(const bib of (Array.isArray(doc.bibliography)?doc.bibliography:[]).slice(0,10000)) {
     if(!this.validId(bib?.id)||!targets.has(bib.id)||typeof bib.text!=='string'||!bib.text.trim()||bib.text.length>20000)continue;
     if(records.has(bib.id)||duplicate.has(bib.id)){records.delete(bib.id);duplicate.add(bib.id);continue;}
     records.set(bib.id,{id:bib.id,text:bib.text.trim(),key:this.normalize(bib.text.replace(/(?:URL:\s*)?https?:\/\/\S+/gi,'')),urls:[...new Set((Array.isArray(bib.urls)?bib.urls:[]).slice(0,8).map(u=>this.safeURL(u)).filter(Boolean))]});
    }
    for(const t of (Array.isArray(doc.targets)?doc.targets:[]).slice(0,20000)){
     const record=this.media.record(t);if(!record)continue;
     if(records.has(record.id)||duplicate.has(record.id)){records.delete(record.id);duplicate.add(record.id);continue;}
     records.set(record.id,record);
    }
    if(this.file===file&&this.generation===generation){this.records=records;this.tableStyle=doc.table_style==='three-line'?'three-line':'';this.links=new EditingToolbarXrefLinks(doc,records);this.signature=signature;this.blockCache=null;if(this.context)this.context.onIndex?.();else this.toolbar.tableColumns?.scan();}
   } catch(error) {if(this.file===file&&this.generation===generation){this.records=new Map();this.tableStyle='';this.links=null;this.signature='';if(this.context)this.context.onIndex?.();else this.toolbar.tableColumns?.scan();}}
   finally {if(this.file===file&&this.generation===generation){this.loadedAt=Date.now();this.pending=null;}}
  })();
  return this.pending;
 }
 validId(id) {return typeof id==='string'&&/^(?:ref|fig|tab|table)-[^\s#/?\\<>]{1,250}$/u.test(id);}
 safeURL(value) {
  if(typeof value!=='string'||value.length>2048||/[\u0000-\u0020<>"\\]/.test(value))return null;
  try{const u=new URL(value);return /^https?:$/.test(u.protocol)&&!u.username&&!u.password?u.href:null;}catch{return null;}
 }
 normalize(value) {return value.normalize('NFKC').toLowerCase().replace(/[^\p{L}\p{N}]/gu,'');}
 linkId(a) {
  const href=a?.getAttribute('href'),resolved=this.links?.resolve(href);if(resolved)return resolved;
  try{if(!href?.startsWith('#'))return null;const id=decodeURIComponent(href.slice(1));return this.validId(id)?id:null;}catch{return null;}
 }
 link(target) {const a=target?.closest?.('a[href]');return a&&this.write?.contains(a)&&!a.closest('pre,code,.md-fences,.md-toc')&&(this.linkId(a)||EditingToolbarXrefLinks.candidate(a.getAttribute('href')))?a:null;}
 hover(a) {
  if(a===this.anchor){clearTimeout(this.leaveTimer);return;}
  this.hide();if(!this.valid()||!getSelection()?.isCollapsed)return;
  this.anchor=a;this.anchorHref=a.getAttribute('href');this.activeId=this.linkId(a);const serial=this.serial,file=this.file,start=Date.now();
  this.load().then(()=>{
   if(serial!==this.serial||!this.valid(file))return;
   this.activeId=this.linkId(a);if(!this.records.has(this.activeId))return;
   this.timer=setTimeout(()=>{
    if(serial===this.serial&&this.valid(file)&&a.isConnected&&getSelection()?.isCollapsed&&(a.matches(':hover')||document.activeElement===a))this.show(this.records.get(this.activeId),a);
   },Math.max(0,300-(Date.now()-start)));
  });
 }
 leave() {clearTimeout(this.leaveTimer);this.leaveTimer=setTimeout(()=>this.hide(),220);}
 hide() {
  this.serial++;clearTimeout(this.timer);clearTimeout(this.leaveTimer);
  this.anchor?.removeAttribute('aria-describedby');this.anchor=null;this.activeId=null;
  if(this.popup)this.popup.hidden=true;
 }
 makePopup() {
  if(this.popup)return;
  const popup=document.createElement('aside');popup.id=this.popupId;popup.className='et-citation-preview';popup.etCitationOwner=this;popup.hidden=true;popup.setAttribute('role','dialog');popup.setAttribute('aria-label','参考文献');
  popup.innerHTML='<div class="et-citation-body"><p class="et-citation-text"></p><div class="et-citation-links"></div></div>';
  document.body.append(popup);this.popup=popup;
  this.sizeObserver=new ResizeObserver(()=>{if(!popup.hidden)this.place();});
  this.sizeObserver.observe(popup.querySelector('.et-citation-body'));
  popup.addEventListener('pointerenter',()=>clearTimeout(this.leaveTimer));
  popup.addEventListener('pointerleave',()=>this.leave());
  popup.addEventListener('focusin',()=>clearTimeout(this.leaveTimer));
  popup.addEventListener('focusout',e=>{if(!popup.contains(e.relatedTarget))this.leave();});
  for(const type of ['pointerdown','mousedown','click','keydown'])popup.addEventListener(type,e=>e.stopPropagation());
 }
 show(record,a) {
  if(!record)return;this.makePopup();for(const other of [this.toolbar.citationPreview,this.toolbar.splitView?.citationPreview])if(other&&other!==this)other.hide();this.toolbar.annotations?.hoverPreview?.hide();this.toolbar.hide();
  const serial=this.serial,file=this.file,isCurrent=()=>serial===this.serial&&this.valid(file)&&a.isConnected;
  const body=this.popup.querySelector('.et-citation-body');body.replaceChildren();body.scrollTop=0;body.scrollLeft=0;
  this.popup.classList.toggle('et-xref-media',!!record.kind);
  this.popup.setAttribute('aria-label',record.kind==='figure'?'图预览':record.kind==='table'?'表预览':'参考文献');
  if(record.kind){
   const content=document.createElement('div');content.className='et-xref-content';body.append(content);
   try{if(!this.media.render(content,record,isCurrent))return this.hide();}catch(error){console.warn('[EditingToolbar] Figure/table preview:',error);return this.hide();}
   if(!isCurrent())return;
  }else{
   const text=document.createElement('p');text.className='et-citation-text';text.textContent=record.text;body.append(text);
   const links=document.createElement('div');links.className='et-citation-links';body.append(links);
   for(const url of record.urls){const link=document.createElement('a');link.href=url;link.textContent=url;link.addEventListener('click',e=>{e.preventDefault();File.editor.tryOpenUrl(url);});links.append(link);}
   links.hidden=!links.childElementCount;
  }
  this.popup.hidden=false;a.setAttribute('aria-describedby',this.popup.id);this.place();
 }
 place() {
  const a=this.anchor;if(!a?.isConnected||!this.popup||this.popup.hidden)return;
  const r=a.getBoundingClientRect();
  // Keep previews in the reading column; docked AI/notes panels have their own stacking layer.
  const column=(this.context?.scroller()||this.write)?.getBoundingClientRect(),left=Math.max(8,column?.left||0),right=Math.min(innerWidth-8,column?.right||innerWidth-8);
  const viewport=(this.context?.scroller()||(this.toolbar.splitView?.enabled?this.write?.closest('content'):null))?.getBoundingClientRect(),topBound=Math.max(8,viewport?viewport.top+8:8),bottomBound=Math.min(innerHeight-8,viewport?viewport.bottom-8:innerHeight-8);
  this.popup.style.maxWidth=Math.max(80,right-left)+'px';
  this.popup.style.maxHeight=Math.max(40,Math.min(this.popup.classList.contains('et-xref-media')?640:440,bottomBound-topBound,Math.max(r.top-topBound-8,bottomBound-r.bottom-8)))+'px';
  const p=this.popup.getBoundingClientRect(),top=r.bottom+8+p.height<=bottomBound?r.bottom+8:r.top-p.height-8;
  Object.assign(this.popup.style,{left:Math.max(left,Math.min(r.left,right-p.width))+'px',top:Math.max(topBound,Math.min(top,bottomBound-p.height))+'px'});
 }
 async click(event) {
  const a=this.link(event.target);if(!a||event.button!==0||event.altKey||event.shiftKey||!this.valid())return;
  if(this.down&&event.detail&&Math.hypot(event.clientX-this.down.x,event.clientY-this.down.y)>6)return;
  if(!getSelection()?.isCollapsed&&!event.ctrlKey&&!event.metaKey)return;
  const href=a.getAttribute('href'),file=this.file;event.preventDefault();event.stopImmediatePropagation();this.hide();const serial=this.serial;
  await this.load();if(!this.valid(file)||serial!==this.serial||!a.isConnected||!this.write.contains(a))return;
  const id=this.linkId(a);if(!this.records.has(id)){if(this.context)this.context.openLink(href);else File.editor.tryOpenUrl(href);return;}
  this.navigate(id,file);
 }
 blockText(el) {
  const clone=el.cloneNode(true);
  clone.querySelectorAll('.md-meta,.md-url,.md-link-title,.md-before,.md-after,script,style').forEach(n=>n.remove());
  return this.normalize(clone.textContent||'');
 }
 blocks() {
  if(!this.blockCache)this.blockCache=[...this.write.querySelectorAll(this.context?'p,li':'p[cid],li[cid]')].filter(el=>!el.closest('pre,code,.md-fences,.md-toc,.md-htmlblock')).map(el=>({el,key:this.blockText(el)}));
  return this.blockCache;
 }
 locate(record) {
  const anchor=this.context?[...this.write.querySelectorAll('[data-preview-anchor]')].find(n=>n.dataset.previewAnchor===record.id):[...this.write.querySelectorAll('[id]')].find(n=>n.id===record.id);if(anchor)return anchor.closest(this.context?'p,li':'[cid]')||anchor;
  if(record.kind)return this.media.locate(record);
  if(record.key.length<32)return null;
  const matches=this.blocks().filter(b=>b.el.isConnected&&b.key.includes(record.key));
  if(matches.length===1)return matches[0].el;
  // Restrict duplicates in quoted body passages to the actual bibliography section.
  const heading=[...this.write.querySelectorAll('h1,h2,h3,h4,h5,h6')].find(el=>/^(?:\d+[.\s]*)?(?:参考文献|references|bibliography)$/i.test(el.textContent.trim()));
  const refs=heading?matches.filter(b=>heading.compareDocumentPosition(b.el)&Node.DOCUMENT_POSITION_FOLLOWING):[];
  return refs.length===1?refs[0].el:null;
 }
 navigate(id,file) {
  if(!this.valid(file))return;const record=this.records.get(id);if(!record)return;
  this.hide();const target=this.locate(record);
  if(!target){this.toolbar._showToolbarNotice(record.kind?'对应图表已更改或不存在，暂时无法准确定位。':'文末对应条目已更改或不存在，暂时无法准确定位。');return;}
  if(!this.context)this.toolbar.readingPosition?.cancelRestore();this.toolbar.hide();File.editor.contextMenu?.hide();
  const scroller=this.context?this.context.scroller():this.write.closest('content')||document.scrollingElement,r=scroller.getBoundingClientRect();
  const bar=this.toolbar.topHost?.getBoundingClientRect(),offset=Math.max(28,bar&&bar.width&&bar.bottom<innerHeight/2?bar.bottom-r.top+20:28);
  scroller.scrollTo({top:Math.max(0,scroller.scrollTop+target.getBoundingClientRect().top-r.top-offset),behavior:'instant'});
  this.clearMark();
  if(window.Highlight&&CSS.highlights){const range=document.createRange();range.selectNodeContents(target);CSS.highlights.set(this.markKey,new Highlight(range));this.markTimer=setTimeout(()=>this.clearMark(),2200);}
 }
 clearMark(){clearTimeout(this.markTimer);if(window.CSS?.highlights)CSS.highlights.delete(this.markKey);}
}

