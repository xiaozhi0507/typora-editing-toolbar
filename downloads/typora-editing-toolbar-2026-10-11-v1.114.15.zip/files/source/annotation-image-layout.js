import {Plugin} from 'prosemirror-state';
import {Decoration,DecorationSet} from 'prosemirror-view';

export const imageWrapModes=[
 ['inline','嵌入','与文字排在同一行'],
 ['square','四周','文字绕开图片的矩形边界'],
 ['tight','紧密','文字沿透明图片的外轮廓排列'],
 ['through','穿越','文字进入朝向文字一侧的透明凹口'],
 ['top-bottom','上下','图片独占一行，文字在上方和下方'],
 ['front','衬于文字上方','图片覆盖文字，不挤开段落'],
 ['behind','衬于文字下方','文字显示在图片上面']
];
export const floatingWrap=wrap=>['square','tight','through'].includes(wrap);
export const imageRotation=value=>{const n=Number(value);return Number.isFinite(n)?Math.round(((n%360+360)%360)*10)%3600/10:0;};
export function imageLayout(attrs={}){
 const wrap=imageWrapModes.some(([id])=>id===attrs.wrap)?attrs.wrap:'inline';
 const side=['left','center','right'].includes(attrs.side)?attrs.side:'left';
 return {wrap,side:wrap==='inline'||(floatingWrap(wrap)&&side==='center')?'left':side};
}
export function imageLayoutStyle(attrs){
 const {wrap,side}=imageLayout(attrs);
 if(floatingWrap(wrap))return 'float:'+side+';margin:0 '+(side==='left'?'12px 8px 0':'0 8px 12px')+';'+(wrap==='through'?'shape-outside:url('+attrs.src+');shape-margin:6px;':'');
 if(wrap==='top-bottom')return 'display:block;clear:both;margin:8px '+(side==='center'?'auto':side==='right'?'0 8px auto':'auto 8px 0')+';';
 // Other Markdown readers have no paragraph anchor model. Keep those images
 // visible in normal flow there; this editor restores layers from data attrs.
 if(wrap==='front'||wrap==='behind')return 'vertical-align:middle;';
 return '';
}
// The anchor paragraph must not reserve a blank text line before following prose.
// Decorations are editor-only and never enter saved Markdown or clipboard text.
export function imageLayoutPlugin(){
 const build=doc=>{const result=[];doc.descendants((node,pos)=>{
  if(node.type.name!=='paragraph'||node.childCount!==1||node.firstChild.type.name!=='image')return;
  const {wrap}=imageLayout(node.firstChild.attrs);
  if(wrap!=='inline'&&wrap!=='top-bottom')result.push(Decoration.node(pos,pos+node.nodeSize,{class:'note-image-anchor'}));
 });return DecorationSet.create(doc,result);};
 const plugin=new Plugin({state:{init:(_,s)=>build(s.doc),apply:(tr,old)=>tr.docChanged?build(tr.doc):old},props:{decorations:s=>plugin.getState(s)}});return plugin;
}

// Sample the alpha channel once per node view, never during pointer movement.
// Tight uses the convex outer contour; through retains open concave scanlines.
export function imageContours(img,rotation=0){
 if(!img.naturalWidth||!img.naturalHeight)return null;
 try{
  const a=rotation*Math.PI/180,c=Math.abs(Math.cos(a)),s=Math.abs(Math.sin(a));
  const bw=img.naturalWidth*c+img.naturalHeight*s,bh=img.naturalWidth*s+img.naturalHeight*c;
  const ratio=Math.min(1,256/Math.max(bw,bh));
  const w=Math.max(1,Math.ceil(bw*ratio)),h=Math.max(1,Math.ceil(bh*ratio));
  const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;
  const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.translate(w/2,h/2);ctx.rotate(a);ctx.drawImage(img,-img.naturalWidth*ratio/2,-img.naturalHeight*ratio/2,img.naturalWidth*ratio,img.naturalHeight*ratio);
  const rgba=ctx.getImageData(0,0,w,h).data,points=[],left=[],right=[];
  for(let y=0;y<h;y++){
   let lo=w,hi=-1;for(let x=0;x<w;x++)if(rgba[(y*w+x)*4+3]>20){lo=Math.min(lo,x);hi=x;}
   left.push(lo);right.push(hi+1);
   if(hi>=0)points.push([lo,y],[hi+1,y],[lo,y+1],[hi+1,y+1]);
  }
  if(!points.length)return null;
  const cross=(o,a,b)=>(a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0]);
  points.sort((a,b)=>a[0]-b[0]||a[1]-b[1]);
  const lower=[],upper=[];for(const p of points){while(lower.length>1&&cross(lower.at(-2),lower.at(-1),p)<=0)lower.pop();lower.push(p);}
  for(const p of points.slice().reverse()){while(upper.length>1&&cross(upper.at(-2),upper.at(-1),p)<=0)upper.pop();upper.push(p);}
  const polygon=ps=>'polygon('+ps.map(([x,y])=>(100*x/w).toFixed(3)+'% '+(100*y/h).toFixed(3)+'%').join(',')+') border-box';
  const edge=side=>{
   const ps=side==='left'?[[0,0]]:[[w,0]],xs=side==='left'?right:left;
   for(let y=0;y<h;y++)ps.push([xs[y],y],[xs[y],y+1]);
   ps.push([side==='left'?0:w,h]);return polygon(ps);
  };
  const outline=[];for(let y=0;y<h;y++)if(right[y])outline.push([left[y],y],[left[y],y+1]);for(let y=h-1;y>=0;y--)if(right[y])outline.push([right[y],y+1],[right[y],y]);
  return {tight:polygon(lower.slice(0,-1).concat(upper.slice(0,-1))),left:edge('left'),right:edge('right'),outline:polygon(outline)};
 }catch(_){return null;}
}
