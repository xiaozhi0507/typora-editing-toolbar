'use strict';

// Markdown-native context types. Legacy names keep exported prompts portable.
class ETAIPrompts {
  static types = [
    ['abstractPagesText', '摘要', '读取摘要标题下的内容；未找到时不会用正文替代。'],
    ['text', '选中文字', '使用打开助手时保留的正文选区。'],
    ['pageText', '当前章节', '使用光标所在章节，可手动切换。'],
    ['pagesText', '多个章节', '勾选需要阅读的章节，重叠内容只发送一次。'],
    ['pageImage', '图片', '扫描当前 Markdown 的图片或从电脑选择；需要支持图片输入的模型。'],
    ['fullText', '全文', '使用当前 Markdown 文档的完整内容。'],
    ['noteText', '笔记', '选择当前文档的一篇笔记。'],
    ['quickFill', '跟随对话', '保留当前资料范围，作为快捷命令发送；不在输入框展示提示词正文。']
  ];
  static scopes = { abstractPagesText: 'abstract', text: 'selection', pageText: 'section', pagesText: 'sections', pageImage: 'image', fullText: 'document', noteText: 'note' };
  static providers = [
  {
    "id": "custom",
    "name": "自定义",
    "url": "",
    "protocol": "openai-chat",
    "hint": "填写该服务商已开通的模型 ID"
  },
  {
    "id": "openai",
    "name": "OpenAI Chat",
    "url": "https://api.openai.com/v1/chat/completions",
    "protocol": "openai-chat",
    "hint": "填写该服务商已开通的模型 ID"
  },
  {
    "id": "deepseek",
    "name": "DeepSeek",
    "url": "https://api.deepseek.com/v1/chat/completions",
    "protocol": "openai-chat",
    "hint": "填写该服务商已开通的模型 ID"
  },
  {
    "id": "mimo",
    "name": "Xiaomi MiMo",
    "url": "https://api.xiaomimimo.com/v1/chat/completions",
    "protocol": "openai-chat",
    "hint": "填写该服务商已开通的模型 ID"
  },
  {
    "id": "kimi",
    "name": "Kimi",
    "url": "https://api.moonshot.cn/v1/chat/completions",
    "protocol": "openai-chat",
    "hint": "填写该服务商已开通的模型 ID"
  },
  {
    "id": "qwen",
    "name": "Qwen",
    "url": "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
    "protocol": "openai-chat",
    "hint": "填写该服务商已开通的模型 ID"
  },
  {
    "id": "zhipu",
    "name": "GLM",
    "url": "https://open.bigmodel.cn/api/paas/v4/chat/completions",
    "protocol": "openai-chat",
    "hint": "填写该服务商已开通的模型 ID"
  },
  {
    "id": "doubao",
    "name": "Doubao",
    "url": "https://ark.cn-beijing.volces.com/api/v3/chat/completions",
    "protocol": "openai-chat",
    "hint": "填写已开通的模型 ID 或 ep- 接入点 ID"
  },
  {
    "id": "minimax",
    "name": "MiniMax",
    "url": "https://api.minimax.cn/v1/chat/completions",
    "protocol": "openai-chat",
    "hint": "填写该服务商已开通的模型 ID"
  },
  {
    "id": "minimax-global",
    "name": "MiniMax Global",
    "url": "https://api.minimax.io/v1/chat/completions",
    "protocol": "openai-chat",
    "hint": "填写该服务商已开通的模型 ID"
  },
  {
    "id": "openai-responses",
    "name": "OpenAI Responses",
    "url": "https://api.openai.com/v1/responses",
    "protocol": "openai-responses",
    "hint": "填写该服务商已开通的模型 ID"
  },
  {
    "id": "anthropic",
    "name": "Anthropic",
    "url": "https://api.anthropic.com/v1/messages",
    "protocol": "anthropic-messages",
    "hint": "填写该服务商已开通的模型 ID"
  }
];
  static defaults() {
    return [
      ['分析文献', 'abstractPagesText', '根据所提供的摘要，梳理研究问题、方法、主要发现和局限。摘要中未说明的信息请明确标为未说明。'],
      ['提出问题', 'abstractPagesText', '根据这份摘要提出五个值得深入阅读和讨论的问题，并说明各问题对应的原文依据。'],
      ['翻译', 'text', '忠实地将所选文字翻译成中文，保留术语、公式、引用和原文结构，只输出译文。'],
      ['解释', 'text', '用通俗中文解释所选文字，先讲直觉，再说明关键术语和公式，区分原文与推断。'],
      ['概括', 'text', '概括所选文字的核心观点、论据和结论，不增加原文未提供的信息。'],
      ['改写', 'text', '润色所选文字，使表述清楚、连贯，保持原意、事实、引用与公式不变。直接输出改写后的文字。'],
      ['总结本章', 'pageText', '总结本章的逻辑结构、核心概念和主要结论，保留重要公式并解释变量含义。'],
      ['翻译本章', 'pageText', '完整地将本章翻译成中文，保留标题层级、公式、引用及原文结构。'],
      ['部分总结', 'pagesText', '综合所选章节，梳理各章节的联系、主要观点及差异，并注明依据来自哪个章节。'],
      ['解读图片', 'pageImage', '解释图片中的文字、图表或公式。先描述看见的内容，再解释含义；无法看清之处请明确说明。'],
      ['全文总结', 'fullText', '总结全文的主题、结构、关键论据、结论和局限；区分作者观点与推断。'],
      ['提升写作', 'noteText', '改进这篇笔记的清晰度、结构与衔接，保持事实和原意不变。使用中文，直接输出改写结果。'],
      ['自由提问', 'quickFill', '请根据当前资料回答：']
    ].map(([name, type, prompt], i) => ({ id: 'builtin-' + i, name, type, prompt }));
  }
  static normalize(value) {
    if (!Array.isArray(value)) return this.defaults();
    const seen = new Set();
    return value.filter(p => p && typeof p.name === 'string' && typeof p.prompt === 'string' && this.types.some(t => t[0] === p.type)).map((p, i) => {
      let id = typeof p.id === 'string' ? p.id : 'prompt-' + i;
      if (seen.has(id)) id += '-' + i; seen.add(id);
      return { id, name: p.name.slice(0, 60), type: p.type, prompt: p.prompt.slice(0, 16000) };
    });
  }
  static sections(markdown) {
    const text = String(markdown), lines = text.split(/\n/), sections = [];
    let offset = 0, fence = '', yaml = /^---\s*\r?$/.test(lines[0]), yamlDone = !yaml;
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i], start = offset; offset += line.length + 1;
      if (!yamlDone) { if (i > 0 && /^(---|\.\.\.)\s*\r?$/.test(line)) yamlDone = true; continue; }
      const f = line.match(/^\s{0,3}(`{3,}|~{3,})/);
      if (f) { if (!fence) fence = f[1]; else if (f[1][0] === fence[0] && f[1].length >= fence.length) fence = ''; continue; }
      if (fence) continue;
      let m = line.match(/^ {0,3}(#{1,6})\s+(.+?)\s*#*\s*\r?$/), level, title;
      if (m) { level = m[1].length; title = m[2]; }
      else if (line.trim() && !/^\s*[>|]/.test(line) && /^(?: {0,3})(=+|-+)\s*\r?$/.test(lines[i + 1] || '')) { level = lines[i + 1].trim()[0] === '=' ? 1 : 2; title = line.trim(); }
      else continue;
      sections.push({ id: String(start), start, level, title: title.replace(/[*_`]/g, '') });
    }
    for (let i = 0; i < sections.length; i++) {
      sections[i].end = sections.slice(i + 1).find(s => s.level <= sections[i].level)?.start ?? text.length;
    }
    return sections;
  }
  static excerpt(markdown, sections, ids) {
    const ranges = sections.filter(s => ids.includes(s.id)).sort((a, b) => a.start - b.start), merged = [];
    for (const r of ranges) { const last = merged.at(-1); if (last && r.start < last.end) last.end = Math.max(last.end, r.end); else merged.push({ ...r }); }
    return merged.map(r => markdown.slice(r.start, r.end).trim()).join('\n\n');
  }
  static abstract(markdown, sections = this.sections(markdown)) {
    const section = sections.find(s => /^(?:\d+[.、\s]*)?(?:abstract|摘要|内容摘要|摘\s+要)(?:\s|[:：]|$)/i.test(s.title));
    if (section) return markdown.slice(section.start, section.end).trim();
    const inline = markdown.match(/^(?:\*\*)?(?:Abstract|摘要|摘\s+要)(?:\*\*)?\s*[:：]\s*(.+(?:\n(?!\s*$|#{1,6}\s|(?:关键词|Keywords)\b).+)*)/im);
    return inline ? inline[0].trim() : '';
  }
}
module.exports = ETAIPrompts;
