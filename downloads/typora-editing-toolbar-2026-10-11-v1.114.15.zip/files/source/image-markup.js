// Reading-mode image annotations. Original assets are never overwritten; applying
// swaps one source token through Typora's existing undo-aware model transaction.
class EditingToolbarImageMarkup {
 constructor(toolbar){
  this.toolbar=toolbar;this.fs=reqnode('fs');this.path=reqnode('path');this.tool='pen';this.shape='rect';this.color='#ef4444';this.strokeSize=4;this.textSize=28;this.eraseSize=18;this.bold=false;
  this.backgroundKey='et-image-markup-transparency-v1';this.backgroundTransparency=this.readBackground();
  window.addEventListener('storage',e=>{if(e.key===this.backgroundKey){this.backgroundTransparency=this.readBackground();if(this.root)this.syncBackground();}});
  window.addEventListener('dblclick',e=>{const img=e.target.closest?.('#write img');if(!img||!toolbar.readingMode?.enabled||document.body.classList.contains('typora-sourceview-on'))return;e.preventDefault();e.stopImmediatePropagation();this.open(img);},true);
 }
 static icons={pen:'<path d="M4 17c3-7 5-13 8-13 4 0-7 15-3 15 3 0 7-12 9-11 2 1-5 10-1 10 1 0 3-2 4-3"/>',text:'<path d="M5 5h14M12 5v15M8 20h8M5 5v3M19 5v3"/>',shapes:'<rect x="3" y="3" width="12" height="12" rx="3"/><rect x="9" y="9" width="12" height="12" rx="3"/>',erase:'<path d="m4 13 9-9a2 2 0 0 1 3 0l5 5a2 2 0 0 1 0 3l-9 9H8l-4-4a3 3 0 0 1 0-4ZM8 9l9 9M12 21h9"/>',undo:'<path d="m8 4-5 5 5 5M3 9h11a6 6 0 0 1 0 12h-4"/>',redo:'<path d="m16 4 5 5-5 5M21 9H10a6 6 0 0 0 0 12h4"/>',history:'<path d="M3 10a9 9 0 1 1 2 8M3 4v6h6M12 7v6l4 2"/>',close:'<path d="m6 6 12 12M18 6 6 18"/>',line:'<path d="m5 19 14-14"/>',arrow:'<path d="m5 19 14-14M8 5h11v11"/>',rect:'<rect x="4" y="4" width="16" height="16" rx="1"/>',ellipse:'<circle cx="12" cy="12" r="8"/>',triangle:'<path d="m12 4 9 16H3Z"/>',diamond:'<path d="m12 3 9 9-9 9-9-9Z"/>',star:'<path d="m12 3 3 6 6 1-5 5 1 6-5-3-5 3 1-6-5-5 6-1Z"/>',heart:'<path d="M12 20 4 12C-1 5 8 0 12 7c4-7 13-2 8 5Z"/>',image:'<rect x="3" y="3" width="18" height="18" rx="3"/><path d="m4 18 6-6 4 4 3-3 4 4"/><circle cx="8" cy="8" r="1"/>',check:'<path d="m5 12 4 4L19 6"/>'};
 icon(name){return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+EditingToolbarImageMarkup.icons[name]+'</svg>';}
 node(tag,cls,text){const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;}
 button(action,label,icon=action){const b=this.node('button','im-button');b.type='button';b.dataset.im=action;b.title=label;b.setAttribute('aria-label',label);b.innerHTML=this.icon(icon);return b;}
 readBackground(){try{const value=localStorage.getItem(this.backgroundKey),number=Number(value);return value?.trim()&&Number.isFinite(number)?Math.max(0,Math.min(100,Math.round(number))):50;}catch{return 50;}}
 buildBackground(){
  this.backgroundControl=this.node('div','im-background-control');
  this.backgroundControl.innerHTML='<button type="button" class="im-background-toggle" data-im="background" title="背景透明度" aria-label="背景透明度" aria-expanded="false" aria-controls="im-background-popover"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><path d="M12 3.5a8.5 8.5 0 0 1 0 17Z" fill="currentColor" fill-opacity=".4" stroke="none"/></svg><span>背景</span></button><div class="im-background-popup" id="im-background-popover" hidden><div class="im-background-heading"><label for="im-background-range">背景透明度</label><output for="im-background-range">50%</output></div><input id="im-background-range" type="range" min="0" max="100" step="1" value="50" aria-label="背景透明度"><div class="im-background-scale"><span>不透明</span><span>全透明</span></div><button type="button" data-im="background-reset">恢复 50%</button><span class="im-background-note" role="status" hidden></span></div>';
  this.root.querySelector('.im-header-actions').insertBefore(this.backgroundControl,this.root.querySelector('[data-im=apply]'));
  this.backgroundButton=this.backgroundControl.querySelector('[data-im=background]');this.backgroundPopup=this.backgroundControl.querySelector('.im-background-popup');this.backgroundRange=this.backgroundControl.querySelector('input');this.backgroundOutput=this.backgroundControl.querySelector('output');this.backgroundNote=this.backgroundControl.querySelector('.im-background-note');
  this.backgroundRange.oninput=()=>{this.backgroundTransparency=Number(this.backgroundRange.value);this.syncBackground();};
  this.backgroundRange.onchange=()=>this.saveBackground();
  this.backgroundRange.onpointerup=()=>{if(this.backgroundTextFocus&&this.textarea)this.textarea.focus({preventScroll:true});};
  this.syncBackground();
 }
 syncBackground(){this.root.style.setProperty('--im-bg-opacity',(100-this.backgroundTransparency)+'%');this.backgroundRange.value=this.backgroundTransparency;this.backgroundOutput.textContent=this.backgroundTransparency+'%';this.backgroundRange.setAttribute('aria-valuetext',this.backgroundTransparency+'% 透明');}
 saveBackground(){try{localStorage.setItem(this.backgroundKey,String(this.backgroundTransparency));this.backgroundNote.hidden=true;}catch{this.backgroundNote.textContent='本次有效，设置未能保存';this.backgroundNote.hidden=false;}}
 setBackgroundOpen(open,returnFocus=false){this.backgroundPopup.hidden=!open;this.backgroundButton.setAttribute('aria-expanded',String(open));if(!open){if(returnFocus)(this.backgroundTextFocus&&this.textarea?this.textarea:this.backgroundButton).focus({preventScroll:true});this.backgroundTextFocus=false;}}
 buildZoom(){
  this.zoomControl=this.root.querySelector('.im-zoom-control');
  this.zoomControl.innerHTML='<button type="button" class="im-zoom-toggle" data-im="zoom" aria-label="图片缩放" aria-haspopup="listbox" aria-expanded="false" aria-controls="im-zoom-menu"><span>—</span><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m4 6 4 4 4-4"/></svg></button><div class="im-zoom-menu" id="im-zoom-menu" role="listbox" aria-label="缩放比例" hidden></div>';
  this.zoom=this.zoomControl.querySelector('button');this.zoomLabel=this.zoom.querySelector('span');this.zoomMenu=this.zoomControl.querySelector('.im-zoom-menu');
  for(const [value,label]of [['0.25','25%'],['0.5','50%'],['1','100%'],['1.5','150%'],['2','200%'],['3','300%'],['fit','缩放至适合窗口']]){
   const item=this.node('button','im-zoom-option');item.type='button';item.dataset.im='zoom:'+value;item.dataset.value=value;item.tabIndex=-1;item.setAttribute('role','option');item.append(this.node('span','',label));item.insertAdjacentHTML('beforeend',this.icon('check'));this.zoomMenu.append(item);
  }
  this.zoomControl.addEventListener('focusout',e=>{if(!this.zoomControl.contains(e.relatedTarget))this.setZoomOpen(false);});
 }
 syncZoom(){this.zoomLabel.textContent=this.target&&this.scale?Math.round(this.scale*100)+'%':'—';this.zoom.title=(this.view==='fit'?'缩放至适合窗口 · ':'缩放 ')+this.zoomLabel.textContent;this.zoom.disabled=this.busy||!this.target;for(const item of this.zoomMenu.children)item.setAttribute('aria-selected',String(item.dataset.value===String(this.view)));}
 setZoomOpen(open,returnFocus=false){
  this.zoomMenu.hidden=!open;this.zoom.setAttribute('aria-expanded',String(open));
  if(open){this.popup.hidden=true;this.setBackgroundOpen(false);this.syncZoom();const current=this.zoomMenu.querySelector('[aria-selected=true]')||this.zoomMenu.firstElementChild;current.focus({preventScroll:true});current.scrollIntoView({block:'nearest'});}
  else if(returnFocus)this.zoom.focus({preventScroll:true});
 }
 zoomKey(e){
  if(!this.zoomControl.contains(e.target)||!['ArrowDown','ArrowUp','Home','End'].includes(e.key))return false;
  e.preventDefault();if(this.zoomMenu.hidden){this.setZoomOpen(true);if(e.key!=='Home'&&e.key!=='End')return true;}
  const items=[...this.zoomMenu.children],current=items.indexOf(document.activeElement),index=e.key==='Home'?0:e.key==='End'?items.length-1:(current+(e.key==='ArrowDown'?1:-1)+items.length)%items.length;
  items[index].focus({preventScroll:true});items[index].scrollIntoView({block:'nearest'});return true;
 }
 build(){
  if(this.root)return;
  const root=this.node('dialog');root.id='et-image-markup';root.setAttribute('aria-label','图片批注');
  root.innerHTML='<header class="im-header"><div class="im-title"><span class="im-image-icon"></span><strong>图片批注</strong></div><div class="im-header-actions"><div class="im-zoom-control"></div><button type="button" class="im-apply" data-im="apply">完成并替换</button></div></header><div class="im-stage"><div class="im-stage-inner"><div class="im-board"><img draggable="false" alt="原图"><svg class="im-layer" xmlns="http://www.w3.org/2000/svg"></svg></div></div></div><aside class="im-size"><div class="im-size-track"><i class="im-size-wedge" aria-hidden="true"></i><input type="range" min="1" max="32" value="4" step="1" aria-label="画笔粗细" orient="vertical"><output aria-hidden="true">4</output></div></aside><div class="im-tools-wrap"><div class="im-popup" hidden></div><div class="im-tools" role="toolbar" aria-label="图片批注工具"></div></div><footer class="im-footer"><span class="im-status" role="status" aria-live="polite"></span><span class="im-hint">滚轮缩放 · 空格拖动图片</span></footer><div class="im-confirm" hidden><div><strong>放弃这次批注？</strong><p>图片尚未替换，当前编辑步骤将被清除。</p><button type="button" data-im="continue">继续编辑</button><button type="button" data-im="discard">放弃修改</button></div></div>';
  this.root=root;this.stage=root.querySelector('.im-stage');this.inner=root.querySelector('.im-stage-inner');this.board=root.querySelector('.im-board');this.image=this.board.querySelector('img');this.layer=root.querySelector('.im-layer');this.range=root.querySelector('.im-size input');this.output=root.querySelector('.im-size output');this.status=root.querySelector('.im-status');this.popup=root.querySelector('.im-popup');this.tools=root.querySelector('.im-tools');this.confirm=root.querySelector('.im-confirm');
  root.querySelector('.im-image-icon').innerHTML=this.icon('image');root.querySelector('.im-header-actions').append(this.button('close','关闭图片批注'));this.buildZoom();this.buildBackground();
  for(const [action,label]of [['pen','画笔'],['text','文字'],['shapes','线条与形状']])this.tools.append(this.button(action,label));
  const color=this.node('label','im-color');color.title='批注颜色';color.innerHTML='<input type="color" aria-label="批注颜色"><span></span>';this.tools.append(color);this.colorInput=color.querySelector('input');this.colorInput.value=this.color;
  this.boldButton=this.node('button','im-button im-bold','B');this.boldButton.type='button';this.boldButton.dataset.im='bold';this.boldButton.title='文字加粗';this.boldButton.setAttribute('aria-label','文字加粗');this.tools.append(this.boldButton);
  this.tools.append(this.button('erase','橡皮：擦除整条批注'),this.node('i','im-divider'),this.button('undo','撤销（Ctrl+Z）'),this.button('redo','重做（Ctrl+Shift+Z）'),this.button('history','历史步骤'),this.node('i','im-divider'),this.button('close','关闭图片批注'));
  this.board.tabIndex=0;this.board.setAttribute('aria-label','图片绘制区域');document.body.append(root);
  root.addEventListener('cancel',e=>{e.preventDefault();this.escape();});
  root.addEventListener('click',e=>{if(!e.target.closest('.im-zoom-control'))this.setZoomOpen(false);if(!e.target.closest('.im-background-control'))this.setBackgroundOpen(false);const b=e.target.closest('[data-im]');if(b){e.preventDefault();this.action(b.dataset.im,b);}else if(!e.target.closest('.im-popup,.im-tools'))this.popup.hidden=true;});
  root.addEventListener('pointerdown',e=>{if(e.target.closest('.im-tools,.im-size'))this.lastTextFocus=this.textarea===document.activeElement;if(e.target.closest('.im-background-control')&&this.textarea===document.activeElement)this.backgroundTextFocus=true;});
  this.range.oninput=()=>{const size=Number(this.range.value);if(this.tool==='text')this.textSize=size;else if(this.tool==='erase')this.eraseSize=size;else this.strokeSize=size;this.sync();};
  this.sizeControl=this.range.closest('.im-size');
  this.range.onpointerdown=()=>this.sizeControl.classList.add('im-adjusting');
  this.range.onpointerup=()=>{this.sizeControl.classList.remove('im-adjusting');if(this.textarea&&this.lastTextFocus)this.textarea.focus({preventScroll:true});};
  this.range.onpointercancel=this.range.onlostpointercapture=()=>this.sizeControl.classList.remove('im-adjusting');
  this.colorInput.oninput=()=>{this.color=this.colorInput.value;this.sync();};
  this.board.addEventListener('pointerdown',e=>this.down(e));this.board.addEventListener('pointermove',e=>this.move(e));this.board.addEventListener('pointerup',e=>this.up(e));this.board.addEventListener('pointercancel',()=>this.cancelGesture());this.board.addEventListener('lostpointercapture',()=>this.cancelGesture());
  this.stage.addEventListener('wheel',e=>{e.preventDefault();if(this.gesture)return;this.commitText();this.view=Math.max(.1,Math.min(4,this.scale*Math.exp(-e.deltaY*.0015)));this.fit({x:e.clientX,y:e.clientY});},{passive:false});
  root.addEventListener('keydown',e=>this.key(e),true);root.addEventListener('keyup',e=>{if(e.code==='Space'){this.space=false;this.board.classList.remove('im-pan');}});
  window.addEventListener('blur',()=>{if(!this.root.open)return;this.cancelGesture();this.sizeControl.classList.remove('im-adjusting');this.space=false;this.board.classList.remove('im-pan');});
  new ResizeObserver(()=>{if(root.open&&!this.gesture)this.fit();}).observe(this.stage);
 }
 capture(img){
  const block=img.closest('[cid]'),editor=File.editor,node=block&&editor.getNode(block.getAttribute('cid'));if(!node)throw Error('暂不支持这张图片的位置');
  const source=node.get('text');if(typeof source!=='string')throw Error('图片源码暂时不可用');
  const span=img.closest('.md-image'),raw=n=>n.nodeType===3?n.textContent:typeof n.rawText==='function'?n.rawText(true):n.textContent;
  let start=0,end,token;
  if(span&&block.contains(span)){
   token=raw(span);for(let n=span;n!==block;n=n.parentNode){if(!n?.parentNode)throw Error('图片位置已改变');for(let p=n.previousSibling;p;p=p.previousSibling)start+=raw(p).length;}
   end=start+token.length;if(source.slice(start,end)!==token)throw Error('图片正在刷新，请稍后重试');
  }else{
   const all=[...source.matchAll(/<img\b(?:[^"'<>]|"[^"]*"|'[^']*')*>/gi)],index=[...block.querySelectorAll('img')].indexOf(img),match=all[index];if(!match)throw Error('暂不支持这张图片的位置');start=match.index;end=start+match[0].length;token=match[0];
  }
  // Typora omits alt/title on rendered reference images. Preserve the source
  // label verbatim and read the existing definition without modifying it.
  let markdownAlt;
  if(token.startsWith('![')){let depth=1;for(let i=2;i<token.length;i++){if(token[i]==='\\'){i++;continue;}if(token[i]==='[')depth++;if(token[i]===']'&&!--depth){markdownAlt=token.slice(2,i);break;}}}
  const ref=span?.getAttribute('data-ref'),definition=ref&&editor.nodeMap?.link_list?.getNodeByRef?.(ref);
  return {file:File.bundle?.filePath||'',cid:node.cid,source,start,end,token,markdownAlt,alt:img.alt||markdownAlt||'',title:img.title||definition?.get('title')||'',style:img.getAttribute('style')||'',html:/^<img\b/i.test(token.trim()),src:img.currentSrc||img.src};
 }
 async open(img){
  if(this.root?.open)return;this.build();this.previousFocus=document.activeElement;this.target=null;this.ops=[];this.history=[{label:'原图',ops:[]}];this.index=0;this.busy=true;this.view='fit';this.syncZoom();this.setZoomOpen(false);this.confirm.hidden=true;this.popup.hidden=true;this.setBackgroundOpen(false);this.root.showModal();this.status.textContent='正在读取图片…';this.layer.replaceChildren();this.image.removeAttribute('src');this.root.querySelector('[data-im=apply]').disabled=true;
  const job=this.job=(this.job||0)+1;
  try{
   this.target=this.capture(img);let src=this.target.src;
   if(/^file:/i.test(src)){const u=new URL(src);u.search='';u.hash='';const file=reqnode('url').fileURLToPath(u),stat=await this.fs.promises.stat(file);if(stat.size>40*1024*1024)throw Error('图片超过 40 MB，请使用较小的图片');const bytes=await this.fs.promises.readFile(file),ext=this.path.extname(file).slice(1).toLowerCase(),mime=({jpg:'jpeg',svg:'svg+xml'})[ext]||ext;if(!['png','jpeg','webp','gif','bmp','svg+xml','avif'].includes(mime))throw Error('不支持的图片类型');src='data:image/'+mime+';base64,'+bytes.toString('base64');}
   else if(!/^data:image\//i.test(src)){const response=await fetch(src);if(!response.ok)throw Error('远程图片读取失败');const blob=await response.blob();if(blob.size>40*1024*1024)throw Error('图片超过 40 MB');src=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(blob);});}
   const base=new Image();base.src=src;await base.decode();if(job!==this.job||!this.root.open)return;
   if(!base.naturalWidth||base.naturalWidth*base.naturalHeight>32e6)throw Error('图片像素过大，请使用不超过 3200 万像素的图片');
   this.base=base;this.w=base.naturalWidth;this.h=base.naturalHeight;this.image.src=src;this.layer.setAttribute('viewBox','0 0 '+this.w+' '+this.h);this.fit();this.busy=false;this.sync();this.board.focus({preventScroll:true});
  }catch(error){if(job===this.job){this.busy=false;this.target=null;this.status.textContent='无法打开图片：'+error.message;this.sync();}}
 }
 size(){return this.tool==='text'?this.textSize:this.tool==='erase'?this.eraseSize:this.strokeSize;}
 sync(){
  this.syncZoom();
  for(const b of this.tools.querySelectorAll('[data-im]'))b.setAttribute('aria-pressed',String(b.dataset.im===this.tool||b.dataset.im==='shapes'&&!['pen','text','erase'].includes(this.tool)));
  this.boldButton.hidden=this.tool!=='text';this.boldButton.setAttribute('aria-pressed',String(this.bold));
  this.tools.querySelector('[data-im=undo]').disabled=this.index<=0||this.busy;this.tools.querySelector('[data-im=redo]').disabled=this.index>=this.history.length-1||this.busy;this.tools.querySelector('[data-im=history]').disabled=this.busy;
  this.root.querySelector('[data-im=apply]').disabled=this.busy||!this.target||!this.ops.length&&!this.textarea?.value.trim();
  this.range.min=1;this.range.max=this.tool==='text'?96:this.tool==='erase'?64:32;this.range.step=this.tool==='text'?.5:1;this.range.value=this.size();this.range.setAttribute('aria-label',this.tool==='text'?'文字字号':this.tool==='erase'?'橡皮大小':'线条粗细');this.range.setAttribute('aria-valuetext',this.size()+' 像素');this.output.textContent=this.size();
  const ratio=(Number(this.range.max)-this.size())/(Number(this.range.max)-Number(this.range.min));this.output.style.top='calc('+ratio*100+'% + '+(9-ratio*18)+'px)';this.tools.querySelector('.im-color span').style.background=this.color;
  this.board.dataset.tool=this.tool;if(this.target&&!this.busy)this.status.textContent=(this.tool==='erase'?'橡皮会擦除整条批注':this.tool==='text'?'点击图片输入文字，Ctrl+Enter 完成':'在图片上拖动绘制，按住 Shift 约束方向')+' · '+this.index+' 步';
  if(this.textarea){Object.assign(this.textarea.style,{fontSize:this.textSize*this.scale+'px',fontWeight:this.bold?'700':'400',color:this.color});}
 }
 fit(anchor){
  if(!this.w||!this.root.open)return;const rect=this.stage.getBoundingClientRect(),old=this.scale||1,before=this.board.getBoundingClientRect();const point=anchor?{x:(anchor.x-before.left)/old,y:(anchor.y-before.top)/old}:null;
  this.scale=this.view==='fit'?Math.min(1,Math.max(.05,(rect.width-48)/this.w),Math.max(.05,(rect.height-48)/this.h)):this.view;
  Object.assign(this.board.style,{width:this.w*this.scale+'px',height:this.h*this.scale+'px'});Object.assign(this.inner.style,{width:(this.w*this.scale+48)+'px',height:(this.h*this.scale+48)+'px'});
  if(this.textarea){this.textarea.style.left=this.textPoint[0]*this.scale+'px';this.textarea.style.top=this.textPoint[1]*this.scale+'px';this.textarea.style.fontSize=this.textSize*this.scale+'px';}
  this.syncZoom();
  if(point){const after=this.board.getBoundingClientRect();this.stage.scrollLeft+=after.left+point.x*this.scale-anchor.x;this.stage.scrollTop+=after.top+point.y*this.scale-anchor.y;}
 }
 point(e){const r=this.gesture?.rect||this.board.getBoundingClientRect();return [Math.max(0,Math.min(this.w,(e.clientX-r.left)/this.scale)),Math.max(0,Math.min(this.h,(e.clientY-r.top)/this.scale))];}
 down(e){
  if(this.busy||!this.target||e.button!==0||e.target===this.textarea)return;e.preventDefault();this.popup.hidden=true;
  if(this.space){this.gesture={pan:true,id:e.pointerId,x:e.clientX,y:e.clientY,left:this.stage.scrollLeft,top:this.stage.scrollTop};this.board.setPointerCapture(e.pointerId);return;}
  this.commitText();this.board.focus({preventScroll:true});const p=this.point(e);if(this.tool==='text'){this.textPoint=p;const input=this.node('textarea','im-text');input.setAttribute('aria-label','图片批注文字');input.placeholder='输入文字';input.wrap='off';input.rows=2;Object.assign(input.style,{left:p[0]*this.scale+'px',top:p[1]*this.scale+'px',maxWidth:Math.max(80,(this.w-p[0])*this.scale)+'px'});this.board.append(input);this.textarea=input;input.oninput=()=>this.sync();this.sync();input.focus();return;}
  this.gesture={id:e.pointerId,rect:this.board.getBoundingClientRect(),previous:this.ops.slice()};
  if(this.tool==='erase')this.erase(p);else this.draft={kind:this.tool,color:this.color,size:this.strokeSize,x:p[0],y:p[1],x2:p[0],y2:p[1],points:[p]};
  this.board.setPointerCapture(e.pointerId);this.render();
 }
 move(e){
  const g=this.gesture;if(!g||g.id!==e.pointerId)return;e.preventDefault();if(g.pan){this.stage.scrollLeft=g.left-e.clientX+g.x;this.stage.scrollTop=g.top-e.clientY+g.y;return;}
  for(const event of e.getCoalescedEvents?.().length?e.getCoalescedEvents():[e]){const p=this.point(event);if(this.tool==='erase'){this.erase(p);continue;}const d=this.draft;if(!d)continue;
   if(d.kind==='pen'){const last=d.points[d.points.length-1];if(Math.hypot(last[0]-p[0],last[1]-p[1])>.4/this.scale)d.points.push(p);}else{let [x,y]=p;if(e.shiftKey){if(['line','arrow'].includes(d.kind)){const a=Math.round(Math.atan2(y-d.y,x-d.x)/(Math.PI/4))*Math.PI/4,length=Math.hypot(x-d.x,y-d.y);x=d.x+Math.cos(a)*length;y=d.y+Math.sin(a)*length;}else{const side=Math.max(Math.abs(x-d.x),Math.abs(y-d.y));x=d.x+Math.sign(x-d.x)*side;y=d.y+Math.sign(y-d.y)*side;}}d.x2=x;d.y2=y;}
  }
  if(!this.frame)this.frame=requestAnimationFrame(()=>{this.frame=0;this.render();});
 }
 up(e){const g=this.gesture;if(!g||g.id!==e.pointerId)return;this.move(e);this.gesture=null;if(this.board.hasPointerCapture(e.pointerId))this.board.releasePointerCapture(e.pointerId);if(!g.pan){if(this.draft){if(this.draft.kind==='pen'||Math.hypot(this.draft.x2-this.draft.x,this.draft.y2-this.draft.y)>1)this.ops=[...this.ops,this.draft];this.draft=null;}if(this.ops.length!==g.previous.length)this.commit(this.tool==='erase'?'橡皮擦除':this.label(this.tool));}this.render();}
 cancelGesture(){const g=this.gesture;if(!g)return;this.gesture=null;if(g.previous)this.ops=g.previous;this.draft=null;if(this.board.hasPointerCapture(g.id))this.board.releasePointerCapture(g.id);this.render();}
 erase(p){this.ops=this.ops.filter(op=>!ETImageMarkupModel.hit(op,p,this.eraseSize/2));}
 label(kind){return {pen:'画笔',text:'文字',line:'直线',arrow:'箭头',rect:'矩形',ellipse:'圆形',triangle:'三角形',diamond:'菱形',star:'星形',heart:'心形'}[kind]||kind;}
 render(){
  cancelAnimationFrame(this.frame);this.frame=0;
  if(!this.committedLayer?.isConnected){const ns='http://www.w3.org/2000/svg';this.committedLayer=document.createElementNS(ns,'g');this.draftLayer=document.createElementNS(ns,'g');this.layer.replaceChildren(this.committedLayer,this.draftLayer);this.renderedOps=null;}
  // During a pen stroke keep completed annotations intact; only redraw the draft.
  if(this.renderedOps!==this.ops){this.committedLayer.replaceChildren(...this.ops.map(op=>ETImageMarkupModel.svg(op)));this.renderedOps=this.ops;}
  this.draftLayer.replaceChildren(...(this.draft?[ETImageMarkupModel.svg(this.draft)]:[]));
 }
 commit(label){this.history=this.history.slice(0,this.index+1);this.history.push({label,ops:this.ops.slice()});this.index=this.history.length-1;this.sync();}
 commitText(){if(!this.textarea)return;const text=this.textarea.value.trim().slice(0,3000),[x,y]=this.textPoint;this.textarea.remove();this.textarea=null;if(text){this.ops=[...this.ops,{kind:'text',text,x,y,size:this.textSize,color:this.color,bold:this.bold}];this.commit('文字');this.render();}}
 goto(index){this.cancelGesture();this.commitText();if(index<0||index>=this.history.length)return;this.index=index;this.ops=this.history[index].ops.slice();this.render();this.sync();}
 action(action,b){
  if(action==='continue'){this.confirm.hidden=true;return;}if(action==='discard'){this.close();return;}if(!this.confirm.hidden)return;if(action==='close'){this.requestClose();return;}
  if(action==='background'){this.popup.hidden=true;this.setBackgroundOpen(this.backgroundPopup.hidden,!this.backgroundPopup.hidden);return;}
  if(action==='background-reset'){this.backgroundTransparency=50;this.syncBackground();this.saveBackground();return;}
  if(this.busy||!this.target)return;
  if(action==='zoom'){this.setZoomOpen(this.zoomMenu.hidden);return;}
  if(action.startsWith('zoom:')){const value=action.slice(5);if(![...this.zoomMenu.children].some(item=>item.dataset.value===value))return;this.commitText();this.view=value==='fit'?'fit':Number(value);this.fit();this.setZoomOpen(false,true);return;}
  if(['pen','text','erase'].includes(action)){this.commitText();this.tool=action;this.popup.hidden=true;this.sync();this.board.focus({preventScroll:true});return;}
  if(action==='bold'){this.bold=!this.bold;this.sync();this.textarea?.focus();return;}
  if(action==='undo'){this.commitText();this.goto(this.index-1);return;}if(action==='redo'){this.goto(this.index+1);return;}
  if(action==='shapes'){this.commitText();if(this.menu==='shapes'&&!this.popup.hidden){this.popup.hidden=true;return;}this.menu='shapes';this.popup.className='im-popup im-shapes';this.popup.replaceChildren();for(const kind of ['line','arrow','rect','ellipse','triangle','diamond','star','heart']){const item=this.button('shape:'+kind,this.label(kind),kind);item.setAttribute('aria-pressed',String(this.tool===kind));this.popup.append(item);}this.popup.hidden=false;return;}
  if(action.startsWith('shape:')){this.tool=this.shape=action.slice(6);this.popup.hidden=true;this.sync();this.board.focus({preventScroll:true});return;}
  if(action==='history'){this.commitText();if(this.menu==='history'&&!this.popup.hidden){this.popup.hidden=true;return;}this.menu='history';this.popup.className='im-popup im-history';this.popup.replaceChildren(this.node('strong','','历史步骤'));for(const [i,item]of this.history.entries()){const row=this.node('button','',i+' · '+item.label);row.type='button';row.dataset.im='step:'+i;row.setAttribute('aria-current',String(i===this.index));this.popup.append(row);}this.popup.hidden=false;this.popup.querySelector('[aria-current=true]')?.scrollIntoView({block:'nearest'});return;}
  if(action.startsWith('step:')){this.goto(Number(action.slice(5)));this.popup.hidden=true;return;}if(action==='apply')this.apply();
 }
 key(e){
  e.stopPropagation();if(e.key==='Escape'){e.preventDefault();this.escape();return;}if(this.busy||!this.confirm.hidden){if(e.ctrlKey||e.metaKey)e.preventDefault();return;}if(this.zoomKey(e))return;if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();this.apply();return;}if(e.target===this.textarea){if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();this.commitText();this.tools.querySelector('[data-im=text]').focus();}return;}
  if((e.ctrlKey||e.metaKey)&&['z','y'].includes(e.key.toLowerCase())){e.preventDefault();this.goto(this.index+(e.key.toLowerCase()==='y'||e.shiftKey?1:-1));return;}
  if(e.code==='Space'&&!e.target.matches('input,select,button')){e.preventDefault();this.space=true;this.board.classList.add('im-pan');}
 }
 escape(){if(this.saving)return;if(this.gesture){this.cancelGesture();return;}if(!this.confirm.hidden){this.confirm.hidden=true;return;}if(!this.zoomMenu.hidden){this.setZoomOpen(false,true);return;}if(!this.backgroundPopup.hidden){this.setBackgroundOpen(false,true);return;}if(!this.popup.hidden){this.popup.hidden=true;return;}if(this.textarea){this.textarea.remove();this.textarea=null;this.sync();return;}this.requestClose();}
 requestClose(){if(this.saving)return;if(this.ops.length||this.textarea?.value.trim()){this.confirm.hidden=false;this.confirm.querySelector('[data-im=continue]').focus();}else this.close();}
 close(){this.setZoomOpen(false);this.cancelGesture();this.sizeControl.classList.remove('im-adjusting');this.setBackgroundOpen(false);this.saveBackground();this.job++;this.textarea?.remove();this.textarea=null;this.root.close();this.image.removeAttribute('src');this.base=null;this.target=null;this.w=this.h=0;this.busy=false;this.previousFocus?.isConnected&&this.previousFocus.focus({preventScroll:true});}
 replacement(src){
  const t=this.target,escaped=src.replace(/&/g,'&amp;').replace(/"/g,'&quot;');
  if(t.html)return t.token.replace(/(\s+src\s*=\s*)(?:"[^"]*"|'[^']*'|[^\s>]+)/i,(_,prefix)=>prefix+'"'+escaped+'"');
  if(t.style){const img=document.createElement('img');img.setAttribute('src',src);img.alt=t.alt;if(t.title)img.title=t.title;img.setAttribute('style',t.style);return img.outerHTML;}
  return '!['+(t.markdownAlt??t.alt.replace(/[\\\[\]]/g,'\\$&'))+'](<'+src.replace(/>/g,'%3E')+'>'+(t.title?' '+JSON.stringify(t.title):'')+')';
 }
 assetSource(output,file){
  const relative=this.path.relative(this.path.dirname(file),output).replace(/\\/g,'/').split('/').map(encodeURIComponent).join('/');
  try{
   let resolved=File.editor.imgEdit.getAbsolutePath(relative);if(/^file:/i.test(resolved))resolved=reqnode('url').fileURLToPath(resolved);
   if(this.path.resolve(resolved).toLowerCase()===this.path.resolve(output).toLowerCase())return relative;
  }catch{}
  // A front-matter image root can override document-relative paths. Use an
  // unambiguous URL in that case rather than inserting a broken reference.
  return reqnode('url').pathToFileURL(output).href;
 }
 async png(){const canvas=document.createElement('canvas');canvas.width=this.w;canvas.height=this.h;const ctx=canvas.getContext('2d');ctx.drawImage(this.base,0,0);const svg=this.layer.cloneNode(true);svg.setAttribute('width',this.w);svg.setAttribute('height',this.h);const layer=new Image();layer.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(new XMLSerializer().serializeToString(svg));await layer.decode();ctx.drawImage(layer,0,0);return new Promise((resolve,reject)=>canvas.toBlob(b=>{if(b)b.arrayBuffer().then(a=>resolve(reqnode('buffer').Buffer.from(a)),reject);else reject(Error('图片合成失败'));},'image/png'));}
 async apply(){
  if(this.busy||!this.target)return;this.cancelGesture();this.commitText();if(!this.ops.length)return;const target=this.target;this.busy=this.saving=true;this.sync();this.status.textContent='正在生成并替换图片…';let output,created=false;
  const validate=()=>{if(File.bundle?.filePath!==target.file||!target.file)throw Error('请先保存当前 Markdown 文件，再进行图片批注');const n=File.editor.getNode(target.cid);if(!n||n.get('text')!==target.source)throw Error('图片所在段落已变化，请关闭后重新打开图片');return n;};
  try{
   validate();const data=await this.png(),dir=this.path.join(this.path.dirname(target.file),this.path.basename(target.file,this.path.extname(target.file))+'.assets');await this.fs.promises.mkdir(dir,{recursive:true});output=this.path.join(dir,'image-annotated-'+reqnode('crypto').randomUUID()+'.png');await this.fs.promises.writeFile(output,data,{flag:'wx'});created=true;
   const node=validate(),src=this.assetSource(output,target.file),replacement=this.replacement(src),text=target.source.slice(0,target.start)+replacement+target.source.slice(target.end);
   this.toolbar._commitFormattingChanges(File.editor,[{node,result:{text,mapOffset:offset=>offset<=target.start?offset:offset>=target.end?offset+replacement.length-(target.end-target.start):target.start+replacement.length}}]);
   this.busy=this.saving=false;this.close();this.toolbar._showToolbarNotice('图片已替换，保存文档后生效；可用撤销恢复原图。');
  }catch(error){if(created&&File.editor.getNode(target.cid)?.get('text')===target.source)await this.fs.promises.unlink(output).catch(()=>{});this.busy=this.saving=false;this.sync();this.status.textContent='未替换图片：'+error.message;}
 }
}
