// Large pastes are a presentation of the draft, never a truncated attachment.
class EditingToolbarAIDraft {
  constructor(ai) {this.ai=ai;this.folded='';this.quotes=new EditingToolbarAIQuotes(ai,()=>this.changed());this.media=new EditingToolbarAIInputMedia(ai,()=>this.changed());}
  mount() {
    const a=this.ai;this.quotes.mount(a.prompt);this.media.mount(a.prompt);this.card=a.node('div','et-ai-paste-card');this.card.hidden=true;
    this.expand=a.node('button','et-ai-paste-expand');this.expand.type='button';
    this.expand.innerHTML='<span class="et-ai-paste-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3H5a2 2 0 0 0-2 2v3m13-5h3a2 2 0 0 1 2 2v3M3 16v3a2 2 0 0 0 2 2h3m13-5v3a2 2 0 0 1-2 2h-3M8 8h8M8 12h8M8 16h5"/></svg></span>';
    const copy=a.node('span','et-ai-paste-copy');this.title=a.node('strong');copy.append(this.title,a.node('span','','在文本框中显示 ›'));this.expand.append(copy);
    this.remove=a.node('button','et-ai-paste-remove','×');this.remove.type='button';this.remove.title='移除粘贴内容';this.remove.setAttribute('aria-label',this.remove.title);
    this.card.append(this.expand,this.remove);a.prompt.before(this.card);
    this.expand.onclick=()=>{if((a.composerLocked?.()??a.busy))return;const text=this.text();this.folded='';a.prompt.value=text;this.changed();a.prompt.focus();a.prompt.setSelectionRange(text.length,text.length);};
    this.remove.onclick=()=>{if((a.composerLocked?.()??a.busy))return;this.folded='';this.changed();a.prompt.focus();};
    a.prompt.addEventListener('paste',e=>{
      if((a.composerLocked?.()??a.busy)||e.defaultPrevented)return;
      const text=e.clipboardData?.getData('text/plain');if(!text||(text.length<1200&&(text.length<360||text.split(/\r?\n/).length<12)))return;
      e.preventDefault();const input=a.prompt;let inserted;if(input.richEditor){input.richEditor.insertText(text);inserted=input.value;}else inserted=input.value.slice(0,input.selectionStart)+text+input.value.slice(input.selectionEnd);
      this.folded=this.folded?this.folded+'\n\n'+inserted:inserted;input.value='';this.changed();
    },true);
    this.observer=new ResizeObserver(entries=>{const {width,height}=entries[0].contentRect,key=width+':'+height;if(key!==this.bounds){this.bounds=key;this.resize();}});this.observer.observe(a.panel);
    this.sync();
  }
  text() {return this.folded+(this.folded&&this.ai.prompt.value?'\n\n':'')+this.ai.prompt.value;}
  snapshot() {return {skills:this.ai.skillsUI?.snapshot(),text:this.ai.prompt.value,folded:this.folded,webSearch:!!this.ai.webUI?.enabled,quotes:this.quotes.snapshot(),images:this.media.snapshot()};}
  restore(data,text='') {if(this.ai.webUI){this.ai.webUI.enabled=!!data?.webSearch;this.ai.webUI.sync();}this.quotes.restore(data?.quotes);this.media.restore(data?.images);this.folded=typeof data?.folded==='string'?data.folded:'';this.ai.prompt.value=typeof data?.text==='string'?data.text:text;this.ai.skillsUI?.restore(data?.skills);this.sync();}
  clear() {if(this.ai.webUI){this.ai.webUI.enabled=false;this.ai.webUI.sync();}this.media.clear();this.quotes.clear();this.folded='';this.ai.prompt.value='';this.ai.skillsUI?.clear();this.sync();}
  changed() {this.ai.status.hidden=true;this.sync();this.ai.composerUI.sync();this.ai.conversations.schedule();}
  sync() {
    this.quotes.sync();this.media.sync();this.ai.skillsUI?.sync();if(!this.card)return;this.card.hidden=!this.folded;
    this.title.textContent=this.folded.replace(/\s+/g,' ').trim().slice(0,90)||'粘贴的内容';
    this.expand.title='在文本框中显示 · '+this.folded.length.toLocaleString()+' 字符';this.expand.setAttribute('aria-label',this.expand.title);
    this.expand.disabled=this.remove.disabled=!!(this.ai.composerLocked?.()??this.ai.busy);this.resize();
  }
  resize() {
    if(this.frame)return;this.frame=requestAnimationFrame(()=>{this.frame=null;const input=this.ai.prompt;if(!input.getClientRects().length)return;
      // The message list can live in the navigation viewport. Reserve space for
      // controls, not the flexible reply viewport, when growing a multiline draft.
      const a=this.ai,occupied=[...a.chat.children].filter(e=>e!==a.messages&&!e.contains(a.messages)&&e.getClientRects().length).reduce((sum,e)=>{const s=getComputedStyle(e);return sum+e.getBoundingClientRect().height+(parseFloat(s.marginTop)||0)+(parseFloat(s.marginBottom)||0);},0)-input.getBoundingClientRect().height;
      const max=Math.max(34,Math.min(180,Math.floor(a.panel.clientHeight*.26),a.chat.clientHeight-occupied-36)),scroll=input.scrollTop;
      // scrollHeight rounds fractional line boxes; allow one pixel so an uncapped
      // rich draft does not acquire a scrollbar merely from font rounding.
      input.style.height='0px';const natural=input.scrollHeight,height=Math.max(34,Math.min(max,natural+(natural>34?1:0)));input.style.height=height+'px';input.scrollTop=scroll;
      this.ai.composerUI.followModel?.();if(this.ai.composerUI.menu!==this.ai.composerUI.modelMenu)this.ai.composerUI.positionMenu();
    });
  }
}
