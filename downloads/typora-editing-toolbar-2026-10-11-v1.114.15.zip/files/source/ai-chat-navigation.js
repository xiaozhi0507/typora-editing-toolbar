// Keep reading position independent of streamed Markdown and delayed image/math layout.
class EditingToolbarAIChatNavigation {
  constructor(ai) {
    this.ai=ai;this.following=true;
    this.viewport=ai.node('div','et-ai-messages-viewport');ai.messages.before(this.viewport);this.viewport.append(ai.messages);
    this.button=ai.node('button','et-ai-latest');this.button.type='button';this.button.hidden=true;
    this.button.innerHTML='<span class="et-ai-latest-dots" aria-hidden="true"><i></i><i></i><i></i></span><svg class="et-ai-latest-arrow" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4v16m-7-7 7 7 7-7"/></svg>';
    this.viewport.append(this.button);this.button.onclick=()=>this.latest();
    ai.messages.tabIndex=-1;
    this.measure();
    ai.messages.addEventListener('scroll',()=>{
      const m=ai.messages,resized=this.height!==m.scrollHeight||this.clientHeight!==m.clientHeight;
      if(this.atBottom())this.following=true;else if(!resized)this.following=false;
      this.measure();if(this.following&&!this.atBottom())this.schedule();this.update();
    },{passive:true});
    ai.messages.addEventListener('wheel',e=>{if(e.deltaY<0)this.following=false;},{passive:true});
    ai.messages.addEventListener('keydown',e=>{if(['ArrowUp','PageUp','Home'].includes(e.key))this.following=false;});
    ai.messages.addEventListener('touchmove',()=>{this.following=false;},{passive:true});
    ai.messages.addEventListener('pointerdown',e=>{if(e.clientX>=ai.messages.getBoundingClientRect().left+ai.messages.clientWidth)this.following=false;});
    this.observer=new ResizeObserver(()=>this.schedule());this.observer.observe(this.viewport);this.update();
  }
  atBottom() {const m=this.ai.messages;return m.scrollHeight-m.clientHeight-m.scrollTop<=4;}
  measure() {this.height=this.ai.messages.scrollHeight;this.clientHeight=this.ai.messages.clientHeight;}
  observe(turn) {this.observer.observe(turn.article);}
  schedule() {
    if(this.frame)return;
    this.frame=requestAnimationFrame(()=>{this.frame=null;if(this.following){this.ai.messages.scrollTop=this.ai.messages.scrollHeight;this.measure();}this.update();});
  }
  update() {
    const working=!!this.ai.busy,show=working&&this.ai.turns.length>0&&!this.following&&!this.atBottom();
    this.button.hidden=!show;
    this.button.classList.toggle('is-visible',show);this.button.dataset.working=String(working);
    this.button.setAttribute('aria-hidden',String(!show));this.button.tabIndex=show?0:-1;this.button.disabled=!show;
    const label=working?'正在生成，回到最新内容':'回到最新内容';this.button.title=label;this.button.setAttribute('aria-label',label);
  }
  latest() {this.following=true;this.ai.messages.scrollTop=this.ai.messages.scrollHeight;this.measure();this.update();this.schedule();}
  reveal(turn) {
    if(!this.ai.turns.includes(turn)||!turn.article?.isConnected)return false;
    this.following=false;const m=this.ai.messages,article=turn.article;
    article.tabIndex=-1;article.focus({preventScroll:true});
    m.scrollTop+=article.getBoundingClientRect().top-m.getBoundingClientRect().top-12;
    this.clearHighlight();this.highlight=article;article.classList.add('et-ai-turn-located');
    this.highlightTimer=setTimeout(()=>this.clearHighlight(),1600);this.update();return true;
  }
  clearHighlight() {clearTimeout(this.highlightTimer);this.highlight?.classList.remove('et-ai-turn-located');this.highlight=null;}
  reset() {this.clearHighlight();this.observer.disconnect();this.observer.observe(this.viewport);this.following=true;this.schedule();}
  current() {
    const m=this.ai.messages,edge=m.getBoundingClientRect().top+16;
    return this.ai.turns.find(t=>t.article?.isConnected&&t.article.getBoundingClientRect().bottom>edge)||this.ai.turns.at(-1);
  }
}
