# 科研绘图字体

AI 可以生成指定字体的绘图代码；实际渲染由所选项目 Python、Matplotlib 和该环境可访问的字体完成。Notebook 与项目脚本共用项目 Python 设置，模型名称并不决定输出字体。若代码明确指定 DejaVu Sans，安装了 Times New Roman 也不会自动切换。

## 检查与配置

在创建图形前运行：

```python
import matplotlib as mpl
from matplotlib import font_manager

font_path = font_manager.findfont(
    font_manager.FontProperties(family="Times New Roman"),
    fallback_to_default=False,
)
print("Times New Roman:", font_path)
mpl.rcParams.update({
    "font.family": "Times New Roman",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
})
```

`fallback_to_default=False` 会在缺少字体时报错，避免静默换成默认字体。之后重新创建并导出图形，已生成的图片不会随配置自动变化。Seaborn 主题或脚本中的局部 `fontfamily` / `FontProperties` 设置可能覆盖全局配置，应检查实际文本对象。

Times New Roman 不覆盖所有中文字符；中文标题应单独选择可用中文字体。数学公式由 MathText 或 TeX 设置决定，`mathtext.fontset="stix"` 提供接近 Times 的数学字形，但不能称为全部公式都使用 Times New Roman。

## 验证导出

PDF 可通过字体资源确认是否嵌入 TimesNewRomanPSMT；`pdf.fonttype=42` 用于嵌入 TrueType 字体。SVG 设置 `fonttype="none"` 保留可编辑文字，但打开 SVG 的设备仍需相应字体。PNG 已栅格化，不能单凭肉眼确定准确字体名称。

可对 AI 说明：

> 英文和数字统一使用 Times New Roman，运行前检查字体是否存在，并检查导出的 PDF 是否嵌入该字体；保持已有数据和布局。

模型能否看懂拖入的图还取决于所选服务是否支持图片输入；本功能负责构建图片附件，不会在拖放时调用模型。
