# 技能 ZIP 与 AI 插件

在 AI 助手设置中打开“技能”或“插件”。这两个页面使用相同的搜索、卡片与详情样式。

## 技能 ZIP

点击“添加”，选择 .zip / .md 文件，或拖入、粘贴本机路径。仍可通过“选择技能文件夹”导入目录。ZIP 中可以是根目录 SKILL.md，也可以包含多个独立技能目录。预览后勾选需要的技能，再添加。

安装会保留技能目录内的脚本、agents 配置、assets 与 references，并保存在 Typora 自己的数据目录中。源 ZIP 不变。重名会明确提示，不覆盖旧技能；预览后 ZIP 被修改时必须重新预览。预览不写入磁盘，安装失败清理本次副本。当前限制：压缩包 32 MiB、总解压内容 64 MiB、单文件 16 MiB、4000 文件、100 个技能。不支持加密、分卷、ZIP64、链接、路径越界或嵌套技能。

## 通过 Codex 连接 GitHub / Google Drive（v1.98.0）

两家插件均可在“已连接的账户 → 登录设置”选择“通过 Codex 连接（推荐）”。本机 Codex 必须安装并登录 ChatGPT；API Key 登录不能使用这一方式。已有一个授权账户时会直接验证并连接；多个账户时先选择，验证成功后才保存并显示“已连接 · Codex”。

若尚未授权，点击“在浏览器中管理授权”，在官方 ChatGPT 插件页面连接 GitHub 或 Google Drive。完成后回到 Typora 点击“刷新账户”，选择账户即可。连接另一个账户也通过此入口进行。无需创建自己的 OAuth 应用；授权由 Codex 管理，不再使用个人 Google Cloud 测试应用。服务端仍可能要求重新登录或授权，不能保证授权永久有效。

账户菜单支持重命名、重新连接、切换当前账户和断开。断开仅移除 Typora 的使用记录，不撤销 Codex 中的授权。若在 Codex 更换 ChatGPT 登录账户、删除授权或禁用插件，下一次读取会要求重新连接，不会自动换用其他账户。

现有聊天工具保持只读：GitHub 支持仓库列表、仓库信息、文件、Issue 搜索和 PR；Google Drive 支持搜索与文件内容读取（格式由官方连接器支持范围决定）。连接器的写入、共享、删除、云端发布和自动同步未开放。长结果超过 48000 字符会明确截断。该通道通过本机 app-server 的实际 MCP 工具执行；不额外发起模型推理，也不改变助手当前选用的模型。

“使用独立 OAuth”可切回下述原有方式。Codex 模式只在 plugins.json 保存账户显示资料、连接标识和登录身份校验摘要，独立授权 accounts.dpapi 的加密内容保持原样。不会读取或复制 Codex 的登录令牌，也不会打包用户账户数据。连接所需的短生命周期进程由 Typora 启动，完成、取消或超时后关闭；临时只读运行上下文不创建持久对话。

本版本以 Codex CLI 0.162.0-alpha.2 验证了两家的真实账户资料、GitHub 公开文件读取与 Drive 搜索。app-server 的相关接口仍可能随 Codex 更新发生变化；启动、权限或网络错误会提示重新检查或连接。参考 [Codex app-server 官方接口](https://learn.chatgpt.com/docs/app-server)。

## GitHub 独立 OAuth

在“插件 → GitHub → 已连接的账户”点击“连接账户”。选择“使用独立 OAuth”后，首次会打开一次性登录设置：在 [GitHub OAuth Apps](https://github.com/settings/applications/new) 创建自己的 OAuth App，应用名称可填 Typora AI Assistant，Homepage URL 填 `http://127.0.0.1`，Authorization callback URL 填 `http://127.0.0.1/oauth/callback`。复制 Client ID，并生成 Client secret 后填入向导；这里不是 GitHub 密码，也不是个人访问令牌。

点击“保存并登录”自动打开 GitHub 官方授权页；后续“连接账户”“连接另一个账户”“重新连接”都会直接打开系统浏览器。授权后回调本机，再通过 GitHub /user 验证身份，成功后自动显示头像、用户名。等待界面可以重新打开浏览器、取消或重试；不需要手工复制授权码。

默认只申请 read:user，支持公开仓库。如需私有仓库，在登录设置勾选“访问私有仓库”；GitHub 的 repo OAuth 权限也包含写入权限，当前 Typora 工具仍只执行读取。旧版本的个人访问令牌账户继续可用；更换 OAuth Client ID 只清除旧 OAuth 账户，保留个人令牌账户。

当前可在聊天中列出最近更新的仓库、读取仓库信息/文件、检索 Issue 和读取 PR。最多一次 50 个仓库或 30 条搜索结果；回复应说明这些范围。工具不执行远端写入。权限不足或授权失效时可通过账户菜单重新连接；带有效刷新令牌的过期 OAuth 授权会自动刷新。

## Google Drive 独立 OAuth

在“插件 → Google Drive → 已连接的账户”点击“连接账户”。选择“使用独立 OAuth”后，首次向导提供三个步骤和相应网页入口：

1. 在 Google Cloud 创建或选择项目，启用 Google Drive API。
2. 配置 Google Auth Platform 的应用名称与受众；测试模式需把自己的账号加入测试用户。
3. 创建“桌面应用”OAuth 客户端，下载 JSON，点击“选择 OAuth JSON”导入。

点击“保存并登录”自动打开 Google 官方账户选择页；后续直接点击账户区连接即可。需要修改配置时，使用账户标题旁的“登录设置”。配置仅需在这台电脑首次使用时完成，凭据以 Windows DPAPI 加密保存在本机。

两家登录均使用系统浏览器、随机本机回环端口、state 和 PKCE；取消或超时会关闭本机回调。Google 当前申请 drive.readonly：可搜索和读取文件；不会上传、修改或删除远端文件。支持文本、JSON、CSV、Google Docs 文本导出和 Sheets 第一个工作表 CSV 导出。搜索每页 40 条，工具返回 nextPageToken 可继续翻页；文本响应上限 2 MiB，长结果会标记截断。测试模式下 Google 的离线授权可能到期，需要重新连接。

聊天中的读取连接保持只读。v1.99.0 新增单独的知识库手动备份入口，使用独立的 `drive.file` 上传授权；支持单向增量上传与恢复校验，没有双向同步或定时任务。参见 [Google Drive 备份](GOOGLE-DRIVE-BACKUP.md)。

## Data

已安装的 Data 技能保存在 Typora 独立存储，停用 Data 后模型不能继续读取。可通过插件压缩包或插件市场导入其他工作流；已导入的同名技能不会悄悄覆盖。

Data 提供分析、质量检查、绘图、Notebook、报告等工作流；按需使用 plugin_read 读取技能及其资源。执行仍使用 Typora 已有的项目文件、Python/Notebook 和授权机制。GitHub、Google Drive 等只在各自已连接和启用时可用。Data 原文提到的其他专有工具或数据库连接不会因导入技能而获得。

## 接入边界与存储

设计参考本机 Codex 插件页面代码、插件清单及 app-server 接口。只有显式选择 Codex 方式的 GitHub / Google Drive 使用官方托管连接器；独立 OAuth 方式仍直接访问服务 API。Data 读取你本机已有的技能，不将该技能包包含在发布 ZIP 中。

元数据：Typora 用户数据目录 / editing-toolbar/plugins/plugins.json。
独立授权凭据：同目录 accounts.dpapi，以当前 Windows 用户的 DPAPI 加密。OAuth 客户端密钥、GitHub 令牌和 Google 刷新令牌不会作为模型工具参数、系统提示词或聊天记录发送。远端返回的文件内容视作不可信参考资料。独立模式断开账号清除该账号的本机凭据；若要撤销服务端授权，可在 GitHub 的 Applications / Authorized OAuth Apps（旧个人令牌在令牌设置）或 Google 账号的第三方连接中撤销。

插件只在支持工具调用的助手模型通道中使用；GPT 网页通道不具有这些本机工具。账户未连接时不会向模型提供该插件工具。Codex 模式已使用用户已授权的两家真实账户验证；独立 OAuth 的测试使用隔离环境、模拟服务响应、真实回环授权流程及加密存储。

参考：[GitHub REST 身份验证](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)、[Google 桌面应用 OAuth](https://developers.google.com/identity/protocols/oauth2/native-app)、[Google Drive 权限](https://developers.google.com/workspace/drive/api/guides/api-specific-auth)、[OpenAI 插件结构](https://developers.openai.com/plugins/build/plugins)。

## v1.96.0 插件详情与 Plugin Creator

GitHub、Google Drive、Data、Plugin Creator 的图标、介绍和示例取自本机 Codex 插件清单（分别为 0.1.12、0.1.16、1.0.11、0.1.22）。信息中的功能为原始插件声明；当前 Typora 可用范围以应用区说明为准。没有试用、复制链接或 Data 兼容插件区域。

Plugin Creator 安装本机三个技能：创建、更新、准备提交。添加 → 创建插件会启用它并把请求放入聊天输入框，由你补充需求后发送；不会自动发送消息或创建项目。使用当前助手的项目文件与终端工具；云端生成、发布和托管插件工具未接入。

插件技能可逐个开关，超过五个时展开/收起，点击可查看原文。禁用后模型不能读取该技能。左下角卸载清除 Typora 插件副本与该插件本机账号凭据，原始 Codex 插件、ZIP 与本地市场保留。

## 插件压缩包

添加 → 上传插件压缩包，支持选择、拖入或粘贴 .zip / .tar.gz / .tgz 路径，也可输入插件目录。先预览名称、技能数和未接入声明，再点击添加插件。支持根目录 plugin.json 的可移植格式及 .codex-plugin/plugin.json，技能位于 skills/<名称>/SKILL.md。压缩包限 100 MiB，解压总内容 256 MiB、单文件 32 MiB、最多 10000 条目。拒绝路径越界、链接、特殊文件、冲突路径和损坏校验；同名已安装插件不覆盖。

导入只安装技能及其资源。账号连接器、MCP 服务、钩子声明会保留并提示未接入，不自动启动程序或执行脚本。不提供自定义 MCP 服务器配置入口。

## 插件市场

添加 → 添加插件市场，填写 owner/repo、HTTPS/SSH Git URL 或本地目录；可选 Git 引用及每行一个稀疏目录。Git 来源需要本机 Git 和仓库访问权限，使用参数调用且不执行仓库钩子。取消添加不保存市场。

清单支持 .agents/plugins/marketplace.json、.codex-plugin/marketplace.json、.claude-plugin/marketplace.json 或根目录 marketplace.json。清单包含 name 与 plugins，每个条目有 name、description（可选）及 source（目录内相对路径或 {"path":"./plugins/example"}）。本版市场条目使用同一仓库内的插件目录。示例：

```json
{"name":"我的插件市场","plugins":[{"name":"example","source":"./plugins/example","description":"示例工作流"}]}
```

在市场中查看并安装插件，仍会先预览；安装复制到 Typora 自己的目录。添加 → 管理插件市场可重新打开或移除市场，移除不影响已安装插件，本地原始目录保留。Git 市场当前为添加时的快照；需要更新时可移除后重新添加。

含独立外部 Git URL 的市场条目会显示“外部来源”，可下载该插件压缩包后导入，不阻塞同一市场中的本地路径条目。已使用 openai/plugins 官方公开市场验证 Git 克隆、稀疏检出、清单读取和 GitHub 插件预览。

## v1.96.1 账户与紧凑布局

插件详情使用与技能相同的 600px 宽、高度至多 600px 的弹窗，窄窗口自动收缩。列表条目高 60px，状态在名称右侧；无技能的插件省略整个技能区。

GitHub 和 Google Drive 的账户区支持连接多个账户。点击“连接另一个账户”添加，已有相同账户会更新授权而不重复添加。更多菜单提供重命名、重新连接、断开连接；有多个账户时可设为当前账户，聊天中的插件读取使用标记为“当前”的账户。新添加的账户成为当前账户。重新连接必须选择原账户，避免意外替换。断开一个账户不影响其他账户，断开当前账户后使用剩余的第一个账户。

升级会保留旧版单账户及自定义名称。账户资料与头像来自服务验证结果；尚未连接时显示连接入口，不展示示例账户。Google 同一客户端配置更新保留账户，更换客户端会清除本机 Drive 连接，需重新授权。账户管理外观参考 Codex；登录使用 Typora 独立的 GitHub OAuth 与 Google 桌面 OAuth 流程。

## v1.97.1 授权后超时修复

浏览器回调显示“授权已收到”表示授权码已到达本机；Typora 仍需通过 HTTPS 换取令牌并验证账户，只有全部成功后才会显示已连接。登录窗口现在明确显示各阶段，回调页面也说明它不是连接成功提示。

插件网络按显式 HTTPS_PROXY / HTTP_PROXY（含小写变量）及 NO_PROXY 优先，否则读取当前 Windows 用户的系统代理（含系统解析的 PAC / 绕过规则）。采用独立 HTTPS 代理连接，不修改全局网络配置，不关闭证书验证，也不将授权码或密钥传入代理检测命令。失败后会清除代理缓存，点击重试读取最新设置。请求总超时也覆盖代理解析、DNS 和代理握手阶段。

若升级前已超时，保存文档并完全重启 Typora，在账户区重新连接；无需重新创建 OAuth 应用。此前浏览器标签中的授权码不要再次使用。修复验证包括实际官方服务连通性探测（无真实凭据）和隔离的模拟授权流程；真实账户连接状态以软件显示为准。

实现参考：[Node HTTPS Agent 的代理支持](https://nodejs.org/api/https.html#new-agentoptions)、[Windows 系统代理解析](https://learn.microsoft.com/en-us/dotnet/api/system.net.webrequest.getsystemwebproxy)。

## v1.106.1 本机目录与打包

右键技能或插件卡片，选择“查看目录”或“一键打包…”。打包时选择保存文件夹，生成包含清单和资源的 ZIP；同名时自动编号。完成后不弹出成功通知，失败仍显示原因。插件导出使用本机已安装包目录，不包含 Typora 的账户授权和启用设置；尚无本机包的连接器需先在 Codex 安装对应插件。

上传插件时，点击路径框右侧的文件夹图标选择压缩包，选中后自动预览；也可粘贴路径后按 Enter。空路径不读取，修改路径会清除旧预览，避免误装之前的文件。
