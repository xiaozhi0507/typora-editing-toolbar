# 项目环境

AI 助手设置 → 项目环境。终端新建菜单中的“项目环境…”也可打开。

页面沿用技能、插件页的标题与卡片样式。右上角提供重新检测、选择解释器图标和“安装环境”按钮。环境列表下拉选择，仅显示当前所选环境的路径、版本与依赖详情；切换查看不会修改默认环境。点击详情卡片“设为全局默认”设置默认解释器，下方配置项目环境。安装进度显示在内容区顶部，成功后自动清除进度、输出和完成提示，失败时保留错误信息以便重试。

## 选择与检测

- 显示解释器完整路径、Python 版本和位数，实际导入 NumPy、Pandas、Matplotlib、Seaborn、SciPy、ipykernel、jupyter_client，并验证 Matplotlib 可以生成图片。正常的用户目录包也会被识别。
- 选择已有 `python.exe`，再设为全局默认，或用于当前已信任的项目。项目下拉框可切换要配置的项目；选择“跟随全局默认”清除该项目的覆盖。
- 优先级：项目单独指定 → 全局默认 → 项目根目录 `.venv` / `venv` / `.env` / `env` / `.conda` → PATH 中真实的 Python。跳过 Windows Store 命令别名。指定路径失效时会报错，不悄悄换用其他解释器。
- 路径选择立即保存。终端、AI 的 Python 运行和 Notebook 共用设置。新终端使用新选择；正在运行的终端与单元格不被终止，Notebook 下次运行时按需更换内核。
- 已有项目解释器自动迁移。环境设置保存于本机 `et-python-environments-v1`，不会随安装包复制给别人；终端窗口布局保存不会覆盖环境设置。

## 一键安装

点击右上角“安装环境”：检测可用的 64 位 Python 3.10+；没有时下载并校验官方 CPython 3.13.16 Windows 安装包，安装到当前用户目录，然后建立专用虚拟环境并安装上述七个依赖。不会更改系统 PATH、文件关联或原有项目环境。

专用环境默认位于 `%LOCALAPPDATA%\TyporaEditingToolbar\python\scientific`。全部依赖导入与绘图验证通过后，才设为全局默认；项目已有单独设置仍保留。已有解释器卡片上的“补齐科研包”会安装到该卡片指定的环境。

安装需要联网，Python 来自 python.org，依赖来自 PyPI 的二进制包。支持系统 HTTP(S) 代理，显示安装进度及输出；下载失败可重试，也可手动安装后选择解释器。校验失败不会运行下载文件。取消下载或 pip 会结束本次进程树；Python 安装器阶段会先完成当前步骤，再停止后续操作。失败或取消保留原默认环境；下次点击可继续补齐已创建的专用环境。

安装进行中可关闭设置窗口，重新打开查看进度；完成或取消后再停用/升级 AI 模块。包安装不等于所有科研脚本都具备依赖，额外需要的 scikit-learn、statsmodels 等仍可在对应环境自行安装。

## 确认当前终端

```powershell
python -c "import sys; print(sys.executable)"
python -m pip --version
```

终端会话也显示 Python 路径。切换默认环境后请新建终端；给环境安装包时使用它自己的 `python -m pip`。

来源：[Python Windows 安装参数](https://docs.python.org/3.13/using/windows.html#installing-without-ui)、[CPython 3.13.16 安装包与 SHA-256](https://www.python.org/downloads/release/python-31316/)、[虚拟环境与 pip](https://docs.python.org/3/tutorial/venv.html)。
