# 项目选择与紧凑文件结果（v1.83.0）

- 项目文件单击选中，Ctrl/Command 切换选择，Shift 按当前项目的可见文件顺序连选；Ctrl+Shift 追加范围。双击或 Enter 打开，普通文件使用系统默认应用，Markdown 使用 Typora。单击不再打开或定位目录。
- 右键已选条目保留多选；右键未选条目选择它。多选菜单提供批量删除，Delete 键同样进入删除确认。移入回收站，取消不修改；删除前核验完整选择，未保存文档受保护，部分失败保留剩余条目。没有新增常驻操作提示。
- 文件创建结果立即保存到会话，实时过程仍立即更新。结果卡片等待最终回答完成才显示，停止或错误后仍提供已经真实创建的文件。历史恢复沿用同一组件。
- 文件结果共用一个紧凑边框，文件名和类型行搭配打开按钮；底部保留真实新增行数、撤销和查看变更，移除重复文件名列表。长名称截断并保留完整路径悬浮提示。

## 额度查询结论

当前为 SIWC ChatGPT 套餐授权。官方说明提供 public Responses API 和 Settings → Usage 用量页入口，没有在此授权文档中提供剩余百分比查询接口。后台加载网页仍需要独立的网站登录会话；API OAuth 令牌不能直接作为网页登录态。要做网页抓取需另建网页登录及依赖页面结构，本版未添加这种不稳定的隐藏抓取方式，也未借用浏览器或 Codex 的登录数据。保留仅用户手动刷新；打开菜单和模型回答不触发查询。

官方依据：
- https://developers.openai.com/siwc/token-sharing-open-source/profiles-and-sessions
- https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference

## 验证

新增回归覆盖选择/范围/重绘、批量删除取消/全部成功/部分失败/确认期间变化、未保存文档保护、回答期间卡片隐藏、完成后同数据立即显示、停止与旧记录恢复。独立 Typora 窗口验证 Ctrl/Shift 实际点击、右键菜单、真实回收站删除，以及本地 Responses 流驱动的真实文件创建。系统确认框由测试夹具代答，回收站调用实际执行；未发起外部付费模型请求。

320px 侧栏单文件卡片约高 91px，浅深色无横向溢出。完成事件后 7ms 检测到卡片；此前文件已创建并持续输出最终正文，卡片始终隐藏。证据位于 codex-temp/sessions/2026-09-29-typora-gpt-pro-source-study/project-selection-cards-v1830。
