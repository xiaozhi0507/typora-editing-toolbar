# 插件市场与功能模块（v1.110.1）

“浏览市场”的按钮随安装状态更新：未安装显示“安装”，有兼容的新版本显示“更新”，已安装相同或更高版本显示“无需更新”；新版本不兼容时提示“需升级工具栏”。检查失败时保留缓存并注明来源不可用。

入口：工具栏的“插件市场”。紧凑工具栏可将该入口收入“更多功能”。

AI 阅读助手已作为独立模块管理，包含项目、终端、代码编辑器和 Notebook。知识库、Google Drive 备份、阅读工具和主题功能继续由主程序提供。这里管理的是能扩展界面的功能模块；AI 设置中的插件、技能和账户连接保持独立。

## 使用

- **已安装**：紧凑条目，名称右侧显示版本徽标，开关启用/停用，问号打开文档，垃圾桶按钮卸载。右键可查看详情和模块命令。
- **浏览市场**：查看市场模块，安装或更新；不再提供模块搜索框。
- 市场来源页已移除，默认地址为 `https://raw.githubusercontent.com/xiaozhi0507/typora-editing-toolbar/main/marketplace.json`。打开市场会确保此官方清单存在；旧版保存的其他来源数据不会删除。
- 每次打开市场自动在后台检查新版本，已有条目与本地安装可立即使用；只检查，不会自动安装更新。同一次检查尚未结束时重新打开，不会重复请求。
- **本地安装**：拖入一个 ZIP 或模块目录，点击拖放区域选择 ZIP，或用路径框右侧文件夹图标选择目录；填写路径后也可按 Enter 预览。预览及确认安装前都不会执行模块代码。
- 新安装和更新后的模块默认停用；点“启用”后确认信任来源。更新保留模块数据，需要重新启用。
- 卸载先停止模块并保存草稿，再移除当前模块代码，保留对话、设置和项目文件。保存草稿失败时中止卸载。取消安装、取消文件选择或关闭对话框，不会安装模块。
- 市场网络失败时保留缓存并显示失败提示。包下载后先验证 SHA-256，再检查 ID、版本、接口和工具栏兼容性。

## 格式

模块根目录必须有 `module.json`、`main.js`，可选 `styles.css` 和其他静态资源。可以直接选择目录，或将根目录压缩为 ZIP。Obsidian 的插件包依赖 Obsidian API，不能直接安装到此处；Codex/Claude 的 AI 技能包也不是功能模块。

```json
{
  "format": "typora-toolbar-module",
  "schemaVersion": 1,
  "apiVersion": 1,
  "id": "hello-toolbar",
  "name": "示例模块",
  "version": "1.0.0",
  "minHostVersion": "1.104.0",
  "author": "Your name",
  "description": "说明模块提供的功能",
  "permissions": ["commands"]
}
```

版本使用 `x.y.z`。当前 API 为 1，不处理跨模块依赖；请把第三方依赖打包进 `main.js`。

```javascript
module.exports = {
  activate(api) {
    api.registerCommand({
      id: 'hello',
      name: '显示问候',
      callback: () => api.notice('模块已启用')
    });
    // 可返回清理函数。停用、更新和关闭时调用。
    return () => {};
  }
};
```

`activate` 可异步，也可导出 `deactivate()`。所有通过 SDK 注册的资源按相反顺序清理；模块启动失败会停用并显示错误，避免每次刷新重复加载。

| 接口 | 用途 | 能力声明 |
| --- | --- | --- |
| `registerCommand({id,name,callback})` | 命令保存在模块命名空间，在模块详情中执行 | `commands` |
| `addStyle(css)` | 添加样式，停用时删除；styles.css 自动使用此接口 | `styles` |
| `readDocument()` | 获取当前 Markdown 和选区文本 | `document-read` |
| `loadData()` / `saveData(json)` | 独立 JSON 设置，最大 1 MiB | 基础接口 |
| `on('window'或'document', event, callback, options)` | 注册并自动移除 DOM 事件 | 基础接口 |
| `setInterval(callback, ms)` | 注册并自动清理定时器 | 基础接口 |
| `register(dispose)` | 登记自定义资源清理函数 | 基础接口 |
| `notice(text)` | 显示工具栏提示 | 基础接口 |

模块是可信本机代码，能力声明不是沙箱，不能阻止恶意代码自行访问全局对象。只安装可信来源；SDK 外自行创建的监听器、定时器和 DOM，需要模块主动登记清理。同步死循环无法在同一渲染进程内隔离。普通设置不要保存密码或 OAuth 令牌。

## 市场清单

```json
{
  "schemaVersion": 1,
  "name": "我的功能模块市场",
  "modules": [{
    "id": "hello-toolbar",
    "name": "示例模块",
    "description": "说明",
    "author": "Your name",
    "version": "1.0.0",
    "apiVersion": 1,
    "minHostVersion": "1.104.0",
    "packageUrl": "https://YOUR-HOST.example/releases/hello-toolbar-1.0.0.zip",
    "sha256": "填写该ZIP文件的64位SHA256"
  }]
}
```

`packageUrl` 也可为相对于清单地址的 HTTPS 路径。源码和安装包可托管在自己的 GitHub Releases 或其他 HTTPS 服务；发布包后计算 SHA-256，再更新清单。SHA-256 用于确认包与清单一致，不证明发布者身份。本版没有社区审核、发布者签名、依赖解算或自动静默更新。

## 文件与后续拆分

配置保存在 Typora 用户数据目录 `editing-toolbar/feature-modules`，独立于 AI 插件的凭据目录：

- `modules.json`：安装记录、启用状态、市场缓存。
- `packages/<UUID>/`：不可原地覆盖的模块版本目录；更新后旧副本保留，暂不提供自动清理或回滚 UI。
- `data/<模块ID>.json`：模块设置；卸载后保留。
- `downloads/`：市场下载缓存。

可以在完全退出 Typora 后备份并调整 `modules.json` 中的 `enabled` 为 false，停用导致启动异常的第三方模块。

完整示例在 `files/templates/feature-module-example`。示例不会自动安装到用户环境。后续按指定边界拆分功能时，应先移除构建时的直接实例化和原型补丁依赖，再通过接口注册入口、保存设置并处理停用清理；不会仅给现有功能加一个没有实际卸载效果的开关。
