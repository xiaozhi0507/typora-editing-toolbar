function Assert-TyporaAssociationKey([string]$Key) {
    if ($Key -notmatch '^Software\\Classes\\(?:Typora\.[^\\]+|Applications\\Typora\.exe)\\shell\\open\\command$') { throw "Unexpected file association key: $Key" }
}
function Get-TyporaOpenCommandPlan([string]$TyporaDir) {
    $progIds = @('Applications\Typora.exe')
    foreach ($extension in @('.md','.markdown','.mdown','.mkd','.mkdn')) {
        foreach ($suffix in @('UserChoice','UserChoiceLatest\ProgId')) {
            $choice = Get-ItemProperty -LiteralPath ('HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\'+$extension+'\'+$suffix) -ErrorAction SilentlyContinue
            if ($choice.ProgId -match '^Typora\.[^\\]+$') { $progIds += $choice.ProgId }
        }
        $extKey = Get-Item -LiteralPath ('Registry::HKEY_CLASSES_ROOT\'+$extension) -ErrorAction SilentlyContinue
        if ($extKey -and $extKey.GetValue('') -match '^Typora\.[^\\]+$') { $progIds += $extKey.GetValue('') }
    }
    $command = '"'+(Join-Path $TyporaDir 'resources\editing-toolbar.open.exe')+'" "%1"'
    foreach ($progId in @($progIds | Select-Object -Unique)) {
        $keyPath = 'Software\Classes\'+$progId+'\shell\open\command'
        Assert-TyporaAssociationKey $keyPath
        $key = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($keyPath)
        $hadValue = $false; $previous = $null; $kind = 'String'
        try { if ($key -and '' -in $key.GetValueNames()) { $hadValue=$true; $previous=$key.GetValue('',$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames); $kind=[string]$key.GetValueKind('') } }
        finally { if ($key) { $key.Dispose() } }
        [PSCustomObject]@{key=$keyPath;hadValue=$hadValue;previousValue=$previous;previousKind=$kind;installedValue=$command}
    }
}
function Set-TyporaOpenCommand($Entry) {
    Assert-TyporaAssociationKey $Entry.key
    $key=[Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($Entry.key)
    try { $key.SetValue('',$Entry.installedValue,[Microsoft.Win32.RegistryValueKind]::String) } finally { $key.Dispose() }
}
function Test-TyporaOpenCommand($Entry) {
    Assert-TyporaAssociationKey $Entry.key
    $key=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($Entry.key)
    try { return ($key -and $key.GetValue('') -eq $Entry.installedValue) } finally { if ($key) { $key.Dispose() } }
}
function Restore-TyporaOpenCommand($Entry) {
    Assert-TyporaAssociationKey $Entry.key
    $key=[Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($Entry.key)
    try {
        if ($Entry.hadValue) { $kind=[Microsoft.Win32.RegistryValueKind]([Enum]::Parse([Microsoft.Win32.RegistryValueKind],$Entry.previousKind)); $key.SetValue('',$Entry.previousValue,$kind) }
        else { $key.DeleteValue('',$false) }
        $empty=$key.ValueCount -eq 0 -and $key.SubKeyCount -eq 0
    } finally { $key.Dispose() }
    if ($empty) { [Microsoft.Win32.Registry]::CurrentUser.DeleteSubKey($Entry.key,$false) }
}
function Update-TyporaAssociationCache {
    if (-not ('ETFileAssociationNotify' -as [type])) {
        Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class ETFileAssociationNotify{[DllImport("shell32.dll")]public static extern void SHChangeNotify(uint events,uint flags,IntPtr a,IntPtr b);}'
    }
    # Wait for the running Explorer to consume the new command before the
    # installer exits. An asynchronous notification can leave its old handler cached.
    [ETFileAssociationNotify]::SHChangeNotify(0x08000000,0x1003,[IntPtr]::Zero,[IntPtr]::Zero)
}
