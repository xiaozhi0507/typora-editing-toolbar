﻿function Test-TyporaInstallerAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    try {
        return ([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } finally { $identity.Dispose() }
}

function Test-TyporaAccessDenied($Failure) {
    if ($Failure.CategoryInfo.Category -eq 'PermissionDenied') { return $true }
    $errorObject = $Failure.Exception
    while ($errorObject) {
        if ($errorObject -is [UnauthorizedAccessException] -or
            ($errorObject.HResult -band 0xFFFF) -eq 5 -or
            ($errorObject -is [ComponentModel.Win32Exception] -and $errorObject.NativeErrorCode -eq 5)) { return $true }
        $errorObject = $errorObject.InnerException
    }
    return $false
}

function Assert-TyporaInstallWritable([string[]]$Files, [string]$BackupParent) {
    $directories = @($BackupParent)
    foreach ($file in $Files) {
        $directories += Split-Path -Parent $file
        if (Test-Path -LiteralPath $file -PathType Leaf) {
            # Open without truncating or writing: detect ACL/read-only failures before backup/overwrite.
            $stream = [IO.File]::Open($file, [IO.FileMode]::Open, [IO.FileAccess]::Write, [IO.FileShare]::ReadWrite)
            $stream.Dispose()
        }
    }
    $checked = @{}
    foreach ($directory in $directories) {
        $existing = [IO.Path]::GetFullPath($directory)
        while (-not (Test-Path -LiteralPath $existing -PathType Container)) {
            $parent = Split-Path -Parent $existing
            if (-not $parent -or $parent -eq $existing) { throw "Cannot locate a writable parent for: $directory" }
            $existing = $parent
        }
        if ($checked.ContainsKey($existing)) { continue }
        $checked[$existing] = $true
        $probe = Join-Path $existing ('.editing-toolbar-write-check-' + [guid]::NewGuid().ToString('N') + '.tmp')
        $stream = $null
        try {
            $stream = [IO.FileStream]::new($probe, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None, 1, [IO.FileOptions]::DeleteOnClose)
        } finally { if ($stream) { $stream.Dispose() } }
    }
}

function ConvertTo-TyporaPowerShellLiteral([string]$Value) {
    return "'" + $Value.Replace("'", "''") + "'"
}

function Get-TyporaElevatedInstallCommand([string]$Installer, [string]$TyporaDir, [bool]$InstallThemes, [string]$ThemeDir, [bool]$SkipFileAssociation, [string]$LogPath) {
    $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $command = '& ' + (ConvertTo-TyporaPowerShellLiteral $Installer) + ' -TyporaDir ' + (ConvertTo-TyporaPowerShellLiteral $TyporaDir) + ' -ElevationAttempt -OriginalUserSid ' + (ConvertTo-TyporaPowerShellLiteral $sid)
    if ($InstallThemes) { $command += ' -InstallThemes -ThemeDir ' + (ConvertTo-TyporaPowerShellLiteral $ThemeDir) }
    if ($SkipFileAssociation) { $command += ' -SkipFileAssociation' }
    # EncodedCommand avoids cmd.exe quoting and preserves spaces, Chinese, apostrophes and metacharacters.
    $command += ' *> ' + (ConvertTo-TyporaPowerShellLiteral $LogPath)
    $script = "`$ErrorActionPreference = 'Stop'; `$global:LASTEXITCODE = 0; try { $command; exit `$LASTEXITCODE } catch { `$_ | Out-String | Add-Content -LiteralPath " + (ConvertTo-TyporaPowerShellLiteral $LogPath) + "; exit 1 }"
    return [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($script))
}

function Start-TyporaElevatedInstall([string]$Installer, [string]$TyporaDir, [bool]$InstallThemes, [string]$ThemeDir, [bool]$SkipFileAssociation) {
    $logPath = Join-Path ([IO.Path]::GetTempPath()) ('typora-install-' + [guid]::NewGuid().ToString('N') + '.log')
    try {
        [IO.File]::WriteAllText($logPath, '')
        $encoded = Get-TyporaElevatedInstallCommand $Installer $TyporaDir $InstallThemes $ThemeDir $SkipFileAssociation $logPath
        $shell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
        $process = Start-Process -FilePath $shell -Verb RunAs -WindowStyle Hidden -ArgumentList ('-NoProfile -STA -ExecutionPolicy Bypass -EncodedCommand ' + $encoded) -Wait -PassThru
        try { return [int]$process.ExitCode } finally { if ($process -is [IDisposable]) { $process.Dispose() } }
    } catch {
        $errorObject = $_.Exception
        while ($errorObject) {
            if ($errorObject -is [ComponentModel.Win32Exception] -and $errorObject.NativeErrorCode -eq 1223) {
                Write-Host '已取消管理员授权，未开始安装。'
                return 1223
            }
            $errorObject = $errorObject.InnerException
        }
        throw
    } finally {
        if (Test-Path -LiteralPath $logPath -PathType Leaf) {
            $log = Get-Content -LiteralPath $logPath -Raw
            if ($log) { Write-Host $log.TrimEnd() }
            Remove-Item -LiteralPath $logPath -ErrorAction SilentlyContinue
        }
    }
}
