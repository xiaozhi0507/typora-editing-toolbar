#requires -Version 5.1
[CmdletBinding()]
param([string]$TyporaDir, [switch]$InstallThemes, [string]$ThemeDir, [switch]$ChooseFolder, [switch]$SkipFileAssociation)
& (Join-Path $PSScriptRoot 'install-typora-toolbar.ps1') @PSBoundParameters
