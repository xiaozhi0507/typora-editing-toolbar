#requires -Version 5.1
[CmdletBinding()]
param([string]$TyporaDir='D:\Typora',[string]$ResultPath)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'typora-open-association.ps1')
try {
    $TyporaDir=(Resolve-Path -LiteralPath $TyporaDir).Path
    $resources=Join-Path $TyporaDir 'resources'
    if(-not(Test-Path -LiteralPath (Join-Path $TyporaDir 'Typora.exe') -PathType Leaf) -or -not(Test-Path -LiteralPath (Join-Path $resources 'editing-toolbar.open.exe') -PathType Leaf)){throw 'Typora and its direct-open launcher are required.'}
    $entries=@(Get-TyporaOpenCommandPlan $TyporaDir)
    $backup=Join-Path $resources ('editing-toolbar-backups\'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-association-'+[guid]::NewGuid().ToString('N').Substring(0,8))
    New-Item -ItemType Directory -Path $backup | Out-Null
    @{schema=2;typoraDir=$TyporaDir;created=(Get-Date -Format o);entries=@();associations=$entries} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $backup 'backup.json') -Encoding UTF8
    $written=@()
    try {
        foreach($entry in $entries){$written+=$entry;Set-TyporaOpenCommand $entry}
        Update-TyporaAssociationCache
        foreach($entry in $entries){if(-not(Test-TyporaOpenCommand $entry)){throw ('Association verification failed: '+$entry.key)}}
    } catch {
        foreach($entry in $written){Restore-TyporaOpenCommand $entry}
        Update-TyporaAssociationCache
        throw
    }
    $result=@{ok=$true;backup=$backup;associations=$entries.Count}
    Write-Host ('Direct-open associations repaired. Backup: '+$backup)
} catch {
    $result=@{ok=$false;error=$_.Exception.Message}
    Write-Error -Message $_.Exception.Message -ErrorAction Continue
}
if($ResultPath){[IO.File]::WriteAllText([IO.Path]::GetFullPath($ResultPath),($result|ConvertTo-Json -Depth 6),(New-Object Text.UTF8Encoding($false)))}
if(-not $result.ok){exit 1}
