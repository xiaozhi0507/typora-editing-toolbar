﻿function Get-BytesSha256([byte[]]$Bytes) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash($Bytes))).Replace('-','').ToLowerInvariant() }
    finally { $sha.Dispose() }
}
function Get-Sha256([string]$Path) {
    $stream = [IO.File]::OpenRead($Path)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-','').ToLowerInvariant() }
    finally { $sha.Dispose(); $stream.Dispose() }
}
function Get-ContainedPath([string]$Root, [string]$Relative) {
    $base = [IO.Path]::GetFullPath($Root).TrimEnd('\') + '\'
    $full = [IO.Path]::GetFullPath((Join-Path $base $Relative))
    if (-not $full.StartsWith($base, [StringComparison]::OrdinalIgnoreCase)) { throw "Path outside expected folder: $Relative" }
    return $full
}
function Assert-TyporaClosed([string]$Root) {
    $exe = Join-Path $Root 'Typora.exe'
    foreach ($process in @(Get-Process -Name Typora -ErrorAction SilentlyContinue)) {
        $processPath = $null
        try { $processPath = $process.Path } catch {}
        if (-not $processPath -or $processPath -eq $exe) { throw 'Save your notes and exit Typora completely before continuing.' }
    }
}

function Select-TyporaInstallFolder {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.Application]::EnableVisualStyles()
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    try {
        $dialog.Description = '请选择 Typora 安装文件夹（里面应有 Typora.exe 和 resources 文件夹）'
        $dialog.RootFolder = [Environment+SpecialFolder]::MyComputer
        $dialog.ShowNewFolderButton = $false
        if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            return $dialog.SelectedPath
        }
        return $null
    } finally { $dialog.Dispose() }
}
