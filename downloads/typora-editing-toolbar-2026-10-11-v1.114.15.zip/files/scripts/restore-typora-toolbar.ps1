#requires -Version 5.1
[CmdletBinding()]
param([string]$BackupDir)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'toolbar-install-common.ps1')
. (Join-Path $PSScriptRoot 'typora-open-association.ps1')
try {
    if (-not $BackupDir) { $BackupDir = Read-Host 'Enter the backup folder printed by the installer' }
    $BackupDir = (Resolve-Path -LiteralPath $BackupDir.Trim('"')).Path
    $info = Get-Content -LiteralPath (Join-Path $BackupDir 'backup.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($info.schema -notin @(1,2)) { throw 'Unsupported backup manifest.' }
    Assert-TyporaClosed $info.typoraDir
    $allowed = @('editing-toolbar.js','editing-toolbar.css','editing-toolbar.runtime.js','editing-toolbar.runtime.css','editing-toolbar.theme-bootstrap.js','editing-toolbar.chatgpt.cjs','editing-toolbar.open.exe','editing-toolbar.terminal.exe','editing-toolbar.code.js','editing-toolbar.code.css','editing-toolbar.code.LICENSE.txt','editing-toolbar.notebook.py','editing-toolbar.modules/ai-reading-assistant/module.json','editing-toolbar.modules/ai-reading-assistant/main.js','editing-toolbar.modules/ai-reading-assistant/styles.css','editing-toolbar.modules/ai-reading-assistant/chatgpt.cjs','editing-toolbar.modules/ai-reading-assistant/assets/editing-toolbar.code.js','editing-toolbar.modules/ai-reading-assistant/assets/editing-toolbar.code.css','editing-toolbar.modules/ai-reading-assistant/assets/editing-toolbar.code.LICENSE.txt','editing-toolbar.modules/ai-reading-assistant/assets/editing-toolbar.notebook.py','editing-toolbar.modules/ai-reading-assistant/assets/editing-toolbar.terminal.exe','window.html') | ForEach-Object { Join-Path (Join-Path $info.typoraDir 'resources') $_ }
    foreach ($association in $info.associations) {
        if (-not (Test-TyporaOpenCommand $association)) { throw "File association changed after installation; restore stopped: $($association.key)" }
    }
    foreach ($entry in $info.entries) {
        $target = [IO.Path]::GetFullPath($entry.target)
        $themeAllowed = $false
        if ($info.themeDir) {
            $themeRoot = [IO.Path]::GetFullPath($info.themeDir).TrimEnd('\')
            $themeAllowed = ((Split-Path -Parent $target) -eq $themeRoot -and (Split-Path -Leaf $target) -match '^editing-toolbar-(github|newsprint|night|pixyll|whitey)\.css$') -or $target.StartsWith(($themeRoot+'\editing-toolbar-assets\'),[StringComparison]::OrdinalIgnoreCase)
        }
        if ($target -notin $allowed -and -not $themeAllowed) { throw "Unexpected restore target: $target" }
        if (-not (Test-Path -LiteralPath $target -PathType Leaf) -or (Get-Sha256 $target) -ne $entry.installedSha256) {
            throw "File changed after installation (possibly a Typora update); restore stopped without changing files: $target"
        }
        if ($entry.existed) {
            $source = Get-ContainedPath $BackupDir $entry.backup
            if ((Get-Sha256 $source) -ne $entry.beforeSha256) { throw "Backup hash mismatch: $source" }
        }
    }
    foreach ($association in $info.associations) { Restore-TyporaOpenCommand $association }
    if (@($info.associations).Count) { Update-TyporaAssociationCache }
    # Restore the editor entry point before removing newly installed assets.
    $entries = @($info.entries)
    [array]::Reverse($entries)
    foreach ($entry in $entries) {
        if ($entry.existed) {
            Copy-Item -LiteralPath (Get-ContainedPath $BackupDir $entry.backup) -Destination $entry.target -Force
            if ((Get-Sha256 $entry.target) -ne $entry.beforeSha256) { throw "Restore verification failed: $($entry.target)" }
        } else { Remove-Item -LiteralPath $entry.target }
    }
    Write-Host 'Restored the exact file state from before this installation. Reopen Typora.' -ForegroundColor Green
    Write-Host 'Backup files are retained.'
} catch {
    Write-Host "Restore failed: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
