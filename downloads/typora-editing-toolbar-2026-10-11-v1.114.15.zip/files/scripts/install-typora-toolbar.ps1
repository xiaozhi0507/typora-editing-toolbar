﻿#requires -Version 5.1
[CmdletBinding()]
param([string]$TyporaDir, [switch]$InstallThemes, [string]$ThemeDir, [switch]$ChooseFolder, [switch]$SkipFileAssociation, [switch]$ElevationAttempt, [string]$OriginalUserSid)
$ErrorActionPreference = 'Stop'
$PackageRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$PayloadRoot = Join-Path $PackageRoot 'files'
. (Join-Path $PSScriptRoot 'toolbar-install-common.ps1')
. (Join-Path $PSScriptRoot 'typora-open-association.ps1')
. (Join-Path $PSScriptRoot 'toolbar-install-permissions.ps1')
try {
    if ($OriginalUserSid -and $OriginalUserSid -ne [Security.Principal.WindowsIdentity]::GetCurrent().User.Value) {
        # A standard user may supply a different admin account at the UAC prompt.
        # Keep themes at the original explicit path and never change that admin's file associations.
        $SkipFileAssociation = $true
        Write-Host '正在使用另一管理员账户安装；不会修改该管理员账户的 Markdown 打开方式。'
    }
    if ($ChooseFolder -and -not $TyporaDir) {
        $TyporaDir = Select-TyporaInstallFolder
        if (-not $TyporaDir) {
            Write-Host 'Installation cancelled. No files were changed.'
            return
        }
    }
    if (-not $TyporaDir) {
        $candidates = @('D:\Typora', (Join-Path $env:ProgramFiles 'Typora'))
        if (${env:ProgramFiles(x86)}) { $candidates += Join-Path ${env:ProgramFiles(x86)} 'Typora' }
        if ($env:LOCALAPPDATA) { $candidates += Join-Path $env:LOCALAPPDATA 'Programs\Typora' }
        foreach ($key in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths\Typora.exe','HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths\Typora.exe')) {
            $item = Get-Item -LiteralPath $key -ErrorAction SilentlyContinue
            if ($item) { $exe = $item.GetValue(''); if ($exe) { $candidates += Split-Path -Parent $exe.Trim('"') } }
        }
        $candidates = @($candidates | Select-Object -Unique | Where-Object { Test-Path -LiteralPath (Join-Path $_ 'resources\window.html') -PathType Leaf })
        if ($candidates.Count -eq 1) { $TyporaDir = $candidates[0] }
        else {
            if ($candidates.Count) { Write-Host ('Detected locations: ' + ($candidates -join ', ')) }
            $TyporaDir = Read-Host 'Enter the Typora installation folder (for example C:\Program Files\Typora)'
        }
    }
    $TyporaDir = (Resolve-Path -LiteralPath $TyporaDir.Trim('"')).Path
    $resources = Join-Path $TyporaDir 'resources'
    $window = Join-Path $resources 'window.html'
    if (-not (Test-Path -LiteralPath (Join-Path $TyporaDir 'Typora.exe') -PathType Leaf) -or -not (Test-Path -LiteralPath $window -PathType Leaf)) {
        throw 'Unsupported folder: Typora.exe and resources\window.html are required.'
    }
    Assert-TyporaClosed $TyporaDir
    $manifest = Get-Content -LiteralPath (Join-Path $PayloadRoot 'metadata\package-manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($file in $manifest.files) {
        $source = Get-ContainedPath $PackageRoot $file.path
        if ((Get-Sha256 $source) -ne $file.sha256) { throw "Package file changed or incomplete: $($file.path)" }
    }
    $html = [IO.File]::ReadAllText($window)
    if (-not [regex]::IsMatch($html, 'id\s*=\s*["'']write["'']', 'IgnoreCase')) { throw 'Unrecognized Typora editor HTML; no files changed.' }
    $tagPattern = '<script\b(?=[^>]*\bsrc\s*=\s*["''](?:\./)?editing-toolbar(?:\.runtime|\.theme-bootstrap)?\.js(?:\?[^"'']*)?["''])[^>]*>\s*</script>'
    $clean = [regex]::Replace($html, $tagPattern, '', 'IgnoreCase')
    $head = [regex]::Matches($clean, '</head\s*>', 'IgnoreCase')
    if ($head.Count -ne 1) { throw 'Cannot locate a unique closing head tag; no files changed.' }
    # A small parser-blocking script applies saved colors before the body can paint.
    $clean = $clean.Insert($head[0].Index, '<script src="./editing-toolbar.theme-bootstrap.js"></script>')
    $body = [regex]::Matches($clean, '</body\s*>', 'IgnoreCase')
    if ($body.Count -ne 1) { throw 'Cannot locate a unique closing body tag; no files changed.' }
    $updated = $clean.Insert($body[0].Index, '<script src="./editing-toolbar.js" defer="defer"></script>')
    $originalBytes = [IO.File]::ReadAllBytes($window)
    $hasBom = $originalBytes.Length -ge 3 -and $originalBytes[0] -eq 239 -and $originalBytes[1] -eq 187 -and $originalBytes[2] -eq 191
    if ($originalBytes.Length -ge 2 -and (($originalBytes[0] -eq 255 -and $originalBytes[1] -eq 254) -or ($originalBytes[0] -eq 254 -and $originalBytes[1] -eq 255))) { throw 'Unsupported UTF-16 editor HTML; no files changed.' }
    $encoder = New-Object System.Text.UTF8Encoding($hasBom)
    $htmlBytes = [byte[]]($encoder.GetPreamble() + $encoder.GetBytes($updated))
    $plan = @()
    foreach ($name in @('editing-toolbar.js','editing-toolbar.css','editing-toolbar.runtime.js','editing-toolbar.runtime.css','editing-toolbar.theme-bootstrap.js','editing-toolbar.chatgpt.cjs','editing-toolbar.open.exe','editing-toolbar.terminal.exe','editing-toolbar.code.js','editing-toolbar.code.css','editing-toolbar.code.LICENSE.txt','editing-toolbar.notebook.py')) {
        $plan += @{ target=(Join-Path $resources $name); bytes=[IO.File]::ReadAllBytes((Join-Path (Join-Path $PayloadRoot 'plugin') $name)) }
    }
    if ($InstallThemes) {
        if (-not $ThemeDir) { $ThemeDir = Join-Path $env:APPDATA 'Typora\themes' }
        $ThemeDir = [IO.Path]::GetFullPath($ThemeDir)
        $themeSource = Join-Path $PayloadRoot 'themes'
        foreach ($file in Get-ChildItem -LiteralPath $themeSource -File -Recurse) {
            $relative = $file.FullName.Substring($themeSource.Length + 1)
            if ($file.DirectoryName -eq $themeSource -and $file.Extension -eq '.css') {
                $target = Join-Path $ThemeDir ('editing-toolbar-' + $file.Name)
                $css = [IO.File]::ReadAllText($file.FullName).Replace("url('./", "url('./editing-toolbar-assets/")
                $bytes = [Text.Encoding]::UTF8.GetBytes($css)
            } else {
                $target = Get-ContainedPath (Join-Path $ThemeDir 'editing-toolbar-assets') $relative
                $bytes = [IO.File]::ReadAllBytes($file.FullName)
            }
            $plan += @{ target=$target; bytes=$bytes }
        }
    }
    # Install the injection tag last. Every overwritten file has an exact backup.
    $plan += @{ target=$window; bytes=$htmlBytes }
    try {
        Assert-TyporaInstallWritable -Files @($plan | ForEach-Object { $_.target }) -BackupParent (Join-Path $resources 'editing-toolbar-backups')
    } catch {
        if (-not (Test-TyporaAccessDenied $_)) { throw }
        if ($ElevationAttempt -or (Test-TyporaInstallerAdministrator)) {
            throw ('已取得管理员权限，但安装目录仍拒绝写入。请检查文件只读属性、目录权限或安全软件限制。详细信息：' + $_.Exception.Message)
        }
        Write-Host '安装目录需要管理员权限，即将请求 Windows 授权。已选择的目录会保留。'
        $result = Start-TyporaElevatedInstall -Installer $PSCommandPath -TyporaDir $TyporaDir -InstallThemes ([bool]$InstallThemes) -ThemeDir $ThemeDir -SkipFileAssociation ([bool]$SkipFileAssociation)
        if ($result -ne 0 -and $result -ne 1223) { Write-Host ('管理员安装未完成，退出代码：' + $result) -ForegroundColor Red }
        exit $result
    }
    $backup = Join-Path $resources ('editing-toolbar-backups\' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N').Substring(0,8))
    New-Item -ItemType Directory -Path $backup | Out-Null
    $entries = @()
    for ($i=0; $i -lt $plan.Count; $i++) {
        $item = $plan[$i]; $exists = Test-Path -LiteralPath $item.target -PathType Leaf
        $backupName = '{0:D3}.bin' -f $i
        $beforeHash = $null
        if ($exists) { Copy-Item -LiteralPath $item.target -Destination (Join-Path $backup $backupName); $beforeHash = Get-Sha256 $item.target }
        $entries += [PSCustomObject]@{target=$item.target; existed=$exists; backup=$backupName; beforeSha256=$beforeHash; installedSha256=(Get-BytesSha256 $item.bytes)}
    }
    $associations = @(); if (-not $SkipFileAssociation) { $associations = @(Get-TyporaOpenCommandPlan $TyporaDir) }
    @{schema=2; typoraDir=$TyporaDir; themeDir=$ThemeDir; created=(Get-Date -Format o); entries=$entries; associations=$associations} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $backup 'backup.json') -Encoding UTF8
    $written = @()
    $writtenAssociations = @()
    try {
        for ($i=0; $i -lt $plan.Count; $i++) {
            $item = $plan[$i]
            New-Item -ItemType Directory -Path (Split-Path -Parent $item.target) -Force | Out-Null
            $written += $i
            [IO.File]::WriteAllBytes($item.target, $item.bytes)
            if ((Get-Sha256 $item.target) -ne $entries[$i].installedSha256) { throw "Copy verification failed: $($item.target)" }
        }
        foreach ($association in $associations) { $writtenAssociations += $association; Set-TyporaOpenCommand $association }
        if ($associations.Count) { Update-TyporaAssociationCache }
    } catch {
        $failure = $_
        foreach ($association in $writtenAssociations) { Restore-TyporaOpenCommand $association }
        if ($writtenAssociations.Count) { Update-TyporaAssociationCache }
        foreach ($i in @($written | Sort-Object -Descending)) {
            $entry=$entries[$i]
            if ($entry.existed) { Copy-Item -LiteralPath (Join-Path $backup $entry.backup) -Destination $entry.target -Force }
            elseif (Test-Path -LiteralPath $entry.target -PathType Leaf) { Remove-Item -LiteralPath $entry.target }
        }
        throw $failure
    }
    Write-Host "Installed successfully: $TyporaDir" -ForegroundColor Green
    Write-Host "Backup folder: $backup"
    if ($InstallThemes) { Write-Host 'Select an editing-toolbar-* theme from the Typora Themes menu to use the bundled card styles.' }
    Write-Host 'Reopen Typora and click the toolbar settings button.'
} catch {
    Write-Host "Installation failed: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host '请保存文档并完全退出 Typora；确认安装目录正确、安装包已完整解压。'
    exit 1
}
