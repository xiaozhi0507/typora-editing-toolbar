@echo off
setlocal
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0files\scripts\install-typora-toolbar.ps1" -ChooseFolder %*
set "RESULT=%ERRORLEVEL%"
echo.
pause
exit /b %RESULT%
