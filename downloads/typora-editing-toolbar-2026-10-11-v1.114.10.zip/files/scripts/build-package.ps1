﻿#requires -Version 5.1
[CmdletBinding()]
param([string]$OutputPath)
$ErrorActionPreference = 'Stop'
$PackageRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$PayloadRoot = Join-Path $PackageRoot 'files'
. (Join-Path $PSScriptRoot 'toolbar-install-common.ps1')
foreach ($extension in @('js','css')) {
    if ((Get-Sha256 (Join-Path $PayloadRoot "plugin\editing-toolbar.$extension")) -ne (Get-Sha256 (Join-Path $PayloadRoot "plugin\editing-toolbar.runtime.$extension"))) { throw "Runtime mirror does not match: $extension" }
}
$items = @('install.cmd','README.md',
    'files\plugin','files\scripts','files\docs','files\templates','files\themes')
$files = @()
foreach ($item in $items) {
    $full = Join-Path $PackageRoot $item
    if (Test-Path -LiteralPath $full -PathType Container) { $files += Get-ChildItem -LiteralPath $full -File -Recurse }
    else { $files += Get-Item -LiteralPath $full }
}
# AI modules are distributed as separate ZIPs, never seeded by the host installer.
$moduleRoot = [IO.Path]::GetFullPath((Join-Path $PayloadRoot 'plugin\editing-toolbar.modules')) + [IO.Path]::DirectorySeparatorChar
$files = @($files | Where-Object { -not $_.FullName.StartsWith($moduleRoot,[StringComparison]::OrdinalIgnoreCase) })
# The portable source tree is flat apart from base/. Do not recurse into a
# developer's node_modules or include local build/test output after npm ci.
$sourceRoot = Join-Path $PayloadRoot 'source'
$files += Get-ChildItem -LiteralPath $sourceRoot -File
$files += Get-ChildItem -LiteralPath (Join-Path $sourceRoot 'base') -File
$entries = @($files | Sort-Object FullName | ForEach-Object {
    @{path=$_.FullName.Substring($PackageRoot.Length+1).Replace('\','/');sha256=(Get-Sha256 $_.FullName);bytes=$_.Length}
})
$manifest = @{name='Typora Editing Toolbar';release='2026-10-11';testedTypora='1.14.10';platform='Windows';created=(Get-Date -Format o);files=$entries}
$manifestPath = Join-Path $PayloadRoot 'metadata\package-manifest.json'
New-Item -ItemType Directory -Path (Split-Path -Parent $manifestPath) -Force | Out-Null
$manifest | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $manifestPath -Encoding UTF8
if (-not $OutputPath) { $OutputPath = Join-Path $PackageRoot 'dist\typora-editing-toolbar-2026-10-11-v1.114.10.zip' }
$OutputPath = [IO.Path]::GetFullPath($OutputPath)
if ($OutputPath -notmatch '\.zip$') { throw 'OutputPath must end with .zip' }
$sourcePaths = @($files.FullName) + @($manifestPath)
if ($sourcePaths -contains $OutputPath) { throw 'Output would replace a package source file.' }
New-Item -ItemType Directory -Path (Split-Path -Parent $OutputPath) -Force | Out-Null
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$outputStream = [IO.File]::Open($OutputPath,[IO.FileMode]::Create,[IO.FileAccess]::Write,[IO.FileShare]::None)
$archive = $null
try {
    $archive = New-Object IO.Compression.ZipArchive($outputStream,[IO.Compression.ZipArchiveMode]::Create,$true)
    foreach ($entry in $entries) {
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $PackageRoot $entry.path),$entry.path,[IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
    [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$manifestPath,'files/metadata/package-manifest.json',[IO.Compression.CompressionLevel]::Optimal) | Out-Null
} finally { if ($archive) { $archive.Dispose() }; $outputStream.Dispose() }
Write-Host "Package created: $OutputPath" -ForegroundColor Green
Write-Host ('SHA256: ' + (Get-Sha256 $OutputPath))

