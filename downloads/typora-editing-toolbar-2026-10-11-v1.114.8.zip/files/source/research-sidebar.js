import {localGraph} from './research-note-core.js';
import {ResearchGraphMenu} from './research-graph-menu.js';
import {ResearchGraphView} from './research-graph-view.js';
import {ResearchIndexClient} from './research-index-client.js';
import {ResearchGraphCache} from './research-graph-cache.js';
import {ResearchGraphOutline} from './research-graph-outline.js';
const naturalForces={depthView:false,folderGrouping:false,center:.1,repulsion:1,attraction:1,linkDistance:160};
const lightGraphColors={bg:'#f8f8fa',node:'#628bb7',edge:'#8c8796',accent:'#9864d8',text:'#46424f'};
const defaults={scope:'global',depth:1,incoming:true,outgoing:true,interlinks:true,excludeNonMarkdown:true,existingOnly:false,darkGraph:true,arrows:false,distanceFade:.75,textOpacity:.7,nodeSize:1,lineWidth:1,...naturalForces,maxNodes:500,groups:[]};
const icon={graph:'<circle cx="6" cy="5" r="2"/><circle cx="18" cy="5" r="2"/><circle cx="12" cy="18" r="2"/><path d="M6 7v3l6 6 6-6V7"/>',settings:'<path d="M4 7h16M4 17h16"/><circle cx="9" cy="7" r="3"/><circle cx="15" cy="17" r="3"/>',refresh:'<path d="M20 9a8 8 0 1 0-1 9M20 3v6h-6"/>',fit:'<path d="M8 3H3v5M16 3h5v5M3 16v5h5M21 16v5h-5"/>',collapse:'<path d="m7 14 5-5 5 5"/>',close:'<path d="m6 6 12 12M18 6 6 18"/>'};
const el=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!=null)n.textContent=text;return n;};
export class ResearchSidebar {
 constructor(toolbar,workerSource){
  this.toolbar=toolbar;this.fs=toolbar.annotations.fs;this.path=toolbar.annotations.path;this.workerSource=workerSource;this.file='';this.root='';this.index=null;this.requestId=0;this.indexCache=new ResearchGraphCache(localStorage);this.state=this.readState();this.options={...defaults,...this.state.options};this.outline=new ResearchGraphOutline(this);
  // Keep the old checkbox position while adopting its requested exclusion meaning once.
  if(typeof this.state.options?.excludeNonMarkdown!=='boolean')this.options.excludeNonMarkdown=this.state.options?.attachments!==false;
  delete this.options.attachments;this.options.lightColors=this.normalizeLightColors(this.options.lightColors);this.initGraphPalettes();
  if(this.state.naturalLayoutVersion!==1){Object.assign(this.options,naturalForces,{scope:'global'});this.state.naturalLayoutVersion=1;}this.options.scope=this.options.scope==='local'?'local':'global';delete this.options.search;delete this.options.tags;this.options.groups=Array.isArray(this.options.groups)?this.options.groups:[];this.state.tab='graph';delete this.state.propertyMode;delete this.state.propertySort;this.state.ratio=Math.min(.85,Math.max(.18,Number(this.state.ratio)||.53));this.build();this.bind();this.switchFile();if(File.isDocumentEdited?.())this.scheduleEdit();this.saveState();
 }
 key(file){return this.path.resolve(file).replace(/\\/g,'/').toLowerCase();}
 readState(){try{return JSON.parse(localStorage.getItem('et-research-sidebar-v1'))||{};}catch{return{};}}
 saveState(){delete this.options.search;delete this.options.tags;try{localStorage.setItem('et-research-sidebar-v1',JSON.stringify({...this.state,options:this.options}));return true;}catch{return false;}}
 button(label,name,action){const b=el('button','et-rs-icon');b.type='button';b.title=label;b.setAttribute('aria-label',label);if(icon[name])b.innerHTML='<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">'+icon[name]+'</svg>';else b.textContent=name;b.onclick=action;return b;}
 build(){
  this.sidebar=document.getElementById('typora-sidebar');if(!this.sidebar)return;this.sidebar.classList.add('et-research-sidebar');this.panel=el('section','et-research-panel');this.panel.id='et-research-panel';
  this.splitter=el('div','et-research-splitter');this.splitter.tabIndex=0;this.splitter.setAttribute('role','separator');this.splitter.setAttribute('aria-label','调整文件大纲与图谱的高度');this.splitter.setAttribute('aria-orientation','horizontal');this.splitter.append(el('span'));this.panel.append(this.splitter);
  this.bar=el('div','et-rs-tabbar');this.bar.setAttribute('role','tablist');this.graphTab=this.button('局部关系图谱','graph',()=>this.selectTab('graph'));this.graphTab.setAttribute('role','tab');this.title=el('span','et-rs-title');this.fold=this.button('折叠下方面板','collapse',()=>{this.state.collapsed=!this.state.collapsed;this.layout();this.saveState();});this.bar.append(this.graphTab,this.title,this.fold);this.panel.append(this.bar);
  this.body=el('div','et-rs-body');this.panel.append(this.body);this.graphPane=el('div','et-rs-graph-pane');this.graphHost=el('div','et-rs-canvas');this.nodeMenu=new ResearchGraphMenu(this);this.graph=new ResearchGraphView(this.graphHost,node=>this.openNode(node),(node,event)=>this.nodeMenu.show(node,event));this.graphActions=el('div','et-rs-graph-actions');this.scopeButtons=el('div','et-rs-scope-buttons');this.localButton=this.button('局部图谱','局部',()=>this.setGraphScope('local'));this.globalButton=this.button('全局图谱','全局',()=>this.setGraphScope('global'));this.scopeButtons.append(this.localButton,this.globalButton);this.depthButton=this.button('3D 透视视图','3D',()=>this.setDepthView(!this.options.depthView));this.depthButton.classList.add('et-rs-depth-button');this.graphActions.append(this.scopeButtons,this.depthButton,this.button('图谱设置','settings',()=>{this.settings.hidden=!this.settings.hidden;if(this.settings.hidden)this.cancelGraphPalette();}),this.button('自然布局','graph',()=>this.naturalLayout()),this.button('适应图谱','fit',()=>this.graph.fit()),this.button('刷新索引','refresh',()=>this.refresh()));
  this.graphPane.append(this.graphHost,this.graphActions);
  this.status=el('div','et-rs-status');this.relations=el('details','et-rs-relations');this.relationSummary=el('summary',null,'入链 · 出链');this.relationList=el('div','et-rs-relation-list');this.relations.append(this.relationSummary,this.relationList);this.graphPane.append(this.status,this.relations);this.body.append(this.graphPane);
  this.settings=el('div','et-rs-settings');this.settings.hidden=true;this.graphPane.append(this.settings);this.renderSettings();
  this.message=el('div','et-rs-message');this.message.hidden=true;this.panel.append(this.message);this.sidebar.insertBefore(this.panel,document.getElementById('ty-sidebar-footer'));this.graphTab.id='et-rs-graph-tab';this.graphPane.setAttribute('role','tabpanel');this.graphPane.setAttribute('aria-labelledby',this.graphTab.id);
  // Keep Typora's delegated tree/editor handlers out of controls in the new pane.
  for(const event of ['mousedown','click','dblclick','keydown','contextmenu'])this.panel.addEventListener(event,e=>e.stopPropagation());
  this.splitter.addEventListener('pointerdown',e=>{if(e.button!==0)return;e.preventDefault();this.state.collapsed=false;const r=this.sidebar.getBoundingClientRect();this.drag={start:this.state.ratio,top:r.top,height:r.height,y:e.clientY};this.splitter.setPointerCapture(e.pointerId);document.body.classList.add('et-rs-resizing');});
  this.splitter.addEventListener('pointermove',e=>{if(!this.drag)return;this.drag.y=e.clientY;if(!this.dragRaf)this.dragRaf=requestAnimationFrame(()=>{this.dragRaf=0;if(!this.drag)return;this.state.ratio=Math.min(.85,Math.max(.18,(this.drag.y-this.drag.top)/this.drag.height));this.layout();});});
  const finish=e=>{if(!this.drag)return;if(e?.type==='pointercancel')this.state.ratio=this.drag.start;this.drag=null;if(this.dragRaf)cancelAnimationFrame(this.dragRaf);this.dragRaf=0;document.body.classList.remove('et-rs-resizing');this.layout();this.saveState();};this.splitter.addEventListener('pointerup',finish);this.splitter.addEventListener('pointercancel',finish);this.splitter.addEventListener('lostpointercapture',finish);window.addEventListener('blur',finish);
  this.splitter.addEventListener('keydown',e=>{if(['ArrowUp','ArrowDown','Home','End'].includes(e.key)){e.preventDefault();this.state.collapsed=false;this.state.ratio=e.key==='Home'?.18:e.key==='End'?.85:Math.min(.85,Math.max(.18,this.state.ratio+(e.key==='ArrowDown'?.03:-.03)));this.layout();this.saveState();}});this.splitter.addEventListener('dblclick',()=>{this.state.ratio=.53;this.state.collapsed=false;this.layout();this.saveState();});
  this.resize=new ResizeObserver(()=>this.layout());this.resize.observe(this.sidebar);this.selectTab(this.state.tab,false);this.layout();
 }
 layout(){if(!this.sidebar)return;const h=this.sidebar.clientHeight,footer=0,top=this.state.collapsed?Math.max(70,h-40):Math.max(90,Math.min(h-150,h*this.state.ratio));if(this.sidebar.style.getPropertyValue('--et-rs-top')!==top+'px')this.sidebar.style.setProperty('--et-rs-top',top+'px');if(this.sidebar.style.getPropertyValue('--et-rs-footer')!==footer+'px')this.sidebar.style.setProperty('--et-rs-footer',footer+'px');this.body.hidden=!!this.state.collapsed;this.fold.setAttribute('aria-expanded',String(!this.state.collapsed));this.fold.title=this.state.collapsed?'展开下方面板':'折叠下方面板';this.splitter.setAttribute('aria-valuenow',String(Math.round(this.state.ratio*100)));this.splitter.setAttribute('aria-valuemin','18');this.splitter.setAttribute('aria-valuemax','85');
  // The graph host has its own ResizeObserver. Reading it immediately after
  // writing sidebar geometry forces a second document layout on every resize.
 }
 selectTab(_tab,save=true){this.state.tab='graph';if(save)this.state.collapsed=false;this.graphPane.hidden=false;this.graphTab.setAttribute('aria-selected','true');this.updateScope();this.layout();this.graph.request();if(save)this.saveState();}
 updateScope(){const global=this.options.scope==='global';this.title.textContent=global?'全局关系图谱':'局部关系图谱';this.graphTab.title=this.title.textContent;this.graphTab.setAttribute('aria-label',this.title.textContent);this.localButton.setAttribute('aria-pressed',String(!global));this.globalButton.setAttribute('aria-pressed',String(global));this.applyTheme();}
 normalizeLightColors(input){const colors={};for(const key of Object.keys(lightGraphColors))if(typeof input?.[key]==='string'&&/^#[\da-f]{6}$/i.test(input[key])&&(key!=='bg'||this.isLightBackground(input[key])))colors[key]=input[key].toLowerCase();return colors;}
 isLightBackground(hex){const rgb=[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4);return rgb[0]*.2126+rgb[1]*.7152+rgb[2]*.0722>=.35;}
 applyTheme(){const dark=!!this.options.darkGraph;this.panel.classList.toggle('et-rs-dark',dark);this.nodeMenu.menu.classList.toggle('et-rs-dark',dark);const colors={...lightGraphColors,...this.normalizeLightColors(this.graphPaletteDraft?.colors||this.options.lightColors)};for(const key of Object.keys(lightGraphColors))this.graphHost.style.setProperty('--et-graph-'+key,dark?'':colors[key]);this.graphHost.style.color=dark?'':colors.text;this.graphHost.style.backgroundColor=dark?'':colors.bg;if(this.lightColorBox)this.lightColorBox.disabled=dark;}
 setGraphScope(scope){this.nodeMenu.close();if(scope!==this.options.scope)this.outline.reset();this.options.scope=scope;this.saveState();this.updateScope();this.renderSettings();this.renderGraph();this.graph.fit();}
 notify(text){this.message.textContent=text;this.message.hidden=false;clearTimeout(this.messageTimer);this.messageTimer=setTimeout(()=>this.message.hidden=true,6500);}
 hiddenKey(){return this.options.scope==='global'?'global:'+this.key(this.root||this.file):this.key(this.file);}
 hiddenNodes(){const saved=this.file&&this.state.hiddenNodes?.[this.hiddenKey()];return Array.isArray(saved)?saved:[];}
 setNodeHidden(id,hidden){if(!this.file||id===this.key(this.file))return;const ids=new Set(this.hiddenNodes());if(hidden)ids.add(id);else ids.delete(id);this.state.hiddenNodes={...this.state.hiddenNodes,[this.hiddenKey()]:[...ids]};this.saveState();this.renderGraph();this.notify(hidden?'已从此图谱隐藏；清除筛选或右键可恢复。':'已恢复节点。');}
 restoreHiddenNodes(){if(this.file&&this.state.hiddenNodes)delete this.state.hiddenNodes[this.hiddenKey()];this.saveState();this.renderGraph();this.graph.fit();}
 clearFilters(){if(this.file&&this.state.hiddenNodes)delete this.state.hiddenNodes[this.hiddenKey()];Object.assign(this.options,{incoming:true,outgoing:true});this.saveState();this.renderSettings();this.renderGraph();this.graph.fit();}
 updateDepthButton(){const tree=!!this.graph?.outlineMode;this.depthButton.disabled=tree;this.depthButton.setAttribute('aria-pressed',String(!tree&&!!this.options.depthView));this.depthButton.title=tree?'标题展开时按文章层级排列，收起后恢复原视图':'3D 透视视图';}
 setDepthView(value){this.options.depthView=!!value;this.saveState();this.renderSettings();this.graph.configure(this.options);this.graph.fit();}
 naturalLayout(){Object.assign(this.options,naturalForces,{interlinks:true});this.saveState();this.renderSettings();this.renderGraph();if(this.graph.data)this.graph.relayout();this.notify(this.graph.outlineMode?'已按文章顺序重新排列标题。':'已采用二维自然布局：按实际链接聚散，连接越多，节点越大、颜色越深。');}
 section(name){const d=el('details','et-rs-section');d.open=true;d.append(el('summary',null,name));this.settings.append(d);return d;}
 renderSettings(){
  this.updateScope();this.updateDepthButton();this.settings.replaceChildren();const head=el('div','et-rs-settings-head');head.append(el('strong',null,'图谱设置'),this.button('恢复图谱默认设置','refresh',()=>{this.graphPaletteDraft=null;this.state.graphPalettes.selected='system';this.options={...defaults,groups:[]};this.syncGraphPalette();this.saveState();this.renderSettings();this.renderGraph();}),this.button('关闭图谱设置','close',()=>{this.settings.hidden=true;this.cancelGraphPalette();}));this.settings.append(head);
  const filter=this.section('筛选'),scope=el('div','et-rs-scope');this.scopeLabel=el('div',null,this.root||'请先保存文档或选择文件夹');this.scopeLabel.title=this.root||'';scope.append(this.scopeLabel);
  if(File.getMountFolder?.())scope.append(el('p','et-rs-help','范围跟随 Typora「文件 → 打开文件夹」，包含其子文件夹。'));
  else{const choose=el('button',null,'选择索引文件夹');choose.onclick=async()=>{try{const r=await JSBridge.invoke('dialog.showOpenDialog',{properties:['openDirectory']});if(r.filePaths?.[0]){this.state.customRoot=r.filePaths[0];this.saveState();this.switchFile(true);}}catch(e){this.notify('无法选择文件夹：'+e.message);}};const auto=el('button',null,'跟随当前文件夹');auto.onclick=()=>{delete this.state.customRoot;this.saveState();this.switchFile(true);};scope.append(choose,auto);}filter.append(scope);

  const change=(key,value,graph=true)=>{this.options[key]=value;if(key==='darkGraph')this.applyTheme();this.saveState();if(graph)this.renderGraph();else this.graph.configure(this.options);this.updateDepthButton();};
  const range=(parent,label,key,min,max,step,graph=false)=>{const row=el('label','et-rs-range'),top=el('span',null,label),value=el('output',null,String(this.options[key])),input=el('input');input.type='range';input.min=min;input.max=max;input.step=step;input.value=this.options[key];input.setAttribute('aria-label',label);top.append(value);row.append(top,input);parent.append(row);input.oninput=()=>{value.textContent=input.value;this.options[key]=Number(input.value);if(graph){clearTimeout(this.rangeTimer);this.rangeTimer=setTimeout(()=>change(key,Number(input.value),true),90);}else{if(!this.controlRaf)this.controlRaf=requestAnimationFrame(()=>{this.controlRaf=0;this.graph.configure(this.options);});}};input.onchange=()=>this.saveState();};
  const toggle=(parent,label,key,graph=true)=>{const row=el('label','et-rs-toggle'),input=el('input');input.type='checkbox';input.checked=!!this.options[key];input.onchange=()=>change(key,input.checked,graph);row.append(el('span',null,label),input);parent.append(row);};
  if(this.options.scope==='local'){range(filter,'关系深度','depth',1,5,1,true);for(const [label,key]of [['入链（反向链接）','incoming'],['出链（正向链接）','outgoing'],['其他节点之间的链接','interlinks']])toggle(filter,label,key);}else filter.append(el('p','et-rs-help','全局显示索引文件夹中的笔记，包含没有入链和出链的孤立笔记。'));
  toggle(filter,'非 Markdown 附件','excludeNonMarkdown');filter.append(el('p','et-rs-help','勾选后排除所有非 Markdown 附件的节点和连线。取消勾选可显示非图片附件，图片仍不加入图谱。'));toggle(filter,'仅显示已存在文件','existingOnly');
  const groups=this.section('颜色组');this.groupBox=el('div');groups.append(this.groupBox);const add=el('button',null,'＋ 新建颜色组');add.onclick=()=>{this.options.groups.push({query:'',color:'#ad82b8'});this.renderGroups();};groups.append(add);this.renderGroups();
  const appearance=this.section('外观');appearance.append(el('p','et-rs-help','关联文件越多，节点越大、颜色越深；入链和出链按文件去重。'));toggle(appearance,'暗色背景','darkGraph',false);toggle(appearance,'3D 透视','depthView',false);range(appearance,'远线淡化程度','distanceFade',0,1,.05);toggle(appearance,'箭头','arrows',false);range(appearance,'文字不透明度','textOpacity',0,1,.05);range(appearance,'节点大小','nodeSize',.5,3,.05);range(appearance,'连线粗细','lineWidth',.3,4,.1);
  const colorSection=this.section('图谱配色');this.renderLightColors(colorSection);
  const force=this.section('力导向布局'),natural=el('button',null,'应用自然布局');natural.onclick=()=>this.naturalLayout();force.append(natural);toggle(force,'大型图谱按文件夹聚拢','folderGrouping',false);range(force,'图谱向心力','center',0,1,.01);range(force,'节点排斥力','repulsion',0,5,.05);range(force,'相连节点吸引力','attraction',0,3,.05);range(force,'连线长度','linkDistance',30,350,1);range(force,'最多显示节点','maxNodes',100,1000,100,true);
 }
 initGraphPalettes(){
  const raw=this.state.graphPalettes,schemes=[],ids=new Set(),names=new Set(['系统默认']);
  for(const item of Array.isArray(raw?.schemes)?raw.schemes:[]){
   const name=typeof item?.name==='string'?item.name.trim().slice(0,32):'',colors=this.normalizeLightColors(item?.colors);
   if(!/^graph-[\w-]+$/.test(item?.id)||!name||ids.has(item.id)||names.has(name.toLowerCase())||Object.keys(colors).length!==5)continue;
   ids.add(item.id);names.add(name.toLowerCase());schemes.push({id:item.id,name,colors});
  }
  let selected=ids.has(raw?.selected)?raw.selected:'system';
  if(raw?.version!==1){
   const colors={...lightGraphColors,...this.options.lightColors};
   if(Object.keys(lightGraphColors).some(key=>colors[key]!==lightGraphColors[key])){
    const existing=schemes.find(s=>Object.keys(colors).every(key=>s.colors[key]===colors[key]));
    if(existing)selected=existing.id;
    else{let name='原有配色',i=2;while(names.has(name.toLowerCase()))name='原有配色 '+i++;let id='graph-legacy',j=2;while(ids.has(id))id='graph-legacy-'+j++;schemes.push({id,name,colors});selected=id;}
   }
  }
  this.state.graphPalettes={version:1,selected,schemes};this.syncGraphPalette();
 }
 syncGraphPalette(){const s=this.state.graphPalettes;this.options.lightColors={...(s.schemes.find(p=>p.id===s.selected)?.colors||lightGraphColors)};}
 graphPaletteError(text){if(this.graphPaletteWarning){this.graphPaletteWarning.textContent=text;this.graphPaletteWarning.hidden=!text;}}
 commitGraphPalette(next){
  const old=this.state.graphPalettes,colors=this.options.lightColors;this.state.graphPalettes=next;this.syncGraphPalette();
  if(!this.saveState()){this.state.graphPalettes=old;this.options.lightColors=colors;this.graphPaletteError('保存失败，请稍后重试。');return false;}
  this.graphPaletteDraft=null;this.renderLightColors(this.graphColorSection);this.graph.request();return true;
 }
 cancelGraphPalette(){if(!this.graphPaletteDraft)return;this.graphPaletteDraft=null;if(this.graphColorSection)this.renderLightColors(this.graphColorSection);this.graph.request();}
 editGraphPalette(create){
  if(this.options.darkGraph)return;
  const saved=this.state.graphPalettes,scheme=saved.schemes.find(s=>s.id===saved.selected);
  if(create&&saved.schemes.length>=100){this.graphPaletteError('最多保存 100 个配色方案。');return;}
  if(!create&&!scheme)return;
  this.graphPaletteDraft={id:create?null:scheme.id,name:create?'':scheme.name,colors:{...(this.graphPaletteDraft?.colors||this.options.lightColors)},invalid:new Set(),values:{}};
  this.renderLightColors(this.graphColorSection);this.graphPaletteName.focus();
 }
 saveGraphPalette(){
  const draft=this.graphPaletteDraft;if(!draft||this.options.darkGraph)return;
  const name=draft.name.trim(),saved=this.state.graphPalettes;
  if(!name||name.length>32){this.graphPaletteError('请填写 1–32 个字符的方案名称。');this.graphPaletteName.setAttribute('aria-invalid','true');this.graphPaletteName.focus();return;}
  if(name==='系统默认'||saved.schemes.some(s=>s.id!==draft.id&&s.name.toLowerCase()===name.toLowerCase())){this.graphPaletteError('此方案名称已存在，请换一个名称。');this.graphPaletteName.setAttribute('aria-invalid','true');this.graphPaletteName.focus();return;}
  if(draft.invalid.size||Object.keys(this.normalizeLightColors(draft.colors)).length!==5){this.graphPaletteError('请检查颜色值，背景需要使用浅色。');return;}
  if(!draft.id&&saved.schemes.length>=100){this.graphPaletteError('最多保存 100 个配色方案。');return;}
  const id=draft.id||'graph-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8),scheme={id,name,colors:{...draft.colors}};
  this.commitGraphPalette({...saved,selected:id,schemes:draft.id?saved.schemes.map(s=>s.id===id?scheme:s):[...saved.schemes,scheme]});
 }
 renderLightColors(section){
  this.graphColorSection=section;section.replaceChildren(el('summary',null,'图谱配色'));
  const box=el('fieldset','et-rs-graph-palettes');this.lightColorBox=box;section.append(box);
  const saved=this.state.graphPalettes,draft=this.graphPaletteDraft,scheme=saved.schemes.find(s=>s.id===saved.selected),colors=draft?.colors||this.options.lightColors;
  const selector=el('select');selector.setAttribute('aria-label','图谱配色方案');const system=el('option',null,'系统默认');system.value='system';selector.append(system);
  if(saved.schemes.length){const group=el('optgroup');group.label='我的方案';for(const s of saved.schemes){const option=el('option',null,s.name);option.value=s.id;group.append(option);}selector.append(group);}
  selector.value=saved.selected;selector.onchange=()=>{if(!this.commitGraphPalette({...saved,selected:selector.value}))selector.value=saved.selected;};
  const preview=el('div','et-rs-palette-swatches');preview.setAttribute('aria-hidden','true');for(const key of Object.keys(lightGraphColors)){const swatch=el('i');swatch.dataset.colorKey=key;swatch.style.backgroundColor=colors[key];preview.append(swatch);}
  const picker=el('div','et-rs-palette-choice');picker.append(preview,draft?el('strong','et-rs-palette-editor-title',draft.id?'编辑配色方案':'新增配色方案'):selector);box.append(picker);
  const actions=el('div','et-rs-palette-actions');
  const button=(label,action,fn)=>{const b=el('button',null,label);b.type='button';b.dataset.paletteAction=action;b.onclick=fn;return b;};
  actions.append(button('＋ 新增配色方案','new',()=>this.editGraphPalette(true)));
  if(scheme&&!draft){actions.append(button('编辑','edit',()=>this.editGraphPalette(false)),button('删除','delete',()=>{const row=el('div','et-rs-palette-confirm'),label=el('span',null,'删除“'+scheme.name+'”？');row.append(label,button('取消','keep',()=>this.renderLightColors(section)),button('删除方案','confirm-delete',()=>this.commitGraphPalette({...saved,selected:'system',schemes:saved.schemes.filter(s=>s.id!==scheme.id)})));actions.replaceWith(row);}));}
  if(!draft)box.append(actions);
  if(draft){const label=el('label','et-rs-palette-name','方案名称'),name=el('input');name.value=draft.name;name.maxLength=32;name.placeholder='给这套配色起个名字';name.setAttribute('aria-label','图谱方案名称');name.oninput=()=>{draft.name=name.value;name.removeAttribute('aria-invalid');this.graphPaletteError('');};label.append(name);box.append(label);this.graphPaletteName=name;}
  const fields=el('div','et-rs-light-colors');box.append(fields);
  for(const [key,label]of [['bg','背景'],['node','节点'],['edge','连线'],['accent','悬停与选中'],['text','名称文字']]){
   const row=el('label'),picker=el('input'),hex=el('input');picker.type='color';picker.value=colors[key];picker.setAttribute('aria-label','图谱'+label+'颜色');hex.value=draft?.values[key]??colors[key];if(draft?.invalid.has(key))hex.setAttribute('aria-invalid','true');hex.maxLength=7;hex.setAttribute('aria-label','图谱'+label+'十六进制');picker.disabled=!draft;hex.readOnly=!draft;
   const change=value=>{
    if(!draft||this.options.darkGraph)return;draft.values[key]=value;
    if(!/^#[\da-f]{6}$/i.test(value)||key==='bg'&&!this.isLightBackground(value)){draft.invalid.add(key);hex.setAttribute('aria-invalid','true');this.graphPaletteError(key==='bg'?'背景请使用浅色的六位颜色值。':'请输入六位颜色值，例如 #628bb7。');return;}
    draft.invalid.delete(key);hex.removeAttribute('aria-invalid');draft.colors[key]=value.toLowerCase();picker.value=hex.value=draft.colors[key];preview.querySelector('[data-color-key="'+key+'"]').style.backgroundColor=draft.colors[key];this.graphPaletteError('');this.applyTheme();this.graph.request();
   };
   picker.oninput=()=>change(picker.value);hex.oninput=()=>change(hex.value);row.append(el('span',null,label),picker,hex);fields.append(row);
  }
  this.graphPaletteWarning=el('p','et-rs-palette-warning');this.graphPaletteWarning.hidden=true;this.graphPaletteWarning.setAttribute('role','status');box.append(this.graphPaletteWarning);
  if(draft){const footer=el('div','et-rs-palette-footer');footer.append(button('取消','cancel',()=>this.cancelGraphPalette()),button('保存并应用','save',()=>this.saveGraphPalette()));box.append(footer);}
  this.applyTheme();
 }

 renderGroups(){this.groupBox.replaceChildren();this.options.groups.forEach((group,i)=>{const row=el('div','et-rs-group'),query=el('input'),color=el('input');query.placeholder='path:第3章 / file:目录';query.value=group.query;query.setAttribute('aria-label','颜色组条件');color.type='color';color.value=group.color;color.setAttribute('aria-label','颜色组颜色');query.onchange=()=>{group.query=query.value;this.saveState();this.graph.request();};color.oninput=()=>{group.color=color.value;this.graph.request();};color.onchange=()=>this.saveState();row.append(query,color,this.button('移除颜色组','close',()=>{this.options.groups.splice(i,1);this.saveState();this.renderGroups();this.graph.request();}));this.groupBox.append(row);});}
 defaultRoot(file){return File.getMountFolder?.()||this.state.customRoot||(file?this.path.dirname(file):'');}
 bind(){
  this.poll=setInterval(()=>this.switchFile(),1200);
  // Native navigation announces the target before loading its editor contents.
  // Reuse the folder index without ever reading the previous editor as the target.
  document.addEventListener('et-document-leaving',e=>{clearTimeout(this.editTimer);if(e.detail?.file)this.switchFile(false,e.detail.file);});
  document.addEventListener('et-document-loaded',()=>{this.switchFile();if(File.isDocumentEdited?.())this.scheduleEdit();});
  document.addEventListener('et-document-saved-as',()=>this.switchFile(true));
  // Formula/image rendering also mutates #write. Only native document changes
  // (including undo/redo) should refresh graph links.
  const self=this,changed=File.updateChangeCount;
  if(typeof changed==='function')File.updateChangeCount=function(type,...args){const result=changed.call(this,type,...args);if([File.ChangeType.NSChangeDone,File.ChangeType.NSChangeUndone,File.ChangeType.NSChangeRedone].includes(type))self.scheduleEdit();return result;};
  document.addEventListener('et-library-relations-changed',()=>this.refreshLibraryRelations());
  window.addEventListener('focus',()=>{if(Date.now()-(this.lastRefresh||0)>10000)this.refresh();});window.addEventListener('beforeunload',()=>{this.flushIndexCache();this.watcher?.close();this.worker?.terminate();});
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)this.graph.request();});
 }
 scheduleEdit(){if(File.isFileLoading?.()||this.file!==File.bundle?.filePath)return;this.outline.schedule();clearTimeout(this.editTimer);this.editTimer=setTimeout(()=>this.refresh({incremental:true,edit:true}),600);}
 queueIndexCache(index){this.pendingIndexCache=index;if(this.cacheWrite)return;const save=()=>{this.cacheWrite=null;this.flushIndexCache();};this.cacheWrite=typeof requestIdleCallback==='function'?requestIdleCallback(save,{timeout:1500}):setTimeout(save,250);}
 flushIndexCache(){const index=this.pendingIndexCache;this.pendingIndexCache=null;if(index)this.indexCache.save(index);}
 pausePathChange(){
  this.pathChangeDepth=(this.pathChangeDepth||0)+1;this.watcher?.close();this.watcher=null;clearTimeout(this.watchTimer);
  return (from,to)=>{this.pathChangeDepth--;const map=file=>{if(!file||!from||!to)return file;const relative=this.path.relative(from,file);return relative!=='..'&&!relative.startsWith('..'+this.path.sep)&&!this.path.isAbsolute(relative)?this.path.join(to,relative):file;};if(from!==to&&this.state.customRoot){this.state.customRoot=map(this.state.customRoot);this.saveState();}if(!this.pathChangeDepth)this.switchFile(true,map(this.file));};
 }
 switchFile(force=false,target){if(this.pathChangeDepth)return;if(!target&&File.isFileLoading?.()&&this.file)return;const file=target||File.bundle?.filePath||'',root=this.defaultRoot(file);if(!force&&file===this.file&&root===this.root){if(this.graph.visible())this.graph.request();return;}this.nodeMenu.close();if(file!==this.file||root!==this.root)this.outline.reset();const rootChanged=root!==this.root||!this.watcher;clearTimeout(this.editTimer);this.lastSource=null;this.file=file;this.root=root;this.settings.hidden=true;this.cancelGraphPalette();if(this.scopeLabel){this.scopeLabel.textContent=root||'请先保存文档或选择文件夹';this.scopeLabel.title=root;}if(rootChanged){this.requestId++;this.worker?.postMessage({cancel:true});this.activeRequest=null;this.pendingRefresh=null;this.index=null;this.graph.set({nodes:[],edges:[]},this.options,'');this.renderSettings();this.watcher?.close();clearTimeout(this.watchTimer);try{if(root)this.watcher=this.fs.watch(root,{recursive:true},(event,name)=>{if(!name||/(?:^|[\\/])\.|\.(资料|笔记|注释|标注)([\\/]|$)|node_modules/.test(name))return;clearTimeout(this.watchTimer);this.watchTimer=setTimeout(()=>this.refresh(),900);});}catch{}}
  if(!file||!root){this.index=null;this.graph.set({nodes:[],edges:[]},this.options,'');this.updateDepthButton();this.relationList.replaceChildren();this.relationSummary.textContent='入链 · 出链';}else{if(!this.index&&this.path.parse(root).root!==this.path.resolve(root)){const cached=this.indexCache.load(root);if(cached?.nodes.some(n=>n.id===this.key(file))){this.index=cached;this.indexFromCache=true;performance.mark('et-graph-cache-restored');}}if(this.index)this.renderGraph();}this.refresh({incremental:!rootChanged&&!force,overlay:false});
 }
 async refreshLibraryRelations(){
  const generation=this.libraryRequest=(this.libraryRequest||0)+1;
  try{const snapshot=await this.toolbar.knowledgeLibrary?.graphSnapshot();if(generation!==this.libraryRequest)return;this.libraryGraph=snapshot;this.renderGraph();}
  catch(error){if(generation===this.libraryRequest)this.notify('文库关联暂未更新：'+error.message);}
 }
 refresh({incremental=false,overlay=true,edit=false}={}){
  void this.refreshLibraryRelations();
  if(!this.root||!this.file){this.status.textContent='保存文档后显示关系图谱';return;}
  if(this.path.parse(this.root).root===this.path.resolve(this.root)){this.status.textContent='请选择具体笔记文件夹，避免索引整个磁盘';return;}
  // Do not cancel useful work when edits, saves and navigation arrive together.
  // A single queued job always uses the latest file/root and unsaved contents.
  if(this.activeRequest){const pending=this.pendingRefresh;this.pendingRefresh={incremental:incremental&&(pending?.incremental??true),overlay:overlay||!!pending?.overlay,edit:edit&&(pending?.edit??true)};return;}
  try{let source;if(overlay&&!File.isFileLoading?.()&&this.file===File.bundle?.filePath&&(edit||File.isDocumentEdited?.()!==false))source=File.editor.getMarkdown();
   if(edit&&(source===undefined||this.lastSource?.file===this.file&&this.lastSource.source===source))return;
   if(!this.worker){this.worker=new ResearchIndexClient(this.workerSource,this.fs);this.worker.on('message',m=>{if(m.id!==this.requestId)return;if(m.progress){if(!this.index)this.status.textContent='正在索引 '+m.progress+' 篇笔记…';return;}const request=this.activeRequest;this.activeRequest=null;if(m.error){this.lastSource=null;this.status.textContent='索引失败：'+m.error;}else{this.index=m.result;this.indexFromCache=false;this.lastRefresh=Date.now();this.renderGraph();if(request&&typeof request.source!=='string')this.queueIndexCache(m.result);}const pending=this.pendingRefresh;this.pendingRefresh=null;if(pending)this.refresh(pending);});this.worker.on('error',e=>{this.status.textContent='后台索引不可用：'+e.message;this.worker?.terminate();this.worker=null;this.activeRequest=null;this.pendingRefresh=null;this.lastSource=null;});}
   this.status.textContent=this.index?'正在更新关系…':'正在建立本地索引…';this.lastSource=typeof source==='string'?{file:this.file,source}:null;const request={id:++this.requestId,root:this.root,file:this.file,source,incremental};this.activeRequest=request;this.worker.postMessage(request);
  }catch(e){this.activeRequest=null;this.lastSource=null;this.status.textContent='无法读取索引文件夹：'+e.message;}
 }
 renderGraph(){if(!this.index)return;const data=this.outline.decorate(localGraph(this.toolbar.knowledgeLibrary?.mergeGraph(this.index,this.libraryGraph)||this.index,this.key(this.file),{...this.options,search:'',tags:false,hiddenNodes:this.hiddenNodes()}));this.updateScope();this.graph.set(data,this.options,this.key(this.file));this.updateDepthButton();this.status.textContent=data.nodes.length+' 个节点 · '+data.edges.length+' 条连线'+(data.headingCount?' · '+data.headingCount+' 个标题':'')+(data.isolated&&!data.headingCount?' · '+data.isolated+' 个孤立节点':'')+(data.omitted?' · 另有 '+data.omitted+' 个节点，可调高显示上限':'')+(data.omittedHeadings?' · 另有 '+data.omittedHeadings+' 个标题，可调高显示上限':'')+(data.omittedEdges?' · 另有 '+data.omittedEdges+' 条连线未绘制':'')+' · '+this.index.notes+' 篇笔记';if(this.index.warnings.length||this.index.limited)this.status.textContent+=' · 部分文件未索引';this.status.title=[this.status.textContent,this.root,...this.index.warnings,this.index.limited?'已达到 30000 文件索引上限':''].filter(Boolean).join('\n');
  this.relationSummary.textContent='入链 '+data.incoming.length+' · 出链 '+data.outgoing.length;this.relationList.replaceChildren();for(const [label,list]of [['入链',data.incoming],['出链',data.outgoing]]){this.relationList.append(el('strong',null,label));for(const node of list.slice(0,200)){const b=el('button','et-rs-link',node.label);b.title=node.relative;b.onclick=()=>this.openNode(node);b.oncontextmenu=e=>this.nodeMenu.show(node,e);if(this.hiddenNodes().includes(node.id)){b.classList.add('et-rs-link-hidden');b.title+='（已从图谱隐藏；右键可恢复）';}this.relationList.append(b);}if(list.length>200)this.relationList.append(el('span',null,'列表仅显示前 200 项'));}
 }
 openNode(node){if(node.kind==='library')return this.toolbar.knowledgeLibrary?.openGraphItem(node.libraryItemId);if(node.kind==='heading')return this.outline.jump(node);if(node.kind==='tag')return;if(!node.exists){this.notify('链接目标尚不存在：'+node.label);return;}if(!node.path)return;if(node.kind==='note'&&this.options.scope==='local'&&this.key(node.path)===this.key(this.file))return this.outline.cycle();this.toolbar.readingPosition?.cancelRestore();if(node.kind==='note'){this.options.scope='local';this.saveState();this.renderSettings();if(this.key(node.path)===this.key(this.file)){this.renderGraph();this.graph.fit();}else File.editor.library.openFile(this.path.normalize(node.path));}else File.editor.tryOpenUrl(this.path.normalize(node.path));}
}

