// The top toolbar stays docked; compact sizing follows the viewport.
class EditingToolbarTopMotion {
  constructor(toolbar) {
    this.toolbar=toolbar;this.host=toolbar.topHost;this.bar=toolbar.topToolbar;
    this.bar.removeAttribute('title');
    window.addEventListener('resize',()=>this.apply());
    this.apply();
  }
  apply() {
    const s=this.toolbar.uiSettings;s.topMode='docked';s.topCollapsed=false;s.responsive=true;
    this.host.dataset.placement='docked';this.host.dataset.collapsed='false';
    this.host.style.left='';this.host.style.top='';this.host.style.transform='';this.bar.inert=false;
    this.toolbar._applyToolbarButtonSize(this.bar,true);
  }
}
