# AI 阅读助手模块发布

主程序 v1.114.5，AI 模块 1.3.5，最低主程序版本 v1.114.3。主安装包不携带或自动登记 AI 模块；用户通过市场或本地 ZIP 单独安装并启用。升级保留原有安装记录，停用或卸载后不会自动恢复。本版提高阅读资料的源码容量至 2,097,152 字符，保留完整资料并去除相同来源的重复发送；编辑写回限制保留。主程序修复原生打开拦截的提示、重试和保存弹窗显示，不修改 Typora 授权。

本版将“项目环境”与技能、插件页的视觉样式统一：右上角安装按钮、检测/路径图标、分区标题和紧凑卡片。下拉查看单个环境，安装成功后清除进度与日志；保留全局与项目默认环境、一键安装和科研包验证，详见 [项目环境](python-runtime.md)。安装期间阻止停用模块，完成或取消后即可切换。

AI 1.3.5：欢迎页内置 16 条古典名言与诗句，下方显示书名或篇名及作者；每次打开助手或新建对话时随机更换，连续两次不重复。最低主程序要求 1.114.3，以确保项目环境及当前模块接口兼容。

## 边界和数据

独立包位于 files/plugin/editing-toolbar.modules/ai-reading-assistant，包含 module.json、main.js、styles.css、chatgpt.cjs 和 assets/（Monaco 编辑器、终端宿主、Notebook 内核桥接）。阅读问答、AI 编辑、网页助手、模型设置、对话、提示词、技能和 AI 插件界面随模块启停。项目侧栏、终端、代码编辑器与 Notebook 一并随 AI 模块启停。基础工具栏、Markdown 标签与收藏、双栏阅读、笔记、知识库及云备份留在主程序；共享连接存储仍由主程序维护。

原有模型配置、密钥、技能、插件连接及知识库 sessions 路径不变。停用停止生成及终端/Notebook 进程、关闭助手和开发窗口并保存会话及代码/Notebook 草稿；文件读写期间会提示稍后切换，备份失败会保留启用状态；当前窗口重新启用可恢复对应文档的会话和草稿。重启后可从历史会话找回已保存内容。取消已运行的代码不会撤销其已产生的文件。

## 生成发布文件

在 files/source 中执行（首次需要 npm ci）：

```powershell
node build.cjs
node build-module-release.cjs --repository 你的用户名/你的仓库
```

不提供 --repository 时只生成 ZIP 和 SHA256，适合本地导入，不生成虚构市场地址。默认输出 dist/modules。每次发布先在 build-ai-module.cjs 更新模块 version，保持 宿主接口兼容，改动宿主接口时提高 minHostVersion；构建工具会从 module.json 自动读取版本并校验。

## GitHub 发布和更新

1. 在 xiaozhi0507/typora-editing-toolbar 创建工具输出 tag 对应的 GitHub Release（本版为 ai-reading-assistant-v1.3.5），上传模块 ZIP 与 SHA256 文件；其他模块使用自己的 ID 和版本标签。
2. 上传验证完成后，将新条目合并到仓库 main 分支的 marketplace.json，保留其他模块。仓库 scripts/update-marketplace.cjs 提供合并工具。固定来源为 https://raw.githubusercontent.com/xiaozhi0507/typora-editing-toolbar/main/marketplace.json，不依赖 releases/latest。
3. 后续提高模块版本，重新生成发布文件并发布新的稳定 Release。用户每次打开插件市场会后台检查新版本，再主动选择下载经 SHA256 验证的新包。
4. 更新替换模块代码并保留数据；新下载的版本先停用，再由用户启用并确认执行本机代码。无需重装整个工具栏。

市场支持 HTTPS、版本比较、最低宿主版本检查、哈希校验和数据独立存储；自动检查但不会后台静默安装或执行新版本。官方 GitHub 来源已配置；手动移除后不会自动恢复。关闭或切换 Typora 窗口后，其他窗口会在收到状态通知或重新获得焦点时同步启停状态。慢速网络若超过下载限时，可下载 ZIP 后用“本地安装”导入。

## 开发约定

模块 activate(api) 返回异步清理函数。可用 api.registerBeforeStop(fn) 在卸载前保存草稿；检查抛错时保留模块和命令，并恢复启用状态。AI 能力使用 api.assistant.version=1；宿主接口变化必须同步提高最低宿主版本。模块样式、事件、计时器、观察器和请求按本次激活持有，停用会清理。模块执行受信任的本机代码，并非安全沙箱。

## 图标和文档网址

module.json 与 marketplace.json 支持 icon 和 documentationUrl。内置 AI 模块使用 icon: "ai-reading-assistant"，复用工具栏的书本星光图标。documentationUrl 填写你的 HTTPS 文档地址；支持页内锚点，不接受脚本地址或包含密码的网址。

没有网址时，点击问号填写；已配置后，点击打开、悬停显示完整网址、右键问号修改。本机覆盖保存在模块状态中，更新模块不会覆盖它。发布给其他用户的默认网址应写入 build-ai-module.cjs 的 manifest.documentationUrl 后重新构建；版本号也由该文件维护。右键模块卡片仍可查看版本、命令和卸载入口。

AI 1.3.5 为本次配套独立发行，保留 16 条欢迎名句。更新按钮位置由主程序控制：工具栏 1.114.5 起仅在“浏览市场”显示更新操作，“已安装”保留开关、版本、文档与卸载。更新 AI 模块不会自行替换主程序。
