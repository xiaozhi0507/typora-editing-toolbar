'use strict';
// Download complete resource trees before committing any library references.
// Original local files are never overwritten by a cloud version.
module.exports=async function restore(d,b,catalog,{signal,onProgress=()=>{},packageId=''}={}){
 d.check(signal,catalog.key);const selected=packageId?catalog.snapshots.filter(s=>s.packageId===packageId):catalog.snapshots;
 if(packageId&&!selected.length)throw Error('所选备份已变化，请重新打开云端文件');
 if(!selected.length)return {files:0,items:0,conflicts:0};
 const release=await b.lock('cloud.lock');try{
  const base=(await b.store.read()).data,root=b.path.join(b.store.root,'storage','drive-downloads'),receiptPath=b.path.join(b.root,'restore-'+b.digest(catalog.key).slice(0,24)+'.json');
  let receipt={items:{}};try{receipt=await b.json(receiptPath);}catch(e){if(e.code!=='ENOENT')throw e;}
  if(!receipt.items||typeof receipt.items!=='object')throw Error('本地下载记录损坏，请保留原记录');
  const unique=new Map(),copies=selected.flatMap(s=>s.files.map(f=>({snapshot:s,...f})));let total=0;
  if(copies.length>b.archive.limits.files)throw Error('历史文件过多，请选择一个备份版本同步');
  for(const f of copies){total+=f.bytes;unique.set(f.sha256,f);}
  if(total>b.archive.limits.bytes)throw Error('历史文件超过 2 GB，请选择一个备份版本同步');
  // Download and verify all data before exposing even one changed reference.
  let count=0;
  for(const f of unique.values()){
   d.check(signal,catalog.key);const row=catalog.rows.find(r=>r.path===f.path&&r.sha256===f.sha256),target=b.object(f.sha256);if(!row)throw Error('云端目录已变化');
   if(!await b.exists(target)||(await b.fingerprint(target,{signal})).sha256!==f.sha256)await d.download(b,catalog.key,row.remote,target,{signal});
   const actual=await b.fingerprint(target,{signal});if(actual.sha256!==f.sha256||actual.bytes!==f.bytes)throw Error('云端文件校验失败，未修改本地文献');
   onProgress('正在下载 '+(++count)+' / '+unique.size,'downloading');
  }
  await b.mkdir(root);const targets=new Map(),written=[],folders={...(receipt.folders||{})};let conflicts=0;
  // A complete snapshot directory keeps relative image/book links intact. If a
  // previously downloaded resource was edited, stage a new sibling directory.
  for(const snapshot of selected){
   let dir=folders[snapshot.packageId]||b.path.join(root,snapshot.packageId),conflict=false;
   if(b.path.dirname(dir)!==root||!b.path.basename(dir).startsWith(snapshot.packageId))throw Error('本地下载记录路径无效');
   for(const f of snapshot.files){const file=b.path.join(dir,...f.path.split('/'));if(await b.exists(file)&&(await b.fingerprint(file,{signal})).sha256!==f.sha256){conflict=true;break;}}
   if(conflict){dir=b.path.join(root,snapshot.packageId+'-copy-'+b.crypto.randomUUID().slice(0,12));conflicts++;}folders[snapshot.packageId]=dir;
   for(const f of snapshot.files){
    d.check(signal,catalog.key);const file=b.path.join(dir,...f.path.split('/'));await b.mkdir(b.path.dirname(file));
    if(!await b.exists(file)){await b.io.copyFile(b.object(f.sha256),file,b.store.fs.constants.COPYFILE_EXCL);written.push(file);}
    if((await b.fingerprint(file,{signal})).sha256!==f.sha256)throw Error('本地文件写入校验失败，请重试');
    targets.set(snapshot.packageId+'\n'+f.path,file);
   }
  }
  d.check(signal,catalog.key);if(!b.sameSource(base,(await b.store.read()).data))throw Error('下载期间本地知识库已变化，请重新同步');
  const next=JSON.parse(JSON.stringify(base)),byId=new Map(next.items.map(i=>[i.id,i])),chosen=new Map(),collections=new Map(next.collections.map(c=>[c.id,c]));
  // Catalog order is committed latest first, then older snapshots. Each paper
  // gets its newest available metadata; all older file trees stay on disk.
  for(const s of selected){for(const c of s.library.collections)if(!collections.has(c.id))collections.set(c.id,JSON.parse(JSON.stringify(c)));for(const item of s.library.items)if(!chosen.has(item.id))chosen.set(item.id,{item,s});}
  let added=0;const pendingReceipt={...receipt.items};
  for(const [id,{item,s}]of chosen){
   const existing=byId.get(id),record=receipt.items[id];let replaceable=!existing;const refs=item.files.map(ref=>{
    if(ref.linkType==='url')return {...ref};const file=targets.get(s.packageId+'\n'+ref.path);if(!file)throw Error('云端条目缺少附件');
    return {...b.store.fileRef(file,ref.kind),id:ref.id,name:ref.name};
   });
   if(!existing){const restored={...JSON.parse(JSON.stringify(item)),files:refs};next.items.push(restored);byId.set(id,restored);added++;}
   else {
    // Replace a previously downloaded reference only when its complete resource
    // tree still matches the last verified backup. Preserve edited trees intact.
    let unchanged=record?.replaceable===true&&record.itemHash===itemHash(b,existing);
    if(unchanged)for(const f of record.files||[]){if(!b.managed.inside(root,f.file)||!await b.exists(f.file)||(await b.fingerprint(f.file,{signal})).sha256!==f.sha256){unchanged=false;break;}}
    replaceable=!!unchanged;
    if(unchanged){const keepDeleted=existing.deleted;Object.assign(existing,JSON.parse(JSON.stringify(item)),{files:refs});if(keepDeleted)existing.deleted=keepDeleted;}
    else {let addedReference=false;for(const ref of refs){
     if(existing.files.some(f=>f.path===ref.path&&f.relative===ref.relative&&f.linkType===ref.linkType))continue;
     const duplicate=existing.files.some(f=>f.id===ref.id),copy={...ref,id:duplicate?b.crypto.randomUUID():ref.id};existing.files.push(copy);if(!addedReference)existing.defaultFile=copy.id;addedReference=true;
    }if(addedReference)conflicts++;}
   }
   const saved=byId.get(id);pendingReceipt[id]={replaceable,itemHash:itemHash(b,saved),files:s.files.map(f=>({file:targets.get(s.packageId+'\n'+f.path),sha256:f.sha256}))};
  }
  next.collections=[...collections.values()];const itemIds=new Set(next.items.map(i=>i.id)),collectionIds=new Set(next.collections.map(c=>c.id));
  for(const c of next.collections)if(c.parentId&&!collectionIds.has(c.parentId))c.parentId=null;
  for(const i of next.items){i.collections=(i.collections||[]).filter(id=>collectionIds.has(id));i.related=(i.related||[]).filter(id=>itemIds.has(id)&&id!==i.id);if(i.relatedOut)i.relatedOut=i.relatedOut.filter(id=>i.related.includes(id));}
  b.store.validate(next);onProgress('正在保存本地文献…','saving');d.check(signal,catalog.key);
  // Detect concurrent changes under the store lock; do not re-add a paper the
  // user deleted while the download was in progress.
  const committed=await b.store.commit(base,next,live=>{d.check(signal,catalog.key);if(!b.sameSource(base,live))throw Error('本地知识库已变化，请重新同步');});
  for(const [id,r]of Object.entries(pendingReceipt)){const item=committed.items.find(i=>i.id===id);if(item)r.itemHash=itemHash(b,item);}
  await b.atomic(receiptPath,JSON.stringify({version:1,folders,items:pendingReceipt}));
  return {files:written.length,items:added,conflicts,root};
 }finally{await release();}
};
function itemHash(b,item){const {modified,last,lastFile,metrics,...value}=item;return b.store.hash(value);}
