(function(){'use strict';try{
  if(window.__editingToolbarNoAutoInit)return;
  try{const reading=localStorage.getItem('et-reading-mode-v1');document.documentElement.classList.toggle('et-reading-mode',['true','read','protected'].includes(reading));document.documentElement.classList.toggle('et-protected-mode',reading==='protected');}catch{}
  // Shared by the head bootstrap and the main plugin. Start one stylesheet request
// early, and mount plugin UI only after the browser has applied that stylesheet.
function ensureEditingToolbarStyle(href) {
    let link = document.getElementById('editing-toolbar-style');
    const pending = window.__etToolbarStyle;
    if (pending && pending.link === link) return pending.ready;
    if (!link) {
        link = document.createElement('link');
        link.id = 'editing-toolbar-style';
        link.rel = 'stylesheet';
        link.href = href;
    }
    let resolve;
    const ready = new Promise(done => { resolve = done; });
    window.__etToolbarStyle = { link, ready };
    const finish = loaded => {
        link.removeEventListener('load', onLoad);
        link.removeEventListener('error', onError);
        if (loaded) performance.mark('et-toolbar-style-ready');
        else console.warn('[EditingToolbar] Stylesheet unavailable; toolbar was not mounted.');
        resolve(loaded);
    };
    const onLoad = () => finish(true);
    const onError = () => finish(false);
    link.addEventListener('load', onLoad);
    link.addEventListener('error', onError);
    if (!link.isConnected) {
        // Keep saved palette overrides after the base stylesheet in the cascade.
        document.head.insertBefore(link, document.getElementById('et-theme-palette-overrides'));
    }
    if (link.sheet) finish(true);
    return ready;
}

  try{ensureEditingToolbarStyle(new URL('./editing-toolbar.css',document.currentScript.src).href);}catch(error){console.warn('[EditingToolbar] Early stylesheet unavailable:',error);}
  const palette={key:'et-theme-palette-v1',toolbar:{},presets:{"chatgpt":{"name":"ChatGPT","group":"chatgpt","variants":{"light":{"surface":"#fcfcfc","ink":"#0d0d0d","accent":"#3a83f7","contrast":45},"dark":{"surface":"#000000","ink":"#ededed","accent":"#3a83f7","contrast":60}}},"absolutely":{"name":"Absolutely","group":"codex","variants":{"dark":{"surface":"#2d2d2b","ink":"#f9f9f7","accent":"#cc7d5e","contrast":60},"light":{"surface":"#f9f9f7","ink":"#2d2d2b","accent":"#cc7d5e","contrast":45}}},"ayu":{"name":"Ayu","group":"codex","variants":{"dark":{"surface":"#10141c","ink":"#bfbdb6","accent":"#e6b450","contrast":60}}},"catppuccin":{"name":"Catppuccin","group":"codex","variants":{"dark":{"surface":"#1e1e2e","ink":"#cdd6f4","accent":"#cba6f7","contrast":60},"light":{"surface":"#eff1f5","ink":"#4c4f69","accent":"#8839ef","contrast":45}}},"codex":{"name":"Codex","group":"codex","variants":{"dark":{"surface":"#111111","ink":"#fcfcfc","accent":"#0169cc","contrast":60},"light":{"surface":"#ffffff","ink":"#0d0d0d","accent":"#0169cc","contrast":45}}},"dracula":{"name":"Dracula","group":"codex","variants":{"dark":{"surface":"#282a36","ink":"#f8f8f2","accent":"#ff79c6","contrast":60}}},"everforest":{"name":"Everforest","group":"codex","variants":{"dark":{"surface":"#2d353b","ink":"#d3c6aa","accent":"#a7c080","contrast":60},"light":{"surface":"#fdf6e3","ink":"#5c6a72","accent":"#93b259","contrast":45}}},"github":{"name":"GitHub","group":"codex","variants":{"dark":{"surface":"#0d1117","ink":"#e6edf3","accent":"#1f6feb","contrast":60},"light":{"surface":"#ffffff","ink":"#1f2328","accent":"#0969da","contrast":45}}},"gruvbox":{"name":"Gruvbox","group":"codex","variants":{"dark":{"surface":"#282828","ink":"#ebdbb2","accent":"#458588","contrast":60},"light":{"surface":"#fbf1c7","ink":"#3c3836","accent":"#458588","contrast":45}}},"linear":{"name":"Linear","group":"codex","variants":{"dark":{"surface":"#0f0f11","ink":"#e3e4e6","accent":"#606acc","contrast":60},"light":{"surface":"#fcfcfd","ink":"#1b1b1b","accent":"#5e6ad2","contrast":45}}},"lobster":{"name":"Lobster","group":"codex","variants":{"dark":{"surface":"#111827","ink":"#e4e4e7","accent":"#ff5c5c","contrast":60}}},"material":{"name":"Material","group":"codex","variants":{"dark":{"surface":"#212121","ink":"#eeffff","accent":"#80cbc4","contrast":60}}},"matrix":{"name":"Matrix","group":"codex","variants":{"dark":{"surface":"#040805","ink":"#b8ffca","accent":"#1eff5a","contrast":60}}},"monokai":{"name":"Monokai","group":"codex","variants":{"dark":{"surface":"#272822","ink":"#f8f8f2","accent":"#99947c","contrast":60}}},"night-owl":{"name":"Night Owl","group":"codex","variants":{"dark":{"surface":"#011627","ink":"#d6deeb","accent":"#44596b","contrast":60}}},"nord":{"name":"Nord","group":"codex","variants":{"dark":{"surface":"#2e3440","ink":"#d8dee9","accent":"#88c0d0","contrast":60}}},"notion":{"name":"Notion","group":"codex","variants":{"dark":{"surface":"#191919","ink":"#d9d9d8","accent":"#3183d8","contrast":60},"light":{"surface":"#ffffff","ink":"#37352f","accent":"#3183d8","contrast":45}}},"og":{"name":"OG","group":"codex","variants":{"dark":{"surface":"#343541","ink":"#d1d5db","accent":"#10a37f","contrast":60}}},"one":{"name":"One","group":"codex","variants":{"dark":{"surface":"#282c34","ink":"#abb2bf","accent":"#4d78cc","contrast":60},"light":{"surface":"#fafafa","ink":"#383a42","accent":"#526fff","contrast":45}}},"oscurange":{"name":"Oscurange","group":"codex","variants":{"dark":{"surface":"#0b0b0f","ink":"#e6e6e6","accent":"#f9b98c","contrast":60}}},"proof":{"name":"Proof","group":"codex","variants":{"light":{"surface":"#f5f3ed","ink":"#2f312d","accent":"#3d755d","contrast":45}}},"raycast":{"name":"Raycast","group":"codex","variants":{"dark":{"surface":"#101010","ink":"#fefefe","accent":"#ff6363","contrast":60},"light":{"surface":"#ffffff","ink":"#030303","accent":"#ff6363","contrast":45}}},"rose-pine":{"name":"Rose Pine","group":"codex","variants":{"dark":{"surface":"#232136","ink":"#e0def4","accent":"#ea9a97","contrast":60},"light":{"surface":"#faf4ed","ink":"#575279","accent":"#d7827e","contrast":45}}},"sentry":{"name":"Sentry","group":"codex","variants":{"dark":{"surface":"#2d2935","ink":"#e6dff9","accent":"#7055f6","contrast":60}}},"solarized":{"name":"Solarized","group":"codex","variants":{"dark":{"surface":"#002b36","ink":"#839496","accent":"#d30102","contrast":60},"light":{"surface":"#fdf6e3","ink":"#657b83","accent":"#b58900","contrast":45}}},"temple":{"name":"Temple","group":"codex","variants":{"dark":{"surface":"#02120c","ink":"#c7e6da","accent":"#e4f222","contrast":60}}},"tokyo-night":{"name":"Tokyo Night","group":"codex","variants":{"dark":{"surface":"#1a1b26","ink":"#a9b1d6","accent":"#3d59a1","contrast":60}}},"vercel":{"name":"Vercel","group":"codex","variants":{"dark":{"surface":"#000000","ink":"#ededed","accent":"#006efe","contrast":50},"light":{"surface":"#ffffff","ink":"#171717","accent":"#006aff","contrast":40}}},"vscode-plus":{"name":"VS Code Plus","group":"codex","variants":{"dark":{"surface":"#1e1e1e","ink":"#d4d4d4","accent":"#007acc","contrast":60},"light":{"surface":"#ffffff","ink":"#000000","accent":"#007acc","contrast":45}}},"xcode":{"name":"Xcode","group":"codex","variants":{"dark":{"surface":"#1f1f24","ink":"#ffffff","accent":"#5482ff","contrast":60},"light":{"surface":"#ffffff","ink":"#000000","accent":"#0e0eff","contrast":45}}},"default":{"name":"原主题"},"ranunculus":{"name":"洋牡丹","light":["#f7f1e8","#f7f1e8","#f2e4d4","#6d5849","#6d5849","#ddcab5"],"dark":["#39342d","#39342d","#2e2824","#e5d4c1","#e5d4c1","#6b5948"]},"hydrangea":{"name":"绣球","light":["#dce3e4","#dce3e4","#ccd6d9","#152d7a","#152d7a","#bdcadf"],"dark":["#2f383e","#2f383e","#293137","#5284be","#5284be","#465d78"]},"freesia":{"name":"香雪兰","light":["#e8efe3","#e8efe3","#d2ddc4","#238349","#238349","#b9d4b7"],"dark":["#3f443c","#3f443c","#2b2f29","#70be88","#70be88","#45674b"]},"campanula":{"name":"风铃","light":["#fcf9f4","#fcf8f4","#f7e4e9","#238349","#238349","#e7cbd4"],"dark":["#303631","#303631","#1f221d","#70be88","#70be88","#4b6552"]},"rose":{"name":"玫瑰","light":["#fff5f5","#fff5f5","#df7a93","#8b2317","#df7a93","#efbdcb"],"dark":["#4b2e34","#4b2e34","#8b2317","#f0b8c0","#f0b8c0","#794552"]}},validHex(value){return typeof value==='string'&&/^#[\da-f]{6}$/i.test(value);},normalizeProfile(value){if(!value||!['surface','ink','accent'].every(k=>this.validHex(value[k])))return null;const out={};for(const k of ['surface','ink','accent','bold','annotation','selection','side','card'])if(this.validHex(value[k]))out[k]=value[k].toLowerCase();out.contrast=Number.isFinite(value.contrast)?Math.max(0,Math.min(100,Math.round(value.contrast))):60;return out;},supports(p,mode){return !!p&&(p===this.presets.default||!!p[mode]||!!p.variants?.[mode]);},selectedId(state=this.draft||this.state,mode=this.mode(state)){return state?.[mode]?.preset||state?.preset||'default';},profile(state=this.draft||this.state,mode=this.mode(state)){
  const p=this.palette(state,mode);let raw=p.variants?.[mode];
  if(!raw&&p[mode]){const c=p[mode],ink=this.textFor(c[0]),accent=this.contrast(c[3],c[0])>=4.5?c[3]:this.mix(c[3],ink,.5);raw={surface:c[0],side:c[1],card:c[2],ink,accent,bold:c[3],annotation:c[4],selection:c[5],contrast:mode==='dark'?60:45};}
  const overrides=state?.[mode]?.overrides||{};
  if(!raw&&!Object.keys(overrides).length)return null;
  const base=raw||this.presets.chatgpt.variants[mode],out={...base,...overrides};
  // Explicit component colors are independent of the three base colors.
  return out;
 },tokens(state=this.draft||this.state,mode=this.mode(state)){
  const p=this.profile(state,mode);if(!p)return null;
  const bg=p.surface,text=p.ink,accent=p.accent,contrast=p.contrast??60,dark=this.luminance(bg)<.19;
  const side=p.side||this.mix(bg,text,dark?.025:.016),card=p.card||this.mix(bg,text,dark?.05:.012),bold=p.bold||text;
  const border=this.mix(bg,text,.08+contrast*.002),muted=this.mix(text,bg,.48-contrast*.0015),hover=this.mix(card,accent,.09),active=this.mix(card,accent,.17),selection=p.selection||this.mix(bg,accent,.25);
  return{bg,side,card,text,sideText:text,cardText:text,bold,accent,link:accent,border,muted,hover,active,selection,selectionText:this.textFor(selection),annotation:p.annotation||accent,contrast};
 },normalize(input){
  const s={version:7,preset:'default',mode:['light','dark'].includes(input?.mode)?input.mode:'auto',scope:input?.scope==='plugin'?'plugin':'app',separate:input?.separate===true,saved:[]},ids=new Set(),names=new Set();
  const valid=v=>Array.isArray(v)&&[4,5,6].includes(v.length)&&v.every(c=>this.validHex(c));
  const expand=v=>[...v.slice(0,4),v[4]||v[3],v[5]||this.mix(v[3],v[0],.72)].map(c=>c.toLowerCase());
  for(const item of (Array.isArray(input?.saved)?input.saved:[]).slice(0,200)){
   const name=this.cleanName(item?.name);if(!/^user-[a-z\d-]{1,80}$/i.test(item?.id)||!name||ids.has(item.id)||names.has(name.toLowerCase()))continue;
   let saved;if(valid(item.light)&&valid(item.dark))saved={id:item.id,name,light:expand(item.light),dark:expand(item.dark)};
   else{const variants={};for(const mode of ['light','dark']){const p=this.normalizeProfile(item?.variants?.[mode]);if(p)variants[mode]=p;}if(!Object.keys(variants).length)continue;saved={id:item.id,name,variants};}
   s.saved.push(saved);ids.add(item.id);names.add(name.toLowerCase());
  }
  let catalog=this.catalog(s);if(Object.hasOwn(catalog,input?.preset))s.preset=input.preset;
  // Older releases stored edits against built-ins. Migrate them without changing originals.
  if(![3,4,5,6,7].includes(input?.version))for(const [id,p]of Object.entries(catalog)){
   if(!p.light||!p.dark)continue;const converted={};let changed=false;
   for(const mode of ['light','dark']){const v=input?.custom?.[id]?.[mode];converted[mode]=p[mode].map((c,i)=>this.validHex(v?.[i])?v[i].toLowerCase():c);if(v?.length===4)converted[mode][4]=converted[mode][3];if(v?.length&&v.length<6)converted[mode][5]=this.mix(converted[mode][3],converted[mode][0],.72);if(JSON.stringify(converted[mode])!==JSON.stringify(p[mode]))changed=true;}
   if(!changed)continue;if(p.id)Object.assign(p,converted);else{let name=p.name+' · 自定义',n=2;while(names.has(name.toLowerCase()))name=p.name+' · 自定义 '+n++;let newId='user-legacy-'+id;while(ids.has(newId))newId+='-x';s.saved.push({id:newId,name,...converted});names.add(name.toLowerCase());ids.add(newId);if(s.preset===id)s.preset=newId;}
  }
  catalog=this.catalog(s);
  for(const mode of ['light','dark']){const entry=[6,7].includes(input?.version)?input?.[mode]:null;let id=entry?.preset||s.preset;if(!Object.hasOwn(catalog,id)||!this.supports(catalog[id],mode))id='chatgpt';const overrides={};for(const k of ['surface','ink','accent','side','card','bold','annotation','selection'])if(this.validHex(entry?.overrides?.[k]))overrides[k]=entry.overrides[k].toLowerCase();if(Number.isFinite(entry?.overrides?.contrast))overrides.contrast=Math.max(0,Math.min(100,Math.round(entry.overrides.contrast)));s[mode]={preset:id,overrides};}
  // Preserve v6's derived surfaces/selection once, then keep every v7 color independent.
  if(input?.version===6)for(const mode of ['light','dark']){const o=s[mode].overrides,p=this.profile(s,mode);if(!p)continue;if(o.surface){const dark=this.luminance(p.surface)<.19;o.side=this.mix(p.surface,p.ink,dark?.025:.016);o.card=this.mix(p.surface,p.ink,dark?.05:.012);}if(o.accent)o.selection=this.mix(p.surface,p.accent,.25);}
  return s;
 },cleanName(value){return typeof value==='string'?value.replace(/[\u0000-\u001f\u007f]/g,'').trim().slice(0,32):'';},catalog(state=this.draft||this.state){return Object.assign({},this.presets,Object.fromEntries((state?.saved||[]).map(p=>[p.id,p])));},palette(state=this.draft||this.state,mode=this.mode(state)){return this.catalog(state)[this.selectedId(state,mode)]||this.presets.default;},read(){try{return this.normalize(JSON.parse(localStorage.getItem(this.key)));}catch{return this.normalize();}},rgb(hex){return [1,3,5].map(i=>parseInt(hex.slice(i,i+2),16));},mix(a,b,t){return '#'+this.rgb(a).map((v,i)=>Math.round(v+(this.rgb(b)[i]-v)*t).toString(16).padStart(2,'0')).join('');},luminance(hex){return this.rgb(hex).map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;}).reduce((s,v,i)=>s+v*[.2126,.7152,.0722][i],0);},textFor(bg){return this.luminance(bg)>.19?'#292a31':'#eeedf2';},contrast(a,b){const x=this.luminance(a),y=this.luminance(b);return(Math.max(x,y)+.05)/(Math.min(x,y)+.05);},mode(state=this.draft||this.state){return state.mode==='auto'?this.nativeMode:state.mode;},colors(state=this.draft||this.state){const t=this.tokens(state);return t?[t.bg,t.side,t.card,t.bold,t.annotation,t.selection]:undefined;},apply(){const s=this.draft||this.state,t=this.tokens(s),c=this.colors(s);this.currentColors=c;this.currentTokens=t;
  // The first-paint style is created before the toolbar stylesheet. Keep the
  // same element, but restore its cascade order when the full toolbar takes over.
  if(document.head.lastElementChild!==this.style)document.head.append(this.style);
  if(!c)this.style.textContent='';else{
   const {bg,side,card,bold,text,cardText,sideText,muted,border,hover,active,link,accent,selection,selectionText}=t,graphNode=this.mix(link,text,.45);
   const native=`--select-text-bg-color:${selection};--select-text-font-color:${selectionText};--bg-color:${bg};--text-color:${text};--side-bar-bg-color:${side};--control-text-color:${muted};--active-file-bg-color:${active};--active-file-text-color:${sideText};--item-hover-bg-color:${hover};--window-border:${border};--search-select-bg-color:${active};--search-select-text-color:${text};`;
   const et=`--et-accent:${accent};--et-surface:${card};--et-surface-strong:${card};--et-border:${border};--et-border-strong:${this.mix(text,bg,.60)};--et-text:${cardText};--et-text-dim:${this.mix(cardText,card,.30)};--et-hover:${hover};--et-active:${active};--et-shadow:0 8px 26px #0002;--et-shadow-soft:0 4px 14px #0002;`;
   const prefBg=card,prefText=text,prefAccent=accent;
   const panels=':is(#et-annotation-panel,#et-document-note-panel,#et-manual-mark-panel,#et-annotation-preview,#et-citation-preview,#et-split-citation-preview)';
   // Keep the rightmost selector restricted to bold elements. A descendant
   // wildcard inside :not() makes any ancestor style change (including a
   // sidebar's content inset) invalidate every MathJax node in the document.
   const strong=':where(strong,b):not([style*="color"],[style*="color"] strong,[style*="color"] b)';
   this.style.textContent=`@media screen {
    :root,.theme-dark,[data-theme="dark"]{${et}--et-annotation-preview-bg:${card};--et-annotation-rgb:${this.rgb(c[4]||bold).join(',')};--et-annotation-accent:${c[4]||bold};--et-annotation-opacity:${this.mode(s)==='dark'?.28:.16};--et-annotation-active-opacity:${this.mode(s)==='dark'?.42:.30};} .et-top-chrome button:focus-visible,.et-settings-dialog :focus-visible{outline-color:${accent};} .et-settings-row.et-drop-before{box-shadow:inset 0 2px ${accent};} .et-settings-row.et-drop-after{box-shadow:inset 0 -2px ${accent};} #editing-toolbar-top-host:not([data-placement="floating"]){background:${card};border-bottom-color:${border};} ${panels}{${native}${et}color:${cardText};color-scheme:${this.mode(s)};}
    #et-research-panel:not(.et-rs-dark),.et-rs-node-menu:not(.et-rs-dark){${native}${et}color-scheme:${this.mode(s)};--rs-accent:${link};--rs-border:${border};--et-graph-node:${graphNode};--et-graph-accent:${link};--et-graph-edge:${muted};--et-graph-bg:${side};background:${side};color:${sideText};}
    .et-settings-dialog{${native}color:${prefText};color-scheme:${this.mode(s)};--et-surface:${prefBg};--et-surface-strong:${prefBg};--et-text:${prefText};--et-text-dim:${this.mix(prefText,prefBg,.28)};--et-border:${this.mix(prefText,prefBg,.82)};--et-border-strong:${this.mix(prefText,prefBg,.64)};--et-hover:${this.mix(prefAccent,prefBg,.90)};--et-active:${this.mix(prefAccent,prefBg,.82)};--et-preferences-accent:${prefAccent};--et-preferences-on-accent:${this.textFor(prefAccent)};--et-preferences-error:${this.luminance(prefBg)<.19?'#ffb2be':'#b5263c'};}
    #et-manual-mark-panel{--et-mark-surface:${bg};--et-mark-card:${this.mix(bg,card,.25)};--et-mark-accent:${link};--et-mark-selected:${this.mix(bg,accent,.07)};background:var(--et-mark-surface);}
    ${s.scope==='app'?`:root{${native}} html,body,content,#write{background-color:${bg}!important;color:${text}!important;color-scheme:${this.mode(s)};}
    #typora-sidebar,#sidebar-content,#ty-sidebar-footer{background-color:${side}!important;color:${sideText}!important;}
    #typora-sidebar :is(.file-node-title,.file-list-item-file-name,.outline-item,.sidebar-tab){color:inherit;}
    #write ${strong}{color:${bold};} #write a:not([style*="color"]){color:${link};}
    #write :is(blockquote,hr,th,td){border-color:${border};} #write blockquote{color:${muted};}
    #write :is(.md-fences,code,.md-rawblock-container):not([style*="background"]){background-color:${this.mix(bg,card,.45)};}
    #write :is(th,tr:nth-child(2n) td):not([style*="background"]){background-color:${this.mix(bg,card,.4)};}
    #typora-source .CodeMirror{background:${bg};color:${text};} #write .MathJax{color:${text};}`:''}
   }`;
  }
  for(const m of [this.toolbar.annotations,this.toolbar.documentNotes,this.toolbar.manualMarks])m?._themeEditor();this.toolbar.researchSidebar?.applyTheme(c?this.mode(s):this.nativeMode);
  this.updateLauncher();this.refreshDialogColors?.();
 },updateLauncher(){if(this.launcher)this.launcher.title='随机切换配色 · 当前：'+this.palette().name;}};
  let mode;try{mode=localStorage.getItem('et-theme-native-mode-v1');}catch{}
  const css=getComputedStyle(document.documentElement),background=css.getPropertyValue('--bg-color').trim()||css.backgroundColor;
  let hex=/^#[\da-f]{6}$/i.test(background)?background:null;
  const rgba=background.match(/^rgba?\(([^)]+)\)/);if(rgba){const channels=rgba[1].split(',').map(Number);if(channels.length===3||channels[3]>0)hex='#'+channels.slice(0,3).map(v=>Math.round(v).toString(16).padStart(2,'0')).join('');}
  if(mode!=='dark'&&mode!=='light'&&hex)mode=palette.luminance(hex)<.19?'dark':'light';
  palette.nativeMode=mode==='dark'||mode==='light'?mode:matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';
  palette.state=palette.read();palette.style=document.getElementById('et-theme-palette-overrides')||document.createElement('style');palette.style.id='et-theme-palette-overrides';
  if(!palette.style.isConnected)document.head.append(palette.style);
  palette.apply();
  const spacing=(()=>{const module={exports:{}};// Display preferences only: never serialize layout into Markdown.
const key='et-paragraph-spacing-v1';
const fields={line:{min:1,max:3,step:.05},paragraph:{min:0,max:3,step:.1}};
function value(name,input){
 const limits=fields[name];if(!limits||input===null||input===''||typeof input==='boolean')return null;
 const n=Number(input);if(!Number.isFinite(n))return null;
 return Number((Math.round(Math.max(limits.min,Math.min(limits.max,n))/limits.step)*limits.step).toFixed(2));
}
function normalize(input){return {line:value('line',input?.line),paragraph:value('paragraph',input?.paragraph)};}
function read(raw){try{return normalize(JSON.parse(raw));}catch{return normalize(null);}}
function css(input){
 const state=normalize(input),exclude=':not(:where(table *,pre *,.md-fences *,.md-htmlblock *,.md-math-block *,.md-diagram-panel *))';
 const paragraphs='#write p'+exclude,lines=paragraphs+',#write li'+exclude;
 return '@media screen {'+(state.line===null?'':lines+'{line-height:'+state.line.toFixed(2)+'!important;}')+
  (state.paragraph===null?'':paragraphs+'{margin-block-start:0!important;margin-block-end:'+state.paragraph.toFixed(1)+'em!important;}')+'}';
}
module.exports={key,fields,value,normalize,read,css};
;return module.exports;})();
  const spacingStyle=document.createElement('style');spacingStyle.id='et-paragraph-spacing-style';spacingStyle.textContent=spacing.css(spacing.read(localStorage.getItem(spacing.key)));document.head.append(spacingStyle);
  performance.mark('et-theme-bootstrap-applied');
 }catch(error){console.warn('[EditingToolbar] Early theme unavailable:',error);}})();