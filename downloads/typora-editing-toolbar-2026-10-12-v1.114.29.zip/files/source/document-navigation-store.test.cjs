'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs/promises'),path=require('node:path'),vm=require('node:vm');
const Navigation=require('./document-navigation-store.cjs'),Library=require('./knowledge-library-store.cjs');
const scratch='C:/Users/xiaozhi/Downloads/codex-temp';
const empty=()=>({version:5,favorites:[],pinned:[],collectionSections:[],navigationLibraries:[],pinSort:'manual',pinCollapsed:false,favoritesCollapsed:false});
async function fixture(t){const dir=await fs.mkdtemp(path.join(scratch,'navigation-restore-'));t.after(()=>fs.rm(dir,{recursive:true,force:true}));const store=new Library(path.join(dir,'library'));await store.open();return {dir,store,nav:new Navigation(path.join(dir,'profile'))};}
async function tabs(profile,cache=new Map()){
 const context={reqnode:require,localStorage:{getItem:k=>cache.get(k)||null,setItem:(k,v)=>cache.set(k,v)},ETDocumentNavigation:Navigation,console};
 const Class=vm.runInNewContext(await fs.readFile(path.join(__dirname,'document-tabs.js'),'utf8')+';EditingToolbarDocumentTabs',context),tabs=Object.create(Class.prototype);
 Object.assign(tabs,{path,storageKey:'et-document-tabs-v1',navigationStorage:new Navigation(profile),tabs:[],render(){},notice(message){throw Error(message);}});
 tabs.preferences=tabs.readPreferences();tabs.favoritesData=tabs.preferences.favorites;return {tabs,cache};
}
test('upgrade cache migration survives missing or malformed browser storage, including empty removals',async t=>{
 const {dir,nav}=await fixture(t),value=empty();value.favorites=[{path:path.join(dir,'note.md'),sectionId:'reading'}];value.pinned=[{path:path.join(dir,'code.py')}];nav.save(value);
 assert.deepEqual(nav.read(null),value);assert.deepEqual(nav.read('{broken'),value);
 const removed=empty();nav.save(removed);assert.deepEqual(nav.read(null),removed);assert.deepEqual(nav.read(JSON.stringify(value)),value);
});
test('corrupt durable file falls back to last checksum-verified preferences',async t=>{
 const {dir,nav}=await fixture(t),value=empty();value.pinned=[{path:path.join(dir,'book.md')}];nav.save(value);nav.save({...value,pinCollapsed:true});await fs.writeFile(nav.file,'truncated');assert.deepEqual(nav.read(null),value);
});
test('portable references rebase inside a moved library, retain external paths, and reject traversal',async t=>{
 const {dir,store}=await fixture(t),value=empty();value.favorites=[{path:path.join(store.root,'storage','book','chapter.md')}];value.pinned=[{path:path.join(dir,'outside.md')}];
 const portable=Navigation.portable(value,store);assert.equal(portable.favorites[0].path,'storage/book/chapter.md');const moved=new Library(path.join(dir,'moved'));
 const restored=Navigation.restore(portable,moved);assert.equal(restored.favorites[0].path,path.join(moved.root,'storage','book','chapter.md'));assert.equal(restored.pinned[0].path,value.pinned[0].path);
 portable.pinned.push({path:'../escape.md',relative:true});assert.equal(Navigation.restore(portable,moved).pinned.length,1);
});
test('fresh profile restores pins, favorites, groups and all library items after moving the intact folder',async t=>{
 const {dir,store}=await fixture(t),a=await tabs(path.join(dir,'old-profile'));
 await fs.mkdir(path.join(store.root,'storage','book'),{recursive:true});await fs.writeFile(path.join(store.root,'storage','book','chapter.md'),'# chapter');
 const base=(await store.read()).data,next=structuredClone(base);next.collections=[{id:'books',name:'书籍'}];next.items=[{id:'book',type:'book',title:'测试书',status:'reading',star:true,files:[{id:'chapter',name:'chapter.md',path:'storage/book/chapter.md',relative:true}],tags:['保留'],related:[],collections:['books']}];const committed=await store.commit(base,next);
 a.tabs.change(db=>{db.favorites=[{path:path.join(store.root,'storage','book','chapter.md'),sectionId:'reading'}];db.pinned=[{path:path.join(store.root,'storage','book','chapter.md')}];db.collectionSections=[{id:'reading',name:'阅读',collection:'favorites',collapsed:false}];db.pinSort='updated_at';});await a.tabs.attachNavigation(store);
 const destination=path.join(dir,'copied-library');await fs.cp(store.root,destination,{recursive:true});const b=await tabs(path.join(dir,'fresh-profile')),moved=new Library(destination);await b.tabs.attachNavigation(moved);
 assert.equal(b.tabs.preferences.favorites[0].path,path.join(destination,'storage','book','chapter.md'));assert.equal(b.tabs.preferences.pinned.length,1);assert.equal(b.tabs.preferences.collectionSections[0].name,'阅读');assert.equal(b.tabs.preferences.pinSort,'updated_at');
 const reopened=await moved.open();assert.deepEqual(reopened.data.items,committed.items);assert.deepEqual(reopened.data.collections,committed.collections);assert.equal(await fs.readFile(moved.resolveFile(reopened.data.items[0].files[0]),'utf8'),'# chapter');
});
test('deliberate removal is not resurrected by reselect, restart or browser-cache loss',async t=>{
 const {dir,store}=await fixture(t),a=await tabs(path.join(dir,'profile'));a.tabs.change(db=>db.pinned.push({path:path.join(store.root,'note.md')}));await a.tabs.attachNavigation(store);
 a.tabs.change(db=>db.pinned=[]);await a.tabs.navigationPending;await a.tabs.attachNavigation(store);assert.equal(a.tabs.preferences.pinned.length,0);
 const b=await tabs(path.join(dir,'profile'));await b.tabs.attachNavigation(store);assert.equal(b.tabs.preferences.pinned.length,0);
 const c=await tabs(path.join(dir,'new-profile'));await c.tabs.attachNavigation(store);assert.equal(c.tabs.preferences.pinned.length,0);
});
test('navigation writes and stale item edits merge without losing either metadata or bookmarks',async t=>{
 const {store}=await fixture(t),base=(await store.read()).data,next=structuredClone(base);next.collections.push({id:'books',name:'书籍'});
 const value=empty();value.pinned=[{path:'storage/book.md',relative:true}];await store.updateDocumentNavigation(()=>value,base.libraryId);await store.commit(base,next);
 const data=(await store.read()).data;assert.equal(data.collections.length,1);assert.deepEqual(data.documentNavigation,value);
 await assert.rejects(store.updateDocumentNavigation(()=>empty(),'wrong-library'),/替换/);assert.deepEqual((await store.read()).data.documentNavigation,value);
});
test('opening recovers previous index and refuses to create an empty index over orphaned storage',async t=>{
 const {dir,store}=await fixture(t),base=(await store.read()).data;await store.updateDocumentNavigation(()=>empty(),base.libraryId);await fs.unlink(store.file);assert.equal((await store.open()).data.libraryId,base.libraryId);
 const orphan=new Library(path.join(dir,'orphan'));await fs.mkdir(path.join(orphan.root,'storage','book'),{recursive:true});await fs.writeFile(path.join(orphan.root,'storage','book','chapter.md'),'kept');await assert.rejects(orphan.open(),/未创建空库/);await assert.rejects(fs.stat(orphan.file),{code:'ENOENT'});assert.equal(await fs.readFile(path.join(orphan.root,'storage','book','chapter.md'),'utf8'),'kept');
});
test('an upgrade with existing favorites merges a selected library once and preserves unrelated paths',async t=>{
 const {dir,store}=await fixture(t),portable=empty();portable.pinned=[{path:'storage/book.md',relative:true}];await store.updateDocumentNavigation(()=>portable,(await store.read()).data.libraryId);
 const a=await tabs(path.join(dir,'profile'));a.tabs.change(db=>db.favorites.push({path:path.join(dir,'external.md')}));await a.tabs.attachNavigation(store);assert.equal(a.tabs.preferences.favorites.length,1);assert.equal(a.tabs.preferences.pinned.length,1);
 await a.tabs.attachNavigation(store);assert.equal(a.tabs.preferences.pinned.length,1);
});

test('same profile reselecting its moved library rebases bookmarks without reviving removed ones',async t=>{
 const {dir,store}=await fixture(t),a=await tabs(path.join(dir,'profile'));a.tabs.change(db=>{db.pinned.push({path:path.join(store.root,'storage','book.md')});db.favorites.push({path:path.join(dir,'outside.md')});});await a.tabs.attachNavigation(store);
 const target=path.join(dir,'relocated');await fs.cp(store.root,target,{recursive:true});await a.tabs.attachNavigation(new Library(target));assert.equal(a.tabs.preferences.pinned[0].path,path.join(target,'storage','book.md'));assert.equal(a.tabs.preferences.favorites[0].path,path.join(dir,'outside.md'));
 a.tabs.change(db=>db.pinned=[]);await a.tabs.navigationPending;await a.tabs.attachNavigation(new Library(target));assert.equal(a.tabs.preferences.pinned.length,0);
});

test('browser storage write failure still uses the newly saved durable preferences',async t=>{
 const {dir}=await fixture(t),a=await tabs(path.join(dir,'profile'));a.tabs.change(db=>db.favorites.push({path:path.join(dir,'first.md')}));a.cache.set=()=>{throw Error('QuotaExceeded');};a.tabs.change(db=>db.pinned.push({path:path.join(dir,'second.md')}));assert.equal(a.tabs.readPreferences().pinned.length,1);assert.equal(a.tabs.readPreferences().favorites.length,1);
});
