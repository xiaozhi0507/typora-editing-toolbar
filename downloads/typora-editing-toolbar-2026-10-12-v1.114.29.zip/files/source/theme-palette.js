// Theme colors are a reversible display layer; never write document or theme files.
class EditingToolbarThemePalette {
 static presets={
   ...ET_CODEX_THEME_PRESETS,
   default:{name:'原主题'},
   ranunculus:{name:'洋牡丹',light:['#f7f1e8','#f7f1e8','#f2e4d4','#6d5849','#6d5849','#ddcab5'],dark:['#39342d','#39342d','#2e2824','#e5d4c1','#e5d4c1','#6b5948']},
   hydrangea:{name:'绣球',light:['#dce3e4','#dce3e4','#ccd6d9','#152d7a','#152d7a','#bdcadf'],dark:['#2f383e','#2f383e','#293137','#5284be','#5284be','#465d78']},
   freesia:{name:'香雪兰',light:['#e8efe3','#e8efe3','#d2ddc4','#238349','#238349','#b9d4b7'],dark:['#3f443c','#3f443c','#2b2f29','#70be88','#70be88','#45674b']},
   campanula:{name:'风铃',light:['#fcf9f4','#fcf8f4','#f7e4e9','#238349','#238349','#e7cbd4'],dark:['#303631','#303631','#1f221d','#70be88','#70be88','#4b6552']},
   rose:{name:'玫瑰',light:['#fff5f5','#fff5f5','#df7a93','#8b2317','#df7a93','#efbdcb'],dark:['#4b2e34','#4b2e34','#8b2317','#f0b8c0','#f0b8c0','#794552']}
  };
 constructor(toolbar){
  this.toolbar=toolbar;this.key='et-theme-palette-v1';this.presets=EditingToolbarThemePalette.presets;this.fields=['主背景','侧栏背景','卡片与工具栏','加粗文字','注释高亮','文字选区'];this.state=this.read();this.style=document.getElementById('et-theme-palette-overrides')||document.createElement('style');this.style.id='et-theme-palette-overrides';if(!this.style.isConnected)document.head.append(this.style);this.nativeMode=this.detectMode();this.apply();performance.mark('et-theme-palette-ready');this.addLauncher();
  const refresh=()=>{clearTimeout(this.themeTimer);this.themeTimer=setTimeout(()=>{this.nativeMode=this.detectMode();this.apply();if(this.dialog)this.render();},60);};
  document.addEventListener('load',e=>{if(e.target instanceof HTMLLinkElement&&e.target.rel==='stylesheet')refresh();},true);
  this.themeObserver=new MutationObserver(records=>{if(records.some(r=>r.target instanceof HTMLLinkElement||[...r.addedNodes,...r.removedNodes].some(n=>n.nodeName==='LINK')))refresh();});this.themeObserver.observe(document.head,{childList:true,subtree:true,attributes:true,attributeFilter:['href']});
  window.addEventListener('storage',e=>{if(e.key!==this.key)return;this.close(false);this.state=this.read();this.apply();});
  window.addEventListener('resize',()=>this.closeColorPicker());
 }
 validHex(value){return typeof value==='string'&&/^#[\da-f]{6}$/i.test(value);}
 normalizeProfile(value){if(!value||!['surface','ink','accent'].every(k=>this.validHex(value[k])))return null;const out={};for(const k of ['surface','ink','accent','bold','annotation','selection','side','card'])if(this.validHex(value[k]))out[k]=value[k].toLowerCase();out.contrast=Number.isFinite(value.contrast)?Math.max(0,Math.min(100,Math.round(value.contrast))):60;return out;}
 normalize(input){
  const s={version:7,preset:'default',mode:['light','dark'].includes(input?.mode)?input.mode:'auto',scope:input?.scope==='plugin'?'plugin':'app',separate:input?.separate===true,saved:[]},ids=new Set(),names=new Set();
  const valid=v=>Array.isArray(v)&&[4,5,6].includes(v.length)&&v.every(c=>this.validHex(c));
  const expand=v=>[...v.slice(0,4),v[4]||v[3],v[5]||this.mix(v[3],v[0],.72)].map(c=>c.toLowerCase());
  for(const item of (Array.isArray(input?.saved)?input.saved:[]).slice(0,200)){
   const name=this.cleanName(item?.name);if(!/^user-[a-z\d-]{1,80}$/i.test(item?.id)||!name||ids.has(item.id)||names.has(name.toLowerCase()))continue;
   let saved;if(valid(item.light)&&valid(item.dark))saved={id:item.id,name,light:expand(item.light),dark:expand(item.dark)};
   else{const variants={};for(const mode of ['light','dark']){const p=this.normalizeProfile(item?.variants?.[mode]);if(p)variants[mode]=p;}if(!Object.keys(variants).length)continue;saved={id:item.id,name,variants};}
   s.saved.push(saved);ids.add(item.id);names.add(name.toLowerCase());
  }
  let catalog=this.catalog(s);if(Object.hasOwn(catalog,input?.preset))s.preset=input.preset;
  // Older releases stored edits against built-ins. Migrate them without changing originals.
  if(![3,4,5,6,7].includes(input?.version))for(const [id,p]of Object.entries(catalog)){
   if(!p.light||!p.dark)continue;const converted={};let changed=false;
   for(const mode of ['light','dark']){const v=input?.custom?.[id]?.[mode];converted[mode]=p[mode].map((c,i)=>this.validHex(v?.[i])?v[i].toLowerCase():c);if(v?.length===4)converted[mode][4]=converted[mode][3];if(v?.length&&v.length<6)converted[mode][5]=this.mix(converted[mode][3],converted[mode][0],.72);if(JSON.stringify(converted[mode])!==JSON.stringify(p[mode]))changed=true;}
   if(!changed)continue;if(p.id)Object.assign(p,converted);else{let name=p.name+' · 自定义',n=2;while(names.has(name.toLowerCase()))name=p.name+' · 自定义 '+n++;let newId='user-legacy-'+id;while(ids.has(newId))newId+='-x';s.saved.push({id:newId,name,...converted});names.add(name.toLowerCase());ids.add(newId);if(s.preset===id)s.preset=newId;}
  }
  catalog=this.catalog(s);
  for(const mode of ['light','dark']){const entry=[6,7].includes(input?.version)?input?.[mode]:null;let id=entry?.preset||s.preset;if(!Object.hasOwn(catalog,id)||!this.supports(catalog[id],mode))id='chatgpt';const overrides={};for(const k of ['surface','ink','accent','side','card','bold','annotation','selection'])if(this.validHex(entry?.overrides?.[k]))overrides[k]=entry.overrides[k].toLowerCase();if(Number.isFinite(entry?.overrides?.contrast))overrides.contrast=Math.max(0,Math.min(100,Math.round(entry.overrides.contrast)));s[mode]={preset:id,overrides};}
  // Preserve v6's derived surfaces/selection once, then keep every v7 color independent.
  if(input?.version===6)for(const mode of ['light','dark']){const o=s[mode].overrides,p=this.profile(s,mode);if(!p)continue;if(o.surface){const dark=this.luminance(p.surface)<.19;o.side=this.mix(p.surface,p.ink,dark?.025:.016);o.card=this.mix(p.surface,p.ink,dark?.05:.012);}if(o.accent)o.selection=this.mix(p.surface,p.accent,.25);}
  return s;
 }
 supports(p,mode){return !!p&&(p===this.presets.default||!!p[mode]||!!p.variants?.[mode]);}
 selectedId(state=this.draft||this.state,mode=this.mode(state)){return state?.[mode]?.preset||state?.preset||'default';}
 palette(state=this.draft||this.state,mode=this.mode(state)){return this.catalog(state)[this.selectedId(state,mode)]||this.presets.default;}
 profile(state=this.draft||this.state,mode=this.mode(state)){
  const p=this.palette(state,mode);let raw=p.variants?.[mode];
  if(!raw&&p[mode]){const c=p[mode],ink=this.textFor(c[0]),accent=this.contrast(c[3],c[0])>=4.5?c[3]:this.mix(c[3],ink,.5);raw={surface:c[0],side:c[1],card:c[2],ink,accent,bold:c[3],annotation:c[4],selection:c[5],contrast:mode==='dark'?60:45};}
  const overrides=state?.[mode]?.overrides||{};
  if(!raw&&!Object.keys(overrides).length)return null;
  const base=raw||this.presets.chatgpt.variants[mode],out={...base,...overrides};
  // Explicit component colors are independent of the three base colors.
  return out;
 }
 tokens(state=this.draft||this.state,mode=this.mode(state)){
  const p=this.profile(state,mode);if(!p)return null;
  const bg=p.surface,text=p.ink,accent=p.accent,contrast=p.contrast??60,dark=this.luminance(bg)<.19;
  const side=p.side||this.mix(bg,text,dark?.025:.016),card=p.card||this.mix(bg,text,dark?.05:.012),bold=p.bold||text;
  const border=this.mix(bg,text,.08+contrast*.002),muted=this.mix(text,bg,.48-contrast*.0015),hover=this.mix(card,accent,.09),active=this.mix(card,accent,.17),selection=p.selection||this.mix(bg,accent,.25);
  return{bg,side,card,text,sideText:text,cardText:text,bold,accent,link:accent,border,muted,hover,active,selection,selectionText:this.textFor(selection),annotation:p.annotation||accent,contrast};
 }
 colors(state=this.draft||this.state){const t=this.tokens(state);return t?[t.bg,t.side,t.card,t.bold,t.annotation,t.selection]:undefined;}
 selectionState(id,state=this.state,mode=this.mode(state)){
  const next=this.clone(state),p=this.catalog(next)[id];if(!this.supports(p,mode))return next;
  next[mode]={preset:id,overrides:{}};next.preset=id;
  if(!next.separate){const other=mode==='light'?'dark':'light';if(this.supports(p,other))next[other]={preset:id,overrides:{}};}
  return next;
 }
 randomize(){if(this.dialog)return;const mode=this.mode(this.state),choices=Object.entries(this.catalog(this.state)).filter(([id,p])=>id!=='default'&&id!==this.selectedId(this.state)&&this.supports(p,mode)).map(([id])=>id);if(!choices.length)return;const next=this.normalize(this.selectionState(choices[Math.floor(Math.random()*choices.length)]));try{localStorage.setItem(this.key,JSON.stringify(next));}catch(e){this.toolbar._showToolbarNotice('配色未能保存：'+e.message);return;}this.state=next;this.apply();this.toolbar._showToolbarNotice('配色：'+this.palette().name);}
 choose(id,mode=this.mode()){
  const next=this.selectionState(id,this.draft,mode);
  for(const variant of ['light','dark'])if(variant===mode||(!next.separate&&next[variant].preset===id)){
   delete this.colorEdits[variant];for(const key of Object.keys(this.invalidColors||{}))if(key.startsWith(variant+':'))delete this.invalidColors[key];
  }
  if(!Object.keys(this.colorEdits).length)this.pendingName='';this.edit=null;this.closeMenu();this.draft=next;this.apply();this.render();
 }
 uniqueName(base){const names=new Set(Object.values(this.catalog()).map(p=>p.name.toLowerCase()));let name=this.cleanName(base)||'我的配色',n=2;while(names.has(name.toLowerCase()))name=this.cleanName(base).slice(0,26)+' '+n++;return name;}
 beginEdit(id=this.selectedId(),copy=false,mode=this.mode()){
  const p=this.catalog()[id];this.edit={id:!copy&&p?.id?p.id:null,name:!copy&&p?.id?p.name:this.uniqueName((p?.name||'我的配色')+' · 副本'),mode};this.render();this.dialog.querySelector('[data-scheme-name]')?.focus();
 }
 saveScheme(){
  if(!this.edit)return true;const name=this.cleanName(this.edit.name),id=this.edit.id||'user-'+crypto.randomUUID();
  if(!name||Object.entries(this.catalog()).some(([key,p])=>key!==id&&p.name.toLowerCase()===name.toLowerCase())){this.message('请使用一个不重复的方案名称。',true);return false;}
  if(!this.edit.id&&this.draft.saved.length>=200){this.message('已达到方案数量上限，请先删除不需要的方案。',true);return false;}
  const old=this.draft.saved.find(p=>p.id===id);let saved;
  if(old){saved={...old,name};}
  else{const variants={};for(const mode of ['light','dark']){const profile=this.resolvedProfile(this.draft,mode);if(profile)variants[mode]=this.normalizeProfile(profile);}if(!Object.keys(variants).length)variants[this.edit.mode]=this.normalizeProfile(this.presets.chatgpt.variants[this.edit.mode]);saved={id,name,variants};}
  this.draft.saved=old?this.draft.saved.map(p=>p.id===id?saved:p):[...this.draft.saved,saved];
  if(!old){for(const mode of ['light','dark'])if(saved.variants?.[mode])this.draft[mode]={preset:id,overrides:{}};this.draft.preset=id;}this.edit=null;return true;
 }
 commit(){const invalidKey=Object.keys(this.invalidColors||{})[0];if(invalidKey){this.draft.mode=invalidKey.split(':')[0];this.apply();this.render();this.message('请输入完整的六位颜色值，例如 #2D2D2B。',true);this.dialog.querySelector('[data-color="'+invalidKey+'"]')?.focus();return false;}const invalid=this.dialog.querySelector('[data-color][aria-invalid=true]');if(invalid){this.message('请输入完整的六位颜色值，例如 #2D2D2B。',true);invalid.focus();return false;}if(!this.savePendingScheme()||!this.saveScheme())return false;return this.close(true,this.draft);}
 removeScheme(id){if(!this.draft.saved.some(p=>p.id===id))return;this.closeMenu();this.draft.saved=this.draft.saved.filter(p=>p.id!==id);for(const mode of ['light','dark'])if(this.draft[mode].preset===id)this.draft[mode]={preset:'default',overrides:{}};if(this.draft.preset===id)this.draft.preset='default';this.edit=null;this.apply();this.render();this.message('方案已移除；应用后保存，取消可恢复。');}
 importTheme(value){
  if(typeof value!=='string'||value.length>65536)throw Error('主题内容过长或格式不正确。');let text=value.trim();if(!text.startsWith('codex-theme-v1:'))throw Error('请粘贴以 codex-theme-v1: 开头的主题。');text=text.slice(15);let data;try{data=JSON.parse(text);}catch{try{data=JSON.parse(decodeURIComponent(text));}catch{throw Error('主题 JSON 无法解析，请完整复制后重试。');}}
  if(!data||!['light','dark'].includes(data.variant)||typeof data.codeThemeId!=='string'||data.codeThemeId.length>100)throw Error('主题缺少有效的模式或名称。');
  const theme=data.theme;if(!theme||!['surface','ink','accent'].every(k=>this.validHex(theme[k]))||!Number.isInteger(theme.contrast)||theme.contrast<0||theme.contrast>100)throw Error('背景、前景、强调色必须是六位颜色值，对比度须为 0–100 的整数。');
  if(this.draft.saved.length>=200)throw Error('已达到方案数量上限，请先删除不需要的方案。');
  // Fonts and other application-specific properties are deliberately not applied or persisted.
  const mode=data.variant,id='user-'+crypto.randomUUID(),base=(data.codeThemeId==='codex'?'ChatGPT':this.presets[data.codeThemeId]?.name)||this.cleanName(data.codeThemeId)||'Codex';
  const profile=this.normalizeProfile({surface:theme.surface,ink:theme.ink,accent:theme.accent,contrast:theme.contrast});
  delete this.colorEdits[mode];if(!Object.keys(this.colorEdits).length)this.pendingName='';this.edit=null;this.draft.saved.push({id,name:this.uniqueName(base+' · 导入'),variants:{[mode]:profile}});this.draft[mode]={preset:id,overrides:{}};this.draft.preset=id;this.draft.mode=mode;
  for(const key of Object.keys(this.invalidColors||{}))if(key.startsWith(mode+':'))delete this.invalidColors[key];this.importOpen=false;this.importText='';this.apply();this.render();this.message('已导入'+(mode==='dark'?'深色':'浅色')+'配色；点击“应用配色”保存。字体设置已忽略。');
 }
 exportTheme(mode=this.mode()){
  const id=this.selectedId(this.draft,mode),p=this.profile(this.draft,mode)||this.presets.chatgpt.variants[mode];
  return 'codex-theme-v1:'+JSON.stringify({codeThemeId:this.presets[id]?.group==='codex'?id:'codex',variant:mode,theme:{surface:p.surface,ink:p.ink,accent:p.accent,accentSource:'custom',contrast:p.contrast,fonts:{ui:null,code:null},opaqueWindows:true,semanticColors:{diffAdded:'#40c977',diffRemoved:'#fa423e',skill:p.accent}}});
 }

 nativeProfile(mode){const parse=(v,fallback)=>{if(this.validHex(v))return v;const m=String(v).match(/^rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)/);return m?'#'+m.slice(1,4).map(n=>Math.max(0,Math.min(255,Number(n))).toString(16).padStart(2,'0')).join(''):fallback;};const css=getComputedStyle(document.body),root=getComputedStyle(document.documentElement),base=this.presets.chatgpt.variants[mode];return{...base,surface:parse(css.backgroundColor,base.surface),ink:parse(css.color,base.ink),accent:parse(root.getPropertyValue('--et-accent').trim(),mode==='dark'?'#bd9ce8':'#8060aa')};}
 escape(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
 appearanceIcon(name){if(name==='more')return '<svg viewBox="0 0 24 24" width="17" height="17" fill="currentColor" aria-hidden="true"><circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/></svg>';const paths={import:'M12 3v12m-4-4 4 4 4-4M5 15v5h14v-5',copy:'M9 8V4h11v12h-4M4 8h12v12H4z',chevron:'m8 10 4 4 4-4',more:'M5 12h.01M12 12h.01M19 12h.01'};return '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="'+paths[name]+'"/></svg>';}
 refreshDialogColors(){if(!this.dialog)return;const t=this.tokens();this.dialog.dataset.mode=this.mode();const values=t?{bg:t.bg,card:t.card,text:t.text,muted:t.muted,border:t.border,accent:t.accent,soft:t.hover,'on-accent':this.textFor(t.accent)}:{};for(const key of ['bg','card','text','muted','border','accent','soft','on-accent'])if(values[key])this.dialog.style.setProperty('--tp-'+key,values[key]);else this.dialog.style.removeProperty('--tp-'+key);}
 resolvedProfile(state=this.draft||this.state,mode=this.mode(state)){
  const p=this.profile(state,mode)||this.nativeProfiles?.[mode]||this.nativeProfile(mode);
  const dark=this.luminance(p.surface)<.19;
  return{surface:p.surface,ink:p.ink,accent:p.accent,side:p.side||this.mix(p.surface,p.ink,dark?.025:.016),card:p.card||this.mix(p.surface,p.ink,dark?.05:.012),bold:p.bold||p.ink,annotation:p.annotation||p.accent,selection:p.selection||this.mix(p.surface,p.accent,.25),contrast:p.contrast};
 }
 updatePendingUI(){
  if(!this.dialog)return;const pending=Object.keys(this.colorEdits||{}).length>0,box=this.dialog.querySelector('[data-pending-save]');
  if(box){box.hidden=!pending;const input=box.querySelector('input');if(document.activeElement!==input)input.value=this.pendingName||'';}
  for(const button of this.dialog.querySelectorAll('[data-theme-menu]')){const variant=button.dataset.themeMenu;button.querySelector('span:nth-child(2)').textContent=this.colorEdits?.[variant]?'新方案 · 未保存':this.palette(this.draft,variant).name;}
  this.dialog.querySelector('[data-action=apply]').textContent=pending?'保存并应用':'应用配色';
 }
 updateColor(mode,key,value){
  const before=this.resolvedProfile(this.draft,mode),next=key==='contrast'?Math.max(0,Math.min(100,Math.round(Number(value)))):value.toLowerCase();
  if(before[key]===next)return;
  this.colorEdits??={};if(!this.colorEdits[mode])this.colorEdits[mode]={entry:this.clone(this.draft[mode]),profile:before};
  if(!this.pendingName)this.pendingName=this.uniqueName(this.palette(this.draft,mode).name+' · 自定义');
  this.edit=null;const editor=this.dialog?.querySelector('.et-appearance-save');if(editor)editor.hidden=true;
  this.draft[mode].overrides={...before,[key]:next};
  if(JSON.stringify(this.resolvedProfile(this.draft,mode))===JSON.stringify(this.colorEdits[mode].profile)){
   this.draft[mode]=this.clone(this.colorEdits[mode].entry);delete this.colorEdits[mode];if(!Object.keys(this.colorEdits).length)this.pendingName='';
  }
  this.updatePendingUI();
  if(!this.colorRaf)this.colorRaf=requestAnimationFrame(()=>{this.colorRaf=0;this.apply();});
 }
 savePendingScheme(){
  if(!Object.keys(this.colorEdits||{}).length)return true;
  const name=this.cleanName(this.pendingName),input=this.dialog.querySelector('[data-pending-name]');
  if(!name||Object.values(this.catalog()).some(p=>p.name.toLowerCase()===name.toLowerCase())){this.message('请为新方案填写一个不重复的名称。',true);input?.setAttribute('aria-invalid','true');input?.focus();return false;}
  if(this.draft.saved.length>=200){this.message('已达到方案数量上限，请先删除不需要的方案。',true);return false;}
  const id='user-'+crypto.randomUUID(),variants={};for(const mode of ['light','dark'])variants[mode]=this.normalizeProfile(this.resolvedProfile(this.draft,mode));
  this.draft.saved.push({id,name,variants});for(const mode of ['light','dark'])this.draft[mode]={preset:id,overrides:{}};
  this.draft.preset=id;this.colorEdits={};this.pendingName='';this.edit=null;return true;
 }
 closeMenu(focus=false){const anchor=this.menuAnchor;this.menu?.remove();this.menu=null;this.menuAnchor=null;anchor?.setAttribute('aria-expanded','false');if(focus&&anchor?.isConnected)anchor.focus({preventScroll:true});}
 positionMenu(menu,anchor){const r=anchor.getBoundingClientRect();this.menuRect={top:r.top,left:r.left};menu.style.maxHeight=Math.max(100,Math.min(360,innerHeight-32))+'px';const h=menu.getBoundingClientRect().height;menu.style.left=Math.max(12,Math.min(innerWidth-menu.offsetWidth-12,r.right-menu.offsetWidth))+'px';menu.style.top=Math.max(12,Math.min(innerHeight-h-12,r.bottom+6))+'px';}
 makeMenu(anchor,label){this.closeColorPicker();this.closeMenu();const menu=document.createElement('div');menu.className='et-theme-menu et-appearance-menu';menu.setAttribute('role','menu');menu.setAttribute('aria-label',label);this.menu=menu;this.menuAnchor=anchor;anchor.setAttribute('aria-expanded','true');this.dialog.append(menu);menu.onkeydown=e=>{
  const items=[...menu.querySelectorAll('button:not(:disabled)')].filter(b=>!b.hidden),i=items.indexOf(document.activeElement);
  if(e.target instanceof HTMLInputElement){if(e.key==='ArrowDown'&&items.length){e.preventDefault();items[0].focus();}return;}
  if(items.length&&['ArrowDown','ArrowUp','Home','End'].includes(e.key)){e.preventDefault();e.stopPropagation();items[e.key==='Home'?0:e.key==='End'?items.length-1:(i+(e.key==='ArrowDown'?1:-1)+items.length)%items.length]?.focus();}
  if(e.key==='Tab'){e.preventDefault();e.stopPropagation();this.closeMenu(true);}
 };return menu;}
 showThemeMenu(anchor,mode){
  const menu=this.makeMenu(anchor,'选择'+(mode==='light'?'浅色':'深色')+'主题'),catalog=this.catalog(),selected=this.selectedId(this.draft,mode);
  menu.classList.add('et-appearance-theme-menu');menu.setAttribute('role','dialog');
  const search=document.createElement('input');search.type='search';search.placeholder='搜索主题';search.setAttribute('aria-label','搜索主题');search.className='et-theme-search';menu.append(search);
  const list=document.createElement('div');list.className='et-theme-results';list.setAttribute('role','menu');menu.append(list);
  const groups=[['',['chatgpt']],['Codex 主题',Object.keys(this.presets).filter(id=>this.presets[id].group==='codex')],['其它配色',Object.keys(this.presets).filter(id=>!this.presets[id].group)],['我的方案',this.draft.saved.map(p=>p.id)]],sections=[];
  for(const [title,ids]of groups){const eligible=ids.filter(id=>this.supports(catalog[id],mode));if(!eligible.length)continue;const buttons=[];let heading;
   if(title){heading=document.createElement('div');heading.className='et-appearance-menu-label';heading.textContent=title;list.append(heading);}
   for(const id of eligible){const p=catalog[id],b=document.createElement('button');b.type='button';b.dataset.preset=id;b.setAttribute('role','menuitemradio');b.setAttribute('aria-checked',String(selected===id));const profile=p.variants?.[mode],c=p[mode];b.innerHTML='<span class="et-appearance-aa" aria-hidden="true">Aa</span><span>'+this.escape(p.name)+'</span><span class="et-appearance-check">'+(selected===id?'✓':'')+'</span>';const aa=b.firstElementChild;aa.style.backgroundColor=profile?.surface||c?.[0]||(mode==='dark'?'#202027':'#fff');aa.style.color=profile?.accent||c?.[3]||(mode==='dark'?'#bd9ce8':'#8060aa');b.onclick=()=>{this.choose(id,mode);this.dialog.querySelector('[data-theme-menu="'+mode+'"]')?.focus({preventScroll:true});};list.append(b);buttons.push(b);}
   sections.push({heading,buttons});
  }
  const empty=document.createElement('p');empty.className='et-theme-search-empty';empty.textContent='没有匹配的主题';empty.hidden=true;empty.setAttribute('role','status');list.append(empty);
  search.oninput=()=>{const term=search.value.trim().toLowerCase();let count=0;for(const section of sections){for(const b of section.buttons){b.hidden=!catalog[b.dataset.preset].name.toLowerCase().includes(term);if(!b.hidden)count++;}if(section.heading)section.heading.hidden=section.buttons.every(b=>b.hidden);}empty.hidden=count>0;list.scrollTop=0;this.positionMenu(menu,anchor);};
  this.positionMenu(menu,anchor);search.focus({preventScroll:true});
 }
 showMenu(id,event){
  const anchor=event.target.closest('button'),mode=anchor?.dataset.schemeMenu||this.mode(),p=this.catalog()[id];if(!anchor||!p)return;
  const menu=this.makeMenu(anchor,'配色方案操作');menu.classList.add('et-appearance-action-menu');
  const action=(label,key,run)=>{const b=document.createElement('button');b.type='button';b.textContent=label;b.dataset.menuAction=key;b.setAttribute('role','menuitem');b.onclick=()=>{this.closeMenu();run();};menu.append(b);};
  if(Object.keys(this.colorEdits||{}).length)action('命名新方案','name',()=>this.dialog.querySelector('[data-pending-name]')?.focus());
  else{action('保存为我的方案','duplicate',()=>this.beginEdit(id,true,mode));if(p.id){action('重命名方案','rename',()=>this.beginEdit(id,false,mode));action('删除方案','delete',()=>this.removeScheme(id));}}
  action('恢复此主题默认颜色','reset',()=>{this.draft[mode].overrides={};delete this.colorEdits[mode];if(!Object.keys(this.colorEdits).length)this.pendingName='';for(const key of Object.keys(this.invalidColors||{}))if(key.startsWith(mode+':'))delete this.invalidColors[key];this.apply();this.render();});
  this.positionMenu(menu,anchor);menu.querySelector('button')?.focus();
 }
 render(){
  if(!this.dialog)return;const scroll=this.dialog.querySelector('.et-theme-body')?.scrollTop||0;this.closeColorPicker();this.closeMenu();const s=this.draft,mode=this.mode();
  const modeButton=(id,name)=>'<button type="button" data-mode-choice="'+id+'" aria-label="'+name+'" aria-pressed="'+(s.mode===id)+'"><span class="et-mode-preview et-mode-'+id+'" aria-hidden="true"><i class="et-mode-pane et-mode-light"><b></b><em></em><em></em><em></em><small></small></i><i class="et-mode-pane et-mode-dark"><b></b><em></em><em></em><em></em><small></small></i></span><span>'+name+'</span></button>';
  const colorRow=(variant,key,label,p)=>'<div class="et-appearance-row"><span>'+label+'</span><div class="et-appearance-value">'+(key==='accent'?'<select data-accent="'+variant+'" aria-label="'+variant+'强调色预设"><option value="">自定义</option><option value="default">主题默认</option><option value="#3a83f7">蓝色</option><option value="#18a78c">绿色</option><option value="#efb93f">黄色</option><option value="#ed6da8">粉色</option><option value="#df7d53">橙色</option><option value="#a16de2">紫色</option></select>':'')+'<label class="et-color-pill"><button type="button" data-color-picker="'+variant+':'+key+'" aria-label="'+(variant==='dark'?'深色':'浅色')+label+'颜色" aria-haspopup="dialog" aria-expanded="false" style="--well-color:'+p[key]+'"><i></i></button><input data-color="'+variant+':'+key+'" aria-label="'+(variant==='dark'?'深色':'浅色')+label+'十六进制" value="'+p[key].toUpperCase()+'" maxlength="7" spellcheck="false"></label></div></div>';
  const card=variant=>{const p=this.resolvedProfile(s,variant),preset=this.palette(s,variant),title=s.separate?(variant==='dark'?'深色主题':'浅色主题'):'主题';return '<section class="et-appearance-card" data-theme-card="'+variant+'"><div class="et-appearance-row et-appearance-theme-row"><span>'+title+'</span><div class="et-appearance-value"><button type="button" class="et-appearance-icon-button" data-import="'+variant+'" title="粘贴 Codex 主题" aria-label="粘贴 Codex 主题">'+this.appearanceIcon('import')+'</button><button type="button" class="et-appearance-icon-button" data-copy="'+variant+'" title="复制主题" aria-label="复制'+title+'">'+this.appearanceIcon('copy')+'</button><button type="button" class="et-theme-select" data-theme-menu="'+variant+'" aria-haspopup="menu" aria-expanded="false"><span class="et-appearance-aa" aria-hidden="true" style="background:'+p.surface+';color:'+p.accent+'">Aa</span><span>'+this.escape(preset.name)+'</span>'+this.appearanceIcon('chevron')+'</button><button type="button" class="et-appearance-icon-button" data-scheme-menu="'+variant+'" aria-label="'+title+'方案操作">'+this.appearanceIcon('more')+'</button></div></div>'+((!s.separate||variant==='light')?'<div class="et-appearance-pending" data-pending-save hidden><label>方案名称<input data-pending-name maxlength="32" aria-label="新方案名称"></label><small>修改后保存为独立方案，保留原配色。</small></div>':'')+[['accent','强调色'],['surface','主背景'],['ink','普通文字'],['side','侧栏背景'],['card','卡片与工具栏'],['bold','加粗文字'],['annotation','注释高亮'],['selection','文字选区']].map(([key,label])=>colorRow(variant,key,label,p)).join('')+'<div class="et-appearance-row"><label for="et-contrast-'+variant+'">对比度</label><div class="et-appearance-value et-contrast"><input id="et-contrast-'+variant+'" type="range" data-contrast="'+variant+'" min="0" max="100" value="'+p.contrast+'"><output>'+p.contrast+'</output></div></div></section>';};
  this.dialog.innerHTML='<header class="et-preferences-header" data-preferences-move><div><h2 id="et-theme-title">外观</h2><p>主题配色</p></div><button type="button" class="et-preferences-close" data-action="cancel" aria-label="取消预览并关闭">×</button></header><div class="et-theme-body et-appearance-body"><div class="et-appearance-section-title"><h3>视觉风格</h3><label>范围 <select data-option="scope" aria-label="配色范围"><option value="app">正文、侧栏和插件</option><option value="plugin">仅插件面板</option></select></label></div><section class="et-appearance-card et-appearance-mode"><span>模式</span><div role="group" aria-label="配色明暗">'+modeButton('auto','跟随主题')+modeButton('light','浅色')+modeButton('dark','深色')+'</div></section>'+ (s.separate?card('light')+card('dark'):card(mode))+'<section class="et-appearance-import" '+(this.importOpen?'':'hidden')+'><div class="et-theme-section-head"><h3>粘贴 Codex 主题</h3><button type="button" data-import-close aria-label="关闭主题导入">×</button></div><textarea data-import-text aria-label="Codex 主题内容" rows="4" placeholder="codex-theme-v1:{…}" spellcheck="false"></textarea><div><span>导入颜色与对比度，保留当前字体。</span><button type="button" data-import-confirm>导入并预览</button></div></section><section class="et-appearance-save" '+(this.edit?'':'hidden')+'><label>方案名称<input data-scheme-name maxlength="32" aria-label="方案名称"></label><button type="button" data-save-scheme>保存到我的方案</button><button type="button" data-save-cancel>取消</button></section><div class="et-appearance-advanced-heading"><button type="button" data-advanced aria-expanded="'+!!this.advancedOpen+'">高级 <span>'+ (this.advancedOpen?'⌃':'⌄')+'</span></button><button type="button" data-reset>重置为默认设置</button></div><section class="et-appearance-card" '+(this.advancedOpen?'':'hidden')+'><div class="et-appearance-row et-appearance-split"><label for="et-separate-mode">分别设置浅色和深色模式<small>分别选择各自的主题和颜色</small></label><button type="button" id="et-separate-mode" role="switch" aria-checked="'+s.separate+'" aria-label="分别设置浅色和深色模式"><i></i></button></div></section></div><footer><p class="et-theme-warning" role="status" aria-live="polite" hidden></p><span class="et-theme-preview-label">预览中</span><button type="button" data-action="cancel">取消</button><button type="button" class="et-theme-apply" data-action="apply">应用配色</button></footer>';
  this.refreshDialogColors();const q=selector=>this.dialog.querySelector(selector),all=selector=>[...this.dialog.querySelectorAll(selector)];
  q('[data-option=scope]').value=s.scope;q('[data-option=scope]').onchange=e=>{s.scope=e.target.value;this.apply();};
  for(const b of all('[data-mode-choice]'))b.onclick=()=>{s.mode=b.dataset.modeChoice;this.apply();this.render();q('[data-mode-choice="'+s.mode+'"]')?.focus({preventScroll:true});};
  for(const b of all('[data-theme-menu]'))b.onclick=()=>this.showThemeMenu(b,b.dataset.themeMenu);
  for(const b of all('[data-scheme-menu]'))b.onclick=()=>this.showMenu(this.selectedId(s,b.dataset.schemeMenu),{target:b});
  for(const input of all('[data-color]')){const [variant,key]=input.dataset.color.split(':'),button=q('[data-color-picker="'+input.dataset.color+'"]');const change=value=>{if(!this.validHex(value)){this.invalidColors[input.dataset.color]=value;input.setAttribute('aria-invalid','true');return;}delete this.invalidColors[input.dataset.color];input.removeAttribute('aria-invalid');input.value=value.toUpperCase();button.style.setProperty('--well-color',value);this.updateColor(variant,key,value);if(key==='accent')q('[data-accent="'+variant+'"]').value='';};input.oninput=()=>change(input.value.trim());button.onclick=()=>this.openColorPicker(button,this.resolvedProfile(s,variant)[key],change);if(Object.hasOwn(this.invalidColors||{},input.dataset.color)){input.value=this.invalidColors[input.dataset.color];input.setAttribute('aria-invalid','true');}}
  for(const select of all('[data-accent]')){const variant=select.dataset.accent;select.onchange=()=>{if(!select.value)return;const value=select.value==='default'?(this.palette(s,variant).variants?.[variant]?.accent||this.profile({...s,[variant]:{...s[variant],overrides:{}}},variant)?.accent||this.presets.chatgpt.variants[variant].accent):select.value;this.updateColor(variant,'accent',value);const input=q('[data-color="'+variant+':accent"]');delete this.invalidColors[input.dataset.color];input.value=value.toUpperCase();input.removeAttribute('aria-invalid');q('[data-color-picker="'+variant+':accent"]').style.setProperty('--well-color',value);};}
  for(const input of all('[data-contrast]')){input.style.setProperty('--range-position',input.value+'%');input.oninput=()=>{input.style.setProperty('--range-position',input.value+'%');input.nextElementSibling.value=input.value;this.updateColor(input.dataset.contrast,'contrast',input.value);};}
  q('[data-advanced]').onclick=()=>{this.advancedOpen=!this.advancedOpen;this.render();q('[data-advanced]').focus({preventScroll:true});};
  q('[role=switch]').onclick=()=>{s.separate=!s.separate;this.apply();this.render();q('[role=switch]').focus({preventScroll:true});};
  q('[data-reset]').onclick=()=>{this.colorEdits={};this.pendingName='';this.edit=null;this.invalidColors={};for(const variant of ['light','dark'])s[variant]={preset:'chatgpt',overrides:{}};s.preset='chatgpt';s.mode='auto';s.separate=false;this.apply();this.render();this.message('已预览默认配色；你的已保存方案仍保留。');};
  for(const b of all('[data-import]'))b.onclick=()=>{this.importOpen=true;this.render();q('[data-import-text]').focus();};
  q('[data-import-text]').value=this.importText||'';q('[data-import-text]').oninput=e=>{this.importText=e.target.value;};q('[data-import-close]').onclick=()=>{this.importOpen=false;this.render();};
  q('[data-import-confirm]').onclick=()=>{try{this.importTheme(q('[data-import-text]').value);}catch(e){this.message(e.message,true);}};
  for(const b of all('[data-copy]'))b.onclick=async()=>{try{await navigator.clipboard.writeText(this.exportTheme(b.dataset.copy));this.message('主题已复制。');}catch{this.message('无法访问剪贴板，请检查应用权限。');}};
  if(this.edit){q('[data-scheme-name]').value=this.edit.name;q('[data-scheme-name]').oninput=e=>this.edit.name=e.target.value;}
  q('[data-save-scheme]').onclick=()=>{if(this.saveScheme()){this.apply();this.render();this.message('方案已加入预览，应用后保存。');}};q('[data-save-cancel]').onclick=()=>{this.edit=null;this.render();};
  for(const b of all('[data-action=cancel]'))b.onclick=()=>this.close(false);q('[data-action=apply]').onclick=()=>this.commit();
  q('[data-pending-name]').oninput=e=>{this.pendingName=e.target.value;e.target.removeAttribute('aria-invalid');this.message();};this.updatePendingUI();q('.et-theme-body').scrollTop=scroll;
 }

 clone(value){return JSON.parse(JSON.stringify(value));}
 cleanName(value){return typeof value==='string'?value.replace(/[\u0000-\u001f\u007f]/g,'').trim().slice(0,32):'';}
 catalog(state=this.draft||this.state){return Object.assign({},this.presets,Object.fromEntries((state?.saved||[]).map(p=>[p.id,p])));}
 read(){try{return this.normalize(JSON.parse(localStorage.getItem(this.key)));}catch{return this.normalize();}}
 rgb(hex){return [1,3,5].map(i=>parseInt(hex.slice(i,i+2),16));}
 mix(a,b,t){return '#'+this.rgb(a).map((v,i)=>Math.round(v+(this.rgb(b)[i]-v)*t).toString(16).padStart(2,'0')).join('');}
 luminance(hex){return this.rgb(hex).map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;}).reduce((s,v,i)=>s+v*[.2126,.7152,.0722][i],0);}
 textFor(bg){return this.luminance(bg)>.19?'#292a31':'#eeedf2';}
 contrast(a,b){const x=this.luminance(a),y=this.luminance(b);return(Math.max(x,y)+.05)/(Math.min(x,y)+.05);}
 detectMode(){this.style.disabled=true;const css=getComputedStyle(document.body),match=css.backgroundColor.match(/[\d.]+/g);this.style.disabled=false;let mode=document.documentElement.classList.contains('theme-dark')||document.body.classList.contains('theme-dark')?'dark':'light';if(match&&match.length>=3&&!(match.length>3&&Number(match[3])===0)){const hex='#'+match.slice(0,3).map(v=>Math.round(Number(v)).toString(16).padStart(2,'0')).join('');mode=this.luminance(hex)<.19?'dark':'light';}try{localStorage.setItem('et-theme-native-mode-v1',mode);}catch{}return mode;}
 mode(state=this.draft||this.state){return state.mode==='auto'?this.nativeMode:state.mode;}
 addLauncher(){
  if(this.quickbar?.isConnected)return;
  const source=document.getElementById('toggle-sourceview-btn');
  if(!source?.parentElement){if((this.launcherRetries=(this.launcherRetries||0)+1)<20)setTimeout(()=>this.addLauncher(),250);return;}
  this.quickbar=document.createElement('div');this.quickbar.className='et-theme-quickbar footer-item footer-item-left';
  this.launcher=document.createElement('button');this.launcher.type='button';this.launcher.className='et-theme-palette-launcher';this.launcher.setAttribute('aria-label','随机切换配色');this.launcher.innerHTML=this.icon();
  for(const type of ['mousedown','click','keydown'])this.launcher.addEventListener(type,e=>e.stopPropagation());
  this.launcher.onclick=()=>this.randomize();this.quickbar.append(this.launcher);source.after(this.quickbar);this.updateLauncher();this.toolbar.researchSidebar?.layout();
 }
 updateLauncher(){if(this.launcher)this.launcher.title='随机切换配色 · 当前：'+this.palette().name;}
 message(text='',error=false){if(!this.dialog)return;const status=this.dialog.querySelector('.et-theme-warning');status.textContent=text;status.dataset.error=String(error);status.hidden=!text;}
 icon(){return '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M12 3a9 9 0 1 0 0 18h1a2 2 0 0 0 1-3.7 1.5 1.5 0 0 1 1-2.8h2a4 4 0 0 0 4-4C21 6 17 3 12 3Z"/><circle cx="7" cy="10" r=".8"/><circle cx="10" cy="7" r=".8"/><circle cx="15" cy="7" r=".8"/><circle cx="17" cy="11" r=".8"/></svg>';}
 apply(){const s=this.draft||this.state,t=this.tokens(s),c=this.colors(s);this.currentColors=c;this.currentTokens=t;
  // The first-paint style is created before the toolbar stylesheet. Keep the
  // same element, but restore its cascade order when the full toolbar takes over.
  if(document.head.lastElementChild!==this.style)document.head.append(this.style);
  if(!c)this.style.textContent='';else{
   const {bg,side,card,bold,text,cardText,sideText,muted,border,hover,active,link,accent,selection,selectionText}=t,graphNode=this.mix(link,text,.45);
   const native=`--select-text-bg-color:${selection};--select-text-font-color:${selectionText};--bg-color:${bg};--text-color:${text};--side-bar-bg-color:${side};--control-text-color:${muted};--active-file-bg-color:${active};--active-file-text-color:${sideText};--item-hover-bg-color:${hover};--window-border:${border};--search-select-bg-color:${active};--search-select-text-color:${text};`;
   const et=`--et-accent:${accent};--et-surface:${card};--et-surface-strong:${card};--et-border:${border};--et-border-strong:${this.mix(text,bg,.60)};--et-text:${cardText};--et-text-dim:${this.mix(cardText,card,.30)};--et-hover:${hover};--et-active:${active};--et-shadow:0 8px 26px #0002;--et-shadow-soft:0 4px 14px #0002;`;
   const prefBg=card,prefText=text,prefAccent=accent;
   const panels=':is(#et-annotation-panel,#et-document-note-panel,#et-manual-mark-panel,#et-annotation-preview,#et-citation-preview,#et-split-citation-preview)';
   // Keep the rightmost selector restricted to bold elements. A descendant
   // wildcard inside :not() makes any ancestor style change (including a
   // sidebar's content inset) invalidate every MathJax node in the document.
   const strong=':where(strong,b):not([style*="color"],[style*="color"] strong,[style*="color"] b)';
   this.style.textContent=`@media screen {
    :root,.theme-dark,[data-theme="dark"]{${et}--et-annotation-preview-bg:${card};--et-annotation-rgb:${this.rgb(c[4]||bold).join(',')};--et-annotation-accent:${c[4]||bold};--et-annotation-opacity:${this.mode(s)==='dark'?.28:.16};--et-annotation-active-opacity:${this.mode(s)==='dark'?.42:.30};} .et-top-chrome button:focus-visible,.et-settings-dialog :focus-visible{outline-color:${accent};} .et-settings-row.et-drop-before{box-shadow:inset 0 2px ${accent};} .et-settings-row.et-drop-after{box-shadow:inset 0 -2px ${accent};} #editing-toolbar-top-host:not([data-placement="floating"]){background:${card};border-bottom-color:${border};} ${panels}{${native}${et}color:${cardText};color-scheme:${this.mode(s)};}
    #et-research-panel:not(.et-rs-dark),.et-rs-node-menu:not(.et-rs-dark){${native}${et}color-scheme:${this.mode(s)};--rs-accent:${link};--rs-border:${border};--et-graph-node:${graphNode};--et-graph-accent:${link};--et-graph-edge:${muted};--et-graph-bg:${side};background:${side};color:${sideText};}
    .et-settings-dialog{${native}color:${prefText};color-scheme:${this.mode(s)};--et-surface:${prefBg};--et-surface-strong:${prefBg};--et-text:${prefText};--et-text-dim:${this.mix(prefText,prefBg,.28)};--et-border:${this.mix(prefText,prefBg,.82)};--et-border-strong:${this.mix(prefText,prefBg,.64)};--et-hover:${this.mix(prefAccent,prefBg,.90)};--et-active:${this.mix(prefAccent,prefBg,.82)};--et-preferences-accent:${prefAccent};--et-preferences-on-accent:${this.textFor(prefAccent)};--et-preferences-error:${this.luminance(prefBg)<.19?'#ffb2be':'#b5263c'};}
    #et-manual-mark-panel{--et-mark-surface:${bg};--et-mark-card:${this.mix(bg,card,.25)};--et-mark-accent:${link};--et-mark-selected:${this.mix(bg,accent,.07)};background:var(--et-mark-surface);}
    ${s.scope==='app'?`:root{${native}} html,body,content,#write{background-color:${bg}!important;color:${text}!important;color-scheme:${this.mode(s)};}
    #typora-sidebar,#sidebar-content,#ty-sidebar-footer{background-color:${side}!important;color:${sideText}!important;}
    #typora-sidebar :is(.file-node-title,.file-list-item-file-name,.outline-item,.sidebar-tab){color:inherit;}
    #write ${strong}{color:${bold};} #write a:not([style*="color"]){color:${link};}
    #write :is(blockquote,hr,th,td){border-color:${border};} #write blockquote{color:${muted};}
    #write :is(.md-fences,code,.md-rawblock-container):not([style*="background"]){background-color:${this.mix(bg,card,.45)};}
    #write :is(th,tr:nth-child(2n) td):not([style*="background"]){background-color:${this.mix(bg,card,.4)};}
    #typora-source .CodeMirror{background:${bg};color:${text};} #write .MathJax{color:${text};}`:''}
   }`;
  }
  for(const m of [this.toolbar.annotations,this.toolbar.documentNotes,this.toolbar.manualMarks])m?._themeEditor();this.toolbar.researchSidebar?.applyTheme(c?this.mode(s):this.nativeMode);
  this.updateLauncher();this.refreshDialogColors?.();
 }
 styleFrame(frame){const doc=frame?.contentDocument;if(!doc?.head)return;let style=doc.getElementById('et-note-theme-palette');if(!style){style=doc.createElement('style');style.id='et-note-theme-palette';doc.head.append(style);}const t=this.currentTokens;style.textContent=t?`@media screen {::selection{background:${t.selection};color:${t.selectionText};}html,body{background:${t.bg};color:${t.text};color-scheme:${this.mode()};} a{color:${t.accent};}:where(strong,b):not([style*="color"],[style*="color"] strong,[style*="color"] b){color:${t.bold};}}`:'';}

 open(){if(this.dialog){this.dialog.querySelector('button')?.focus();return;}this.toolbar._closeActivePopover();this.toolbar.hide();this.previousFocus=document.activeElement;this.draft=this.clone(this.state);this.colorEdits={};this.pendingName='';this.nativeProfiles={light:this.nativeProfile('light'),dark:this.nativeProfile('dark')};this.edit=null;this.importOpen=false;this.importText="";this.invalidColors={};this.backdrop=document.createElement('div');this.backdrop.className='et-theme-backdrop';this.dialog=document.createElement('section');this.dialog.className='et-theme-dialog';this.dialog.setAttribute('role','dialog');this.dialog.setAttribute('aria-modal','true');this.dialog.setAttribute('aria-labelledby','et-theme-title');this.backdrop.append(this.dialog);document.body.append(this.backdrop);this.render();this.disposeMovement=attachMovablePreferences(this.dialog,()=>{this.closeColorPicker();this.closeMenu();});
  for(const type of ['mousedown','click','keydown'])this.backdrop.addEventListener(type,e=>e.stopPropagation());
  this.backdrop.addEventListener('mousedown',e=>{if(e.target===this.backdrop)this.close(false);});
  this.dialog.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();this.colorPopup?this.closeColorPicker(true):this.menu?this.closeMenu(true):this.close(false);}if(e.key==='Tab'){const items=[...this.dialog.querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled)')].filter(n=>n.getClientRects().length),i=items.indexOf(document.activeElement);if(e.shiftKey&&i<=0){e.preventDefault();items.at(-1)?.focus();}else if(!e.shiftKey&&i===items.length-1){e.preventDefault();items[0]?.focus();}}});
  this.dialog.addEventListener('contextmenu',e=>{if(e.target.closest('input,select,textarea'))return;e.preventDefault();e.stopPropagation();this.showMenu(e.target.closest('[data-card]')?.dataset.card||null,e);});
  this.dialog.addEventListener('pointerdown',e=>{if(this.menu&&!this.menu.contains(e.target))this.closeMenu();if(this.colorPopup&&!this.colorPopup.contains(e.target)&&e.target!==this.colorAnchor)this.closeColorPicker();});
  this.dialog.addEventListener('wheel',e=>{if(this.menu?.contains(e.target)||this.colorPopup?.contains(e.target))return;this.closeMenu();this.closeColorPicker();},{capture:true,passive:true});
  this.dialog.addEventListener('scroll',e=>{
   if(this.menu?.contains(e.target)||this.colorPopup?.contains(e.target))return;
   // Ignore delayed scroll events from the click's own scroll-into-view step.
   const moved=(anchor,previous)=>{const r=anchor?.getBoundingClientRect();return r&&previous&&(Math.abs(r.top-previous.top)>1||Math.abs(r.left-previous.left)>1);};
   if(moved(this.menuAnchor,this.menuRect))this.closeMenu();if(moved(this.colorAnchor,this.colorRect))this.closeColorPicker();
  },true);
  this.dialog.querySelector('[data-mode-choice="'+this.draft.mode+'"]')?.focus();
 }
 colorHSV(hex){const [r,g,b]=this.rgb(hex).map(v=>v/255),max=Math.max(r,g,b),min=Math.min(r,g,b),d=max-min;let h=0;if(d)h=60*(max===r?((g-b)/d+6)%6:max===g?(b-r)/d+2:(r-g)/d+4);return{h,s:max?d/max:0,v:max};}
 colorHex({h,s,v}){const c=v*s,x=c*(1-Math.abs((h/60)%2-1)),m=v-c,segments=[[c,x,0],[x,c,0],[0,c,x],[0,x,c],[x,0,c],[c,0,x]],rgb=segments[Math.floor(h/60)%6];return '#'+rgb.map(n=>Math.round((n+m)*255).toString(16).padStart(2,'0')).join('');}
 closeColorPicker(focus=false){const anchor=this.colorAnchor;this.colorPopup?.remove();this.colorPopup=null;this.colorAnchor=null;anchor?.setAttribute('aria-expanded','false');if(focus&&anchor?.isConnected)anchor.focus({preventScroll:true});}
 openColorPicker(anchor,value,onChange){if(this.colorAnchor===anchor){this.closeColorPicker(true);return;}this.closeColorPicker();this.closeMenu();const popup=document.createElement('div');popup.className='et-theme-color-popup';popup.setAttribute('role','dialog');popup.setAttribute('aria-label',anchor.getAttribute('aria-label')+'选择');popup.innerHTML='<div class="et-theme-color-sv" role="slider" tabindex="0" aria-label="饱和度与明度，左右调整饱和度，上下调整明度" aria-valuemin="0" aria-valuemax="100"><span></span></div><label class="et-theme-hue-label">色相<input class="et-theme-color-hue" type="range" min="0" max="359" step="1" aria-label="色相"></label><div class="et-theme-color-foot"><output></output><button type="button">完成</button></div>';this.colorPopup=popup;this.colorAnchor=anchor;anchor.setAttribute('aria-expanded','true');this.dialog.append(popup);
  const hsv=this.colorHSV(value),square=popup.querySelector('.et-theme-color-sv'),hue=popup.querySelector('input'),output=popup.querySelector('output');
  const update=(apply=true)=>{const hex=this.colorHex(hsv);square.style.setProperty('--hue-color',this.colorHex({h:hsv.h,s:1,v:1}));square.firstElementChild.style.left=hsv.s*100+'%';square.firstElementChild.style.top=(1-hsv.v)*100+'%';square.setAttribute('aria-valuenow',String(Math.round(hsv.s*100)));square.setAttribute('aria-valuetext','饱和度 '+Math.round(hsv.s*100)+'%，明度 '+Math.round(hsv.v*100)+'%');hue.value=Math.round(hsv.h);output.textContent=hex.toUpperCase();if(apply)onChange(hex);};update(false);
  const select=e=>{const r=square.getBoundingClientRect();hsv.s=Math.max(0,Math.min(1,(e.clientX-r.left)/r.width));hsv.v=1-Math.max(0,Math.min(1,(e.clientY-r.top)/r.height));update();};
  let pointer=null;square.onpointerdown=e=>{if(e.button!==0)return;e.preventDefault();square.focus({preventScroll:true});pointer=e.pointerId;square.setPointerCapture(pointer);select(e);};square.onpointermove=e=>{if(e.pointerId===pointer)select(e);};const release=()=>{pointer=null;};square.onpointerup=release;square.onpointercancel=release;square.onlostpointercapture=release;
  square.onkeydown=e=>{const step=e.shiftKey?.1:.01;if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'].includes(e.key))return;e.preventDefault();e.stopPropagation();if(e.key==='ArrowLeft')hsv.s-=step;if(e.key==='ArrowRight')hsv.s+=step;if(e.key==='ArrowUp')hsv.v+=step;if(e.key==='ArrowDown')hsv.v-=step;if(e.key==='Home')hsv.s=0;if(e.key==='End')hsv.s=1;hsv.s=Math.min(1,Math.max(0,hsv.s));hsv.v=Math.min(1,Math.max(0,hsv.v));update();};
  hue.oninput=()=>{hsv.h=Number(hue.value);update();};popup.querySelector('button').onclick=()=>this.closeColorPicker(true);popup.oncontextmenu=e=>{e.preventDefault();e.stopPropagation();};popup.onkeydown=e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();this.closeColorPicker(true);}if(e.key==='Tab'){const items=[square,hue,popup.querySelector('button')],i=items.indexOf(document.activeElement);if(e.shiftKey&&i===0||!e.shiftKey&&i===items.length-1){e.preventDefault();e.stopPropagation();items[e.shiftKey?items.length-1:0].focus({preventScroll:true});}}};
  const r=anchor.getBoundingClientRect();this.colorRect={top:r.top,left:r.left};popup.style.left=Math.max(8,Math.min(innerWidth-popup.offsetWidth-8,r.left))+'px';popup.style.top=Math.max(8,Math.min(innerHeight-popup.offsetHeight-8,r.bottom+7))+'px';square.focus({preventScroll:true});
 }
 close(commit=false,candidate=this.draft){if(!this.dialog)return false;if(commit){const saved=this.normalize(candidate);try{localStorage.setItem(this.key,JSON.stringify(saved));this.state=saved;}catch(e){this.message('配色未能保存：'+e.message,true);return false;}}if(this.colorRaf){cancelAnimationFrame(this.colorRaf);this.colorRaf=0;}this.closeColorPicker();this.closeMenu();this.edit=null;this.colorEdits={};this.pendingName='';this.nativeProfiles=null;this.draft=null;this.disposeMovement?.();this.disposeMovement=null;this.backdrop.remove();this.dialog=null;this.backdrop=null;this.apply();if(this.previousFocus?.isConnected)this.previousFocus.focus({preventScroll:true});return true;}
}
