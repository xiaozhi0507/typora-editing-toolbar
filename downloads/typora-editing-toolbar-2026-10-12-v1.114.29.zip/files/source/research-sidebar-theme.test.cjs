const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),{JSDOM}=require('jsdom');
function setup(t,{options={},mounted=true}={}){
 const dom=new JSDOM('<body><aside id="typora-sidebar"><footer id="ty-sidebar-footer"></footer></aside></body>',{url:'https://typora.test',pretendToBeVisual:true});t.after(()=>dom.window.close());
 const w=dom.window;w.localStorage.setItem('et-research-sidebar-v1',JSON.stringify({naturalLayoutVersion:1,options}));
 class Graph{constructor(){this.canvas=w.document.createElement('canvas');} configure(o){this.options=o;} request(){} fit(){} set(d,o){this.data=d;this.options=o;}}
 const context={document:w.document,window:w,localStorage:w.localStorage,File:{getMountFolder:()=>mounted?'C:/notes':''},ResearchGraphView:Graph,ResearchGraphMenu:class{constructor(){this.menu=w.document.createElement('div');}close(){}},ResearchGraphCache:class{},ResearchGraphOutline:class{reset(){}},ResizeObserver:class{observe(){}},requestAnimationFrame:w.requestAnimationFrame.bind(w),cancelAnimationFrame:w.cancelAnimationFrame.bind(w),setTimeout,clearTimeout};
 const source=fs.readFileSync(__dirname+'/research-sidebar.js','utf8').replace(/^import .*;\r?\n/gm,'').replace('export class','class');
 const Sidebar=vm.runInNewContext(source+';ResearchSidebar',context);Sidebar.prototype.bind=function(){};Sidebar.prototype.switchFile=function(){};
 const sidebar=new Sidebar({annotations:{fs:{},path}},'');
 const input=label=>[...sidebar.settings.querySelectorAll('label')].find(n=>n.firstElementChild?.textContent===label)?.querySelector('input');
 return {sidebar,w,input};
}
test('existing manual dark/light choice remains unchanged until follow is enabled',t=>{
 for(const darkGraph of [false,true]){const h=setup(t,{options:{darkGraph}});h.sidebar.applyTheme(darkGraph?'light':'dark');assert.equal(h.sidebar.isGraphDark(),darkGraph);assert.equal(h.input('跟随主题').checked,false);assert.equal(h.input('暗色背景').disabled,false);}
});
test('follow tracks both theme directions and locks background without overwriting manual preference',t=>{
 const h=setup(t,{options:{darkGraph:false}}),s=h.sidebar;s.applyTheme('dark');h.input('跟随主题').click();
 assert.equal(s.graph.options.darkGraph,true);assert.equal(h.input('暗色背景').checked,true);assert.equal(h.input('暗色背景').disabled,true);assert.equal(s.lightColorBox.disabled,true);
 h.input('暗色背景').click();assert.equal(s.options.darkGraph,false);
 s.applyTheme('light');assert.equal(s.graph.options.darkGraph,false);assert.equal(h.input('暗色背景').checked,false);assert.equal(h.input('暗色背景').disabled,true);
 s.applyTheme('dark');h.input('跟随主题').click();assert.equal(s.graph.options.darkGraph,false);assert.equal(h.input('暗色背景').disabled,false);assert.equal(s.lightColorBox.disabled,false);
});
test('saved dark preference is restored after following a light theme',t=>{
 const h=setup(t,{options:{darkGraph:true}});h.sidebar.applyTheme('light');h.input('跟随主题').click();assert.equal(h.sidebar.graph.options.darkGraph,false);h.input('跟随主题').click();assert.equal(h.sidebar.graph.options.darkGraph,true);assert.equal(h.sidebar.lightColorBox.disabled,true);
});
test('follow and original manual preference survive settings reload and scope changes',t=>{
 const h=setup(t,{options:{darkGraph:true}});h.sidebar.applyTheme('light');h.input('跟随主题').click();
 const saved=JSON.parse(h.w.localStorage.getItem('et-research-sidebar-v1')),next=setup(t,{options:saved.options});next.sidebar.applyTheme('light');assert.equal(next.input('跟随主题').checked,true);assert.equal(next.sidebar.graph.options.darkGraph,false);assert.equal(next.sidebar.options.darkGraph,true);
 next.sidebar.setGraphScope('local');assert.equal(next.input('暗色背景').disabled,true);next.sidebar.setDepthView(true);assert.equal(next.sidebar.graph.options.darkGraph,false);next.sidebar.applyTheme('dark');assert.equal(next.sidebar.graph.options.darkGraph,true);
});
test('theme preview rollback restores effective mode and keeps filters/layout',t=>{
 const h=setup(t,{options:{followTheme:true,existingOnly:true,nodeSize:2,scope:'local'}}),s=h.sidebar;
 s.applyTheme('light');s.applyTheme('dark');s.applyTheme('light');assert.equal(s.graph.options.darkGraph,false);assert.equal(s.options.existingOnly,true);assert.equal(s.options.nodeSize,2);assert.equal(s.options.scope,'local');
});
test('reset removes follow and unlocks manual background',t=>{
 const h=setup(t,{options:{followTheme:true,darkGraph:true}});h.sidebar.applyTheme('dark');h.sidebar.settings.querySelector('[aria-label="恢复图谱默认设置"]').click();assert.equal(h.input('跟随主题').checked,false);assert.equal(h.input('暗色背景').disabled,false);assert.equal(h.sidebar.graph.options.darkGraph,false);
});
test('settings remove marked notes and paths while retaining actionable folder selection',t=>{
 for(const mounted of [true,false]){const h=setup(t,{mounted}),s=h.sidebar;assert.equal(s.settings.querySelector('.et-rs-help'),null);assert.equal(s.settings.textContent.includes('C:/notes'),false);assert.equal(s.settings.textContent.includes('选择索引文件夹'),!mounted);assert(s.settings.textContent.indexOf('跟随主题')<s.settings.textContent.indexOf('暗色背景'));s.setGraphScope('local');assert(h.input('入链（反向链接）'));assert.equal(s.settings.querySelector('.et-rs-help'),null);}
});
test('theme manager notifies graph even when using the original Typora theme',t=>{
 const h=setup(t,{options:{followTheme:true}}),Palette=vm.runInNewContext(fs.readFileSync(__dirname+'/theme-palette.js','utf8')+';EditingToolbarThemePalette',{ET_CODEX_THEME_PRESETS:{},document:h.w.document});
 const p=Object.create(Palette.prototype);Object.assign(p,{state:{mode:'light'},nativeMode:'dark',style:h.w.document.createElement('style'),tokens:()=>null,colors:()=>null,toolbar:{researchSidebar:h.sidebar},updateLauncher(){},refreshDialogColors(){}});
 p.apply();assert.equal(h.sidebar.graph.options.darkGraph,true);p.nativeMode='light';p.state.mode='dark';p.apply();assert.equal(h.sidebar.graph.options.darkGraph,false);
});
