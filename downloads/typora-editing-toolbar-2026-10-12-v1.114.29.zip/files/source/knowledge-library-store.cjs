'use strict';
// Metadata only. Linked documents are never moved, rewritten, or deleted here.
class KnowledgeLibraryStore {
  constructor(root, requireNode = require) {
    this.fs = requireNode('fs'); this.io = this.fs.promises;
    this.path = requireNode('path'); this.crypto = requireNode('crypto'); this.process = requireNode('process');
    this.root = this.path.resolve(root);
    this.file = this.path.join(this.root, 'library.json');
    this.previous = this.file + '.previous'; this.lockFile = this.file + '.lock';
  }
  static clone(value) { return JSON.parse(JSON.stringify(value)); }
  static orderCollections(collections) {
    // Older libraries keep their original array order until a sibling group is moved.
    return collections.map((collection,index)=>({collection,index,order:Number.isFinite(collection.sortOrder)?collection.sortOrder:index}))
      .sort((a,b)=>a.order-b.order||a.index-b.index).map(entry=>entry.collection);
  }
  static equal(a, b) { return JSON.stringify(a) === JSON.stringify(b); }
  static itemContent(item) {
    // Reading history and cached service results have their own timestamps.
    const { modified, last, lastFile, metrics, notes, ...content } = item;
    return content;
  }
  static merge(base, local, remote) {
    const same = this.equal, copy = this.clone;
    const result = { ...copy(remote) };
    for (const group of ['items', 'collections']) {
      const before = new Map(base[group].map(v => [v.id, v]));
      const next = new Map(local[group].map(v => [v.id, v]));
      const current = new Map(remote[group].map(v => [v.id, copy(v)]));
      const conflict = id => { const e = new Error('其他窗口已修改同一条目或分类，请保留当前修改并重新载入后再编辑。'); e.code = 'CONFLICT'; e.entity = id; throw e; };
      for (const [id, old] of before) {
        const wanted = next.get(id), live = current.get(id);
        if (same(old, wanted)) continue;
        if (!wanted) { if (live && !same(old, live)) conflict(id); current.delete(id); continue; }
        if (!live) conflict(id);
        for (const key of new Set([...Object.keys(old), ...Object.keys(wanted)])) {
          if (same(old[key], wanted[key])) continue;
          if (!same(live[key], old[key]) && !same(live[key], wanted[key])) conflict(id);
          if (wanted[key] === undefined) delete live[key]; else live[key] = copy(wanted[key]);
        }
      }
      for (const [id, wanted] of next) if (!before.has(id)) {
        if (current.has(id) && !same(current.get(id), wanted)) conflict(id);
        current.set(id, copy(wanted));
      }
      result[group] = [...current.values()];
    }
    return result;
  }
  validate(data) {
    const fail = message => { throw new Error('知识库数据无效：' + message); };
    if (!data || data.schemaVersion !== 1 || typeof data.libraryId !== 'string' || !Number.isSafeInteger(data.revision) || data.revision < 0 || !Array.isArray(data.items) || !Array.isArray(data.collections)) fail('版本或结构不受支持');
    const ids = new Set(), collectionIds = new Set();
    const validID = id => typeof id === 'string' && /^[\w-]{1,100}$/.test(id);
    for (const c of data.collections) {
      if (!validID(c.id) || collectionIds.has(c.id) || typeof c.name !== 'string' || !c.name.trim()) fail('分类名称或标识重复');
      collectionIds.add(c.id);
    }
    const parents = new Map(data.collections.map(c => [c.id, c.parentId || null]));
    for (const c of data.collections) {
      const seen = new Set([c.id]); let parent = c.parentId;
      while (parent) { if (!parents.has(parent) || seen.has(parent)) fail('分类层级存在循环或缺失'); seen.add(parent); parent = parents.get(parent); }
    }
    for (const item of data.items) {
      if (!validID(item.id) || ids.has(item.id) || typeof item.title !== 'string' || !['paper', 'thesis', 'book', 'note', 'webpage'].includes(item.type)) fail('条目标题、类型或标识无效');
      ids.add(item.id);
      if(item.type==='webpage'){KnowledgeLibraryStore.webURL(item.url);if(['status','readStatus','saveStatus'].some(key=>Object.hasOwn(item,key)))fail('网页不使用阅读或保存状态字段');}
      if ((item.type !== 'webpage' && !['unread', 'reading', 'done'].includes(item.status)) || !Array.isArray(item.files) || !Array.isArray(item.tags) || !Array.isArray(item.collections) || !Array.isArray(item.related)) fail('条目字段缺失');
      if (item.tags.some(t => typeof t !== 'string') || item.collections.some(id => !collectionIds.has(id))) fail('标签或分类成员无效');
      const files = new Set();
      for (const f of item.files) {
        if (!validID(f.id) || files.has(f.id) || typeof f.name !== 'string' || typeof f.path !== 'string' || !f.path || f.path.includes('\0')) fail('附件路径或标识无效');
        files.add(f.id); if(f.linkType==='url'){if(f.relative)fail('网页链接不能是相对路径');KnowledgeLibraryStore.webURL(f.path);}else this.resolveFile(f);
      }
      if ((item.defaultFile && !files.has(item.defaultFile)) || (item.lastFile && !files.has(item.lastFile))) fail('默认或最近附件不存在');
    }
    for (const item of data.items) {
      if (item.related.some(id => !ids.has(id) || id === item.id)) fail('相关条目不存在');
      if (item.relatedOut !== undefined && (!Array.isArray(item.relatedOut) || item.relatedOut.some(id => !ids.has(id) || id === item.id || !item.related.includes(id)))) fail('出链条目不存在或未关联');
    }
    return data;
  }
  hash(data) { return this.crypto.createHash('sha256').update(JSON.stringify(data)).digest('hex'); }
  encode(data) { this.validate(data); return JSON.stringify({ ...data, checksum: this.hash(data) }, null, 2) + '\n'; }
  decode(raw) {
    const data = JSON.parse(raw.replace(/^\uFEFF/, '')), checksum = data.checksum; delete data.checksum;
    if (typeof checksum !== 'string' || checksum !== this.hash(data)) throw new Error('知识库校验未通过');
    return this.validate(data);
  }
  async readOptional(file) { try { return await this.io.readFile(file, 'utf8'); } catch (e) { if (e.code === 'ENOENT') return null; throw e; } }
  async read() {
    const raw = await this.readOptional(this.file);
    let problem;
    if (raw !== null) { try { return { data: this.decode(raw), raw, recovered: false }; } catch (e) { problem = e; } }
    const previous = await this.readOptional(this.previous);
    if (previous !== null) {
      try { return { data: this.decode(previous), raw: previous, damaged: raw, recovered: true, warning: '已从上一份有效备份恢复。原损坏数据将在保存时保留。' }; }
      catch (e) { problem = problem || e; }
    }
    if (problem) throw new Error('无法读取知识库，未覆盖任何数据：' + problem.message);
    return null;
  }
  async atomic(file, raw) {
    const temp = file + '.tmp-' + this.crypto.randomUUID();
    let handle;
    try {
      handle = await this.io.open(temp, 'wx'); await handle.writeFile(raw, 'utf8'); await handle.sync(); await handle.close(); handle = null;
      // Windows scanners/readers can briefly hold the destination during rapid inline saves.
      // Retry only transient sharing failures; never unlink the last valid file first.
      for(let attempt=0;;attempt++){
        try{await this.io.rename(temp,file);break;}
        catch(error){if(this.process.platform!=='win32'||!['EPERM','EACCES','EBUSY'].includes(error.code)||attempt>=3)throw error;await new Promise(resolve=>setTimeout(resolve,50*(attempt+1)));}
      }
    } finally { if (handle) await handle.close().catch(() => {}); await this.io.unlink(temp).catch(() => {}); }
  }
  async locked(work) {
    await this.io.mkdir(this.root, { recursive: true });
    const token = this.crypto.randomUUID(); let handle;
    for (let attempt = 0; attempt < 30; attempt++) {
      try { handle = await this.io.open(this.lockFile, 'wx'); break; }
      catch (e) {
        if (e.code !== 'EEXIST') throw e;
        try {
          const raw = await this.io.readFile(this.lockFile, 'utf8'), lock = JSON.parse(raw);
          if (Number.isInteger(lock.pid) && lock.pid > 0 && Date.now() - lock.time > 10000) {
            let dead = false; try { this.process.kill(lock.pid, 0); } catch (p) { dead = p.code === 'ESRCH'; }
            if (dead && await this.io.readFile(this.lockFile, 'utf8') === raw) await this.io.unlink(this.lockFile);
          }
        } catch (_) { /* An incomplete or foreign lock is never stolen. */ }
        await new Promise(r => setTimeout(r, 70));
      }
    }
    if (!handle) throw new Error('另一个窗口正在保存知识库，请稍后重试。');
    try {
      await handle.writeFile(JSON.stringify({ token, pid: this.process.pid, time: Date.now() })); await handle.close(); handle = null;
      return await work();
    } finally {
      if (handle) await handle.close().catch(() => {});
      try { if (JSON.parse(await this.io.readFile(this.lockFile, 'utf8')).token === token) await this.io.unlink(this.lockFile); } catch (_) {}
    }
  }
  async open() {
    const existing = await this.read(); if (existing) return existing;
    return this.locked(async () => {
      const again = await this.read(); if (again) return again;
      const stored=await this.io.readdir(this.path.join(this.root,'storage')).catch(error=>{if(error.code==='ENOENT')return [];throw error;});
      if(stored.length)throw Error('此文件夹已有知识库附件，但缺少 library.json 和有效的 library.json.previous。请恢复索引文件或选择完整知识库文件夹，未创建空库。');
      const data = { schemaVersion: 1, libraryId: this.crypto.randomUUID(), revision: 0, updatedAt: new Date().toISOString(), items: [], collections: [] };
      const raw = this.encode(data); await this.atomic(this.file, raw); return { data, raw, recovered: false };
    });
  }
  async updateDocumentNavigation(readPreferences, libraryId) {
    return this.locked(async () => {
      const live=await this.read();if(!live||live.data.libraryId!==libraryId)throw Error('知识库已被替换或移动，请重新载入。');
      const value=readPreferences();
      if(KnowledgeLibraryStore.equal(live.data.documentNavigation,value))return live.data;
      const next={...live.data,documentNavigation:KnowledgeLibraryStore.clone(value),revision:live.data.revision+1,updatedAt:new Date().toISOString()};
      if(live.recovered&&live.damaged!=null)await this.atomic(this.file+'.damaged-'+Date.now()+'-'+this.crypto.randomUUID(),live.damaged);
      await this.atomic(this.previous,live.raw);await this.atomic(this.file,this.encode(next));return next;
    });
  }
  async commit(base, local, validateLive = null) {
    return this.locked(async () => {
      const live = await this.read(); if (!live || live.data.libraryId !== base.libraryId) throw new Error('知识库已被替换或移动，请重新载入。');
      if (validateLive) await validateLive(live.data);
      const next = KnowledgeLibraryStore.merge(base, local, live.data);
      const previousItems = new Map(live.data.items.map(item => [item.id, item]));
      const modified = new Date().toISOString();
      for (const item of next.items) {
        const previous = previousItems.get(item.id);
        if (!previous || !KnowledgeLibraryStore.equal(KnowledgeLibraryStore.itemContent(previous), KnowledgeLibraryStore.itemContent(item))) item.modified = modified;
      }
      this.validate(next);
      if (KnowledgeLibraryStore.equal(next.items, live.data.items) && KnowledgeLibraryStore.equal(next.collections, live.data.collections)) return live.data;
      next.revision = live.data.revision + 1; next.updatedAt = new Date().toISOString();
      if (live.recovered && live.damaged !== null && live.damaged !== undefined) await this.atomic(this.file + '.damaged-' + Date.now() + '-' + this.crypto.randomUUID(), live.damaged);
      await this.atomic(this.previous, live.raw);
      await this.atomic(this.file, this.encode(next));
      return next;
    });
  }
  fileRef(file, kind = '') {
    const absolute = this.path.resolve(file), relative = this.path.relative(this.root, absolute);
    const inside = relative && relative !== '..' && !relative.startsWith('..' + this.path.sep) && !this.path.isAbsolute(relative);
    const ext=this.path.extname(absolute).toLowerCase();
    return { id: this.crypto.randomUUID(), name: this.path.basename(absolute), kind: kind || (/^\.(md|markdown|mdown|txt)$/.test(ext)?'Markdown':ext.slice(1).toUpperCase()||'文件'), path: inside ? relative : absolute, relative: !!inside };
  }
  static webURL(value){
    const text=String(value||'').trim();let url;try{url=new URL(text);}catch(_){throw Error('请输入完整的 http:// 或 https:// 网页链接');}
    if(text.length>4096||!['http:','https:'].includes(url.protocol)||!url.hostname||url.username||url.password)throw Error('请输入不含登录凭据的 http:// 或 https:// 网页链接');
    return url.href;
  }
  urlRef(url,title=''){const address=KnowledgeLibraryStore.webURL(url);return {id:this.crypto.randomUUID(),name:String(title||'').trim().slice(0,1000)||address,kind:'网页链接',linkType:'url',path:address,relative:false};}
  resolveFile(file) {
    if(file.linkType==='url')throw Error('网页链接不是本地文件');
    if (!file.relative) { if (!this.path.isAbsolute(file.path)) throw new Error('外部附件需要绝对路径'); return this.path.normalize(file.path); }
    const absolute = this.path.resolve(this.root, file.path), relative = this.path.relative(this.root, absolute);
    if (relative === '..' || relative.startsWith('..' + this.path.sep) || this.path.isAbsolute(relative)) throw new Error('附件相对路径超出了知识库');
    return absolute;
  }
}
module.exports = KnowledgeLibraryStore;
