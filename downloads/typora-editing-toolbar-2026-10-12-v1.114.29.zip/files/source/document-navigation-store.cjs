'use strict';
// The browser cache is convenient, but is not a durable home for explicit bookmarks.
class DocumentNavigationStore {
  constructor(profile, requireNode = require) {
    this.fs = requireNode('fs'); this.path = requireNode('path'); this.crypto = requireNode('crypto');
    this.file = this.path.join(profile, 'editing-toolbar', 'document-navigation.json');
  }
  static valid(value) { return value && typeof value === 'object' && Array.isArray(value.favorites) && Array.isArray(value.pinned); }
  static parse(raw) { try { const value = JSON.parse(raw); return this.valid(value) ? value : null; } catch (_) { return null; } }
  hash(value) { return this.crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex'); }
  readFile(file) {
    try { const record = JSON.parse(this.fs.readFileSync(file, 'utf8')); return record.version === 1 && DocumentNavigationStore.valid(record.preferences) && record.checksum === this.hash(record.preferences) ? record.preferences : null; }
    catch (_) { return null; }
  }
  read(raw) { return DocumentNavigationStore.parse(raw) || this.readFile(this.file) || this.readFile(this.file + '.previous'); }
  atomic(file, text) {
    const temporary = file + '.tmp-' + this.crypto.randomUUID(); let fd;
    try {
      fd = this.fs.openSync(temporary, 'wx'); this.fs.writeFileSync(fd, text, 'utf8'); this.fs.fsyncSync(fd); this.fs.closeSync(fd); fd = undefined;
      this.fs.renameSync(temporary, file);
    } finally { if (fd !== undefined) this.fs.closeSync(fd); try { this.fs.unlinkSync(temporary); } catch (_) {} }
  }
  save(preferences) {
    if (!DocumentNavigationStore.valid(preferences)) throw Error('收藏和置顶设置无效');
    const old = this.readFile(this.file); if (old && this.hash(old) === this.hash(preferences)) return;
    this.fs.mkdirSync(this.path.dirname(this.file), {recursive: true});
    const encode = value => JSON.stringify({version: 1, preferences: value, checksum: this.hash(value)}, null, 2) + '\n';
    if (old) this.atomic(this.file + '.previous', encode(old));
    this.atomic(this.file, encode(preferences));
  }
  static portable(preferences, store) {
    const result = JSON.parse(JSON.stringify(preferences)); delete result.navigationLibraries; delete result.navigationRoots;
    for (const group of ['favorites', 'pinned']) result[group] = result[group].map(item => {
      const relative = store.path.relative(store.root, item.path);
      const inside = relative && relative !== '..' && !relative.startsWith('..' + store.path.sep) && !store.path.isAbsolute(relative);
      return {...item, path: inside ? relative.replaceAll('\\', '/') : item.path, relative: !!inside};
    });
    return result;
  }
  static restore(snapshot, store) {
    if (!DocumentNavigationStore.valid(snapshot)) return null;
    const result = JSON.parse(JSON.stringify(snapshot));
    for (const group of ['favorites', 'pinned']) result[group] = result[group].flatMap(item => {
      try { return [{path: store.resolveFile(item), ...(typeof item.sectionId === 'string' ? {sectionId: item.sectionId} : {})}]; }
      catch (_) { return []; }
    });
    return result;
  }
}
module.exports = DocumentNavigationStore;
