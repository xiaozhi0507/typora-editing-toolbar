class EditingToolbarFeatureModules {
 constructor(toolbar){this.toolbar=toolbar;this.tab='installed';this.busy=false;this.init().catch(e=>toolbar._showToolbarNotice(e.message));}
 node(tag,cls='',text){const el=document.createElement(tag);el.className=cls;if(text!==undefined)el.textContent=text;return el;}
 button(label,fn,cls=''){const b=this.node('button',cls,label);b.type='button';b.onclick=()=>this.run(fn);return b;}
 async init(){if(this.ready)return this.ready;return this.ready=(async()=>{
  for(let i=0;i<100&&(typeof reqnode!=='function'||!window.File?.option?.userDataPath);i++)await new Promise(resolve=>setTimeout(resolve,100));
  if(typeof reqnode!=='function'||!window.File?.option?.userDataPath)throw Error('模块管理尚未就绪，请稍后打开');
  this.store=new ETFeatureStore(reqnode,reqnode('path').join(File.option.userDataPath,'editing-toolbar','feature-modules'));
  this.updater=new ETToolbarUpdater(reqnode,reqnode('path').join(File.option.userDataPath,'editing-toolbar','host-updates'));
  // Modules are installed explicitly from the market or a local package.
  // Ignore legacy resources bundles; preserve only the user's existing registry.
  this.runtime=new ETFeatureRuntime(this.store,{assistant:row=>this.assistantHost(row),notice:message=>this.toolbar._showToolbarNotice(message),readDocument:()=>{if(File.isFileLoading?.())throw Error('文档正在加载');return {markdown:String(File.editor.sourceView?.inSourceMode?File.editor.sourceView.cm.getValue():File.editor.getMarkdown()),selection:String(window.getSelection()||'')};},addStyle:(id,css)=>{const s=this.node('style');s.dataset.featureModule=id;s.textContent=css;document.head.append(s);return()=>s.remove();},on:(target,event,fn,options)=>{const el=target==='window'?window:target==='document'?document:null;if(!el||typeof fn!=='function')throw Error('事件目标只支持 window 或 document');el.addEventListener(event,fn,options);return()=>el.removeEventListener(event,fn,options);},interval:(fn,ms)=>{const timer=setInterval(()=>Promise.resolve().then(fn).catch(e=>this.toolbar._showToolbarNotice(e.message)),ms);return()=>clearInterval(timer);}});
  await this.runtime.reconcile();
  this.onFocus=()=>this.runtime.reconcile().then(()=>this.dialog?.open&&this.render()).catch(e=>this.toolbar._showToolbarNotice(e.message));window.addEventListener('focus',this.onFocus);
  this.onStorage=e=>{if(e.key==='et-feature-module-change')this.onFocus();};window.addEventListener('storage',this.onStorage);
  window.addEventListener('unload',()=>{window.removeEventListener('focus',this.onFocus);window.removeEventListener('storage',this.onStorage);void this.runtime.close();},{once:true});
 })().catch(e=>{this.ready=null;throw e;});}
 assistantHost(row){return {version:1,toolbar:this.toolbar,workspaceState:()=>this.toolbar._aiWorkspaceDrafts||(this.toolbar._aiWorkspaceDrafts={code:new Map(),notebook:new Map()}),sessionKeys:()=>this.toolbar._aiModuleKeys||(this.toolbar._aiModuleKeys=new Map()),readSession:()=>this.toolbar._aiModuleSession,writeSession:value=>{this.toolbar._aiModuleSession=value;},bindPanel:Type=>EditingToolbarPanelWorkspace.bindType(Type),directory:row.directory,delay:(fn,ms)=>setTimeout(fn,ms),globals:{ETConnectionStore,ETKnowledgeStorage,ETKnowledgeManaged,ETCodeWorkspace,ETDocumentProjects,ETTerminalEnvironment,ETNotebookStore,ETAIWeb,ETAIExecution,ETAIShell},setEnabled:value=>{document.documentElement.classList.toggle('et-ai-module-enabled',value);},detachPanel:ai=>{const workspace=this.toolbar.panelWorkspace;if(workspace){workspace.closed(ai);workspace.entries.delete('ai');workspace.slots=workspace.slots.map(id=>id==='ai'?null:id);workspace.layout();}document.body.classList.remove('et-ai-docked');document.documentElement.style.removeProperty('--et-ai-width');this.toolbar._applyTopPlacement();}};}
 async changed(){await this.runtime.reconcile();try{localStorage.setItem('et-feature-module-change',Date.now()+':'+Math.random());}catch{}await this.render();}
 async run(fn){if(this.busy)return;this.busy=true;if(this.status)delete this.status.dataset.error;this.setBusy();try{await fn();}catch(e){this.status.textContent=e.message;this.status.dataset.error='true';}finally{this.busy=false;this.setBusy();}}
 setBusy(){if(!this.dialog)return;this.dialog.setAttribute('aria-busy',String(this.busy));this.dialog.querySelectorAll('button:not([data-close]),input').forEach(el=>{if(!el.closest('.et-module-prompt'))el.disabled=this.busy||el.dataset.unavailable==='true';});}
 async open(){await this.init();if(this.dialog?.open){this.dialog.focus();return;}this.toolbar._closeActivePopover();
  const d=this.dialog=this.node('dialog','et-module-center');d.setAttribute('aria-label','插件市场');
  const head=this.node('div','et-module-head'),title=this.node('div');title.append(this.node('h2','','插件市场'));
  const close=this.button('×',()=>d.close(),'et-module-close');close.dataset.close='';close.setAttribute('aria-label','关闭插件市场');head.append(title,close);
  this.tabs=this.node('nav','et-module-tabs');this.tabs.setAttribute('role','tablist');for(const [id,label]of [['installed','已安装'],['market','浏览市场'],['toolbar','工具栏更新']]){const b=this.button(label,async()=>{this.tab=id;this.status.textContent='';await this.render();if(id==='toolbar')await this.checkToolbar();});b.dataset.tab=id;b.setAttribute('role','tab');this.tabs.append(b);}
  this.tabs.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();const buttons=[...this.tabs.children],count=buttons.length,index=buttons.indexOf(document.activeElement),next=e.key==='Home'?0:e.key==='End'?count-1:(index+(e.key==='ArrowLeft'?count-1:1))%count;buttons[next].click();buttons[next].focus();}});
  this.actions=this.node('div','et-module-actions');this.checkStatus=this.node('span','et-module-check');this.checkStatus.setAttribute('role','status');this.checkStatus.setAttribute('aria-live','polite');
  this.importButton=this.button('',()=>this.importForm(),'et-module-import');this.importButton.innerHTML=this.glyph('plus');this.importButton.append(this.node('span','','本地安装'));this.actions.append(this.checkStatus,this.importButton);
  this.list=this.node('div','et-module-list');this.list.setAttribute('role','tabpanel');this.status=this.node('p','et-module-status');this.status.setAttribute('role','status');this.status.setAttribute('aria-live','polite');
  const foot=this.node('div','et-module-footer');foot.append(this.status);
  d.append(head,this.tabs,this.actions,this.list,foot);document.body.append(d);d.addEventListener('close',()=>{for(const child of d.querySelectorAll('dialog[open]'))child.close();d.remove();if(this.dialog===d)this.dialog=null;});d.addEventListener('keydown',e=>e.stopPropagation());d.showModal();await this.render();this.tabs.querySelector('[aria-selected=true]')?.focus();void this.checkUpdates();void this.checkToolbar().catch(e=>this.toolbar._showToolbarNotice(e.message));
 }
 async render(){const dialog=this.dialog;if(!dialog?.open)return;const state=await this.store.state();if(this.dialog!==dialog||!dialog.open)return;this.state=state;for(const b of this.tabs.children){b.setAttribute('aria-selected',String(this.tab===b.dataset.tab));b.tabIndex=this.tab===b.dataset.tab?0:-1;}this.actions.hidden=false;this.importButton.hidden=this.tab!=='installed';this.checkStatus.textContent=this.tab==='toolbar'?'':this.checkMessage||'';this.checkStatus.classList.toggle('is-checking',this.tab!=='toolbar'&&!!this.checking);await this.drawList();this.setBusy();}
 async checkToolbar(){if(this.hostChecking)return this.hostChecking;this.hostChecking=Promise.resolve().then(async()=>{await this.render();try{await this.updater.check();}finally{this.hostChecking=null;await this.render();}});return this.hostChecking;}
 async toolbarAction(action){
  const dialog=this.dialog;
  this.status.textContent=action==='prepare'?'正在下载并校验…':action==='queue'?'准备安装…':'正在取消等待…';
  if(action==='cancel'){await this.updater.cancel();this.status.textContent='';await this.render();return;}
  if(action==='prepare')await this.updater.prepare();
  this.status.textContent='';await this.render();
  if(this.dialog!==dialog||!dialog?.open)return;
  if(typeof JSBridge==='undefined'||typeof JSBridge.invoke!=='function')throw Error('无法打开 Typora 安装确认，请重新启动后重试');
  const state=await this.updater.state();
  const result=await JSBridge.invoke('dialog.showMessageBox',{type:'question',title:'工具栏更新',message:'工具栏 v'+state.stage.version+' 已准备就绪',detail:'退出 Typora 后完成安装。未保存的文档会先提示保存。',buttons:['退出并完成安装','取消'],defaultId:0,cancelId:1,noLink:true});
  if(result?.response!==0||this.dialog!==dialog||!dialog.open)return;
  await this.updater.queue();
  // Typora's native quit IPC runs its beforeunload/save flow. Remove our modal
  // first so the native #common-dialog remains visible if a document is dirty.
  dialog.close();
  try{await JSBridge.invoke('quit');}catch(e){await this.updater.cancel();this.toolbar._showToolbarNotice('未能退出 Typora，已取消安装：'+e.message);}
 }
 async drawToolbarUpdate(){
  const dialog=this.dialog,s=await this.updater.state();if(this.dialog!==dialog||!dialog?.open||this.tab!=='toolbar')return;
  this.list.replaceChildren();const card=this.node('article','et-module-card et-toolbar-update-card'),icon=this.node('span','et-module-icon');icon.innerHTML=this.moduleIcon({});icon.setAttribute('aria-hidden','true');
  const copy=this.node('div','et-module-copy'),heading=this.node('div','et-module-name');heading.append(this.node('strong','','Typora 工具栏'),this.node('span','et-module-version','v'+s.currentVersion));copy.append(heading);
  const pending=['queued','waiting','installing'].includes(s.task?.state),prepared=s.stage&&s.stage.version===s.latest?.version&&s.available;
  const labels={queued:'请保存文档并退出 Typora',waiting:'等待 Typora 退出',installing:'正在安装…',complete:'已安装，重新打开 Typora 生效',canceled:'已取消等待',expired:'等待超时，请重试',failed:'安装未完成，请重试'};
  this.checkStatus.textContent=this.hostChecking?'正在检查更新…':s.error||labels[s.task?.state]||(s.available?'可更新至 v'+s.latest.version:'已是最新版本');
  this.checkStatus.classList.toggle('is-checking',!!this.hostChecking);
  if(s.task?.message)copy.append(this.node('p','et-module-warning',s.task.message));
  const actions=this.node('div','et-module-card-actions'),current=!this.hostChecking&&!s.error&&!!s.latest&&!s.available&&!pending;
  const check=this.button(current?'无需更新':this.hostChecking?'正在检查…':'检查更新',()=>this.checkToolbar(),current?'et-module-current':'');
  if(current||this.hostChecking){check.dataset.unavailable='true';check.disabled=true;}actions.append(check);
  if(pending){if(s.task.state!=='installing')actions.append(this.button('取消等待',()=>this.toolbarAction('cancel')));}
  else if(s.available)actions.append(this.button(prepared?'安装更新':'更新',()=>this.toolbarAction(prepared?'queue':'prepare'),'et-module-primary'));
  card.append(icon,copy,actions);this.list.append(card);
  const release=ETToolbarUpdater.notes(s);if(release.text){const notes=this.node('details','et-toolbar-release');notes.open=!!s.available;notes.append(this.node('summary','','v'+release.version+' 更新说明'));const changes=this.node('ul');for(const line of release.text.split('\n'))changes.append(this.node('li','',line));notes.append(changes);this.list.append(notes);}
  clearTimeout(this.hostTimer);if(pending){this.hostTimer=setTimeout(()=>{if(this.dialog===dialog&&dialog.open&&this.tab==='toolbar'&&!this.busy)void this.render().catch(e=>{this.status.textContent=e.message;});},1500);dialog.addEventListener('close',()=>clearTimeout(this.hostTimer),{once:true});}
 }

 async checkUpdates(){
  if(this.checking)return this.checking;
  this.checkMessage='正在检查更新…';if(this.tab!=='toolbar'){this.checkStatus.textContent=this.checkMessage;this.checkStatus.classList.add('is-checking');}
  this.checking=(async()=>{try{
   await this.store.ensureOfficialMarket({required:true});await this.store.refreshMarkets();const state=await this.store.state(),failed=state.markets.filter(m=>m.error);
   const updates=Object.values(state.installed).filter(r=>state.markets.some(m=>m.modules.some(v=>v.id===r.manifest.id&&(!r.source||v.source===r.source)&&this.store.compatible(v)&&ETFeatureStore.compare(v.version,r.manifest.version)>0))).length;
   this.checkMessage=failed.length?'部分来源未连接，已保留缓存':updates?'有 '+updates+' 个模块可更新':state.markets.length?'已是最新版本':'尚未添加市场来源';
  }catch(e){this.checkMessage='暂时无法检查更新';if(this.dialog?.open){this.status.textContent=e.message;this.status.dataset.error='true';}}
  finally{this.checking=null;await this.render();}})();return this.checking;
 }
 empty(title,description){const e=this.node('div','et-module-empty');e.append(this.node('strong','',title),this.node('p','',description));this.list.append(e);}
 async drawList(){this.list.replaceChildren();const s=this.state;if(!s)return;
  if(this.tab==='toolbar')return this.drawToolbarUpdate();
  let rows=this.tab==='installed'?Object.values(s.installed).map(r=>({...r.manifest,installed:r})):s.markets.flatMap(m=>m.modules.map(r=>({...r,sourceError:m.error,installed:s.installed[r.id]})));
   if(!rows.length){this.empty(this.tab==='installed'?'尚未安装功能模块':'尚无市场条目',this.tab==='installed'?'点击“本地安装”，或在“浏览市场”选择模块。':'正在读取官方市场，请稍后重新打开。');return;}
  for(const row of rows){const card=this.node('article','et-module-card'),icon=this.node('span','et-module-icon'),copy=this.node('div','et-module-copy'),heading=this.node('div','et-module-name'),name=this.node('strong','',row.name);icon.innerHTML=this.moduleIcon(row);icon.setAttribute('aria-hidden','true');name.title=row.name;const version=this.node('span','et-module-version','v'+row.version);version.title=(this.tab==='installed'?'已安装版本 ':'市场版本 ')+row.version;heading.append(name,version,this.helpButton(row));copy.append(heading);card.dataset.moduleId=row.id;card.oncontextmenu=e=>{e.preventDefault();this.detail(row);};if(row.installed?.error)copy.append(this.node('p','et-module-warning',row.installed.error));if(row.sourceError)copy.append(this.node('small','et-module-warning','来源不可用，正在显示缓存'));
   const controls=this.node('div','et-module-card-actions');
   if(this.tab==='installed'){const toggle=this.button('',async()=>{if(row.installed.enabled){await this.store.enable(row.id,false);try{await this.changed();}catch(e){await this.render();throw e;}}else if(row.installed.bundled){await this.store.enable(row.id,true);await this.changed();}else this.enableForm(row);},'et-module-toggle');toggle.setAttribute('role','switch');toggle.setAttribute('aria-checked',String(row.installed.enabled));toggle.setAttribute('aria-label',row.name);toggle.title=row.installed.enabled?'关闭 AI 及其工作区，保留数据和草稿':'启用 '+row.name;toggle.append(this.node('span','et-module-switch'),this.node('span','et-module-toggle-label',row.installed.enabled?'已开启':'已关闭'));controls.append(toggle);
     const uninstall=this.button('',()=>this.uninstallForm(row),'et-module-uninstall');uninstall.innerHTML=this.glyph('trash');uninstall.title='卸载模块';uninstall.setAttribute('aria-label','卸载 '+row.name);controls.append(uninstall);
   }else{const installed=row.installed?.manifest,canInstall=!installed||ETFeatureStore.compare(row.version,installed.version)>0,b=this.button(installed?'更新':'安装',()=>this.remote(row),'et-module-primary');if(!canInstall){b.dataset.unavailable='true';b.disabled=true;b.textContent='无需更新';b.className='et-module-current';b.title='已安装 v'+installed.version+'；市场版本 v'+row.version;}else if(!this.store.compatible(row)){b.dataset.unavailable='true';b.disabled=true;b.textContent='需升级工具栏';}controls.append(b);}
   card.append(icon,copy,controls);this.list.append(card);
  }
 }
 moduleIcon(row){if(row.icon==='ai-reading-assistant'||row.id==='ai-reading-assistant')return BUTTON_DEFINITIONS['ai-assistant'].icon;return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/></svg>';}
 glyph(name){const shapes={plus:'M12 5v14M5 12h14',folder:'M3 6h7l2 3h9v11H3Z',upload:'M12 16V3m-5 5 5-5 5 5M4 16v5h16v-5',trash:'M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7'};return '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="'+shapes[name]+'"/></svg>';}
 documentation(row){return this.state.documentation?.[row.id]||row.documentationUrl||this.state.markets.flatMap(m=>m.modules).find(m=>m.id===row.id&&m.documentationUrl)?.documentationUrl||'';}
 helpButton(row){const url=this.documentation(row),b=this.button('',()=>url?reqnode('electron').shell.openExternal(ETFeatureStore.documentationURL(url)):this.documentationForm(row),'et-module-help');b.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><circle cx="12" cy="12" r="8.5"/><path d="M9.5 9a2.5 2.5 0 0 1 5 .3c0 1.6-2.5 2-2.5 3.7M12 16.5h.01"/></svg>';b.title=url||'设置文档网址';b.setAttribute('aria-label',row.name+' 使用文档');b.oncontextmenu=e=>{e.preventDefault();e.stopPropagation();this.documentationForm(row);};return b;}
 documentationForm(row){const f=this.modal('文档网址'),input=this.node('input');input.type='url';input.placeholder='https://…';input.setAttribute('aria-label','文档网址');input.value=this.documentation(row);f.content.append(input,this.node('p','','点击问号打开文档；右键问号可修改网址。'));f.submit('保存',async()=>{await this.store.setDocumentation(row.id,input.value);await this.render();});input.focus();}
 modal(title){const d=this.node('dialog','et-module-prompt');d.setAttribute('aria-label',title);d.append(this.node('h3','',title));const content=this.node('div','et-module-prompt-content'),error=this.node('p','et-module-warning'),actions=this.node('div','et-module-prompt-actions');error.setAttribute('role','alert');const cancel=this.node('button','','取消');cancel.onclick=()=>d.close();actions.append(cancel);d.append(content,error,actions);this.dialog.append(d);d.addEventListener('close',()=>d.remove());d.addEventListener('keydown',e=>e.stopPropagation());d.showModal();return {d,content,error,actions,submit:(label,fn)=>{const b=this.node('button','et-module-primary',label);b.onclick=async()=>{b.disabled=true;try{await fn();d.close();}catch(e){error.textContent=e.message;}finally{b.disabled=false;}};actions.append(b);return b;}};}
 importForm(){
  const form=this.modal('本地安装'),input=this.node('input'),pathBox=this.node('div','et-module-path'),drop=this.node('button','et-module-drop'),folder=this.node('button','et-module-folder');let working=false;
  input.placeholder='模块 ZIP 或目录路径';input.setAttribute('aria-label','模块路径');drop.type=folder.type='button';drop.innerHTML=this.glyph('upload');drop.append(this.node('strong','','拖入模块 ZIP 或文件夹'),this.node('span','','或点击选择 ZIP 文件'));folder.innerHTML=this.glyph('folder');folder.title='选择模块文件夹';folder.setAttribute('aria-label','选择模块文件夹');pathBox.append(input,folder);form.content.append(drop,pathBox);
  const update=()=>{input.disabled=drop.disabled=folder.disabled=working;submit.disabled=working||!input.value.trim();drop.classList.toggle('has-file',!!input.value.trim());};
  const choose=async directory=>{if(working)return;working=true;update();try{const result=await JSBridge.invoke('dialog.showOpenDialog',{title:directory?'选择模块文件夹':'选择模块 ZIP',properties:[directory?'openDirectory':'openFile'],...(!directory?{filters:[{name:'功能模块 ZIP',extensions:['zip']}]}:{})});if(form.d.open&&result?.filePaths?.[0]){input.value=result.filePaths[0];form.error.textContent='';}}catch(e){if(form.d.open)form.error.textContent=e.message;}finally{working=false;if(form.d.open)update();}};
  drop.onclick=()=>choose(false);folder.onclick=()=>choose(true);input.oninput=()=>{form.error.textContent='';update();};
  const submit=form.submit('预览安装',async()=>{if(working||!input.value.trim())return;working=true;update();try{const preview=await this.store.preview(input.value.trim());if(!form.d.open){this.store.previews.delete(preview.token);return;}form.d.close();this.installForm(preview);}finally{working=false;if(form.d.open)update();}});
  const hasFiles=e=>[...(e.dataTransfer?.types||[])].includes('Files');
  const drag=e=>{if(!hasFiles(e))return;e.preventDefault();e.stopImmediatePropagation();e.dataTransfer.dropEffect=working?'none':'copy';drop.classList.toggle('is-dragging',!working);};
  const receive=e=>{if(!hasFiles(e))return;e.preventDefault();e.stopImmediatePropagation();drop.classList.remove('is-dragging');if(working)return;const files=[...(e.dataTransfer.files||[])];if(files.length!==1){form.error.textContent='一次请拖入一个模块 ZIP 或文件夹';return;}try{const file=reqnode('electron').webUtils?.getPathForFile?.(files[0])||files[0].path;if(!file)throw Error('无法取得路径，请点击选择文件');input.value=file;form.error.textContent='';update();}catch(error){form.error.textContent=error.message;}};
  document.addEventListener('dragover',drag,true);document.addEventListener('drop',receive,true);form.d.addEventListener('dragleave',e=>{if(!form.d.contains(e.relatedTarget))drop.classList.remove('is-dragging');});form.d.addEventListener('close',()=>{document.removeEventListener('dragover',drag,true);document.removeEventListener('drop',receive,true);},{once:true});input.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();if(!submit.disabled)submit.click();}};update();drop.focus();return form;
 }
 async remote(row){const dialog=this.dialog;this.status.textContent='正在下载并校验 '+row.name+'…';const p=await this.store.previewRemote(row.source,row.id);if(this.dialog!==dialog||!dialog?.open){this.store.previews.delete(p.token);return;}this.installForm(p);this.status.textContent='下载校验完成';}
 installForm(p){const existing=this.state?.installed?.[p.manifest.id],verb=existing?'更新':'安装',f=this.modal(verb+' '+p.manifest.name);f.d.classList.add('et-module-install-prompt');f.d.addEventListener('close',()=>this.store.previews.delete(p.token),{once:true});f.content.append(this.node('p','et-module-install-version',existing?'v'+existing.manifest.version+' → v'+p.manifest.version:'v'+p.manifest.version));if(!p.compatible)f.content.append(this.node('p','','需要工具栏 '+p.manifest.minHostVersion+' 或更高版本。'));if(p.compatible)f.submit(verb,async()=>{await this.store.install(p.token);this.tab='installed';await this.changed();this.status.textContent='已安装，待启用';});}
 enableForm(row){const f=this.modal('启用 '+row.name);f.content.append(this.node('p','','模块可运行本机代码，请确认来源可信。'));f.submit('信任并启用',async()=>{await this.store.enable(row.id,true);await this.changed();});}
 uninstallForm(row,parent){const f=this.modal('卸载 '+row.name);f.content.append(this.node('p','','卸载模块程序，保留对话、设置、项目文件和草稿。之后可重新安装。'));f.submit('卸载模块',async()=>{await this.store.enable(row.id,false);try{await this.runtime.reconcile();await this.store.uninstall(row.id);await this.changed();parent?.close();}catch(e){await this.render();throw e;}});}
 detail(row){const f=this.modal(row.name);f.content.append(this.node('p','',row.description),this.node('p','','模块 ID：'+row.id),this.node('p','','版本：'+row.version+' · 最低工具栏版本：'+row.minHostVersion),this.node('p','','作者：'+(row.author||'未提供')));const commands=[...this.runtime.commands.entries()].filter(([,c])=>c.moduleId===row.id);if(commands.length){f.content.append(this.node('h4','','模块命令'));for(const [key,c]of commands){const b=this.node('button','',c.name);b.onclick=()=>this.runtime.execute(key).catch(e=>f.error.textContent=e.message);f.content.append(b);}}if(row.installed){const b=this.node('button','','卸载模块');b.onclick=()=>this.uninstallForm(row,f.d);f.actions.append(b);}}
}
