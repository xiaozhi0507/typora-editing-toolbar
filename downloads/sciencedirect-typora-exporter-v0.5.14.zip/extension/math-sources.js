/* Runs read-only in the page's MAIN world. Never passes extension settings or credentials. */
(() => {
  async function readMathSources() {
    const sources=[],seen=new Set(),errors=[];let totalSourceLength=0;
    const mathJax=globalThis.MathJax;
    const signature=node=>{const html=node.outerHTML;let hash=2166136261;for(let i=0;i<html.length;i++)hash=Math.imul(hash^html.charCodeAt(i),16777619);return html.length+':'+(hash>>>0).toString(16);};
    const add=(node,source,type,display)=>{
      if(!node?.isConnected||node.ownerDocument!==document||seen.has(node)||typeof source!=='string'||!source.trim())return;
      if(source.length>200000||sources.length>=2000||totalSourceLength+source.length>5000000)throw Error('公式源超出单次读取限制');
      if(!node.matches('.MathJax,.MathJax_Display,.MathJax_SVG,.MathJax_SVG_Display,.MathJax_CHTML,.MathJax_CHTML_Display,mjx-container'))return;
      const path=[];let current=node;
      while(current!==document.documentElement){const parent=current.parentElement;if(!parent)return;path.unshift(Array.prototype.indexOf.call(parent.children,current));current=parent;}
      sources.push({path,tag:node.localName,signature:signature(node),source,type,display:!!display});seen.add(node);totalSourceLength+=source.length;
    };
    if(mathJax?.startup?.promise){
      let timer;
      try{await Promise.race([mathJax.startup.promise,new Promise(resolve=>{timer=setTimeout(resolve,2500);})]);}catch{errors.push('MathJax 初始化未完成');}finally{clearTimeout(timer);}
    }
    try{
      const mathDocument=mathJax?.startup?.document;
      const items=typeof mathDocument?.getMathItemsWithin==='function'?mathDocument.getMathItemsWithin(document.body):mathDocument?.math;
      if(items)for(const item of items){
        const input=String(item.inputJax?.name||'');
        if(/^(?:MathML|MML)$/i.test(input))add(item.typesetRoot,item.math,'MathML',item.display);
        else if(/^TeX$/i.test(input))add(item.typesetRoot,item.math,'TeX',item.display);
        else if(item.root&&typeof mathJax.startup.toMML==='function')add(item.typesetRoot,mathJax.startup.toMML(item.root),'MathML',item.display);
      }
    }catch{errors.push('MathJax 运行时公式读取失败');}
    try{
      if(typeof mathJax?.Hub?.getAllJax==='function')for(const item of mathJax.Hub.getAllJax()){
        const source=typeof item.SourceElement==='function'?item.SourceElement():document.getElementById(item.inputID);
        const node=document.getElementById(item.inputID+'-Frame');
        const input=String(item.inputJax||'');
        const display=/mode\s*=\s*display/i.test(source?.getAttribute('type')||'')||item.root?.Get?.('display')==='block';
        if(/MathML|MML/i.test(input))add(node,item.originalText,'MathML',display);
        else if(/TeX/i.test(input))add(node,item.originalText,'TeX',display);
        else if(typeof item.root?.toMathML==='function')add(node,item.root.toMathML(),'MathML',display);
      }
    }catch{errors.push('MathJax 2 运行时公式读取失败');}
    return {url:location.origin+location.pathname,sources,errors};
  }
  globalThis.SDMathSources={read:readMathSources};
  if(typeof module!=='undefined')module.exports=globalThis.SDMathSources;
})();
