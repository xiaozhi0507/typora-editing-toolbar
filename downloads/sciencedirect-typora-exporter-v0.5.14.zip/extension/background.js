'use strict';
importScripts('settings.js','math-sources.js','updates.js','update-worker.js');
// The worker owns downloads and per-tab state; the hidden document owns ZIP blobs.
const jobs=new Map(),locks=new Map(),captures=new Set(),offscreenURL=chrome.runtime.getURL('offscreen.html');
const terminal=j=>['complete','error','canceled'].includes(j.phase);
const articleURL=url=>{try{const u=new URL(url);return u.origin==='https://www.sciencedirect.com'&&/^\/science\/article\/pii\/[^/]+$/.test(u.pathname)?u.origin+u.pathname:null;}catch{return null;}};
let creating,storageQueue=Promise.resolve();
const ready=chrome.storage.session.get('jobs').then(data=>{for(const j of data.jobs||[])jobs.set(j.id,j);});
function persist(){const recent=new Set([...jobs.values()].filter(terminal).slice(-40));const data=[...jobs.values()].filter(j=>!terminal(j)||recent.has(j)).map(j=>({...j}));storageQueue=storageQueue.catch(()=>{}).then(()=>chrome.storage.session.set({jobs:data}));return storageQueue;}
function current(tabId){return [...jobs.values()].filter(j=>j.tabId===tabId).at(-1);}
async function display(job,reveal=false){
  if(current(job.tabId)?.id!==job.id)return;
  const tab=await chrome.tabs.get(job.tabId).catch(()=>null);if(!tab||articleURL(tab.url)!==job.url)return;
  const text=job.phase==='complete'?'✓':job.phase==='error'||job.phase==='canceled'?'!':'…';
  await Promise.allSettled([
    chrome.tabs.sendMessage(job.tabId,{target:'connector',type:'state',job,reveal},{documentId:job.documentId}),
    chrome.action.setBadgeText({tabId:job.tabId,text}),
    chrome.action.setBadgeBackgroundColor({tabId:job.tabId,color:job.phase==='error'?'#ad3e35':'#28766a'}),
    chrome.action.setTitle({tabId:job.tabId,title:'ScienceDirect → Typora：'+job.message})
  ]);
}
async function update(job,changes){Object.assign(job,changes,{revision:(job.revision||0)+1,updated:Date.now()});const snapshot={...job};await persist();await display(snapshot);}
async function ensureOffscreen(){
  if(creating)return creating;
  creating=(async()=>{const contexts=await chrome.runtime.getContexts({contextTypes:['OFFSCREEN_DOCUMENT'],documentUrls:[offscreenURL]});if(!contexts.length)await chrome.offscreen.createDocument({url:'offscreen.html',reasons:['BLOBS'],justification:'Build the article ZIP and retain its Blob until the browser download finishes, without opening a tab.'});})();
  try{await creating;}finally{creating=null;}
}
async function release(job){await chrome.runtime.sendMessage({target:'offscreen',type:'release',id:job.id}).catch(()=>{});}
async function fail(job,message){if(terminal(job))return;await update(job,{phase:'error',message:'保存未完成：'+message});await release(job);}
async function reconcile(job){
  if(terminal(job))return;
  if(job.phase==='choosing')return;
  if(job.downloadId!==undefined){const d=(await chrome.downloads.search({id:job.downloadId}))[0];if(d?.state==='complete')return complete(job);if(!d||d.state==='interrupted')return fail(job,'下载已取消或中断，请重试。');return;}
  if(captures.has(job.id))return;
  const state=await chrome.runtime.sendMessage({target:'offscreen',type:'status',id:job.id}).catch(()=>null);
  if(!state?.exists)await fail(job,'后台任务已中断，请重试。');
}
async function complete(job){if(terminal(job))return;await update(job,{phase:'complete',message:'已保存到下载文件夹',progress:1});await release(job);}
async function preferences(){const data=await chrome.storage.local.get(['settings','connectorToken']);return {settings:{...SDSettings.defaults,...data.settings},token:data.connectorToken};}
async function cancelChangedDestination(job){
  if(terminal(job)||['committing','saving-directory'].includes(job.phase))return;
  await update(job,{phase:'canceled',settingsChanged:true,message:'保存方式已改变，请重新点击保存。',collections:undefined});
  if(job.downloadId!==undefined)await chrome.downloads.cancel(job.downloadId).catch(()=>{});
  await release(job);
}
async function startCapture(job){if(terminal(job))return;await SDSettings.checkDestination(job.destination);if(terminal(job))return;await update(job,{phase:'extracting',message:'正在读取论文…',collections:undefined});if(terminal(job))return;captures.add(job.id);capture(job).catch(error=>fail(job,error.message)).finally(()=>captures.delete(job.id));}
async function capture(job){
  const target={tabId:job.tabId,documentIds:[job.documentId]};
  await chrome.scripting.executeScript({target,files:['extractor.js']});
  const [prepared]=await chrome.scripting.executeScript({target,func:async()=>{try{await globalThis.SDTypora.prepare();return {};}catch(error){return {captureError:error.message};}}});
  if(prepared?.result?.captureError)throw Error(prepared.result.captureError);
  // Page-owned MathJax sources are not visible to an isolated content script.
  const [mathFrame]=await chrome.scripting.executeScript({target,world:'MAIN',func:SDMathSources.read});
  const [frame]=await chrome.scripting.executeScript({target,args:[mathFrame?.result||null],func:mathSources=>{try{return globalThis.SDTypora.extract(document,location.href,mathSources);}catch(error){return {captureError:error.message};}}});
  const extraction=frame?.result;if(extraction?.captureError)throw Error(extraction.captureError);if(!extraction||articleURL(extraction.report.source_url)!==job.url)throw Error('论文页面已改变，请在目标论文页重新保存。');
  if(terminal(job))return;
  await update(job,{title:extraction.index.documents[0].metadata.title_original,phase:'assets',message:'正在保存图片和补充材料…'});
  await ensureOffscreen();if(terminal(job))return;
  await SDSettings.checkDestination(job.destination);if(terminal(job))return;
  const credentials=job.destination.mode==='library'?{token:(await preferences()).token}:{};
  const answer=await chrome.runtime.sendMessage({target:'offscreen',type:'build',id:job.id,extraction,destination:job.destination,...credentials});
  if(!answer?.accepted)throw Error(answer?.error||'后台打包未启动。');
}
async function activate(tab,force=false,selection=null){
  await ready;if(locks.has(tab.id))return locks.get(tab.id);
  const task=(async()=>{
    const url=articleURL(tab.url);
    if(!url){await chrome.action.setBadgeText({tabId:tab.id,text:'!'});await chrome.action.setTitle({tabId:tab.id,title:'请在 ScienceDirect 论文详情页点击保存'});return;}
    const [frame]=await chrome.scripting.executeScript({target:{tabId:tab.id},files:['connector.js']});
    const {settings,token}=await preferences();
    let job=current(tab.id);
    const destinationChanged=job?.destination&&job.destination.mode!==SDSettings.destinationMode(settings);
    if(destinationChanged)await cancelChangedDestination(job);
    if(job?.url===url&&!job.settingsChanged&&!(destinationChanged&&terminal(job))&&job.phase!=='complete'&&(!force||!terminal(job))){job.documentId=frame.documentId;await reconcile(job);await display(job,true);return;}
    job={id:crypto.randomUUID(),tabId:tab.id,documentId:frame.documentId,url,title:String(frame.result||'当前论文').trim().slice(0,500),phase:'extracting',message:'正在读取论文…',revision:0,updated:Date.now()};jobs.set(job.id,job);
    await update(job,{});await display(job,true);
    if(terminal(job))return;
    if(settings.mode==='library'){
      if(!token)throw Error('请右键插件图标，在“选项”中连接 Typora。');
      const info=await SDSettings.request('/library',{token});
      if(terminal(job))return;
      const direct=settings.collectionMode==='direct';
      if(direct&&settings.libraryId!==info.libraryId)throw Error('知识库已切换，请在选项中重新设置默认分类。');
      if(direct&&settings.defaultCollection&&!info.collections.some(c=>c.id===settings.defaultCollection))throw Error('默认分类已不存在，请在选项中重新选择。');
      job.destination={mode:'library',libraryId:info.libraryId,collectionId:direct?(settings.defaultCollection||''):(info.collections.some(c=>c.id===settings.lastCollection)&&(!settings.libraryId||settings.libraryId===info.libraryId)?settings.lastCollection:''),root:info.root};
      job.savePrompt={choosing:!direct,collections:info.collections,message:direct?'保存到 '+(info.collections.find(c=>c.id===settings.defaultCollection)?.name||'我的文库'):'选择保存到的文库分类'};
      if(direct)await startCapture(job);
      else if(selection){
        if(selection.libraryId!==info.libraryId)throw Error('知识库已切换，请重新选择分类。');
        if(selection.collectionId&&!info.collections.some(c=>c.id===selection.collectionId))throw Error('所选分类已不存在，请重新选择分类。');
        job.destination.collectionId=selection.collectionId;
        await chrome.storage.local.set({settings:{...settings,lastCollection:selection.collectionId}});await startCapture(job);
      }
      else await update(job,{phase:'choosing',message:'选择保存到的文库分类',collections:info.collections});
    }else{job.destination={mode:settings.customDirectory?'directory':'zip',directoryName:settings.directoryName,directoryId:settings.directoryId};job.savePrompt={choosing:false,message:'保存当前论文为 ZIP 压缩包'};await startCapture(job);}
  })();locks.set(tab.id,task);try{await task;}finally{locks.delete(tab.id);}
}
chrome.action.onClicked.addListener(tab=>{activate(tab).catch(async error=>{const j=current(tab.id);if(j&&!terminal(j))await fail(j,error.message);else await chrome.action.setTitle({tabId:tab.id,title:'保存未完成：'+error.message}).catch(()=>{});});});
chrome.runtime.onMessage.addListener((message,sender,respond)=>{
  if(message?.target!=='worker'||sender.id!==chrome.runtime.id)return;
  const fromOffscreen=sender.url===offscreenURL&&!sender.tab;
  const fromPage=sender.tab&&sender.frameId===0&&articleURL(sender.url);
  if(!fromOffscreen&&!fromPage)return;
  (async()=>{
    await ready;const job=jobs.get(message.id);
    if(fromPage){
      if(!job||job.tabId!==sender.tab.id||job.documentId!==sender.documentId||current(job.tabId)?.id!==job.id)return;
      if(message.type==='retry')await activate(await chrome.tabs.get(job.tabId),true);
      if(message.type==='options')await chrome.runtime.openOptionsPage();
      if(message.type==='select'&&job.phase==='complete'){
        const selection=job.savePrompt?.choosing?{collectionId:typeof message.collectionId==='string'?message.collectionId:'',libraryId:job.destination.libraryId}:null;
        await activate(await chrome.tabs.get(job.tabId),true,selection);
      }
      if(message.type==='select'&&job.phase==='choosing'){
        const {settings:latest}=await preferences();
        if(job.destination.mode!==SDSettings.destinationMode(latest)){await cancelChangedDestination(job);await activate(await chrome.tabs.get(job.tabId),true);return {ok:true};}
        const value=typeof message.collectionId==='string'?message.collectionId:'';
        if(value&&!job.collections.some(c=>c.id===value))throw Error('请重新选择分类');
        job.destination.collectionId=value;await update(job,{phase:'extracting',message:'正在读取论文…'});const {settings}=await preferences();await chrome.storage.local.set({settings:{...settings,lastCollection:value}});await startCapture(job);
      }
      if(message.type==='show'&&job.phase==='complete'&&job.downloadId!==undefined)await chrome.downloads.show(job.downloadId);
      if(message.type==='cancel'&&!terminal(job)&&!['committing','saving-directory'].includes(job.phase)){await update(job,{phase:'canceled',message:'已取消保存'});if(job.downloadId!==undefined)await chrome.downloads.cancel(job.downloadId).catch(()=>{});await release(job);}
      return {ok:true};
    }
    if(!job||terminal(job))return {discard:true};
    if(message.type==='check-destination'){await SDSettings.checkDestination(job.destination);return {ok:true};}
    if(message.type==='progress'&&job.downloadId===undefined)await update(job,{phase:message.phase,message:message.message,progress:message.progress});
    if(message.type==='error')await fail(job,message.error);
    if(message.type==='heartbeat')await reconcile(job);
    if(message.type==='saved'){
      await update(job,{phase:'complete',message:message.message,summary:message.summary,result:message.result,progress:1});await release(job);
    }
    if(message.type==='download'&&job.downloadId===undefined){
      if(typeof message.url!=='string'||!message.url.startsWith('blob:'+chrome.runtime.getURL('')))throw Error('无效的下载资源');
      if(job.phase==='downloading')return {ok:true};
      await update(job,{phase:'downloading',message:'正在保存到下载文件夹…',summary:message.summary,notes:message.notes,progress:1});
      if(terminal(job))return {discard:true};
      const stamp=new Date().toISOString().replace(/[:.]/g,'-'),name=String(message.stem).replace(/[<>:"/\\|?*\x00-\x1f]/g,' ').slice(0,130);
      const id=await chrome.downloads.download({url:message.url,filename:'ScienceDirect-Typora/'+name+'_'+stamp+'.zip',saveAs:false,conflictAction:'uniquify'});
      job.downloadId=id;await persist();if(job.phase==='canceled'){await chrome.downloads.cancel(id).catch(()=>{});await release(job);}else await reconcile(job);
    }
    return {ok:true};
  })().then(value=>respond(value||{ok:false})).catch(async error=>{const j=fromPage?current(sender.tab.id):jobs.get(message.id);if(j&&!terminal(j)&&message.type!=='show'&&message.type!=='options')await fail(j,error.message);respond({error:error.message});});
  return true;
});
chrome.downloads.onChanged.addListener(delta=>{if(!delta.state)return;ready.then(async()=>{const j=[...jobs.values()].find(j=>j.downloadId===delta.id);if(!j||terminal(j))return;if(delta.state.current==='complete')await complete(j);else if(delta.state.current==='interrupted')await fail(j,'下载已取消或中断，请重试。');}).catch(()=>{});});
chrome.tabs.onUpdated.addListener((tabId,change)=>{if(change.status==='loading'){chrome.action.setBadgeText({tabId,text:''}).catch(()=>{});chrome.action.setTitle({tabId,title:'保存当前论文到 Typora'}).catch(()=>{});}});
chrome.storage.onChanged.addListener((changes,area)=>{
  if(area!=='local'||!changes.settings)return;
  ready.then(async()=>{
    const {settings}=await preferences(),mode=SDSettings.destinationMode(settings);
    for(const job of jobs.values())if(job.destination&&job.destination.mode!==mode)await cancelChangedDestination(job);
  }).catch(()=>{});
});
ready.then(()=>{for(const j of jobs.values())if(!terminal(j))reconcile(j).catch(()=>{});});
