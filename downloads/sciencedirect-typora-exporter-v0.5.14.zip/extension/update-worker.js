'use strict';
// Only the extension's own settings page may trigger downloads or change preferences.
if(chrome.runtime.onInstalled){
 const updater=new SDUpdates();
 chrome.runtime.onMessage.addListener((message,sender,respond)=>{
  if(message?.target!=='extension-updates'||sender.id!==chrome.runtime.id||sender.url!==chrome.runtime.getURL('options.html'))return;
  const actions={state:()=>updater.view(),check:()=>updater.check(message.force===true),auto:()=>updater.setAuto(message.enabled),download:()=>updater.download(),native:()=>updater.nativeCheck()};
  if(!Object.hasOwn(actions,message.type))return;
  actions[message.type]().then(value=>respond({ok:true,value}),error=>respond({ok:false,error:error.message}));return true;
 });
 const startup=()=>updater.schedule().then(()=>updater.check()).catch(()=>{});
 chrome.runtime.onInstalled.addListener(startup);chrome.runtime.onStartup.addListener(startup);
 chrome.alarms?.onAlarm.addListener(alarm=>{if(alarm.name===SDUpdates.alarm)void updater.check().catch(()=>{});});
 // Store-installed extensions retain the browser's normal automatic-update lifecycle.
}
