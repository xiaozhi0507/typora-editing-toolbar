/* Shared by the extension and verification runner. No dependencies. */
(() => {
  'use strict';
  const encoder=new TextEncoder();
  const bytes=x=>typeof x==='string'?encoder.encode(x):new Uint8Array(x);
  const safePath=p=>typeof p==='string'&&p.length>0&&!/^[\\/]|[\\:\x00-\x1f]/.test(p)&&p.split('/').every(x=>x&&x!=='.'&&x!=='..');
  const libraryPath=p=>{
    if(!safePath(p)||p.length>230||/[<>"|?*]/.test(p))return false;
    const parts=p.split('/');if(parts.some(x=>/[. ]$/.test(x)||/^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(x)))return false;
    return parts.length===1?/\.md$/i.test(p):parts[0]==='_xref'?/\.json$/i.test(p):parts[0]==='_assets'&&/\.(?:jpe?g|png|gif|webp|svg|pdf|zip|docx?|xlsx?|txt|csv)$/i.test(p);
  };
  async function sha256(data){return [...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes(data)))].map(n=>n.toString(16).padStart(2,'0')).join('');}
  const crcTable=Uint32Array.from({length:256},(_,n)=>{for(let i=0;i<8;i++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
  const crc32=b=>{let c=0xffffffff;for(const n of b)c=crcTable[(c^n)&255]^(c>>>8);return (c^0xffffffff)>>>0;};
  function zip(files){
    if(files.length>65535)throw Error('文件数量超出 ZIP 限制。');
    const chunks=[],central=[],names=new Set();let offset=0,centralLength=0;
    const now=new Date(),time=(now.getHours()<<11)|(now.getMinutes()<<5)|(now.getSeconds()>>1),date=((Math.max(1980,now.getFullYear())-1980)<<9)|((now.getMonth()+1)<<5)|now.getDate();
    for(const file of files){
      if(!safePath(file.path)||names.has(file.path))throw Error('无效或重复的包内路径：'+file.path);names.add(file.path);
      const name=encoder.encode(file.path),data=bytes(file.data),crc=crc32(data);
      if(name.length>65535||offset+data.length>0xffffffff)throw Error('导出包过大。');
      const local=new Uint8Array(30+name.length),l=new DataView(local.buffer);
      l.setUint32(0,0x04034b50,true);l.setUint16(4,20,true);l.setUint16(6,0x800,true);l.setUint16(10,time,true);l.setUint16(12,date,true);l.setUint32(14,crc,true);l.setUint32(18,data.length,true);l.setUint32(22,data.length,true);l.setUint16(26,name.length,true);local.set(name,30);
      const cent=new Uint8Array(46+name.length),c=new DataView(cent.buffer);
      c.setUint32(0,0x02014b50,true);c.setUint16(4,20,true);c.setUint16(6,20,true);c.setUint16(8,0x800,true);c.setUint16(12,time,true);c.setUint16(14,date,true);c.setUint32(16,crc,true);c.setUint32(20,data.length,true);c.setUint32(24,data.length,true);c.setUint16(28,name.length,true);c.setUint32(42,offset,true);cent.set(name,46);
      chunks.push(local,data);central.push(cent);offset+=local.length+data.length;centralLength+=cent.length;
    }
    const end=new Uint8Array(22),e=new DataView(end.buffer);e.setUint32(0,0x06054b50,true);e.setUint16(8,files.length,true);e.setUint16(10,files.length,true);e.setUint32(12,centralLength,true);e.setUint32(16,offset,true);
    return new Blob([...chunks,...central,end],{type:'application/zip'});
  }
  function validateAsset(data,path,mime=''){
    const b=bytes(data),start=new TextDecoder().decode(b.slice(0,200)),ext=path.split('.').pop().toLowerCase();
    if(b.length<16||/text\/html/i.test(mime)||/^\s*(?:<!doctype html|<html)/i.test(start))throw Error('返回的是空文件或网页，未取得资源');
    let valid=true;
    if(/jpe?g/.test(ext))valid=b[0]===255&&b[1]===216&&b[2]===255;
    else if(ext==='png')valid=b[0]===137&&start.slice(1,4)==='PNG';
    else if(ext==='gif')valid=start.startsWith('GIF8');
    else if(ext==='webp')valid=start.startsWith('RIFF')&&start.slice(8,12)==='WEBP';
    else if(ext==='pdf')valid=start.startsWith('%PDF-');
    else if(['zip','docx','xlsx'].includes(ext))valid=b[0]===80&&b[1]===75;
    // Word/Excel 97-2003 use an OLE compound file, not the ZIP container of OOXML.
    // This is a file-signature check only; preserve the original bytes without opening Office.
    else if(['doc','xls'].includes(ext))valid=b.length>=512&&[0xd0,0xcf,0x11,0xe0,0xa1,0xb1,0x1a,0xe1].every((n,i)=>b[i]===n);
    else if(ext==='svg'){const svg=new TextDecoder().decode(b);valid=/<svg\b/i.test(svg)&&!/<(?:script|foreignObject)\b|\bon\w+\s*=|(?:href|src)\s*=\s*["'](?:https?:|javascript:|data:)/i.test(svg);}
    if(!valid)throw Error('文件内容与格式不符：'+ext);
    return b;
  }
  async function fetchAsset(asset,fetcher=fetch){
    const failures=[];
    for(let i=0;i<asset.urls.length;i++){
      const url=asset.urls[i];if(!/^https:\/\/(?:ars\.els-cdn\.com|www\.sciencedirect\.com)\//.test(url))throw Error('资源域名不受支持。');
      const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),30000);
      try{
        const response=await fetcher(url,{credentials:'omit',signal:controller.signal,redirect:'follow'});
        if(!response.ok)throw Error('HTTP '+response.status);
        if(response.url&&!/^https:\/\/(?:ars\.els-cdn\.com|www\.sciencedirect\.com)\//.test(response.url))throw Error('资源跳转到了未知域名');
        if(Number(response.headers.get('content-length'))>50*1024*1024)throw Error('单个资源超过 50 MB');
        const data=validateAsset(await response.arrayBuffer(),asset.path,response.headers.get('content-type'));
        if(data.length>50*1024*1024)throw Error('单个资源超过 50 MB');
        return {data,url,fallback:i>0,sha256:await sha256(data)};
      }catch(error){failures.push(error.message);}finally{clearTimeout(timer);}
    }
    throw Error(asset.path+'：'+failures.join('；'));
  }
  async function build(extraction,{fetcher=fetch,onProgress=()=>{}}={}){
    const result=JSON.parse(JSON.stringify(extraction)),files=[],resourceReport=[];let total=0;
    if(!safePath(result.filename)||!safePath('_xref/'+result.stem+'/xref-index.json'))throw Error('导出文件名无效。');
    const paths=[result.filename,'_xref/'+result.stem+'/xref-index.json','_xref/'+result.stem+'/export-report.json',...result.assets.map(a=>a.path)],seen=new Set();
    if(paths.length>1000)throw Error('论文包文件数量超过 1000 个。');
    for(const path of paths){
      if(!libraryPath(path))throw Error('导出文件路径或格式不受支持：'+path+'；请更新抓取扩展或检查原网页资源');
      if(seen.has(path.toLowerCase()))throw Error('导出文件路径重复：'+path);seen.add(path.toLowerCase());
    }
    for(const [i,asset] of result.assets.entries()){
      if(!safePath(asset.path)||!asset.path.startsWith('_assets/'))throw Error('资源路径无效。');
      onProgress({phase:'assets',current:i,total:result.assets.length,path:asset.path});
      const downloaded=await fetchAsset(asset,fetcher);total+=downloaded.data.length;if(total>250*1024*1024)throw Error('资源总量超过 250 MB。');
      files.push({path:asset.path,data:downloaded.data});resourceReport.push({path:asset.path,url:downloaded.url,bytes:downloaded.data.length,sha256:downloaded.sha256,fallback:downloaded.fallback});
      if(downloaded.fallback)result.report.warnings.push('高分辨率资源不可用，已使用原网页图片：'+asset.path);
    }
    result.index.documents[0].sha256=await sha256(result.markdown);
    files.push({path:result.filename,data:result.markdown},{path:'_xref/'+result.stem+'/xref-index.json',data:JSON.stringify(result.index,null,2)+'\n'});
    result.report={...result.report,exporter_version:result.version,status:result.report.warnings.length?'exported_with_notes':'exported',downloaded_assets:resourceReport.length,resources:resourceReport,markdown_sha256:result.index.documents[0].sha256,completed_at:new Date().toISOString()};
    files.push({path:'_xref/'+result.stem+'/export-report.json',data:JSON.stringify(result.report,null,2)+'\n'});
    onProgress({phase:'package',current:result.assets.length,total:result.assets.length});
    return {files,blob:zip(files),report:result.report,filename:result.filename,stem:result.stem};
  }
  globalThis.SDPackage={zip,sha256,validateAsset,fetchAsset,build};
  if(typeof module!=='undefined')module.exports=globalThis.SDPackage;
})();
