(() => {
  'use strict';
  const paperTitle=()=>document.querySelector('meta[name="citation_title"]')?.content||document.querySelector('h1')?.textContent||'当前论文';
  if(globalThis.SDConnector)return paperTitle();
  let host,root,state,hidden=false;
  function create(){
    host=document.createElement('div');host.id='sd-typora-connector';
    host.style.cssText='all:initial!important;position:fixed!important;top:18px!important;right:18px!important;z-index:2147483647!important;width:min(350px,calc(100vw - 28px))!important;';
    root=host.attachShadow({mode:'open'});const style=document.createElement('style');style.textContent=`
      :host{color-scheme:light}*{box-sizing:border-box}.panel{font:13px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",sans-serif;color:#27342f;background:#fff;border:1px solid #d9e1dc;border-radius:10px;box-shadow:0 6px 28px #132c3024;overflow:hidden}header{display:flex;align-items:center;gap:9px;padding:12px 14px;border-bottom:1px solid #ecf0ed;font-weight:600}header .brand{color:#28766a;font-size:17px}header span:nth-child(2){flex:1}button{font:inherit;cursor:pointer;border:0;border-radius:5px;background:none;color:inherit;padding:4px 7px}button:hover{background:#edf3ef}button:focus-visible{outline:2px solid #28766a;outline-offset:2px}.close{font-size:20px;line-height:20px;color:#69756e}.content{padding:13px 15px 14px}.title{font-size:13px;font-weight:600;line-height:1.5;overflow-wrap:anywhere;margin:0 0 9px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.status{color:#54655a;margin:0;overflow-wrap:anywhere}.error .status{color:#a63d32}progress{display:block;width:100%;height:4px;border:0;margin:12px 0 4px;accent-color:#28766a}.summary{margin:7px 0 0;color:#69756e;font-size:12px}footer{display:flex;gap:8px;justify-content:flex-end;margin-top:12px}footer .primary{background:#28766a;color:white;padding:5px 11px}select{display:block;width:100%;margin:12px 0 0;font:inherit;padding:7px;border:1px solid #c4d3ca;border-radius:5px;background:#fff;color:#27342f;color-scheme:light}option{background:#fff;color:#27342f}select:focus-visible{outline:2px solid #93bdb0;outline-offset:2px}[hidden]{display:none!important}@media(prefers-color-scheme:dark){:host{color-scheme:dark}select{color-scheme:dark;background:#26332c;border-color:#63776b;color:#e8efeb}option{background:#26332c;color:#e8efeb}footer .primary{background:#80c9b2;color:#142b22}.panel{background:#222a26;color:#e3ebe6;border-color:#48564d}header{border-color:#3c4840}.status,.summary,.close{color:#b2c1b7}button:hover{background:#3b4940}.error .status{color:#ffab9e}}
    `;
    const panel=document.createElement('section');panel.className='panel';panel.setAttribute('aria-label','保存到 Typora');
    panel.innerHTML='<header><span class="brand" aria-hidden="true">▤</span><span>保存到 Typora</span><button class="close" aria-label="关闭保存提示" title="关闭提示，后台继续保存">×</button></header><div class="content"><p class="title"></p><p class="status" role="status" aria-live="polite"></p><progress aria-label="保存进度"></progress><p class="summary" hidden></p><select class="collections" aria-label="保存到文库分类" hidden></select><footer><button class="options">选项</button><button class="select primary" hidden>保存</button><button class="cancel">取消</button><button class="retry">重试</button><button class="show primary">查看文件</button></footer></div>';
    root.append(style,panel);document.documentElement.append(host);
    root.querySelector('.close').addEventListener('click',e=>{if(!e.isTrusted)return;hidden=true;host.style.setProperty('display','none','important');});
    for(const type of ['retry','show','cancel','options','select'])root.querySelector('.'+type).addEventListener('click',async e=>{if(!e.isTrusted||!state)return;const button=e.currentTarget;button.disabled=true;try{const r=await chrome.runtime.sendMessage({target:'worker',type,id:state.id,collectionId:root.querySelector('.collections').value});if(r?.error)root.querySelector('.status').textContent=r.error;}catch{root.querySelector('.status').textContent='扩展已更新，请刷新论文页后重试。';}finally{button.disabled=false;}});
  }
  function render(job,reveal){
    if(state?.id===job.id&&state.revision>job.revision)return;
    const sameJob=state?.id===job.id;
    if(state?.id!==job.id||reveal)hidden=false;state=job;if(!host?.isConnected)create();host.style.setProperty('display',hidden?'none':'block','important');
    const q=s=>root.querySelector(s),done=job.phase==='complete',failed=['error','canceled'].includes(job.phase),choosing=job.phase==='choosing'||done&&job.savePrompt?.choosing,busy=!done&&!failed;
    q('.panel').classList.toggle('error',failed);q('.title').textContent=job.title;q('.status').textContent=done?(job.savePrompt?.message||'保存当前论文'):job.message;
    q('progress').hidden=!busy||choosing;if(Number.isFinite(job.progress)){q('progress').value=job.progress;q('progress').max=1;}else q('progress').removeAttribute('value');
    q('.summary').textContent=job.summary||'';q('.summary').hidden=done||!job.summary;
    q('.cancel').hidden=!busy||['committing','saving-directory'].includes(job.phase);q('.retry').hidden=!failed;q('.retry').textContent='重试';q('.show').hidden=true;q('.options').hidden=!failed;
    q('.select').hidden=!choosing&&!done;q('.collections').hidden=!choosing;
    if(choosing){const select=q('.collections'),previous=sameJob&&!select.hidden?select.value:job.destination.collectionId||'';select.replaceChildren(new Option('我的文库',''));const add=(parent,depth)=>{for(const c of (job.collections||job.savePrompt?.collections||[]).filter(c=>(c.parentId||'')===parent)){select.add(new Option('　'.repeat(depth)+c.name,c.id));add(c.id,depth+1);}};add('',1);select.value=[...select.options].some(o=>o.value===previous)?previous:'';}

  }
  chrome.runtime.onMessage.addListener((message,sender)=>{if(sender.id===chrome.runtime.id&&message?.target==='connector'&&message.type==='state')render(message.job,message.reveal);});
  globalThis.SDConnector={};return paperTitle();
})();
