'use strict';
const $=s=>document.querySelector(s);let settings,token,libraryInfo,busy=false;
const status=(text,error=false)=>{$('#status').textContent=text;$('#status').classList.toggle('error',error);};
function connected(value){$('#connection').textContent=value?'已连接':'未连接';$('#connection').classList.toggle('connected',value);$('#connect').hidden=value;$('#disconnect').hidden=!token;}
function sections(){
  $('#zip').hidden=$('input[name=mode]:checked')?.value!=='zip';$('#library').hidden=!$('#zip').hidden;
  $('#directory').textContent=$('#custom').checked?(settings.directoryName||'尚未选择文件夹'):'浏览器下载文件夹 / ScienceDirect-Typora';
  $('#default-collection').hidden=$('input[name=collectionMode]:checked')?.value!=='direct';
}
function collections(data,selected=''){
  const select=$('#collection');select.replaceChildren(new Option('我的文库',''));
  const add=(parent,depth)=>{for(const c of data.collections.filter(c=>(c.parentId||'')===parent)){select.add(new Option('　'.repeat(depth)+c.name,c.id));add(c.id,depth+1);}};add('',1);
  if(selected&&![...select.options].some(o=>o.value===selected)){const missing=new Option('原分类已不存在，请重新选择',selected);missing.disabled=true;select.add(missing);}
  select.value=selected;
}
function showLibrary(info,preserve=false){
  const before=libraryInfo?.libraryId||settings.libraryId,changed=!!before&&before!==info.libraryId;
  const selected=changed?'':preserve?$('#collection').value:settings.defaultCollection;
  if(changed){settings.defaultCollection='';settings.lastCollection='';$('input[name=collectionMode][value=ask]').checked=true;}
  libraryInfo=info;connected(true);$('#root').textContent=info.root;$('#root').title=info.root;collections(info,selected);sections();return info;
}
async function check(preserve=false){
  if(!token)throw Error('请先连接 Typora');
  try{return showLibrary(await SDSettings.request('/library',{token}),preserve);}catch(e){connected(false);throw e;}
}
async function run(button,fn){
  if(busy)return;busy=true;const controls=[...document.querySelectorAll('button,input,select')].map(n=>[n,n.disabled]);controls.forEach(([n])=>n.disabled=true);status('');
  try{await fn();}catch(e){if(e.name==='AbortError')status('已取消选择。');else status(e.message,true);}finally{controls.forEach(([n,disabled])=>n.disabled=disabled);busy=false;}
}
async function init(){
  const data=await chrome.storage.local.get(['settings','connectorToken']);settings={...SDSettings.defaults,...data.settings};settings.defaultCollection=data.settings?.defaultCollection??data.settings?.lastCollection??'';token=data.connectorToken;
  $(`input[name=mode][value="${settings.mode==='library'?'library':'zip'}"]`).checked=true;
  $(`input[name=collectionMode][value="${settings.collectionMode==='direct'?'direct':'ask'}"]`).checked=true;
  $('#custom').checked=settings.customDirectory;connected(false);sections();
  const h=await SDSettings.handle();$('#grant').hidden=!h||await h.queryPermission({mode:'readwrite'})==='granted';
  if(token&&settings.mode==='library')await check().catch(e=>status(e.message,true));
}
for(const radio of document.querySelectorAll('input[type=radio]'))radio.onchange=()=>{
  sections();
  // Opting out of library writes takes effect on selection, even before saving
  // the remaining directory preferences. Do not persist stale hidden fields.
  if(radio.name==='mode'&&radio.value==='zip')run(radio,async()=>{
    const {settings:stored}=await chrome.storage.local.get('settings');
    await chrome.storage.local.set({settings:{...SDSettings.defaults,...stored,mode:'zip'}});
    settings.mode='zip';status('已切换为仅下载 ZIP。');
  });
};$('#custom').onchange=sections;
$('#pick').onclick=e=>run(e.currentTarget,async()=>{const handle=await window.showDirectoryPicker({id:'sd-typora-zip',mode:'readwrite'});const record=await SDSettings.directory(handle);settings.directoryId=record.id;settings.directoryName=handle.name;$('#custom').checked=true;$('#grant').hidden=true;sections();status('已选择文件夹，请保存设置。');});
$('#grant').onclick=e=>run(e.currentTarget,async()=>{const h=await SDSettings.handle();if(!h||await h.requestPermission({mode:'readwrite'})!=='granted')throw Error('没有取得文件夹写入权限');$('#grant').hidden=true;status('文件夹已授权。');});
$('#connect').onclick=e=>run(e.currentTarget,async()=>{status('请在 Typora 窗口中点击“允许连接”…');const r=await SDSettings.request('/pair',{method:'POST',body:{},timeout:95000});token=r.token;await chrome.storage.local.set({connectorToken:token});await check();status('连接成功。');});
$('#refresh').onclick=e=>run(e.currentTarget,async()=>{await check(true);status('连接正常。');});
$('#disconnect').onclick=e=>run(e.currentTarget,async()=>{if(token)await SDSettings.request('/unpair',{method:'POST',body:{},token});token=null;libraryInfo=null;await chrome.storage.local.remove('connectorToken');connected(false);$('#root').textContent='连接后显示知识库目录';status('已断开连接。');});
$('#choose-root').onclick=e=>run(e.currentTarget,async()=>{
  const info=await check(true);if(!info.capabilities?.includes('choose-library'))throw Error('请先更新并重启 Typora 工具栏 v1.27.0。');
  status('请在 Typora 窗口中选择知识库文件夹…');
  const next=await SDSettings.request('/library/choose',{token,method:'POST',body:{libraryId:info.libraryId},timeout:125000});
  showLibrary(next,true);status(next.canceled?'已取消选择。':'知识库已切换，请设置分类并保存。');
});
$('#save').onclick=e=>run(e.currentTarget,async()=>{
  const mode=$('input[name=mode]:checked').value;
  if(mode==='library'){
    const before=libraryInfo?.libraryId,info=await check(true);if(before&&before!==info.libraryId)throw Error('知识库已切换，请重新选择保存方式。');
    if($('input[name=collectionMode]:checked').value==='direct'&&$('#collection').value&&!info.collections.some(c=>c.id===$('#collection').value))throw Error('默认分类已不存在，请重新选择。');
  }
  if(mode==='zip'&&$('#custom').checked){const h=await SDSettings.handle();if(!h||await h.queryPermission({mode:'readwrite'})!=='granted')throw Error('请先选择文件夹或允许写入');}
  settings={...settings,mode,customDirectory:$('#custom').checked,collectionMode:$('input[name=collectionMode]:checked').value,defaultCollection:$('#collection').value,...(libraryInfo?{libraryId:libraryInfo.libraryId}:{})};
  await chrome.storage.local.set({settings});status('设置已保存。');
});
init().catch(e=>status(e.message,true));
