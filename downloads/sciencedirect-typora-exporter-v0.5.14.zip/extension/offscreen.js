'use strict';
const jobs=new Map();
const send=(id,type,data={})=>chrome.runtime.sendMessage({target:'worker',id,type,...data});
async function build(job,extraction){
  try{
    await SDSettings.checkDestination(job.destination,job.id);
    if(job.destination?.mode==='directory'){const record=await SDSettings.directory();if(job.destination.directoryId&&record?.id!==job.destination.directoryId)throw Error('保存位置已改变，请在插件选项中保存设置后重试。');job.directoryHandle=record?.handle||record;}
    const fetcher=async(url,options)=>{
      const controller=new AbortController(),abort=()=>controller.abort(),signals=[options.signal,job.controller.signal];
      const cleanup=()=>{signals.forEach(s=>s.removeEventListener('abort',abort));job.cleanups.delete(cleanup);};job.cleanups.add(cleanup);
      signals.forEach(s=>{if(s.aborted)abort();else s.addEventListener('abort',abort,{once:true});});
      try{const r=await fetch(url,{...options,signal:controller.signal});if(!r.ok)cleanup();return {ok:r.ok,status:r.status,url:r.url,headers:r.headers,arrayBuffer:async()=>{try{return await r.arrayBuffer();}finally{cleanup();}}};}catch(e){cleanup();throw e;}
    };
    const result=await SDPackage.build(extraction,{fetcher,onProgress:p=>{
      if(job.controller.signal.aborted)return;
      send(job.id,'progress',{phase:p.phase,message:p.phase==='package'?'正在整理英文文档…':`正在保存资源 ${p.current+1} / ${p.total}`,progress:p.total?p.current/p.total:0}).catch(()=>{});
    }});
    if(job.controller.signal.aborted)return;
    const summary=`${result.report.figures} 张图 · ${result.report.tables} 张表 · ${result.report.references} 条文献`;
    await SDSettings.checkDestination(job.destination,job.id);if(job.controller.signal.aborted)return;
    if(job.destination?.mode==='library')await importLibrary(job,result,summary);
    else if(job.destination?.mode==='directory')await saveDirectory(job,result,summary);
    else {job.url=URL.createObjectURL(result.blob);await send(job.id,'download',{url:job.url,stem:result.stem,summary,notes:result.report.warnings});}
  }catch(error){if(!job.controller.signal.aborted)await send(job.id,'error',{error:error.message}).catch(()=>{});release(job.id);}
}
async function saveDirectory(job,result,summary){
  const handle=job.directoryHandle;if(!handle||handle.name!==job.destination.directoryName||await handle.queryPermission({mode:'readwrite'})!=='granted')throw Error('所选文件夹需要重新授权，请在插件“选项”中允许写入。');
  if(job.controller.signal.aborted)return;
  await send(job.id,'progress',{phase:'saving-directory',message:'正在写入 '+handle.name+'…',progress:1});
  if(job.controller.signal.aborted)return;
  const name=result.stem.slice(0,120)+'_'+new Date().toISOString().replace(/[:.]/g,'-')+'_'+job.id.slice(0,8)+'.zip';
  const file=await handle.getFileHandle(name,{create:true}),stream=await file.createWritable();
  try{await stream.write(result.blob);await stream.close();}catch(e){await stream.abort().catch(()=>{});throw e;}
  await send(job.id,'saved',{message:'已保存到 '+handle.name,summary,result:{filename:name}});
}
async function importLibrary(job,result,summary){
  const bytes=data=>typeof data==='string'?new TextEncoder().encode(data):new Uint8Array(data),sha=async data=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',data))].map(n=>n.toString(16).padStart(2,'0')).join('');
  const files=[];for(const f of result.files){const data=bytes(f.data);files.push({path:f.path,bytes:data.length,sha256:await sha(data)});}
  const call=async(path,body,method='POST')=>{await SDSettings.checkDestination(job.destination,job.id);return SDSettings.request(path,{token:job.token,method,body,signal:job.controller.signal,timeout:60000});};
  await call('/import',{id:job.id,files,libraryId:job.destination.libraryId,collectionId:job.destination.collectionId});
  for(let i=0;i<files.length;i++){if(job.controller.signal.aborted)return;await send(job.id,'progress',{phase:'transferring',message:`正在存入知识库 ${i+1} / ${files.length}`,progress:i/files.length});await call('/import/'+job.id+'/file/'+i,bytes(result.files[i].data),'PUT');}
  if(job.controller.signal.aborted)return;
  await send(job.id,'progress',{phase:'committing',message:'正在登记文库条目…',progress:1});
  if(job.controller.signal.aborted)return;
  // Retry the same import ID if the response is lost; the receiver is idempotent.
  let saved;for(let attempt=0;;attempt++){try{saved=await call('/import/'+job.id+'/commit',{});break;}catch(e){if(attempt>=1||job.controller.signal.aborted)throw e;}}
  await send(job.id,'saved',{message:'已保存到 '+saved.collectionName,summary,result:saved});
}
function release(id){const job=jobs.get(id);if(!job)return;job.controller.abort();for(const cleanup of job.cleanups)cleanup();if(job.url)URL.revokeObjectURL(job.url);jobs.delete(id);if(job.destination?.mode==='library')SDSettings.request('/import/'+id+'/abort',{token:job.token,method:'POST',body:{}}).catch(()=>{});}
chrome.runtime.onMessage.addListener((message,sender,respond)=>{
  if(message?.target!=='offscreen'||sender.id!==chrome.runtime.id||sender.tab||sender.url&&sender.url!==chrome.runtime.getURL('background.js'))return;
  if(message.type==='build'){
    if(jobs.has(message.id)){respond({accepted:true});return;}
    const job={id:message.id,controller:new AbortController(),cleanups:new Set(),destination:message.destination,token:message.token};jobs.set(job.id,job);respond({accepted:true});build(job,message.extraction);
  }else if(message.type==='release'){release(message.id);respond({ok:true});}
  else if(message.type==='status')respond({exists:jobs.has(message.id)});
});
setInterval(()=>{for(const job of jobs.values())send(job.id,'heartbeat').then(r=>{if(r?.discard)release(job.id);}).catch(()=>{});},20000);
