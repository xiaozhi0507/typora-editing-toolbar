/* Shared extension-origin directory handles. Credentials never enter the article page. */
globalThis.SDSettings={
  connectorURL:'http://127.0.0.1:23120/v1',
  defaults:{mode:'zip',customDirectory:false,directoryName:'',lastCollection:'',collectionMode:'ask',defaultCollection:''},
  destinationMode(settings){return settings.mode==='library'?'library':settings.customDirectory?'directory':'zip';},
  async checkDestination(destination,id){
    // Chrome offscreen documents expose runtime messaging, not storage APIs.
    if(!chrome.storage?.local){
      const result=await chrome.runtime.sendMessage({target:'worker',type:'check-destination',id});
      if(!result?.ok)throw Error(result?.error||'保存方式已改变，请重新点击保存。');
      return;
    }
    const {settings:stored}=await chrome.storage.local.get('settings'),settings={...this.defaults,...stored};
    if(destination?.mode!==this.destinationMode(settings))throw Error('保存方式已改变，请重新点击保存。');
    return settings;
  },
  async directory(value){
    const saved=value===undefined?undefined:{handle:value,id:crypto.randomUUID()};
    const db=await new Promise((resolve,reject)=>{const r=indexedDB.open('sd-typora-settings',1);r.onupgradeneeded=()=>r.result.createObjectStore('handles');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});
    try{return await new Promise((resolve,reject)=>{const tx=db.transaction('handles',value===undefined?'readonly':'readwrite'),store=tx.objectStore('handles');const req=value===undefined?store.get('zipDirectory'):store.put(saved,'zipDirectory');let result;req.onsuccess=()=>result=req.result;tx.oncomplete=()=>resolve(saved||result);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error);});}finally{db.close();}
  },
  async handle(value){const r=await this.directory(value);return r?.handle||r;},
  async request(path,{token,method='GET',body,signal,timeout=20000}={}){
    const controller=new AbortController(),abort=()=>controller.abort();if(signal?.aborted)abort();signal?.addEventListener('abort',abort,{once:true});
    const timer=setTimeout(abort,timeout);
    try{
      const headers={'X-Typora-Connector':chrome.runtime.getURL('').replace(/\/$/,'')};
      const options={credentials:'omit',cache:'no-store',redirect:'error',signal:controller.signal};
      const invalid='本机 23120 端口未返回有效的 Typora 连接数据，可能被其他程序占用。请更新配套工具栏并完整重启 Typora。';
      const read=async response=>{let data;try{data=await response.json();}catch(e){if(e.name==='AbortError')throw e;throw Error(invalid);}if(!data||typeof data!=='object'||Array.isArray(data))throw Error(invalid);return data;};
      // Probe without credentials or document content; never follow redirects or
      // fall back to Zotero's port when Typora is unavailable.
      const healthResponse=await fetch(this.connectorURL+'/health',{...options,headers});
      const health=await read(healthResponse);
      if(!healthResponse.ok||health.service!=='typora-library'||health.version!==1)throw Error(invalid);
      const binary=body instanceof Uint8Array,response=await fetch(this.connectorURL+path,{...options,method,headers:{...headers,...(token?{Authorization:'Bearer '+token}:{}),...(body!==undefined?{'Content-Type':binary?'application/octet-stream':'application/json'}:{})},body:body===undefined?undefined:binary?body:JSON.stringify(body)});
      const result=await read(response);if(!response.ok)throw Error(typeof result.error==='string'?result.error:'Typora 连接失败');return result;
    }catch(e){if(e instanceof TypeError||e.name==='AbortError')throw Error(signal?.aborted?'已取消保存':'无法连接 Typora（本机端口 23120）。请安装配套工具栏 v1.113.3 或更新版本，完整退出并重开 Typora 后重试。');throw e;}
    finally{clearTimeout(timer);signal?.removeEventListener('abort',abort);}
  }
};
