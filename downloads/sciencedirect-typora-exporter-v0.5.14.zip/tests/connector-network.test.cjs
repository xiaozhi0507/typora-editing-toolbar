'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../extension/settings.js'),'utf8');
const identity='chrome-extension://'+'a'.repeat(32),health={service:'typora-library',version:1};
function client(fetch){
 const context={fetch,AbortController,Uint8Array,TypeError,setTimeout,clearTimeout,chrome:{runtime:{getURL:()=>identity+'/'}}};
 vm.createContext(context);vm.runInContext(source,context);return context.SDSettings;
}
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json'}});
test('new port probes Typora without credentials before an authenticated request',async()=>{
 const calls=[],api=client(async(url,options)=>{calls.push({url,options});return json(calls.length===1?health:{root:'fixture',collections:[]});});
 const result=await api.request('/library',{token:'private-token'});
 assert.equal(result.root,'fixture');assert.deepEqual(calls.map(c=>c.url),['http://127.0.0.1:23120/v1/health','http://127.0.0.1:23120/v1/library']);
 assert.equal(calls[0].options.headers.Authorization,undefined);assert.equal(calls[0].options.body,undefined);
 assert.equal(calls[1].options.headers.Authorization,'Bearer private-token');
 for(const {options} of calls){assert.equal(options.headers['X-Typora-Connector'],identity);assert.equal(options.redirect,'error');assert.equal(options.credentials,'omit');}
});
test('non-JSON and unrelated service responses stop before pairing or uploading',async()=>{
 for(const response of [()=>new Response('No endpoint found',{status:404}),()=>new Response('<html>Error</html>',{status:502}),()=>json({service:'zotero',version:1}),()=>json({service:'typora-library',version:2}),()=>json(null),()=>json([]),()=>json(health,500)]){
  const calls=[],api=client(async(url,options)=>{calls.push({url,options});return response();});
  await assert.rejects(api.request('/import',{method:'POST',token:'secret',body:{document:'private'}}),/23120.*未返回有效的 Typora/);
  assert.equal(calls.length,1);assert.equal(calls[0].options.headers.Authorization,undefined);assert.equal(calls[0].options.body,undefined);
 }
});
test('offline receiver gives paired-update instructions without retrying port 23119',async()=>{
 let calls=0;const api=client(async()=>{calls++;throw new TypeError('fetch failed');});
 await assert.rejects(api.request('/pair',{method:'POST',body:{}}),/23120.*v1\.113\.3/);assert.equal(calls,1);
});
test('HTTP authorization errors retain the server explanation and are not retried',async()=>{
 let calls=0;const api=client(async()=>json(++calls===1?health:{error:'请在扩展选项中连接 Typora'},calls===1?200:401));
 await assert.rejects(api.request('/library',{token:'expired'}),/请在扩展选项中连接 Typora/);assert.equal(calls,2);
});
test('non-JSON action errors are readable and never retry an import',async()=>{
 let calls=0;const api=client(async()=>++calls===1?json(health):new Response('No endpoint found',{status:404}));
 await assert.rejects(api.request('/import',{method:'POST',body:{}}),/23120.*未返回有效的 Typora/);assert.equal(calls,2);
});
test('pairing uses JSON and upload preserves binary bytes after the identity probe',async()=>{
 const calls=[],api=client(async(url,options)=>{calls.push({url,options});return json(url.endsWith('/health')?health:{ok:true});});
 await api.request('/pair',{method:'POST',body:{}});assert.equal(calls[1].options.body,'{}');assert.equal(calls[1].options.headers['Content-Type'],'application/json');
 const bytes=new Uint8Array([0,255,3,128]);await api.request('/import/fixture/file/0',{method:'PUT',body:bytes,token:'secret'});
 assert.equal(calls[3].options.body,bytes);assert.equal(calls[3].options.headers['Content-Type'],'application/octet-stream');
});
test('canceling the probe stops the pending request before any action',async()=>{
 const controller=new AbortController();let calls=0;
 const api=client(async(url,{signal})=>{calls++;return new Promise((resolve,reject)=>{signal.addEventListener('abort',()=>reject(new DOMException('Aborted','AbortError')),{once:true});});});
 const pending=api.request('/pair',{method:'POST',body:{},signal:controller.signal});controller.abort();
 await assert.rejects(pending,/已取消保存/);assert.equal(calls,1);
});
test('probe timeout ends promptly with update guidance',async()=>{
 const api=client(async(url,{signal})=>new Promise((resolve,reject)=>signal.addEventListener('abort',()=>reject(new DOMException('Aborted','AbortError')),{once:true})));
 await assert.rejects(api.request('/pair',{method:'POST',body:{},timeout:10}),/23120.*v1\.113\.3/);
});
