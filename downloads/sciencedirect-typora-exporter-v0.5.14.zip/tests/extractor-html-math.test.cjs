const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {JSDOM}=require('jsdom');
const url='https://www.sciencedirect.com/science/article/pii/S0167198719313601?via%3Dihub';
const code=fs.readFileSync(process.env.SD_EXTRACTOR_TEST_SOURCE||path.join(__dirname,'../extension/extractor.js'),'utf8');
function capture(markup){
 const dom=new JSDOM(`<meta name="citation_title" content="HTML chemistry regression"><div id="body"><h2>Methods</h2><p>${'Soil physicochemical properties were measured in replicated plots. '.repeat(25)}</p>${markup}</div>`,{runScripts:'outside-only',url});
 try{dom.window.eval(code);return JSON.parse(JSON.stringify(dom.window.SDTypora.extract(dom.window.document,url)));}finally{dom.window.close();}
}
test('chemical ions written in ordinary HTML preserve each subscript and charge',()=>{
 const ions=['HCO<sub>3</sub><sup>−</sup>','CO<sub>3</sub><sup>2−</sup>','Cl<sup>−</sup>','SO<sub>4</sub><sup>2−</sup>','Ca<sup>2+</sup>','Mg<sup>2+</sup>','Na<sup>+</sup>','K<sup>+</sup>'];
 const r=capture('<p>'+ions.map(s=>'<span class="math">'+s+'</span>').join(' and ')+'</p>');
 for(const ion of ions)assert.ok(r.markdown.includes(ion),ion);
 assert.equal(r.report.math,8);assert.equal(r.report.math_html,8);
});
test('plain and italic HTML equations, nested wrappers and units remain readable',()=>{
 const r=capture('<div class="display"><span class="label">(1)</span><span class="math"><i>ET</i> = <i>P</i> + <i>I</i> + Δ<i>W</i></span></div><p><span class="math"><span class="math">kg·ha<sup>−1</sup> mm<sup>−1</sup></span></span></p>');
 assert.match(r.markdown,/\*ET\* = \*P\* \+ \*I\* \+ Δ\*W\*/);
 assert.match(r.markdown,/kg·ha<sup>−1<\/sup> mm<sup>−1<\/sup>/);assert.equal(r.report.math,2);
});
test('native MathML with a math CSS class is not confused with an empty renderer',()=>{
 const r=capture('<math class="math"><msub><mi>T</mi><mi>c</mi></msub></math>');
 assert.match(r.markdown,/\$\{T\}_\{c\}\$/);assert.equal(r.report.math,1);
});
test('generic wrappers retain surrounding text and all separate mathematical sources',()=>{
 const r=capture('<span class="math">A <math><mi>x</mi></math> plus <script type="math/tex">y</script> B</span>');
 assert.match(r.markdown,/A \$x\$ plus \$y\$ B/);assert.equal(r.report.math,2);
});
test('plain HTML chemistry beside a TeX source is not mistaken for its preview',()=>{
 const r=capture('<p><span class="math">Na<sup>+</sup></span><script type="math/tex">x</script></p>');
 assert.match(r.markdown,/Na<sup>\+<\/sup>\$x\$/);assert.equal(r.report.math,2);
});
test('HTML chemistry in merged table cells, headings and figure captions preserves indexes',()=>{
 const r=capture('<h3><span class="math">Ca<sup>2+</sup></span> concentration</h3><div class="tables" id="t1"><div class="captions"><span class="label">Table 1</span> Ions</div><table><tr><th colspan="2"><span class="math">HCO<sub>3</sub><sup>−</sup></span></th></tr><tr><td>A</td><td>1</td></tr></table></div><figure id="f1"><img src="https://ars.els-cdn.com/content/image/test.jpg" alt="Fig. 1"><figcaption>Balance of <span class="math">Na<sup>+</sup></span>.</figcaption></figure>');
 assert.match(r.markdown,/Ca<sup>2\+<\/sup>/);assert.match(r.markdown,/HCO<sub>3<\/sub><sup>−<\/sup>/);
 assert.match(r.markdown,/Na<sup>\+<\/sup>/);
 for(const t of r.index.documents[0].targets)assert.equal(r.markdown.split('\n').slice(t.start_line-1,t.end_line).join('\n'),t.content);
});
test('formula images retain the local asset, rather than becoming blank or guessed TeX',()=>{
 const r=capture('<span class="math"><img alt="equation" src="https://ars.els-cdn.com/content/image/formula.gif"></span>');
 assert.equal(r.assets.length,1);assert.match(r.markdown,/001-inline.gif/);
});
test('unreadable rendering is still blocked, even when accompanied by a label',()=>{
 for(const s of ['<span class="math"><svg/></span>','<span class="math">ET = <svg/></span>','<span class="math">ET = <img alt="missing formula"></span>','<span class="math"><canvas/></span>','<span class="MathJax_SVG math">visual placeholder<svg/></span>'])assert.throws(()=>capture(s),/公式缺少|无法完整保存公式/);
 assert.throws(()=>capture('<span class="math"><script type="math/mml"><math><mfrac></math></script></span>'),/不完整/);
});
