const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {JSDOM}=require('jsdom');
const url='https://www.sciencedirect.com/science/article/pii/S0034425725003621';
const cdn='https://ars.els-cdn.com/content/image/1-s2.0-S0034425725003621-';
function capture(html){
 const dom=new JSDOM(`<meta name="citation_title" content="Table and caption regression"><div id="body"><h2>Methods</h2><p>${'Scientific observations and reproducible measurements. '.repeat(25)}</p>${html}</div>`,{url,runScripts:'outside-only'});
 try{dom.window.eval(fs.readFileSync(path.join(__dirname,'../extension/extractor.js'),'utf8'));return JSON.parse(JSON.stringify(dom.window.SDTypora.extract(dom.window.document,url)));}finally{dom.window.close();}
}
function checkTargets(r){for(const t of r.index.documents[0].targets)assert.equal(r.markdown.split('\n').slice(t.start_line-1,t.end_line).join('\n'),t.content);}
test('multi-paragraph figure caption closes each inline span before paragraph breaks',()=>{
 const r=capture(`<figure id="f0010"><img alt="Fig. 2" src="${cdn}gr2.jpg"><span class="captions"><p><span class="label">Fig. 2</span>. Model overview <em>top panels</em>.</p><div>Top-left: ${'Encoder details. '.repeat(10)}</div><div>Top-right: Decoder and <a href="https://example.org/method">method</a>.</div></span></figure>`);
 const f=r.index.documents[0].targets.find(t=>t.kind==='figure');
 assert.equal((f.content.match(/<span style=/g)||[]).length,4);
 for(const p of f.content.split('\n\n')){assert.equal((p.match(/<span /g)||[]).length,(p.match(/<\/span>/g)||[]).length);}
 assert.match(f.content,/\*top panels\*/);assert.match(f.content,/\[method\]/);checkTargets(r);
});
test('merged tables retain header groups, row spans, footer, math and genuinely empty cells',()=>{
 const r=capture(`<div class="tables" id="t0005"><div class="captions"><span class="label">Table 1</span>. Measurements.</div><table><thead><tr><td rowspan="2" scope="col"><span class="screen-reader-only">Empty Cell</span></td><th colspan="2">Values</th></tr><tr><th>A</th><th>B</th></tr></thead><tbody><tr><td colspan="3">Training sets</td></tr><tr><th scope="row">1</th><td><em>leaf</em></td><td><math><msub><mi>C</mi><mi>w</mi></msub></math></td></tr><tr><th scope="row">2</th><td></td><td>None</td></tr></tbody><tfoot><tr><td colspan="3">Measured total</td></tr></tfoot></table></div>`);
 const html=r.markdown.match(/<table[\s\S]*?<\/table>/)[0],dom=new JSDOM(html),table=dom.window.document.querySelector('table');
 assert.ok(table.classList.contains('et-table-three-line'));assert.equal(table.tHead.rows.length,2);assert.equal(table.tBodies[0].rows.length,3);assert.equal(table.tFoot.rows.length,1);
 assert.equal(table.tHead.rows[0].cells[0].rowSpan,2);assert.equal(table.tHead.rows[0].cells[1].colSpan,2);assert.equal(table.tBodies[0].rows[2].cells[1].textContent,'');
 assert.doesNotMatch(r.markdown,/Empty Cell/);assert.ok(html.includes('${C}_{w}$'));assert.equal(r.index.documents[0].targets.find(t=>t.kind==='table').table_style,'three-line');checkTargets(r);dom.window.close();
});
test('simple editable tables also discard accessible empty-cell placeholders',()=>{
 const r=capture('<table><thead><tr><td><span class="screen-reader-only">Empty Cell</span></td><th>Value</th></tr></thead><tbody><tr><th>1</th><td>42</td></tr></tbody></table>');
 assert.match(r.markdown,/\|  \| Value \|\n\| --- \| --- \|/);assert.doesNotMatch(r.markdown,/<table|Empty Cell/);
});
test('named local supplements retain descriptions and source type/size; table S1 opens its attachment',()=>{
 const r=capture(`<p>See <a href="#ec0005">Table S1</a>.</p><h2>Appendix A</h2><span class="article-attachment"><form><button>Download all</button></form><a class="help-link" href="https://service.elsevier.com/help">What's this?</a></span><span class="e-component" id="ec0005"><span class="article-attachment"><a class="download-link" href="${cdn}mmc1.pdf" title="Download Acrobat PDF file (26MB)">Download</a></span><span class="captions"><p id="ca0050">Supplementary material 1</p><div>Additional <em>methods</em> and data.</div></span></span><span class="e-component" id="ec0010"><span class="article-attachment"><a class="download-link" href="${cdn}mmc2.zip" title="Download zip file (21KB)">Download</a></span><span class="captions"><p>Supplementary material 2</p></span></span><p><a href="${url}#ca0050">Supplement description</a>. <a class="help-link" href="https://example.org/help">Scientific help resource</a>.</p>`);
 assert.equal(r.assets.length,2);assert.equal(r.assets[0].kind,'supplement');assert.match(r.markdown,/\[Supplementary material 1\]\(<_assets\/.*001-supplement.pdf>\) — PDF · 26 MB/);
 assert.match(r.markdown,/\[Table S1\]\(<_assets\/.*001-supplement.pdf>\)/);assert.match(r.markdown,/\[Supplement description\]\(<_assets\/.*001-supplement.pdf>\)/);
 assert.match(r.markdown,/Additional \*methods\* and data/);assert.match(r.markdown,/ZIP · 21 KB/);assert.match(r.markdown,/Scientific help resource/);
 assert.doesNotMatch(r.markdown,/What's this|Download all|\[Supplementary material\]|service.elsevier.com/);checkTargets(r);
});
