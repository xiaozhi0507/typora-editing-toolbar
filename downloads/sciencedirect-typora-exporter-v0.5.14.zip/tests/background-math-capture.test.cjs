const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {JSDOM}=require('jsdom');
const extension=path.join(__dirname,'../extension'),url='https://www.sciencedirect.com/science/article/pii/S0167198719313601';
function harness({broken=false}={}){
 const dom=new JSDOM(`<meta name="citation_title" content="Worker capture test"><div id="body"><h2>Methods</h2><p>${'Cotton water balance observations. '.repeat(50)}</p><mjx-container class="MathJax CtxtMenu_Attached_0"><mjx-math>visual formula</mjx-math></mjx-container></div>`,{url,runScripts:'outside-only'});
 const element=dom.window.document.querySelector('mjx-container');
 dom.window.MathJax={startup:{document:{getMathItemsWithin:()=>[{typesetRoot:element,inputJax:{name:'MathML'},math:broken?'<math><mfrac></math>':'<math><mi>ET</mi><mo>=</mo><mi>P</mi><mo>+</mo><mi>I</mi></math>',display:true}]}}};
 const isolated=vm.createContext({document:dom.window.document,location:dom.window.location,DOMParser:dom.window.DOMParser,URL,setTimeout,clearTimeout});
 const requests=[],messages=[],event={addListener(){}};
 const chrome={
  storage:{session:{get:async()=>({}),set:async()=>{}},local:{get:async()=>({settings:{mode:'zip'},connectorToken:'test-credential-never-send-to-page'})},onChanged:event},
  runtime:{id:'test-extension',getURL:p=>'chrome-extension://test/'+p,onMessage:event,getContexts:async()=>[{}],sendMessage:async m=>{messages.push(m);return {accepted:true};}},
  action:{onClicked:event},tabs:{onUpdated:event},downloads:{onChanged:event},
  scripting:{executeScript:async request=>{
   requests.push(request);assert.deepEqual(JSON.parse(JSON.stringify(request.target)),{tabId:9,documentIds:['document-9']});
   if(request.files){for(const file of request.files)vm.runInContext(fs.readFileSync(path.join(extension,file),'utf8'),isolated);return [{}];}
   const expression='('+request.func.toString()+')(...'+JSON.stringify(request.args||[])+')';
   const result=request.world==='MAIN'?await dom.window.eval(expression):await vm.runInContext(expression,isolated);
   return [{result:result===undefined?undefined:JSON.parse(JSON.stringify(result))}];
  }}
 };
 const worker=vm.createContext({chrome,URL,setTimeout,clearTimeout});
 worker.importScripts=(...files)=>{for(const file of files)vm.runInContext(fs.readFileSync(path.join(extension,file),'utf8'),worker);};
 vm.runInContext(fs.readFileSync(path.join(extension,'background.js'),'utf8'),worker);
 worker.testJob={id:'capture-test',tabId:9,documentId:'document-9',url,phase:'extracting',destination:{mode:'zip'}};
 return {dom,requests,messages,run:()=>vm.runInContext('capture(testJob)',worker)};
}
test('worker collects MAIN-world math then passes plain data to isolated extraction and packaging',async()=>{
 const h=harness();try{
  await h.run();assert.equal(h.requests.length,4);
  const main=h.requests.find(r=>r.world==='MAIN');assert.ok(main);assert.equal(main.args,undefined);
  assert.equal(h.requests[3].args[0].sources.length,1);
  assert.ok(!JSON.stringify(main).includes('test-credential'));
  const build=h.messages.find(m=>m.type==='build');assert.ok(build);assert.equal(build.extraction.report.math_runtime,1);
  assert.match(build.extraction.markdown,/ET=P\+I/);assert.equal(build.token,undefined);
 }finally{h.dom.window.close();}
});
test('worker does not start packaging when a runtime equation is malformed',async()=>{
 const h=harness({broken:true});try{await assert.rejects(h.run(),/不完整/);assert.equal(h.messages.filter(m=>m.type==='build').length,0);}finally{h.dom.window.close();}
});
