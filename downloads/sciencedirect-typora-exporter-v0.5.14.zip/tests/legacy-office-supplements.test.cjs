const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {JSDOM}=require('jsdom'),{unzipSync}=require('fflate');
const pack=require('../extension/package.js');
const url='https://www.sciencedirect.com/science/article/pii/S1234567890123456';
const cdn='https://ars.els-cdn.com/content/image/1-s2.0-S1234567890123456-';
// Header fixtures exercise signature and transport checks, not Office document parsing.
const ole=()=>{const b=new Uint8Array(512);b.set([0xd0,0xcf,0x11,0xe0,0xa1,0xb1,0x1a,0xe1]);return b;};
function capture(){
 const html=['doc','XLS','docx','xlsx'].map((ext,i)=>`<span class="e-component" id="ec${i}"><span class="article-attachment"><a class="download-link" href="${cdn}mmc${i+1}.${ext}?download=1" title="Download file (1KB)">Download</a></span><span class="captions"><p>Supplementary material ${i+1}</p></span></span>`).join('');
 const dom=new JSDOM(`<meta name="citation_title" content="Legacy Office supplements"><div id="body"><h2>Methods</h2><p>${'Scientific observations and reproducible measurements. '.repeat(25)}</p><p>See <a href="#ec0">Methods document</a> and <a href="#ec1">Results workbook</a>.</p>${html}</div>`,{url,runScripts:'outside-only'});
 try{dom.window.eval(fs.readFileSync(path.join(__dirname,'../extension/extractor.js'),'utf8'));return JSON.parse(JSON.stringify(dom.window.SDTypora.extract(dom.window.document,url)));}finally{dom.window.close();}
}
test('legacy and modern Office supplements retain type, local links and one asset per file',()=>{
 const r=capture();assert.equal(r.assets.length,4);
 assert.deepEqual(r.assets.map(a=>path.extname(a.path)),['.doc','.xls','.docx','.xlsx']);
 for(const [i,a] of r.assets.entries()){assert.equal(a.kind,'supplement');assert.ok(r.markdown.includes(`[Supplementary material ${i+1}](<${a.path}>)`));}
 assert.ok(r.markdown.includes(`[Methods document](<${r.assets[0].path}>)`));assert.ok(r.markdown.includes(`[Results workbook](<${r.assets[1].path}>)`));
 assert.match(r.markdown,/— DOC · 1 KB/);assert.match(r.markdown,/— XLS · 1 KB/);
});
test('legacy Office signatures accept binary MIME and reject HTML, truncated headers and renamed ZIPs',()=>{
 for(const ext of ['doc','xls','DOC','XLS']){
  const p='_assets/sample.'+ext,b=ole();assert.deepEqual(pack.validateAsset(b,p,'application/octet-stream'),b);
  assert.throws(()=>pack.validateAsset(b,p,'text/html'),/空文件或网页/);
  assert.throws(()=>pack.validateAsset(new TextEncoder().encode('<html>Download error</html>'),p),/空文件或网页/);
  assert.throws(()=>pack.validateAsset(b.slice(0,32),p),/文件内容与格式不符/);
  const zip=new Uint8Array(512);zip.set([80,75,3,4]);assert.throws(()=>pack.validateAsset(zip,p),/文件内容与格式不符/);
  const corrupt=ole();corrupt[7]=0;assert.throws(()=>pack.validateAsset(corrupt,p),/文件内容与格式不符/);
 }
});
test('Office resources download once, preserve exact bytes and survive ZIP packaging with hashes',async()=>{
 const r=capture(),payloads=[ole(),ole(),new Uint8Array(512),new Uint8Array(512)],calls=[];
 payloads.forEach((b,i)=>{if(i>=2)b.set([80,75,3,4]);b[128]=i+1;});
 const out=await pack.build(r,{fetcher:async u=>{calls.push(u);const i=r.assets.findIndex(a=>a.urls.includes(u));assert.ok(i>=0);return {ok:true,status:200,url:u,headers:new Headers({'content-type':'application/octet-stream'}),arrayBuffer:async()=>payloads[i].buffer};}});
 assert.equal(calls.length,4);const zip=unzipSync(new Uint8Array(await out.blob.arrayBuffer()));
 for(const [i,a] of r.assets.entries()){assert.deepEqual(zip[a.path],payloads[i]);assert.equal(out.report.resources[i].sha256,await pack.sha256(payloads[i]));}
 assert.equal(out.report.downloaded_assets,4);
});
test('legacy Office download errors and oversized files fail instead of reporting a saved attachment',async()=>{
 const r=capture();
 for(const response of [
  {ok:false,status:404},
  {ok:true,status:200,headers:new Headers({'content-type':'text/html'}),arrayBuffer:async()=>new TextEncoder().encode('<html>Login required</html>').buffer},
  {ok:true,status:200,headers:new Headers({'content-length':String(50*1024*1024+1)}),arrayBuffer:async()=>{throw Error('must reject before read');}}
 ])await assert.rejects(pack.build(r,{fetcher:async u=>({url:u,...response})}),/supplement\.doc.*(?:HTTP 404|空文件或网页|50 MB)/);
});
