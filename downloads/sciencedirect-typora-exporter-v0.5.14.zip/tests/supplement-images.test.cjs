const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {JSDOM}=require('jsdom');
const pack=require('../extension/package.js');
const url='https://www.sciencedirect.com/science/article/pii/S2589721725001060';
const cdn='https://ars.els-cdn.com/content/image/1-s2.0-S2589721725001060-';
function supplement(n){return `<span class="e-component"><span class="article-attachment"><a href="${cdn}mmc${n}_lrg.jpg"><span><img src="${cdn}mmc${n}.sml" alt="Thumbnail"></span></a><ul><li><a class="download-link" title="Download high-res image" href="${cdn}mmc${n}_lrg.jpg">Download high-res</a></li><li><a class="download-link" href="${cdn}mmc${n}.jpg">Download full-size</a></li></ul></span><span class="captions">Supplementary material ${n}</span></span>`;}
function capture(html){
 const dom=new JSDOM(`<meta name="citation_title" content="PlantSegNeRF supplementary images"><div id="body"><h2>Methods</h2><p>${'Plant reconstruction and instance segmentation observations. '.repeat(30)}</p>${html}</div>`,{url,runScripts:'outside-only'});
 try{dom.window.eval(fs.readFileSync(path.join(__dirname,'../extension/extractor.js'),'utf8'));return JSON.parse(JSON.stringify(dom.window.SDTypora.extract(dom.window.document,url)));}finally{dom.window.close();}
}
const jpg=Uint8Array.from([255,216,255,224,...new Array(32).fill(0)]);
test('publisher .sml supplementary thumbnails select the matching high-res images once',()=>{
 const r=capture(supplement(1)+supplement(2));assert.equal(r.assets.length,2);
 for(let i=0;i<2;i++){
  assert.equal(r.assets[i].kind,'supplement');assert.ok(r.assets[i].path.endsWith('-supplement.jpg'));
  assert.deepEqual(r.assets[i].urls,[`${cdn}mmc${i+1}_lrg.jpg`,`${cdn}mmc${i+1}.jpg`,`${cdn}mmc${i+1}.sml`]);
  assert.equal(r.markdown.split(r.assets[i].path).length-1,1);
  assert.ok(r.markdown.includes('Supplementary material '+(i+1)));
 }
 assert.doesNotMatch(r.markdown,/\.bin|Thumbnail|Download full-size/);
});
test('high-res failure falls back to the real full-size JPEG with hash and local Markdown intact',async()=>{
 const r=capture(supplement(1)),calls=[];
 const out=await pack.build(r,{fetcher:async u=>{calls.push(u);return {ok:!u.includes('_lrg'),status:u.includes('_lrg')?404:200,url:u,headers:new Headers({'content-type':'image/jpeg'}),arrayBuffer:async()=>jpg.buffer};}});
 assert.deepEqual(calls,[cdn+'mmc1_lrg.jpg',cdn+'mmc1.jpg']);
 assert.equal(out.report.resources[0].fallback,true);assert.equal(out.report.resources[0].sha256,await pack.sha256(jpg));
 assert.equal(out.files.filter(f=>f.path.startsWith('_assets/')).length,1);assert.ok(out.blob.size>jpg.length);
});
test('ordinary figure and complex table image retain their correct matching source',()=>{
 const r=capture(`<figure><a title="high-res" href="${cdn}gr1_lrg.jpg"></a><img src="${cdn}gr1.jpg" alt="Fig. 1"><figcaption>Figure</figcaption></figure><table><tr><td colspan="2"><span class="article-attachment"><a href="${cdn}mmc1_lrg.jpg"><img src="${cdn}mmc1.sml"></a></span></td></tr></table>`);
 assert.equal(r.assets.length,2);assert.equal(r.assets[0].urls[0],cdn+'gr1_lrg.jpg');assert.equal(r.assets[1].urls[0],cdn+'mmc1_lrg.jpg');assert.doesNotMatch(r.markdown,/\.bin/);
});
test('missing or unrelated original-image link is reported instead of fabricating a URL or bin file',()=>{
 assert.throws(()=>capture(`<span class="article-attachment"><a href="${cdn}mmc2.jpg"><img src="${cdn}mmc1.sml"></a></span>`),/未找到可下载的原图链接.*mmc1.sml/);
});
test('unknown resource extension and case-insensitive path collisions fail before downloads',async()=>{
 const r=capture(supplement(1));let calls=0;const fetcher=async()=>{calls++;throw Error('unexpected download');};
 for(const bad of ['_assets/a.bin','_assets/NUL.jpg','_assets/../a.jpg','_assets/a?.jpg'])await assert.rejects(pack.build({...r,assets:[{...r.assets[0],path:bad}]},{fetcher}),/路径或格式不受支持/);
 await assert.rejects(pack.build({...r,assets:[r.assets[0],{...r.assets[0],path:r.assets[0].path.toUpperCase()}]},{fetcher}),/路径或格式不受支持|路径重复/);
 assert.equal(calls,0);
});
test('HTML returned for a supplementary JPEG still fails content validation',async()=>{
 const r=capture(supplement(1));
 await assert.rejects(pack.build(r,{fetcher:async u=>({ok:true,status:200,url:u,headers:new Headers({'content-type':'text/html'}),arrayBuffer:async()=>new TextEncoder().encode('<html>Login page instead of image</html>').buffer})}),/返回的是空文件或网页/);
});
