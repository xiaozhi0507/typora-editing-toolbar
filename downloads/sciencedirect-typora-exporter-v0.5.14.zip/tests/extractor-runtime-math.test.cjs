const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {JSDOM}=require('jsdom');
const url='https://www.sciencedirect.com/science/article/pii/S0167198719313601';
const readCode=fs.readFileSync(path.join(__dirname,'../extension/math-sources.js'),'utf8');
const extractor=fs.readFileSync(path.join(__dirname,'../extension/extractor.js'),'utf8');
function page(content){const dom=new JSDOM(`<meta name="citation_title" content="Runtime math fixture"><div id="body"><h2>Methods</h2><p>${'Scientific article content. '.repeat(60)}</p>${content}</div>`,{url,runScripts:'outside-only'});dom.window.eval(readCode);dom.window.eval(extractor);return dom;}
const renderer='<mjx-container class="MathJax CtxtMenu_Attached_0"><mjx-math><mjx-mi>visual glyphs</mjx-mi></mjx-math></mjx-container>';
function modern(dom,sources){const nodes=[...dom.window.document.querySelectorAll('mjx-container')];dom.window.MathJax={startup:{promise:Promise.resolve(),document:{getMathItemsWithin:()=>sources.map((source,i)=>({typesetRoot:nodes[i],math:source,display:i===0,inputJax:{name:'MathML'}}))}}};}
const et='<math xmlns="http://www.w3.org/1998/Math/MathML"><mi>ET</mi><mo>=</mo><mi>P</mi><mo>+</mo><mi>I</mi><mo>+</mo><mi>ΔSWS</mi></math>';
test('MAIN-world MathJax sources restore source-free rendered equations and ions in isolation',async()=>{
 const dom=page(renderer+'<p>'+renderer+'</p>');
 try{
  modern(dom,[et,'<math><msubsup><mi>HCO</mi><mn>3</mn><mo>−</mo></msubsup></math>']);
  assert.throws(()=>dom.window.SDTypora.extract(dom.window.document,url),/公式缺少/);
  const before=dom.window.document.documentElement.outerHTML;
  const snapshot=JSON.parse(JSON.stringify(await dom.window.SDMathSources.read()));
  assert.equal(dom.window.document.documentElement.outerHTML,before);
  delete dom.window.MathJax;
  const r=dom.window.SDTypora.extract(dom.window.document,url,snapshot);
  assert.match(r.markdown,/ET=P\+I\+ΔSWS/);assert.match(r.markdown,/\{HCO\}_\{3\}\^\{-\}/);
  assert.equal(r.report.math_runtime,2);assert.equal(r.report.math_display,1);
 }finally{dom.window.close();}
});
test('TeX runtime input and unknown input with serialized MathML use their declared format',async()=>{
 const dom=page(renderer+renderer);
 try{
  const nodes=dom.window.document.querySelectorAll('mjx-container');
  dom.window.MathJax={startup:{document:{math:[{typesetRoot:nodes[0],math:'x_{1}',inputJax:{name:'TeX'}},{typesetRoot:nodes[1],root:{},inputJax:{name:'AsciiMath'}}]},toMML:()=>et}};
  const r=dom.window.SDTypora.extract(dom.window.document,url,await dom.window.SDMathSources.read());
  assert.match(r.markdown,/\$x_\{1\}\$/);assert.match(r.markdown,/ET=P\+I\+ΔSWS/);assert.equal(r.report.math_runtime,2);
 }finally{dom.window.close();}
});
test('MathJax 2 runtime source works through an outer display wrapper',async()=>{
 const dom=page('<div class="MathJax_Display"><span id="MathJax-Element-1-Frame" class="MathJax">visual</span></div>');
 try{
  dom.window.MathJax={Hub:{getAllJax:()=>[{inputID:'MathJax-Element-1',inputJax:'MathML',originalText:et,root:{Get:()=> 'block'}}]}};
  const r=dom.window.SDTypora.extract(dom.window.document,url,await dom.window.SDMathSources.read());
  assert.equal(r.report.math_runtime,1);assert.equal(r.report.math_display,1);assert.match(r.markdown,/ET=P\+I\+ΔSWS/);
 }finally{dom.window.close();}
});
test('existing DOM source takes priority and does not duplicate runtime or assistive math',async()=>{
 const dom=page(renderer.replace('</mjx-container>','<mjx-assistive-mml>'+et+'</mjx-assistive-mml></mjx-container>'));
 try{modern(dom,[et]);const r=dom.window.SDTypora.extract(dom.window.document,url,await dom.window.SDMathSources.read());assert.equal(r.report.math,1);assert.equal(r.report.math_runtime,0);}finally{dom.window.close();}
});
test('stale snapshots, cross-paper snapshots and malformed runtime sources fail safely',async()=>{
 const dom=page(renderer);
 try{
  modern(dom,[et]);const data=JSON.parse(JSON.stringify(await dom.window.SDMathSources.read()));
  assert.throws(()=>dom.window.SDTypora.extract(dom.window.document,url,{...data,url:url+'other'}),/不一致/);
  const bad=JSON.parse(JSON.stringify(data));bad.sources[0].source='<math><mfrac></math>';
  assert.throws(()=>dom.window.SDTypora.extract(dom.window.document,url,bad),/不完整/);
  dom.window.document.querySelector('mjx-mi').textContent='changed';
  assert.throws(()=>dom.window.SDTypora.extract(dom.window.document,url,data),/发生变化/);
 }finally{dom.window.close();}
});
test('no runtime and disconnected formula sources cannot silently produce incomplete exports',async()=>{
 const dom=page(renderer);
 try{
  assert.equal((await dom.window.SDMathSources.read()).sources.length,0);
  modern(dom,[et]);dom.window.document.querySelector('mjx-container').remove();
  assert.equal((await dom.window.SDMathSources.read()).sources.length,0);
 }finally{dom.window.close();}
});
