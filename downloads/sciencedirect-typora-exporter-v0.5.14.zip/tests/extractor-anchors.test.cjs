const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {JSDOM}=require('jsdom');
const source='https://www.sciencedirect.com/science/article/pii/S0022169422012410';
function capture(){
 const dom=new JSDOM(`<meta name="citation_title" content="Publisher anchors regression"><div id="body"><h2>Introduction</h2><p>${'A sufficiently detailed scientific article sentence. '.repeat(25)}
 <a href="#b0105">Le and Chunjie, 2016</a> <a href="${source}#b0105">same article absolute reference</a>
 <a href="${source}#%62%30%31%30%35">encoded reference</a>
 <a href="#f0005">Fig. 1</a> <a href="${source}#t0005">Table 1</a>
 <a href="https://www.sciencedirect.com/science/article/pii/OTHER#b0105">other article</a>
 <a href="https://www.sciencedirect.com/topics/plant">plant topic</a>
 </p><p>Our code is available at <a href="https://github.com/lab/code">code</a> and our data is available at <a href="https://doi.org/10.5281/zenodo.1234">data</a>.</p>
 <figure id="f0005"><img alt="Fig. 1" src="https://ars.els-cdn.com/content/image/test.jpg"><figcaption><span class="label">Fig. 1</span> Plant measurements.</figcaption></figure>
 <div class="tables" id="t0005"><div class="captions"><span class="label">Table 1</span> Measurements.</div><table><tr><th>Day</th><th>Value</th></tr><tr><td>1</td><td>2</td></tr></table></div></div>
 <div id="references"><ol><li><span class="label"><a href="#bb0105">Le and Chunjie, 2016</a></span><div class="reference" id="bb0105">Q. Le, Q. Chunjie. Status Quo and Development Trend of World's Citrus Industry. Agricultural Outlook, 12 (2016), 46-52.</div></li></ol></div>`,{runScripts:'outside-only',url:source});
 try{dom.window.eval(fs.readFileSync(path.join(__dirname,'../extension/extractor.js'),'utf8'));return JSON.parse(JSON.stringify(dom.window.SDTypora.extract(dom.window.document,source)));}finally{dom.window.close();}
}
test('b/bb and same-article absolute anchors become local references',()=>{
 const r=capture(),doc=r.index.documents[0],ref=doc.targets.find(t=>t.kind==='reference');
 assert.equal(ref.id,'ref-bb0105');assert.ok(ref.source_ids.includes('b0105'));assert.ok(ref.source_ids.includes('bb0105'));
 assert.equal((r.markdown.match(/\]\(#ref-bb0105\)/g)||[]).length,3);
 assert.equal(doc.citation_links,3);
});
test('figure/table source aliases are retained and resolve without external navigation',()=>{
 const r=capture(),doc=r.index.documents[0];
 assert.match(r.markdown,/\[Fig\. 1\]\(#fig-1\)/);assert.match(r.markdown,/\[Table 1\]\(#tab-1\)/);
 assert.ok(doc.targets.find(t=>t.id==='fig-1').source_ids.includes('f0005'));
 assert.ok(doc.targets.find(t=>t.id==='tab-1').source_ids.includes('t0005'));
 for(const t of doc.targets)assert.equal(r.markdown.split('\n').slice(t.start_line-1,t.end_line).join('\n'),t.content);
});
test('other article links remain external and declared resources survive extraction',()=>{
 const r=capture(),meta=r.index.documents[0].metadata;
 assert.ok(r.markdown.includes('https://www.sciencedirect.com/science/article/pii/OTHER#b0105'));
 assert.ok(r.markdown.includes('https://www.sciencedirect.com/topics/plant'));
 assert.deepEqual(meta.code_urls,['https://github.com/lab/code']);assert.deepEqual(meta.data_urls,['https://doi.org/10.5281/zenodo.1234']);
});
