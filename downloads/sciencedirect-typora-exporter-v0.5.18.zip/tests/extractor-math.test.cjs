const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {JSDOM}=require('jsdom');
const source='https://www.sciencedirect.com/science/article/pii/S0022169422012410';
const extractor=fs.readFileSync(path.join(__dirname,'../extension/extractor.js'),'utf8');
const fraction='<math xmlns="http://www.w3.org/1998/Math/MathML"><mrow><mi>NDVI</mi><mo>=</mo><mfrac><mrow><mi>NIR</mi><mo>−</mo><mi>R</mi></mrow><mrow><mi>NIR</mi><mo>+</mo><mi>R</mi></mrow></mfrac></mrow></math>';
const variable='<math><msub><mi>band</mi><mi>green</mi></msub></math>';
function capture(markup,references=''){
 const dom=new JSDOM(`<meta name="citation_title" content="Mathematical extraction regression"><div id="body"><h2>Method</h2><p>${'A sufficiently detailed scientific article sentence. '.repeat(25)}</p>${markup}</div>${references}`,{runScripts:'outside-only',url:source});
 try{dom.window.eval(extractor);return JSON.parse(JSON.stringify(dom.window.SDTypora.extract(dom.window.document,source)));}finally{dom.window.close();}
}
test('MathML source scripts recover display fractions and inline subscripts',()=>{
 const r=capture(`<div class="display"><span>(1)</span><script type="math/mml; mode=display" id="m1">${fraction}</script></div><p>where <script type="math/mml">${variable}</script> is the green band.</p>`);
 assert.match(r.markdown,/\$\$\nNDVI=\\frac\{NIR-R\}\{NIR\+R\}\n\$\$/);
 assert.match(r.markdown,/where \$\{band\}_\{green\}\$ is the green band/);
 assert.equal(r.report.math,2);assert.equal(r.report.math_display,1);assert.equal(r.report.math_inline,1);
});
test('MathJax 2 HTML/SVG/CHTML and preview copies emit only the associated source',()=>{
 for(const klass of ['MathJax','MathJax_Display','MathJax_SVG','MathJax_SVG_Display','MathJax_CHTML','MathJax_CHTML_Display']){
  const r=capture(`<p>before <span class="MathJax_Preview">${variable}</span><span class="${klass}"><svg></svg><span class="MJX_Assistive_MathML">${variable}</span></span><script type="math/mml">${variable}</script> after <script type="math/tex">z</script></p>`);
  assert.equal((r.markdown.match(/\{band\}_\{green\}/g)||[]).length,1,klass);assert.equal(r.report.math,2);
 }
});
test('independent formulas in the same paragraph are not suppressed by a different TeX script',()=>{
 const r=capture(`<p><span class="MathJax">${variable}</span> plus <script type="math/tex">z</script></p>`);
 assert.match(r.markdown,/\{band\}_\{green\}/);assert.equal(r.report.math,2);
});
test('MathJax 3 SVG plus assistive MathML is retained once',()=>{
 const r=capture(`<mjx-container display="true"><svg></svg><mjx-assistive-mml>${fraction}</mjx-assistive-mml></mjx-container>`);
 assert.equal(r.report.math_display,1);assert.equal((r.markdown.match(/NDVI=/g)||[]).length,1);
});
test('source-free rendered formula fails explicitly instead of silently dropping it',()=>{
 assert.throws(()=>capture('<p>where <span class="MathJax_SVG" id="broken-math"><svg><path d="M0 0"/></svg></span> is temperature.</p>'),/公式缺少.*broken-math/);
});
test('adjacent assistive fallback does not duplicate output',()=>{
 const r=capture(`<span class="MathJax_SVG"><svg/></span><span class="MJX_Assistive_MathML">${variable}</span>`);
 assert.equal(r.report.math,1);
});
test('KaTeX uses TeX annotation without consuming rendered HTML',()=>{
 const r=capture('<span class="katex"><span class="katex-mathml"><math><semantics><mrow><mi>x</mi></mrow><annotation encoding="application/x-tex">x_{a}+1</annotation></semantics></math></span><span class="katex-html">visual duplicate</span></span>');
 assert.match(r.markdown,/\$x_\{a\}\+1\$/);assert.doesNotMatch(r.markdown,/visual duplicate/);assert.equal(r.report.math,1);
});
test('malformed or unsupported MathML fails with source locator',()=>{
 assert.throws(()=>capture('<script type="math/mml" id="bad"><math><msub></math></script>'),/bad.*不完整/);
 assert.throws(()=>capture('<math id="unknown"><maction><mi>x</mi></maction></math>'),/unknown.*maction/);
});
test('namespace-prefixed MathML scripts and native nodes survive',()=>{
 const r=capture('<script type="application/mathml+xml"><m:math xmlns:m="http://www.w3.org/1998/Math/MathML"><m:msup><m:mi>A</m:mi><m:mn>2</m:mn></m:msup></m:math></script><math><mi>x</mi></math>');
 assert.match(r.markdown,/\$\{A\}\^\{2\}\$/);assert.equal(r.report.math,2);
});
test('native display math, TeX scripts, headings and table cell math preserve structure',()=>{
 const r=capture(`<h3>Band ${variable}</h3><script type="math/tex; mode=display">E=mc^2</script><table><tr><th>Variable</th></tr><tr><td>${variable}</td></tr></table>${fraction.replace('<math ','<math display="block" ')}`);
 assert.equal(r.report.math,4);assert.equal(r.report.math_display,2);assert.match(r.markdown,/### Band \$/);
 for(const t of r.index.documents[0].targets)assert.equal(r.markdown.split('\n').slice(t.start_line-1,t.end_line).join('\n'),t.content);
});
test('same source text at different locations is retained at each occurrence',()=>{
 const r=capture(`<p>${variable} and ${variable}</p>`);assert.equal(r.report.math,2);
});
test('complex formula tables use editable Markdown with math and inline markup',()=>{
 const r=capture(`<table><tr><th colspan="2">${variable}</th></tr><tr><td><em>unit</em><sub>c</sub></td><td><script type="math/mml">${variable}</script></td></tr></table>`);
 assert.equal(r.report.math,2);assert.doesNotMatch(r.markdown,/<table|<t[dh]/);assert.match(r.markdown,/\| \$\{band\}_\{green\}\$ \| \$\{band\}_\{green\}\$ \|/);assert.match(r.markdown,/\*unit\*<sub>c<\/sub>/);
});
test('detached DOMParser document supports MathML scripts',()=>{
 const dom=new JSDOM('',{runScripts:'outside-only',url:source});
 try{dom.window.eval(extractor);const d=new dom.window.DOMParser().parseFromString(`<div id="body"><h2>Methods</h2><p>${'Scientific article sentence. '.repeat(50)}</p><script type="math/mml">${variable}</script></div>`,'text/html');assert.equal(dom.window.SDTypora.extract(d,source).report.math,1);}finally{dom.window.close();}
});
test('publisher math wrapper and numbered display container keep block mode',()=>{
 const r=capture(`<div class="display"><span class="label">(2)</span><span class="math">${fraction}</span></div>`);
 assert.equal(r.report.math_display,1);assert.match(r.markdown,/\\tag\{2\}\n\$\$/);assert.doesNotMatch(r.markdown,/\(2\)\n\n\$\$/);
 assert.throws(()=>capture('<span class="math"><svg/></span>'),/公式缺少/);
});
test('publisher equation labels stay inside their own displays and unnumbered displays stay unnumbered',()=>{
 const r=capture('<p>See Eq. (1):</p><div class="formula"><span class="label">(1)</span><script type="math/tex">x=1</script></div><div class="formula"><span class="label">(A2)</span><script type="math/tex; mode=display">y=2\\tag{A2}</script></div><script type="math/tex; mode=display">z=3</script>');
 assert.match(r.markdown,/See Eq\. \(1\):\n\n\$\$\nx=1\\tag\{1\}/);
 assert.equal((r.markdown.match(/\\tag\{A2\}/g)||[]).length,1);
 assert.match(r.markdown,/\$\$\nz=3\n\$\$/);assert.equal(r.report.math_display,3);
});

test('MathML accents and vector/script variants produce valid TeX commands',()=>{
 const r=capture('<p><math><msub><mover accent="true"><mi mathvariant="bold-italic">C</mi><mo>^</mo></mover><mi>c</mi></msub><mo>+</mo><mi mathvariant="script">R</mi></math></p><math><mover><mi>x</mi><mo>~</mo></mover></math>');
 assert.match(r.markdown,/\{\\widehat\{\\boldsymbol\{C\}\}\}_\{c\}\+\\mathcal\{R\}/);
 assert.match(r.markdown,/\\widetilde\{x\}/);assert.doesNotMatch(r.markdown,/\\overset\{\^\}/);
 const other=capture('<math><mover accent="false"><mi>x</mi><mi>n</mi></mover></math>');
 assert.match(other.markdown,/\\overset\{n\}\{x\}/);
});

test('piecewise and loss-function matrix fences grow to enclose every row',()=>{
 for(const [open,close,left,right] of [['{','','\\{','.'],['[',']','[',']']]){
  const r=capture(`<math display="block"><mfenced open="${open}" close="${close}"><mtable><mtr><mtd><mi>x</mi></mtd><mtd><mi>a</mi></mtd></mtr><mtr><mtd><mi>y</mi></mtd><mtd><mi>b</mi></mtd></mtr></mtable></mfenced></math>`);
  assert.ok(r.markdown.includes('\\left'+left+'\\begin{matrix}x & a \\\\ y & b\\end{matrix}\\right'+(right==='.'?' .':right)));
 }
});

test('triple-b ScienceDirect reference labels map body citations to the indexed bibliography',()=>{
 const r=capture(`<p><a href="#bb0030" name="bbb0030">Zhang et al., 2024</a></p>`,`<ol id="references"><li id="rf0030"><span class="label"><a id="ref-id-bb0030" href="#bbb0030">Zhang et al., 2024</a></span><div class="reference">Zhang. A study of plants. 2024.</div></li></ol>`);
 const target=r.index.documents[0].targets.find(t=>t.kind==='reference');
 assert.ok(target);assert.ok(target.source_ids.includes('bbb0030'));assert.ok(target.source_ids.includes('bb0030'));
 assert.ok(r.markdown.includes(`[Zhang et al., 2024](#${target.id})`));assert.equal(r.index.documents[0].citation_links,1);
});
module.exports={capture};
