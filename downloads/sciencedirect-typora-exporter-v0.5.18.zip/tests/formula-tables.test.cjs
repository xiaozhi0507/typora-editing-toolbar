const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {JSDOM}=require('jsdom');
const url='https://www.sciencedirect.com/science/article/pii/S1569843223004417';
const code=fs.readFileSync(path.join(__dirname,'../extension/extractor.js'),'utf8');
function capture(markup){
 const dom=new JSDOM(`<meta name="citation_title" content="Formula table regression"><div id="body"><h2>Methods</h2><p>${'Scientific measurements were compared across multiple wavelength bands. '.repeat(25)}</p><div class="tables" id="t0010"><div class="captions"><span class="label">Table 2</span>. Indices.</div>${markup}</div></div><ol id="references"><li><div class="reference" id="bb0020">Carter, 1994. Reference.</div></li></ol>`,{url,runScripts:'outside-only'});
 try{dom.window.eval(code);return JSON.parse(JSON.stringify(dom.window.SDTypora.extract(dom.window.document,url)));}finally{dom.window.close();}
}
test('row-spanning index families and citations remain in the correct formula columns',()=>{
 const result=capture('<table><thead><tr><td></td><th>Index</th><th>Formula</th><th>Reference</th></tr></thead><tbody><tr><td rowspan="2"><script type="math/tex">SR</script></td><td>SR1</td><td><script type="math/tex">\\rho_{750}/\\rho_{710}</script></td><td><a href="#bb0020">Carter, 1994</a></td></tr><tr><td>SR2</td><td><math><mfrac><mi>a</mi><mi>b</mi></mfrac></math></td><td><a href="#bb0020">Carter, 1994</a></td></tr><tr><td></td><td>Other</td><td>1</td><td></td></tr></tbody></table>');
 assert.doesNotMatch(result.markdown,/<table|rowspan/);
 assert.match(result.markdown,/\| \$SR\$ \| SR1 \| \$\\rho_\{750\}\/\\rho_\{710\}\$ \| \[Carter, 1994\]\(#ref-bb0020\) \|/);
 assert.match(result.markdown,/\| \$SR\$ \| SR2 \| \$\\frac\{a\}\{b\}\$ \| \[Carter, 1994\]\(#ref-bb0020\) \|/);
 assert.match(result.markdown,/\|  \| Other \| 1 \|  \|/);
 assert.equal(result.report.math,3);assert.equal(result.report.unresolved_links.length,0);
 for(const t of result.index.documents[0].targets)assert.equal(result.markdown.split('\n').slice(t.start_line-1,t.end_line).join('\n'),t.content);
});
test('display math in cells becomes a single inline formula without breaking rows',()=>{
 const result=capture('<table><tr><th>Formula</th></tr><tr><td><script type="math/tex; mode=display">\\frac{a}{b}\n+ c</script></td></tr></table>');
 assert.match(result.markdown,/\| \$\\frac\{a\}\{b\} \+ c\$ \|/);assert.doesNotMatch(result.markdown,/\$\$/);
 assert.equal(result.report.math,1);
});
test('rowspan zero stops at row group boundary, headers do not duplicate across vertical spans',()=>{
 const result=capture('<table><thead><tr><th rowspan="2">Group</th><th colspan="2">Values</th></tr><tr><th>A</th><th>B</th></tr></thead><tbody><tr><td rowspan="0">One</td><td><script type="math/tex">x</script></td><td>2</td></tr><tr><td>3</td><td>4</td></tr></tbody><tbody><tr><td>Two</td><td>5</td><td>6</td></tr></tbody></table>');
 assert.match(result.markdown,/\| Group \| Values<br>A \| Values<br>B \|/);
 assert.match(result.markdown,/\| One \| 3 \| 4 \|/);assert.match(result.markdown,/\| Two \| 5 \| 6 \|/);
});
test('pipes and paragraph breaks inside math tables cannot add columns or rows',()=>{
 const result=capture('<table><tr><th>Label</th><th>Formula</th></tr><tr><td>A | B<br>note</td><td><script type="math/tex">|x| + \\|v\\|</script></td></tr></table>');
 assert.match(result.markdown,/A \\\| B<br>note/);assert.match(result.markdown,/\$\\vert x\\vert  \+ \\Vert v\\Vert \$/);
});
