/* Runs only on the article selected by the user. No page scripts or account data are exported. */
(() => {
  'use strict';
  const text = n => (n?.textContent || '').replace(/\s+/g, ' ').trim();
  // Typora treats backslash-square-brackets as TeX delimiters; entities stay literal.
  const esc = s => String(s).replace(/&/g,'&amp;').replace(/([\\`*_<>])/g, '\\$1').replace(/\[/g,'&#91;').replace(/\]/g,'&#93;');
  const attr = s => String(s).replace(/[&"<>]/g, c => ({'&':'&amp;','"':'&quot;','<':'&lt;','>':'&gt;'}[c]));
  const safeName = s => s.replace(/[<>:"/\\|?*\x00-\x1f]/g,' ').replace(/\s+/g,' ').replace(/[. ]+$/,'').slice(0,110).trim() || 'Article';
  const clean = s => s.replace(/[ \t]+\n/g,'\n').replace(/\n{3,}/g,'\n\n').trim();
  const center = s => '<span style="display:inline-block;width:100%;text-align:center;text-indent:0;">'+s+'</span>';
  // Typora inline HTML cannot span Markdown paragraphs. Keep each caption paragraph editable.
  const centerCaption = s => clean(s).split(/\n\s*\n/).filter(Boolean).map(center).join('\n\n');
  const hashID = s => s.replace(/[^a-zA-Z0-9_-]/g,'-');
  // HTML blocks do not parse $TeX$ in Typora. Expand formula tables into an
  // editable grid, repeating merged labels so each row keeps its meaning.
  function tableMarkdown(table, convertCell) {
    const rows=[...table.rows],grid=rows.map(()=>[]);
    if(!rows.length)return '';
    let width=0;
    for(let r=0;r<rows.length;r++){
      let column=0;
      for(const cell of rows[r].cells){
        while(grid[r][column])column++;
        let groupEnd=r+1;
        while(groupEnd<rows.length&&rows[groupEnd].parentElement===rows[r].parentElement)groupEnd++;
        const height=cell.rowSpan===0?groupEnd-r:Math.min(cell.rowSpan,groupEnd-r),span=cell.colSpan;
        if((column+span)*rows.length>50000)throw Error('表格过大，无法安全展开合并单元格。');
        const value=clean(convertCell(cell))
          .replace(/\$\$\s*([\s\S]*?)\s*\$\$/g,(_,tex)=>'$'+tex.replace(/\n+/g,' ').trim()+'$')
          // A Markdown escape inside TeX would turn |x| into the norm \|x\|.
          .replace(/\$([^$]+)\$/g,(_,tex)=>'$'+tex.replace(/\\(?:[a-zA-Z]+|.)|\|/g,token=>token==='|'?'\\vert ':token==='\\|'?'\\Vert ':token)+'$')
          .replace(/\|/g,'\\|').replace(/\n+/g,'<br>');
        const entry={value};
        for(let y=r;y<r+height;y++)for(let x=column;x<column+span;x++){
          if(grid[y][x])throw Error('表格合并单元格重叠，已停止导出，避免错列。');
          grid[y][x]=entry;
        }
        column+=span;width=Math.max(width,column);
      }
    }
    const headerCount=table.tHead?.rows.length||1;
    const header=Array.from({length:width},(_,c)=>{
      const seen=new Set(),labels=[];
      for(let r=0;r<headerCount;r++){
        const entry=grid[r][c];if(!entry||seen.has(entry))continue;
        seen.add(entry);if(entry.value)labels.push(entry.value);
      }
      return labels.join('<br>');
    });
    const line=values=>'| '+values.join(' | ')+' |';
    return [line(header),line(Array(width).fill('---')),...grid.slice(headerCount).map(row=>line(Array.from({length:width},(_,c)=>row[c]?.value||'')))].join('\n');
  }
  // Classify the paper's own resource statements, never by hosting domain alone.
  function extractResources(doc, sourceURL) {
    const excluded='#references,.references,.reference,.bibliography,.ReferenceLinks,nav,aside';
    const availability=/\b(?:(?:code|data|software|materials?|resources?)\s+(?:and\s+(?:code|data)\s+)?availability|availability\s+of\s+(?:data|code|software))\b/i;
    const resources=[],statements=[],seen=new Set(),blocks=new Map();
    const collect=(root,heading='')=>{
      if(!root||root.closest(excluded))return;
      const selector='p,div.para,div[id^="sp"],div[id^="p0"],li';
      const parts=[...(root.matches(selector)?[root]:[]),...root.querySelectorAll(selector)].filter(n=>!n.closest(excluded)&&!n.querySelector(selector));
      for(const n of parts.length?parts:[root])if(!blocks.has(n)||heading)blocks.set(n,heading);
    };
    collect(doc.querySelector('#abstracts'));collect(doc.querySelector('#body'));
    // Publishers may place availability and footnotes after, rather than inside, #body.
    for(const h of doc.querySelectorAll('h2,h3,h4')){
      if(h.closest(excluded)||!availability.test(text(h)))continue;
      const section=h.closest('section');
      if(section)collect(section,text(h));
      else for(let n=h.nextElementSibling;n&&!/^H[1-6]$/.test(n.tagName);n=n.nextElementSibling)collect(n,text(h));
    }
    for(const root of doc.querySelectorAll('#article-footnotes,#footnotes,.article-footnotes'))collect(root);
    const kinds=s=>{
      const out=[];
      if(/\b(?:codes?|implementation|software|scripts?)\b|代码|源码/i.test(s))out.push('code');
      if(/\b(?:data|datasets?)\b|数据/i.test(s))out.push('data');
      return out;
    };
    // Carry the explicit release statement into its linked footnote, not an unrelated nearby URL.
    for(const [block] of [...blocks])for(const a of block.querySelectorAll('a[href^="#"]')){
      const range=doc.createRange();range.selectNodeContents(block);range.setEndBefore(a);
      const prefix=range.toString().replace(/\s+/g,' ').split(/(?<=[.!?])\s+(?=[A-Z])/).at(-1);
      const types=kinds(prefix);
      if(!types.length||!/\b(?:availab\w*|releas\w*|access\w*|download\w*|found\s+(?:at|on))\b/i.test(prefix))continue;
      let id;try{id=decodeURIComponent(a.getAttribute('href').slice(1));}catch{continue;}
      const target=doc.getElementById(id);
      if(target&&!target.closest(excluded)&&target.matches('.footnote,[id^="fn"],[id^="nt"],li'))collect(target,types.join(' and ')+' availability');
    }
    const normalize=raw=>{
      raw=raw.trim().replace(/[.,;:!，。；：]+$/,'');
      while(raw.endsWith(')')&&(raw.match(/\)/g)||[]).length>(raw.match(/\(/g)||[]).length)raw=raw.slice(0,-1);
      try{const u=new URL(/^www\./i.test(raw)?'https://'+raw:raw,sourceURL);return /^https?:$/.test(u.protocol)&&!u.username&&!u.password?u.href:null;}catch{return null;}
    };
    for(const [block,heading] of blocks){
      const copy=block.cloneNode(true),links=[];
      copy.querySelectorAll(excluded+',script,style,button').forEach(n=>n.remove());
      const token=(raw,label='')=>{const url=normalize(raw);if(!url)return label;const id=links.push({url,label})-1;return ` SDRESOURCE${id} `;};
      for(const a of copy.querySelectorAll('a[href]')){
        const raw=a.getAttribute('href'),label=text(a);
        if(!raw||!/^https?:\/\/|^\/\//i.test(raw))continue;
        a.replaceWith((/^https?:\/\/|^www\./i.test(label)?'':label+' ')+token(raw,label));
      }
      const plain=text(copy).replace(/(?:https?:\/\/|www\.)[^\s<>"\u201c\u201d]+/gi,url=>token(url));
      const original=text(block);
      if(heading&&original)statements.push({heading,text:original.slice(0,1600)});
      let previousKinds=[];
      for(const sentence of plain.split(/(?<=[.!?。！？])\s+(?=[A-Z\u4e00-\u9fff])|[;；\n]+/)){
        previousKinds=[];let end=0;
        for(const match of sentence.matchAll(/SDRESOURCE(\d+)/g)){
          const link=links[Number(match[1])],prefix=sentence.slice(end,match.index),whole=sentence.replace(/SDRESOURCE\d+/g,'[link]');end=match.index+match[0].length;
          if(!link)continue;
          // A quoted/cited implementation and a resource used as input are not this paper's release.
          if(/\b(?:we\s+(?:use|used|adopt|adopted|follow|followed|employ|employed|utilize|utilized)|third[- ]party|baseline|previous\s+work|proposed\s+by|using\s+the\s+.{0,80}(?:tool|software))\b|\(\s*[^)]*\b(?:19|20)\d{2}[a-z]?\s*\)|\[\d+(?:[,–-]\d+)*\]/i.test(whole))continue;
          const clauses=prefix.split(/,\s*(?=(?:and\s+)?(?:the\s+|our\s+)?(?:code|data|dataset|software)\b)|\b(?:whereas|while)\b/i);
          let selected=kinds(clauses[clauses.length-1]);
          if(!selected.length)selected=kinds(link.label);
          if(!selected.length)selected=previousKinds.length?previousKinds:kinds(heading);
          const declared=/\b(?:availab\w*|releas\w*|access\w*|download\w*|public\w*|open[- ]source|provid\w*|found\s+(?:at|on)|our\s+(?:code|data|implementation))\b|开源|公开|发布|可用|下载/i.test(whole);
          if(!selected.length||!(declared||heading||/^(?:source\s+code|code|data|dataset|software)$/i.test(link.label)))continue;
          previousKinds=selected;
          for(const kind of selected){
            const key=kind+'|'+link.url;if(seen.has(key))continue;seen.add(key);
            const evidence=sentence.replace(/SDRESOURCE(\d+)/g,(_,n)=>links[Number(n)]?.url||'').trim().slice(0,1600);
            resources.push({kind,url:link.url,heading:heading||null,locator:block.id?'#'+block.id:null,evidence});
          }
        }
      }
    }
    return {code_urls:resources.filter(r=>r.kind==='code').map(r=>r.url),data_urls:resources.filter(r=>r.kind==='data').map(r=>r.url),resources,statements:[...new Map(statements.map(s=>[s.heading+'|'+s.text,s])).values()]};
  }
  const mathName = n => n.localName?.toLowerCase().split(':').pop();
  const texEscape = s => String(s).replace(/\\/g,'\\backslash ').replace(/([#$%&_{}])/g,'\\$1');
  function mathTex(n, warnings=[]) {
    if(n.nodeType===3)return texEscape(n.nodeValue);
    const tag=mathName(n);
    const elements=[...n.children||[]];
    if(tag==='semantics'){
      const annotation=elements.find(x=>mathName(x)==='annotation'&&/^(?:application\/x-tex|application\/x-latex|text\/x-tex|TeX|LaTeX)$/i.test(x.getAttribute('encoding')||''));
      if(annotation?.textContent.trim())return annotation.textContent.trim();
      const presentation=elements.find(x=>!['annotation','annotation-xml'].includes(mathName(x)));
      if(presentation)return mathTex(presentation,warnings);
      const alternative=elements.find(x=>mathName(x)==='annotation-xml'&&/MathML-Presentation/i.test(x.getAttribute('encoding')||''));
      if(alternative)return [...alternative.children].map(x=>mathTex(x,warnings)).join('');
      throw Error('MathML semantics 缺少可转换的公式');
    }
    if(['annotation','annotation-xml'].includes(tag))return '';
    const children=[...n.childNodes].filter(x=>x.nodeType===1||x.nodeType===3&&x.nodeValue.trim());
    const arity={mfrac:2,mroot:2,msub:2,msup:2,msubsup:3,mover:2,munder:2,munderover:3};
    if(arity[tag]&&children.length!==arity[tag])throw Error('MathML '+tag+' 的子元素不完整');
    const xs=children.map(x=>mathTex(x,warnings)), x=i=>xs[i]||'';
    if(['math','mrow','mstyle','mpadded','mtd'].includes(tag))return xs.join('');
    if(tag==='mfrac')return `\\frac{${x(0)}}{${x(1)}}`;
    if(tag==='msqrt')return `\\sqrt{${xs.join('')}}`;
    if(tag==='mroot')return `\\sqrt[${x(1)}]{${x(0)}}`;
    if(tag==='msub')return `{${x(0)}}_{${x(1)}}`;
    if(tag==='msup')return `{${x(0)}}^{${x(1)}}`;
    if(tag==='msubsup')return `{${x(0)}}_{${x(1)}}^{${x(2)}}`;
    if(tag==='mover'){
      const accent={'^':'widehat','ˆ':'widehat','̂':'widehat','~':'widetilde','˜':'widetilde','̃':'widetilde','¯':'overline','‾':'overline','→':'vec','˙':'dot','˙˙':'ddot','¨':'ddot'}[children[1]?.textContent.trim()];
      if(accent&&n.getAttribute('accent')!=='false')return `\\${accent}{${x(0)}}`;
      return `\\overset{${x(1)}}{${x(0)}}`;
    }
    if(tag==='munder')return `\\underset{${x(1)}}{${x(0)}}`;
    if(tag==='munderover')return `\\overset{${x(2)}}{\\underset{${x(1)}}{${x(0)}}}`;
    if(tag==='mfenced'){
      const separators=(n.getAttribute('separators')??',').replace(/\s/g,'');
      const open=n.getAttribute('open')??'(',close=n.getAttribute('close')??')';
      const inner=xs.map((s,i)=>(i?texEscape(separators[Math.min(i-1,separators.length-1)]||''):'')+s).join('');
      const fences={'':' .','(':'(',')':')','[':'[',']':']','{':'\\{','}':'\\}','|':'|','‖':'\\Vert ','⟨':'\\langle ','⟩':'\\rangle '};
      if(elements.some(e=>mathName(e)==='mtable')&&open in fences&&close in fences)return '\\left'+fences[open]+inner+'\\right'+fences[close];
      return texEscape(open)+inner+texEscape(close);
    }
    if(tag==='mtable')return '\\begin{matrix}'+xs.join(' \\\\ ')+'\\end{matrix}';
    if(tag==='mtr')return xs.join(' & ');
    if(tag==='mspace')return '\\, ';
    if(tag==='mphantom')return '\\phantom{'+xs.join('')+'}';
    if(tag==='mtext'||tag==='ms')return '\\text{'+texEscape(n.textContent.replace(/\s+/g,' '))+'}';
    if(['mi','mn','mo'].includes(tag)){
      const operators={'−':'-','×':'\\times ','÷':'\\div ','⋅':'\\cdot ','·':'\\cdot ','≤':'\\le ','≥':'\\ge ','≠':'\\ne ','∞':'\\infty ','∑':'\\sum ','∏':'\\prod ','∫':'\\int ','∂':'\\partial ','∇':'\\nabla ','∈':'\\in ','±':'\\pm ','→':'\\to ','^':'\\text{\\textasciicircum}','⁢':'','⁡':'',' ':'\\, '};
      let result=[...n.textContent].map(c=>operators[c]??texEscape(c)).join('');
      const variant=n.getAttribute('mathvariant');
      if(variant==='normal'&&tag==='mi')result='\\mathrm{'+result+'}';
      if(variant==='bold')result='\\mathbf{'+result+'}';
      if(variant==='bold-italic')result='\\boldsymbol{'+result+'}';
      if(variant==='script')result='\\mathcal{'+result+'}';
      if(variant==='double-struck')result='\\mathbb{'+result+'}';
      return result;
    }
    // Joining unknown nodes silently can turn an equation into a different one.
    throw Error('未支持的 MathML 元素：'+tag);
  }
  const mathScript = n => mathName(n)==='script'&&/^(?:math\/(?:tex|mml)|application\/mathml\+xml)(?:\s*;|\s*$)/i.test(n.getAttribute('type')||'');
  const mathPresentation = n => n?.matches?.('.MathJax,.MathJax_Display,.MathJax_SVG,.MathJax_SVG_Display,.MathJax_CHTML,.MathJax_CHTML_Display,.MathJax_Preview,.MJX_Assistive_MathML,mjx-container,mjx-assistive-mml,.katex,.katex-display');
  const descendantMath = n => [...n.querySelectorAll('*')].find(x=>mathName(x)==='math');
  function adjacentMathScript(n) {
    for(const direction of ['nextSibling','previousSibling']){
      for(let sibling=n[direction];sibling;sibling=sibling[direction]){
        if(sibling.nodeType===8||sibling.nodeType===3&&!sibling.nodeValue.trim())continue;
        if(sibling.nodeType!==1)break;
        if(mathScript(sibling)){
          const frameID=n.id?.replace(/-Frame$/,'');
          if(/^MathJax-Element-/.test(frameID)&&sibling.id&&frameID!==sibling.id)break;
          return sibling;
        }
        if(!mathPresentation(sibling))break;
      }
    }
    return null;
  }
  function createMathReader(doc, runtime=null) {
    const emitted=new WeakSet(),aliases=new WeakMap(),sources=new Map(),stats={inline:0,display:0};
    const runtimeSources=new WeakMap(),runtimeOrigins=new WeakSet();
    const signature=node=>{const html=node.outerHTML;let hash=2166136261;for(let i=0;i<html.length;i++)hash=Math.imul(hash^html.charCodeAt(i),16777619);return html.length+':'+(hash>>>0).toString(16);};
    for(const row of runtime?.sources||[]){
      if(!Array.isArray(row.path)||row.path.length>100||!['MathML','TeX'].includes(row.type)||typeof row.source!=='string'||row.source.length>200000)throw Error('网页公式源记录无效，请刷新论文后重试。');
      let node=doc.documentElement;
      for(const i of row.path){if(!Number.isInteger(i)||i<0){node=null;break;}node=node?.children[i];}
      if(!node||node.localName!==row.tag||signature(node)!==row.signature)throw Error('读取期间网页公式发生变化，请等待排版完成后重试。');
      if(!mathPresentation(node)||runtimeSources.has(node))throw Error('网页公式源定位不唯一，已停止保存。');
      const source=doc.createElement('script');source.type=row.type==='TeX'?'math/tex':'math/mml';source.textContent=row.source;
      runtimeSources.set(node,{source,display:!!row.display});runtimeOrigins.add(source);
    }
    function read(n) {
      const native=mathName(n)==='math',script=mathScript(n),presentation=!native&&!script&&mathPresentation(n);
      const htmlWrapper=!native&&!script&&!presentation&&n.matches('.math');
      if(!native&&!script&&!presentation&&!htmlWrapper)return null;
      const displayContainer=n.closest('.formula,.display,.equation');
      const number=displayContainer&&text(displayContainer.querySelector('.label')).match(/^\(?([A-Z]?\d+[a-z]?)\)?$/i)?.[1];
      const numberedDisplay=!!number;
      if(htmlWrapper){
        // `.math` is also publisher styling for ordinary HTML ions and units.
        // Traverse it normally so text, subscripts, images and each separate source survive.
        let nested=false,readable=false;
        const supported=child=>{
          if(child.nodeType===3){readable ||= !!child.nodeValue.trim();return true;}
          if(child.nodeType!==1)return true;
          if(mathName(child)==='math'||mathScript(child)||mathPresentation(child)||child.matches('.math')){nested=true;return true;}
          if(mathName(child)==='img'){const hasSource=!!(child.getAttribute('src')||child.getAttribute('data-src'));readable ||= hasSource;return hasSource;}
          if(!['span','i','em','b','strong','sub','sup','br','a'].includes(mathName(child)))return false;
          return [...child.childNodes].every(supported);
        };
        if(![...n.childNodes].every(supported)||!nested&&!readable)throw Error('公式缺少可读取的 MathML/TeX 或 HTML 内容：'+(n.id||n.closest('[id]')?.id||'math')+'。当前显示结构无法完整保存。');
        if(!nested&&!emitted.has(n)){emitted.add(n);sources.set(n,{kind:'HTML',display:numberedDisplay,source_id:n.id||null});stats[numberedDisplay?'display':'inline']++;}
        return null;
      }
      // MathJax 2 renders a sibling before its source script; emit at the source once.
      const adjacent=presentation&&adjacentMathScript(n);
      if(adjacent){for(const child of n.querySelectorAll('*'))if(mathName(child)==='math')aliases.set(child,adjacent);return '';}
      let source=n,display=n.getAttribute('display')==='block'||n.matches('.MathJax_Display,.MathJax_SVG_Display,.MathJax_CHTML_Display,.katex-display')||n.getAttribute('display')==='true';
      display ||= numberedDisplay;
      if(presentation){
        source=[...n.querySelectorAll('script')].find(mathScript)||descendantMath(n);
        if(!source){
          // Some renderers put assistive MathML beside their SVG, rather than inside it.
          const sibling=[n.nextElementSibling,n.previousElementSibling].find(s=>s?.matches?.('.MJX_Assistive_MathML,mjx-assistive-mml')&&descendantMath(s));
          source=sibling&&descendantMath(sibling);
        }
        if(!source){
          const candidates=[n,...n.querySelectorAll('*')].map(node=>runtimeSources.get(node)).filter(Boolean);
          if(candidates.length>1)throw Error('同一渲染容器对应多个公式源，已停止保存，避免合并公式。');
          const saved=candidates[0];if(saved){source=saved.source;display ||= saved.display;}
        }
        if(!source)throw Error('公式缺少可读取的 MathML/TeX：'+(n.id||n.className||mathName(n))+'。'+(runtime?'网页 DOM 和 MathJax 运行时均未提供可读取的公式源，请保留此页用于检查。':'尚未读取网页 MathJax 运行时公式源，请重新加载扩展后重试。'));
        for(const child of n.querySelectorAll('*'))if(mathName(child)==='math'&&child!==source)aliases.set(child,source);
      }
      if(emitted.has(source))return '';
      let latex,kind='MathML',math=source;
      try{
        if(mathScript(source)){
          const type=source.getAttribute('type');display ||= /mode\s*=\s*display/i.test(type);
          if(/^math\/tex/i.test(type)){latex=source.textContent.trim();kind='TeX';}
          else{
            const xml=source.textContent.trim();
            if(/<!DOCTYPE|<!ENTITY/i.test(xml))throw Error('公式包含不支持的 XML 声明');
            const Parser=doc.defaultView?.DOMParser||globalThis.DOMParser;
            const parsed=new Parser().parseFromString(xml,'application/xml');
            if(parsed.getElementsByTagName('parsererror').length||mathName(parsed.documentElement)!=='math')throw Error('MathML 源码不完整');
            math=parsed.documentElement;
          }
        }
        if(latex===undefined){display ||= math.getAttribute('display')==='block';latex=mathTex(math);}
        if(!latex.trim())throw Error('公式内容为空');
      }catch(error){throw Error('无法完整保存公式 '+(source.id||n.id||'(无编号)')+'：'+error.message);}
      emitted.add(source);sources.set(source,{kind,display,source_id:source.id||n.id||null,runtime:runtimeOrigins.has(source)});stats[display?'display':'inline']++;
      if(display&&number&&!/\\tag\*?\s*\{/.test(latex))latex+='\\tag{'+number+'}';
      return display?'\n\n$$\n'+latex+'\n$$\n\n':'$'+latex+'$';
    }
    function verify(roots){
      for(const root of roots.filter(Boolean))for(const n of [root,...root.querySelectorAll('*')]){
        if(mathName(n)!=='math'&&!mathScript(n))continue;
        // Source and rendered/assistive copies represent one occurrence.
        let wrapper=n.parentElement;while(wrapper&&wrapper!==root){if(mathPresentation(wrapper))break;wrapper=wrapper.parentElement;}
        if(wrapper&&mathPresentation(wrapper)){
          const sibling=adjacentMathScript(wrapper);
          if(sibling&&emitted.has(sibling))continue;
        }
        if(!emitted.has(n)&&!emitted.has(aliases.get(n)))throw Error('公式未被完整导出：'+(n.id||mathName(n))+'，已停止保存，避免遗漏公式。');
      }
    }
    return {read,verify,stats,sources};
  }
  async function prepare(doc=document) {
    const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
    const group=doc.querySelector('#author-group,.author-group'),abstracts=doc.querySelector('#abstracts');
    const labels=()=>new Set([...doc.querySelectorAll('.affiliation dt,.affiliation .label')].map(n=>text(n).toLowerCase()));
    const expected=[...new Set([...(group?.querySelectorAll('.author-ref sup')||[])].flatMap(n=>text(n).toLowerCase().split(/[,;\s]+/)).filter(v=>/^[a-z]{1,2}$/.test(v)))];
    const ready=()=>[...doc.querySelectorAll('.affiliation')].some(n=>text(n).length>12)&&expected.every(v=>labels().has(v));
    if(!ready()){
      const more=n=>/^(?:show\s+more|显示更多|展开更多)$/i.test(text(n))&&!n.disabled;
      let expand=null,scope=group;
      for(let level=0;scope&&level<4&&!expand;level++,scope=scope.parentElement)expand=[...scope.querySelectorAll('button,a[role="button"]')].find(more);
      // The current publisher layout places Show more next to, rather than inside, #author-group.
      expand ||= [...doc.querySelectorAll('button,a[role="button"]')].find(n=>more(n)&&abstracts&&(n.compareDocumentPosition(abstracts)&4));
      if(expand){
        expand.click();
        const end=Date.now()+8000;let stableAt=0;
        while(Date.now()<end){if(ready()){stableAt ||= Date.now();if(Date.now()-stableAt>=350)break;}else stableAt=0;await sleep(100);}
      }
      if((expand||expected.length)&&!ready())throw Error('作者单位尚未加载完整，请在论文页展开 Show more 后重试。');
    }
    const refs=doc.querySelector('#references'),button=refs&&[...refs.querySelectorAll('button')].find(b=>/show (?:all|more) references/i.test(text(b)));
    if(button){button.click();await sleep(700);}
  }
  function extract(doc=document, url=location.href, runtimeMath=null) {
    const source=new URL(url);if(source.hostname!=='www.sciencedirect.com'||!/^\/science\/article\/pii\//.test(source.pathname))throw Error('请在 ScienceDirect 论文详情页点击扩展。');
    const body=doc.querySelector('#body');if(!body||text(body).length<1000||!body.querySelector('h2,h3'))throw Error('当前页面尚未显示完整正文。请先在原网页打开全文并完成正常登录或验证，再重新导出。');
    const meta = key => doc.querySelector(`meta[name="citation_${key}"]`)?.content || '';
    const title=meta('title')||text(doc.querySelector('h1')),pii=meta('pii')||source.pathname.split('/').pop();
    const stem=safeName(title)+'_English',assetDir='_assets/'+hashID(pii),sourceURL=source.origin+source.pathname;
    const roots=[doc.querySelector('#abstracts'),doc.querySelector('.keywords'),body];
    const after=body.nextElementSibling;if(after&&after.id!=='references'&&after.querySelector('h2'))roots.push(after);
    const refs=doc.querySelector('#references'),warnings=[],assets=[],targets=[],bibliography=[],idMap=new Map(),registered=new WeakMap(),usedIDs=new Set(),imageMap=new Map();
    const nodes=selector=>roots.filter(Boolean).flatMap(r=>[...(r.matches(selector)?[r]:[]),...r.querySelectorAll(selector)]);
    const ambiguousIDs=new Set();
    const targetKey=value=>{if(typeof value!=='string'||!value)return null;try{if(value.startsWith('#'))return decodeURIComponent(value.slice(1));if(/^(?:https?:|\/)/.test(value)){const u=new URL(value,sourceURL);return u.origin+u.pathname===sourceURL&&!u.search&&u.hash?decodeURIComponent(u.hash.slice(1)):null;}return value;}catch{return null;}};
    const referenceAliases=key=>{const m=key.match(/^(?:b{1,3}|b?bib|sbref)(\d+)$/i);return m?[key,...(/^(?:b?bib|sbref)/i.test(key)?['bib','bbib','sbref']:['b','bb','bbb']).map(p=>p+m[1])]:[key];};
    const mapTarget=(node,kind,id,aliases=[])=>{let final=id,n=2;while(usedIDs.has(final))final=id+'-'+n++;usedIDs.add(final);const keys=[...new Set([node.id,...aliases].map(targetKey).filter(Boolean).flatMap(key=>kind==='reference'?referenceAliases(key):[key]))];registered.set(node,{kind,id:final,source_ids:keys});for(const key of keys){if(ambiguousIDs.has(key))continue;if(idMap.has(key)&&idMap.get(key)!==final){idMap.delete(key);ambiguousIDs.add(key);}else idMap.set(key,final);}return final;};
    for(const f of nodes('figure')){const label=text(f.querySelector('.label'))||f.querySelector('img')?.alt||'Graphical abstract',num=label.match(/(?:Fig(?:ure)?\.?\s*)([\w.-]+)/i)?.[1];mapTarget(f,'figure','fig-'+(num||'graphical-abstract'),[...f.querySelectorAll('[id]')].map(x=>x.id));}
    for(const t of nodes('.tables')){const num=text(t.querySelector('.label')).match(/Table\s+([\w.-]+)/i)?.[1]||String(nodes('.tables').indexOf(t)+1);mapTarget(t,'table','tab-'+num,[...t.querySelectorAll('.captions [id]')].map(x=>x.id));}
    for(const h of nodes('h2,h3,h4,h5,h6')){const section=h.parentElement?.tagName==='SECTION'?h.parentElement.id:'';const slug=text(h).toLowerCase().replace(/[^\p{L}\p{N}\s_-]/gu,'').replace(/\s/g,'-');mapTarget(h,'section',slug||'section',section?[section]:[]);}
    const referenceRows=refs?[...refs.querySelectorAll('li')].filter(li=>li.querySelector('.reference')):[];
    for(const li of referenceRows){const r=li.querySelector('.reference'),label=li.querySelector('.label a'),raw=targetKey(label?.getAttribute('href'))||r.id;mapTarget(li,'reference','ref-'+hashID(raw),[raw,r.id,...[...li.querySelectorAll('[id]')].map(x=>x.id)]);}
    function asset(urls,kind){
      const candidates=[...new Set(urls.filter(Boolean).map(u=>new URL(u,sourceURL).href))];
      for(const u of candidates)if(!/^https:\/\/(?:ars\.els-cdn\.com|www\.sciencedirect\.com)\//.test(u))throw Error('未下载来源不明的资源：'+u);
      const key=candidates[0];if(imageMap.has(key))return imageMap.get(key);
      const ext=new URL(key).pathname.match(/\.(png|jpe?g|gif|webp|svg|pdf|docx?|xlsx?|zip)$/i)?.[1]?.toLowerCase()||'bin';
      const path=assetDir+'/'+String(assets.length+1).padStart(3,'0')+'-'+kind+'.'+ext;
      assets.push({path,urls:candidates,kind});imageMap.set(key,path);return path;
    }
    function imageSources(img,scope=img.closest('.article-attachment,figure')){
      const src=img.getAttribute('src')||img.getAttribute('data-src');if(!src)return [];
      const key=value=>{try{const u=new URL(value,sourceURL);return u.origin+u.pathname.replace(/(?:_lrg)?\.(?:sml|png|jpe?g|gif|webp|svg)$/i,'');}catch{return '';}};
      const original=new URL(src,sourceURL),links=[...(scope?.querySelectorAll('a[href]')||[])].filter(a=>{
        const href=a.getAttribute('href');return /\.(?:png|jpe?g|gif|webp|svg)(?:[?#]|$)/i.test(href)&&key(href)===key(src);
      });
      links.sort((a,b)=>Number(/high-res|_lrg\./i.test(b.title+' '+b.textContent+' '+b.getAttribute('href')))-Number(/high-res|_lrg\./i.test(a.title+' '+a.textContent+' '+a.getAttribute('href'))));
      if(/\.sml$/i.test(original.pathname)&&!links.length)throw Error('图片只有缩略图地址，未找到可下载的原图链接：'+original.pathname.split('/').pop());
      return [...links.map(a=>a.getAttribute('href')),src];
    }
    function link(node){
      const label=clean(convertChildren(node)),raw=node.getAttribute('href');if(!raw||!label)return label;
      const key=targetKey(raw);if(raw.startsWith('#')||key&&/^(?:https?:|\/)/.test(raw)){if(idMap.has(key))return `[${label}](#${idMap.get(key)})`;if(supplementLinks.has(key))return `[${label}](<${asset([supplementLinks.get(key)],'supplement')}>)`;warnings.push(/^spnsr/.test(key||'')?'致谢中的资助机构链接保留为原网页链接。':'链接保留到原网页：'+text(node).slice(0,80));return `[${label}](<${new URL(raw,sourceURL).href.replace(/>/g,'%3E')}>)`;}
      let u;try{u=new URL(raw,sourceURL);}catch{return label;}if(!['http:','https:','mailto:'].includes(u.protocol))return label;
      if(u.hostname==='ars.els-cdn.com'&&/[-/]mmc\d+\./i.test(u.pathname))return `[Supplementary material](<${asset([u.href],'supplement')}>)`;
      return `[${label}](<${u.href.replace(/>/g,'%3E')}>)`;
    }
    if(runtimeMath&&runtimeMath.url!==sourceURL)throw Error('公式源与当前论文不一致，请重新抓取。');
    const mathReader=createMathReader(doc,runtimeMath);
    const skip='script,style,svg,button,form,iframe,.ReferenceLinks,.download-link,.list-label,.sr-only,.screen-reader-only,.article-attachment .help-link,.MathJax,.MathJax_Display,.MJX_Assistive_MathML,.ref-link';
    const supplementLinks=new Map(),supplementFiles=new WeakMap();
    for(const component of nodes('.e-component')){
      if(component.querySelector('.article-attachment img'))continue;
      const a=[...component.querySelectorAll('.article-attachment a[href]')].find(a=>/[-/]mmc\d+\.(?:pdf|docx?|xlsx?|zip)(?:[?#]|$)/i.test(a.getAttribute('href')));
      if(!a)continue;
      const href=new URL(a.getAttribute('href'),sourceURL).href;supplementFiles.set(component,{a,href});
      for(const id of [component.id,...[...component.querySelectorAll('[id]')].map(n=>n.id)].filter(Boolean)){
        if(supplementLinks.has(id)&&supplementLinks.get(id)!==href)throw Error('补充材料目标不唯一：'+id);
        supplementLinks.set(id,href);
      }
    }
    function convertChildren(n){return [...n.childNodes].map(convert).join('');}
    function tableInline(n){
      if(n.nodeType===3)return attr(n.nodeValue.replace(/\s+/g,' '));if(n.nodeType!==1)return '';
      const formula=mathReader.read(n);if(formula!==null)return attr(formula);
      if(n.matches(skip))return '';
      const tag=mathName(n),inner=()=>[...n.childNodes].map(tableInline).join('');
      if(['sub','sup','b','strong','i','em'].includes(tag))return '<'+tag+'>'+inner()+'</'+tag+'>';
      if(tag==='br')return '<br>';
      if(tag==='img')return '<img src="'+attr(asset(imageSources(n),'inline'))+'" alt="'+attr(n.alt||'')+'">';
      if(tag==='a'){
        const raw=n.getAttribute('href')||'',key=targetKey(raw);let href;
        try{href=idMap.has(key)?'#'+idMap.get(key):new URL(raw,sourceURL).href;}catch{return inner();}
        return /^(?:https?:|mailto:|#)/.test(href)?'<a href="'+attr(href)+'">'+inner()+'</a>':inner();
      }
      return inner();
    }
    function convert(n){
      if(n.nodeType===3)return esc(n.nodeValue.replace(/\s+/g,' '));if(n.nodeType!==1)return '';
      const tag=n.localName.toLowerCase();
      if(tag==='a'&&/[-/]mmc\d+\./i.test(n.getAttribute('href')||''))return link(n);
      const formula=mathReader.read(n);if(formula!==null)return formula;
      if(n.matches(skip))return '';
      if(n.matches('.label')&&/^\(?[A-Z]?\d+[a-z]?\)?$/i.test(text(n))&&n.closest('.formula,.display,.equation')?.querySelector('math,script[type^="math/"],script[type^="application/mathml"],mjx-container,.MathJax,.MathJax_SVG,.MathJax_CHTML,.katex'))return '';
      const target=registered.get(n);let value;
      if(n.matches('.e-component')&&n.querySelector('.article-attachment img')){
        const img=n.querySelector('.article-attachment img'),caption=n.querySelector('.captions');
        const path=asset(imageSources(img),'supplement');
        value=center(`![${esc(text(caption)||img.alt||'Supplementary material')}](<${path}>)`)+(caption?'\n\n'+centerCaption(convertChildren(caption)):'');
      }else if(supplementFiles.has(n)){
        const {a,href}=supplementFiles.get(n),caption=n.querySelector('.captions'),first=caption?.querySelector('p')||caption;
        const label=text(first)||'Supplementary material '+(href.match(/mmc(\d+)/i)?.[1]||'');
        const type=new URL(href).pathname.split('.').pop().toUpperCase(),size=(a.title||text(a)).match(/\(([\d.,]+)\s*(KB|MB|GB)\)/i);
        value=`[${esc(label)}](<${asset([href],'supplement')}>) — ${type}`+(size?' · '+size[1]+' '+size[2].toUpperCase():'');
        if(caption&&first!==caption){const rest=caption.cloneNode(true);rest.querySelector('p')?.remove();const description=clean(convertChildren(rest));if(description)value+='\n\n'+description;}
      }else if(tag==='figure'){
        const img=n.querySelector('img');if(!img){warnings.push('图缺少图片：'+n.id);value=convertChildren(n);}else{
          const path=asset(imageSources(img,n),'figure');const caption=n.querySelector('.captions,figcaption');
          value=center(`![${esc(img.alt||'Graphical abstract')}](<${path}>)`)+(caption?'\n\n'+centerCaption(convertChildren(caption)):'');
        }
      }else if(n.matches('.keywords')){const heading=n.querySelector('h2,h3');value=(heading?convert(heading):'')+[...n.querySelectorAll('.keyword')].map(x=>esc(text(x))).join('; ');}
      else if(n.matches('.tables'))value=clean(convertChildren(n));
      else if(n.matches('.captions'))value=centerCaption(convertChildren(n));
      else if(n.matches('.label')&&n.closest('.captions'))return '**'+convertChildren(n)+'**';
      else if(tag==='table'){
        const rows=[...n.rows],complex=n.tHead?.rows.length>1||!!n.tFoot||rows.some(r=>[...r.cells].some(c=>c.colSpan>1||c.rowSpan>1));
        const hasFormula=[...n.querySelectorAll('*')].some(c=>mathName(c)==='math'||mathScript(c)||mathPresentation(c));
        if(hasFormula)value=tableMarkdown(n,c=>convertChildren(c));
        else if(complex){
          const cell=c=>`<${c.tagName.toLowerCase()}${c.colSpan>1?' colspan="'+c.colSpan+'"':''}${c.rowSpan>1?' rowspan="'+c.rowSpan+'"':''}${c.hasAttribute('scope')?' scope="'+attr(c.getAttribute('scope'))+'"':''}>${tableInline(c)}</${c.tagName.toLowerCase()}>`;
          const row=r=>'<tr>'+[...r.cells].map(cell).join('')+'</tr>';
          // Preserve header/body/footer boundaries and merged cells for three-line rendering.
          value='<table class="et-table-three-line">\n'+[...n.children].filter(c=>/^(?:THEAD|TBODY|TFOOT|TR)$/.test(c.tagName)).map(c=>c.tagName==='TR'?row(c):'<'+c.localName+'>\n'+[...c.rows].map(row).join('\n')+'\n</'+c.localName+'>').join('\n')+'\n</table>';
        }
        else {const lines=rows.map(r=>'| '+[...r.cells].map(c=>clean(convertChildren(c)).replace(/\|/g,'\\|').replace(/\n+/g,'<br>')).join(' | ')+' |');if(lines.length)lines.splice(1,0,'| '+[...rows[0].cells].map(()=>'---').join(' | ')+' |');value=lines.join('\n');}
      }else if(/^h[1-6]$/.test(tag))value='#'.repeat(Number(tag[1]))+' '+clean(convertChildren(n));
      else if(tag==='a')return link(n);
      else if(['strong','b'].includes(tag))return '**'+convertChildren(n)+'**';
      else if(['em','i'].includes(tag))return '*'+convertChildren(n)+'*';
      else if(['sub','sup'].includes(tag))return '<'+tag+'>'+attr(text(n))+'</'+tag+'>';
      else if(tag==='br')return '\n';
      else if(tag==='img'){const src=n.getAttribute('src')||n.getAttribute('data-src');if(!src){warnings.push('存在未加载图片');return esc(n.alt||'');}return `![${esc(n.alt||'')}](<${asset(imageSources(n),'inline')}>)`;}
      else if(tag==='ul'||tag==='ol'){value=[...n.children].filter(c=>c.tagName==='LI').map((li,i)=>(tag==='ol'?(i+1)+'. ':'- ')+clean(convertChildren(li)).replace(/\n/g,'\n  ')).join('\n');}
      else {value=convertChildren(n);if(!['div','p','section','blockquote'].includes(tag))return value;}
      value=clean(value);if(!value)return '';
      if(target)targets.push({...target,content:value,...(target.kind==='table'?{table_style:'three-line'}:{})});
      return '\n\n'+value+'\n\n';
    }
    const authorDetails=[...doc.querySelectorAll('#author-group .react-xocs-alternative-link')].map(n=>({name:text(n),markers:[...new Set([...n.parentElement.querySelectorAll('.author-ref sup')].map(text).filter(Boolean))]})).filter(a=>a.name);
    const authors=authorDetails.map(a=>a.name);
    const affiliationDetails=[...new Map([...doc.querySelectorAll('.affiliation')].map(n=>{const label=text(n.querySelector('dt,.label')),copy=n.cloneNode(true);copy.querySelector('dt,.label')?.remove();const item={label,text:text(copy)};return [label+'|'+item.text,item];})).values()];
    const affiliations=affiliationDetails.map(a=>[a.label,a.text].filter(Boolean).join(' '));
    const metadata={title_original:title,authors,affiliations,publication_year:Number(meta('publication_date').slice(0,4))||null,journal:meta('journal_title'),volume:meta('volume'),issue:meta('issue'),pages:meta('firstpage')+(meta('lastpage')?'-'+meta('lastpage'):''),article_number:meta('id'),doi:meta('doi'),doi_url:meta('doi')?'https://doi.org/'+meta('doi'):'',publisher:meta('publisher'),publisher_url:sourceURL,publication_date:meta('publication_date'),published_online:meta('online_date'),article_type:meta('article_type'),keywords:[...doc.querySelectorAll('.keywords .keyword')].map(text),abstract_original:text(doc.querySelector('#abstracts .abstract.author:not(.author-highlights) [id^="sp"]')),language:'en'};
    const abstract=[...doc.querySelectorAll('#abstracts .abstract')].find(n=>text(n.querySelector('h2'))==='Abstract');
    metadata.author_details=authorDetails;metadata.affiliation_details=affiliationDetails;
    const resourceInfo=extractResources(doc,sourceURL);
    metadata.code_urls=resourceInfo.code_urls;metadata.data_urls=resourceInfo.data_urls;
    metadata.resource_urls=[...new Set([...metadata.code_urls,...metadata.data_urls])];
    metadata.abstract_original=abstract?[...abstract.children].filter(n=>!/^H\d$/.test(n.tagName)).map(text).join(' '):'';
    metadata.article_history=[...doc.querySelectorAll('div.u-margin-s-bottom')].map(text).find(t=>t.length<700&&/^Received \d{1,2} [A-Za-z]+ \d{4}/.test(t))||'';
    let markdown='# '+title+'\n\n**Authors:** '+authorDetails.map(a=>esc(a.name)+(a.markers.length?'<sup>'+attr(a.markers.join(','))+'</sup>':'')).join('; ')+'\n\n'+(affiliations.length?'**Affiliations:**\n\n'+affiliationDetails.map(a=>'- '+(a.label?'<sup>'+attr(a.label)+'</sup> ':'')+esc(a.text)).join('\n')+'\n\n':'')+`**Journal:** ${metadata.journal}. **Volume:** ${metadata.volume}. **Article:** ${metadata.article_number}. **Date:** ${metadata.publication_date}.\n\n**DOI:** ${metadata.doi_url}\n\n**Source:** ${sourceURL}\n\n`;
    if(metadata.article_history)markdown+='**Article history:** '+esc(metadata.article_history)+'\n\n';
    markdown+=roots.filter(Boolean).map(convert).join('\n');
    markdown+='\n\n## References\n\n';
    for(const li of referenceRows){const t=registered.get(li),r=li.querySelector('.reference'),content=clean(convertChildren(r)).replace(/\n+/g,' '),urls=[...r.querySelectorAll('a[href]')].filter(a=>!a.closest('.ReferenceLinks')).map(a=>new URL(a.getAttribute('href'),sourceURL).href).filter(u=>/^https?:/.test(u));targets.push({...t,content});const plain=r.cloneNode(true);plain.querySelectorAll('.ReferenceLinks').forEach(n=>n.remove());plain.querySelectorAll('div').forEach(n=>n.append(' '));bibliography.push({id:t.id,text:text(plain),urls:[...new Set(urls)]});markdown+=`${content}\n\n`;}
    markdown=clean(markdown)+'\n';
    let targetOffset=0;for(const target of targets){const at=markdown.indexOf(target.content,targetOffset);if(at<0)throw Error('内部目标内容定位失败：'+target.id);target.start_line=markdown.slice(0,at).split('\n').length;target.end_line=target.start_line+target.content.split('\n').length-1;targetOffset=at+target.content.length;}
    const linkIDs=[...markdown.matchAll(/\]\(#([^\s)]+)\)/g)].map(m=>m[1]);const dangling=linkIDs.filter(id=>!targets.some(t=>t.id===id));if(dangling.length)throw Error('存在未解析的本地引用：'+dangling.join(', '));
    mathReader.verify(roots);
    const report={source_url:sourceURL,captured_at:new Date().toISOString(),body_characters:text(body).length,source_figures:nodes('figure').length,figures:targets.filter(t=>t.kind==='figure').length,tables:targets.filter(t=>t.kind==='table').length,references:referenceRows.length,sections:targets.filter(t=>t.kind==='section').length,math:mathReader.sources.size,math_inline:mathReader.stats.inline,math_display:mathReader.stats.display,math_html:[...mathReader.sources.values()].filter(s=>s.kind==='HTML').length,math_runtime:[...mathReader.sources.values()].filter(s=>s.runtime).length,local_links:linkIDs.length,unresolved_links:dangling,warnings:[...new Set(warnings)]};
    if(!referenceRows.length)report.warnings.push('未找到参考文献列表，请核对原网页。');
    report.code_links=metadata.code_urls.length;report.data_links=metadata.data_urls.length;
    const metadata_sources=resourceInfo.resources.map(r=>({fields:[r.kind+'_urls','resource_urls'],source:'publisher_html',locator:sourceURL+(r.locator||''),url:r.url,evidence:r.evidence}));
    return {version:'0.5.18',stem,filename:stem+'.md',markdown,assets,report,index:{schema:'xref-sidecar-v2',path_base:'markdown-directory',documents:[{id:1,markdown:stem+'.md',source_url:sourceURL,metadata,metadata_sources,resource_statements:resourceInfo.statements,references:referenceRows.length,citation_links:linkIDs.filter(id=>id.startsWith('ref-')).length,cross_reference_links:linkIDs.filter(id=>!id.startsWith('ref-')).length,targets,bibliography}]}};
  }
  globalThis.SDTypora={extract,mathTex,prepare,extractResources,tableMarkdown};
})();
