# Changelog

## 0.5.17 — 2026-10-11

- Align update actions on the right, directly below the update status. Keep the version beside the heading and automatic checks on the left.

## 0.5.16 — 2026-10-11

- Place the extension version beside the update heading and the live update status at the upper right.
- Remove the installation-mode helper text from the update card; retain update actions and accessible status announcements.

## 0.5.15 — 2026-10-11

- Invoke native fetch without binding it to the updater instance; fixes `Illegal invocation` in browser workers before either GitHub request was sent.
- Prefer the GitHub API endpoint, retaining the raw file endpoint as fallback, explicit host permissions and fixed download URLs.
- Retry failed automatic checks after 5 minutes instead of caching failures for 6 hours; retain the normal 6-hour interval after success and respect opt-out.
- Cover native receiver semantics, API fallback, cached release preservation and retry recovery. Browser Worker reproduction confirms the old error and successful live network access after the fix.

## 0.5.12 — 2026-10-10

- Move local Typora connections from port 23119 to 23120, alongside toolbar v1.113.3, to avoid Zotero's connector port. Both ends must be updated.
- Check `/v1/health` without credentials before requests; require the Typora service/protocol response, reject redirects and never fall back to the old port.
- Replace raw JSON parser errors with actionable Chinese connection messages. Preserve explicit approval, token authorization, cancellation, binary uploads and ZIP-only operation.
- Add network regressions for wrong-service/non-JSON responses, offline connections, authorization errors, binary transfer, cancellation and timeout.

## 0.5.11 — 2026-10-05

- Allow legacy `.doc` and `.xls` assets in ZIP packages and the companion Typora v1.90.22+ receiver.
- Validate the OLE signature and minimum header length for legacy Office; preserve original bytes, local links, source labels and modern OOXML support.
- Reject HTML error pages, renamed ZIPs, truncated/corrupt signatures, unsupported paths and oversized downloads. Retain SHA-256 transport checks and idempotent imports.
- 51 extension regressions pass, including legacy extraction and byte-preserving ZIPs. Installed Typora v1.90.23 imports the package over loopback HTTP into an isolated library, rejects corrupt transfers, preserves every hash and commits idempotently. Publisher responses and OLE headers in the new tests are controlled fixtures, not live downloads or Office document parsing.


## 0.5.10 — 2026-10-05

- Preserve header/body/footer and merged cells in three-line HTML tables; omit accessible Empty Cell labels.
- Center caption paragraphs individually to prevent literal inline HTML spanning blank lines.
- Name local supplementary files by their source captions, retain descriptions/type/source size, and resolve supplementary cross-links to the same local asset. Remove publisher attachment-help controls only.
- Hybrid paper live capture retains 8 figures, 1 table, 68 references, 42 formulas and 11 resources; 47 extraction regressions pass. Companion toolbar adds safe complex-table previews and native three-line styling.

## 0.5.9 — 2026-10-05

- Convert MathML hat/tilde accents to valid TeX accents; retain bold-italic and script math variants. Use scalable fences around multirow matrices and piecewise expressions.
- Preserve publisher formula labels using display-math tags, suppress detached labels and retain unnumbered equations as unnumbered.
- Recognize b/bb/bbb reference families, including PlantSegNeRF reference-label back-links. Keep same-source and ambiguity safeguards.
- Live page validation: 70 formula sources, 17 numbered equations, 48 body citations; strict TeX validation and native Typora rendering pass. All 44 reference hover targets verified. 43 extension regressions pass.
- Repair the specified existing paper and its index/checksums with backups, preserving article history, 15 image files and user image zoom.

## 0.5.8 — 2026-10-05

- Resolve publisher .sml thumbnails using matching high-resolution/full-size links; retain supplementary image captions and avoid duplicate representations. No guessed URLs or unsupported .bin files.
- Preflight the same path, extension and case-insensitive duplicate rules as the library receiver, before downloading. Preserve content signature, domain and SHA-256 verification.
- Live PlantSegNeRF capture: 13 figures plus 2 supplementary JPEGs downloaded; 2 tables, 44 references and 70 math occurrences retained. Actual isolated Typora receiver accepted 18 files, idempotent commit, all 15 images rendered.
- 39 extension tests pass, including fallback and unsupported/invalid asset failures. Permissions unchanged. Toolbar v1.90.13 adds file-specific receiver diagnostics; 632 toolbar tests pass.


## 0.5.7 — 2026-10-04

- Read MathJax 3 MathItems and MathJax 2 element jax in the page MAIN world, then pass source-only JSON to the isolated extractor. Restore original MathML/TeX when rendered output has no DOM source.
- Match sources by article URL, structural path and rendered-node fingerprint; reject stale, ambiguous or malformed sources. No page mutations or connector credentials enter MAIN.
- Preserve DOM-source priority, assistive deduplication and HTML math handling. Add math_runtime to the export report and distinguish unavailable runtime sources from ordinary loading delays.
- Reproduce the exact MathJax CtxtMenu_Attached_0 error using real Chrome + MathJax 3.2.2 without assistive MathML. Verify isolated-world recovery, PDF-backed equation/ion samples and ZIP output. Pass 33 tests including worker wiring and failure behavior.
- User's live publisher page could be listed but not inspected by the available browser binding; no claim of completed online article import.

## 0.5.6 — 2026-10-04

- Distinguish ordinary HTML `.math` containers from strict MathJax rendering layers; retain chemical charges, subscripts, superscripts, units, italic text and formula images.
- Recognize native `<math class="math">` directly and traverse mixed wrappers without losing text or separate mathematical sources.
- Keep explicit failures for missing formula sources, unsupported rendering, broken MathML and missing image URLs; add HTML math counts to the report.
- Reproduce the regression on v0.5.5, pass all 25 focused tests, cached article coverage and the shared package builder. Live capture of S0167198719313601 remains unverified because browser automation is unavailable.
- No permission, connector, library or toolbar changes.

## 0.5.5 — 2026-10-04

- Read MathML source scripts as well as native MathML and TeX; resolve MathJax HTML/SVG/CHTML and MathJax 3/KaTeX assistive sources.
- Deduplicate render/preview/source copies locally without dropping separate formulas in the same paragraph.
- Preserve math in headings and merged table cells, and report inline/display counts.
- Stop with a source-specific error for unreadable or unsupported mathematical structures instead of silently omitting them.
- Add 17 focused regression checks covering math and existing references/resources. Cached article coverage and PDF-backed document repair checked separately.
- No new permissions or changes to toolbar/web ChatGPT features.

## 0.5.4 — 2026-10-04

- Normalize bare and same-article absolute publisher anchors and known reference aliases.
- Retain source_ids per target; reject ambiguous aliases instead of guessing.
- Preserve original external links, resource extraction and existing save-mode behavior.
- Verified 21 resource/package cases, 3 anchor regressions, and local indexed previews in actual Typora v1.87.5.

## 0.5.3 — 2026-09-29

- Make selecting ZIP immediately opt out of library imports; retain explicit Save Settings for other preferences and library opt-in.
- Invalidate stale category pickers and pending captures after destination changes. Recheck the selected mode before packaging, transfer and final library commit; a failed old-mode task no longer blocks a fresh ZIP action.
- Keep connector credentials out of ZIP jobs and allow ZIP options/downloads while paired Typora is offline. Rename the option to “仅下载 ZIP 压缩包”.
- Reproduce the old stale-picker import in an isolated baseline; pass 16 real Chrome/Typora checks, including browser and chosen-directory ZIP, repeated saves, active-task cancellation and the final commit boundary.
- Extraction/package engines, existing library entries and previous release archives remain unchanged.

## 0.5.2 — 2026-09-28

- Extract explicitly declared paper code/data URLs from accessible article content and linked resource footnotes; exclude references and identified third-party tools.
- Save deduplicated resource_urls plus compatible code_urls/data_urls, source sentences and locators in xref-sidecar-v2. Preserve on-request statements without inventing URLs.
- Support the unified Resource Links field in Typora toolbar v1.31.9. No new permissions, repository crawling or dataset downloads.
- Verified 21 extraction/package cases, original article DOM format replay, and actual isolated Typora ingestion. No fresh authenticated publisher capture in this release.

## 0.5.1 — 2026-09-28

- Return to the initial save form immediately after success; remove the Again Save step.
- Restore the category selector in ask mode and an idle Save button in direct/ZIP modes, without automatic recapture.
- A later explicit Save or toolbar-icon click starts a new validated job; in-progress clicks still reuse the existing job.
- Revalidate library identity and category existence; retain error retry and current save preferences.
- 18 isolated real Chrome/Typora checks pass. Extraction format engine remains unchanged from v0.5.0.

## 0.5.0 — 2026-09-28

- Automatically expand ScienceDirect author information even when Show more is outside the author group; wait for expected affiliation markers and stable content.
- Stop with an actionable error when affiliations fail to load; preserve author/affiliation superscripts.
- Pair with Typora toolbar v1.28.0: captures now live under storage, alongside managed local Markdown bundles, document language and root directory actions.
- Verify a delayed collapsed-author fixture through the actual extension action and local Typora receiver; test failure without downloads. Existing capture format and settings remain compatible.

## 0.4.0 — 2026-09-28

- Redesign options with compact save-mode cards, connection status, a selectable library location and light/dark palettes.
- Choose between asking for a collection on each capture and saving immediately to a configured default collection. Bind defaults to a specific library and reject deleted or stale destinations.
- Add “更换文件夹…” using Typora's native directory dialog; switch the whole library and refresh its collections while leaving the previous library untouched. Require toolbar v1.27.0.
- Improve pairing buttons and dark collection-select contrast; remove the redundant storage explanation.
- Verify real extension/Typora pairing, classified imports, whole-library switching, cancellation, stale defaults, and both ZIP destinations in isolated profiles.

## 0.3.0 — 2026-09-28

- Add native extension Options entry with ZIP/download-directory and paired Typora library modes.
- Select a library collection on every capture; import verified Markdown/assets/xref into a managed folder and register metadata using the existing library importer.
- Support user-picked ZIP directories using persisted File System Access handles, explicit permission checks and destination identity checks.
- Pair with the local Typora receiver only after an in-app approval; tokens stay outside webpage messages and exports.
- Remove the redundant hint disclosure and unzip text. Preserve compact progress, error/retry and previous extraction features.
- Require Typora toolbar v1.26.0 for direct library import; ZIP mode remains independent.

## 0.2.0 — 2026-09-28

- Replace the standalone export tab and second confirmation click with a Connector-style toolbar action: click once to save, with compact progress on the original article page.
- Move ZIP construction and Blob lifetime to an offscreen document; service worker owns browser downloads and session-scoped per-document progress.
- Save to the browser download directory under `ScienceDirect-Typora`, with timestamped non-overwriting filenames; show/retry/cancel controls stay in the small in-page card.
- Closing the card or an already-captured article does not stop packaging. Repeated action clicks reveal the same job. Worker restarts reconcile ongoing jobs/downloads.
- Scope page messages to the initiating tab/document and progress to its article, reject untrusted synthetic page clicks, release Blob URLs after completion/cancellation.
- Preserve v0.1.1 extraction fidelity, superscripts, centered captions, three-line table metadata, resource validation and full ZIP structure.

## 0.1.1 — 2026-09-28

- Preserve author affiliation markers and affiliation labels using superscript markup, with separate structured author details and clean metadata names.
- Center images and figure/table captions while retaining their local cross-reference targets and line mappings.
- Mark exported table targets with `table_style: three-line` for Typora toolbar v1.25.0; native Markdown tables remain editable.
- Deliver a separate v0.1.1 English sample, preserving the original export and assets.

## 0.1.0 — 2026-09-28

- Initial English ScienceDirect article exporter, packaged as a Chrome Manifest V3 extension.
- Export current accessible article text, local high-resolution figures and supplementary material.
- Generate xref-sidecar-v2 metadata, citation and figure/table records compatible with the installed Typora toolbar.
- Save a timestamped ZIP, with source/asset provenance and SHA-256 checksums.
- Validate missing resources and reject HTML login/error pages masquerading as images.
- Avoid visible HTML anchor scaffolding in Typora; preserve literal square brackets without triggering TeX parsing.
