// Placement and dragging stay in the host, independent of optional modules.
class EditingToolbarTopMotion {
  constructor(toolbar) {
    this.frame=ETDragSupport.frame(()=>this.paint(),requestAnimationFrame,cancelAnimationFrame);
    this.toolbar=toolbar;this.host=toolbar.topHost;this.bar=toolbar.topToolbar;
    this.bar.removeAttribute('title');
    const chrome=document.createElement('div');chrome.className='et-top-chrome';
    const button=(id,paths,label)=>{const b=document.createElement('button');b.type='button';b.dataset.topControl=id;b.title=label;b.setAttribute('aria-label',label);b.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+paths+'</svg>';chrome.append(b);return b;};
    this.grip=button('drag','<path d="M8 5h.01M16 5h.01M8 12h.01M16 12h.01M8 19h.01M16 19h.01" stroke-width="3"/>','拖动工具栏；双击切换浮动');
    this.dock=button('dock','<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M4 9h16"/>','浮动工具栏');
    chrome.addEventListener('mousedown',e=>{if(e.button===0){toolbar._saveSelection();e.preventDefault();}e.stopPropagation();});
    this.dock.addEventListener('click',e=>{e.stopPropagation();this.toggle();});
    this.grip.addEventListener('dblclick',e=>{e.preventDefault();e.stopPropagation();this.toggle();});
    this.grip.addEventListener('keydown',e=>{
      if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home'].includes(e.key))return;
      e.preventDefault();e.stopPropagation();if(e.key==='Home'){this.toolbar.uiSettings.topMode='docked';this.apply();this.toolbar._persistTopPlacement();return;}
      const s=this.toolbar.uiSettings,r=this.host.getBoundingClientRect(),step=e.shiftKey?40:10;
      s.topMode='floating';s.topPosition={x:r.left+(e.key==='ArrowLeft'?-step:e.key==='ArrowRight'?step:0),y:r.top+(e.key==='ArrowUp'?-step:e.key==='ArrowDown'?step:0)};this.apply();this.toolbar._persistTopPlacement();
    });
    this.host.prepend(chrome);toolbar.topChrome=chrome;
    this.host.addEventListener('pointerdown',e=>this.start(e),true);
    window.addEventListener('pointermove',e=>this.move(e),true);
    window.addEventListener('pointerup',e=>{if(this.drag?.id===e.pointerId){this.move(e);this.finish(false);}},true);
    window.addEventListener('pointercancel',()=>this.finish(true),true);
    this.grip.addEventListener('lostpointercapture',()=>this.finish(true));
    window.addEventListener('blur',()=>this.finish(true));
    window.addEventListener('keydown',e=>{if(e.key==='Escape'&&this.drag){e.preventDefault();e.stopImmediatePropagation();this.finish(true);}},true);
    window.addEventListener('resize',()=>{this.finish(true);this.apply();});
    this.apply();
  }
  toggle(){
    this.finish(true);const s=this.toolbar.uiSettings,r=this.host.getBoundingClientRect();
    if(s.topMode==='floating')s.topMode='docked';else{s.topMode='floating';s.topPosition={x:r.left,y:r.top};}
    this.toolbar._closeActivePopover();this.apply();this.toolbar._persistTopPlacement();
  }
  start(e){
    if(e.button!==0||e.isPrimary===false||this.drag)return;
    const handle=e.target.closest?.('[data-top-control="drag"]');
    if(!handle&&(!this.bar.contains(e.target)||e.target.closest?.('button,input,textarea,select,a,[role=button],.et-popover')))return;
    e.preventDefault();e.stopPropagation();this.toolbar._saveSelection();
    const r=this.host.getBoundingClientRect(),s=this.toolbar.uiSettings;
    this.drag={id:e.pointerId,x:e.clientX,y:e.clientY,left:r.left,top:r.top,next:{x:r.left,y:r.top},mode:s.topMode,position:{...s.topPosition},focus:document.activeElement,moved:false};
    this.grip.setPointerCapture(e.pointerId);
  }
  move(e){
    const d=this.drag;if(!d||d.id!==e.pointerId)return;e.preventDefault();e.stopPropagation();
    if(!d.moved&&Math.hypot(e.clientX-d.x,e.clientY-d.y)<4)return;
    if(!d.moved){
      d.moved=true;this.toolbar._closeActivePopover();this.toolbar.hide();document.body.classList.add('et-top-dragging');
      d.shield=ETDragSupport.shield(document,'et-top-drag-shield');d.shield.focus({preventScroll:true});
    }
    d.next={x:d.left+e.clientX-d.x,y:d.top+e.clientY-d.y};
    this.frame.queue();
  }
  paint(){const d=this.drag;if(!d?.moved)return;this.toolbar.uiSettings.topMode='floating';this.toolbar.uiSettings.topPosition={...d.next};this.apply();}
  finish(cancel){
    const d=this.drag;if(!d)return;this.frame.cancel();
    if(cancel){this.toolbar.uiSettings.topMode=d.mode;this.toolbar.uiSettings.topPosition=d.position;this.apply();}else this.paint();
    this.drag=null;const focus=document.hasFocus()&&document.activeElement===d.shield;d.shield?.remove();if(focus&&d.focus?.isConnected)d.focus.focus({preventScroll:true});document.body.classList.remove('et-top-dragging');
    if(this.grip.hasPointerCapture(d.id))this.grip.releasePointerCapture(d.id);
    if(d.moved&&!cancel)this.toolbar._persistTopPlacement();
  }
  apply() {
    const s=this.toolbar.uiSettings,floating=s.topMode==='floating';s.topCollapsed=false;s.responsive=true;
    this.host.dataset.placement=floating?'floating':'docked';this.host.dataset.collapsed='false';this.host.style.transform='';this.bar.inert=false;
    this.toolbar._applyToolbarButtonSize(this.bar,true);
    const label=floating?'固定到顶部':'浮动工具栏';this.dock.title=label;this.dock.setAttribute('aria-label',label);this.dock.setAttribute('aria-pressed',String(floating));
    if(floating){
      const r=this.host.getBoundingClientRect(),position=s.topPosition||{x:24,y:100},w=document.documentElement.clientWidth,h=document.documentElement.clientHeight;
      this.host.style.left=Math.max(8,Math.min(Number.isFinite(position.x)?position.x:24,w-r.width-8))+'px';
      this.host.style.top=Math.max(8,Math.min(Number.isFinite(position.y)?position.y:100,h-r.height-8))+'px';
    }else{this.host.style.left='';this.host.style.top='';}
  }
}
