'use strict';
// Update metadata is data only. Unpacked extensions never execute downloaded code.
globalThis.SDUpdates=class {
 constructor(api=chrome,request=fetch,now=()=>Date.now()){this.api=api;this.request=request;this.now=now;this.pending=null;}
 static key='extensionUpdates';
 static alarm='sd-extension-updates';
 static interval=6*60*60*1000;
 static repository='https://github.com/xiaozhi0507/typora-editing-toolbar';
 static catalog='https://raw.githubusercontent.com/xiaozhi0507/typora-editing-toolbar/main/exporter-update.json';
 static version(v){if(typeof v!=='string'||!/^\d{1,5}(?:\.\d{1,5}){2,3}$/.test(v)||v.split('.').some(n=>+n>65535))throw Error('更新信息中的版本无效');return v;}
 static compare(a,b){const x=this.version(a).split('.').map(Number),y=this.version(b).split('.').map(Number);for(let i=0;i<4;i++){const d=(x[i]||0)-(y[i]||0);if(d)return Math.sign(d);}return 0;}
 static release(value){const version=this.version(value?.version);if(value.schemaVersion!==1||value.id!=='sciencedirect-typora-exporter'||!(/^[a-f0-9]{64}$/i.test(value.sha256||'')))throw Error('更新信息校验失败');const tag='sciencedirect-typora-exporter-v'+version,name=tag+'.zip';return {version,sha256:value.sha256.toLowerCase(),releaseUrl:this.repository+'/releases/tag/'+tag,downloadUrl:this.repository+'/releases/download/'+tag+'/'+name,filename:name};}
 async state(){const data=await this.api.storage.local.get(SDUpdates.key),value=data[SDUpdates.key]||{};let release;try{if(value.release)release=SDUpdates.release({schemaVersion:1,id:'sciencedirect-typora-exporter',...value.release});}catch{}return {autoCheck:value.autoCheck!==false,checkedAt:Number(value.checkedAt)||0,attemptedAt:Number(value.attemptedAt)||0,error:String(value.error||''),release};}
 async save(value){await this.api.storage.local.set({[SDUpdates.key]:value});return value;}
 async view(){const s=await this.state(),version=this.api.runtime.getManifest().version;let installType='development';try{installType=(await this.api.management.getSelf()).installType;}catch{}return {...s,version,installType,available:!!s.release&&SDUpdates.compare(s.release.version,version)>0};}
 async schedule(){const s=await this.state();if(s.autoCheck){await this.api.alarms.create(SDUpdates.alarm,{delayInMinutes:1,periodInMinutes:360});}else await this.api.alarms.clear(SDUpdates.alarm);}
 async setAuto(value){await this.save({...await this.state(),autoCheck:!!value});await this.schedule();return this.view();}
 async check(force=false){if(this.pending)return this.pending;this.pending=this.performCheck(force).finally(()=>{this.pending=null;});return this.pending;}
 async performCheck(force){const s=await this.state();if(!force&&(!s.autoCheck||(s.attemptedAt&&this.now()-s.attemptedAt<SDUpdates.interval)))return this.view();const attemptedAt=this.now(),controller=new AbortController(),timer=setTimeout(()=>controller.abort(),10000);try{
  const response=await this.request(SDUpdates.catalog,{cache:'no-store',credentials:'omit',redirect:'error',signal:controller.signal});if(!response.ok)throw Error('暂时无法连接更新源');if(Number(response.headers?.get('content-length'))>65536)throw Error('更新信息过大');const text=await response.text();if(text.length>65536)throw Error('更新信息过大');const release=SDUpdates.release(JSON.parse(text));await this.save({...await this.state(),release,attemptedAt,checkedAt:this.now(),error:''});
 }catch(error){await this.save({...await this.state(),attemptedAt,error:error.name==='AbortError'?'检查超时，请稍后重试':'暂时无法检查更新，请稍后重试'});}finally{clearTimeout(timer);}return this.view();}
 async download(){const s=await this.view();if(!s.available)throw Error('暂无可下载的更新');const id=await this.api.downloads.download({url:s.release.downloadUrl,filename:s.release.filename,saveAs:true});return {downloadId:id};}
 async nativeCheck(){const s=await this.view();if(s.installType==='development')throw Error('解压版请下载新版并替换原文件夹');return this.api.runtime.requestUpdateCheck();}
};
