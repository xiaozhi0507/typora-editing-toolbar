const fs=require('node:fs'),path=require('node:path');
module.exports=code=>{
 const core=(file,name)=>'const '+name+'=(()=>{const module={exports:{}};'+fs.readFileSync(path.join(__dirname,file),'utf8')+';return module.exports;})();\n';
 const connection=require('esbuild').buildSync({entryPoints:[path.join(__dirname,'ai-plugins.cjs')],bundle:true,format:'iife',globalName:'ETConnectionStore',platform:'browser',minify:true,write:false}).outputFiles[0].text;
 const progress=fs.readFileSync(path.join(__dirname,'ai-turn-timing.js'),'utf8').replaceAll('EditingToolbarAITiming','EditingToolbarTaskTiming')+'\n'+fs.readFileSync(path.join(__dirname,'ai-execution.js'),'utf8').replaceAll('EditingToolbarAIExecution','EditingToolbarTaskProgress').replaceAll('EditingToolbarAITiming','EditingToolbarTaskTiming');
 const extra=progress+'\n'+connection+'\n'+core('local-data-protection.cjs','ETLocalProtection')+core('document-diff.cjs','ETDocumentDiff')+core('ai-web.cjs','ETAIWeb')+core('ai-shell.cjs','ETAIShell')+core('ai-execution.cjs','ETAIExecution')+['core-connections.js','document-selection.js','sidebar-motion.js'].map(f=>fs.readFileSync(path.join(__dirname,f),'utf8')).join('\n');
 const pos=code.lastIndexOf('(function () {');if(pos<0)throw Error('Missing core services boot');return code.slice(0,pos)+extra+'\n'+code.slice(pos);
};
