// Native sidebar uses a release-only guide. Take over its handle, not the editor.
class EditingToolbarSidebarMotion {
  constructor(toolbar){
    this.toolbar=toolbar;
    this.createToggle();
    const handle=document.getElementById('typora-sidebar-resizer');
    if(handle){handle.tabIndex=0;handle.setAttribute('role','separator');handle.setAttribute('aria-label','调整左侧栏宽度');handle.setAttribute('aria-orientation','vertical');handle.setAttribute('aria-valuemin','160');}
    document.addEventListener('pointerdown',e=>this.start(e),true);
    document.addEventListener('pointermove',e=>this.move(e),true);
    document.addEventListener('pointerup',e=>{if(this.drag?.id===e.pointerId){this.move(e);this.finish(false);}},true);
    document.addEventListener('pointercancel',()=>this.finish(true),true);
    document.addEventListener('lostpointercapture',e=>{if(this.drag?.id===e.pointerId)this.finish(true);},true);
    window.addEventListener('blur',()=>this.finish(true));
    window.addEventListener('keydown',e=>{if(e.key==='Escape'&&this.drag){e.preventDefault();e.stopImmediatePropagation();this.finish(true);}},true);
    window.addEventListener('resize',()=>this.finish(true));
    document.addEventListener('keydown',e=>{
      if(e.target.id!=='typora-sidebar-resizer'||!['ArrowLeft','ArrowRight'].includes(e.key)||!File.editor.library.isSidebarShown())return;
      e.preventDefault();e.stopImmediatePropagation();const a=this.toolbar.aiAssistant,right=this.toolbar.panelWorkspace?.dockWidth()||(a?.panel&&!a.panel.hidden&&a.panel.dataset.layout==='dock'?a.panel.getBoundingClientRect().width:0);
      const max=Math.max(160,innerWidth-right-220),width=Math.max(160,Math.min(max,document.getElementById('typora-sidebar').getBoundingClientRect().width+(e.key==='ArrowRight'?1:-1)*(e.shiftKey?40:10)));
      document.documentElement.style.setProperty('--sidebar-width',width+'px');e.target.setAttribute('aria-valuenow',Math.round(width));JSBridge.putSetting('sidebar-width',Math.round(width));window.dispatchEvent(new Event('resize'));window.dispatchEvent(new Event('optimizedResize'));
    },true);
  }
  createToggle(){
    const sidebar=document.getElementById('typora-sidebar');if(!sidebar)return;
    const button=document.createElement('button');button.id='et-sidebar-toggle';button.type='button';button.setAttribute('aria-controls','typora-sidebar');
    button.innerHTML='<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m11 3-5 5 5 5"/></svg>';
    // Keep the document selection when using this chrome control; keyboard
    // activation remains a normal focused button action.
    button.addEventListener('mousedown',e=>{if(e.button===0)e.preventDefault();e.stopPropagation();});
    button.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();if(this.drag)return;const library=window.File?.editor?.library;if(!library)return;library.toggleSidebar();this.syncToggle();});
    this.toggle=button;document.body.append(button);document.body.classList.add('et-sidebar-toggle-ready');
    this.toggleObserver=new MutationObserver(()=>this.syncToggle());this.toggleObserver.observe(document.body,{attributes:true,attributeFilter:['class']});this.syncToggle();
  }
  syncToggle(){
    if(!this.toggle)return;const open=Boolean(window.File?.editor?.library?.isSidebarShown());if(this.toggle.getAttribute('aria-expanded')===String(open))return;
    this.toggle.setAttribute('aria-expanded',String(open));const label=open?'收起左侧栏':'展开左侧栏';this.toggle.setAttribute('aria-label',label);this.toggle.title=label;this.toolbar.panelWorkspace?.scheduleLayout();
  }
  start(e){
    const handle=e.target.closest('#typora-sidebar-resizer');
    if(!handle||e.button!==0||e.isPrimary===false||this.drag||!window.File?.editor?.library?.isSidebarShown())return;
    e.preventDefault();e.stopImmediatePropagation();
    const root=document.documentElement,sidebar=document.getElementById('typora-sidebar'),r=sidebar.getBoundingClientRect(),a=this.toolbar.aiAssistant;
    const right=this.toolbar.panelWorkspace?.dockWidth()||(a?.panel&&!a.panel.hidden&&a.panel.dataset.layout==='dock'?a.panel.getBoundingClientRect().width:0);
    this.drag={id:e.pointerId,handle,start:e.clientX,width:r.width,next:r.width,saved:root.style.getPropertyValue('--sidebar-width'),max:Math.max(160,innerWidth-right-220),changed:false};
    this.drag.live=[{node:sidebar,prop:'width'},...(this.toggle?[{node:this.toggle,prop:'left',offset:-9}]:[]),...[...document.querySelectorAll('content,titlebar,#top-titlebar,footer.ty-footer,#md-searchpanel,.md-notification-container')].map(node=>({node,prop:'left'})),{node:handle,prop:'left'}].map(item=>({...item,value:item.node.style.getPropertyValue(item.prop),priority:item.node.style.getPropertyPriority(item.prop)}));
    document.body.classList.add('et-sidebar-sizing');handle.setPointerCapture(e.pointerId);
    this.drag.shield=document.createElement('div');this.drag.shield.className='et-sidebar-drag-shield';this.drag.shield.setAttribute('aria-hidden','true');document.body.append(this.drag.shield);
    // Escape otherwise remains inside a focused Monaco/terminal iframe.
    this.drag.focus=document.activeElement;this.drag.shield.tabIndex=-1;this.drag.shield.focus({preventScroll:true});
  }
  move(e){
    const d=this.drag;if(!d||e.pointerId!==d.id)return;e.preventDefault();e.stopImmediatePropagation();
    d.next=Math.max(160,Math.min(d.max,d.width+e.clientX-d.start));d.changed||=Math.abs(d.next-d.width)>0.5;
    if(!this.frame)this.frame=requestAnimationFrame(()=>{this.frame=0;this.paint();});
  }
  paint(){if(this.drag){for(const {node,prop,offset=0} of this.drag.live){const value=(this.drag.next+offset)+'px';if(node.style.getPropertyValue(prop)!==value)node.style.setProperty(prop,value,'important');}this.drag.handle.setAttribute('aria-valuenow',Math.round(this.drag.next));}}
  finish(cancel){
    const d=this.drag;if(!d)return;cancelAnimationFrame(this.frame);this.frame=0;
    // Root custom properties invalidate inherited styles throughout a long document.
    // Commit that native variable once; the gesture only touches geometric properties.
    if(!cancel)document.documentElement.style.setProperty('--sidebar-width',d.next+'px');
    for(const {node,prop,value,priority} of d.live){if(value)node.style.setProperty(prop,value,priority);else node.style.removeProperty(prop);}this.drag=null;
    const restoreFocus=document.hasFocus()&&document.activeElement===d.shield;d.shield?.remove();if(restoreFocus&&d.focus?.isConnected)d.focus.focus({preventScroll:true});d.handle.setAttribute('aria-valuenow',Math.round(cancel?d.width:d.next));document.body.classList.remove('et-sidebar-sizing');if(d.handle.hasPointerCapture(d.id))d.handle.releasePointerCapture(d.id);
    // Match Typora's native persistence; avoid repeated transition listeners and I/O.
    if(!cancel&&d.changed)JSBridge.putSetting('sidebar-width',Math.round(d.next));
    if(d.changed){window.dispatchEvent(new Event('resize'));window.dispatchEvent(new Event('optimizedResize'));}
  }
}
