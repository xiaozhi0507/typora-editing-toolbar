const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),{JSDOM}=require('jsdom');
function setup(t){
 const dom=new JSDOM('<body><header><div id="typora-sidebar"></div><div id="typora-sidebar-resizer"></div></header><content></content><iframe></iframe></body>',{pretendToBeVisual:true});t.after(()=>dom.window.close());
 const {window}=dom,{document}=window,frames=new Map(),saved=[];let serial=0,captured=false;
 window.File={editor:{library:{isSidebarShown:()=>true}}};document.documentElement.style.setProperty('--sidebar-width','355px');
 const sidebar=document.getElementById('typora-sidebar');sidebar.getBoundingClientRect=()=>({width:355});
 const handle=document.getElementById('typora-sidebar-resizer');handle.setPointerCapture=()=>captured=true;handle.hasPointerCapture=()=>captured;handle.releasePointerCapture=()=>captured=false;
 const Sidebar=vm.runInNewContext(fs.readFileSync(__dirname+'/sidebar-motion.js','utf8')+';EditingToolbarSidebarMotion',{window,document,File:window.File,Event:window.Event,MutationObserver:window.MutationObserver,innerWidth:1400,JSBridge:{putSetting:(...args)=>saved.push(args)},requestAnimationFrame:fn=>{frames.set(++serial,fn);return serial;},cancelAnimationFrame:id=>frames.delete(id)});
 const motion=new Sidebar({panelWorkspace:{dockWidth:()=>420,scheduleLayout(){}}});
 const event=(node,type,x,key)=>{const e=new window.Event(type,{bubbles:true,cancelable:true});Object.assign(e,{button:0,pointerId:1,isPrimary:true,clientX:x,key});node.dispatchEvent(e);};
 const iframe=document.querySelector('iframe');iframe.focus();event(handle,'pointerdown',355);
 return {motion,document,window,handle,iframe,frames,saved,event,flush(){const jobs=[...frames.values()];frames.clear();jobs.forEach(f=>f());}};
}
test('sidebar drag owns keyboard focus so Escape cancels from a code iframe and restores focus',t=>{
 const h=setup(t);assert.equal(h.document.activeElement,h.motion.drag.shield);h.event(h.handle,'pointermove',300);h.flush();assert.equal(h.document.getElementById('typora-sidebar').style.width,'300px');
 h.event(h.document.activeElement,'keydown',0,'Escape');h.event(h.handle,'pointerup',300);
 assert.equal(h.motion.drag,null);assert.equal(h.document.documentElement.style.getPropertyValue('--sidebar-width'),'355px');assert.equal(h.document.getElementById('typora-sidebar').style.width,'');assert.equal(h.saved.length,0);assert.equal(h.document.activeElement,h.iframe);assert.equal(h.document.querySelector('.et-sidebar-drag-shield'),null);assert.equal(h.frames.size,0);
});
test('sidebar move coalesces samples, saves only the final release width and removes capture shield',t=>{
 const h=setup(t);for(let x=356;x<430;x++)h.event(h.handle,'pointermove',x);assert.equal(h.frames.size,1);assert.equal(h.saved.length,0);h.flush();h.event(h.handle,'pointerup',440);
 assert.equal(h.document.documentElement.style.getPropertyValue('--sidebar-width'),'440px');assert.equal(h.saved.length,1);assert.deepEqual(h.saved[0],['sidebar-width',440]);assert.equal(h.document.activeElement,h.iframe);assert.equal(h.document.querySelector('.et-sidebar-drag-shield'),null);
});
test('sidebar pointer cancellation discards an unpainted width and leaves persisted settings intact',t=>{
 const h=setup(t);h.event(h.handle,'pointermove',410);h.event(h.handle,'pointercancel',410);h.flush();assert.equal(h.motion.drag,null);assert.equal(h.document.documentElement.style.getPropertyValue('--sidebar-width'),'355px');assert.equal(h.saved.length,0);assert.equal(h.document.querySelector('.et-sidebar-drag-shield'),null);
});
