'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {JSDOM}=require('jsdom'),Store=require('./feature-module-store.cjs'),tick=()=>new Promise(r=>setImmediate(r));
function setup(t){
 const dom=new JSDOM('<body></body>',{runScripts:'outside-only',url:'https://local.test'}),w=dom.window;t.after(()=>w.close());
 w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};w.HTMLDialogElement.prototype.close=function(){if(!this.open)return;this.open=false;this.dispatchEvent(new w.Event('close'));};
 w.ETFeatureStore=Store;w.BUTTON_DEFINITIONS={'ai-assistant':{icon:'<svg></svg>'}};w.reqnode=n=>n==='electron'?{webUtils:{getPathForFile:f=>f.path},shell:{openExternal:async()=>{}}}:require(n);
 const UI=vm.runInContext(fs.readFileSync(path.join(__dirname,'feature-modules.js'),'utf8')+'\nEditingToolbarFeatureModules',dom.getInternalVMContext());UI.prototype.init=async()=>{};
 const ui=new UI({_closeActivePopover(){},_showToolbarNotice(){}}),calls={refresh:0,seed:0,preview:[],install:[],enable:[],uninstall:[],reconcile:0,pickers:[]};
 const manifest={id:'ai-reading-assistant',name:'AI 阅读助手',version:'1.1.0',minHostVersion:'1.108.0',permissions:[],description:'Description'};
 const state={installed:{[manifest.id]:{manifest,enabled:true,bundled:true}},markets:[{name:'Official',url:'https://example.test/index.json',modules:[],error:''}]};
 let refresh=async()=>{},picker=async()=>({canceled:true});w.JSBridge={invoke:async(method,args)=>{calls.pickers.push({method,args});return picker();}};
 ui.store={state:async()=>structuredClone(state),ensureOfficialMarket:async()=>{calls.seed++;},refreshMarkets:async()=>{calls.refresh++;return refresh();},compatible:()=>true,previews:new Map(),preview:async file=>{calls.preview.push(file);const p={token:'p'+calls.preview.length,manifest,compatible:true};ui.store.previews.set(p.token,p);return p;},install:async token=>{calls.install.push(token);ui.store.previews.delete(token);},enable:async(id,value)=>{calls.enable.push([id,value]);state.installed[id].enabled=value;},uninstall:async id=>{calls.uninstall.push(id);delete state.installed[id];}};
 ui.runtime={commands:new Map(),reconcile:async()=>{calls.reconcile++;}};
 const button=(text,root=w.document)=>[...root.querySelectorAll('button')].find(b=>b.textContent===text||b.getAttribute('aria-label')===text);
 const drop=(files,types=['Files'])=>{const e=new w.Event('drop',{bubbles:true,cancelable:true});Object.defineProperty(e,'dataTransfer',{value:{types,files,dropEffect:'copy'}});w.document.querySelector('.et-module-drop').dispatchEvent(e);return e;};
 return {w,ui,calls,state,manifest,button,drop,refresh:fn=>refresh=fn,picker:fn=>picker=fn,open:async()=>{await ui.open();await ui.checking;},input:()=>w.document.querySelector('[aria-label="模块路径"]')};
}
test('market has two keyboard-accessible tabs and reports installed version beside the name',async t=>{
 const f=setup(t);await f.open();assert.deepEqual([...f.ui.tabs.children].map(b=>b.textContent),['已安装','浏览市场']);assert.equal(f.ui.list.querySelector('.et-module-version').textContent,'v1.1.0');assert.equal(f.ui.list.querySelector('.et-module-name strong').nextElementSibling.className,'et-module-version');
 f.ui.tabs.children[0].focus();f.ui.tabs.dispatchEvent(new f.w.KeyboardEvent('keydown',{key:'End',bubbles:true}));await tick();assert.equal(f.ui.tab,'market');assert.equal(f.w.document.activeElement,f.ui.tabs.children[1]);f.ui.tabs.dispatchEvent(new f.w.KeyboardEvent('keydown',{key:'ArrowRight',bubbles:true}));await tick();assert.equal(f.ui.tab,'installed');
});
test('browse market distinguishes install, upgrade, current, newer local and incompatible versions',async t=>{
 const f=setup(t);await f.open();f.ui.tab='market';
 for(const [local,remote,compatible,label,disabled] of [[null,'1.2.0',true,'安装',false],['1.1.0','1.2.0',true,'更新',false],['1.2.0','1.2.0',true,'无需更新',true],['1.3.0','1.2.0',true,'无需更新',true],['1.1.0','1.2.0',false,'需升级工具栏',true],[null,'1.2.0',false,'需升级工具栏',true]]){
  f.state.installed=local?{[f.manifest.id]:{manifest:{...f.manifest,version:local},enabled:true}}:{};
  f.state.markets[0].modules=[{...f.manifest,version:remote}];f.ui.store.compatible=()=>compatible;await f.ui.render();
  const b=f.ui.list.querySelector('.et-module-card-actions button');assert.equal(b.textContent,label);assert.equal(b.disabled,disabled);
  if(label==='无需更新'){assert.match(b.title,new RegExp('已安装 v'+local));b.click();await tick();assert.equal(f.calls.preview.length,0);assert.equal(f.calls.install.length,0);}
 }
});
test('market action re-renders current status after an installed version or inventory change',async t=>{
 const f=setup(t);f.state.markets[0].modules=[{...f.manifest,version:'1.2.0'}];await f.open();f.ui.tab='market';await f.ui.render();assert(f.button('更新'));
 f.state.installed[f.manifest.id].manifest={...f.manifest,version:'1.2.0'};await f.ui.changed();assert(f.button('无需更新').disabled);assert(!f.button('更新'));
 delete f.state.installed[f.manifest.id];await f.ui.changed();assert(!f.button('安装').disabled);
});
test('opening auto-checks once without search or blocking installed controls; reopening checks again',async t=>{
 const f=setup(t);let resolve;f.refresh(()=>new Promise(r=>resolve=r));await f.ui.open();await tick();assert.equal(f.calls.refresh,1);assert.equal(f.w.document.querySelector('input[type=search]'),null);assert(!f.button('检查更新'));assert(!f.button('本地安装').disabled);assert(f.button('卸载 AI 阅读助手'));assert.equal(f.w.document.querySelector('[role=switch]').disabled,false);
 await f.ui.open();assert.equal(f.calls.refresh,1);resolve();await f.ui.checking;assert.equal(f.ui.checkStatus.textContent,'已是最新版本');f.ui.dialog.close();f.refresh(async()=>{});await f.open();assert.equal(f.calls.refresh,2);
});
test('close/reopen during a check reuses the request and does not resurrect closed dialogs',async t=>{
 const f=setup(t);let resolve;f.refresh(()=>new Promise(r=>resolve=r));await f.ui.open();await tick();f.ui.dialog.close();await f.ui.open();assert.equal(f.calls.refresh,1);resolve();await f.ui.checking;assert.equal(f.w.document.querySelectorAll('.et-module-center').length,1);f.ui.dialog.close();await tick();assert.equal(f.w.document.querySelectorAll('dialog').length,0);
});
test('cached updates and documentation remain available after offline refresh',async t=>{
 const f=setup(t);f.state.markets[0].modules=[{...f.manifest,version:'1.2.0',source:'https://example.test/index.json',documentationUrl:'https://example.test/help'}];f.refresh(async()=>{f.state.markets[0].error='offline';});await f.open();assert.match(f.ui.checkStatus.textContent,/保留缓存/);assert(f.button('更新至 1.2.0'));assert.equal(f.button('AI 阅读助手 使用文档').title,'https://example.test/help');assert.equal(f.calls.install.length,0);
});
test('uninstall cancels without mutation and confirms disable-stop-remove in order',async t=>{
 const f=setup(t);await f.open();f.button('卸载 AI 阅读助手').click();await tick();f.button('取消').click();assert.equal(f.calls.uninstall.length,0);f.button('卸载 AI 阅读助手').click();await tick();f.button('卸载模块').click();await tick();assert.deepEqual(f.calls.enable,[[f.manifest.id,false]]);assert.equal(f.calls.reconcile,2);assert.deepEqual(f.calls.uninstall,[f.manifest.id]);assert.equal(f.ui.list.querySelectorAll('[data-module-id]').length,0);
});
test('uninstall aborts if workspace shutdown cannot save drafts',async t=>{
 const f=setup(t);await f.open();f.ui.runtime.reconcile=async()=>{f.state.installed[f.manifest.id].enabled=true;throw Error('草稿保存失败');};f.button('卸载 AI 阅读助手').click();await tick();f.button('卸载模块').click();await tick();assert.equal(f.calls.uninstall.length,0);assert(f.state.installed[f.manifest.id].enabled);assert.match(f.w.document.querySelector('.et-module-prompt .et-module-warning').textContent,/草稿保存失败/);
});
test('local installer uses inline folder picker, ZIP drop area, and explicit preview before installation',async t=>{
 const f=setup(t);await f.open();f.ui.importForm();assert(f.button('预览安装').disabled);const folder=f.button('选择模块文件夹');assert.equal(folder.parentNode,f.input().parentNode);f.picker(async()=>({filePaths:['C:/module']}));folder.click();await tick();assert.deepEqual([...f.calls.pickers[0].args.properties],['openDirectory']);assert.equal(f.input().value,'C:/module');
 const e=f.drop([{path:'C:/模块.zip'}]);assert(e.defaultPrevented);assert.equal(f.input().value,'C:/模块.zip');assert.equal(f.calls.preview.length,0);f.button('预览安装').click();await tick();assert.deepEqual(f.calls.preview,['C:/模块.zip']);assert.equal(f.calls.install.length,0);assert(f.button('确认安装'));f.button('取消').click();assert.equal(f.ui.store.previews.size,0);
});
test('multiple/empty drops and canceled chooser never start an install',async t=>{
 const f=setup(t);await f.open();f.ui.importForm();f.drop([{path:'C:/a.zip'},{path:'C:/b.zip'}]);assert.match(f.w.document.querySelector('.et-module-prompt .et-module-warning').textContent,/一个模块/);f.drop([]);assert.equal(f.calls.preview.length,0);f.w.document.querySelector('.et-module-drop').click();await tick();assert.deepEqual([...f.calls.pickers[0].args.properties],['openFile']);assert.equal(f.input().value,'');assert(f.button('预览安装').disabled);f.button('取消').click();const e=new f.w.Event('drop',{bubbles:true,cancelable:true});Object.defineProperty(e,'dataTransfer',{value:{types:['Files'],files:[{path:'C:/a.zip'}]}});f.w.document.dispatchEvent(e);assert(!e.defaultPrevented);
});
test('late picker and preview results are discarded when the installer closes',async t=>{
 const f=setup(t);await f.open();f.ui.importForm();let resolve;f.picker(()=>new Promise(r=>resolve=r));f.button('选择模块文件夹').click();f.button('取消').click();resolve({filePaths:['C:/late']});await tick();assert.equal(f.calls.preview.length,0);assert.equal(f.w.document.querySelectorAll('.et-module-prompt').length,0);
 f.ui.importForm();f.input().value='C:/slow.zip';f.input().dispatchEvent(new f.w.Event('input'));f.ui.store.preview=()=>new Promise(r=>resolve=r);f.button('预览安装').click();f.button('取消').click();f.ui.store.previews.set('late',{});resolve({token:'late',manifest:f.manifest,compatible:true});await tick();assert.equal(f.ui.store.previews.size,0);assert(!f.button('确认安装'));
});
test('background refresh does not re-enable controls during a pending native picker',async t=>{
 const f=setup(t);await f.open();f.ui.importForm();let resolve;f.picker(()=>new Promise(r=>resolve=r));f.button('选择模块文件夹').click();await f.ui.render();assert(f.input().disabled);assert(f.button('预览安装').disabled);resolve({canceled:true});await tick();assert(!f.input().disabled);assert(f.button('预览安装').disabled);
});
