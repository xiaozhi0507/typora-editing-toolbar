'use strict';
const fs=require('node:fs'),path=require('node:path');
module.exports=body=>{
 const dest=path.resolve(__dirname,'../plugin/editing-toolbar.modules/ai-reading-assistant');fs.mkdirSync(dest,{recursive:true});
 const manifest={format:'typora-toolbar-module',schemaVersion:1,apiVersion:1,id:'ai-reading-assistant',name:'AI 阅读助手',version:'1.3.4',minHostVersion:'1.114.3',icon:'ai-reading-assistant',documentationUrl:'https://github.com/xiaozhi0507/typora-editing-toolbar/blob/main/docs/ai-reading-assistant.md',author:'Typora Editing Toolbar',description:'阅读问答、编辑、GPT 网页、对话历史、提示词、技能、AI 插件连接、项目、终端、代码编辑与 Notebook。',permissions:['styles','commands','document-read','ai-assistant']};
 const scope=fs.readFileSync(path.join(__dirname,'ai-module-scope.cjs'),'utf8');
 const globals=['ETKnowledgeStorage','ETKnowledgeManaged','ETCodeWorkspace','ETDocumentProjects','ETTerminalEnvironment','ETNotebookStore','ETAIWeb','ETAIExecution','ETAIShell'];
 const bindings=globals.map(n=>'const '+n+'=host.globals.'+n+';').join('\n')+'\nconst ETAIPlugins=host.globals.ETConnectionStore;';
 const main=`'use strict';\nconst AIModuleScope=(()=>{const module={exports:{}};${scope};return module.exports;})();
module.exports={async activate(api){
 const host=api.assistant;if(!host||host.version!==1)throw Error('请升级工具栏以使用 AI 阅读助手');
 const scope=new AIModuleScope(globalThis,globalThis.document);api.register(()=>scope.close());
 return await (async function(window,document,setTimeout,clearTimeout,setInterval,clearInterval,requestAnimationFrame,cancelAnimationFrame,AbortController,MutationObserver,ResizeObserver,IntersectionObserver){
 ${bindings}
 ${require("./build-ai-workspace.cjs")()}
 ${body}
 ${fs.readFileSync(path.join(__dirname,'ai-module-entry.js'),'utf8')}
 })(scope.window,scope.document,scope.setTimeout,scope.clearTimeout,scope.setInterval,scope.clearInterval,scope.requestAnimationFrame,scope.cancelAnimationFrame,scope.AbortController,scope.MutationObserver,scope.ResizeObserver,scope.IntersectionObserver);
}};`;
 new Function('module',main);fs.writeFileSync(path.join(dest,'main.js'),main);
 fs.writeFileSync(path.join(dest,'module.json'),JSON.stringify(manifest,null,2));
 const css=["ai-python-settings.css","terminal-panel.css","code-editor.css","notebook.css","document-projects.css","ai-chatgpt.css","ai-assistant.css","ai-images.css","ai-conversations.css","ai-selection.css","ai-rich-composer.css","ai-code-edit.css","ai-references.css","ai-execution.css","ai-chat-navigation.css","ai-context.css","ai-web-chat.css","ai-usage-browser.css","ai-skills.css","ai-plugins.css","ai-effort.css","ai-document-edit.css","ai-input-media.css","ai-composer-controls.css","ai-web.css","ai-message-queue.css"].map(f=>fs.readFileSync(path.join(__dirname,f),'utf8')).join('\n');fs.writeFileSync(path.join(dest,'styles.css'),css);
 require('esbuild').buildSync({entryPoints:[path.join(__dirname,'ai-chatgpt-worker.cjs')],bundle:true,platform:'node',target:'node18',outfile:path.join(dest,'chatgpt.cjs')});
 return dest;
};
