'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs/promises'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto');
const {JSDOM}=require('jsdom'),Store=require('./feature-module-store.cjs'),Runtime=require('./feature-module-runtime.cjs');
const tmp=process.env.CODEX_TEST_TMP||'C:/Users/xiaozhi/Downloads/codex-temp';
test('fresh host starts without seeding legacy AI resources; explicit installs survive restart',async t=>{
 const root=path.join(tmp,'clean-host-'+crypto.randomUUID());await fs.mkdir(root,{recursive:true});
 t.after(async()=>{assert(path.resolve(root).startsWith(path.resolve(tmp)+path.sep));await fs.rm(root,{recursive:true,force:true});});
 const resources=path.join(root,'resources'),bundle=path.join(resources,'editing-toolbar.modules','ai-reading-assistant');await fs.mkdir(bundle,{recursive:true});
 await fs.writeFile(path.join(bundle,'module.json'),JSON.stringify({format:'typora-toolbar-module',schemaVersion:1,apiVersion:1,id:'ai-reading-assistant',name:'AI',version:'1.2.1',minHostVersion:'1.110.0',permissions:[]}));
 await fs.writeFile(path.join(bundle,'main.js'),'module.exports={activate(){}}');
 const source=await fs.readFile(path.join(__dirname,'feature-modules.js'),'utf8');
 async function start(){
  const dom=new JSDOM('<body>',{url:'https://local.test',runScripts:'outside-only'}),w=dom.window;
  w.File={option:{userDataPath:path.join(root,'profile')}};w.ETFeatureStore=Store;w.ETFeatureRuntime=Runtime;
  w.reqnode=name=>name==='process'?{...process,resourcesPath:resources}:require(name);
  const UI=vm.runInContext(source+'\nEditingToolbarFeatureModules',dom.getInternalVMContext()),ui=Object.create(UI.prototype);ui.toolbar={_showToolbarNotice:message=>assert.fail(message)};
  await ui.init();return {ui,close:async()=>{await ui.runtime.close();w.close();}};
 }
 const first=await start();assert.deepEqual((await first.ui.store.state()).installed,{});assert.equal(first.ui.runtime.running.size,0);
 const preview=await first.ui.store.preview(bundle);await first.ui.store.install(preview.token);assert.equal((await first.ui.store.state()).installed['ai-reading-assistant'].enabled,false);
 await first.ui.store.enable('ai-reading-assistant',true);await first.ui.changed();assert.equal(first.ui.runtime.running.size,1);await first.close();
 const second=await start();assert.equal(second.ui.runtime.running.size,1);await second.ui.store.enable('ai-reading-assistant',false);await second.ui.runtime.reconcile();await second.ui.store.uninstall('ai-reading-assistant');await second.close();
 const third=await start();assert.deepEqual((await third.ui.store.state()).installed,{});assert.equal(third.ui.runtime.running.size,0);await third.close();
});
