const fs=require('node:fs'),path=require('node:path');
module.exports=code=>{
 const replace=(a,b)=>{if(!code.includes(a))throw Error('Missing feature module integration: '+a);code=code.replace(a,b);};
 const icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><path d="M17.5 14v7M14 17.5h7"/></svg>';
 replace('const BUTTON_DEFINITIONS = {','const BUTTON_DEFINITIONS = {\n"feature-modules":{icon:'+JSON.stringify(icon)+',title:"插件市场"},');
 replace('    _executeAction(action) {','    _executeAction(action) {\n        if(action === "feature-modules") {this.featureModules?.open().catch(e=>this._showToolbarNotice(e.message));return;}');
 replace('    _mountToolbarUI() {','    _mountToolbarUI() {\n        this.featureModules ||= new EditingToolbarFeatureModules(this);');
 replace('return ["undo","redo","heading-menu"','return ["feature-modules","undo","redo","heading-menu"');
 replace('title:"更多功能",actions:[','title:"更多功能",actions:["feature-modules",');
 replace('        const top = topLayout === "classic"',`        if(!input.featureModulesRevision&&!compact.menus['more-menu'].includes('feature-modules'))compact.menus['more-menu'].push('feature-modules');
        const top = topLayout === "classic"`);
 code=code.replaceAll('return {version:1,layoutRevision:3,','return {version:1,layoutRevision:3,featureModulesRevision:1,');
 replace('    _editingNotePanel(){return ','    _editingNotePanel(){return document.activeElement?.closest?.(".et-module-center,.et-module-prompt")||');
 const bundle=(file,name)=>require('esbuild').buildSync({entryPoints:[path.join(__dirname,file)],bundle:true,format:'iife',globalName:name,platform:'browser',write:false,minify:true}).outputFiles[0].text;
 const pos=code.lastIndexOf('(function () {');if(pos<0)throw Error('Missing feature module boot');return code.slice(0,pos)+bundle('feature-module-store.cjs','ETFeatureStore')+'\n'+bundle('feature-module-runtime.cjs','ETFeatureRuntime')+'\n'+fs.readFileSync(path.join(__dirname,'feature-modules.js'),'utf8')+'\n'+code.slice(pos);
};
