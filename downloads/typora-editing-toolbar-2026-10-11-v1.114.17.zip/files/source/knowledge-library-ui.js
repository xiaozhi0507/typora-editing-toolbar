
  (()=>{
    const root=document.getElementById('et-knowledge-library'),q=s=>root.querySelector(s),qa=s=>[...root.querySelectorAll(s)];
    const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const icon=(name)=>`<i data-lucide="${name}" aria-hidden="true"></i>`;
    const typeNames={paper:'期刊文章',thesis:'学位论文',book:'书籍',webpage:'网页',note:'旧条目'},editableTypes=['paper','thesis','book'],typeIcons={paper:'file-text',thesis:'graduation-cap',book:'book-open',webpage:'globe',note:'notebook-pen'},statuses={unread:'未读',reading:'在读',done:'已读'};
    const isWeb=f=>f?.linkType==='url',canNote=f=>f&&!isWeb(f)&&/\.(md|markdown|mdown|txt)$/i.test(f.path),fileIcon=f=>isWeb(f)?'link':f.kind==='PDF'?'file':'file-text';
    let attachmentMenu=null,attachmentDraft=null,webOnlyList=false;
    const bridge=window.KnowledgeLibraryBridge;
    if(bridge.workspace)root.dataset.workspace="true";
    root.dataset.workspacePane="list";
    function workspacePane(name){root.dataset.workspacePane=name;for(const b of qa("button[data-workspace-pane]"))b.setAttribute("aria-pressed",String(b.dataset.workspacePane===name));}
    root.addEventListener("click",e=>{const tab=e.target.closest("[data-workspace-pane]");if(!tab||!tab.matches("button"))return;root.dataset.workspacePane=tab.dataset.workspacePane;if(tab.dataset.workspacePane==="detail"){state.detailCollapsed=false;renderDetail();updateIcons();}for(const b of qa("button[data-workspace-pane]"))b.setAttribute("aria-pressed",String(b===tab));applyLayout();});
    let duplicateCache={key:'',groups:[],ids:new Set(),byID:new Map()},mergeDraft=null,merging=false;
    function refreshDuplicates(){
      const key=JSON.stringify(items.map(i=>[i.id,i.type,i.deleted,i.doi,i.isbn,i.title,i.author,i.date,i.year]));
      if(key!==duplicateCache.key){const groups=bridge.duplicateGroups(items);duplicateCache={key,groups,ids:new Set(groups.flat()),byID:new Map(groups.flatMap(g=>g.map(id=>[id,g])))};}
      return duplicateCache;
    }
    const duplicateAlertsSeen=new Set();let duplicateAlertTimer=null,refreshPending=false;
    const duplicateAlertKey=ids=>JSON.stringify([base?.libraryId,...[...ids].sort()]);
    function queueDuplicateAlert(delay=180){
      clearTimeout(duplicateAlertTimer);duplicateAlertTimer=setTimeout(()=>{
        duplicateAlertTimer=null;
        if(!base||!bridge.metricsActive()||state.reader)return;
        const groups=refreshDuplicates().groups.filter(ids=>!duplicateAlertsSeen.has(duplicateAlertKey(ids)));
        if(!refreshPending&&(!groups.length||state.view==='duplicates'))return;
        if(loading||refreshJob||modal||dirty()||summaryEditor||tagEditor||infoEditor||notePane||!q('[data-menu]').hidden){queueDuplicateAlert(600);return;}
        if(refreshPending){void run(refresh).then(queueDuplicateAlert);return;}
        showDuplicateAlert(groups);
      },delay);
    }
    function showDuplicateAlert(groups){
      groups.forEach(ids=>duplicateAlertsSeen.add(duplicateAlertKey(ids)));
      previousFocus=document.activeElement;modal='duplicate-alert';q('[data-menu]').hidden=true;
      const form=q('[data-form]');form.classList.add('is-compact-confirm','is-duplicate-dialog');form.setAttribute('aria-describedby','kb-duplicate-summary');
      form.innerHTML=`<header data-dialog-move title="按住标题栏拖动"><h3 id="kb-modal-title">发现重复条目</h3><button type="button" data-do="cancel" aria-label="关闭对话框">${icon('x')}</button></header><div class="kb-duplicate-intro">${icon('copy')}<div><strong>有 ${groups.length} 组文献可能重复</strong><p id="kb-duplicate-summary">查看条目版本，选择需要保留的信息。</p></div></div><div class="kb-duplicate-groups">${groups.map(ids=>{const item=byID(ids[0]);return `<section class="kb-duplicate-card"><div class="kb-duplicate-card-heading"><span>${ids.length} 个条目</span><button type="button" class="kb-outline" data-duplicate-review="${escape(item.id)}">前往合并${icon('chevron-right')}</button></div><h4>${escape(itemTitle(item))}</h4><p>${escape([item.author,item.date||item.year].filter(Boolean).join(' · '))}</p></section>`;}).join('')}</div><footer><span>附件与笔记将在合并时保留</span><button type="button" class="kb-outline" data-do="cancel">稍后处理</button></footer>`;
      q('[data-shade]').hidden=false;updateIcons();openFloatingDialogLayout('confirm',480);form.querySelector('[data-duplicate-review]').focus({preventScroll:true});
    }
    function mergeMembers(){return selectionIDs().map(byID).filter(Boolean);}
    function mergeSignature(members){return JSON.stringify(members.map(({notes,...i})=>i));}
    function mergeValue(value,key,item){if(key==='resourceUrls'&&item)value=resourceURLs(item);if(key==='metrics'){if(!value)return '';const v=bridge.metricValues({...item,metrics:value});return [...v.badges.map(b=>b.text),...v.citationBadges.map(b=>b.text)].join(' · ')||'已保存的文献指标';}return Array.isArray(value)?value.join('；'):String(value??'');}
    function renderMergePane(){
      const members=mergeMembers(),eligible=members.length>1&&members.every(i=>!i.deleted&&i.type===members[0].type),pane=q('[data-detail]');
      if(!eligible){mergeDraft=null;pane.innerHTML=`<div class="kb-detail-content"><div class="kb-empty">${members.length>1?'请选择类型相同的条目':'选择要合并的项'}</div></div><nav class="kb-detail-rail">${paneToggleMarkup()}</nav>`;applyLayout();return;}
      const signature=mergeSignature(members);
      if(mergeDraft?.signature!==signature){const description=bridge.mergeDescription(members);mergeDraft={signature,ids:members.map(i=>i.id),masterId:description.masterId,choices:{}};}
      const description=bridge.mergeDescription(members,mergeDraft.masterId),master=byID(mergeDraft.masterId),labels=new Map(members.flatMap(infoDefinitions));
      for(const [key,label]of [['summary','摘要'],['year','年份'],['metrics','文献指标'],['journalTag','期刊标签'],['citationCount','被引数'],['citedCount','被引数'],['impactFactor','影响因子']])labels.set(key,label);
      const versions=[...members].sort((a,b)=>(Date.parse(a.added)||0)-(Date.parse(b.added)||0)||a.id.localeCompare(b.id));
      const fields=description.fields.filter(f=>metricsEligible(master)||!['metrics','journalTag','citationCount','citedCount','impactFactor'].includes(f.key)).map(f=>{
        const chosen=mergeDraft.choices[f.key]||f.sourceId,source=byID(chosen),value=f.key==='resourceUrls'&&source?resourceURLs(source):source?.[f.key]??'',label=labels.get(f.key)||f.key;
        return `<div class="kb-merge-field"><label for="merge-field-${f.key}">${escape(label)}</label>${f.variants.length>1?`<select id="merge-field-${f.key}" data-merge-field="${f.key}" aria-label="保留${escape(label)}">${f.variants.map(v=>{const text=mergeValue(v.value,f.key,byID(v.sourceId))||'（空）';return `<option value="${escape(v.sourceId)}" ${chosen===v.sourceId?'selected':''}>${escape(text.length>140?text.slice(0,140)+'…':text)}</option>`;}).join('')}</select>`:''}<div class="kb-merge-value" data-merge-value="${f.key}">${escape(mergeValue(value,f.key,source)||'（空）')}</div></div>`;
      }).join('');
      pane.innerHTML=`<div class="kb-detail-content kb-merge-panel"><div class="kb-merge-top"><button type="button" class="kb-outline kb-merge-submit" data-merge-submit ${merging?'disabled':''}>${merging?'正在合并…':'合并 '+members.length+' 个条目'}</button><p>选择作为主条目的版本</p><div class="kb-merge-versions" role="group" aria-label="主条目版本">${versions.map((i,n)=>`<button type="button" data-merge-master="${escape(i.id)}" aria-pressed="${i.id===master.id}" title="${escape(itemTitle(i))}"><span>${escape(i.added?fullDate(i.added):'版本 '+(n+1))}</span><small>${i.files.length} 个附件</small></button>`).join('')}</div></div><div class="kb-merge-fields"><p>选择需要保留的字段</p><h3>${icon('file-text')}信息</h3>${fields}<p class="kb-muted kb-small">合并保留附件、笔记、标签和分类。</p></div></div><nav class="kb-detail-rail">${paneToggleMarkup()}</nav>`;
      applyLayout();updateIcons();
    }
    function openDuplicates(id){
      if(!leaveNotePane()||!commitInfoEdit()||tagEditor&&!commitTagEdit())return;
      commitSummaryEdit();state.view='duplicates';state.query='';clearItemFilters();state.detailCollapsed=false;state.checked=[];state.selected=null;mergeDraft=null;refreshDuplicates();
      if(id&&duplicateCache.byID.has(id)){state.checked=[...duplicateCache.byID.get(id)];state.selected=id;}
      render();persist();
    }
    async function mergeSelected(){
      if(merging||!mergeDraft)return;
      const request=clone(mergeDraft);merging=true;
      try{
        if(!await flush())return;
        if(mergeSignature(mergeMembers())!==request.signature){mergeDraft=null;renderMergePane();throw Error('条目已更新，请检查当前版本后再合并。');}
        loading=true;libraryGeneration++;q('[data-library]').inert=true;q('[data-save-status]').textContent='正在合并…';
        const button=q('[data-merge-submit]');if(button){button.disabled=true;button.textContent='正在合并…';}
        const result=await bridge.mergeDuplicates(clone(base),{ids:request.ids,masterId:request.masterId,choices:request.choices});
        mergeDraft=null;state.selected=state.view==='duplicates'?null:result.masterId;state.checked=[];
        loadLibrary(result.data,{state,design});saveView();notify('已合并 '+result.count+' 个条目，其他版本已移入回收站');
      }finally{merging=false;loading=false;q('[data-library]').inert=false;q('[data-save-status]').textContent=saveError?'尚未保存':'已保存';if(q('[data-merge-submit]'))renderMergePane();}
    }
    root.addEventListener('change',event=>{const field=event.target.dataset.mergeField;if(field&&mergeDraft){mergeDraft.choices[field]=event.target.value;const source=byID(event.target.value);q('[data-merge-value="'+field+'"]').textContent=mergeValue(source?.[field]??'',field,source)||'（空）';}});
    let items=[],collections=[],state={view:'all',sections:{info:true},activeSection:'info',detailCollapsed:false,closedGroups:[],tagQuery:'',selected:null,query:'',tags:[],showAutomaticTags:true,showAllTags:false,statusFilter:'',ratingFilter:0,tab:'info',sort:'recent',expanded:[],checked:[],reader:null};
    const design={density:'compact',navWidth:200,detailWidth:300,tagHeight:155,palette:'default'},newID=()=>globalThis.crypto?.randomUUID?.()||'item-'+Date.now()+'-'+Math.random().toString(36).slice(2);
    let modal=null,previousFocus=null,itemDraft=null,editingItemId=null,importToken=null,purgeDraft=null,typeChangeDraft=null,purging=false;
    const byID=id=>items.find(i=>i.id===id),selected=()=>byID(state.selected),activeItems=()=>items.filter(i=>!i.deleted);
    const updateIcons=()=>globalThis.lucide?.createIcons({attrs:{width:16,height:16}});
    const notify=text=>{const message=q('[data-message]');message.textContent=text;message.removeAttribute('title');};
    const clone=value=>JSON.parse(JSON.stringify(value));
    let base=null,saving=null,saveError='',loading=false,metadataJob=null,libraryGeneration=0;
    let summaryEditor=null,summarySourceDraft=null,refreshJob=null,detailSignature='',detailItemID=null,noteObserver=null,tagEditor=null,tagSearchPending=false;
    let notePane=null;
    const detailPositions=new Map(),metadataChecks=new Map(),searchCache=new WeakMap(),summaryUndo=new Map();
    const typeMetadataPending=new Map();let typeMetadataRequest=0;
    let metadataFollowup=false,summarySearchPending=false;
    const snapshot=()=>({...clone(base),items:items.map(({notes,...item})=>clone(item)),collections:clone(collections)});
    const equalData=(a,b)=>JSON.stringify(a?.items)===JSON.stringify(b?.items)&&JSON.stringify(a?.collections)===JSON.stringify(b?.collections);
    function dirty(){return !!collectionTreeDrag?.active||merging||purging||!!infoEditor&&infoEditor.input.value!==infoEditor.original||!!summaryEditor&&summaryEditor.value!==summaryEditor.original||!!tagEditor&&tagEditor.input.value!==(tagEditor.original||'')||!!importToken||!!base&&(!equalData(base,snapshot())||!!saving);}
    let retryOpen=null;
    function showError(message,retry=null){retryOpen=retry;q('[data-library-error]').hidden=false;q('[data-error-text]').textContent=message;for(const action of ['retry-save','reload-library'])q('[data-library-error] [data-do="'+action+'"]').hidden=!!retry;for(const action of ['retry-open','close-library'])q('[data-library-error] [data-do="'+action+'"]').hidden=!retry;}
    function clearError(){retryOpen=null;q('[data-library-error]').hidden=true;}
    function run(action){return Promise.resolve().then(action).catch(error=>{showError(error.message);return false;});}
    function saveView(){if(base)bridge.savePreferences({state:{...state,checked:[],reader:null},design});}
    function persist(){saveView();if(base&&!loading)void flush(false);}
    function flush(commitTags=true){
      if(commitTags&&!bridge.flushNotePane())return Promise.resolve(false);
      if(summaryEditor?.composing||commitTags&&(tagEditor?.composing||infoEditor?.composing))return Promise.resolve(false);
      if(commitTags){commitInfoEdit();commitTagEdit();}
      commitSummaryEdit();
      if(saving)return saving;
      if(!base||equalData(base,snapshot()))return Promise.resolve(true);
      q('[data-save-status]').textContent='正在保存…';
      saving=(async()=>{
        while(!equalData(base,snapshot())){
          const next=snapshot(),saved=await bridge.commit(clone(base),next),current=snapshot();
          const merged=bridge.merge(next,current,saved),changed=!equalData(current,merged);
          base=clone(saved);items=merged.items.map(i=>({...i,notes:[]}));collections=merged.collections;
          if(changed){normalizePreferences();pickVisible();render();}
        }
        saveError='';clearError();q('[data-save-status]').textContent='已保存';return true;
      })().catch(error=>{saveError=error.message;q('[data-save-status]').textContent='尚未保存';showError('修改尚未保存：'+error.message);return false;}).finally(()=>{saving=null;if(!saveError)queueMicrotask(resumeTypeMetadata);queueDuplicateAlert();});
      return saving;
    }
    function loadLibrary(data,preferences={},warning=''){
      if(!leaveNotePane())return;
      endColumnOrder(true);endCollectionTree(true);
      tagEditor=null;tagSearchPending=false;infoEditor=null;infoSearchPending=false;isbnStates.clear();addedInfoFields.clear();infoTouches.clear();
      closeCollectionMenu();tagRemoval=null;const sameLibrary=base?.libraryId===data.libraryId;captureDetailPosition();
      libraryGeneration++;metadataJob=null;metricsJob=null;metadataChecks.clear();typeMetadataPending.clear();if(!sameLibrary){detailPositions.clear();detailItemID=null;summaryUndo.clear();}detailSignature='';summaryEditor=null;loading=true;base=clone(data);items=clone(data.items).map(i=>({...i,notes:[]}));collections=clone(data.collections);
      Object.assign(state,{tags:undefined,tag:'',tagQuery:'',showAutomaticTags:true,showAllTags:false,statusFilter:'',ratingFilter:0,...(preferences.state||{view:'all',selected:null,query:'',tag:''})},{checked:[],reader:null});Object.assign(design,preferences.design||{});
      design.columns=preferences.design?.columns;
      design.collectionColumnDefaults=preferences.design?.collectionColumnDefaults;
      design.collectionColumns=preferences.design?.collectionColumns;
      design.columnOrder=preferences.design?.columnOrder;
      design.hiddenColumns=preferences.design?.hiddenColumns;
      design.columnSizing=preferences.design?.columnSizing;
      design.dialogSizingVersion=preferences.design?.dialogSizingVersion;
      saveError='';noteCache.clear();noteRequests.clear();noteMenu=null;noteRemoval=null;normalizePreferences();pickVisible();render();loading=false;
      q('[data-library]').inert=false;q('[data-save-status]').textContent='已保存';q('[data-root-label]').textContent=bridge.root();q('[data-root-label]').title='更换知识库目录 · '+bridge.root();
      for(const button of qa('.kb-top [data-do="new"],.kb-top [data-do="collection"]'))button.disabled=false;
      if(warning)showError(warning);else clearError();
    }
    function refresh(){
      refreshInfoSearch();refreshTagSearch();
      refreshSummarySearch();
      if(refreshJob){refreshPending=true;queueDuplicateAlert();return refreshJob;}
      if(!base||dirty()||modal||summaryEditor||tagEditor||infoEditor||notePane){if(base){refreshPending=true;queueDuplicateAlert();}return Promise.resolve();}
      refreshPending=false;
      const generation=libraryGeneration;
      const job=(async()=>{
        const result=await bridge.read();if(!result)throw new Error('知识库文件已移走，请重新选择目录。');
        if(generation!==libraryGeneration)return;
        if(dirty()||modal||summaryEditor||tagEditor||infoEditor||notePane){refreshPending=true;queueDuplicateAlert();return;}
        if(result.data.revision!==base.revision||result.data.libraryId!==base.libraryId)loadLibrary(result.data,{state,design},result.warning||'');
        loadVisibleNotes(true);refreshExpandedNotes();
        await syncMetadata({force:false});
      })().finally(()=>{if(refreshJob===job)refreshJob=null;queueDuplicateAlert();});
      refreshJob=job;return job;
    }
    function resumeTypeMetadata(){
      for(const id of typeMetadataPending.keys())if(!byID(id)||byID(id).deleted)typeMetadataPending.delete(id);
      if(typeMetadataPending.size&&!saving&&!saveError&&!dirty())void syncMetadata({forTypeChange:true});
    }
    function syncMetadata({force=true,onlySelected=false,forTypeChange=false}={}){
      if(!base||loading||modal||importToken||summaryEditor||tagEditor||infoEditor)return Promise.resolve();
      if(metadataJob){if(onlySelected)metadataFollowup=true;return metadataJob;}
      const generation=libraryGeneration;
      const pending=items.filter(i=>i.type!=='webpage'&&!i.deleted&&(!forTypeChange||typeMetadataPending.has(i.id))&&(!onlySelected||i.id===state.selected)&&(force||i.id===state.selected||Date.now()-(metadataChecks.get(i.id)||0)>10000)).map(i=>i.id);
      let readFailed=false;
      const job=(async()=>{
        const warnings=[];let total=0;
        while(pending.length){
          if(generation!==libraryGeneration||modal||importToken||summaryEditor||tagEditor||infoEditor)break;
          const at=pending.indexOf(state.selected);if(at>0)pending.unshift(pending.splice(at,1)[0]);
          // Prioritize the selected document, then yield between bounded background batches.
          const ids=pending.splice(0,pending[0]===state.selected?1:12);
          const typeRequests=new Map(ids.map(id=>[id,typeMetadataPending.get(id)]));
          const result=await bridge.readMetadata(ids.map(byID).filter(Boolean).map(clone));
          if(generation!==libraryGeneration||modal||importToken||summaryEditor||tagEditor||infoEditor)break;
          ids.forEach(id=>metadataChecks.set(id,Date.now()));
          ids.forEach(id=>{if(typeMetadataPending.get(id)===typeRequests.get(id))typeMetadataPending.delete(id);});
          let changed=false;
          for(const record of result.records){
            const item=byID(record.id);if(!item||item.deleted)continue;
            const next=bridge.applyMetadata(clone(item),record);
            if(JSON.stringify(item)!==JSON.stringify(next)){Object.assign(item,next);total++;changed=true;}
          }
          warnings.push(...result.warnings);
          if(changed){pickVisible();render();persist();await flush(false);}
          if(pending.length)await new Promise(resolve=>setTimeout(resolve,0));
        }
        if(generation!==libraryGeneration)return;
        if(total&&!saveError)notify('已读取 '+total+' 个条目的元数据');
        if(warnings.length){notify(warnings.length+' 个条目的元数据暂未读取');q('[data-message]').title=warnings.join('\n');}
      })().catch(error=>{readFailed=true;if(generation===libraryGeneration)showError('读取元数据失败：'+error.message);}).finally(()=>{
        if(metadataJob!==job)return;metadataJob=null;
        if(metadataFollowup){metadataFollowup=false;void syncMetadata({onlySelected:true});}
        if(!readFailed)queueMicrotask(resumeTypeMetadata);
      });
      metadataJob=job;return job;
    }

let metricsJob=null,metricsTargetKey='',openMetricRound=null,metricRoundID=0;
function onLibraryOpen(){
  openInformationPane(false);
  queueDuplicateAlert();
  const round=openMetricRound={id:'open-'+(++metricRoundID),generation:libraryGeneration};
  if(bridge.metricsSettings().automatic)void syncMetrics(true,true,round);
}
function onLibraryClose(){clearTimeout(duplicateAlertTimer);if(modal==='duplicate-alert')closeModal();endCollectionTree(true);openMetricRound=null;if(leaveNotePane()){detailSignature='';renderDetail();updateIcons();}}
const metricsEligible=item=>bridge.metricsEligible(item);
const metricValues=item=>bridge.metricValues(item);
function metricMarkup(item,kind){
  const value=metricValues(item);
  if(kind==='journal')return value.badges.length?`<span class="kb-metric-badges" title="${escape(value.publicationTip)}">${value.badges.map(b=>`<span class="kb-metric-badge" style="${escape(b.style)}">${escape(b.text)}</span>`).join('')}</span>`:escape(value.legacyJournal||'');
  if(kind==='impact')return value.impact===null?'':`<span class="kb-impact" title="${escape(value.impactLabel+' · '+value.publicationTip)}"><span class="kb-impact-track"><span style="width:${Math.min(100,value.impact/15*100)}%"></span></span><span>${value.impact}</span></span>`;
  return value.citationBadges.length?`<span class="kb-metric-badges">${value.citationBadges.map(b=>`<span class="kb-metric-badge" style="${escape(b.style)}" title="${escape(b.tip)}">${escape(b.text)}</span>`).join('')}</span>`:'';
}
function metricDetail(item){
  if(!metricsEligible(item))return '';
  const fields=item.type==='paper'?[['期刊标签','journal'],['影响因子','impact'],['被引数','cites']]:[['被引数','cites']];
  return '<dl class="kb-info-fields kb-metric-detail">'+fields.map(([label,key])=>`<dt>${label}</dt><dd class="kb-metric-value" data-metric-field="${key}">${metricMarkup(item,key)||'—'}</dd>`).join('')+'</dl>';
}
function syncMetrics(force=false,all=false,round=null){
  // Only an explicit open event or a manual command starts a round; focus and row changes do not.
  if(!force||!base||!bridge.metricsActive()||round&&(openMetricRound!==round||round.generation!==libraryGeneration))return Promise.resolve();
  const access=bridge.metricsSettings();
  if(!access.hasKey&&!access.hasSemanticKey){if(!round)notify('请先在列设置中配置指标 API Key');return Promise.resolve();}
  if(!round&&(loading||modal||importToken||summaryEditor))return Promise.resolve();
  const targetKey=JSON.stringify([libraryGeneration,all?'all':selectionIDs().slice().sort()]);
  if(metricsJob){
    if(!round&&metricsTargetKey===targetKey)return metricsJob;
    const currentGeneration=libraryGeneration;return metricsJob.then(()=>currentGeneration===libraryGeneration?syncMetrics(true,all,round):undefined);
  }
  const generation=libraryGeneration,startedAt=Date.now(),targets=(force&&!all?selectionIDs().map(byID):items).filter(i=>i&&!i.deleted&&metricsEligible(i)).sort((a,b)=>Number(b.id===state.selected)-Number(a.id===state.selected)).map(i=>i.id);
  if(!targets.length)return Promise.resolve();
  const valid=()=>generation===libraryGeneration&&bridge.metricsActive()&&(!round||openMetricRound===round&&bridge.metricsSettings().automatic);
  const busy=()=>loading||modal||importToken||summaryEditor||tagEditor||infoEditor||columnDrag||columnOrderDrag||resizeSession;
  const ready=async()=>{while(round&&valid()&&busy())await new Promise(resolve=>setTimeout(resolve,150));return valid()&&!busy();};
  const job=(async()=>{let changedCount=0,cnkiPrompted=false;const warnings=[];
    for(let n=0;n<targets.length;n++){
      if(!await ready())break;
      const current=byID(targets[n]);if(!current||current.deleted||!metricsEligible(current))continue;
      if(force)notify(`正在更新文献指标 ${n+1}/${targets.length}…`);
      const result=await bridge.readMetrics([clone(current)],{force,startedAt,round:round?.id||'',verifyCNKI:async()=>{
        if(cnkiPrompted||!valid())return false;cnkiPrompted=true;
        notify('知网需要人工验证，完成后将继续更新；关闭验证窗口可跳过本轮。');
        return await bridge.verifyCNKI()&&valid();
      }});
      if(!await ready())break;
      warnings.push(...result.warnings);
      let changed=false;
      for(const record of result.records){const item=byID(record.id);if(!item||item.deleted||!metricsEligible(item))continue;const identity=bridge.metricIdentity(item),next={...(item.metrics||{})};
        if(record.publication&&record.journal===identity.journal)next.publication={...bridge.mergeMetric(next.publication?.query===record.journal?next.publication:null,record.publication),query:record.journal};
        if(record.citations&&record.citations.identity===bridge.citationIdentity(item)){const old=next.citations,oldID=old?.identity||(old?.doi?'doi:'+old.doi:'');next.citations={...bridge.mergeMetric(oldID===record.citations.identity?old:null,record.citations),doi:record.doi};}
        if(Object.keys(next).length&&JSON.stringify(next)!==JSON.stringify(item.metrics)){item.metrics=next;changed=true;changedCount++;}
      }
      if(changed){pickVisible();render();persist();if(!await flush())break;}
    }
    if(!valid())return;
    if(force||changedCount||warnings.length){const unique=[...new Set(warnings)];notify(unique.length?(changedCount?'已更新 '+changedCount+' 项；':'')+unique[0]+'；未获取的指标保留原值':changedCount?'已更新 '+changedCount+' 个条目的文献指标':force?'文献指标已检查；书籍请核对 ISBN，其他文献请核对标题、作者、年份、知网链接或 DOI':'');q('[data-message]').title=unique.join('\n');}
  })().catch(error=>{if(generation===libraryGeneration)notify('文献指标暂未更新：'+error.message);}).finally(()=>{if(metricsJob===job)metricsJob=null;});
  metricsTargetKey=targetKey;metricsJob=job;return job;
}
function saveMetricsSettings(){
  const form=q('[data-form]'),data=new FormData(form),value=Object.fromEntries(data.entries());
  for(const key of ['automatic','useZotero','clearKey'])if(form.elements.namedItem(key))value[key]=data.has(key);
  for(const name of ['secretKey','semanticKey']){
    const secret=form.elements.namedItem(name);
    if(secret?.hasAttribute('data-preserve-secret')){
      if(secret.dataset.preserveSecret==='true')delete value[name];
      else if(name==='secretKey'&&!secret.value.trim()){value.clearKey=true;value.useZotero=false;}
    }
  }
  bridge.saveMetricsSettings(value);detailSignature='';closeModal();render();notify('文献指标设置已保存');
}

const metricSecretInput=(s,name='secretKey')=>`<input id="kb-setting-${name}" name="${name}" type="text" value="${escape(name==='semanticKey'?bridge.semanticSecret():bridge.metricSecret())}" data-preserve-secret="${(name==='semanticKey'?s.hasSemanticKey:s.hasKey)?'true':'false'}" autocomplete="off" spellcheck="false" aria-label="${name==='semanticKey'?'Semantic Scholar':'easyScholar'} API Key">`;
function selectImpactField(){
  const form=q('[data-form]'),select=form.elements.namedItem('impactField');if(!select)return;
  const value=bridge.selectImpact({fields:form.elements.namedItem('fields').value,sortBy:form.elements.namedItem('sortBy').value},select.value);
  for(const name of ['fields','sortBy'])form.elements.namedItem(name).value=value[name];
}
const citationFieldOptions=bridge.citationFields();
function renderCitationFieldChips(){
  const form=q('[data-form]'),input=form.elements.namedItem('citationFields'),box=q('[data-citation-field-chips]');if(!input||!box)return;
  const fields=[...new Set(input.value.split(/[,，]/).map(v=>v.trim()).filter(Boolean))];
  const colors=String(form.elements.namedItem('citationColors')?.value||'');
  box.innerHTML=fields.map((field,n)=>`<span class="kb-setting-chip" style="--chip-color:${bridge.citationColor(field,colors)}"><span>${escape(field)}</span><button type="button" data-remove-citation-field="${escape(field)}" aria-label="移除 ${escape(field)}">${icon('x')}</button></span>`).join('')+`<button type="button" class="kb-add-field" data-add-citation-field aria-expanded="false">${icon('plus')}添加字段</button><div class="kb-field-picker" data-citation-field-picker role="group" aria-label="添加字段" hidden>${citationFieldOptions.filter(v=>!fields.includes(v)).map(v=>`<button type="button" data-citation-field-choice="${escape(v)}">${escape(v)}</button>`).join('')||'<span class="kb-no-fields">没有其他可用字段</span>'}</div>`;
  updateIcons();
}
function updateMetricRange(input){if(input.type!=='range')return;const percent=(Number(input.value)-Number(input.min))/(Number(input.max)-Number(input.min))*100;input.style.setProperty('--range-value',percent+'%');input.setAttribute('aria-valuetext',input.value);}
function resetMetricField(name){
  const input=q('[data-form]').elements.namedItem(name);if(!input)return;
  input.value=name==='metricSource'?'easyscholar':name==='secretKey'?'':bridge.metricsDefaults()[name]??'';
  if(name==='secretKey'||name==='semanticKey')input.dataset.preserveSecret='false';
  if(name==='automatic')input.checked=bridge.metricsDefaults().automatic;
  if(name==='impactField')selectImpactField();
  if(name==='citationFields'||name==='citationColors')renderCitationFieldChips();updateMetricRange(input);
}

let floatingDialog=null,floatingDialogDrag=null,suppressFloatingDialogClick=false;
// Compact confirmations share movement and bounds; settings and related items also resize.
function floatingDialogMinimum(){return floatingDialog?.column==='confirm'?{width:280,height:1}:floatingDialog?.column==='related'?{width:480,height:300}:{width:400,height:240};}
function floatingDialogBounds(){const shade=q('[data-shade]');return {width:shade.clientWidth,height:shade.clientHeight,gap:8};}
function fitFloatingDialog(rect){
  const area=floatingDialogBounds(),maxWidth=Math.max(1,area.width-area.gap*2),maxHeight=Math.max(1,area.height-area.gap*2);
  const bounded=(v,min,max)=>Math.max(min,Math.min(max,Number.isFinite(Number(v))?Number(v):min));
  const width=bounded(rect.width,Math.min(floatingDialogMinimum().width,maxWidth),maxWidth),height=bounded(rect.height,Math.min(floatingDialogMinimum().height,maxHeight),maxHeight);
  return {width,height,left:bounded(rect.left,area.gap,area.width-width-area.gap),top:bounded(rect.top,area.gap,area.height-height-area.gap)};
}
function applyFloatingDialogRect(rect){
  if(!floatingDialog)return;
  const form=q('[data-form]');let next=fitFloatingDialog(rect);
  if(floatingDialog.column==='confirm'){
    // Measure again after wrapping or a deletion error changes the compact dialog's height.
    form.style.width=next.width+'px';form.style.height='auto';
    next=fitFloatingDialog({...rect,width:next.width,height:form.offsetHeight});
  }
  floatingDialog.rect=next;
  for(const key of ['width','height','left','top'])form.style[key]=next[key]+'px';
  form.dataset.metricCompact=String(next.width<520);
}
function rememberFloatingDialog(){
  if(!floatingDialog)return;
  floatingDialog.preferred={...floatingDialog.rect};
  if(floatingDialog.column==='confirm')return;
  if(floatingDialog.column==='related')design.relationDialog={...floatingDialog.rect};
  else design.metricDialogs={...design.metricDialogs,[floatingDialog.column]:{...floatingDialog.rect}};
  saveView();
}
function defaultFloatingDialogRect(){
  const form=q('[data-form]'),area=floatingDialogBounds(),related=floatingDialog?.column==='related',compact=floatingDialog?.column==='confirm',width=Math.max(1,Math.min(compact?(floatingDialog.width||400):related?660:560,area.width-16));
  form.style.width=width+'px';form.style.height='auto';form.dataset.metricCompact=String(width<520);
  // Leave a pixel of rounding room so an otherwise fitting form does not gain a scrollbar.
  const natural=compact?form.offsetHeight:form.querySelector('header').offsetHeight+(related?320:form.querySelector('.kb-column-settings-body').scrollHeight)+form.querySelector('footer').offsetHeight+4;
  const height=Math.min(natural,area.height-16);
  return fitFloatingDialog({width,height,left:(area.width-width)/2,top:(area.height-height)/2});
}
function openFloatingDialogLayout(column,width){
  // Reset old, oversized saved geometry once; later manual resizing remains persistent.
  if(design.dialogSizingVersion!==2){delete design.relationDialog;delete design.metricDialogs;design.dialogSizingVersion=2;saveView();}
  floatingDialog={column,width};const saved=column==='confirm'?null:column==='related'?design.relationDialog:design.metricDialogs?.[column];
  // Keep the chosen size, but each opening starts centered rather than at a stale position.
  const rect=saved&&Number.isFinite(saved.width)&&Number.isFinite(saved.height)?fitFloatingDialog(saved):defaultFloatingDialogRect(),area=floatingDialogBounds();
  floatingDialog.preferred={...rect,left:(area.width-rect.width)/2,top:(area.height-rect.height)/2};
  applyFloatingDialogRect(floatingDialog.preferred);
}
function finishFloatingDialogDrag(cancel=false){
  const drag=floatingDialogDrag;if(!drag)return;floatingDialogDrag=null;suppressFloatingDialogClick=true;delete root.dataset.floatingDialogDrag;
  if(cancel)applyFloatingDialogRect(drag.start);else rememberFloatingDialog();
  if(drag.handle.hasPointerCapture?.(drag.pointer))drag.handle.releasePointerCapture(drag.pointer);
}
function moveFloatingDialog(event){
  const drag=floatingDialogDrag;if(!drag||event.pointerId!==drag.pointer)return;
  const start=drag.start,dx=event.clientX-drag.x,dy=event.clientY-drag.y,area=floatingDialogBounds();let next={...start};
  if(drag.edge==='move'){next.left+=dx;next.top+=dy;}
  else {
    const minWidth=Math.min(floatingDialogMinimum().width,Math.max(1,area.width-16)),minHeight=Math.min(floatingDialogMinimum().height,Math.max(1,area.height-16)),limit=(v,min,max)=>Math.max(min,Math.min(max,v));
    if(drag.edge.includes('e'))next.width=limit(start.width+dx,minWidth,area.width-start.left-8);
    if(drag.edge.includes('s'))next.height=limit(start.height+dy,minHeight,area.height-start.top-8);
    if(drag.edge.includes('w')){next.left=limit(start.left+dx,8,start.left+start.width-minWidth);next.width=start.left+start.width-next.left;}
    if(drag.edge.includes('n')){next.top=limit(start.top+dy,8,start.top+start.height-minHeight);next.height=start.top+start.height-next.top;}
  }
  applyFloatingDialogRect(next);
}
// A canceled drag can release over the shade after the original size is restored.
// Consume that gesture's click so it cannot dismiss the dialog or activate a field.
root.addEventListener('pointerdown',()=>{suppressFloatingDialogClick=false;},true);
root.addEventListener('click',event=>{if(!suppressFloatingDialogClick||!event.detail)return;suppressFloatingDialogClick=false;event.preventDefault();event.stopImmediatePropagation();},true);
root.addEventListener('pointerdown',event=>{
  if(!floatingDialog||purging||event.button!==0)return;
  const handle=event.target.closest('[data-dialog-resize],[data-dialog-move]');if(!handle||handle.hasAttribute('data-dialog-move')&&event.target.closest('button,input,select,textarea'))return;
  event.preventDefault();floatingDialogDrag={handle,pointer:event.pointerId,edge:handle.dataset.dialogResize||'move',x:event.clientX,y:event.clientY,start:{...floatingDialog.rect}};
  root.dataset.floatingDialogDrag=floatingDialogDrag.edge;handle.setPointerCapture(event.pointerId);
});
root.addEventListener('pointermove',moveFloatingDialog);
root.addEventListener('pointerup',event=>{if(floatingDialogDrag?.pointer!==event.pointerId)return;moveFloatingDialog(event);finishFloatingDialogDrag();});
root.addEventListener('pointercancel',()=>finishFloatingDialogDrag(true));
root.addEventListener('lostpointercapture',()=>finishFloatingDialogDrag(true));
root.addEventListener('dblclick',event=>{if(!event.target.closest('[data-dialog-resize]')||!floatingDialog)return;event.preventDefault();applyFloatingDialogRect(defaultFloatingDialogRect());rememberFloatingDialog();});
root.addEventListener('keydown',event=>{
  if(!floatingDialog||!event.target.matches('[data-dialog-resize]')||!['Home','ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key))return;
  event.preventDefault();event.stopImmediatePropagation();const rect={...floatingDialog.rect},step=event.shiftKey?30:10;
  if(event.key==='Home')applyFloatingDialogRect(defaultFloatingDialogRect());
  else{if(event.key==='ArrowLeft')rect.width-=step;if(event.key==='ArrowRight')rect.width+=step;if(event.key==='ArrowUp')rect.height-=step;if(event.key==='ArrowDown')rect.height+=step;applyFloatingDialogRect(rect);}
  rememberFloatingDialog();
});
// Selecting dialog text can leave focus on body, outside the library root.
window.addEventListener('keydown',event=>{if(floatingDialogDrag&&event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();finishFloatingDialogDrag(true);}},true);
window.addEventListener('blur',()=>finishFloatingDialogDrag(true));
window.addEventListener('resize',()=>{if(!floatingDialog||!floatingDialogBounds().width)return;finishFloatingDialogDrag(true);applyFloatingDialogRect(floatingDialog.preferred);});

function showCompactConfirmation(title,question,{width=400,focus='cancel'}={}){
  const form=q('[data-form]');form.classList.remove('is-relation');form.classList.add('is-compact-confirm');
  form.setAttribute('aria-describedby','kb-confirm-question');
  form.innerHTML=`<header data-dialog-move title="按住标题栏拖动"><h3 id="kb-modal-title">${escape(title)}</h3><button type="button" data-do="cancel" aria-label="关闭对话框">${icon('x')}</button></header><div class="kb-confirm-question"><span class="kb-confirm-symbol">${icon('circle-help')}</span><p id="kb-confirm-question">${escape(question)}</p></div><footer><button type="button" class="kb-primary" data-do="confirm">OK</button><button type="button" class="kb-outline" data-do="cancel">Cancel</button></footer>`;
  q('[data-shade]').hidden=false;updateIcons();openFloatingDialogLayout('confirm',width);
  form.querySelector('footer [data-do="'+focus+'"]').focus();
}

function floatingDialogHandles(){return `${['n','e','s','w','ne','nw','sw'].map(edge=>`<div data-dialog-resize="${edge}" aria-hidden="true"></div>`).join('')}<button type="button" data-dialog-resize="se" class="kb-dialog-size-grip" aria-label="调整窗口大小" title="拖动调整大小 · 双击恢复默认 · 方向键微调">${icon('grip')}</button>`;}
function showMetricColumnSettings(column){
  if(!['journal','cites'].includes(column))return;
  q('[data-menu]').hidden=true;commitSummaryEdit();previousFocus=document.activeElement;modal='metrics-column';
  const s=bridge.metricsSettings(),citation=column==='cites',key=name=>citation?'citation'+name[0].toUpperCase()+name.slice(1):name;
  const row=(name,label,control,reset=true)=>`<div class="kb-setting-row"><label for="kb-setting-${name}">${label}</label><div class="kb-setting-control">${control}</div>${reset?`<button type="button" class="kb-setting-reset" data-metric-reset="${name}" title="重置 ${label}" aria-label="重置 ${label}">${icon('undo-2')}</button>`:'<span aria-hidden="true"></span>'}</div>`;
  const field=(name,label)=>row(name,label,`<input id="kb-setting-${name}" name="${name}" value="${escape(s[name]??'')}" autocomplete="off">`);
  const slider=(name,label,min,max,step)=>row(key(name),label,`<input id="kb-setting-${key(name)}" type="range" name="${key(name)}" min="${min}" max="${max}" step="${step}" value="${s[key(name)]}">`);
  const access=citation?
    row('citationSource','Source','<div id="kb-setting-citationSource" class="kb-setting-source">Semantic Scholar</div>',false)+row('semanticKey','API Key',`<div class="kb-api-key-row">${metricSecretInput(s,'semanticKey')}<button type="button" data-metric-get-key="semantic">Get API Key</button></div>`):
    row('metricSource','Source','<select id="kb-setting-metricSource" name="metricSource"><option value="easyscholar">easyscholar</option></select>')+row('secretKey','API Key',`<div class="kb-api-key-row">${metricSecretInput(s)}<button type="button" data-metric-get-key>Get API Key</button></div>`);
  const impact=row('impactField','影响因子',`<select id="kb-setting-impactField" name="impactField">${Object.entries(bridge.impactFields()).map(([value,label])=>`<option value="${escape(value)}" ${value===s.impactField?'selected':''}>${escape(label)}</option>`).join('')}</select>`);
  const fields=citation?
    access+row('citationFields','Fields',`<input type="hidden" name="citationFields" value="${escape(s.citationFields)}"><div id="kb-setting-citationFields" class="kb-citation-fields" data-citation-field-chips role="group" aria-label="Fields"></div>`)+field('citationMap','Map')+field('citationColors','Colors'):
    access+impact+field('fields','Fields')+row('aliases','Journal Aliases',`<textarea id="kb-setting-aliases" name="aliases" rows="4">${escape(s.aliases)}</textarea>`)+field('map','Map')+field('rankColors','Rank Colors')+field('defaultColor','Default Color');
  const actions=citation?row('cnkiVerify','知网','<button id="kb-setting-cnkiVerify" type="button" class="kb-outline" data-cnki-verify>知网验证</button>',false)+row('automatic','自动更新',`<label class="kb-metrics-check"><input id="kb-setting-automatic" name="automatic" type="checkbox" ${s.automatic?'checked':''}>每次打开知识库更新论文的期刊标签和被引数</label>`):'';
  const form=q('[data-form]');form.classList.remove('is-relation');form.classList.add('is-metric-column');
  form.innerHTML=`<header data-dialog-move><h3 id="kb-modal-title">${citation?'CitedCount':'PublicationTags'}</h3><button type="button" data-do="cancel" aria-label="关闭对话框">${icon('x')}</button></header><div class="kb-column-settings-body">${fields}${field(key('textColor'),'Text Color')}${field(key('sortBy'),'Sort By')}${slider('opacity','Opacity',.1,1,.01)}${slider('margin','Margin',0,12,.1)}${slider('padding','Padding',0,16,.1)}${actions}</div><footer><button type="button" data-do="confirm">Set</button><button type="button" data-do="cancel">Cancel</button></footer>${floatingDialogHandles()}`;
  q('[data-shade]').hidden=false;updateIcons();if(citation)renderCitationFieldChips();form.querySelectorAll('input[type=range]').forEach(updateMetricRange);openFloatingDialogLayout(column);form.querySelector('h3').tabIndex=-1;form.querySelector('h3').focus({preventScroll:true});
}
function metricColumnButton(column){return ['journal','cites'].includes(column)?`<button type="button" data-metric-column="${column}">${icon('settings-2')}列设置（${column==='journal'?'期刊标签':'被引数'}）</button>`:'';}
let columnMenu=null;
function columnHeaderMenu(column,x,y){
  closeCollectionMenu();columnMenu={column,x,y};renderColumnMenu();
}
function renderColumnMenu(focusKey=null){
  if(!columnMenu)return;
  const menu=q('[data-menu]');menu.classList.add('is-columns');menu.setAttribute('aria-label','显示列');
  menu.innerHTML=`<div class="kb-column-scope">${escape(activeColumnRoot?activeColumnRoot.name+'及子分类':'我的文库与快捷视图')}</div><div role="menu" aria-label="显示列">${orderedColumns(true).map(([key,label])=>`<button type="button" role="menuitemcheckbox" aria-checked="${!columnLayout().hiddenColumns.includes(key)}" data-toggle-column="${key}" ${key==='title'?'disabled title="标题列始终显示"':''}><span class="kb-column-check" aria-hidden="true">${columnLayout().hiddenColumns.includes(key)?'':icon('check')}</span><span>${escape(label)}</span></button>`).join('')}</div>${metricColumnButton(columnMenu.column)?'<div class="kb-menu-divider"></div>'+metricColumnButton(columnMenu.column):''}`;
  menu.hidden=false;updateIcons();positionCollectionMenu(columnMenu.x,columnMenu.y);
  (focusKey?menu.querySelector('[data-toggle-column="'+focusKey+'"]'):menu.querySelector('button:not(:disabled)'))?.focus({preventScroll:true});
}
function toggleColumnVisibility(key){
  if(key==='title'||!columnDefs.some(c=>c[0]===key))return;
  columnLayout().hiddenColumns=columnLayout().hiddenColumns.includes(key)?columnLayout().hiddenColumns.filter(c=>c!==key):[...columnLayout().hiddenColumns,key];
  columnLayout().columnViewport=null;applyColumnOrder();applyColumnWidths();saveColumnLayout();renderColumnMenu(key);
}

const paneIDs=['info','summary','files','notes','collections','tags','related'];
const clamp=(value,min,max)=>Math.max(min,Math.min(max,Number(value)||min));
let resizeSession=null,resizeFrame=0,detailFrame=0,relationDraft=null;
function normalizePreferences(){
  normalizeCollections();cleanColumns();
  state.tags=[...new Set(Array.isArray(state.tags)?state.tags:state.tag?[state.tag]:[])].filter(t=>typeof t==='string'&&t);delete state.tag;
  state.showAutomaticTags=state.showAutomaticTags!==false;state.showAllTags=state.showAllTags===true;
  if(state.view?.startsWith('type:'))state.view='all';
  if(Object.hasOwn(statuses,state.view)){state.statusFilter=state.view;state.view='all';}
  if(!Object.hasOwn(statuses,state.statusFilter))state.statusFilter='';
  state.ratingFilter=Number.isInteger(Number(state.ratingFilter))&&Number(state.ratingFilter)>=1&&Number(state.ratingFilter)<=5?Number(state.ratingFilter):0;
  if(!Object.hasOwn(sortFields,state.sort))state.sort='recent';
  if(!['asc','desc'].includes(state.sortDirection))state.sortDirection=sortFields[state.sort].direction;
  design.navWidth=clamp(design.navWidth,150,380);
  design.detailWidth=clamp(design.detailWidth,240,500);
  design.tagHeight=clamp(design.tagHeight,80,330);
  if(!paneIDs.includes(state.activeSection))state.activeSection='info';
  state.paneOrder=[...new Set([...(Array.isArray(state.paneOrder)?state.paneOrder:[]),...paneIDs])].filter(id=>paneIDs.includes(id));
  if(!paneIDs.includes(state.pinnedPane))state.pinnedPane=null;
  state.detailCollapsed=!!state.detailCollapsed;
  const defaults={};
  for(const item of items)item.related=[...new Set(Array.isArray(item.related)?item.related:defaults[item.id]||[])].filter(id=>id!==item.id&&byID(id));
  for(const item of items)for(const id of item.related){const peer=byID(id);if(!peer.related.includes(item.id))peer.related.push(item.id);}
}
function layoutBounds(){
  const width=root.clientWidth,layout=width>=930?'desktop':width>=540?'stacked':'compact';
  const rail=matchMedia('(pointer:coarse)').matches?44:35;
  const navMax=layout==='desktop'?Math.min(380,width-12-320-(state.detailCollapsed?rail:240)):Math.min(320,width-306);
  const nav=clamp(design.navWidth,150,Math.max(150,navMax));
  const detailMax=Math.max(240,Math.min(500,width-nav-12-320));
  const detail=state.detailCollapsed?rail:clamp(design.detailWidth,240,detailMax);
  return {layout,rail,nav,detail,navMax:Math.max(150,navMax),detailMax,tagMax:layout==='compact'?170:330};
}
function applyLayout(){
  const b=layoutBounds();root.dataset.layout=b.layout;
  q(".kb-workspace-tabs").hidden=!bridge.workspace||b.layout==="desktop";
  root.dataset.detailCollapsed=String(state.detailCollapsed);
  root.style.setProperty('--kb-nav-width',b.nav+'px');
  root.style.setProperty('--kb-detail',b.detail+'px');
  root.style.setProperty('--kb-rail-width',b.rail+'px');
  root.style.setProperty('--kb-tag-height',clamp(design.tagHeight,80,b.tagMax)+'px');
  q('[data-detail]').dataset.collapsed=String(state.detailCollapsed);applyColumnWidths();
  bridge.layoutNotePane(q('[data-note-editor-surface]'));
  const sizes={nav:[150,b.navMax,b.nav],detail:[240,b.detailMax,clamp(design.detailWidth,240,b.detailMax)],tags:[80,b.tagMax,clamp(design.tagHeight,80,b.tagMax)]};
  for(const [key,[min,max,value]]of Object.entries(sizes)){
    const handle=q('[data-resize="'+key+'"]');if(!handle)continue;
    handle.setAttribute('aria-valuemin',min);handle.setAttribute('aria-valuemax',Math.floor(max));
    handle.setAttribute('aria-valuenow',Math.round(value));handle.setAttribute('aria-valuetext',Math.round(value)+' 像素');
  }
}
function setPaneSize(key,value){
  const b=layoutBounds();
  if(key==='nav')design.navWidth=clamp(value,150,b.navMax);
  if(key==='detail')design.detailWidth=clamp(value,240,b.detailMax);
  if(key==='tags')design.tagHeight=clamp(value,80,b.tagMax);
  applyLayout();
}
function resizeValue(key){const b=layoutBounds();return key==='nav'?b.nav:key==='detail'?clamp(design.detailWidth,240,b.detailMax):clamp(design.tagHeight,80,b.tagMax);}
function finishResize(cancelled=false){
  if(!resizeSession)return;const session=resizeSession;resizeSession=null;
  cancelAnimationFrame(resizeFrame);resizeFrame=0;
  if(cancelled)Object.assign(design,session.original);
  delete session.handle.dataset.dragging;delete root.dataset.resizing;
  if(session.handle.hasPointerCapture?.(session.pointer))session.handle.releasePointerCapture(session.pointer);
  applyLayout();if(!cancelled)persist();
}
root.addEventListener('pointerdown',event=>{
  const handle=event.target.closest('[data-resize]');if(!handle||event.button!==0)return;
  event.preventDefault();handle.focus({preventScroll:true});
  const key=handle.dataset.resize;
  if(key==='detail'&&state.detailCollapsed)openInformationPane();
  resizeSession={handle,key,pointer:event.pointerId,x:event.clientX,y:event.clientY,start:resizeValue(key),original:{navWidth:design.navWidth,detailWidth:design.detailWidth,tagHeight:design.tagHeight}};
  handle.setPointerCapture(event.pointerId);handle.dataset.dragging='true';root.dataset.resizing=key;
});
root.addEventListener('pointermove',event=>{
  const s=resizeSession;if(!s||s.pointer!==event.pointerId)return;
  const value=s.start+(s.key==='nav'?event.clientX-s.x:s.key==='detail'?s.x-event.clientX:s.y-event.clientY);
  cancelAnimationFrame(resizeFrame);resizeFrame=requestAnimationFrame(()=>{resizeFrame=0;if(resizeSession===s)setPaneSize(s.key,value);});
});
root.addEventListener('pointerup',event=>{
  const s=resizeSession;if(!s||s.pointer!==event.pointerId)return;
  setPaneSize(s.key,s.start+(s.key==='nav'?event.clientX-s.x:s.key==='detail'?s.x-event.clientX:s.y-event.clientY));finishResize();
});
root.addEventListener('pointercancel',()=>finishResize(true));
root.addEventListener('lostpointercapture',()=>{if(resizeSession)finishResize(true);});
root.addEventListener('dblclick',event=>{
  const handle=event.target.closest('[data-resize]');if(!handle)return;
  event.preventDefault();const key=handle.dataset.resize;setPaneSize(key,{nav:200,detail:300,tags:155}[key]);persist();
});
root.addEventListener('keydown',event=>{
  const handle=event.target.closest('[data-resize]');if(!handle)return;
  const key=handle.dataset.resize,step=event.shiftKey?30:10;
  const direction=key==='tags'?{ArrowUp:1,ArrowDown:-1}:key==='nav'?{ArrowRight:1,ArrowLeft:-1}:{ArrowLeft:1,ArrowRight:-1};
  if(!(event.key in direction)&&!['Home','End'].includes(event.key))return;
  event.preventDefault();
  if(key==='detail'&&state.detailCollapsed)openInformationPane();
  setPaneSize(key,event.key==='Home'?Number(handle.getAttribute('aria-valuemin')):event.key==='End'?Number(handle.getAttribute('aria-valuemax')):resizeValue(key)+direction[event.key]*step);persist();
});
let observedWidth=0;
new ResizeObserver(()=>{if(resizeSession)return;const width=root.clientWidth,active=state.activeSection,changed=observedWidth&&observedWidth!==width;observedWidth=width;applyLayout();if(changed&&!state.reader&&!state.detailCollapsed)loadVisibleNotes();}).observe(root);
function paneToggleMarkup(){return `<button type="button" class="kb-pane-toggle cursor-interaction" data-do="toggle-detail" aria-label="${state.detailCollapsed?'展开':'收起'}条目详情" aria-expanded="${!state.detailCollapsed}" data-tooltip="${state.detailCollapsed?'展开':'收起'}条目详情">${icon(state.detailCollapsed?'panel-right-open':'panel-right-close')}</button>`;}
function updateRail(){qa('[data-jump-section]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.jumpSection===state.activeSection)));}
function openInformationPane(expand=true){
  if(!leaveNotePane())return;
  if(expand)state.detailCollapsed=false;
  (state.sections||={}).info=true;state.activeSection='info';
  // Opening the pane must override the last item's saved scroll position.
  renderDetail({section:'info',offset:0});updateIcons();
}
function scrollToSection(id,behavior='instant',focus=false){
  const scroller=q('[data-pane-scroll]'),block=q('[data-section-block="'+id+'"]'),tail=q('[data-pane-tail]');
  if(!scroller||!block||state.detailCollapsed)return;
  tail.style.height='0px';
  const top=block.offsetTop;
  // scrollHeight is at least clientHeight even when content is short; use its actual end.
  tail.style.height=Math.max(0,scroller.clientHeight+top-tail.offsetTop)+'px';
  state.activeSection=id;updateRail();
  scroller.scrollTo({top,behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'instant':behavior});
  if(focus)q('[data-section="'+id+'"]')?.focus({preventScroll:true});
}
function captureDetailPosition(){
  const scroller=q('[data-pane-scroll]');if(!scroller||!detailItemID)return null;
  const blocks=[...scroller.querySelectorAll('[data-section-block]')];
  const block=blocks.filter(el=>el.offsetTop<=scroller.scrollTop+8).at(-1)||blocks[0];
  const position={top:scroller.scrollTop,section:block?.dataset.sectionBlock,offset:block?scroller.scrollTop-block.offsetTop:0};
  detailPositions.set(detailItemID,position);return position;
}
function bindPaneScroll(position=null){
  cancelAnimationFrame(detailFrame);
  const scroller=q('[data-pane-scroll]');if(!scroller)return;
  detailFrame=requestAnimationFrame(()=>{
    if(!scroller.isConnected)return;
    applyLayout();
    if(typeof position==='number')scroller.scrollTop=position;
    else if(position){scrollToSection(position.section);scroller.scrollTop=(q('[data-section-block="'+position.section+'"]')?.offsetTop||0)+position.offset;}
    else scrollToSection(state.pinnedPane||state.activeSection);
    loadVisibleNotes();
  });
  scroller.addEventListener('scroll',()=>{
    const position=captureDetailPosition();if(position?.section)state.activeSection=position.section;
    updateRail();loadVisibleNotes();
  },{passive:true});
  noteObserver?.disconnect();
  noteObserver=new IntersectionObserver(()=>loadVisibleNotes(),{root:scroller});
  const notes=q('[data-section-body="notes"]');if(notes)noteObserver.observe(notes);
}
const searchFields=['website','title','titleZh','author','year','date','summary','tags','keywords','publicationTitle','conference','volume','issue','pages','articleNumber','doi','url','articleType','affiliations','codeUrls','dataUrls','resourceUrls','publisher','edition','isbn','journalTag','citationCount','rating','contributor','editor','translator','seriesEditor','thesisType','university','numPages','place','series','seriesNumber','numberOfVolumes','originalDate','originalPublisher','originalPlace','format','language','libraryCatalog','extra','shortTitle','archive','archiveLocation','callNumber','rights','issn','journalAbbreviation','pmid','pmcid'];
// Older automatically named drafts remain intact on disk; explicit user titles stay visible.
const itemTitle=item=>item.title==='未命名条目'&&!item.xrefMetadata?.locked?.includes('title')?'':String(item.title||'');
const creatorCache=new WeakMap();
function creatorView(item){
  const raw=String(item.author||'').trim(),cached=creatorCache.get(item);if(cached?.raw===raw)return cached;
  // Authors from indexes are separated by semicolons. Preserve commas in "Family, Given".
  const names=raw.split(/[;；\n、]+/).map(s=>s.trim()).filter(Boolean).flatMap(name=>{
    const parts=name.split(/[,，]/).map(s=>s.trim()).filter(Boolean);
    const listed=parts.length>1&&parts.every(s=>/^\p{Script=Han}{2,8}$/u.test(s));
    return listed?parts:[name];
  });
  const family=name=>{
    // One-field Chinese names and institutional authors should not be reduced to their last word.
    if(/\p{Script=Han}|\p{Script=Hiragana}|\p{Script=Katakana}|\p{Script=Hangul}/u.test(name)||/\b(?:university|institute|organization|organisation|association|consortium|collaboration|committee|society|academy|council|group|team|department|foundation|bureau|agency|inc|ltd)\b/i.test(name))return name;
    if(/[,，]/.test(name))return name.split(/[,，]/)[0].trim();
    const words=name.split(/\s+/);if(words.length>1&&/^(?:Jr\.?|Sr\.?|II|III|IV)$/i.test(words.at(-1)))words.pop();
    let first=words.length-1;while(first>0&&/^(?:al|bin|da|de|del|della|den|der|di|dos|du|el|la|le|van|von|ter|ten)$/i.test(words[first-1]))first--;
    return words.slice(first).join(' ');
  };
  const shortened=names.map(name=>{const match=name.match(/^(.*?)\s+(?:et\s+al\.?|等)$/i);return {name,family:family(match?match[1]:name),more:!!match};});
  const first=shortened[0],text=!first?'':shortened.length>2||shortened.some(n=>n.more)?first.family+' 等':shortened.length===2?first.family+'和'+shortened[1].family:first.family;
  const value={raw,text,names:shortened,sort:first?.family||''};creatorCache.set(item,value);return value;
}
function searchTerms(query){return (query.normalize('NFKC').toLocaleLowerCase().match(/"[^"]+"|[^\s]+/g)||[]).map(term=>term.replace(/^"|"$/g,''));}
function matchesSearch(item,terms){
  if(!terms.length)return true;
  const metric=metricValues(item);
  const raw=[creatorView(item).text,metric.badges.map(b=>b.text).join(' '),metric.citationBadges.map(b=>b.text).join(' '),metric.impact??'',metric.count??'',typeNames[item.type],statuses[item.status],item.added?new Date(item.added).toLocaleDateString('zh-CN'):'',...searchFields.map(key=>Array.isArray(item[key])?item[key].join(' '):String(item[key]??''))].join('\n');
  let cached=searchCache.get(item);if(cached?.raw!==raw){cached={raw,text:raw.normalize('NFKC').toLocaleLowerCase()};searchCache.set(item,cached);}
  return terms.every(term=>cached.text.includes(term)||(item.webpage&&bridge.webHasTerm(item.id,term)));
}
function renderRelationResults(){
  if(!relationDraft)return;const key=relationDraft.query.trim().toLocaleLowerCase();
  const terms=searchTerms(key),candidates=activeItems().filter(i=>i.id!==relationDraft.owner&&(relationDraft.view==='all'||itemInCollection(i,relationDraft.view))&&matchesSearch(i,terms));
  q('[data-relation-results]').innerHTML=candidates.map(i=>`<label class="kb-relation-item cursor-interaction"><input type="checkbox" data-related="${escape(i.id)}" ${relationDraft.ids.has(i.id)?'checked':''}><span>${escape(itemTitle(i))}</span><span class="kb-relation-author kb-muted">${escape(i.author||'—')}</span></label>`).join('')||'<div class="kb-empty">没有匹配的条目</div>';
  q('[data-relation-count]').textContent=`已选 ${relationDraft.ids.size} 项`;
  qa('[data-relation-view]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.relationView===relationDraft.view)));
}
function renderRelationTree(){
  const choice=(id,label,symbol)=>`<button type="button" class="cursor-interaction" data-relation-view="${escape(id)}" title="${escape(id==='all'?label:collectionPath(id))}" aria-pressed="${id===relationDraft.view}">${icon(symbol)}<span>${escape(label)}</span></button>`;
  const walk=(parent=null,depth=0)=>childrenOf(parent).map(c=>{
    const hasChildren=childrenOf(c.id).length>0,closed=relationDraft.closed.has(c.id);
    return `<div class="kb-relation-folder" style="--kb-depth:${depth}" data-relation-folder="${escape(c.id)}">${hasChildren?`<button type="button" data-relation-toggle="${escape(c.id)}" aria-expanded="${!closed}" aria-label="展开或收起 ${escape(c.name)}">${icon(closed?'chevron-right':'chevron-down')}</button>`:'<span class="kb-tree-spacer" aria-hidden="true"></span>'}${choice(c.id,c.name,'folder')}</div>${hasChildren&&!closed?walk(c.id,depth+1):''}`;
  }).join('');
  q('.kb-relation-tree').innerHTML=choice('all','我的文库','library-big')+walk();updateIcons();
}
function relatedPickerMarkup(item){
  relationDraft={owner:item.id,ids:new Set(item.relatedOut||[]),view:'all',query:'',closed:new Set()};
  return `<div class="kb-relation-picker"><nav class="kb-relation-tree" aria-label="筛选相关条目分类"></nav><div class="kb-relation-main"><label class="kb-relation-search">${icon('search')}<input type="search" data-relation-search aria-label="搜索相关条目" placeholder="所有字段和标签"></label><div class="kb-relation-columns"><span>标题</span><span>创建者</span></div><div class="kb-relation-results" data-relation-results></div></div></div>`;
}
function commitRelations(){
  const owner=byID(relationDraft?.owner);if(!owner)return;
  const ids=[...relationDraft.ids].filter(id=>id!==owner.id&&byID(id)&&!byID(id).deleted);
  const old=new Set(owner.relatedOut||[]);
  for(const peer of items){
    if(ids.includes(peer.id)){if(!owner.related.includes(peer.id))owner.related.push(peer.id);if(!peer.related.includes(owner.id))peer.related.push(owner.id);}
    else if(old.has(peer.id)&&!peer.relatedOut?.includes(owner.id)){owner.related=owner.related.filter(id=>id!==peer.id);peer.related=peer.related.filter(id=>id!==owner.id);}
  }
  owner.relatedOut=ids;state.sections.related=true;state.activeSection='related';
}
function removeRelation(id){const owner=selected(),peer=byID(id);if(!owner||!peer)return;owner.related=(owner.related||[]).filter(x=>x!==id);peer.related=(peer.related||[]).filter(x=>x!==owner.id);if(owner.relatedOut)owner.relatedOut=owner.relatedOut.filter(x=>x!==id);if(peer.relatedOut)peer.relatedOut=peer.relatedOut.filter(x=>x!==owner.id);renderDetail();updateIcons();persist();}

// Hierarchical collections keep memberships on stable item IDs.
let collectionMenu=null,collectionDialog=null,columnDrag=null,columnFrame=0;
const collectionByID=id=>collections.find(c=>c.id===id);
const childrenOf=parent=>bridge.orderCollections(collections).filter(c=>(c.parentId||null)===(parent||null));
const nextCollectionOrder=parent=>Math.max(-1,...childrenOf(parent).map(c=>Number.isFinite(c.sortOrder)?c.sortOrder:collections.indexOf(c)))+1;
function collectionBranch(id){const result=[],seen=new Set();function walk(key){if(seen.has(key))return;seen.add(key);const c=collectionByID(key);if(!c)return;result.push(c);for(const child of childrenOf(key))walk(child.id);}walk(id);return result;}
// Aggregate views follow ancestor links; actual item memberships stay explicit.
function itemInCollection(item,id){
  if(item.collections.includes(id))return true;
  const seen=new Set();
  for(const member of item.collections){let c=collectionByID(member);while(c&&!seen.has(c.id)){if(c.id===id)return true;seen.add(c.id);c=collectionByID(c.parentId);}}
  return false;
}
function collectionPath(id){const names=[],seen=new Set();let c=collectionByID(id);while(c&&!seen.has(c.id)){seen.add(c.id);names.unshift(c.name);c=collectionByID(c.parentId);}return names.join(' / ');}
function orderedCollections(parent=null,depth=0){return childrenOf(parent).flatMap(c=>[{...c,depth},...orderedCollections(c.id,depth+1)]);}
function normalizeCollections(){
  const oldGroups=new Map();
  for(const c of [...collections])if(!Object.hasOwn(c,'parentId')){
    const group=c.group||'';
    if(group){if(!oldGroups.has(group)){let id=group==='研究'?'root-research':group==='阅读'?'root-reading':newID();while(collectionByID(id))id=newID();collections.push({id,name:group,parentId:null});oldGroups.set(group,id);}c.parentId=oldGroups.get(group);}else c.parentId=null;
    delete c.group;
  }
  for(const c of collections){if(c.parentId&&!collectionByID(c.parentId))c.parentId=null;let parent=collectionByID(c.parentId);const seen=new Set([c.id]);while(parent){if(seen.has(parent.id)){c.parentId=null;break;}seen.add(parent.id);parent=collectionByID(parent.parentId);}}
  state.closedGroups=(state.closedGroups||[]).map(k=>oldGroups.has(k.slice(6))?'collection:'+oldGroups.get(k.slice(6)):k);
  if(state.view?.startsWith('collection:')&&!collectionByID(state.view.slice(11)))state.view='all';
}
function revealCollection(id){const open=new Set(['library']);for(const c of collections)if(collectionBranch(c.id).some(x=>x.id===id))open.add('collection:'+c.id);state.closedGroups=state.closedGroups.filter(k=>!open.has(k));}
function collectionTreeMarkup(parent=null,depth=0){
  return childrenOf(parent).map(c=>{const children=childrenOf(c.id),key='collection:'+c.id,closed=state.closedGroups.includes(key);return `<div class="kb-collection-row" data-collection-row="${escape(c.id)}" style="--kb-depth:${depth}">${children.length?`<button type="button" class="kb-collection-toggle cursor-interaction" data-tree="${escape(key)}" aria-expanded="${!closed}" aria-label="展开或收起 ${escape(c.name)}">${icon(closed?'chevron-right':'chevron-down')}</button>`:'<span class="kb-tree-spacer" aria-hidden="true"></span>'}${navButton('collection:'+c.id,c.name,'folder')}</div>${children.length?`<div ${closed?'hidden':''}>${collectionTreeMarkup(c.id,depth+1)}</div>`:''}`;}).join('');
}
function parentOptions(selectedID=null){return `<option value="" ${!selectedID?'selected':''}>我的文库</option>`+orderedCollections().map(c=>`<option value="${escape(c.id)}" ${selectedID===c.id?'selected':''}>${escape(collectionPath(c.id))}</option>`).join('');}
// Folder tree movement uses pointer capture, independently of external file imports.
let collectionTreeDrag=null,collectionTreeFrame=0,suppressTreeClickUntil=0;
function collectionDropPlan(id,targetId,placement){
  const source=collectionByID(id),target=targetId?collectionByID(targetId):null;
  if(!source||targetId&&!target)return {valid:false,label:'目标分类已变化'};
  const parentId=placement==='inside'?(targetId||null):(target?.parentId||null);
  if(id===targetId||collectionBranch(id).some(c=>c.id===parentId))return {valid:false,label:'不能放入自身或自己的子分类'};
  if(childrenOf(parentId).some(c=>c.id!==id&&c.name===source.name))return {valid:false,label:'该位置已有同名分类'};
  return {valid:true,parentId,targetId,placement};
}
function positionCollectionDrop(s){
  qa('[data-collection-drop]').forEach(el=>delete el.dataset.collectionDrop);
  const hit=document.elementFromPoint(s.x,s.y),button=hit?.closest('[data-nav] [data-view]'),row=button?.closest('[data-collection-row]');
  s.plan=null;s.marker.hidden=true;
  if(button&&(row||button.dataset.view==='all')){
    const rect=button.getBoundingClientRect(),edge=Math.min(8,rect.height*.25),placement=!row?'inside':s.y<rect.top+edge?'before':s.y>rect.bottom-edge?'after':'inside';
    s.plan=collectionDropPlan(s.id,row?.dataset.collectionRow||null,placement);
    if(s.plan.valid){
      if(placement==='inside')button.dataset.collectionDrop='inside';
      else{
        let bottom=rect.bottom;
        if(placement==='after')for(const c of collectionBranch(s.plan.targetId)){const child=q('[data-collection-row="'+c.id+'"]');if(child?.getClientRects().length)bottom=Math.max(bottom,child.getBoundingClientRect().bottom);}
        const viewport=q('.kb-nav-main').getBoundingClientRect();
        Object.assign(s.marker.style,{left:rect.left+'px',top:Math.max(viewport.top,Math.min(viewport.bottom,placement==='before'?rect.top:bottom))-1+'px',width:rect.width+'px'});s.marker.hidden=false;
      }
    }else button.dataset.collectionDrop='invalid';
  }
  const hover=s.plan?.valid&&s.plan.placement==='inside'?s.plan.targetId||'library':null;
  if(hover!==s.hover){s.hover=hover;s.hoverAt=performance.now();}
  if(hover&&performance.now()-s.hoverAt>650){
    const key=hover==='library'?'library':'collection:'+hover;
    if(state.closedGroups.includes(key)){const scroll=q('.kb-nav-main').scrollTop;state.closedGroups=state.closedGroups.filter(k=>k!==key);renderNav();updateIcons();q('.kb-nav-main').scrollTop=scroll;}
  }
}
function animateCollectionTree(){
  const s=collectionTreeDrag;if(!s?.active)return;
  const scroller=q('.kb-nav-main'),r=scroller.getBoundingClientRect();
  if(s.x>=r.left&&s.x<=r.right&&s.y>=r.top&&s.y<=r.bottom){const speed=s.y<r.top+28?-Math.min(10,(r.top+28-s.y)/2):s.y>r.bottom-28?Math.min(10,(s.y-r.bottom+28)/2):0;if(speed)scroller.scrollTop+=speed;}
  positionCollectionDrop(s);collectionTreeFrame=requestAnimationFrame(animateCollectionTree);
}
function endCollectionTree(cancelled=false){
  const s=collectionTreeDrag;if(!s)return;collectionTreeDrag=null;cancelAnimationFrame(collectionTreeFrame);collectionTreeFrame=0;
  if(root.hasPointerCapture(s.pointer))root.releasePointerCapture(s.pointer);
  if(!s.active)return;
  suppressTreeClickUntil=performance.now()+400;s.marker.remove();delete root.dataset.collectionDragging;
  qa('[data-collection-drop]').forEach(el=>delete el.dataset.collectionDrop);
  if(cancelled||!s.plan?.valid)return;
  if(s.generation!==libraryGeneration||s.signature!==JSON.stringify(collections)){notify('分类已变化，请重新拖动。');return;}
  const plan=collectionDropPlan(s.id,s.plan.targetId,s.plan.placement);if(!plan.valid){notify(plan.label);return;}
  const source=collectionByID(s.id),siblings=childrenOf(plan.parentId).filter(c=>c.id!==s.id);
  const slot=plan.placement==='inside'?siblings.length:siblings.findIndex(c=>c.id===plan.targetId)+(plan.placement==='after'?1:0);
  if(slot<0)return;siblings.splice(slot,0,source);
  if((source.parentId||null)===plan.parentId&&siblings.every((c,index)=>childrenOf(plan.parentId)[index]?.id===c.id))return;
  source.parentId=plan.parentId;siblings.forEach((c,index)=>{c.sortOrder=index;});
  revealCollection(s.id);const scroll=q('.kb-nav-main').scrollTop;render();q('.kb-nav-main').scrollTop=scroll;
  const moved=q('[data-collection-row="'+s.id+'"] [data-view]');moved?.focus({preventScroll:true});moved?.scrollIntoView({block:'nearest'});
  persist();run(()=>flush());
}
root.addEventListener('pointerdown',event=>{
  const button=event.target.closest('[data-collection-row] > [data-view]');
  if(!button||event.button!==0||modal||loading||importToken||purging||merging)return;
  collectionTreeDrag={id:button.closest('[data-collection-row]').dataset.collectionRow,pointer:event.pointerId,startX:event.clientX,startY:event.clientY,x:event.clientX,y:event.clientY,active:false,generation:libraryGeneration,signature:JSON.stringify(collections)};
});
root.addEventListener('pointermove',event=>{
  const s=collectionTreeDrag;if(!s||s.pointer!==event.pointerId)return;s.x=event.clientX;s.y=event.clientY;
  if(!s.active&&Math.hypot(s.x-s.startX,s.y-s.startY)>=5){
    s.active=true;root.setPointerCapture(s.pointer);root.dataset.collectionDragging=s.id;closeCollectionMenu();
    s.marker=document.createElement('div');s.marker.className='kb-tree-drop-marker';s.marker.setAttribute('aria-hidden','true');root.append(s.marker);animateCollectionTree();
  }
  if(s.active){event.preventDefault();positionCollectionDrop(s);}
});
root.addEventListener('pointerup',event=>{const s=collectionTreeDrag;if(!s||s.pointer!==event.pointerId)return;if(s.active){s.x=event.clientX;s.y=event.clientY;positionCollectionDrop(s);}endCollectionTree();});
root.addEventListener('pointercancel',()=>endCollectionTree(true));
root.addEventListener('lostpointercapture',event=>{if(collectionTreeDrag?.pointer===event.pointerId)endCollectionTree(true);});
window.addEventListener('blur',()=>endCollectionTree(true));window.addEventListener('resize',()=>endCollectionTree(true));
root.addEventListener('keydown',event=>{if(event.key==='Escape'&&collectionTreeDrag){event.preventDefault();event.stopImmediatePropagation();endCollectionTree(true);}},true);
root.addEventListener('click',event=>{if(event.detail&&performance.now()<suppressTreeClickUntil){event.preventDefault();event.stopImmediatePropagation();suppressTreeClickUntil=0;}},true);
root.addEventListener('dragstart',event=>{if(event.target.closest('[data-collection-row]'))event.preventDefault();});
// Show explicit memberships and their ancestors without turning ancestors into memberships.
let membershipMenu=null,membershipRemoval=null;
function membershipTreeMarkup(item){
  const direct=new Set(item.collections),included=new Set();
  for(const id of direct){let c=collectionByID(id);const seen=new Set();while(c&&!seen.has(c.id)){seen.add(c.id);included.add(c.id);c=collectionByID(c.parentId);}}
  const row=(id,name,depth,context=false)=>{
    const view=id?'collection:'+id:'all',current=state.view===view,path=id?collectionPath(id):'我的文库';
    return `<li class="kb-membership-row ${context?'is-context':''}" style="--membership-depth:${depth}" data-membership-row="${escape(id||'library')}"><button type="button" class="kb-membership-link ${current?'is-current':''}" data-membership-view="${escape(view)}" title="${escape(path)}" ${current?'disabled aria-current="location"':''}>${icon(id?'folder':'landmark')}<span>${escape(name)}</span></button>${id&&!context&&!item.deleted?`<button type="button" class="kb-membership-remove" data-membership-remove="${escape(id)}" aria-label="从 ${escape(path)} 中移除条目" title="从此分类移除">${icon('minus')}</button>`:''}</li>`;
  };
  const walk=(parent,depth)=>childrenOf(parent).filter(c=>included.has(c.id)).map(c=>row(c.id,c.name,depth,!direct.has(c.id))+walk(c.id,depth+1)).join('');
  return `<ul class="kb-membership-tree" aria-label="所属文库和分类">${row(null,'我的文库',0)}${walk(null,1)}</ul>`;
}
function membershipHeading(open,item){
  return `<button type="button" class="kb-section-title cursor-interaction" data-section="collections" aria-expanded="${!!open}" aria-controls="kb-section-collections">${icon('folders')}<span>文库和分类</span></button><button type="button" class="kb-section-action cursor-interaction" data-do="add-membership" aria-label="添加到分类" aria-haspopup="menu" ${item.deleted?'disabled':''}>${icon('plus')}</button><button type="button" class="kb-section-action cursor-interaction" data-section="collections" aria-label="${open?'收起':'展开'}文库和分类" aria-expanded="${!!open}" aria-controls="kb-section-collections">${icon(open?'chevron-up':'chevron-down')}</button>`;
}
function navigateMembership(view){
  const item=selected(),id=view.startsWith('collection:')?view.slice(11):null;
  if(!item||view!=='all'&&(!id||!itemInCollection(item,id)||!collectionByID(id)))return;
  state.view=view;clearItemFilters();state.query='';state.checked=[];
  if(id)revealCollection(id);else state.closedGroups=state.closedGroups.filter(k=>k!=='library');
  if(!item.deleted){state.selected=item.id;state.checked=[item.id];selectionAnchor=item.id;}
  pickVisible();render();persist();
  const target=qa('[data-nav] [data-view]').find(b=>b.dataset.view===view);target?.scrollIntoView({block:'nearest'});target?.focus({preventScroll:true});
}
function showMembershipMenu(button){
  const item=selected();if(!item||item.deleted)return;
  closeCollectionMenu();attachmentMenu=null;membershipMenu={owner:item.id};state.sections.collections=true;renderDetail();updateIcons();persist();
  const menu=q('[data-menu]');menu.classList.remove('is-collection','is-menu-stack');menu.setAttribute('aria-label','添加到分类');
  menu.innerHTML=`<div class="kb-membership-picker" role="menu" aria-label="添加到分类"><div class="kb-membership-picker-root">${icon('landmark')}<span>我的文库</span></div><div class="kb-membership-choices">${orderedCollections().map(c=>`<button type="button" role="menuitem" data-membership-add="${escape(c.id)}" style="--membership-depth:${c.depth+1}" title="${escape(collectionPath(c.id))}" ${item.collections.includes(c.id)?'disabled':''}>${icon('folder')}<span>${escape(c.name)}</span>${item.collections.includes(c.id)?icon('check'):''}</button>`).join('')||'<p class="kb-muted">请先在左侧新建分类</p>'}</div></div>`;
  menu.hidden=false;updateIcons();const anchor=q('[data-do="add-membership"]')||button,r=anchor.getBoundingClientRect();positionCollectionMenu(r.left,r.bottom);
  (menu.querySelector('button:not(:disabled)')||anchor).focus({preventScroll:true});
}
function addMembership(id){
  const item=byID(membershipMenu?.owner);if(!item||item.deleted||!collectionByID(id))return;
  if(!item.collections.includes(id))item.collections.push(id);
  q('[data-menu]').hidden=true;membershipMenu=null;render();persist();notify('已添加到分类：'+collectionPath(id));q('[data-do="add-membership"]')?.focus({preventScroll:true});
}
function showRemoveMembership(id,button){
  const item=selected(),c=collectionByID(id);if(!item||item.deleted||!c||!item.collections.includes(id))return;
  previousFocus=button;membershipRemoval={owner:item.id,collection:id};modal='remove-membership';
  showCompactConfirmation('从分类中移除','您确定从“'+collectionPath(id)+'”中移除所选条目吗？',{width:460});
}
root.addEventListener('keydown',event=>{
  if(!event.target.closest('.kb-membership-picker'))return;
  if(event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();q('[data-menu]').hidden=true;membershipMenu=null;q('[data-do="add-membership"]')?.focus();return;}
  if(['ArrowDown','ArrowUp','Home','End'].includes(event.key)){
    event.preventDefault();event.stopImmediatePropagation();const buttons=qa('[data-membership-add]:not(:disabled)'),at=buttons.indexOf(document.activeElement);
    const next=event.key==='Home'?0:event.key==='End'?buttons.length-1:(at+(event.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length;buttons[next]?.focus();
  }
});
function closeCollectionMenu(restoreFocus=false){const noteFocus=noteMenuFocus;noteMenu=null;noteMenuFocus=null;if(restoreFocus&&noteFocus?.isConnected)noteFocus.focus({preventScroll:true});libraryMenu=false;q('[data-do="library-menu"]')?.setAttribute('aria-expanded','false');const menu=q('[data-menu]');menu.hidden=true;if(restoreFocus&&collectionMenu){const id=collectionMenu.id;qa('[data-nav] [data-view]').find(b=>b.dataset.view===(id?'collection:'+id:'all'))?.focus({preventScroll:true});}collectionMenu=null;columnMenu=null;tagOptionsMenu=null;q('[data-do="tag-options"]')?.setAttribute('aria-expanded','false');menu.classList.remove('is-collection','has-destination','is-menu-stack','is-columns','is-tags','is-attachment-picker');}
// Small anchored attachment menus must not float over content that has scrolled away.
root.addEventListener('wheel',()=>{const menu=q('[data-menu]');if(!menu.hidden&&attachmentMenu?.picker){closeCollectionMenu();attachmentMenu=null;}},{capture:true,passive:true});
function positionCollectionMenu(x,y){const menu=q('[data-menu]'),r=root.getBoundingClientRect();menu.style.left=Math.max(4,Math.min(x-r.left,r.width-menu.offsetWidth-4))+'px';menu.style.top=Math.max(4,Math.min(y-r.top,r.height-menu.offsetHeight-4))+'px';}
function openCollectionMenu(id,x,y){
  const c=collectionByID(id);if(id&&!c)return;
  closeCollectionMenu();state.view=id?'collection:'+id:'all';clearItemFilters();state.checked=[];pickVisible();render();
  collectionMenu={id,action:null};const menu=q('[data-menu]');menu.classList.add('is-collection');menu.setAttribute('aria-label','分类操作');
  const action=(key,label,symbol,child=false)=>`<button type="button" class="cursor-interaction" data-collection-action="${key}" ${child?'aria-haspopup="true" aria-expanded="false"':''}>${icon(symbol)}<span>${label}</span>${child?icon('chevron-right'):''}</button>`;
  menu.innerHTML=`<div data-collection-actions>${action('child',id?'新建子分类…':'新建分类…','folder-plus')}${id?'<div class="kb-menu-divider"></div>'+action('rename','重命名分类','pencil')+action('move','移动到','folder-input',true)+action('copy','复制到','copy',true)+action('delete','删除分类…','folder-minus')+action('delete-items','删除分类及条目…','trash-2'):'<div class="kb-menu-divider"></div>'+action('choose-root','选择知识库文件夹…','folder-open')+action('reveal-root','打开知识库文件夹','folder')}</div><div class="kb-destination-menu" data-destination-menu hidden></div>`;
  menu.hidden=false;updateIcons();positionCollectionMenu(x,y);menu.querySelector('button').focus({preventScroll:true});persist();
}
function validCollectionTarget(id,target,action){const c=collectionByID(id);if(!c||target&&!collectionByID(target)||collectionBranch(id).some(x=>x.id===target))return false;if(action==='move'&&((c.parentId||null)===(target||null)||childrenOf(target).some(x=>x.name===c.name&&x.id!==id)))return false;return true;}
function showCollectionTargets(action,focus=false){
  if(!collectionMenu?.id)return;collectionMenu.action=action;
  const menu=q('[data-menu]'),submenu=q('[data-destination-menu]'),targets=[{id:'',name:'我的文库',depth:0},...orderedCollections().map(c=>({...c,depth:c.depth+1}))];
  submenu.innerHTML=`<button type="button" class="kb-destination-back cursor-interaction" data-collection-back>${icon('arrow-left')}${action==='move'?'移动到':'复制到'}</button><div class="kb-destination-list">${targets.map(c=>`<button type="button" class="cursor-interaction" data-collection-target="${escape(c.id)}" style="--kb-depth:${c.depth}" ${validCollectionTarget(collectionMenu.id,c.id||null,action)?'':'disabled'} aria-label="${action==='move'?'移动到':'复制到'} ${escape(c.id?collectionPath(c.id):'我的文库')}">${icon(c.id?'folder':'library-big')}<span>${escape(c.name)}</span></button>`).join('')}</div>`;
  submenu.hidden=false;menu.classList.add('has-destination');const stack=root.clientWidth<460;menu.classList.toggle('is-menu-stack',stack);
  qa('[data-collection-action][aria-expanded]').forEach(b=>b.setAttribute('aria-expanded',String(b.dataset.collectionAction===action)));
  if(!stack){const left=parseFloat(menu.style.left),rightRoom=root.clientWidth-left-menu.offsetWidth;submenu.style.left=rightRoom>=212?'100%':'auto';submenu.style.right=rightRoom>=212?'auto':'100%';submenu.style.top='0px';const remaining=root.clientHeight-parseFloat(menu.style.top);submenu.style.maxHeight=Math.max(150,remaining-6)+'px';}
  updateIcons();if(focus)submenu.querySelector('[data-collection-target]:not(:disabled)')?.focus({preventScroll:true});
}
function hideCollectionTargets(){if(!collectionMenu)return;const action=collectionMenu.action;collectionMenu.action=null;q('[data-destination-menu]').hidden=true;q('[data-menu]').classList.remove('has-destination','is-menu-stack');qa('[data-collection-action][aria-expanded]').forEach(b=>b.setAttribute('aria-expanded','false'));q('[data-collection-action="'+action+'"]')?.focus({preventScroll:true});}
function uniqueCollectionName(name,parent){let result=name,n=1;while(childrenOf(parent).some(c=>c.name===result)){result=name+'（副本'+(n===1?'':n)+'）';n++;}return result;}
function transferCollection(target){
  const {id,action}=collectionMenu||{};target=target||null;if(!validCollectionTarget(id,target,action))return;
  const source=collectionByID(id);let selectedID=id;
  if(action==='move'){source.sortOrder=nextCollectionOrder(target);source.parentId=target;}
  else{
    const branch=collectionBranch(id);
    const mapping=new Map(branch.map(c=>[c.id,newID()]));
    const copies=branch.map(c=>({id:mapping.get(c.id),name:c.id===id?uniqueCollectionName(c.name,target):c.name,parentId:c.id===id?target:mapping.get(c.parentId)}));
    collections.push(...copies);for(const item of items){item.collections=[...new Set([...item.collections,...item.collections.filter(cid=>mapping.has(cid)).map(cid=>mapping.get(cid))])];}
    selectedID=mapping.get(id);
  }
  closeCollectionMenu();state.view='collection:'+selectedID;revealCollection(selectedID);pickVisible();render();persist();notify(action==='move'?'分类已移动，条目关联保持不变':'已复制分类结构，使用同一份条目');
}
function showCollectionDialog(action,id=null){
  const c=collectionByID(id);if(id&&!c)return;
  const sourceButton=qa('[data-nav] [data-view]').find(b=>b.dataset.view===(id?'collection:'+id:'all'));
  closeCollectionMenu();previousFocus=sourceButton||document.activeElement;collectionDialog={action,id};modal='collection-'+action;
  let title,body,confirm='保存';
  if(action==='child'||action==='new'){
    title=action==='child'&&id?'新建子分类':'新建分类';confirm='创建';
    body=`<label>分类名称<input name="name" required maxlength="60" placeholder="分类名称"></label><label>放在<select name="parent">${parentOptions(id)}</select></label>`;
  }else if(action==='rename'){
    title='重命名分类';body=`<label>分类名称<input name="name" required maxlength="60" value="${escape(c.name)}"></label>`;
  }else{
    const count=collectionBranch(id).length;
    title=action==='delete-items'?'删除分类和条目':'删除分类';confirm=title;
    body=`<p class="kb-collection-confirm">您确定要删除 ${count} 个分类${action==='delete-items'?'并删除其中所有条目':''}吗？</p><p class="kb-collection-confirm">${action==='delete-items'?'条目将移入回收站，可在回收站中恢复。':'这些分类中的条目不会被删除。'}</p>`;
  }
  const form=q('[data-form]');form.classList.remove('is-relation');form.innerHTML=`<header><h3 id="kb-modal-title">${title}</h3><button type="button" class="cursor-interaction" data-do="cancel" aria-label="关闭对话框">${icon('x')}</button></header>${body}<footer><button type="button" class="kb-outline cursor-interaction" data-do="cancel">取消</button><button type="button" class="kb-primary cursor-interaction" data-do="confirm">${confirm}</button></footer>`;
  q('[data-shade]').hidden=false;updateIcons();const input=form.querySelector('input');if(input){input.focus();if(action==='rename')input.select();}else form.querySelector('footer [data-do="cancel"]').focus();
}
function submitCollectionDialog(){
  const form=q('[data-form]'),data=new FormData(form),{action,id}=collectionDialog,c=collectionByID(id);
  if(!['child','new'].includes(action)&&!c){closeModal();return;}
  if(['child','new','rename'].includes(action)){
    const name=String(data.get('name')||'').trim(),parent=action==='rename'?c.parentId:String(data.get('parent')||'')||null;
    if(!name||childrenOf(parent).some(x=>x.name===name&&x.id!==((action==='rename')?id:null))){form.elements.name.setCustomValidity(name?'此位置已有同名分类':'请输入分类名称');form.elements.name.reportValidity();return;}
    if(parent&&!collectionByID(parent))return;
    if(action==='rename')c.name=name;
    else{const created={id:newID(),name,parentId:parent};collections.push(created);state.view='collection:'+created.id;clearItemFilters();state.query='';revealCollection(created.id);}
  }else{
    const removed=new Set(collectionBranch(id).map(x=>x.id));
    for(const item of items){const included=item.collections.some(cid=>removed.has(cid));if(included&&action==='delete-items')item.deleted=true;item.collections=item.collections.filter(cid=>!removed.has(cid));}
    collections=collections.filter(x=>!removed.has(x.id));state.closedGroups=state.closedGroups.filter(k=>!removed.has(k.slice(11)));
    if(removed.has(state.view.slice(11)))state.view=c.parentId?'collection:'+c.parentId:'all';
  }
  closeModal();collectionDialog=null;pickVisible();render();persist();notify(action==='delete-items'?'分类已删除，条目已移入回收站':action==='delete'?'分类已删除，条目已保留':action==='rename'?'分类名称已更新':'分类已创建');
}
root.addEventListener('pointerover',event=>{if(!collectionMenu)return;const b=event.target.closest('[data-collection-action]');if(b&&['move','copy'].includes(b.dataset.collectionAction)&&collectionMenu.action!==b.dataset.collectionAction)showCollectionTargets(b.dataset.collectionAction);});
root.addEventListener('pointerdown',event=>{if(!event.target.closest('[data-menu],[data-do="tag-options"]')&&!q('[data-menu]').hidden)closeCollectionMenu();});
root.addEventListener('contextmenu',event=>{
  const c=event.target.closest('[data-collection-row]'),library=event.target.closest('[data-nav] [data-view="all"]');
  if(c||library){event.preventDefault();openCollectionMenu(c?.dataset.collectionRow||null,event.clientX,event.clientY);}
});
root.addEventListener('keydown',event=>{
  const c=event.target.closest('[data-collection-row]'),library=event.target.closest('[data-nav] [data-view="all"]');
  if((event.key==='ContextMenu'||event.shiftKey&&event.key==='F10')&&(c||library)){event.preventDefault();const r=(c||library).getBoundingClientRect();openCollectionMenu(c?.dataset.collectionRow||null,r.left+28,r.bottom);event.stopImmediatePropagation();return;}
  if(!collectionMenu||q('[data-menu]').hidden)return;
  if(event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();if(collectionMenu.action)hideCollectionTargets();else closeCollectionMenu(true);return;}
  if(event.key==='ArrowRight'&&event.target.matches('[data-collection-action="move"],[data-collection-action="copy"]')){event.preventDefault();showCollectionTargets(event.target.dataset.collectionAction,true);return;}
  if(event.key==='ArrowLeft'&&event.target.closest('[data-destination-menu]')){event.preventDefault();hideCollectionTargets();return;}
  if(['ArrowDown','ArrowUp','Home','End'].includes(event.key)){event.preventDefault();const container=event.target.closest('[data-destination-menu]')||q('[data-collection-actions]'),buttons=[...container.querySelectorAll('button:not(:disabled)')].filter(e=>e.getClientRects().length),at=buttons.indexOf(document.activeElement),next=event.key==='Home'?0:event.key==='End'?buttons.length-1:(at+(event.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length;buttons[next]?.focus();}
},true);

// Pane width changes are shared equally, stopping each column at its readable minimum.
const columnDefs=[['title','标题',140,64],['author','创建者',76,40],['status','状态',88,60],['date','添加日期',92,48],['rating','评级',118,112],['journal','期刊标签',180,60],['impact','影响因子',88,56],['cites','被引数',108,60]];
function dateColumnLabel(){return state.view==='recent'?'最近阅读日期':'添加日期';}
function timestamp(value){if(value===null||value===undefined||value==='')return null;const n=typeof value==='number'?value:Date.parse(String(value).replaceAll('/','-'));return Number.isFinite(n)&&Number.isFinite(new Date(n).getTime())?n:null;}
function tableDateValue(item){return state.view==='recent'?(Number(item.last)>0?timestamp(Number(item.last)):null):timestamp(item.added);}
function fullDate(value){const n=timestamp(value);return n===null?'—':new Date(n).toLocaleString('zh-CN',{hour12:false});}
function tableDate(item){const n=tableDateValue(item);return n===null?'—':state.view==='recent'?new Date(n).toLocaleString('zh-CN',{year:'numeric',month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit',hour12:false}):new Date(n).toLocaleDateString('zh-CN');}
function columnDefaults(){return Object.fromEntries(orderedColumns().map(([key,_,width])=>[key,width]));}
let activeColumnLayout=null,activeColumnRoot=null;
const columnLayout=()=>activeColumnLayout||design;
function columnSnapshot(layout){return clone({columns:layout.columns,columnOrder:layout.columnOrder,hiddenColumns:layout.hiddenColumns,columnSizing:layout.columnSizing,columnViewport:layout.columnViewport});}
function columnRoot(){
  let c=state.view?.startsWith('collection:')?collectionByID(state.view.slice(11)):null;
  const seen=new Set();while(c?.parentId&&!seen.has(c.id)){seen.add(c.id);const parent=collectionByID(c.parentId);if(!parent)break;c=parent;}return c;
}
function cleanColumns(){
  cleanColumnLayout(design);
  const object=v=>v&&typeof v==='object'&&!Array.isArray(v);
  design.collectionColumnDefaults=object(design.collectionColumnDefaults)?columnSnapshot(design.collectionColumnDefaults):columnSnapshot(design);
  cleanColumnLayout(design.collectionColumnDefaults);
  const saved=object(design.collectionColumns)?design.collectionColumns:{};
  design.collectionColumns=Object.create(null);
  for(const [id,value]of Object.entries(saved))if(collectionByID(id)&&object(value)){const profile=columnSnapshot(value);cleanColumnLayout(profile);design.collectionColumns[id]=profile;}
  selectColumnLayout();
}
function selectColumnLayout(){
  activeColumnRoot=columnRoot();
  if(!activeColumnRoot){activeColumnLayout=design;return;}
  const saved=design.collectionColumns[activeColumnRoot.id];
  if(saved){activeColumnLayout=saved;return;}
  // Untouched folders follow a stable copy of the pre-migration layout. Manual choices win.
  activeColumnLayout=columnSnapshot(design.collectionColumnDefaults);
  const branchItems=items.filter(i=>!i.deleted&&itemInCollection(i,activeColumnRoot.id));
  const books=branchItems.length?branchItems.every(i=>i.type==='book'):/^(书籍|图书|书库|books?)$/i.test(activeColumnRoot.name.trim());
  if(books)activeColumnLayout.hiddenColumns=[...new Set([...activeColumnLayout.hiddenColumns,'journal','impact'])];
}
function saveColumnLayout(){
  if(activeColumnRoot)design.collectionColumns[activeColumnRoot.id]=columnSnapshot(columnLayout());
  saveView();
}
function cleanColumnLayout(layout){
  const input=layout.columns||{};layout.columns={};for(const [key,_,__,min]of columnDefs){if(Number.isFinite(input[key]))layout.columns[key]=Math.max(min,Math.min(10000,input[key]));}
  layout.columnSizing=layout.columnSizing==='fixed'?'fixed':'fill';
  layout.columnViewport=Number.isFinite(layout.columnViewport)&&layout.columnViewport>0?layout.columnViewport:null;
  const keys=columnDefs.map(c=>c[0]);
  layout.hiddenColumns=[...new Set(Array.isArray(layout.hiddenColumns)?layout.hiddenColumns:[])].filter(key=>key!=='title'&&keys.includes(key));
  const saved=Array.isArray(layout.columnOrder)?layout.columnOrder:[];
  layout.columnOrder=[...new Set([...saved,...keys])].filter(key=>keys.includes(key));
  if(saved.length&&!saved.includes('status')){layout.columnOrder=layout.columnOrder.filter(key=>key!=='status');layout.columnOrder.splice(layout.columnOrder.indexOf('author')+1,0,'status');}
}
function orderedColumns(includeHidden=false){return (columnLayout().columnOrder||columnDefs.map(c=>c[0])).filter(key=>(includeHidden||!columnLayout().hiddenColumns?.includes(key))&&(!webOnlyList||!['status','journal','impact','cites'].includes(key))).map(key=>{const c=columnDefs.find(c=>c[0]===key);return key==='date'?[key,dateColumnLabel(),state.view==='recent'?150:c[2],c[3]]:c;});}
function applyColumnOrder(){
  const columns=orderedColumns(true),header=q('.kb-table thead tr'),group=q('.kb-table colgroup');
  const arrange=container=>{for(let n=0;n<columns.length;n++){const cell=container.querySelector('[data-column="'+columns[n][0]+'"]');if(cell&&container.children[n]!==cell)container.insertBefore(cell,container.children[n]||null);}};
  arrange(header);arrange(group);for(const row of qa('[data-row]'))arrange(row);
  for(const cell of qa('.kb-table [data-column]'))cell.hidden=columnLayout().hiddenColumns.includes(cell.dataset.column)||(webOnlyList&&['status','journal','impact','cites'].includes(cell.dataset.column));
  const count=orderedColumns().length;q('.kb-table').setAttribute('aria-colcount',count);
  for(const cell of qa('.kb-file-inline'))cell.colSpan=count;
  initializeColumnHandles();
}
function distributeColumnWidths(columns,input,target){
  const widths=Object.fromEntries(columns.map(([key,,,min])=>[key,Math.max(min,input[key])])),sum=()=>Object.values(widths).reduce((a,b)=>a+b,0);
  let delta=Math.max(target,columns.reduce((total,c)=>total+c[3],0))-sum();
  if(delta>0){for(const [key]of columns)widths[key]+=delta/columns.length;return widths;}
  let flexible=columns.filter(([key,,,min])=>widths[key]>min);
  while(delta<-.000001&&flexible.length){
    const share=delta/flexible.length;let applied=0;
    for(const [key,,,min]of flexible){const next=Math.max(min,widths[key]+share);applied+=next-widths[key];widths[key]=next;}
    delta-=applied;flexible=flexible.filter(([key,,,min])=>widths[key]>min+.000001);
  }
  return widths;
}
function actualColumnWidths(){
  const columns=orderedColumns(),layout=columnLayout(),defaults=columnDefaults(),widths=Object.fromEntries(columns.map(([key])=>[key,layout.columns[key]??defaults[key]])),available=q('[data-table-scroll]')?.clientWidth||0;
  if(!available)return widths;
  const total=Object.values(widths).reduce((sum,n)=>sum+n,0);
  // Older profiles have no viewport anchor: fit them once without discarding saved proportions.
  // An explicitly widened final column keeps its overflow, while resizing the pane still affects all columns.
  const overflow=layout.columnViewport?Math.max(0,total-layout.columnViewport):0;
  return distributeColumnWidths(columns,widths,available+overflow);
}
function minimumFinalWidth(key,widths){return Math.max(columnDefs.find(c=>c[0]===key)[3],(q('[data-table-scroll]')?.clientWidth||0)-Object.entries(widths).reduce((sum,[name,width])=>sum+(name===key?0:width),0));}
function applyColumnWidths(){
  if(!q('.kb-main')?.clientWidth)return;const widths=actualColumnWidths();
  // Expanded attachments fit the visible list even when its columns scroll horizontally.
  q('.kb-table').style.setProperty('--kb-list-width',q('[data-table-scroll]').clientWidth+'px');
  const columns=orderedColumns();
  for(let n=0;n<columns.length;n++){const [key,label,_,min]=columns[n];q('.kb-col-'+key).style.width=widths[key]+'px';const handle=q('[data-col-resize="'+key+'"]'),next=columns[n+1];if(handle){handle.setAttribute('aria-valuenow',Math.round(widths[key]));handle.setAttribute('aria-valuetext',Math.round(widths[key])+' 像素');handle.setAttribute('aria-valuemin',next?min:Math.ceil(minimumFinalWidth(key,widths)));handle.setAttribute('aria-valuemax',next?Math.round(widths[key]+widths[next[0]]-next[3]):10000);}}
  q('.kb-table').style.width=Object.values(widths).reduce((sum,n)=>sum+n,0)+'px';
  q('.kb-table').style.setProperty('--kb-title-offset',columns.slice(0,columns.findIndex(c=>c[0]==='title')).reduce((sum,c)=>sum+widths[c[0]],0)+'px');
}
function initializeColumnHandles(){
  const columns=orderedColumns();
  for(let n=0;n<columns.length;n++){
    const [key,label,_,min]=columns[n],next=columns[n+1],th=q('[data-sort-by="'+key+'"]').parentElement;
    let handle=th.querySelector('[data-col-resize]');
    if(!handle){handle=document.createElement('button');handle.type='button';handle.className='kb-column-splitter';handle.dataset.colResize=key;handle.setAttribute('role','separator');handle.setAttribute('aria-orientation','vertical');th.append(handle);}
    handle.setAttribute('data-tooltip',(next?'拖动调整相邻两列':'拖动调整最后一列')+' · 双击按内容收紧列宽');
    handle.setAttribute('aria-label','调整'+label+(next?'与'+next[1]:'')+'列宽');handle.setAttribute('aria-valuemin',min);
  }
}
function setColumnWidth(key,width,fit=false){
  const columns=orderedColumns(),index=columns.findIndex(c=>c[0]===key),left=columns[index],right=columns[index+1];if(!left)return;
  const widths=columnDrag?{...columnDrag.widths}:actualColumnWidths();
  if(right&&!fit){const total=widths[key]+widths[right[0]];widths[key]=Math.max(left[3],Math.min(total-right[3],Math.round(width)));widths[right[0]]=total-widths[key];}
  else{widths[key]=Math.max(right?left[3]:minimumFinalWidth(key,widths),Math.min(10000,Math.round(width)));columnLayout().columnSizing='fixed';}
  columnLayout().columns={...columnLayout().columns,...widths};columnLayout().columnViewport=q('[data-table-scroll]').clientWidth;
  applyColumnWidths();
}
function fitColumnWidth(key){
  const definition=columnDefs.find(c=>c[0]===key),header=q('.kb-table thead th[data-column="'+key+'"]');if(!definition||!header)return;
  // Measure the actual styled controls/badges, unconstrained by the saved column width.
  const probe=document.createElement('table');probe.className='kb-table kb-column-measure';probe.setAttribute('aria-hidden','true');
  const copy=cell=>{const clone=cell.cloneNode(true),style=getComputedStyle(cell);clone.style.paddingLeft=style.paddingLeft;clone.style.paddingRight=style.paddingRight;clone.querySelectorAll('[data-col-resize]').forEach(e=>e.remove());return clone;};
  const head=document.createElement('thead'),headRow=document.createElement('tr');headRow.append(copy(header));head.append(headRow);probe.append(head);
  const body=document.createElement('tbody');for(const cell of qa('[data-row] td[data-column="'+key+'"]')){const row=document.createElement('tr');row.append(copy(cell));body.append(row);}probe.append(body);root.append(probe);
  try{const cap={title:640,author:240,status:160,date:220,rating:240,journal:640,impact:180,cites:640}[key];setColumnWidth(key,Math.max(definition[3],Math.min(cap,Math.ceil(probe.getBoundingClientRect().width)+8)),true);}
  finally{probe.remove();}
}
function endColumnDrag(cancelled=false){if(!columnDrag)return;const s=columnDrag;columnDrag=null;cancelAnimationFrame(columnFrame);columnFrame=0;if(cancelled){columnLayout().columns=s.original;columnLayout().columnSizing=s.sizing;columnLayout().columnViewport=s.viewport;}delete root.dataset.resizing;delete s.handle.dataset.dragging;if(s.handle.hasPointerCapture(s.pointer))s.handle.releasePointerCapture(s.pointer);applyColumnWidths();if(!cancelled)saveColumnLayout();}
root.addEventListener('pointerdown',event=>{const handle=event.target.closest('[data-col-resize]');if(!handle||event.button!==0)return;event.preventDefault();handle.focus({preventScroll:true});const widths=actualColumnWidths();columnDrag={handle,key:handle.dataset.colResize,pointer:event.pointerId,x:event.clientX,start:widths[handle.dataset.colResize],widths:{...widths},original:{...columnLayout().columns},sizing:columnLayout().columnSizing,viewport:columnLayout().columnViewport};columnLayout().columnViewport=q('[data-table-scroll]').clientWidth;columnLayout().columns={...columnLayout().columns,...widths};handle.setPointerCapture(event.pointerId);handle.dataset.dragging='true';root.dataset.resizing='columns';});
root.addEventListener('pointermove',event=>{const s=columnDrag;if(!s||s.pointer!==event.pointerId)return;cancelAnimationFrame(columnFrame);columnFrame=requestAnimationFrame(()=>{columnFrame=0;if(columnDrag===s)setColumnWidth(s.key,s.start+event.clientX-s.x);});});
root.addEventListener('pointerup',event=>{const s=columnDrag;if(!s||s.pointer!==event.pointerId)return;setColumnWidth(s.key,s.start+event.clientX-s.x);endColumnDrag();});
root.addEventListener('pointercancel',()=>endColumnDrag(true));
root.addEventListener('lostpointercapture',()=>{if(columnDrag)endColumnDrag(true);});
root.addEventListener('dblclick',event=>{const handle=event.target.closest('[data-col-resize]');if(!handle)return;event.preventDefault();fitColumnWidth(handle.dataset.colResize);saveColumnLayout();});
root.addEventListener('keydown',event=>{const handle=event.target.closest('[data-col-resize]');if(!handle)return;if(event.key==='Escape'&&columnDrag){event.preventDefault();event.stopImmediatePropagation();endColumnDrag(true);return;}if(!['ArrowLeft','ArrowRight','Home'].includes(event.key))return;event.preventDefault();const key=handle.dataset.colResize;columnLayout().columns={...columnLayout().columns,...actualColumnWidths()};columnLayout().columnViewport=q('[data-table-scroll]').clientWidth;setColumnWidth(key,event.key==='Home'?columnDefs.find(c=>c[0]===key)[3]:columnLayout().columns[key]+(event.key==='ArrowRight'?1:-1)*(event.shiftKey?30:10));saveColumnLayout();});

// Header movement is separate from sorting and boundary resizing. Commit only on a valid drop.
let columnOrderDrag=null,columnOrderFrame=0,suppressHeaderClickUntil=0;
function positionColumnDrop(session){
  const scroller=q('[data-table-scroll]'),viewport=scroller.getBoundingClientRect(),head=q('.kb-table thead').getBoundingClientRect();
  session.valid=session.y>=head.top-24&&session.y<=head.bottom+24&&session.x>=viewport.left-12&&session.x<=viewport.right+12;
  const others=qa('.kb-table thead th').filter(th=>!th.hidden&&th.dataset.column!==session.key),rects=others.map(th=>th.getBoundingClientRect());
  const slot=rects.findIndex(r=>session.x<r.left+r.width/2);session.slot=slot<0?others.length:slot;
  const edge=session.slot<rects.length?rects[session.slot].left:rects.at(-1)?.right||head.right;
  session.marker.hidden=!session.valid;session.marker.style.left=clamp(edge,viewport.left,viewport.right)-1+'px';
  session.marker.style.top=head.top+'px';session.marker.style.height=head.height+'px';
  session.ghost.style.left=clamp(session.x+12,0,Math.max(0,innerWidth-session.ghost.offsetWidth))+'px';
  session.ghost.style.top=clamp(session.y+12,0,Math.max(0,innerHeight-session.ghost.offsetHeight))+'px';
}
function animateColumnOrder(){
  const s=columnOrderDrag;if(!s?.active)return;
  const scroller=q('[data-table-scroll]'),r=scroller.getBoundingClientRect(),head=q('.kb-table thead').getBoundingClientRect();
  if(s.y>=head.top-24&&s.y<=head.bottom+24&&s.x>=r.left-12&&s.x<=r.right+12){
    const delta=s.x<r.left+32?-Math.min(16,(r.left+32-s.x)/2):s.x>r.right-32?Math.min(16,(s.x-r.right+32)/2):0;
    if(delta)scroller.scrollLeft+=delta;
  }
  positionColumnDrop(s);columnOrderFrame=requestAnimationFrame(animateColumnOrder);
}
function endColumnOrder(cancelled=false){
  const s=columnOrderDrag;if(!s)return;
  columnOrderDrag=null;cancelAnimationFrame(columnOrderFrame);columnOrderFrame=0;
  if(s.active){
    suppressHeaderClickUntil=performance.now()+400;
    s.ghost.remove();s.marker.remove();delete s.button.parentElement.dataset.columnMoving;delete root.dataset.reordering;
    if(!cancelled&&s.valid){
      const visible=orderedColumns().map(c=>c[0]).filter(key=>key!==s.key);visible.splice(s.slot,0,s.key);
      let at=0;const order=columnLayout().columnOrder.map(key=>columnLayout().hiddenColumns.includes(key)?key:visible[at++]);
      if(order.join()!==columnLayout().columnOrder.join()){
        columnLayout().columnOrder=order;applyColumnOrder();applyColumnWidths();saveColumnLayout();
        notify('已调整列顺序：'+orderedColumns().map(c=>c[1]).join('、'));
      }
    }
  }
  if(s.button.hasPointerCapture(s.pointer))s.button.releasePointerCapture(s.pointer);
}
root.addEventListener('pointerdown',event=>{
  const button=event.target.closest('[data-sort-by]');if(!button||event.button!==0||columnDrag||resizeSession)return;
  suppressHeaderClickUntil=0;button.focus({preventScroll:true});
  columnOrderDrag={button,key:button.dataset.sortBy,pointer:event.pointerId,startX:event.clientX,x:event.clientX,y:event.clientY,active:false};
  button.setPointerCapture(event.pointerId);
});
root.addEventListener('pointermove',event=>{
  const s=columnOrderDrag;if(!s||s.pointer!==event.pointerId)return;s.x=event.clientX;s.y=event.clientY;
  if(!s.active&&Math.abs(s.x-s.startX)>=5){
    s.active=true;s.button.parentElement.dataset.columnMoving='true';root.dataset.reordering='columns';
    s.ghost=document.createElement('div');s.ghost.className='kb-column-ghost';s.ghost.textContent=orderedColumns().find(c=>c[0]===s.key)[1];s.ghost.setAttribute('aria-hidden','true');
    s.marker=document.createElement('div');s.marker.className='kb-column-drop-marker';s.marker.setAttribute('aria-hidden','true');root.append(s.ghost,s.marker);animateColumnOrder();
  }
  if(s.active){event.preventDefault();positionColumnDrop(s);}
});
root.addEventListener('pointerup',event=>{const s=columnOrderDrag;if(!s||s.pointer!==event.pointerId)return;if(s.active){s.x=event.clientX;s.y=event.clientY;positionColumnDrop(s);}endColumnOrder();});
root.addEventListener('pointercancel',()=>endColumnOrder(true));
root.addEventListener('lostpointercapture',event=>{if(columnOrderDrag?.pointer===event.pointerId)endColumnOrder(true);});
window.addEventListener('blur',()=>endColumnOrder(true));
root.addEventListener('keydown',event=>{if(event.key==='Escape'&&columnOrderDrag){event.preventDefault();event.stopImmediatePropagation();endColumnOrder(true);}},true);
root.addEventListener('click',event=>{if(event.detail&&event.target.closest('[data-sort-by]')&&performance.now()<suppressHeaderClickUntil){event.preventDefault();event.stopImmediatePropagation();suppressHeaderClickUntil=0;}},true);
root.addEventListener('dragstart',event=>{if(event.target.closest('[data-sort-by]'))event.preventDefault();});

// Colors and custom schemes come from the existing Typora theme manager.
const rgb=hex=>[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16));
const mix=(a,b,t)=>'#'+rgb(a).map((v,i)=>Math.round(v+(rgb(b)[i]-v)*t).toString(16).padStart(2,'0')).join('');
const luminance=hex=>rgb(hex).map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;}).reduce((s,v,i)=>s+v*[.2126,.7152,.0722][i],0);
const textFor=bg=>luminance(bg)>.19?'#292a31':'#eeedf2';
const contrast=(a,b)=>(Math.max(luminance(a),luminance(b))+.05)/(Math.min(luminance(a),luminance(b))+.05);
function themeTokens(c){const [bg,side,card,bold]=c,text=textFor(bg),accent=contrast(bold,bg)>=4.5?bold:mix(bold,text,.5);return{bg,panel:bg,side,chrome:card,text,muted:mix(text,bg,.35),line:mix(text,bg,.82),accent,soft:mix(bold,card,.80),hover:mix(bold,card,.91),action:accent,'action-text':textFor(accent),selection:c[5]};}
function hexColor(value,fallback){if(!value||value==='transparent'||/rgba\([^)]*,\s*0\s*\)/.test(value))return fallback;const m=String(value).match(/rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)/);return m?'#'+m.slice(1,4).map(n=>Number(n).toString(16).padStart(2,'0')).join(''):fallback;}
function applyPalette(){
  const theme=bridge.theme(),dark=theme.dark,bg=hexColor(theme.native?.bg,dark?'#252427':'#ffffff');
  const c=theme.colors||[bg,bg,bg,dark?'#bcb0ca':'#71637e',dark?'#bcb0ca':'#71637e',dark?'#554e60':'#dedbe3'];
  const t=theme.tokens;const resolved=t?{bg:t.bg,panel:t.bg,side:t.side,chrome:t.card,text:t.text,muted:t.muted,line:t.border,accent:t.accent,soft:t.active,hover:t.hover,action:t.accent,'action-text':textFor(t.accent),selection:t.selection}:themeTokens(c);
  for(const [key,value]of Object.entries(resolved))root.style.setProperty('--kb-'+key,value);
  root.style.colorScheme=dark?'dark':'light';root.dataset.palette=theme.id;
  q('[data-palette]').innerHTML=theme.catalog.map(p=>`<option value="${escape(p.id)}">${escape(p.name)}</option>`).join('');q('[data-palette]').value=theme.id;
  bridge.layoutNotePane(q('[data-note-editor-surface]'));
}

let tagOptionsMenu=null,tagRemoval=null,tagDeleting=false;
const selectedTagCount=()=>state.tags.length+(state.statusFilter?1:0)+(state.ratingFilter?1:0);
function showTagOptions(button){
  closeCollectionMenu();const rect=button.getBoundingClientRect();tagOptionsMenu={x:rect.left,y:rect.bottom};renderTagOptions();
}
function renderTagOptions(focusAction){
  if(!tagOptionsMenu)return;const menu=q('[data-menu]'),count=selectedTagCount(),hasAutomatic=items.some(i=>bridge.automaticTags(i).length);
  const check=(action,label,value)=>`<button type="button" role="menuitemcheckbox" aria-checked="${value}" data-tag-option="${action}"><span class="kb-column-check">${value?icon('check'):''}</span>${label}</button>`;
  menu.classList.add('is-tags');menu.setAttribute('aria-label','标签筛选选项');
  menu.innerHTML=`<div role="menu" aria-label="标签筛选选项"><div class="kb-tag-selection-count" role="presentation">已选中 ${count} 个标签</div><button type="button" role="menuitem" data-tag-option="clear" ${count?'':'disabled'}><span class="kb-column-check"></span>取消全选</button><hr>${check('automatic','显示自动标签',state.showAutomaticTags)}${check('all','显示文献库里的所有标签',state.showAllTags)}<hr><button type="button" role="menuitem" data-tag-option="delete" ${hasAutomatic?'':'disabled'}><span class="kb-column-check"></span>删除此文献库中的自动标签…</button></div>`;
  menu.hidden=false;q('[data-do="tag-options"]')?.setAttribute('aria-expanded','true');updateIcons();positionCollectionMenu(tagOptionsMenu.x,tagOptionsMenu.y);
  (focusAction?menu.querySelector('[data-tag-option="'+focusAction+'"]:not(:disabled)'):null)?.focus({preventScroll:true});
  if(!menu.contains(document.activeElement))menu.querySelector('button:not(:disabled)')?.focus({preventScroll:true});
}
function performTagOption(action){
  if(action==='delete'){showAutomaticTagRemoval();return;}
  if(action==='clear'){clearItemFilters();state.checked=[];pickVisible();render();}
  else if(action==='automatic')state.showAutomaticTags=!state.showAutomaticTags;
  else if(action==='all')state.showAllTags=!state.showAllTags;
  renderTags();saveView();renderTagOptions(action);
}
function showAutomaticTagRemoval(){
  const targets=items.map(item=>({id:item.id,tags:bridge.automaticTags(item)})).filter(t=>t.tags.length);if(!targets.length)return;
  closeCollectionMenu();tagRemoval={generation:libraryGeneration,targets};modal='remove-auto-tags';previousFocus=q('[data-do="tag-options"]');
  const count=new Set(targets.flatMap(t=>t.tags)).size,form=q('[data-form]');form.classList.remove('is-relation');
  form.innerHTML=`<header><h3 id="kb-modal-title">删除自动标签？</h3><button type="button" data-do="cancel" aria-label="关闭">${icon('x')}</button></header><p>将从此文库的 ${targets.length} 个条目中移除 ${count} 种自动标签，范围包括回收站。</p><p class="kb-muted">手动标签、阅读状态、评级和原文件保留。删除的标签不会在自动读取元数据时重新添加。</p><footer><button type="button" class="kb-outline" data-do="cancel">取消</button><button type="button" class="kb-primary" data-do="confirm">删除自动标签</button></footer>`;
  q('[data-shade]').hidden=false;updateIcons();form.querySelector('footer [data-do="cancel"]').focus();
}
async function commitAutomaticTagRemoval(){
  const draft=tagRemoval;if(!draft||tagDeleting)return;
  tagDeleting=true;const controls=[...q('[data-form]').querySelectorAll('button')];controls.forEach(b=>b.disabled=true);
  let committed=false;
  try{
    if(!await flush())return;
    if(draft.generation!==libraryGeneration||tagRemoval!==draft)return;
    const before=snapshot(),next=clone(before);let removed=0;
    for(const target of draft.targets){
      const item=next.items.find(i=>i.id===target.id);if(!item)continue;
      const automatic=bridge.automaticTags(item).filter(t=>target.tags.includes(t));if(!automatic.length)continue;
      const values={tags:item.tags.filter(t=>!automatic.includes(t))};removed+=automatic.length;
      Object.assign(item,bridge.markMetadataEdited(clone(item),values),values);
    }
    if(!removed){tagDeleting=false;closeModal();return;}
    q('[data-save-status]').textContent='正在保存…';
    const job=(async()=>{
      // Publish the deletion only after the existing atomic, conflict-checked commit succeeds.
      const saved=await bridge.commit(clone(base),next);
      const merged=bridge.merge(before,snapshot(),saved);base=clone(saved);items=merged.items.map(i=>({...i,notes:[]}));collections=merged.collections;committed=true;
    })();saving=job;
    try{await job;}finally{if(saving===job)saving=null;}
    state.tags=state.tags.filter(t=>items.some(i=>i.tags.includes(t)));state.checked=[];detailSignature='';saveError='';clearError();q('[data-save-status]').textContent='已保存';
    tagDeleting=false;closeModal();pickVisible();render();saveView();notify('已删除 '+removed+' 个自动标签关联');
  }catch(error){q('[data-save-status]').textContent='删除未完成';throw error;}
  finally{tagDeleting=false;controls.forEach(b=>b.disabled=false);if(committed)persist();}
}

function clearItemFilters(){state.tags=[];state.statusFilter='';state.ratingFilter=0;}
function statusBadge(value){return value==='unread'?`<span class="kb-status-badge unread" title="${statuses.unread}"><span class="kb-tag-dot unread" aria-hidden="true"></span>unread</span>`:'';}
function renderTags(){
  const query=(state.tagQuery||'').trim().toLocaleLowerCase(),matches=text=>!query||text.toLocaleLowerCase().includes(query);
  const source=state.showAllTags?activeItems():visible();
  const tags=[...new Set([...state.tags,...source.flatMap(i=>{const automatic=state.showAutomaticTags?[]:bridge.automaticTags(i);return i.tags.filter(t=>!automatic.includes(t));})])].filter(t=>!['/done','/reading','/unread'].includes(t)&&matches(t)).sort((a,b)=>a.localeCompare(b,'zh-CN',{numeric:true}));
  const statusTags=['done','reading','unread'].filter(v=>matches('/'+v+' '+statuses[v]));
  const ratings=[1,2,3,4,5].filter(n=>matches('⭐'.repeat(n)+' '+n+' 星'));
  const statusHTML=statusTags.map(v=>`<button type="button" class="cursor-interaction kb-status-filter" data-status-filter="${v}" aria-pressed="${state.statusFilter===v}"><span class="kb-tag-dot ${v}" aria-hidden="true"></span>/${v}</button>`).join('');
  const ratingHTML=ratings.map(n=>`<button type="button" class="cursor-interaction kb-rating-filter" data-rating-filter="${n}" aria-pressed="${state.ratingFilter===n}" aria-label="筛选 ${n} 星" title="${n} 星">${'⭐'.repeat(n)}</button>`).join('');
  q('[data-tag-list]').innerHTML=(statusHTML?`<div class="kb-status-filters">${statusHTML}</div>`:'')+ratingHTML+tags.map(t=>`<button type="button" class="cursor-interaction" data-tag="${escape(t)}" aria-pressed="${state.tags.includes(t)}">${escape(t)}</button>`).join('');
  if(!tags.length&&!statusTags.length&&!ratings.length)q('[data-tag-list]').innerHTML='<span class="kb-muted kb-small">没有匹配的标签</span>';
}


    function scope(i,view=state.view){if(view==='trash')return !!i.deleted;if(i.deleted)return false;if(view==='duplicates')return duplicateCache.ids.has(i.id);if(view==='all')return true;if(view==='recent')return !!i.lastFile;if(view==='starred')return i.star;if(['unread','reading','done'].includes(view))return i.status===view;if(view.startsWith('type:'))return i.type===view.slice(5);if(view.startsWith('collection:'))return itemInCollection(i,view.slice(11));return true;}
    const numericValue=value=>value===null||value===undefined||String(value).trim()===''||!Number.isFinite(Number(value))?null:Number(value);
    const sortFields={
      recent:{label:'最近使用',direction:'desc',value:i=>numericValue(i.last)},
      title:{label:'标题',direction:'asc',value:i=>i.title},
      author:{label:'创建者',direction:'asc',value:i=>creatorView(i).sort},
      status:{label:'状态',direction:'asc',value:i=>({unread:0,reading:1,done:2})[i.status]??null},
      date:{get label(){return dateColumnLabel();},direction:'desc',value:tableDateValue},
      rating:{label:'评级',direction:'desc',value:i=>i.rating>0?numericValue(i.rating):null},
      journal:{label:'期刊标签',direction:'asc',value:i=>metricValues(i).badges.map(b=>b.text).join(' ')||(metricsEligible(i)?i.journalTag:'')},
      impact:{label:'影响因子',direction:'desc',value:i=>metricValues(i).impact},
      cites:{label:'被引数',direction:'desc',value:i=>metricValues(i).count},
      year:{label:'年份',direction:'desc',value:i=>numericValue(i.year)}
    };
    const textOrder=new Intl.Collator('zh-Hans-CN',{numeric:true,sensitivity:'base'});
    function compareItems(a,b){
      const field=sortFields[state.sort],av=field.value(a),bv=field.value(b),missing=v=>v===null||v===undefined||String(v).trim()==='';
      if(state.sort==='journal'||state.sort==='cites'){const order=(state.sort==='journal'?bridge.compareJournal:bridge.compareCitations)(a,b,state.sortDirection==='asc'?1:-1);return order||textOrder.compare(a.title,b.title)||a.id.localeCompare(b.id);}
      if(missing(av)!==missing(bv))return missing(av)?1:-1;
      let order=missing(av)?0:typeof av==='number'?av-bv:textOrder.compare(String(av),String(bv));
      if(!order&&state.sort==='author'){
        const ac=creatorView(a).names,bc=creatorView(b).names;
        for(let n=0;n<Math.min(ac.length,bc.length)&&!order;n++)order=textOrder.compare(ac[n].family,bc[n].family)||textOrder.compare(ac[n].name,bc[n].name);
        order ||= ac.length-bc.length;
      }
      return order*(state.sortDirection==='asc'?1:-1)||(Number(b.last)||0)-(Number(a.last)||0)||textOrder.compare(a.title,b.title)||a.id.localeCompare(b.id);
    }
    function renderSort(){
      for(const button of qa('[data-sort-by]')){const key=button.dataset.sortBy,active=state.sort===key,field=sortFields[key],next=active&&state.sortDirection==='asc'?'降序':active?'升序':field.direction==='asc'?'升序':'降序';button.parentElement.setAttribute('aria-sort',active?(state.sortDirection==='asc'?'ascending':'descending'):'none');button.setAttribute('aria-label',field.label+'：点击按'+next+'排列');button.innerHTML='<span>'+field.label+'</span>'+(active?icon(state.sortDirection==='asc'?'chevron-up':'chevron-down'):'');}

    }
    function visible(){refreshDuplicates();const terms=searchTerms(state.query),list=items.filter(i=>scope(i)&&state.tags.every(t=>i.tags.includes(t))&&(!state.statusFilter||i.status===state.statusFilter)&&(!state.ratingFilter||Number(i.rating)===state.ratingFilter)&&matchesSearch(i,terms));
      if(state.view!=='duplicates')return list.sort(compareItems);
      const matches=new Set(list.map(i=>i.id));return duplicateCache.groups.filter(g=>g.some(id=>matches.has(id))).map(g=>g.map(byID)).sort((a,b)=>compareItems(a[0],b[0])).flat();}

    function navButton(view,label,name,sub=false){const count=items.filter(i=>scope(i,view)).length;return `<button type="button" class="cursor-interaction ${sub?'kb-sub':''}" data-view="${escape(view)}" title="${escape(label)}" aria-pressed="${state.view===view}">${icon(name)}<span>${escape(label)}</span><span class="kb-count">${count}</span></button>`;}
function renderNav(){
  refreshDuplicates();
  const closed=state.closedGroups||[],group=(key,label,children)=>`<button type="button" class="kb-tree-group cursor-interaction" data-tree="${escape(key)}" aria-expanded="${!closed.includes(key)}">${icon(closed.includes(key)?'chevron-right':'chevron-down')}${icon('folder-open')}<span>${escape(label)}</span></button><div class="kb-tree-section" ${closed.includes(key)?'hidden':''}>${children}</div>`;
  q('[data-nav]').innerHTML=`<div class="kb-nav-main"><div class="kb-tree-row"><button type="button" class="cursor-interaction" data-tree="library" aria-label="展开或收起我的文库" aria-expanded="${!closed.includes('library')}">${icon(closed.includes('library')?'chevron-right':'chevron-down')}</button>${navButton('all','我的文库','library-big')}</div><div ${closed.includes('library')?'hidden':''}>${collectionTreeMarkup()}</div><div class="kb-tree-divider"></div>${group('views','快捷视图',`<div class="kb-saved-views">${[['recent','最近阅读','history'],['starred','收藏','star'],['duplicates','重复条目','copy'],['trash','回收站','trash-2']].map(v=>navButton(...v)).join('')}</div>`)}</div><button type="button" class="kb-splitter kb-splitter-horizontal" data-resize="tags" role="separator" aria-orientation="horizontal" aria-label="调整标签区高度" aria-valuemin="80" aria-valuemax="330" aria-valuenow="155" data-tooltip="拖动调整标签区 · 双击恢复默认"></button><div class="kb-tag-panel"><div class="kb-tag-list" data-tag-list></div><div class="kb-tag-search"><input data-tag-search aria-label="筛选标签" placeholder="筛选标签" value="${escape(state.tagQuery||'')}">${`<button type="button" class="kb-tag-options" data-do="tag-options" aria-label="标签筛选选项" aria-haspopup="menu" aria-expanded="false">${icon('filter')}${icon('chevron-down')}</button>`}</div></div>`;
  renderTags();
}
    function viewName(){return {all:'全部条目',recent:'最近阅读',starred:'收藏',unread:'未读',reading:'在读',done:'已读',trash:'回收站',duplicates:'重复条目'}[state.view]||typeNames[state.view.slice(5)]||collections.find(c=>'collection:'+c.id===state.view)?.name||'我的文库';}
let selectionAnchor=null;
function selectionIDs(){return state.checked.length?[...state.checked]:(state.selected?[state.selected]:[]);}
function ratingValue(item){const value=Number(item?.rating);return Number.isFinite(value)?Math.max(0,Math.min(5,Math.round(value))):0;}
function ratingMarkup(item,editable=true,surface='list'){
  const value=ratingValue(item),label=value?'评级 '+value+' / 5':'未评级';
  if(!editable)return value?`<span class="kb-rating-static" role="img" aria-label="${label}">${'⭐'.repeat(value)}</span>`:'';
  return `<div class="kb-rating-control" data-rating-id="${escape(item.id)}" data-rating-surface="${surface}" role="group" aria-label="${label}">${[1,2,3,4,5].map(n=>`<button type="button" class="cursor-interaction" data-rate="${n}" data-rating-item="${escape(item.id)}" aria-pressed="${n<=value}" aria-label="${n===value?'清除评级（当前 '+n+' 级）':'评为 '+n+' 级'}" title="${n===value?'再次点击清除评级':'评为 '+n+' 级'}"><span data-rating-symbol aria-hidden="true">${n<=value?'⭐':'🌙'}</span></button>`).join('')}</div>`;
}
function detailRatingMarkup(item){
  const label=item.star?'取消收藏':'收藏';
  return '<div class="kb-field kb-detail-control"><span>评级</span><div class="kb-rating-actions">'+ratingMarkup(item,true,'detail')+'<button type="button" class="kb-detail-favorite cursor-interaction" data-star="'+escape(item.id)+'" aria-label="'+label+'" title="'+label+'" aria-pressed="'+!!item.star+'">'+icon('star')+'</button></div></div>';
}
function renderListRatings(){
  const ids=new Set(selectionIDs());
  for(const row of qa('[data-row]')){
    const item=byID(row.dataset.row),cell=row.querySelector('[data-column="rating"]');if(!item||!cell)continue;
    const editable=ids.has(item.id),signature=ratingValue(item)+':'+editable;
    if(cell.dataset.ratingKey!==signature){cell.innerHTML=ratingMarkup(item,editable);cell.dataset.ratingKey=signature;}
  }
}
function previewRating(group,value){for(const button of group.querySelectorAll('[data-rate]')){const symbol=button.querySelector('[data-rating-symbol]'),text=Number(button.dataset.rate)<=value?'⭐':'🌙';if(symbol.textContent!==text)symbol.firstChild.nodeValue=text;}}
function setItemRating(id,value,surface){
  const item=byID(id);if(!item||!Number.isInteger(value)||value<1||value>5)return;
  item.rating=ratingValue(item)===value?0:value;
  pickVisible();renderList();renderDetail();updateIcons();persist();
  const button=q('[data-rating-surface="'+surface+'"][data-rating-id="'+id+'"] [data-rate="'+value+'"]');
  button?.focus({preventScroll:true});if(surface==='list')button?.scrollIntoView({block:'nearest',inline:'nearest'});
  notify(item.rating?'评级已设为 '+item.rating+' 级':'已清除评级');
}
root.addEventListener('pointerover',event=>{const button=event.target.closest('[data-rate]');if(button)previewRating(button.closest('[data-rating-id]'),Number(button.dataset.rate));});
root.addEventListener('pointerout',event=>{const group=event.target.closest('[data-rating-id]');if(group&&!group.contains(event.relatedTarget))previewRating(group,ratingValue(byID(group.dataset.ratingId)));});
function removalActions(){return state.view==='recent'?[['clear-recent','清除阅读记录','history'],['clear-all-recent','清空阅读记录','x']]:[['trash','移入回收站','trash-2']];}
function renderSelection(){
  const ids=selectionIDs();for(const row of qa('[data-row]')){const active=ids.includes(row.dataset.row);row.classList.toggle('kb-selected',active);row.setAttribute('aria-selected',String(active));row.querySelector('[data-select]')?.setAttribute('aria-pressed',String(active));}
  renderListRatings();
  q('[data-bulk]').hidden=state.view==='recent'?!items.some(i=>scope(i,'recent')):ids.length<2;
  const removeButtons=removalActions().filter(([action])=>ids.length||action==='clear-all-recent').map(([action,label])=>`<button type="button" class="cursor-interaction" data-bulk-action="${action}" title="${action==='clear-all-recent'?'清空全部最近阅读记录，包含筛选隐藏的条目':label}">${label}</button>`).join('');
  q('[data-bulk]').innerHTML=`${ids.length?`<span>已选 ${ids.length} 项</span>`:''}${state.view==='trash'?'<button type="button" class="cursor-interaction" data-bulk-action="restore">恢复条目</button><button type="button" class="cursor-interaction" data-bulk-action="purge">永久删除…</button>':`${ids.length?'<button type="button" class="cursor-interaction" data-bulk-action="done">标为已读</button><button type="button" class="cursor-interaction" data-bulk-action="star">收藏</button>':''}${removeButtons}`}`;
}
function selectRow(id,event={}){
  const list=visible().map(i=>i.id),previous=selectionIDs(),augment=event.ctrlKey||event.metaKey;
  if(state.view==='duplicates'&&!event.shiftKey&&!augment){refreshDuplicates();state.checked=[...(duplicateCache.byID.get(id)||[id])];state.selected=id;selectionAnchor=id;state.detailCollapsed=false;mergeDraft=null;}
  else if(event.shiftKey){const anchor=list.includes(selectionAnchor)?selectionAnchor:(list.includes(state.selected)?state.selected:id),a=list.indexOf(anchor),b=list.indexOf(id),range=list.slice(Math.min(a,b),Math.max(a,b)+1);selectionAnchor=anchor;state.checked=augment?[...new Set([...previous,...range])]:range;state.selected=id;}
  else if(augment){state.checked=previous.includes(id)?previous.filter(x=>x!==id):[...previous,id];state.selected=state.checked.includes(id)?id:state.checked.at(-1)||null;selectionAnchor=id;}
  else{state.selected=id;state.checked=[id];selectionAnchor=id;}
  q('[data-menu]').hidden=true;renderSelection();renderDetail();updateIcons();q('[data-select="'+id+'"]')?.focus({preventScroll:true});persist();
}
function renderList(){
  webOnlyList=visible().length>0&&visible().every(i=>i.type==='webpage');
  root.classList.toggle('is-web-only-list',webOnlyList);
  selectColumnLayout();
  summarySearchPending=false;
  renderSort();
  const list=visible();q('[data-list-title]').textContent=viewName();q('[data-count]').textContent=`${list.length} 个条目`;
  q('[data-filter]').innerHTML=state.tags.map(tag=>`<button type="button" class="cursor-interaction" data-tag="${escape(tag)}">${escape(tag)} ${icon('x')}</button>`).join('')+(state.statusFilter?`<button type="button" data-status-filter="${state.statusFilter}">/${state.statusFilter} ${icon('x')}</button>`:'')+(state.ratingFilter?`<button type="button" data-rating-filter="${state.ratingFilter}">${'⭐'.repeat(state.ratingFilter)} ${icon('x')}</button>`:'');q('[data-filter]').hidden=!state.tags.length&&!state.statusFilter&&!state.ratingFilter;
  q('[data-items]').innerHTML=list.map(i=>`<tr class="kb-row" data-row="${escape(i.id)}"><td data-column="title"><div class="kb-title-cell">${i.type==='webpage'?'<span class="kb-expand kb-web-indent" aria-hidden="true"></span>':`<button type="button" class="kb-expand cursor-interaction" data-expand="${escape(i.id)}" aria-label="展开 ${escape(itemTitle(i))} 的附件和笔记" aria-expanded="${state.expanded.includes(i.id)}">${icon(state.expanded.includes(i.id)?'chevron-down':'chevron-right')}</button>`}<span class="kb-item-symbol">${icon(typeIcons[i.type])}</span><button type="button" class="kb-item-title cursor-interaction" aria-label="${escape(itemTitle(i)||'空白条目')}" data-select="${escape(i.id)}" data-tooltip="${escape(itemTitle(i))}">${escape(itemTitle(i))}</button></div>${i.webpage&&state.query?'<div class="kb-web-snippet">'+escape(bridge.webSnippet(i.id,state.query))+'</div>':''}</td><td data-column="author" class="kb-author-cell" title="${escape(i.type==='webpage'?'':i.author||'')}">${escape(i.type==='webpage'?'':creatorView(i).text)}</td><td data-column="status" class="kb-status-cell">${i.type==='webpage'?'':statusBadge(i.status)}</td><td data-column="date" class="kb-date-cell kb-muted-cell" title="${escape(fullDate(tableDateValue(i)))}">${escape(tableDate(i))}</td><td data-column="rating" class="kb-rating-cell kb-rating-value"></td><td data-column="journal" class="kb-journal-cell kb-muted-cell">${metricMarkup(i,'journal')}</td><td data-column="impact" class="kb-impact-cell">${metricMarkup(i,'impact')}</td><td data-column="cites" class="kb-cites-cell kb-muted-cell">${metricMarkup(i,'cites')}</td></tr>${i.type!=='webpage'&&state.expanded.includes(i.id)?`<tr><td colspan="${orderedColumns().length}" class="kb-file-inline">${bookMode(i)?bookTreeMarkup(i):i.files.length?i.files.map(f=>`<button type="button" class="cursor-interaction" data-read="${escape(i.id)}" data-file="${escape(f.id)}" title="${escape(f.name)}"><span class="kb-file-symbol">${icon(fileIcon(f))}</span><span class="kb-file-name">${escape(f.name)}</span>${f.id===i.defaultFile?'<span class="kb-muted">· 默认</span>':''}</button>`).join(''):'还没有关联文件'}<div data-child-notes="${escape(i.id)}">${childNotesMarkup(i)}</div></td></tr>`:''}`).join('');
  applyColumnOrder();applyColumnWidths();
  renderSelection();updateIcons();
  for(const item of list)if(state.expanded.includes(item.id)&&item.type!=='webpage')void loadItemNotes(item);
}
    const noteCache=new Map(),noteRequests=new Map();let noteMenu=null,noteMenuFocus=null,noteRemoval=null,noteDeleting=false;
    function notesMarkup(item){
      const entry=noteCache.get(item.id);
      if(!entry)return '<div class="kb-notes-pending" role="status" aria-label="正在读取笔记"></div>';
      return (entry.warnings.length?'<p class="kb-error">'+escape(entry.warnings.join('；'))+'</p>':'')+(entry.notes.map((n,index)=>`<div class="kb-note" data-note-index="${index}"><button type="button" class="kb-note-open" data-open-note="${index}" title="${escape(n.title)}" aria-label="打开笔记：${escape(n.title)}">${icon('sticky-note')}<span>${escape(n.title)}</span></button>${!item.deleted&&n.kind==='笔记'?`<button type="button" class="kb-note-remove" data-note-remove="${index}" title="删除笔记" aria-label="删除笔记：${escape(n.title)}">${icon('minus')}</button>`:''}</div>`).join(''));
    }
    function notesHeading(open,item){
      const cached=noteCache.get(item.id),label=cached?cached.notes.length+' 个笔记':'笔记';
      return `<button type="button" class="kb-section-title cursor-interaction" data-section="notes" aria-expanded="${!!open}" aria-controls="kb-section-notes">${icon('sticky-note')}<span>${label}</span></button><button type="button" class="kb-section-action cursor-interaction" data-do="open-notes" aria-label="添加笔记" ${item.deleted?'disabled':''}>${icon('plus')}</button><button type="button" class="kb-section-action cursor-interaction" data-section="notes" aria-label="${open?'收起':'展开'}笔记" aria-expanded="${!!open}" aria-controls="kb-section-notes">${icon(open?'chevron-up':'chevron-down')}</button>`;
    }
    function childNotesMarkup(item){
      const cached=noteCache.get(item.id);if(!cached)return '';
      return cached.notes.map(n=>`<button type="button" class="kb-child-note cursor-interaction" data-child-note="${escape(item.id)}" data-note-id="${escape(n.id)}" data-note-kind="${escape(n.kind)}" data-note-file="${escape(n.fileId)}" title="${escape(n.title)}" aria-label="打开${escape(n.kind)}：${escape(n.title)}"><span class="kb-file-symbol">${icon('sticky-note')}</span><span class="kb-file-name">${escape(n.title||n.kind)}</span><span class="kb-child-note-kind">${escape(n.kind)}</span></button>`).join('')+(cached.warnings.length?'<span class="kb-error">'+escape(cached.warnings.join('；'))+'</span>':'');
    }
    function refreshChildNotes(item){
      const child=qa('[data-child-notes]').find(e=>e.dataset.childNotes===item.id);if(child)child.innerHTML=childNotesMarkup(item);
    }
    function loadItemNotes(item,force=false){
      if(noteRequests.has(item.id))return noteRequests.get(item.id);
      if(noteCache.has(item.id)&&!force)return Promise.resolve(noteCache.get(item.id));
      const generation=libraryGeneration;
      const request=bridge.noteList(clone(item)).catch(error=>({notes:[],warnings:[error.message]})).then(value=>{
        if(generation!==libraryGeneration||noteRequests.get(item.id)!==request)return;
        noteCache.set(item.id,value);refreshChildNotes(item);
        if(state.selected===item.id){const content=q('[data-section-body="notes"]');if(content)content.innerHTML=notesMarkup(item);const label=q('[data-section="notes"] span');if(label)label.textContent=value.notes.length+' 个笔记';}
        updateIcons();return value;
      }).finally(()=>{if(noteRequests.get(item.id)===request)noteRequests.delete(item.id);});
      noteRequests.set(item.id,request);return request;
    }
    function loadVisibleNotes(force=false){
      const item=selected(),body=q('[data-section-body="notes"]'),scroller=q('[data-pane-scroll]');
      if(!item||state.detailCollapsed||!state.sections.notes||!body||body.hidden||!scroller)return;
      const b=body.getBoundingClientRect(),r=scroller.getBoundingClientRect();if(b.bottom<=r.top||b.top>=r.bottom)return;
      void loadItemNotes(item,force);
    }
    function refreshExpandedNotes(){for(const item of visible())if(state.expanded.includes(item.id)&&item.type!=='webpage')void loadItemNotes(item,true);}
    function noteTarget(index,owner=state.selected,identity=null){
      const item=byID(owner),notes=noteCache.get(item?.id)?.notes;
      // Child rows belong to their own item, which need not be the selected row.
      const note=identity?notes?.find(n=>n.id===identity.noteId&&n.kind===identity.noteKind&&n.fileId===identity.noteFile):notes?.[Number(index)];
      if(!item||item.deleted||note?.kind!=='笔记')return null;
      const file=item.files.find(f=>f.id===note.fileId);if(!file)return null;
      return {owner:item.id,file:clone(file),note:clone(note),generation:libraryGeneration};
    }
    function showNoteMenu(card,x,y){
      const d=card.dataset,target=d.childNote?noteTarget(null,d.childNote,d):noteTarget(d.noteIndex);if(!target)return false;
      closeCollectionMenu();attachmentMenu=null;noteMenu=target;noteMenuFocus=card.matches('button')?card:card.querySelector('button');
      const menu=q('[data-menu]');menu.classList.add('is-collection');menu.setAttribute('aria-label','笔记操作');menu.setAttribute('role','menu');
      menu.innerHTML=`<button type="button" role="menuitem" data-note-delete>${icon('trash-2')}<span>删除笔记…</span></button>`;
      menu.hidden=false;updateIcons();positionCollectionMenu(x,y);menu.querySelector('button').focus();return true;
    }
    function showNoteRemoval(target=noteMenu){
      if(!target)return;const focus=noteMenuFocus||document.activeElement;noteRemoval=target;closeCollectionMenu();modal='remove-note';previousFocus=focus;
      showCompactConfirmation('删除笔记','确定删除“'+(target.note.title||'未命名笔记')+'”吗？');
      q('[data-form] [data-do="confirm"]').textContent='删除';q('[data-form] footer [data-do="cancel"]').textContent='取消';
    }
    async function commitNoteRemoval(){
      const draft=noteRemoval;if(!draft||noteDeleting)return;
      const item=byID(draft.owner),file=item?.files.find(f=>f.id===draft.file.id);
      if(draft.generation!==libraryGeneration||!item||item.deleted||JSON.stringify(file)!==JSON.stringify(draft.file))throw Error('笔记所属条目或附件已变化，请重新选择');
      noteDeleting=true;q('[data-form] [data-do="confirm"]').disabled=true;
      try{
        const result=await bridge.deleteNote(clone(file),draft.note.kind,draft.note.id);
        if(draft.generation!==libraryGeneration)return;
        if(result?.closePane)leaveNotePane();
        // The same document can belong to several items; invalidate all cached views.
        noteCache.clear();noteRequests.clear();detailSignature='';
        if(noteRemoval===draft){noteRemoval=null;if(previousFocus?.matches('[data-child-note]'))previousFocus=qa('[data-select]').find(b=>b.dataset.select===draft.owner);closeModal();}
        renderDetail();updateIcons();loadVisibleNotes(true);refreshExpandedNotes();notify('笔记已删除');
      }catch(error){
        if(draft.generation===libraryGeneration){noteCache.clear();noteRequests.clear();detailSignature='';renderDetail();updateIcons();loadVisibleNotes(true);refreshExpandedNotes();}
        throw error;
      }finally{noteDeleting=false;const button=q('[data-form] [data-do="confirm"]');if(button)button.disabled=false;}
    }
function renderDetail(previousScroll=null){
  if(notePane){
    const current=selected();
    if(current?.id===notePane.owner&&!current.deleted&&selectionIDs().length<=1){renderNotePane();return;}
    if(!leaveNotePane()){state.selected=notePane.owner;state.checked=[notePane.owner];renderSelection();return;}
  }
  const oldID=detailItemID,position=captureDetailPosition(),item=selected();
  if(infoEditor){if(infoEditor.id===item?.id&&selectionIDs().length<=1&&!item.deleted&&!state.detailCollapsed&&state.sections.info)return;if(!commitInfoEdit())return;}
  if(tagEditor){if(tagEditor.id===item?.id&&selectionIDs().length<=1&&!item.deleted&&!state.detailCollapsed&&state.sections.tags)return;if(!commitTagEdit())return;}
  if(summaryEditor){if(summaryEditor.id===item?.id)return;commitSummaryEdit();}
  if(state.view==='duplicates'||selectionIDs().length>1&&mergeMembers().every(i=>!i.deleted&&i.type!=='webpage')){detailSignature='';noteObserver?.disconnect();renderMergePane();return;}
  mergeDraft=null;refreshDuplicates();
  const signature=JSON.stringify([item,selectionIDs().length,state.sections,state.paneOrder,state.pinnedPane,state.detailCollapsed,state.view,collections,isbnStates.get(item?.id),[...(addedInfoFields.get(item?.id)||[])],(item?.related||[]).map(id=>byID(id)?.title)]);
  if(detailSignature===signature&&previousScroll===null)return;
  detailSignature=signature;detailItemID=item?.id||null;noteObserver?.disconnect();
  if(previousScroll===null)previousScroll=oldID===detailItemID?position:state.pinnedPane?null:detailPositions.get(detailItemID)||null;
  if(selectionIDs().length>1){q('[data-detail]').innerHTML=`<div class="kb-detail-content"><div class="kb-empty">已选择 ${selectionIDs().length} 个条目</div></div><nav class="kb-detail-rail" aria-label="详情分区">${paneToggleMarkup()}</nav>`;applyLayout();return;}
  const i=selected();if(!i){q('[data-detail]').innerHTML=`<div class="kb-detail-content"><div class="kb-empty">选择一个条目查看详情</div></div><nav class="kb-detail-rail" aria-label="详情分区">${paneToggleMarkup()}</nav>`;applyLayout();return;}
  const sections=state.sections||{info:true};
  const info=i.type==='webpage'?webInfoMarkup(i)+detailRatingMarkup(i):`${itemInfoMarkup(i)}${metricDetail(i)}<div class="kb-field kb-detail-control"><label for="kb-status">阅读状态</label><div class="kb-status-control"><select id="kb-status" data-status>${Object.entries(statuses).map(([v,n])=>`<option value="${v}" ${v===i.status?'selected':''}>${n}</option>`).join('')}</select>${icon('chevron-down')}</div></div>${detailRatingMarkup(i)}${itemInfoActions(i)}${i.deleted?'<button type="button" class="kb-outline kb-open cursor-interaction" data-do="restore">恢复条目</button>':''}`;
  const files=bookMode(i)?bookTreeMarkup(i):i.files.map((f,n)=>`<div class="kb-file" data-attachment-item="${escape(i.id)}" data-attachment-file="${escape(f.id)}"><button type="button" class="kb-file-title cursor-interaction" data-read="${escape(i.id)}" data-file="${escape(f.id)}">${icon(fileIcon(f))}<span title="${escape(f.path)}">${escape(f.name)}</span></button><div class="kb-file-actions"><span>${escape(f.kind)}</span><button type="button" class="kb-default cursor-interaction" data-default="${escape(f.id)}">${i.defaultFile===f.id?'✓ 默认阅读':'设为默认'}</button>${!isWeb(f)?`<button type="button" data-relink="${escape(f.id)}">重新定位</button>`:''}<button type="button" data-unlink="${escape(f.id)}">取消关联</button>${i.type==='book'?`<button type="button" class="cursor-interaction" data-move="${escape(f.id)}" data-dir="-1" aria-label="上移 ${escape(f.name)}" ${n===0?'disabled':''}>${icon('arrow-up')}</button><button type="button" class="cursor-interaction" data-move="${escape(f.id)}" data-dir="1" aria-label="下移 ${escape(f.name)}" ${n===i.files.length-1?'disabled':''}>${icon('arrow-down')}</button>`:''}</div></div>`).join('');
  const related=(i.related||[]).map(byID).filter(x=>x&&!x.deleted);
  const groups=[
    ['info','信息','file-text',info,null],
    ['summary',i.type==='book'?'简介':'摘要','align-left',`<div data-summary-content>${summaryMarkup(i)}</div>`,null],
    ['files',bookMode(i)?`目录与章节（${i.files.length}）`:`${i.files.length} 个${i.type==='book'?'章节 / 附件':'附件'}`,'paperclip',files,'file'],
    ['notes',`${(noteCache.get(i.id)?.notes.length||0)} 个笔记`,'sticky-note',notesMarkup(i),'open-notes'],
    ['collections','文库和分类','folders',membershipTreeMarkup(i),'collections'],
    ['tags',`${i.tags.length} 个标签`,'tag',itemTagsMarkup(i),'add-tag'],
    ['related',`${related.length} 个相关`,'link',related.map(x=>`<div class="kb-related-row"><button type="button" class="kb-related cursor-interaction" data-select="${escape(x.id)}">${icon(typeIcons[x.type])}${escape(itemTitle(x))}</button><button type="button" class="kb-remove-related cursor-interaction" data-unrel="${escape(x.id)}" aria-label="移除与 ${escape(itemTitle(x))} 的关联">${icon('x')}</button></div>`).join(''),'related']
  ].filter(([id])=>i.type!=='webpage'||!['files','notes'].includes(id));
  groups.sort((a,b)=>state.paneOrder.indexOf(a[0])-state.paneOrder.indexOf(b[0]));
  q('[data-detail]').innerHTML=`<div class="kb-detail-content"><header class="kb-item-heading"><h2>${escape(itemTitle(i))}</h2>${i.type==='webpage'?webHeading(i):''}${bookMode(i)&&!i.deleted?`<div class="kb-book-actions"><button type="button" data-read="${escape(i.id)}" data-file="${escape(i.book.entryFile)}">${icon('align-left')}全书目录</button><button type="button" data-read="${escape(i.id)}">${icon('book-open')}${i.lastFile?'继续阅读':'开始阅读'}</button></div>`:''}${!i.deleted&&duplicateCache.ids.has(i.id)?`<div class="kb-duplicate-notice"><span>该条目与已有条目重复</span><button type="button" data-duplicate-open="${escape(i.id)}">前往合并条目窗格</button></div>`:""}</header><div class="kb-accordion" data-pane-scroll>${groups.map(([id,label,symbol,body,action])=>`<section class="kb-section" data-section-block="${id}"><div class="kb-section-head"><button type="button" class="kb-section-title cursor-interaction" data-section="${id}" aria-expanded="${!!sections[id]}" aria-controls="kb-section-${id}">${icon(symbol)}<span>${label}</span><span class="kb-section-chevron">${icon(sections[id]?'chevron-up':'chevron-down')}</span></button>${action?`<button type="button" class="kb-section-action cursor-interaction" data-do="${action}" aria-label="${['edit','summary','collections'].includes(action)?'编辑'+label:action==='file'?'添加关联文件':action==='related'?'添加相关条目':'打开阅读并添加笔记'}">${icon(['edit','summary','collections'].includes(action)?'pencil':'plus')}</button>`:''}</div><div class="kb-section-body" id="kb-section-${id}" data-section-body="${id}" ${sections[id]?'':'hidden'}>${body}</div></section>`).join('')}<div data-pane-tail aria-hidden="true"></div></div></div><nav class="kb-detail-rail" aria-label="详情分区">${paneToggleMarkup()}${groups.map(([id,label,symbol])=>`<button type="button" class="cursor-interaction" data-jump-section="${id}" aria-label="查看${label}" aria-pressed="${state.activeSection===id}" data-tooltip="${label}${state.pinnedPane===id?' · 已固定':''}" title="${label}${state.pinnedPane===id?' · 已固定':''}" data-pinned="${state.pinnedPane===id}">${icon(symbol)}</button>`).join('')}</nav>`;
  q('[data-section-block="collections"] .kb-section-head').innerHTML=membershipHeading(sections.collections,i);
  q('[data-section-block="tags"] .kb-section-head').innerHTML=itemTagsHeading(sections.tags,i);
  const notesHead=q('[data-section-block="notes"] .kb-section-head');if(notesHead)notesHead.innerHTML=notesHeading(sections.notes,i);
  applyLayout();bindPaneScroll(previousScroll);
  if(oldID!==detailItemID&&base&&!loading)queueMicrotask(()=>void syncMetadata({onlySelected:true}));
}
    function render(){applyPalette();root.dataset.density=design.density;root.style.setProperty('--kb-row',design.density==='compact'?'5px':'9px');q('[data-library]').hidden=!!state.reader;q('[data-reader]').hidden=!state.reader;q('[data-search]').value=state.query;renderNav();renderList();renderDetail();applyLayout();updateIcons();queueDuplicateAlert();}
    function pickVisible(){const list=visible();if(state.view==='duplicates'&&!state.checked.length){state.selected=null;selectionAnchor=null;return;}if(!list.some(i=>i.id===state.selected))state.selected=list[0]?.id||null;state.checked=state.checked.filter(id=>list.some(i=>i.id===id));if(!list.some(i=>i.id===selectionAnchor))selectionAnchor=state.selected;}
    let openingFile=false;
    function leaveNotePane(){
      if(!notePane)return true;
      if(!bridge.closeNotePane())return false;
      notePane=null;noteCache.clear();noteRequests.clear();detailSignature='';return true;
    }
    function renderNotePane(){
      noteObserver?.disconnect();
      if(!q('.kb-note-pane')){
        q('[data-detail]').innerHTML=`<div class="kb-detail-content kb-note-pane"><header class="kb-note-pane-heading"><button type="button" data-note-back aria-label="返回条目信息" title="返回条目信息">${icon('arrow-left')}</button>${icon('sticky-note')}<span data-note-pane-title></span></header><div data-note-editor-surface><span data-note-loading role="status">正在打开笔记…</span></div></div><nav class="kb-detail-rail" aria-label="笔记面板">${paneToggleMarkup()}</nav>`;
      }
      q('[data-note-pane-title]').textContent=notePane.title||'笔记';
      q('[data-note-loading]').hidden=!notePane.loading;
      applyLayout();updateIcons();
    }
    async function openSidebarNote(item,file,note){
      if(!await flush()||!leaveNotePane())return;
      if(selected()?.id!==item.id)return;
      captureDetailPosition();
      const session=notePane={owner:item.id,title:note.title||'笔记',loading:true};
      state.detailCollapsed=false;if(bridge.workspace&&root.dataset.layout!=="desktop")workspacePane('detail');renderNotePane();
      try{
        const result=await bridge.openNotePane(clone(file),note.id,!!note.create);
        if(notePane!==session)return;
        if(!result){leaveNotePane();renderDetail();return;}
        session.title=result.title;session.loading=false;renderNotePane();
      }catch(error){if(notePane===session){leaveNotePane();renderDetail();updateIcons();showError(error.message);}}
    }
    async function readItem(id,fileID,note=null){
      if(openingFile)return;const i=byID(id);if(!i||i.deleted)return;
      if(i.type==='webpage'){await bridge.openResourceURL(i.url);return;}
      const f=i.files.find(f=>f.id===(fileID||(i.type==='webpage'?i.webpage?.currentFile:i.lastFile)||i.defaultFile))||i.files[0];
      if(!f){state.selected=id;state.sections.files=true;state.detailCollapsed=false;render();notify('先添加关联文件或章节');return;}
      if(note?.kind==='笔记'){await openSidebarNote(i,f,note);return;}
      openingFile=true;let releaseSurface;
      try{
        if(!await flush())return;
        releaseSurface=bridge.beginRead?.();
        if(note)await bridge.openNote(clone(f),note.kind,note.id,note.create);else await bridge.openFile(clone(f));
        const current=byID(id);if(current){current.lastFile=f.id;current.last=Date.now();if(current.status==='unread')current.status='reading';}
        state.selected=id;state.checked=[id];persist();if(await flush())await bridge.close();
      }catch(error){showError(error.message,()=>readItem(id,f.id,note));}finally{releaseSurface?.();openingFile=false;}
    }
    const bookMode=item=>item?.type==='book'&&item.book?.version===1;
    function bookTreeMarkup(item){
      const tree={folders:new Map(),files:[]},toc=item.files.find(f=>f.id===item.book.entryFile);
      for(const file of item.files){
        if(file===toc)continue;
        const parts=(file.bookPath||file.name).replaceAll('\\','/').split('/').filter(Boolean);let node=tree,trail='';
        for(const part of parts.slice(0,-1)){trail+=(trail?'/':'')+part;if(!node.folders.has(part))node.folders.set(part,{folders:new Map(),files:[],path:trail});node=node.folders.get(part);}
        node.files.push(file);
      }
      const leaf=f=>`<button type="button" class="kb-book-leaf ${f.id===item.lastFile?'is-current':''}" data-read="${escape(item.id)}" data-file="${escape(f.id)}" title="${escape(f.bookPath||f.name)}" ${item.deleted?'disabled':''}>${icon(fileIcon(f))}<span>${escape(f.name.replace(/\.(md|markdown|mdown)$/i,''))}</span>${f.id===item.lastFile?'<small>上次阅读</small>':''}</button>`;
      const branch=node=>node.files.map(leaf).join('')+[...node.folders.entries()].map(([name,child])=>{
        const key=item.id+':'+child.path,remembered=state.bookFolders?.[key],last=item.files.find(f=>f.id===item.lastFile)?.bookPath||'',open=remembered??last.startsWith(child.path+'/');
        return `<details class="kb-book-folder" data-book-folder="${escape(key)}" ${open?'open':''}><summary>${icon('folder')}<span>${escape(name)}</span></summary><div>${branch(child)}</div></details>`;
      }).join('');
      return `<nav class="kb-book-tree" aria-label="章节目录">${toc?`<div class="kb-book-toc">${leaf(toc)}</div>`:''}${branch(tree)}</nav>`;
    }
    root.addEventListener('toggle',event=>{const folder=event.target;if(!folder.matches?.('[data-book-folder]')||!folder.isConnected)return;state.bookFolders||={};state.bookFolders[folder.dataset.bookFolder]=folder.open;saveView();},true);
    async function rememberBookFile(file){
      if(!file||!base||loading||openingFile||saving||dirty()||modal||infoEditor||summaryEditor||tagEditor||notePane)return;
      for(const item of items){
        if(!bookMode(item)||item.deleted)continue;
        const chapter=item.files.find(f=>f.bookPath&&bridge.sameFile(f,file));
        if(!chapter||item.lastFile===chapter.id)continue;
        item.lastFile=chapter.id;item.last=Date.now();if(item.status==='unread')item.status='reading';
        if(state.selected===item.id)detailSignature='';await flush(false);return;
      }
    }
    async function importBook(){
      if(importToken||!base||loading||modal)return;
      closeCollectionMenu();newTypeMenu=false;if(!await flush())return;
      const folder=await bridge.chooseBookFolder();if(!folder)return;
      const token=importToken={cancelled:false,stage:'copying'},target=state.view.startsWith('collection:')?state.view.slice(11):null;setImportBusy(true);
      try{
        const result=await bridge.importBook(folder,target,(text,phase)=>{q('[data-import-progress]').textContent=text;token.stage=phase;q('[data-do="cancel-import"]').disabled=phase==='saving';});
        // The service committed the complete book atomically; load that revision before any UI save.
        importToken=null;loadLibrary(result.data,{state:{...state,view:target?'collection:'+target:'all',selected:result.id,query:'',expanded:[...new Set([...state.expanded,result.id])]},design});
        state.sections.files=true;state.detailCollapsed=false;state.activeSection='files';render();saveView();
        notify(result.reused?'这本书已在知识库中':`已导入整本书，${result.chapters} 个章节文件`);
      }catch(error){if(error.name!=='AbortError')showError('导入书籍失败：'+error.message);}
      finally{importToken=null;setImportBusy(false);if(token.cancelled)notify('已取消导入书籍');}
    }
    function attachFiles(item,files){
      item=byID(item?.id);if(!item||!files?.length)return;let count=0;
      const canonical=f=>isWeb(f)?'url:'+f.path:(f.relative?'relative:':'absolute:')+f.path.replaceAll('\\','/').toLowerCase();
      for(const file of files){if(item.files.some(f=>canonical(f)===canonical(file)||file.sourcePath&&f.sourcePath===file.sourcePath))continue;item.files.push(file);count++;}
      if(!item.defaultFile)item.defaultFile=item.files[0]?.id;
      noteCache.delete(item.id);state.sections.files=true;state.activeSection='files';state.detailCollapsed=false;render();persist();notify('已添加 '+count+' 个附件');
      void syncMetadata();
    }
    function setImportBusy(busy){
      for(const element of qa('[data-library],.kb-top,.kb-footer,[data-library-error]'))element.inert=busy;
      q('[data-import-shade]').hidden=!busy;root.setAttribute('aria-busy',String(busy));
      const cancel=q('[data-do="cancel-import"]');cancel.disabled=false;
      if(busy)cancel.focus();else q('[data-select="'+state.selected+'"]')?.focus({preventScroll:true});
      if(!busy)queueDuplicateAlert();
    }
    function cancelImport(){
      if(!importToken||importToken.stage==='saving')return;
      importToken.cancelled=true;bridge.cancelScan();q('[data-import-progress]').textContent='正在取消…';
    }
    async function importPaths(paths){
      if(importToken)return;
      if(!base||loading||modal){notify('请先完成当前操作，再拖入文件。');return;}
      if(!paths.length){notify('请拖入本地 Markdown 文件或文件夹。');return;}
      const token=importToken={cancelled:false,stage:'scanning'},target=state.view.startsWith('collection:')?state.view.slice(11):null;
      let scanned=null,adopted=false;
      q('[data-menu]').hidden=true;q('[data-import-progress]').textContent='正在识别文件…';setImportBusy(true);
      try{
        if(!await flush()||token.cancelled)return;
        const existing=items.flatMap(i=>i.files.map(file=>({id:i.id,deleted:!!i.deleted,file:clone(file)})));
        const result=scanned=await bridge.scanDrop(paths,existing,text=>{q('[data-import-progress]').textContent=text;});
        if(token.cancelled)return;
        token.stage='saving';q('[data-do="cancel-import"]').disabled=true;q('[data-import-progress]').textContent='正在保存条目…';
        let added=0,books=0,reused=result.duplicates,classified=0,trashed=0,first=null;
        for(const entry of result.files){
          let item=entry.existingId?byID(entry.existingId):null;
          if(item?.deleted){reused++;trashed++;continue;}
          if(item){reused++;if(target&&collectionByID(target)&&!item.collections.includes(target)){item.collections.push(target);classified++;}}
          else{
            item=entry.kind==='book'?clone(entry.item):{id:newID(),type:'paper',title:entry.title||entry.file.name,author:'',year:'',summary:'',tags:[],status:'unread',star:false,related:[],files:[entry.file],defaultFile:entry.file.id,added:new Date().toISOString(),last:0};
            item.collections=target&&collectionByID(target)?[target]:[];
            if(entry.metadata)item=bridge.applyMetadata(item,entry.metadata);
            items.push(item);added++;if(entry.kind==='book')books++;
          }
          first ||= item.id;
        }
        if(first){state.view=target&&collectionByID(target)?'collection:'+target:'all';state.query='';clearItemFilters();state.selected=first;state.checked=[first];}
        adopted=true;if(first&&bookMode(byID(first))){state.sections.files=true;state.detailCollapsed=false;state.activeSection='files';}
        render();persist();const saved=await flush();
        const parts=[added?'已导入 '+added+' 个条目':'没有新增条目'];
        if(books)parts.push(books+' 本书已自动识别');
        if(reused)parts.push('重复 '+reused+' 个');if(classified)parts.push(classified+' 个已有条目已加入当前分类');if(trashed)parts.push(trashed+' 个文件已在回收站');
        if(!result.files.length)parts.push('未找到 Markdown 文件');if(result.warningCount)parts.push(result.warningCount+' 项未能读取');
        if(!saved)parts.push('修改尚未保存，请重试保存');
        notify(parts.join('；'));q('[data-message]').title=result.warnings.join('\n');
      }catch(error){if(error.name!=='AbortError')showError('导入失败：'+error.message);}
      finally{try{if(scanned&&!adopted)await bridge.discardDrop(scanned);}catch(error){showError('清理未完成的副本失败：'+error.message);}finally{importToken=null;setImportBusy(false);}if(token.cancelled)notify('已取消导入，条目未改变。');else await syncMetadata();}
    }
    let dragDepth=0;
    const fileDrag=event=>[...(event.dataTransfer?.types||[])].includes('Files')||!!event.dataTransfer?.files?.length;
    function resetDropHint(){dragDepth=0;q('[data-drop-hint]').hidden=true;}
    for(const name of ['dragenter','dragover'])window.addEventListener(name,event=>{
      if(!fileDrag(event))return;event.preventDefault();event.stopImmediatePropagation();
      const ready=!!base&&!loading&&!modal&&!importToken;event.dataTransfer.dropEffect=ready?'copy':'none';
      if(name==='dragenter')dragDepth++;q('[data-drop-hint]').hidden=!ready;
    },true);
    window.addEventListener('dragleave',event=>{if(fileDrag(event)){event.preventDefault();event.stopImmediatePropagation();if(--dragDepth<=0||!event.relatedTarget)resetDropHint();}},true);
    window.addEventListener('drop',event=>{
      if(!fileDrag(event))return;event.preventDefault();event.stopImmediatePropagation();resetDropHint();
      // Read native paths synchronously while the browser's drop data is available.
      try{const paths=bridge.droppedPaths([...event.dataTransfer.files]);void importPaths(paths);}catch(error){showError(error.message);}
    },true);
    window.addEventListener('blur',resetDropHint);
    function closeModal(){if(tagDeleting||purging)return;if(modal==='webpage'){if(webDraft?.busy)return;webDraft?.controller?.abort();webDraft=null;q('[data-form]').classList.remove('is-web-dialog');}tagRemoval=null;finishFloatingDialogDrag();floatingDialog=null;const form=q('[data-form]');if(form.elements.namedItem('secretKey')){form.elements.namedItem('secretKey').value='';form.elements.namedItem('secretKey').setAttribute('value','');}for(const key of ['width','height','left','top'])form.style.removeProperty(key);delete form.dataset.metricCompact;q('[data-shade]').hidden=true;form.classList.remove('is-metric-column','is-url-dialog','is-relation','is-type-change','is-compact-confirm','is-duplicate-dialog');form.removeAttribute('aria-describedby');if(form.elements.namedItem('semanticKey')){form.elements.namedItem('semanticKey').value='';form.elements.namedItem('semanticKey').setAttribute('value','');}attachmentDraft=null;noteRemoval=null;modal=null;summarySourceDraft=null;relationDraft=null;itemDraft=null;editingItemId=null;purgeDraft=null;typeChangeDraft=null;const focus=previousFocus?.isConnected?previousFocus:q('[data-do="new"]');focus?.focus({preventScroll:true});queueDuplicateAlert();}
    // The same schema drives editable type fields and the information pane.
    const itemSchemas={
      paper:{title:'标题',author:'作者',year:'日期',fields:[['publicationTitle','刊名'],['date','日期'],['volume','卷'],['issue','期'],['pages','页码'],['doi','DOI'],['url','网址']]},
      thesis:{title:'标题',author:'作者',year:'日期',fields:[['contributor','贡献者'],['thesisType','论文类型'],['university','大学'],['date','日期'],['numPages','总页数'],['doi','DOI']]},
      book:{title:'标题',author:'作者',year:'日期',fields:[['date','日期'],['publisher','出版社'],['isbn','ISBN']]},
      note:{title:'标题',author:'作者',year:'年份',fields:[]}
    };
    const commonInfoFields=[['url','网址'],['place','地点'],['language','语言'],['libraryCatalog','文库编目'],['accessDate','访问时间'],['shortTitle','短标题'],['archive','档案'],['archiveLocation','档案编号'],['callNumber','索书号'],['rights','版权'],['extra','其他'],['issn','ISSN']];
    const optionalInfoFields={
      paper:[['publisher','出版社'],['contributor','贡献者'],['editor','编辑'],['translator','译者'],['journalAbbreviation','期刊简称'],['series','系列'],['seriesTitle','系列标题'],['seriesText','系列文本'],['section','章节'],['partNumber','部分编号'],['partTitle','部分标题'],['pmid','PMID'],['pmcid','PMCID'],...commonInfoFields],
      thesis:[['series','系列'],['seriesNumber','系列编号'],['isbn','ISBN'],...commonInfoFields],
      book:[['contributor','贡献者'],['editor','编辑'],['translator','译者'],['seriesEditor','丛书编辑'],['series','系列'],['seriesNumber','系列编号'],['volume','卷次'],['numberOfVolumes','总卷数'],['edition','版/版次'],['originalDate','原出版日期'],['originalPublisher','原出版社'],['originalPlace','原出版地'],['format','格式'],['numPages','总页数'],['doi','DOI'],...commonInfoFields]
    };
    let infoEditor=null,infoSearchPending=false,newTypeMenu=false;
    const addedInfoFields=new Map(),isbnStates=new Map(),infoTouches=new Map();
    const resourceURLs=item=>[...new Set((Array.isArray(item.resourceUrls)?item.resourceUrls:[...(item.codeUrls||[]),...(item.dataUrls||[])]).filter(v=>typeof v==='string').map(v=>v.trim()).filter(Boolean))];
    const infoValue=(item,key)=>key==='resourceUrls'?resourceURLs(item).join('\n'):key==='title'?itemTitle(item):key==='date'?String(item.date??item.year??''):Array.isArray(item[key])?item[key].join('；'):String(item[key]??'');
    function infoDefinitions(item){
      const schema=itemSchemas[item.type]||itemSchemas.note;
      const entries=[['title',schema.title],['author','作者'],...schema.fields,...(optionalInfoFields[item.type]||[])];
      if(item.type==='note')entries.push(['date','日期'],['language','语言']);
      // Preserve previously imported paper-specific metadata, without introducing it on books/theses.
      const extra=[['titleZh','中文标题'],['articleNumber','文章号'],['affiliations','作者单位'],['keywords','关键词'],['resourceUrls','资源链接']];
      entries.push(...extra.filter(([key])=>(infoValue(item,key)||key==='resourceUrls')&&(item.type==='paper'||['titleZh','keywords'].includes(key))));
      return entries.filter(([key],at)=>entries.findIndex(e=>e[0]===key)===at);
    }
    function infoFieldButton(item,key,label){
      const value=infoValue(item,key),display=['author','contributor','editor','translator','seriesEditor'].includes(key)?value.replace(/[；;]/g,'\n'):value;
      if(key==='resourceUrls'&&value)return `<div class="kb-resource-list">${resourceURLs(item).map(url=>/^https?:\/\/\S+$/i.test(url)?`<button type="button" class="kb-resource-link" data-resource-url="${escape(url)}" title="${escape(url)}">${escape(url)}</button>`:`<span>${escape(url)}</span>`).join('')}<button type="button" class="kb-resource-edit" data-info-edit="resourceUrls" aria-label="编辑资源链接" ${item.deleted?'disabled':''}>编辑</button></div>`;
      const association=['author','affiliations'].includes(key)?bridge.authorAssociation(item):null;
      if(association&&key==='author')return `<div class="kb-author-list">${association.authors.map(author=>`<div class="kb-author-entry"><button type="button" class="kb-info-value" data-info-edit="author" aria-label="编辑作者" ${item.deleted?'disabled':''}>${escape(author.name)}</button>${author.markers.length?`<sup>${author.markers.map(marker=>{const unit=association.affiliations.find(a=>a.label===marker);return unit?`<button type="button" class="kb-author-marker" data-author-affiliation="${escape(marker)}" title="${escape(unit.text)}" aria-label="查看作者单位 ${escape(marker)}：${escape(unit.text)}">${escape(marker)}</button>`:`<span title="原文作者标记 ${escape(marker)}">${escape(marker)}</span>`;}).join(',')}</sup>`:''}</div>`).join('')}</div>`;
      if(association&&key==='affiliations')return association.affiliations.map(unit=>`<button type="button" class="kb-info-value kb-affiliation-value" data-info-edit="affiliations" data-affiliation-label="${escape(unit.label)}" aria-label="编辑作者单位" ${item.deleted?'disabled':''}><sup>${escape(unit.label)}</sup> ${escape(unit.text)}</button>`).join('');
      return `<button type="button" class="kb-info-value ${value?'':'is-empty'}" data-info-edit="${key}" aria-label="编辑${label}" ${item.deleted?'disabled':''}>${escape(key==='resourceUrls'&&!value?'未记录链接':display)}</button>`;
    }
    function revealAuthorAffiliation(label){
      const target=qa('[data-affiliation-label]').find(el=>el.dataset.affiliationLabel===label);if(!target)return;
      target.scrollIntoView({block:'nearest',behavior:'smooth'});target.focus({preventScroll:true});
      qa('.kb-affiliation-focus').forEach(el=>el.classList.remove('kb-affiliation-focus'));target.classList.add('kb-affiliation-focus');
      setTimeout(()=>target.classList.remove('kb-affiliation-focus'),1800);
    }
    function infoFieldGroups(item){
      const core=new Set(['title','author','language',...(itemSchemas[item.type]||itemSchemas.note).fields.map(f=>f[0])]),added=addedInfoFields.get(item.id)||new Set();
      const definitions=infoDefinitions(item),shown=definitions.filter(([key])=>core.has(key)||key==='resourceUrls'||added.has(key)||infoValue(item,key));
      return {shown,hidden:definitions.filter(([key])=>!shown.some(f=>f[0]===key))};
    }
    function itemInfoMarkup(item){
      const {shown}=infoFieldGroups(item);
      return `<dl class="kb-info-fields"><dt>条目类型</dt><dd><button type="button" class="kb-info-value" data-info-edit="type" aria-label="修改条目类型" ${item.deleted?'disabled':''}>${typeNames[item.type]}${icon('chevron-down')}</button></dd>${shown.map(([key,label])=>`<dt>${label}</dt><dd data-info-cell="${key}">${infoFieldButton(item,key,label)}</dd>`).join('')}<dt>添加日期</dt><dd class="kb-info-date" data-item-date="added">${escape(fullDate(item.added))}</dd><dt>修改日期</dt><dd class="kb-info-date" data-item-date="modified">${escape(fullDate(item.modified))}</dd></dl>`;
    }
    function itemInfoActions(item){
      if(item.deleted)return '';
      const {hidden}=infoFieldGroups(item),lookup=isbnStates.get(item.id);
      const add=hidden.length?`<select data-info-add aria-label="添加字段"><option value="">＋ 添加字段</option>${hidden.map(([key,label])=>`<option value="${key}">${label}</option>`).join('')}</select>`:'';
      const refresh=metricsEligible(item)?'<button type="button" class="kb-outline" data-metrics-refresh="selected">更新文献指标</button>':'';
      const isbn=item.type==='book'?`<button type="button" data-isbn-lookup ${lookup?.busy?'disabled':''}>${lookup?.busy?'正在识别…':'识别 ISBN'}</button>`:'';
      const action=refresh+isbn;
      return (add||action?`<div class="kb-info-actions">${add}${action}</div>`:'')+(item.type==='book'?`<p class="kb-isbn-status ${lookup?.error?'is-error':''}" data-isbn-status role="status">${escape(lookup?.message||'')}</p>`:'');
    }
    function touchInfo(item,values){
      Object.assign(item,bridge.markMetadataEdited(clone(item),values),values);
      for(const key of Object.keys(values))infoTouches.set(item.id+':'+key,(infoTouches.get(item.id+':'+key)||0)+1);
      infoSearchPending=true;detailSignature='';q('[data-save-status]').textContent='尚未保存';
    }
    function typeChangeLosses(item,type){
      // Include fields hidden by an earlier type change, but never attachment/note/graph data.
      const definitions=new Map(editableTypes.flatMap(type=>infoDefinitions({...item,type})).concat(infoDefinitions(item),[['conference','会议名称'],['articleType','文章类型']]));
      const supported=new Set(supportedTypeFields(type));
      const filled=value=>Array.isArray(value)?value.some(filled):String(value??'').trim()!=='';
      return [...definitions].filter(([key])=>!supported.has(key)&&filled(item[key]));
    }
    function supportedTypeFields(type){
      return ['title','author','date','language',...(itemSchemas[type]?.fields||[]).map(([key])=>key),...(optionalInfoFields[type]||[]).map(([key])=>key),'titleZh','keywords',...(type==='paper'?['articleNumber','affiliations','codeUrls','dataUrls','resourceUrls','conference','articleType']:[])];
    }
    function applyItemType(item,type,losses){
      const next=bridge.changeItemType(clone(item),type,losses.map(([key])=>key),supportedTypeFields(type),supportedTypeFields(item.type));
      const values={type};for(const [key]of losses)values[key]=Array.isArray(item[key])?[]:'';
      touchInfo(item,values);Object.assign(item,next);
      addedInfoFields.delete(item.id);isbnStates.delete(item.id);
      typeMetadataPending.set(item.id,++typeMetadataRequest);queueMicrotask(resumeTypeMetadata);
    }
    function showTypeChange(item,type,losses){
      typeChangeDraft={id:item.id,from:item.type,to:type,losses,generation:libraryGeneration};
      modal='change-type';previousFocus=q('[data-info-edit="type"]');
      const form=q('[data-form]');form.classList.add('is-type-change');
      form.innerHTML=`<header><h3 id="kb-modal-title">更改条目类型</h3><button type="button" data-do="cancel" aria-label="关闭">${icon('x')}</button></header><p>您确定要将“${typeNames[item.type]}”更改为“${typeNames[type]}”吗？</p><p id="kb-type-loss-label">下列字段将丢失：</p><ul class="kb-type-losses" aria-labelledby="kb-type-loss-label">${losses.map(([key,label])=>`<li data-type-loss="${key}">${escape(label)}</li>`).join('')}</ul><footer><button type="button" class="kb-outline" data-do="cancel">取消</button><button type="button" class="kb-primary" data-do="confirm">更改类型</button></footer>`;
      q('[data-shade]').hidden=false;updateIcons();form.querySelector('footer [data-do="cancel"]').focus();
    }
    function requestItemType(item,type){
      if(!editableTypes.includes(type)||type===item.type)return;
      const losses=typeChangeLosses(item,type);
      if(losses.length)showTypeChange(item,type,losses);else applyItemType(item,type,losses);
    }
    function commitTypeChange(){
      const draft=typeChangeDraft,item=byID(draft?.id);
      if(!draft||draft.generation!==libraryGeneration||!item||item.deleted||item.type!==draft.from){closeModal();return;}
      const losses=typeChangeLosses(item,draft.to);
      // An in-flight metadata lookup may have filled another field while the dialog was open.
      if(losses.some(([key])=>!draft.losses.some(([old])=>old===key))){showTypeChange(item,draft.to,losses);return;}
      applyItemType(item,draft.to,losses);closeModal();refreshInfoSearch();persist();q('[data-info-edit="type"]')?.focus();
    }
    function commitInfoEdit(cancel=false){
      const draft=infoEditor;if(!draft)return true;if(draft.composing&&!cancel)return false;
      draft.resizeObserver?.disconnect();infoEditor=null;const item=byID(draft.id);if(!item)return true;
      const value=draft.input.value.trim();
      const changed=!cancel&&value!==draft.original;
      if(changed&&draft.key==='type'){
        if(draft.cell.isConnected)draft.cell.innerHTML=`<button type="button" class="kb-info-value" data-info-edit="type" aria-label="修改条目类型">${typeNames[item.type]}${icon('chevron-down')}</button>`;
        updateIcons();requestItemType(item,value);return true;
      }
      if(changed){
        const values={[draft.key]:value};
        if(draft.key==='date')values.year=value.match(/\b\d{4}\b/)?.[0]||'';
        if(['affiliations','keywords','codeUrls','dataUrls'].includes(draft.key))values[draft.key]=value.split(/[；;\n]/).map(v=>v.trim()).filter(Boolean);
        if(draft.key==='resourceUrls')values[draft.key]=[...new Set(value.split(/[；\n]/).map(v=>v.trim()).filter(Boolean))];
        touchInfo(item,values);
        if(draft.key==='title')item.xrefMetadata.locked=[...new Set([...item.xrefMetadata.locked,'title'])];
      }
      if(draft.cell.isConnected)draft.cell.innerHTML=draft.key==='type'?`<button type="button" class="kb-info-value" data-info-edit="type" aria-label="修改条目类型">${typeNames[item.type]}${icon('chevron-down')}</button>`:infoFieldButton(item,draft.key,draft.label);
      if(changed&&['author','affiliations'].includes(draft.key)){
        const other=draft.key==='author'?'affiliations':'author',cell=q('[data-info-cell="'+other+'"]');
        if(cell)cell.innerHTML=infoFieldButton(item,other,other==='author'?'作者':'作者单位');
      }
      updateIcons();
      if(changed&&draft.key==='isbn'&&item.type==='book'&&value)queueMicrotask(()=>void lookupBookISBN(item.id));
      return true;
    }
    function beginInfoEdit(key='title'){
      const item=selected();if(!item||item.deleted||selectionIDs().length>1||infoEditor?.composing||tagEditor?.composing||summaryEditor?.composing)return;
      if(infoEditor?.id===item.id&&infoEditor.key===key){infoEditor.input.focus();return;}
      commitInfoEdit();if(modal)return;commitTagEdit();commitSummaryEdit();state.sections.info=true;state.detailCollapsed=false;
      const def=infoDefinitions(item).find(d=>d[0]===key);if(key!=='type'&&!def)return;
      if(key!=='type'){if(!addedInfoFields.has(item.id))addedInfoFields.set(item.id,new Set());addedInfoFields.get(item.id).add(key);}
      renderDetail();updateIcons();
      const button=q('[data-info-edit="'+key+'"]');if(!button)return;const cell=button.closest('[data-info-cell]')||button.parentElement,label=def?.[1]||'条目类型';
      const multiline=['title','author','contributor','editor','translator','seriesEditor','extra','affiliations','resourceUrls'].includes(key);
      const input=document.createElement(key==='type'?'select':multiline?'textarea':'input');
      input.className='kb-info-input';input.dataset.infoInput=key;input.setAttribute('aria-label',label);input.maxLength=key==='extra'?30000:key==='url'?4000:2000;
      if(key==='type')input.innerHTML=itemTypeOptions(item);else if(multiline)input.rows=1;
      input.value=key==='type'?item.type:infoValue(item,key);const original=input.value;
      if(['author','contributor','editor','translator','seriesEditor'].includes(key))input.title='多人用分号分隔';
      if(key==='isbn')input.title='填写 ISBN 后自动补全空白信息';
      if(key==='resourceUrls')input.title='每行一个链接；Enter 保存，Shift+Enter 换行';
      infoEditor={id:item.id,key,label,input,cell,original,composing:false,pendingBlur:false};cell.replaceChildren(input);
      if(multiline){
        const fit=()=>{if(!input.isConnected)return;input.style.height='28px';input.style.height=Math.min(240,Math.max(28,input.scrollHeight+2))+'px';};
        input.addEventListener('input',fit);fit();
        let width=cell.clientWidth;
        const observer=new ResizeObserver(()=>{if(cell.clientWidth!==width){width=cell.clientWidth;fit();}});
        observer.observe(cell);infoEditor.resizeObserver=observer;
      }
      input.scrollIntoView({block:'nearest'});input.focus({preventScroll:true});input.select?.();
      input.addEventListener('compositionstart',()=>{if(infoEditor?.input===input)infoEditor.composing=true;});
      input.addEventListener('compositionend',()=>{if(infoEditor?.input!==input)return;infoEditor.composing=false;if(infoEditor.pendingBlur)queueMicrotask(()=>{if(infoEditor?.input===input){commitInfoEdit();refreshInfoSearch();persist();}});});
      input.addEventListener('keydown',event=>{
        if(event.isComposing||event.keyCode===229||infoEditor?.composing){if(['Enter','Escape'].includes(event.key))event.stopPropagation();return;}
        if(event.key==='Escape'){event.preventDefault();event.stopPropagation();commitInfoEdit(true);q('[data-info-edit="'+key+'"]')?.focus();refreshInfoSearch();return;}
        if(event.key==='Enter'&&key!=='type'&&!(key==='resourceUrls'&&event.shiftKey)&&!(key==='extra'&&!(event.ctrlKey||event.metaKey))){event.preventDefault();event.stopPropagation();commitInfoEdit();refreshInfoSearch();persist();q('[data-info-edit="'+key+'"]')?.focus();return;}
        if(event.key==='Tab'){event.preventDefault();event.stopPropagation();const keys=[...new Set(qa('[data-info-edit],[data-info-input]').map(b=>b.dataset.infoEdit||b.dataset.infoInput))],at=keys.indexOf(key);const target=event.shiftKey?keys[at-1]:keys[at+1];commitInfoEdit();refreshInfoSearch();persist();if(modal)return;if(target)beginInfoEdit(target);else q('[data-info-add]')?.focus();}
      });
      if(key==='type')input.addEventListener('change',()=>{commitInfoEdit();refreshInfoSearch();persist();if(!modal)q('[data-info-edit="type"]')?.focus();});
      input.addEventListener('blur',()=>{if(infoEditor?.input!==input||!document.hasFocus())return;if(infoEditor.composing){infoEditor.pendingBlur=true;return;}commitInfoEdit();persist();});
      persist();
    }
    function refreshInfoSearch(){
      if(!infoSearchPending||infoEditor)return;infoSearchPending=false;
      pickVisible();renderNav();renderList();renderDetail();updateIcons();saveView();
    }
    async function lookupBookISBN(id=state.selected){
      const item=byID(id);if(!item||item.deleted||item.type!=='book')return;
      if(isbnStates.get(id)?.busy){isbnStates.get(id).pending=true;return;}
      if(infoEditor?.id===id&&infoEditor.key==='isbn'&&!commitInfoEdit())return;
      const isbn=bridge.normalizeISBN(item.isbn),generation=libraryGeneration,initial=clone(item),touches=new Map(infoTouches);
      if(!isbn){isbnStates.set(id,{error:true,message:'请输入正确的 ISBN（10 或 13 位，支持连字符）。'});renderDetail();updateIcons();return;}
      isbnStates.set(id,{busy:true,isbn,message:'正在按 ISBN 查询书目…'});renderDetail();updateIcons();
      try{
        const result=await bridge.lookupISBN(isbn),current=byID(id);
        if(generation!==libraryGeneration||!current||current.deleted||current.type!=='book'||bridge.normalizeISBN(current.isbn)!==isbn)return;
        const allowed=new Set([...infoDefinitions(current).map(d=>d[0]),'summary']);const values={};
        for(const [key,value]of Object.entries(result.fields||{})){
          if(!allowed.has(key)||!value||infoEditor?.id===id&&infoEditor.key===key||key==='summary'&&summaryEditor?.id===id)continue;
          if((touches.get(id+':'+key)||0)!==(infoTouches.get(id+':'+key)||0))continue;
          if(!infoValue(initial,key)&&!infoValue(current,key))values[key]=value;
        }
        if(values.date)values.year=String(values.date).match(/\b\d{4}\b/)?.[0]||'';
        if(Object.keys(values).length){touchInfo(current,values);current.isbnMetadata={isbn,source:result.source,url:result.url,checkedAt:new Date().toISOString()};}
        isbnStates.set(id,{message:`${Object.keys(values).length?'已补全':'已核对'} · ${result.source}，已有填写内容保留`});persist();
      }catch(error){if(generation===libraryGeneration&&byID(id)?.isbn===initial.isbn)isbnStates.set(id,{error:true,message:error.message});}
      finally{if(generation===libraryGeneration){const status=isbnStates.get(id),again=status?.pending&&byID(id)?.type==='book'&&bridge.normalizeISBN(byID(id)?.isbn)!==isbn;if(status?.busy)isbnStates.delete(id);refreshInfoSearch();renderDetail();updateIcons();if(again)queueMicrotask(()=>void lookupBookISBN(id));}}
    }
    let libraryMenu=false;
    function showLibraryMenu(button){
      if(!base||loading||importToken)return;closeCollectionMenu();newTypeMenu=false;libraryMenu=true;
      const menu=q('[data-menu]'),r=button.getBoundingClientRect();menu.classList.add('is-collection');menu.setAttribute('aria-label','我的文库');menu.setAttribute('role','menu');
      menu.innerHTML='<button type="button" role="menuitem" data-do="drive-backup">'+icon('upload')+'<span>Google Drive 备份…</span></button><button type="button" role="menuitem" data-do="export-library">'+icon('folder')+'<span>导出知识库…</span></button><button type="button" role="menuitem" data-do="import-library">'+icon('folder-open')+'<span>导入…</span></button>';
      button.setAttribute('aria-expanded','true');menu.hidden=false;updateIcons();positionCollectionMenu(r.left,r.bottom);menu.querySelector('button').focus();
    }
    root.addEventListener('keydown',event=>{
      if(!libraryMenu||q('[data-menu]').hidden||!event.target.closest('[data-menu]'))return;
      if(!['ArrowUp','ArrowDown','Home','End','Escape','Tab'].includes(event.key))return;
      event.preventDefault();event.stopImmediatePropagation();
      if(['Escape','Tab'].includes(event.key)){closeCollectionMenu();q('[data-do="library-menu"]').focus();return;}
      const buttons=qa('[data-menu] button'),at=buttons.indexOf(document.activeElement),next=event.key==='Home'?0:event.key==='End'?buttons.length-1:(at+(event.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length;buttons[next].focus();
    },true);
    async function transferLibrary(exporting){
      if(importToken||!base||loading||modal)return;
      closeCollectionMenu();if(!await flush())return;
      const token=importToken={cancelled:false,stage:'choosing'};setImportBusy(true);q('[data-import-progress]').textContent=exporting?'请选择导出文件夹…':'请选择知识库导出包…';
      try{
        const file=await bridge.chooseLibraryArchive(exporting);if(!file||token.cancelled)return;
        const result=await bridge.transferLibrary(exporting,file,(text,phase)=>{q('[data-import-progress]').textContent=text;token.stage=phase;q('[data-do="cancel-import"]').disabled=phase==='saving';});
        if(exporting)notify('已导出 '+result.items+' 个条目：'+result.path);
        else{importToken=null;loadLibrary(result.data,{state:{...state,view:'all',selected:result.id||state.selected,checked:result.id?[result.id]:[],query:'',tags:[],expanded:result.id?[result.id]:[]},design});saveView();notify(result.added?'已导入 '+result.added+' 个条目'+(result.reused?'，已存在 '+result.reused+' 个':''):'这个导出包的条目已在文库中');}
      }catch(error){if(error.name!=='AbortError')showError((exporting?'导出':'导入')+'知识库失败：'+error.message);else notify('已取消'+(exporting?'导出':'导入'));}
      finally{if(importToken===token)importToken=null;setImportBusy(false);q('[data-do="library-menu"]')?.focus({preventScroll:true});}
    }
    function showNewTypeMenu(button=q('[data-do="new"]')){
      if(!base||loading)return;closeCollectionMenu();const menu=q('[data-menu]'),r=button.getBoundingClientRect();newTypeMenu=true;
      menu.classList.add('is-collection');menu.setAttribute('aria-label','新增条目类型');menu.setAttribute('role','menu');
      menu.innerHTML=[...editableTypes,'webpage'].map(type=>`<button type="button" role="menuitem" data-new-type="${type}">${icon(typeIcons[type])}<span>${typeNames[type]}</span></button>`).join('')+`<div class="kb-menu-divider"></div><button type="button" role="menuitem" data-do="import-book">${icon('folder-open')}<span>导入整本 Markdown 书籍…</span></button>`;
      menu.hidden=false;updateIcons();positionCollectionMenu(r.left,r.bottom);menu.querySelector('button').focus();
    }
    function createEmptyItem(type){
      if(type==='webpage'){run(()=>openWebDialog());return;}
      if(!editableTypes.includes(type)||!base||infoEditor?.composing||tagEditor?.composing||summaryEditor?.composing)return;
      commitInfoEdit();commitTagEdit();commitSummaryEdit();q('[data-menu]').hidden=true;newTypeMenu=false;
      const category=state.view.startsWith('collection:')?state.view.slice(11):null;
      const item={id:newID(),type,title:'',author:'',year:'',summary:'',tags:[],files:[],notes:[],related:[],collections:category&&collectionByID(category)?[category]:[],status:'unread',star:false,added:new Date().toISOString(),last:0};
      items.unshift(item);if(!category)state.view='all';state.query='';clearItemFilters();state.checked=[item.id];state.selected=item.id;selectionAnchor=item.id;
      state.detailCollapsed=false;state.sections.info=true;state.activeSection='info';state.pinnedPane=null;render();persist();beginInfoEdit('title');notify('已新建'+typeNames[type]+'，在右侧填写信息');
    }
    root.addEventListener('keydown',event=>{
      if(!newTypeMenu||q('[data-menu]').hidden||!event.target.closest('[data-new-type],[data-do="import-book"]'))return;
      if(!['ArrowUp','ArrowDown','Home','End','Escape','Tab'].includes(event.key))return;
      event.preventDefault();event.stopImmediatePropagation();
      if(['Escape','Tab'].includes(event.key)){q('[data-menu]').hidden=true;newTypeMenu=false;q('[data-do="new"]').focus();return;}
      const buttons=qa('[data-new-type],[data-do="import-book"]'),at=buttons.indexOf(document.activeElement),next=event.key==='Home'?0:event.key==='End'?buttons.length-1:(at+(event.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length;buttons[next].focus();
    },true);
    root.addEventListener('click',refreshInfoSearch);root.addEventListener('keyup',refreshInfoSearch);
    root.addEventListener('click',()=>queueMicrotask(resumeTypeMetadata));root.addEventListener('keyup',()=>queueMicrotask(resumeTypeMetadata));
    function typedFields(item){const schema=itemSchemas[item.type]||itemSchemas.note;return schema.fields.map(([key,label])=>`<label>${label}<input name="${key}" maxlength="${key==='url'?4000:1000}" value="${escape(item[key]||'')}" autocomplete="off"></label>`).join('');}
    function itemTypeOptions(item){
      // Preserve a legacy item's type until the user deliberately changes it.
      const legacy=editableTypes.includes(item.type)?'':`<option value="${escape(item.type)}" selected hidden>原条目类型</option>`;
      return legacy+editableTypes.map(type=>`<option value="${type}" ${item.type===type?'selected':''}>${typeNames[type]}</option>`).join('');
    }
    function itemForm(item){const schema=itemSchemas[item.type]||itemSchemas.note;return `<div class="kb-two"><label>条目类型<select name="type">${itemTypeOptions(item)}</select></label><label><span data-item-year-label>${schema.year}</span><input name="year" inputmode="numeric" pattern="[0-9]{4}" maxlength="4" value="${escape(item.year)}" placeholder="可留空"></label></div><label><span data-item-title-label>${schema.title}</span><input name="title" required maxlength="1000" value="${escape(item.title)}" placeholder="${schema.title}"></label><label><span data-item-author-label>${schema.author}</span><input name="author" maxlength="2000" value="${escape(item.author)}" placeholder="${schema.author}"></label><div class="kb-item-fields" data-item-fields>${typedFields(item)}</div><label>标签<input name="tags" maxlength="2000" value="${escape(item.tags.join('，'))}" placeholder="用逗号分隔"></label>`;}
    function captureTypedFields(){if(!itemDraft)return;for(const input of qa('[data-item-fields] input[name]')){const value=input.value.trim();if(value!==String(itemDraft.values[input.name]||'')){itemDraft.values[input.name]=value;itemDraft.changed.add(input.name);}}}
    function renderTypedFields(){
      const item=itemDraft.values,schema=itemSchemas[item.type]||itemSchemas.note;
      q('[data-item-fields]').innerHTML=typedFields(item);q('[data-item-title-label]').textContent=schema.title;q('[name=title]').placeholder=schema.title;q('[data-item-author-label]').textContent=schema.author;q('[name=author]').placeholder=schema.author;q('[data-item-year-label]').textContent=schema.year;
    }

    function showModal(kind){if(kind==='new'){showNewTypeMenu();return;}if(kind==='edit'){beginInfoEdit();return;}if(kind==='summary'){beginSummaryEdit();return;}if(kind==='file'){showAttachmentPicker();return;}if(kind==='collection'){showCollectionDialog('new',state.view.startsWith('collection:')?state.view.slice(11):null);return;}modal=kind;previousFocus=document.activeElement;const i=selected(),isNew=kind==='new';let title='',body='';
      if(kind==='new'||kind==='edit'){
        const item=isNew?{title:'',type:'paper',author:'',year:'',tags:[],url:''}:i;if(!item)return;
        editingItemId=isNew?null:item.id;itemDraft={values:clone(item),changed:new Set()};title=isNew?'新增条目':'编辑条目';body=itemForm(item);
      }
      else if(kind==='summary'){if(!i)return;editingItemId=i.id;title=i.type==='book'?'编辑简介':'编辑摘要';body=`<label>${i.type==='book'?'简介':'摘要'}<textarea name="summary" rows="7" maxlength="30000">${escape(i.summary||'')}</textarea></label>`;}
      else if(kind==='collections'){if(!i)return;editingItemId=i.id;title='管理分类';body=collections.length?`<div class="kb-memberships">${orderedCollections().map(c=>`<label class="kb-check-label"><input type="checkbox" name="collections" value="${escape(c.id)}" ${i.collections.includes(c.id)?'checked':''}>${escape(collectionPath(c.id))}</label>`).join('')}</div>`:'<p class="kb-muted">还没有分类。请先在左侧创建分类。</p>';}
      else if(kind==='related'){if(!i)return;title='选择相关条目';body=relatedPickerMarkup(i);}
      else return;
      q('[data-form]').classList.toggle('is-relation',kind==='related');
      q('[data-form]').innerHTML=`<header ${kind==='related'?'data-dialog-move':''}><h3 id="kb-modal-title">${title}</h3><button type="button" class="cursor-interaction" data-do="cancel" aria-label="关闭对话框">${icon('x')}</button></header>${body}<footer>${kind==='related'?'<span class="kb-relation-owner" data-relation-count aria-live="polite"></span>':''}<button type="button" class="kb-outline cursor-interaction" data-do="cancel">取消</button><button type="button" data-do="confirm" class="kb-primary cursor-interaction">${isNew?'创建条目':kind==='related'?'选择':'保存'}</button></footer>${kind==='related'?floatingDialogHandles():''}`;q('[data-shade]').hidden=false;if(kind==='related'){renderRelationTree();renderRelationResults();}updateIcons();if(kind==='related')openFloatingDialogLayout('related');(q('[data-form] input[name=title]')||q('[data-form] input:not([type=checkbox])'))?.focus();}
    function showPurgeDialog(ids){
      const targets=[...new Set(ids)].map(byID).filter(item=>item?.deleted);if(!targets.length)return;
      modal='purge';purgeDraft=targets.map(item=>item.id);previousFocus=document.activeElement;q('[data-menu]').hidden=true;
      showCompactConfirmation('删除','您确定要删除所选的条目吗？',{focus:'confirm'});
    }
    async function commitPurge(){
      const ids=(purgeDraft||[]).filter(id=>byID(id)?.deleted);if(!ids.length){closeModal();return;}
      await performPurge({itemIds:ids});
    }
    async function performPurge(request){
      if(purging)return;
      purging=true;
      try{
        if(!await flush())return;
        q('[data-purge-error]')?.remove();
        if(floatingDialog?.column==='confirm')applyFloatingDialogRect(floatingDialog.rect);
        loading=true;libraryGeneration++;q('[data-library]').inert=true;
        for(const b of qa('[data-form] button'))b.disabled=true;
        q('[data-save-status]').textContent='正在删除文件…';
        const result=await bridge.purge(clone(base),request);
        purging=false;closeModal();collectionDialog=null;
        loadLibrary(result.data,{state,design});saveView();
        notify('已永久删除 '+result.removed+' 个条目及对应文库文件'+(result.shared?'；共用文件已保留':'')+(result.external?'；知识库外原文件已保留':''));
        if(result.warning)showError(result.warning);
      }catch(error){
        const message=document.createElement('p');message.dataset.purgeError='';message.setAttribute('role','alert');message.className='kb-collection-confirm';message.style.color='var(--kb-danger,#b24435)';message.textContent=error.message;
        q('[data-form] footer').before(message);
        if(floatingDialog?.column==='confirm')applyFloatingDialogRect(floatingDialog.rect);
        throw error;
      }finally{
        purging=false;loading=false;q('[data-library]').inert=false;
        for(const b of qa('[data-form] button'))b.disabled=false;
        q('[data-save-status]').textContent=saveError?'尚未保存':'已保存';
      }
    }
    function attachmentButton(action,label,symbol,child=false,disabled=false){return `<button type="button" data-attachment-action="${action}" ${child?'aria-haspopup="true" aria-expanded="false"':''} ${disabled?'disabled':''}>${icon(symbol)}<span>${label}</span>${child?icon('chevron-right'):''}</button>`;}
    function contextMenu(id,x,y,fileID=null){
      closeCollectionMenu();const item=byID(id);if(!item)return;
      if(fileID||!selectionIDs().includes(id)){state.checked=[id];selectionAnchor=id;}state.selected=id;render();
      const multi=selectionIDs().length>1,menu=q('[data-menu]'),file=item.files.find(f=>f.id===fileID),preferred=file||item.files.find(f=>f.id===item.defaultFile)||item.files[0];
      attachmentMenu={owner:id,file:file?.id,ids:[...selectionIDs()],branch:null};menu.classList.add('is-collection');menu.setAttribute('aria-label',file?'附件操作':'条目操作');
      const b=attachmentButton,md=canNote(file)?file:item.files.find(canNote),inCollection=state.view.startsWith('collection:')&&selectionIDs().every(key=>byID(key)?.collections.includes(state.view.slice(11))),removeButtons=removalActions().map(([action,label,symbol])=>`<button type="button" data-context="${action}">${icon(symbol)}<span>${label}</span></button>`).join('');
      const common=b('attach','添加附件','paperclip',true)+b('classify','添加到分类','folder-plus',true)+(inCollection?b('remove-collection','从分类中移除条目…','folder-minus'):'');
      const content=item.deleted?`<button type="button" data-context="restore">${icon('undo-2')}恢复条目</button><button type="button" data-context="purge">${icon('trash-2')}永久删除…</button>`:
        (multi?'':b('open',isWeb(file)?'打开网页':'打开阅读',isWeb(file)?'globe':'book-open',false,!preferred)+(preferred&&!isWeb(preferred)?b('folder','打开文件目录','folder-open'):'')+'<hr>'+b('note','添加笔记','notebook-pen',false,!md))+
        common+'<hr>'+(file?b('remove-file','删除附件…','trash-2'):`<button type="button" data-context="star">${icon('star')}<span>${!multi&&item.star?'取消收藏':'收藏'}</span></button><button type="button" data-context="done">${icon('check')}<span>标为已读</span></button>${selectionIDs().some(id=>metricsEligible(byID(id)))?`<button type="button" data-metrics-refresh="selected">${icon('history')}<span>更新文献指标</span></button>`:''}${removeButtons}`);
      menu.innerHTML=`<div data-attachment-actions>${content}</div><div class="kb-destination-menu" data-attachment-submenu hidden></div>`;
      if(selectionIDs().some(key=>byID(key)?.type==='webpage')&&!item.deleted&&!fileID){
        const actions=menu.querySelector('[data-attachment-actions]');
        for(const b of actions.querySelectorAll('[data-context="done"],[data-attachment-action="attach"],[data-attachment-action="note"],[data-attachment-action="folder"],[data-attachment-action="open"]'))b.remove();
        if(!multi)actions.insertAdjacentHTML('afterbegin','<button type="button" data-web-action="open" data-web-id="'+id+'">'+icon('globe')+'打开原网页</button><button type="button" data-web-action="edit" data-web-id="'+id+'">'+icon('pencil')+'编辑网页信息</button>');
      }
      menu.hidden=false;updateIcons();positionCollectionMenu(x,y);menu.querySelector('button:not(:disabled)')?.focus();persist();
    }
    function showAttachmentPicker(){
      const item=selected();if(!item||item.deleted)return;closeCollectionMenu();
      const button=q('[data-section-block="files"] [data-do="file"]'),r=button?.getBoundingClientRect()||{right:root.clientWidth/2,bottom:root.clientHeight/2},menu=q('[data-menu]');
      attachmentMenu={owner:item.id,ids:[item.id],branch:null,picker:true};
      menu.classList.add('is-collection','is-attachment-picker');menu.setAttribute('aria-label','添加附件');
      menu.innerHTML=`<div data-attachment-actions>${attachmentButton('file','文件','file')}${attachmentButton('url','网页链接','link')}</div>`;
      menu.hidden=false;updateIcons();positionCollectionMenu(r.right-menu.offsetWidth,r.bottom);menu.querySelector('button').focus({preventScroll:true});
    }
    function showAttachmentSubmenu(branch,focus=false){
      if(!attachmentMenu)return;attachmentMenu.branch=branch;const menu=q('[data-menu]'),sub=q('[data-attachment-submenu]');if(!sub)return;
      const b=attachmentButton;
      sub.innerHTML=b('back',branch==='attach'?'添加附件':'添加到分类','arrow-left')+`<div class="kb-destination-list">${branch==='attach'?b('file','文件','file')+b('url','网页链接','link'):orderedCollections().map(c=>`<button type="button" data-item-target="${escape(c.id)}" style="--kb-depth:${c.depth}" ${attachmentMenu.ids.every(id=>byID(id)?.collections.includes(c.id))?'disabled':''}>${icon('folder')}<span>${escape(collectionPath(c.id))}</span></button>`).join('')||'<span class="kb-muted">请先在左侧新建分类</span>'}</div>`;
      sub.hidden=false;const stack=root.clientWidth<460;menu.classList.toggle('is-menu-stack',stack);qa('[data-attachment-action][aria-expanded]').forEach(b=>b.setAttribute('aria-expanded',String(b.dataset.attachmentAction===branch)));
      if(!stack){const room=root.clientWidth-parseFloat(menu.style.left)-menu.offsetWidth,available=root.clientHeight-parseFloat(menu.style.top)-8;sub.style.left=room>=212?'100%':'auto';sub.style.right=room>=212?'auto':'100%';sub.style.maxHeight=Math.max(120,available)+'px';const anchor=q('[data-attachment-actions] [data-attachment-action="'+branch+'"]');sub.style.top=Math.max(0,Math.min(anchor.offsetTop-5,available-sub.offsetHeight))+'px';}
      updateIcons();if(focus)sub.querySelector('button:not([data-attachment-action="back"]):not(:disabled)')?.focus();
    }
    function hideAttachmentSubmenu(){const branch=attachmentMenu?.branch;if(!branch)return;attachmentMenu.branch=null;q('[data-attachment-submenu]').hidden=true;q('[data-menu]').classList.remove('is-menu-stack');qa('[data-attachment-action][aria-expanded]').forEach(b=>b.setAttribute('aria-expanded','false'));q('[data-attachment-action="'+branch+'"]')?.focus();}
    function addItemsToCollection(id){if(!collectionByID(id)||!attachmentMenu)return;for(const key of attachmentMenu.ids){const i=byID(key);if(i&&!i.deleted&&!i.collections.includes(id))i.collections.push(id);}q('[data-menu]').hidden=true;render();persist();notify('已添加到分类：'+collectionPath(id));}
    function removeAttachment(item,id){item.files=item.files.filter(f=>f.id!==id);if(item.defaultFile===id)item.defaultFile=item.files[0]?.id||null;if(item.lastFile===id){item.lastFile=null;item.last=0;}if(item.webpage?.currentFile===id){item.webpage.currentFile=item.files.find(canNote)?.id||null;item.collectedAt=item.webpage.versions?.find(v=>v.fileId===item.webpage.currentFile)?.collectedAt||'';}noteCache.delete(item.id);render();persist();}
    function performAttachmentAction(action,button){
      if(['attach','classify'].includes(action)){showAttachmentSubmenu(action,true);return;}if(action==='back'){hideAttachmentSubmenu();return;}
      const ctx=attachmentMenu,item=byID(ctx?.owner);if(!item||item.deleted)return;const file=item.files.find(f=>f.id===(ctx.file||item.defaultFile))||item.files[0];q('[data-menu]').hidden=true;
      if(action==='open'){readItem(item.id,file?.id);return;}
      if(action==='folder'){if(file&&!isWeb(file))run(()=>bridge.revealFile(clone(file)));return;}
      if(action==='note'){const md=canNote(file)?file:item.files.find(canNote);if(md)readItem(item.id,md.id,{kind:'笔记',create:true});return;}
      if(action==='file'){const id=item.id;run(async()=>{const refs=await bridge.chooseFiles();attachFiles(byID(id),refs);});return;}
      if(action==='url'){showAttachmentDialog('url-attachment',item);return;}
      if(action==='remove-file'){if(ctx.file)showAttachmentDialog('remove-attachment',item,file);return;}
      if(action==='remove-collection'){const id=state.view.startsWith('collection:')?state.view.slice(11):null;if(!id||!ctx.ids.every(key=>byID(key)?.collections.includes(id)))return;for(const key of ctx.ids){const target=byID(key);if(target)target.collections=target.collections.filter(c=>c!==id);}state.checked=[];pickVisible();render();persist();notify('已从当前分类移除，条目仍保留在我的文库');}
    }
    function showAttachmentDialog(kind,item,file){
      closeCollectionMenu();modal=kind;attachmentDraft={owner:item.id,file:file?.id};previousFocus=document.activeElement;const form=q('[data-form]');form.classList.remove('is-relation');form.classList.toggle('is-url-dialog',kind==='url-attachment');
      form.innerHTML=`<header><h3 id="kb-modal-title">${kind==='url-attachment'?'将链接附加到 URI':'删除附件？'}</h3><button type="button" data-do="cancel" aria-label="关闭">${icon('x')}</button></header>${kind==='url-attachment'?'<div class="kb-url-fields"><label for="kb-link-url">链接：</label><input id="kb-link-url" name="url" type="url" required maxlength="4096" autocomplete="off"><label for="kb-link-title">标题：</label><input id="kb-link-title" name="title" maxlength="1000" placeholder="（可选）"></div>':`<p>${escape(file.name)}</p><p class="kb-muted">仅删除此条目的附件关联，原文件和文档笔记保留在原位置。</p>`}<footer><button type="button" class="kb-primary" data-do="confirm">${kind==='url-attachment'?'OK':'删除附件'}</button><button type="button" class="kb-outline" data-do="cancel">${kind==='url-attachment'?'Cancel':'取消'}</button></footer>`;
      q('[data-shade]').hidden=false;updateIcons();(form.elements.namedItem('url')||form.querySelector('[data-do="cancel"]')).focus();
    }
    function submitAttachmentDialog(){
      const item=byID(attachmentDraft?.owner);if(!item||item.deleted){closeModal();return;}const form=q('[data-form]');
      if(modal==='url-attachment'){let ref;try{ref=bridge.urlRef(form.elements.url.value,form.elements.title.value);}catch(e){form.elements.url.setCustomValidity(e.message);form.elements.url.reportValidity();return;}closeModal();attachFiles(item,[ref]);}
      else{const id=attachmentDraft.file;closeModal();removeAttachment(item,id);notify('已删除附件关联，原文件和笔记已保留');}
    }
    root.addEventListener('pointerover',event=>{if(!attachmentMenu||q('[data-menu]').hidden)return;const b=event.target.closest('[data-attachment-actions] [data-attachment-action]');if(b&&['attach','classify'].includes(b.dataset.attachmentAction)&&attachmentMenu.branch!==b.dataset.attachmentAction)showAttachmentSubmenu(b.dataset.attachmentAction);});
    root.addEventListener('keydown',event=>{
      if(!attachmentMenu||q('[data-menu]').hidden||!event.target.closest('[data-attachment-actions],[data-attachment-submenu]'))return;
      if(['ArrowUp','ArrowDown','Home','End','ArrowLeft','ArrowRight','Escape'].includes(event.key)){event.preventDefault();event.stopImmediatePropagation();}
      if(event.key==='ArrowRight'){const action=event.target.closest('[data-attachment-action]')?.dataset.attachmentAction;if(['attach','classify'].includes(action))showAttachmentSubmenu(action,true);return;}
      if(event.key==='ArrowLeft'||event.key==='Escape'&&attachmentMenu.branch){hideAttachmentSubmenu();return;}
      if(event.key==='Escape'){const focus=attachmentMenu.picker?q('[data-section-block="files"] [data-do="file"]'):q('[data-select="'+attachmentMenu.owner+'"]');closeCollectionMenu();focus?.focus({preventScroll:true});return;}
      if(['ArrowUp','ArrowDown','Home','End'].includes(event.key)){const group=event.target.closest('[data-attachment-submenu]')||q('[data-attachment-actions]'),buttons=[...group.querySelectorAll('button:not(:disabled)')].filter(b=>b.getClientRects().length),at=buttons.indexOf(document.activeElement),next=event.key==='Home'?0:event.key==='End'?buttons.length-1:(at+(event.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length;buttons[next]?.focus();}
    },true);

    async function clearRecent(ids,all=false){
      if(state.view!=='recent')return;
      // Clearing all history is independent of the current selection, search and tag filters.
      const targets=(all?items:[...new Set(ids)].map(byID)).filter(item=>item&&!item.deleted&&item.lastFile);
      if(!targets.length)return;
      // Clear only recent-reading markers. The item, status, rating and linked files stay intact.
      for(const item of targets){item.lastFile=null;item.last=0;}
      state.checked=[];pickVisible();render();persist();
      if(await flush())notify((all?'已清空全部阅读记录（共 '+targets.length+' 个条目）':'已清除 '+targets.length+' 个条目的阅读记录')+'，条目仍保留在文库中');
      else notify((all?'清空':'清除')+'阅读记录尚未保存，请重试保存');
    }
    function editBatch(action,ids){if(action==='clear-recent'||action==='clear-all-recent'||action==='trash'&&state.view==='recent'){run(()=>clearRecent(ids,action==='clear-all-recent'));return;}if(action==='purge'){showPurgeDialog(ids);return;}for(const id of ids){const i=byID(id);if(!i)continue;if(action==='done'&&i.type!=='webpage')i.status='done';if(action==='star')i.star=true;if(action==='trash')i.deleted=true;if(action==='restore')i.deleted=false;}state.checked=[];pickVisible();render();persist();notify(action==='trash'?'已移入回收站，可随时恢复':action==='restore'?'条目已恢复':'条目已更新');}
    root.addEventListener('click',event=>{if(event.target.closest('[data-summary-display]')){beginSummaryEdit();return;}const button=event.target.closest('button'),row=event.target.closest('[data-row]');if(row&&(!button||button.hasAttribute('data-select'))){selectRow(row.dataset.row,event);return;}if(!button||!root.contains(button))return;const d=button.dataset;
      if(Object.hasOwn(d,'duplicateReview')){closeModal();openDuplicates(d.duplicateReview);q('[data-merge-submit]')?.focus({preventScroll:true});return;}
      if(Object.hasOwn(d,'duplicateOpen')){openDuplicates(d.duplicateOpen);return;}
      if(d.mergeMaster&&mergeDraft){mergeDraft.masterId=d.mergeMaster;mergeDraft.choices={};renderMergePane();return;}
      if(Object.hasOwn(d,'mergeSubmit')){run(mergeSelected);return;}
      if(d.noteBack!==undefined){if(leaveNotePane()){renderDetail();updateIcons();loadVisibleNotes(true);refreshExpandedNotes();}return;}
      if(d.do==='library-menu'){if(libraryMenu&&!q('[data-menu]').hidden)closeCollectionMenu();else showLibraryMenu(button);return;}
      if(d.do==='export-library'||d.do==='import-library'){run(()=>transferLibrary(d.do==='export-library'));return;}
      if(d.do==='drive-backup'){closeCollectionMenu();run(()=>bridge.driveBackup());return;}
      if(d.childNote){const owner=byID(d.childNote),note=noteCache.get(owner?.id)?.notes.find(n=>n.id===d.noteId&&n.kind===d.noteKind&&n.fileId===d.noteFile);if(owner&&note){selectRow(owner.id,{});run(()=>readItem(owner.id,note.fileId,note));}return;}
      if(d.do==='new'){showNewTypeMenu(button);return;}
      if(d.newType){createEmptyItem(d.newType);return;}
      if(d.do==='import-book'){run(importBook);return;}
      if(d.authorAffiliation){revealAuthorAffiliation(d.authorAffiliation);return;}
      if(d.resourceUrl){run(()=>bridge.openResourceURL(d.resourceUrl));return;}
      if(d.infoEdit){beginInfoEdit(d.infoEdit);return;}
      if(Object.hasOwn(d,'isbnLookup')){void lookupBookISBN();return;}
      if(d.do==='tag-options'){if(tagOptionsMenu&&!q('[data-menu]').hidden)closeCollectionMenu();else showTagOptions(button);return;}
      if(d.tagOption){performTagOption(d.tagOption);return;}
      if(d.metricColumn){showMetricColumnSettings(d.metricColumn);return;}
      if(d.toggleColumn){toggleColumnVisibility(d.toggleColumn);return;}
      if(d.metricReset){resetMetricField(d.metricReset);return;}
      if(Object.hasOwn(d,'metricGetKey')){run(()=>bridge.openMetricKeyPage(d.metricGetKey));return;}
      if(Object.hasOwn(d,'removeCitationField')){const input=q('[data-form]').elements.namedItem('citationFields');input.value=input.value.split(/[,，]/).map(v=>v.trim()).filter(v=>v&&v!==d.removeCitationField).join(', ');renderCitationFieldChips();q('[data-add-citation-field]').focus();return;}
      if(Object.hasOwn(d,'addCitationField')){const picker=q('[data-citation-field-picker]');picker.hidden=!picker.hidden;button.setAttribute('aria-expanded',String(!picker.hidden));if(!picker.hidden)picker.querySelector('button')?.focus();return;}
      if(d.citationFieldChoice){const input=q('[data-form]').elements.namedItem('citationFields');input.value=[...new Set([...input.value.split(/[,，]/).map(v=>v.trim()).filter(Boolean),d.citationFieldChoice])].join(', ');renderCitationFieldChips();q('[data-add-citation-field]').focus();return;}
      if(Object.hasOwn(d,'cnkiVerify')){run(()=>bridge.openCNKI());return;}
      if(d.metricsRefresh){q('[data-menu]').hidden=true;run(()=>syncMetrics(true,d.metricsRefresh==='all'));return;}
      if(d.do==='add-membership'){showMembershipMenu(button);return;}
      if(d.membershipView){navigateMembership(d.membershipView);return;}
      if(d.membershipAdd){addMembership(d.membershipAdd);return;}
      if(d.membershipRemove){showRemoveMembership(d.membershipRemove,button);return;}
      if(d.do==='add-tag'){beginTagEdit();return;}
      if(Object.hasOwn(d,'itemTagEdit')){beginTagEdit(d.itemTagEdit);return;}
      if(Object.hasOwn(d,'itemTagRemove')){removeItemTag(d.itemTagRemove);return;}
      if(d.paneAction){run(()=>performPaneAction(d.paneAction,d.pane));return;}
      if(d.summaryAction){q('[data-menu]').hidden=true;run(()=>readSummarySource(d.summaryAction));return;}
      if(d.do==='cancel-import'){cancelImport();return;}
      if(!button.closest('[data-menu]'))q('[data-menu]').hidden=true;
            if(d.do==='choose-root'){run(()=>bridge.chooseRoot());return;}
      if(d.do==='close-library'){run(()=>bridge.close());return;}
      if(d.do==='retry-save'){run(()=>flush());return;}
      if(d.do==='retry-open'){const retry=retryOpen;if(retry)run(retry);return;}
      if(d.do==='reload-library'){run(async()=>{if(saving)await saving;if(dirty()){const file=await bridge.recovery(snapshot());notify('当前修改已保留：'+file);}const result=await bridge.read();if(!result)throw new Error('知识库文件不存在，请更换目录。');loadLibrary(result.data,{state,design},result.warning||'');});return;}
      if(d.do==='open-notes'){const i=selected(),f=i?.files.find(f=>f.id===i.lastFile&&canNote(f))||i?.files.find(canNote);if(f)readItem(i.id,f.id,{kind:'笔记',create:true});else notify('请先关联 Markdown 文件，用于保存笔记');return;}
      if(d.noteDelete!==undefined){showNoteRemoval();return;}
      if(d.noteRemove!==undefined){showNoteRemoval(noteTarget(d.noteRemove));return;}
      if(d.openNote!==undefined){const i=selected(),n=noteCache.get(i?.id)?.notes[Number(d.openNote)];if(n)readItem(i.id,n.fileId,n);return;}
      if(d.relink){const item=selected(),old=item?.files.find(f=>f.id===d.relink);if(old)run(async()=>{const file=await bridge.relink(clone(old));if(file){const current=byID(item.id)?.files.find(f=>f.id===old.id);if(!current)return;Object.assign(current,file);noteCache.delete(item.id);render();persist();await syncMetadata();}});return;}
      if(d.unlink){const i=selected();if(i){removeAttachment(i,d.unlink);notify('已取消关联，原文件仍保留');}return;}

      if(d.do==='random-palette'){bridge.randomTheme();applyPalette();return;}
      if(d.tree){const at=state.closedGroups.indexOf(d.tree);at<0?state.closedGroups.push(d.tree):state.closedGroups.splice(at,1);renderNav();updateIcons();persist();return;}
      if(d.resize||d.colResize)return;
      if(d.collectionAction){if(['choose-root','reveal-root'].includes(d.collectionAction)){const choose=d.collectionAction==='choose-root';closeCollectionMenu();run(()=>choose?bridge.chooseRoot():bridge.revealRoot());return;}if(['move','copy'].includes(d.collectionAction))showCollectionTargets(d.collectionAction,true);else showCollectionDialog(d.collectionAction,collectionMenu.id);return;}
      if(Object.hasOwn(d,'collectionTarget')){transferCollection(d.collectionTarget);return;}
      if(Object.hasOwn(d,'collectionBack')){hideCollectionTargets();return;}
      if(d.do==='toggle-detail'){if(state.detailCollapsed)openInformationPane();else{state.detailCollapsed=true;renderDetail();updateIcons();}q('[data-do="toggle-detail"]')?.focus({preventScroll:true});persist();return;}
      if(d.jumpSection){state.detailCollapsed=false;state.sections[d.jumpSection]=true;state.activeSection=d.jumpSection;renderDetail();updateIcons();cancelAnimationFrame(detailFrame);detailFrame=requestAnimationFrame(()=>scrollToSection(d.jumpSection,'smooth',true));persist();return;}
      if(d.section){const top=q('[data-pane-scroll]')?.scrollTop||0;state.sections[d.section]=!state.sections[d.section];state.activeSection=d.section;renderDetail(top);updateIcons();q('[data-section="'+d.section+'"]')?.focus({preventScroll:true});persist();return;}
      if(d.relationToggle){const closed=relationDraft.closed;closed.has(d.relationToggle)?closed.delete(d.relationToggle):closed.add(d.relationToggle);renderRelationTree();return;}
      if(d.relationView){relationDraft.view=d.relationView;renderRelationResults();return;}
      if(d.unrel){removeRelation(d.unrel);return;}
      if(d.sortBy){state.sortDirection=state.sort===d.sortBy?(state.sortDirection==='asc'?'desc':'asc'):sortFields[d.sortBy].direction;state.sort=d.sortBy;renderList();updateIcons();persist();return;}
      if(d.view){if(d.view==='duplicates'){openDuplicates();return;}mergeDraft=null;if(d.view==='recent'&&state.view!=='recent'){state.sort='date';state.sortDirection='desc';}state.view=d.view;if(bridge.workspace&&root.dataset.layout!=="desktop")workspacePane("list");clearItemFilters();state.checked=[];pickVisible();render();persist();return;}
      if(d.select){state.selected=d.select;state.checked=[d.select];selectionAnchor=d.select;renderSelection();renderDetail();updateIcons();persist();return;}
      if(d.expand){const at=state.expanded.indexOf(d.expand);at<0?state.expanded.push(d.expand):state.expanded.splice(at,1);state.selected=d.expand;state.checked=[d.expand];render();persist();return;}
      if(d.star){const i=byID(d.star);i.star=!i.star;pickVisible();render();persist();return;}
      if(d.statusFilter){state.statusFilter=state.statusFilter===d.statusFilter?'':d.statusFilter;state.checked=[];pickVisible();render();persist();return;}
      if(d.ratingFilter){const value=Number(d.ratingFilter);state.ratingFilter=state.ratingFilter===value?0:value;state.checked=[];pickVisible();render();persist();return;}
      if(d.tag){state.tags=state.tags.includes(d.tag)?state.tags.filter(t=>t!==d.tag):[...state.tags,d.tag];state.checked=[];pickVisible();render();persist();return;}
      if(d.tab){state.tab=d.tab;renderDetail();updateIcons();persist();return;}
      if(d.read){readItem(d.read,d.file);return;}
      if(d.default){selected().defaultFile=d.default;if(selected().webpage&&canNote(selected().files.find(f=>f.id===d.default))){selected().webpage.currentFile=d.default;selected().collectedAt=selected().webpage.versions?.find(v=>v.fileId===d.default)?.collectedAt||'';}renderDetail();updateIcons();persist();notify('默认阅读文件已更新');void syncMetadata();return;}
      if(d.move){const list=selected().files,at=list.findIndex(f=>f.id===d.move),to=at+Number(d.dir);if(to>=0&&to<list.length)[list[at],list[to]]=[list[to],list[at]];render();persist();notify('章节顺序已更新');return;}
      if(d.rate){setItemRating(d.ratingItem,Number(d.rate),button.closest('[data-rating-surface]').dataset.ratingSurface);return;}
      if(d.step){const i=byID(state.reader.item),at=i.files.findIndex(f=>f.id===state.reader.file);const f=i.files[at+Number(d.step)];if(f)readItem(i.id,f.id);return;}
      if(d.bulkAction){editBatch(d.bulkAction,selectionIDs());return;}
      if(d.attachmentAction){performAttachmentAction(d.attachmentAction,button);return;}
      if(d.itemTarget){addItemsToCollection(d.itemTarget);return;}
      if(d.context){q('[data-menu]').hidden=true;if(d.context==='read')readItem(state.selected);else if(d.context==='star'&&selectionIDs().length===1){selected().star=!selected().star;pickVisible();render();persist();}else editBatch(d.context,selectionIDs());return;}
      if(['new','edit','collection','file','related','summary','collections'].includes(d.do))showModal(d.do);
      if(d.do==='cancel'){closeModal();void syncMetadata();}
      if(d.do==='confirm'&&q('[data-form]').reportValidity())submitForm();
      if(d.do==='restore')editBatch('restore',[state.selected]);
      if(d.do==='back'){state.reader=null;render();persist();notify('已返回原分类和列表');}
    });
    root.addEventListener('dblclick',event=>{const row=event.target.closest('[data-row]');if(row&&!event.target.closest('[data-star],[data-expand],[data-rating-id],input'))readItem(row.dataset.row);});
    root.addEventListener('contextmenu',event=>{const note=event.target.closest('[data-child-note],[data-note-index]');if(note&&showNoteMenu(note,event.clientX,event.clientY)){event.preventDefault();return;}const attachment=event.target.closest('[data-attachment-file],[data-read][data-file]');if(attachment){event.preventDefault();contextMenu(attachment.dataset.attachmentItem||attachment.dataset.read,event.clientX,event.clientY,attachment.dataset.attachmentFile||attachment.dataset.file);return;}const cell=event.target.closest('th[data-column],td[data-column]'),column=cell?.dataset.column;if(cell?.tagName==='TH'){event.preventDefault();columnHeaderMenu(column,event.clientX,event.clientY);return;}const pane=event.target.closest('[data-jump-section],[data-section-block]');if(pane){if(event.target.matches('input,textarea'))return;event.preventDefault();showPaneMenu(pane.dataset.jumpSection||pane.dataset.sectionBlock,event.clientX,event.clientY);return;}const row=event.target.closest('[data-row]');if(!row)return;event.preventDefault();contextMenu(row.dataset.row,event.clientX,event.clientY);});
    root.addEventListener('change',event=>{const e=event.target;if(e.matches('[data-info-add]')){const key=e.value;e.value='';if(key)beginInfoEdit(key);return;}if(e.matches('[name=type]')&&itemDraft){captureTypedFields();itemDraft.values.type=e.value;renderTypedFields();return;}if(e.matches('[data-related]')){if(e.checked)relationDraft.ids.add(e.dataset.related);else relationDraft.ids.delete(e.dataset.related);q('[data-relation-count]').textContent='已选 '+relationDraft.ids.size+' 项';return;}if(e.matches('[data-palette]')){try{bridge.setTheme(e.value);applyPalette();}catch(error){showError(error.message);}}else if(e.matches('[data-mobile-view]')){if(e.value==='recent'&&state.view!=='recent'){state.sort='date';state.sortDirection='desc';}state.view=e.value;clearItemFilters();state.checked=[];pickVisible();render();persist();}else if(e.matches('[data-status]')){selected().status=e.value;pickVisible();render();persist();}});
    root.addEventListener('input',event=>{if(event.target.matches('[data-relation-search]')){relationDraft.query=event.target.value;renderRelationResults();return;}if(event.target.matches('[data-tag-search]')){state.tagQuery=event.target.value;renderTags();persist();}});
    q('[data-search]').addEventListener('input',event=>{state.query=event.target.value;state.checked=[];pickVisible();renderTags();renderList();renderDetail();updateIcons();persist();});
    function submitForm(){
      if(modal==='webpage'){void webSave();return;}
      if(modal==='duplicate-alert')return;
      if(modal==='change-type'){commitTypeChange();return;}
      if(modal==='metrics-column'){
        const active=metricsJob,generation=libraryGeneration;saveMetricsSettings();
        run(async()=>{if(active)await active;if(generation===libraryGeneration)await syncMetrics(true,true);});return;
      }
      if(modal==='summary-source'){run(()=>commitSummarySource());return;}
      if(modal==='remove-auto-tags'){run(commitAutomaticTagRemoval);return;}
      if(modal==='purge'){run(()=>commitPurge());return;}
      if(modal==='remove-note'){run(()=>commitNoteRemoval());return;}
      if(modal==='url-attachment'||modal==='remove-attachment'){submitAttachmentDialog();return;}
      if(modal==='remove-membership'){
        const item=byID(membershipRemoval?.owner),id=membershipRemoval?.collection;
        if(item&&!item.deleted)item.collections=item.collections.filter(cid=>cid!==id);
        membershipRemoval=null;closeModal();pickVisible();render();persist();notify('已从分类移除，条目仍保留在我的文库');return;
      }
      if(modal?.startsWith('collection-')){submitCollectionDialog();return;}
      const form=q('[data-form]'),data=new FormData(form),kind=modal;
      if(kind==='new'||kind==='edit'){
        const title=String(data.get('title')||'').trim();if(!title){form.elements.title.setCustomValidity('请输入标题');form.elements.title.reportValidity();return;}
        captureTypedFields();
        const values={type:data.get('type'),title,author:String(data.get('author')||'').trim(),year:String(data.get('year')||''),tags:[...new Set(String(data.get('tags')||'').split(/[，,]/).map(s=>s.trim()).filter(Boolean))]};
        for(const key of itemDraft.changed)values[key]=itemDraft.values[key];
        let i=byID(editingItemId);
        if(kind==='new'){i={id:newID(),status:'unread',star:false,files:[],notes:[],related:[],summary:'',collections:state.view.startsWith('collection:')?[state.view.slice(11)]:[],added:new Date().toISOString(),last:0};items.push(i);}
        if(!i){showError('该条目已不存在，请重新载入后再编辑。');return;}
        Object.assign(i,bridge.markMetadataEdited(clone(i),values),values);state.reader=null;state.selected=i.id;state.checked=[i.id];state.query='';clearItemFilters();if(!scope(i))state.view='all';state.tab=kind==='new'?'files':'info';state.sections[kind==='new'?'files':'info']=true;
      }else if(kind==='summary'){const i=byID(editingItemId);if(i){const values={summary:String(data.get('summary')||'')};Object.assign(i,bridge.markMetadataEdited(clone(i),values),values);}}
      else if(kind==='collections'){const i=byID(editingItemId);if(i)i.collections=data.getAll('collections').filter(id=>collectionByID(id));pickVisible();}
      else if(kind==='related')commitRelations();
      closeModal();render();persist();notify(kind==='related'?'相关条目已更新':'条目已更新');void syncMetadata();
    }
    q('[data-form]').addEventListener('submit',event=>{event.preventDefault();if(q('[data-form]').reportValidity())submitForm();});
    q('[data-form]').addEventListener('input',event=>{updateMetricRange(event.target);if(event.target.name==='citationColors')renderCitationFieldChips();if(event.target.hasAttribute('data-preserve-secret'))event.target.dataset.preserveSecret='false';});
    q('[data-form]').addEventListener('change',event=>{if(event.target.name==='impactField')selectImpactField();});
    q('[data-form]').addEventListener('focusin',event=>{if(event.target.dataset.preserveSecret==='true')event.target.select();});
    q('[data-form]').addEventListener('beforeinput',event=>{if(event.target.dataset.preserveSecret==='true'&&event.target.value==='********')event.target.value='';});
    q('[data-form]').addEventListener('keydown',event=>{if(event.isComposing)return;if(event.key==='Enter'&&event.target.matches('input:not([type=checkbox])')){event.preventDefault();if(q('[data-form]').reportValidity())submitForm();}});
    q('[data-form]').addEventListener('input',event=>event.target.setCustomValidity?.(''));
    q('[data-shade]').addEventListener('click',event=>{if(event.target===q('[data-shade]'))closeModal();});
    root.addEventListener('keydown',event=>{
      const note=event.target.closest('[data-child-note],[data-note-index]');if(note&&(event.key==='ContextMenu'||event.shiftKey&&event.key==='F10')){const r=note.getBoundingClientRect();if(showNoteMenu(note,r.left,r.bottom)){event.preventDefault();return;}}
      if(noteMenu&&!q('[data-menu]').hidden&&['Escape','Tab'].includes(event.key)){event.preventDefault();closeCollectionMenu(true);return;}
      if(tagOptionsMenu&&!q('[data-menu]').hidden&&['Escape','Tab'].includes(event.key)){event.preventDefault();closeCollectionMenu();q('[data-do="tag-options"]')?.focus();return;}
      if(event.target.closest('.kb-menu.is-columns,.kb-menu.is-tags')&&['ArrowDown','ArrowUp','Home','End'].includes(event.key)){
        event.preventDefault();const buttons=qa('.kb-menu.is-columns button:not(:disabled),.kb-menu.is-tags button:not(:disabled)'),at=buttons.indexOf(document.activeElement);
        const next=event.key==='Home'?0:event.key==='End'?buttons.length-1:(at+(event.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length;buttons[next]?.focus();return;
      }
      const columnHeader=event.target.closest('th[data-column]');if(columnHeader&&(event.key==='ContextMenu'||event.shiftKey&&event.key==='F10')){event.preventDefault();const r=columnHeader.getBoundingClientRect();columnHeaderMenu(columnHeader.dataset.column,r.left,r.bottom);return;}
      const attachment=event.target.closest('[data-attachment-file],[data-read][data-file]');if(attachment&&(event.key==='ContextMenu'||event.shiftKey&&event.key==='F10')){event.preventDefault();const r=attachment.getBoundingClientRect();contextMenu(attachment.dataset.attachmentItem||attachment.dataset.read,r.left,r.bottom,attachment.dataset.attachmentFile||attachment.dataset.file);return;}
      const pane=event.target.closest('[data-jump-section],[data-section-block]');
      if(pane&&!event.target.matches('input,textarea')&&(event.key==='ContextMenu'||event.shiftKey&&event.key==='F10')){event.preventDefault();const r=pane.getBoundingClientRect();showPaneMenu(pane.dataset.jumpSection||pane.dataset.sectionBlock,r.left+10,r.top+20);return;}
      if(event.target.matches('[data-summary-display]')&&['Enter',' '].includes(event.key)){event.preventDefault();beginSummaryEdit();return;}
      if(importToken){if(event.key==='Escape'){event.preventDefault();event.stopPropagation();cancelImport();}return;}
      const row=event.target.closest('[data-row]');
      if(row&&!modal&&q('[data-menu]').hidden&&!event.target.closest('[data-expand],[data-rate]')){
        const ids=visible().map(i=>i.id),at=ids.indexOf(row.dataset.row);
        if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='a'){event.preventDefault();state.checked=ids;state.selected=row.dataset.row;selectionAnchor=ids[0];renderSelection();renderDetail();updateIcons();persist();return;}
        if(['ArrowUp','ArrowDown','Home','End'].includes(event.key)){event.preventDefault();const next=event.key==='Home'?0:event.key==='End'?ids.length-1:Math.max(0,Math.min(ids.length-1,at+(event.key==='ArrowDown'?1:-1)));selectRow(ids[next],{shiftKey:event.shiftKey});q('[data-select="'+ids[next]+'"]')?.scrollIntoView({block:'nearest',inline:'nearest'});return;}
        if(event.key===' '&&(event.ctrlKey||event.metaKey)){event.preventDefault();selectRow(row.dataset.row,event);return;}
        if(event.key==='Enter'){event.preventDefault();readItem(row.dataset.row);return;}
      }
      if(event.key==='Escape'){const picker=q('[data-citation-field-picker]');if(picker&&!picker.hidden){picker.hidden=true;q('[data-add-citation-field]').setAttribute('aria-expanded','false');q('[data-add-citation-field]').focus();return;}if(modal)closeModal();else if(!q('[data-menu]').hidden){q('[data-menu]').hidden=true;q('[data-select="'+state.selected+'"]')?.focus();}else if(!columnDrag&&!resizeSession)run(()=>bridge.close());return;}
      if(modal&&event.key==='Tab'){const controls=[...q('[data-form]').querySelectorAll('input,select,textarea,button')].filter(e=>!e.disabled&&e.type!=='hidden'&&e.getClientRects().length),first=controls[0],last=controls.at(-1);if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}return;}
      if(event.key==='/'&&!event.target.closest('input,textarea,select')&&!state.reader&&!modal){event.preventDefault();q('[data-search]').focus();}
      if((event.key==='ContextMenu'||event.shiftKey&&event.key==='F10')&&event.target.closest('[data-row]')){event.preventDefault();const row=event.target.closest('[data-row]'),r=row.getBoundingClientRect();contextMenu(row.dataset.row,r.left+35,r.bottom);}
    });
function itemTagRow(tag,item){
  return `<div class="kb-item-tag-row" data-item-tag-row data-tag-value="${escape(tag)}">${icon('tag')}<button type="button" class="kb-item-tag-label" data-item-tag-edit="${escape(tag)}" title="${escape(tag)}" aria-label="编辑标签：${escape(tag)}" ${item.deleted?'disabled':''}>${escape(tag)}</button>${item.deleted?'':`<button type="button" class="kb-item-tag-remove" data-item-tag-remove="${escape(tag)}" title="移除标签" aria-label="移除标签：${escape(tag||'未保存标签')}">${icon('minus')}</button>`}</div>`;
}
function itemTagsMarkup(item){return `<div class="kb-item-tags" data-item-tags>${item.tags.map(tag=>itemTagRow(tag,item)).join('')}</div>`;}
function itemTagsHeading(open,item){
  return `<button type="button" class="kb-section-title cursor-interaction" data-section="tags" aria-expanded="${!!open}" aria-controls="kb-section-tags">${icon('tag')}<span data-item-tag-count>${item.tags.length} 个标签</span></button><button type="button" class="kb-section-action cursor-interaction" data-do="add-tag" aria-label="添加标签" ${item.deleted?'disabled':''}>${icon('plus')}</button><button type="button" class="kb-section-action cursor-interaction" data-section="tags" aria-label="${open?'收起':'展开'}标签" aria-expanded="${!!open}" aria-controls="kb-section-tags">${icon(open?'chevron-up':'chevron-down')}</button>`;
}
function setItemTags(item,tags){
  tags=[...new Set(tags.map(tag=>tag.trim()).filter(Boolean))];
  if(JSON.stringify(tags)===JSON.stringify(item.tags))return;
  const values={tags};Object.assign(item,bridge.markMetadataEdited(clone(item),values),values);
  tagSearchPending=true;detailSignature='';q('[data-save-status]').textContent='尚未保存';
}
function updateTagCount(item){
  if(detailItemID!==item.id)return;
  const count=q('[data-item-tag-count]'),container=q('[data-item-tags]');if(count)count.textContent=item.tags.length+' 个标签';
  updateIcons();
}
function focusItemTag(tag){(qa('[data-item-tag-edit]').find(b=>b.dataset.itemTagEdit===tag)||q('[data-do="add-tag"]'))?.focus({preventScroll:true});}
function beginTagEdit(original=null){
  if(infoEditor?.composing)return;commitInfoEdit();
  const item=selected();if(!item||item.deleted||selectionIDs().length>1||tagEditor?.composing)return;
  if(tagEditor?.id===item.id&&tagEditor.original===original){tagEditor.input.focus();return;}
  commitTagEdit();commitSummaryEdit();persist();
  if(original!==null&&!item.tags.includes(original))return;
  state.sections.tags=true;state.activeSection='tags';renderDetail();updateIcons();saveView();
  const container=q('[data-item-tags]');if(!container)return;
  container.querySelector('[data-no-item-tags]')?.remove();
  let row=original===null?null:[...container.children].find(r=>r.dataset.tagValue===original);
  if(!row){container.insertAdjacentHTML('beforeend',itemTagRow('',item));row=container.lastElementChild;}
  const input=document.createElement('input');input.type='text';input.className='kb-item-tag-input';input.dataset.itemTagInput='';input.value=original||'';input.setAttribute('aria-label',original===null?'新标签':'编辑标签');
  row.classList.add('is-editing');row.querySelector('[data-item-tag-edit]').replaceWith(input);
  tagEditor={id:item.id,original,input,row,composing:false,pendingBlur:false};updateIcons();row.scrollIntoView({block:'nearest'});input.focus({preventScroll:true});input.select();
  input.addEventListener('compositionstart',()=>{if(tagEditor?.input===input)tagEditor.composing=true;});
  input.addEventListener('compositionend',()=>{
    if(tagEditor?.input!==input)return;tagEditor.composing=false;
    if(tagEditor.pendingBlur)queueMicrotask(()=>{if(tagEditor?.input===input){commitTagEdit();renderDetail();updateIcons();persist();refreshTagSearch();}});
  });
  input.addEventListener('keydown',event=>{
    if(event.isComposing||event.keyCode===229||tagEditor?.composing){if(['Escape','Enter'].includes(event.key))event.stopPropagation();return;}
    if(event.key==='Escape'){event.preventDefault();event.stopPropagation();commitTagEdit(true);refreshTagSearch();focusItemTag(original);return;}
    if(event.key==='Tab'){
      event.preventDefault();event.stopPropagation();
      const controls=qa('button,input,select,textarea,[tabindex="0"]').filter(e=>!e.disabled&&e.getClientRects().length),previous=controls[controls.indexOf(input)-1],value=input.value.trim();
      commitTagEdit();persist();refreshTagSearch();
      const next=event.shiftKey&&previous?.isConnected?previous:qa('[data-item-tag-remove]').find(b=>b.dataset.itemTagRemove===value)||q('[data-do="add-tag"]');next?.focus({preventScroll:true});return;
    }
    if(event.key==='Enter'){
      event.preventDefault();event.stopPropagation();const value=input.value.trim();commitTagEdit();persist();refreshTagSearch();
      if(original===null&&value&&state.selected===item.id)beginTagEdit();else focusItemTag(value);
    }
  });
  input.addEventListener('blur',()=>{
    if(tagEditor?.input!==input||!document.hasFocus())return;
    if(tagEditor.composing){tagEditor.pendingBlur=true;return;}
    commitTagEdit();persist();
  });
}
function commitTagEdit(cancel=false){
  const draft=tagEditor;if(!draft||draft.composing&&!cancel)return false;
  tagEditor=null;const item=byID(draft.id);if(!item)return true;
  const value=cancel?draft.original:draft.input.value.trim();
  if(!cancel&&!item.deleted){
    const tags=[...item.tags],at=tags.indexOf(draft.original);
    if(draft.original===null){if(value)tags.push(value);}else if(at>=0){if(value)tags[at]=value;else tags.splice(at,1);}
    setItemTags(item,tags);
  }
  if(draft.row.isConnected){
    const duplicate=[...draft.row.parentElement.children].some(row=>row!==draft.row&&row.dataset.tagValue===value);
    if(value&&item.tags.includes(value)&&!duplicate)draft.row.outerHTML=itemTagRow(value,item);else draft.row.remove();
  }
  updateTagCount(item);return true;
}
function removeItemTag(tag){
  const item=selected();if(!item||item.deleted)return;
  if(tagEditor?.id===item.id&&(tagEditor.original===tag||tagEditor.original===null&&tag===''))commitTagEdit(true);
  else if(tagEditor){if(tagEditor.composing)return;commitTagEdit();}
  setItemTags(item,item.tags.filter(t=>t!==tag));
  qa('[data-item-tag-row]').filter(row=>row.dataset.tagValue===tag).forEach(row=>row.remove());updateTagCount(item);persist();refreshTagSearch();q('[data-do="add-tag"]')?.focus({preventScroll:true});
}
function refreshTagSearch(){
  if(!tagSearchPending||tagEditor)return;tagSearchPending=false;
  // Run after the clicked target acts; a blur-save must not remove that target first.
  const previous=state.selected,focus=document.activeElement,selectID=focus?.dataset.select,filterTag=focus?.dataset.tag;
  state.tags=state.tags.filter(tag=>items.some(i=>i.tags.includes(tag)));renderTags();
  pickVisible();renderList();if(state.selected!==previous)renderDetail();updateIcons();saveView();
  if(!focus?.isConnected){const target=selectID?qa('[data-select]').find(b=>b.dataset.select===selectID):filterTag?qa('[data-tag]').find(b=>b.dataset.tag===filterTag):null;target?.focus({preventScroll:true});}
}
root.addEventListener('pointerdown',event=>{if(event.target.closest('[data-item-tag-remove]'))event.preventDefault();});
root.addEventListener('click',refreshTagSearch);
root.addEventListener('keyup',refreshTagSearch);
function summarySourceLabel(item){
  if(item.xrefMetadata?.locked?.includes('summary')||item.summary&&!Object.hasOwn(item.xrefMetadata?.applied||{},'summary'))return '手动编辑';
  return item.xrefMetadata?.summarySource?.kind==='index'?'来自索引':item.xrefMetadata?.summarySource?.kind==='markdown'?'来自 Markdown':'摘要';
}
function summaryMarkup(item){
  const label=item.type==='book'?'简介':'摘要';
  return `<div class="kb-summary kb-summary-editable" data-summary-display role="textbox" aria-readonly="true" aria-multiline="true" aria-label="${label}" tabindex="0" title="${summarySourceLabel(item)} · 点击编辑 · 右键更多操作">${escape(item.summary||'')}</div>`;
}
function resizeSummaryEditor(input){input.style.height='0px';input.style.height=Math.max(120,input.scrollHeight+4)+'px';}
function beginSummaryEdit(){
  if(infoEditor?.composing)return;commitInfoEdit();
  const item=selected();if(!item||summaryEditor||selectionIDs().length>1)return;
  state.sections.summary=true;renderDetail();
  const container=q('[data-summary-content]');if(!container)return;
  const input=document.createElement('textarea');input.className='kb-summary kb-summary-input';input.dataset.summaryEditor='';input.maxLength=30000;
  input.setAttribute('aria-label',item.type==='book'?'编辑简介':'编辑摘要');input.value=item.summary||'';
  summaryEditor={id:item.id,original:input.value,value:input.value,input,composing:false,pendingBlur:false};
  container.replaceChildren(input);resizeSummaryEditor(input);input.focus({preventScroll:true});
  input.addEventListener('input',()=>{if(summaryEditor?.input!==input)return;summaryEditor.value=input.value;resizeSummaryEditor(input);});
  input.addEventListener('compositionstart',()=>{if(summaryEditor?.input===input)summaryEditor.composing=true;});
  input.addEventListener('compositionend',()=>{
    if(summaryEditor?.input!==input)return;summaryEditor.composing=false;summaryEditor.value=input.value;
    if(summaryEditor.pendingBlur)queueMicrotask(()=>{if(summaryEditor?.input===input){commitSummaryEdit();persist();}});
  });
  input.addEventListener('keydown',event=>{
    if(event.isComposing||event.keyCode===229||summaryEditor?.composing){if(event.key==='Escape')event.stopPropagation();return;}
    if(event.key==='Escape'){event.preventDefault();event.stopPropagation();commitSummaryEdit(true);q('[data-summary-display]')?.focus({preventScroll:true});}
    if(event.key==='Enter'&&(event.ctrlKey||event.metaKey)){event.preventDefault();event.stopPropagation();commitSummaryEdit();persist();q('[data-summary-display]')?.focus({preventScroll:true});}
  });
  input.addEventListener('blur',()=>{
    if(summaryEditor?.input!==input)return;
    if(!document.hasFocus())return; // Switching applications must not discard the active draft.
    if(summaryEditor.composing){summaryEditor.pendingBlur=true;return;}
    commitSummaryEdit();persist();
  });
}
function commitSummaryEdit(cancel=false){
  const draft=summaryEditor;if(!draft||draft.composing&&!cancel)return false;
  summaryEditor=null;const item=byID(draft.id);if(!item)return false;
  draft.value=draft.input.value;
  if(!cancel&&draft.value!==draft.original){
    rememberSummary(item);
    const values={summary:draft.value};Object.assign(item,bridge.markMetadataEdited(clone(item),values),values);
    summarySearchPending=!!state.query.trim();
    // The unsaved model retains the text if disk commit fails; the existing retry/recovery UI remains available.
    q('[data-save-status]').textContent='尚未保存';
  }
  const container=draft.input.parentElement;if(container?.isConnected)container.innerHTML=summaryMarkup(item);
  detailSignature='';return true;
}
function refreshSummarySearch(){
  if(!summarySearchPending||summaryEditor)return;
  pickVisible();renderList();renderDetail();updateIcons();saveView();
}
// Refilter after the click has selected its target, so a blur-save never removes the clicked row first.
root.addEventListener('click',refreshSummarySearch);
root.addEventListener('keyup',refreshSummarySearch);
function rememberSummary(item){
  const metadata=item.xrefMetadata||{};
  summaryUndo.set(item.id,{summary:item.summary||'',hasApplied:Object.hasOwn(metadata.applied||{},'summary'),applied:metadata.applied?.summary,locked:metadata.locked?.includes('summary')||false,source:metadata.summarySource});
  if(summaryUndo.size>100)summaryUndo.delete(summaryUndo.keys().next().value);
}
function showPaneMenu(pane,x,y){
  if(!paneIDs.includes(pane))return;
  commitSummaryEdit();persist();closeCollectionMenu();
  const menu=q('[data-menu]'),item=selected(),index=state.paneOrder.indexOf(pane);
  const action=(name,label,disabled=false)=>`<button type="button" data-pane-action="${name}" data-pane="${pane}" ${disabled?'disabled':''}>${label}</button>`;
  menu.setAttribute('aria-label','详情分区操作');
  menu.innerHTML=action(state.pinnedPane===pane?'unpin':'pin',state.pinnedPane===pane?'取消固定分区':'固定此分区')+action('up','上移',index===0)+action('down','下移',index===state.paneOrder.length-1)+action('reset','恢复默认顺序');
  if(pane==='summary'&&item){
    menu.innerHTML+='<div class="kb-menu-divider"></div>'+action('edit-summary',item.type==='book'?'编辑简介':'编辑摘要');
    if(summaryUndo.has(item.id))menu.innerHTML+=action('undo-summary','撤销上次摘要修改');
    if(item.type==='paper'&&!item.deleted)menu.innerHTML+='<button type="button" data-summary-action="reread">重新读取摘要…</button><button type="button" data-summary-action="auto">恢复自动更新…</button>';
    menu.innerHTML+=`<div class="kb-menu-source">${escape(summarySourceLabel(item))}</div>`;
  }
  menu.hidden=false;const r=root.getBoundingClientRect();
  menu.style.left=Math.max(5,Math.min(x-r.left,r.width-menu.offsetWidth-5))+'px';menu.style.top=Math.max(5,Math.min(y-r.top,r.height-menu.offsetHeight-5))+'px';menu.querySelector('button:not(:disabled)')?.focus();
}
function performPaneAction(action,pane){
  q('[data-menu]').hidden=true;
  if(action==='edit-summary'){beginSummaryEdit();return;}
  if(action==='undo-summary'){
    const item=selected(),undo=summaryUndo.get(item?.id);if(!undo||!item)return;
    item.summary=undo.summary;
    const metadata=item.xrefMetadata||{},applied={...(metadata.applied||{})},locked=new Set(metadata.locked||[]);
    if(undo.hasApplied)applied.summary=undo.applied;else delete applied.summary;
    if(undo.locked)locked.add('summary');else locked.delete('summary');
    item.xrefMetadata={...metadata,applied,locked:[...locked]};
    if(undo.source)item.xrefMetadata.summarySource=undo.source;else delete item.xrefMetadata.summarySource;
    summaryUndo.delete(item.id);renderDetail();persist();return;
  }
  const position=captureDetailPosition(),index=state.paneOrder.indexOf(pane);
  if(action==='pin'){state.pinnedPane=pane;state.sections[pane]=true;state.activeSection=pane;}
  if(action==='unpin')state.pinnedPane=null;
  if(action==='reset')state.paneOrder=[...paneIDs];
  if(action==='up'||action==='down'){const next=index+(action==='up'?-1:1);if(next>=0&&next<state.paneOrder.length)[state.paneOrder[index],state.paneOrder[next]]=[state.paneOrder[next],state.paneOrder[index]];}
  renderDetail(action==='pin'?{section:pane,offset:0,top:0}:position);updateIcons();persist();
}
async function readSummarySource(mode){
  commitSummaryEdit();if(!await flush())return;
  const item=selected();if(!item||item.type!=='paper'||item.deleted)return;
  const generation=libraryGeneration,id=item.id,initial=item.summary||'',files=JSON.stringify([item.files,item.defaultFile]);
  const result=await bridge.readMetadata([clone(item)]),record=result.records.find(record=>record.id===id);
  if(generation!==libraryGeneration||modal||summaryEditor||state.selected!==id)return;
  const current=byID(id);if(!current||(current.summary||'')!==initial||files!==JSON.stringify([current.files,current.defaultFile]))return;
  if(!record?.fields.summary){notify('未找到可读取的摘要，现有内容已保留。');q('[data-message]').title=result.warnings.join('\n');return;}
  previousFocus=document.activeElement;modal='summary-source';summarySourceDraft={id,generation,initial,files,record,mode};
  const form=q('[data-form]');form.classList.remove('is-relation');
  form.innerHTML=`<header><h3 id="kb-modal-title">${mode==='auto'?'恢复摘要自动更新':'重新读取摘要'}</h3><button type="button" data-do="cancel" aria-label="关闭对话框">${icon('x')}</button></header><label>当前摘要<textarea readonly rows="5">${escape(initial)}</textarea></label><label>${record.summarySource?.kind==='index'?'索引中的摘要':'Markdown 中的摘要'}<textarea readonly rows="5">${escape(record.fields.summary)}</textarea></label><footer><button type="button" class="kb-outline" data-do="cancel">取消</button><button type="button" class="kb-primary" data-do="confirm">${mode==='auto'?'采用并自动更新':'采用此摘要'}</button></footer>`;
  q('[data-shade]').hidden=false;updateIcons();form.querySelector('footer [data-do="cancel"]').focus();
}
async function commitSummarySource(){
  const draft=summarySourceDraft,item=byID(draft?.id);
  if(!draft||!item||draft.generation!==libraryGeneration||item.deleted||(item.summary||'')!==draft.initial||JSON.stringify([item.files,item.defaultFile])!==draft.files){showError('条目已变化，请取消后重新读取摘要。');return;}
  rememberSummary(item);item.summary=draft.record.fields.summary;
  const previous=item.xrefMetadata||{},locked=new Set(previous.locked||[]);
  if(draft.mode==='auto')locked.delete('summary');else locked.add('summary');
  item.xrefMetadata={...previous,version:1,fileId:draft.record.file.id,applied:{...(previous.applied||{}),summary:item.summary},locked:[...locked],summarySource:draft.record.summarySource};
  closeModal();pickVisible();render();persist();await flush();
}

    initializeColumnHandles();normalizePreferences();pickVisible();render();
    q('[data-library]').inert=true;
    for(const button of qa('.kb-top [data-do="new"],.kb-top [data-do="collection"]'))button.disabled=true;
    q('[data-root-label]').textContent='选择知识库目录';
    root.addEventListener('keydown',event=>{if(event.ctrlKey&&event.altKey&&event.code==='KeyK'){event.preventDefault();run(()=>bridge.close());}});
    bridge.ready({translationSelection:()=>state.selected,rememberBookFile,selectItem:async id=>{if(!await flush()||!leaveNotePane())return false;const item=byID(id);if(!item||item.deleted)return false;state.view='all';state.query='';clearItemFilters();state.selected=id;state.checked=[];state.detailCollapsed=false;state.activeSection='related';state.sections.related=true;render();saveView();return true;},load:loadLibrary,refresh,syncMetadata,syncMetrics,onLibraryOpen,onLibraryClose,flush,dirty,webIndexed:()=>{if(!loading&&base)renderList();},importing:()=>!!importToken||purging||merging||!!webDraft?.busy,theme:applyPalette,error:showError,noteSaved:()=>{noteCache.clear();noteRequests.clear();refreshExpandedNotes();if(q('[data-error-text]').textContent==='笔记尚未保存，请重试后再离开。')clearError();},focus:()=>q('[data-search]').focus()});
  })();
  
