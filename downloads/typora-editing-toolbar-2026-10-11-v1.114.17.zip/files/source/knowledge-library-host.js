// Isolated management surface. Typora remains the document editor and owns its save prompts.
class EditingToolbarKnowledgeLibrary {
  constructor(toolbar) {
    this.toolbar = toolbar; this.version = '1.107.0'; this.key = 'et-knowledge-library-root-v1';
    this.quickFileMenu = new KnowledgeLibraryQuickMenu(this);
    this.connector = new ETKnowledgeConnector({requireNode:reqnode,Store:ETKnowledgeStorage,QuickFile:ETKnowledgeQuickFile,Importer:ETKnowledgeImport,Metadata:ETKnowledgeMetadata,Managed:ETKnowledgeManaged,
      root:()=>this.rootPath,getPairs:()=>{try{return JSON.parse(localStorage.getItem('et-library-connector-pairs')||'{}');}catch{return {};}},
      setPairs:pairs=>localStorage.setItem('et-library-connector-pairs',JSON.stringify(pairs)),approve:origin=>this.approveConnector(origin),
      chooseRoot:async expected=>{await this.open();if(!this.ui||!this.store)throw Error('请先打开 Typora 知识库');return this.chooseRoot(expected);},
      changed:()=>{this.graphChanged();if(this.isOpen&&this.store?.root===this.rootPath)this.ui?.refresh().catch(()=>{});this.notice('网页论文已保存到知识库');}
    }).start();
    window.addEventListener('unload',()=>this.connector.close(),{once:true});
    setTimeout(()=>this.graphChanged(),0);
    this.backupUI = new KnowledgeLibraryBackupUI(this);
    const syncBoot=setTimeout(()=>void this.backupUI.boot(),10000);
    window.addEventListener('unload',()=>clearTimeout(syncBoot),{once:true});
    this.onKey = e => { if (e.ctrlKey && e.altKey && e.code === 'KeyK') { e.preventDefault(); e.stopPropagation(); this.toggle(); } };
    document.addEventListener('keydown', this.onKey, true);
    window.addEventListener('beforeunload', e => { if (this.ui?.dirty()) { e.preventDefault(); e.returnValue = ''; } });
    window.addEventListener('focus', () => { if (this.isOpen) this.ui?.refresh().catch(e => this.ui?.error(e.message)); });
    this.bookReadingTimer = setInterval(() => {
      if(this.ui && !File.isFileLoading?.()) this.ui.rememberBookFile(File.bundle?.filePath).catch(e => this.ui?.error(e.message));
    },1500);
    window.addEventListener('unload',()=>clearInterval(this.bookReadingTimer),{once:true});
  }
  get isOpen() { return !!this.overlay && !this.overlay.hidden; }
  get panel() { return this.overlay; }
  get isFullScreen() { return this.isOpen && this.overlay.dataset.layout==='full'; }
  syncWorkspace(mode) {
    const expand=this.overlay?.querySelector('[data-library-expand]');
    if(expand){expand.title=mode==='full'?'还原为小窗':'全屏知识库';expand.setAttribute('aria-label',expand.title);expand.setAttribute('aria-pressed',String(mode==='full'));}
    this.notePane?.schedule();
  }
  approveConnector(origin) {
    return new Promise(resolve=>{
      const layer=document.createElement('div');layer.id='et-library-connector-pair';
      layer.style.cssText='position:fixed;inset:0;z-index:2147483647;background:#0005;display:grid;place-items:center';
      const shadow=layer.attachShadow({mode:'open'}),style=document.createElement('style');
      style.textContent=`*{box-sizing:border-box}.dialog{--surface:#fcfdfc;--ink:#263a32;--muted:#65766e;--line:#d9e3dd;--soft:#edf4ef;--accent:#236b5e;--on:#fff;--ring:#95bdac;width:448px;max-width:90vw;padding:25px;border:1px solid var(--line);border-radius:15px;background:var(--surface);color:var(--ink);font:14px/1.6 "Segoe UI","Microsoft YaHei",sans-serif;box-shadow:0 16px 56px #0003}.dialog.dark{--surface:#242d28;--ink:#e9f0ec;--muted:#b0bfb6;--line:#43534a;--soft:#35443b;--accent:#88cfb4;--on:#132a20;--ring:#8bc6ac}h2{font:600 17px/1.5 "Segoe UI","Microsoft YaHei",sans-serif;margin:0 0 11px}p{margin:0 0 15px}.source{font-size:11px;color:var(--muted);overflow-wrap:anywhere;padding:9px 11px;background:var(--soft);border-radius:6px}.actions{display:flex;justify-content:flex-end;gap:10px;margin-top:21px}button{appearance:none;min-width:88px;min-height:38px;padding:8px 18px;border:1px solid var(--line);border-radius:7px;background:var(--surface);color:var(--ink);font:500 14px/1.4 "Segoe UI","Microsoft YaHei",sans-serif;cursor:pointer;box-shadow:none}button:hover{background:var(--soft);border-color:var(--ring)}button.primary{background:var(--accent);color:var(--on);border-color:var(--accent)}button.primary:hover{filter:brightness(.94)}button:focus-visible{outline:2px solid var(--ring);outline-offset:3px}`;
      const box=document.createElement('div');box.className='dialog'+(this.theme().dark?' dark':'');box.setAttribute('role','dialog');box.setAttribute('aria-modal','true');box.setAttribute('aria-label','连接浏览器扩展');
      const title=document.createElement('h2');title.textContent='允许浏览器连接知识库？';
      const text=document.createElement('p');text.textContent='连接后，此扩展可以读取分类、保存论文和切换知识库目录。';
      const source=document.createElement('p');source.className='source';source.textContent='扩展 ID：'+origin.split('//')[1];
      const actions=document.createElement('div');actions.className='actions';const previous=document.activeElement;
      let timer;const finish=value=>{clearTimeout(timer);layer.remove();previous?.focus?.();resolve(value);};
      for(const [label,value] of [['取消',false],['允许连接',true]]){const b=document.createElement('button');b.type='button';b.textContent=label;if(value)b.className='primary';b.onclick=e=>{if(e.isTrusted)finish(value);};actions.append(b);}
      shadow.addEventListener('keydown',e=>{if(!e.isTrusted)return;if(e.key==='Escape'){e.preventDefault();e.stopPropagation();finish(false);}if(e.key==='Tab'){e.preventDefault();(shadow.activeElement===actions.firstChild?actions.lastChild:actions.firstChild).focus();}});
      box.append(title,text,source,actions);shadow.append(style,box);document.body.append(layer);timer=setTimeout(()=>finish(false),90000);actions.firstChild.focus();
    });
  }
  get rootPath() {
    const path = reqnode('path');
    return localStorage.getItem(this.key) || path.join(File.option.documentsPath || path.join(reqnode('os').homedir(), 'Documents'), 'Typora知识库');
  }
  notice(text) { this.toolbar._showToolbarNotice(text); }
  async toggle() { if (this.isFullScreen) await this.close(); else {if(!this.overlay)this.mount();this.toolbar.panelWorkspace?.ensure(this);this.toolbar.panelWorkspace?.full('library');await this.open();} }
  async open() {
    this.quickFileMenu.close();
    if (this.opening || this.isOpen) return; this.opening = true;
    try {
      if (typeof reqnode !== 'function' || !window.File?.editor) throw new Error('编辑器尚未就绪，请稍后重试。');
      if (!this.overlay) this.mount();
      this.overlay.hidden = false; this.toolbar.hide(); this.frame.focus();
      this.toolbar.panelWorkspace?.opened(this);
      if (!this.store) await this.switchRoot(this.rootPath, false);
      else {await this.ui.refresh();void this.web.prepareIndex((await this.store.read()).data.items).then(()=>this.ui?.webIndexed?.()).catch(()=>{});}
      this.syncTheme(); if(this.isOpen){this.ui.focus();this.ui.onLibraryOpen();}
    } catch (e) { this.ui?.error(e.message); this.notice('知识库：' + e.message); }
    finally { this.opening = false; }
  }
  async close() {
    if (this.ui?.importing()) { this.notice('正在导入文件，请等待完成或点击取消。'); return false; }
    if (!this.isOpen || !await this.ui.flush()) return false;
    this.overlay.hidden = true; this.cnkiBrowser?.cancel(); this.ui.onLibraryClose(); this.toolbar.panelWorkspace?.closed(this);this.toolbar.topChrome?.querySelector('[data-action="knowledge-library"]')?.focus(); return true;
  }
  mount() {
    this.notePane = new KnowledgeLibraryNotePane(this);
    this.overlay = document.createElement('div'); this.overlay.id = 'et-knowledge-library-overlay';
    this.overlay.hidden=true;
    this.overlay.setAttribute('role', 'dialog'); this.overlay.setAttribute('aria-label', '个人知识库');
    const header=document.createElement('header');header.className='et-library-window-header';
    header.innerHTML='<strong><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3 4h4v16H3zM10 4h4v16h-4zM17 4l4 1-1 15-4-1z"/></svg>知识库</strong><button type="button" data-library-expand aria-label="全屏知识库" title="全屏知识库"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/></svg></button><button type="button" data-library-close aria-label="关闭知识库" title="关闭知识库"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="m6 6 12 12M18 6 6 18"/></svg></button>';
    header.querySelector('[data-library-expand]').onclick=()=>{const w=this.toolbar.panelWorkspace;if(w.entries.get('library')?.mode==='full'){w.float('library');w.persist();}else w.full('library');};
    header.querySelector('[data-library-close]').onclick=()=>void this.close();
    this.frame = document.createElement('iframe'); this.frame.id = 'et-knowledge-library-frame'; this.frame.title = '个人知识库';
    this.overlay.append(header,this.frame); document.body.append(this.overlay);
    const d = this.frame.contentDocument;
    d.open(); d.write('<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; script-src \'unsafe-inline\'; style-src \'unsafe-inline\'; img-src data:; connect-src \'none\'"></head><body>' + ET_KNOWLEDGE_HTML + '</body></html>'); d.close();
    const style = d.createElement('style'); style.textContent = ET_KNOWLEDGE_CSS; d.head.append(style);
    this.frame.contentWindow.KnowledgeLibraryBridge = {
      workspace:true,
      webCapture:(url,options)=>this.web.capture(url,options),webSave:async(base,request,options)=>{const result=await this.web.save(base,request,options);this.graphChanged();return result;},webModified:item=>this.web.modified(item),webConvert:(base,id)=>this.web.convert(base,id),
      webIndex:async()=>{await this.web.prepareIndex((await this.store.read()).data.items);},webHasTerm:(id,term)=>this.web?.hasTerm(id,term)||false,webText:id=>this.web?.searchText(id)||'',webSnippet:(id,query)=>this.web?.snippet(id,query)||'',
      webActivity:before=>{const turn={status:'running'},doc=before.ownerDocument,ai={node:(tag,cls='',text)=>{const e=doc.createElement(tag);e.className=cls;if(text!==undefined)e.textContent=text;return e;}};EditingToolbarTaskTiming.begin(turn);const view=new EditingToolbarTaskProgress(ai,turn,before);return {turn,update:()=>view.update(),finish:status=>{turn.status=status;EditingToolbarTaskTiming.finish(turn);view.update();},remove:()=>view.root.remove()};},
      webImport:async()=>{const picked=await JSBridge.invoke('dialog.showOpenDialog',{title:'导入网页 Markdown',properties:['openFile'],filters:[{name:'Markdown',extensions:['md','markdown']}]});const file=picked?.filePaths?.[0];if(!file)return null;await new ETKnowledgeManaged(this.store).regular(file);if((await this.store.io.stat(file)).size>4*1024*1024)throw Error('Markdown 文件超过 4 MB');return {sourceFile:file,markdown:await this.store.io.readFile(file,'utf8')};},
      copyText:text=>reqnode('electron').clipboard.writeText(String(text)),
      ready: ui => { this.ui = ui; },
      commit: async (base, next) => {const saved=await this.store.commit(base,next);this.graphChanged();return saved;},
      duplicateGroups: items => ETKnowledgeDuplicates.groups(items),
      orderCollections: collections => ETKnowledgeStorage.orderCollections(collections),
      mergeDescription: (items, master) => ETKnowledgeDuplicates.describe(items,master),
      mergeDuplicates: async (base, request) => {
        if(!this.notePane.flush())throw Error('笔记尚未保存，请先完成保存。');this.notePane.close();
        const result=await new ETKnowledgeDuplicates(this.store).merge(base,request);this.graphChanged();return result;
      },
      purge: async (base, request) => {
        const store=this.store;if(!this.notePane.flush())throw Error('笔记尚未保存，请先完成保存。');this.notePane.close();
        const service=new ETKnowledgePurge(store,{Managed:ETKnowledgeManaged,blockedPaths:()=>[File.bundle?.filePath]});
        const result=await service.remove(base,request);this.graphChanged();return result;
      },
      read: () => this.store.read(), merge: (...args) => ETKnowledgeStorage.merge(...args),
      readMetadata: items => this.metadata.readItems(items), applyMetadata: (item, record) => ETKnowledgeMetadata.apply(item, record), markMetadataEdited: (item, values) => ETKnowledgeMetadata.markEdited(item, values), automaticTags: item => ETKnowledgeMetadata.automaticTags(item),
      authorAssociation: item => ETKnowledgeMetadata.authorAssociationView(item),
      openResourceURL: url => reqnode('electron').shell.openExternal(ETKnowledgeStorage.webURL(url)),
      changeItemType: (item, type, losses, supported, previousSupported) => ETKnowledgeMetadata.changeType(item, type, losses, supported, previousSupported),
      normalizeISBN: value => ETKnowledgeISBN.normalize(value), lookupISBN: value => this.lookupISBN(value),
      metricsSettings: () => this.metricsSettings(), metricSecret: () => this.metricsSettings(true).secretKey||'', saveMetricsSettings: value => this.saveMetricsSettings(value), metricsActive: () => this.isOpen,
      semanticSecret: () => this.metricsSettings(true).semanticKey||'',
      impactFields: () => ({...ETKnowledgeMetrics.impactFields}), selectImpact: (settings,field) => ETKnowledgeMetrics.selectImpact(settings,field),
      openCNKI: () => {this.toolbar.panelWorkspace?.finish(true);this.cnkiBrowser ||= new KnowledgeLibraryCNKIBrowser(this);return this.cnkiBrowser.show();},
      verifyCNKI: () => {if(!this.isOpen)return Promise.resolve(false);this.toolbar.panelWorkspace?.finish(true);this.cnkiBrowser ||= new KnowledgeLibraryCNKIBrowser(this);return this.cnkiBrowser.waitForVerification();},
      readMetrics: (items, options) => this.metrics.readItems(items, options), metricsEligible: item => ETKnowledgeMetrics.eligible(item), metricIdentity: item => ETKnowledgeMetrics.identity(item), metricValues: item => ETKnowledgeMetrics.view(item,this.metricsSettings()),
      mergeMetric: (old,value) => ETKnowledgeMetrics.mergeRecord(old,value), compareJournal: (a,b,direction) => ETKnowledgeMetrics.compareJournal(a,b,this.metricsSettings(),direction), compareCitations: (a,b,direction) => ETKnowledgeMetrics.compareCitations(a,b,this.metricsSettings(),direction), metricsDefaults: () => ({...ETKnowledgeMetrics.defaults}), citationFields: () => [...ETKnowledgeMetrics.citationFields], citationColor: (field,colors) => ETKnowledgeMetrics.citationColor(field,colors), citationIdentity: item => ETKnowledgeMetrics.citationIdentity(item),
      openMetricKeyPage: source => reqnode('electron').shell.openExternal(source==='semantic'?'https://www.semanticscholar.org/product/api':'https://www.easyscholar.cc/blogs/10009'),
      preferences: () => this.preferences(), savePreferences: value => this.savePreferences(value),
      theme: () => this.theme(), setTheme: id => this.setTheme(id), randomTheme: () => this.toolbar.themePalette?.randomize(),
      chooseRoot: () => this.chooseRoot(), revealRoot: () => reqnode('electron').shell.openPath(this.store?.root||this.rootPath), close: () => this.close(), root: () => this.store?.root || this.rootPath,
      chooseFiles: () => this.chooseFiles(), currentFile: () => this.currentFile(),
      chooseLibraryArchive: async exporting=>{
        const picked=await JSBridge.invoke('dialog.showOpenDialog',exporting?{title:'选择知识库导出位置',properties:['openDirectory','createDirectory']}:{title:'导入知识库',properties:['openFile'],filters:[{name:'知识库导出包',extensions:['zip']}]});
        return picked?.filePaths?.[0]||null;
      },
      transferLibrary:(exporting,file,progress)=>this.transferLibrary(exporting,file,progress),
      driveBackup:()=>this.openDriveBackup(),
      chooseBookFolder: async () => {
        const picked=await JSBridge.invoke('dialog.showOpenDialog',{title:'导入整本 Markdown 书籍（复制到知识库）',properties:['openDirectory']});
        return picked?.filePaths?.[0]||null;
      },
      importBook: (folder,collectionId,progress) => this.importBook(folder,collectionId,progress),
      sameFile: (ref,file) => !!file && this.store.resolveFile(ref).toLowerCase()===this.store.path.resolve(file).toLowerCase(),
      droppedPaths: files => this.droppedPaths(files), scanDrop: (paths, existing, progress) => this.scanDrop(paths, existing, progress), cancelScan: () => this.dropAbort?.abort(),
      discardDrop: result => new ETKnowledgeManaged(this.store).rollback(result?.prepared||[]),
      urlRef: (url,title) => this.store.urlRef(url,title), revealFile: file => this.revealFile(file),
      beginRead: () => this.beginRead(),
      openFile: file => this.openFile(file), noteList: item => this.noteList(item), openNote: (file, kind, id, create) => this.openNote(file, kind, id, create),
      deleteNote: (file, kind, id) => this.deleteNote(file, kind, id),
      openNotePane: (file, id, create) => this.notePane.open(file, id, create),
      closeNotePane: () => this.notePane.close(), flushNotePane: () => this.notePane.flush(),
      layoutNotePane: surface => this.notePane.schedule(surface),
      relink: file => this.relink(file), recovery: data => this.recovery(data),
    };
    const script = d.createElement('script'); script.textContent = ET_KNOWLEDGE_UI; d.head.append(script);
    this.frame.contentDocument.addEventListener('pointerdown',()=>this.toolbar.panelWorkspace?.focus(this.toolbar.panelWorkspace.entries.get('library')),true);
    this.toolbar.panelWorkspace?.ensure(this);
    this.frame.contentWindow.addEventListener('error', e => { console.error('[EditingToolbar] Knowledge library:', e.error || e.message); this.ui?.error(e.message); });
    const paletteStyle = this.toolbar.themePalette?.style;
    if (paletteStyle) { this.themeObserver = new MutationObserver(() => this.syncTheme()); this.themeObserver.observe(paletteStyle, { childList: true, characterData: true, subtree: true }); }
  }
  graphChanged() { document.dispatchEvent(new CustomEvent('et-library-relations-changed')); }
  async graphSnapshot() {
    const store = this.store || new ETKnowledgeStorage(this.rootPath, reqnode);
    const result = await store.read();
    return ETKnowledgeGraph.project(store, result?.data);
  }
  mergeGraph(index, snapshot) { return ETKnowledgeGraph.merge(index, snapshot); }
  async openGraphItem(id) { await this.open(); if(this.ui)await this.ui.selectItem(id); }
  preferences() { try { return JSON.parse(localStorage.getItem('et-knowledge-library-ui:' + this.store.root)) || {}; } catch (_) { return {}; } }
  metricsSettings(privateValues=false) {
    let saved={};try{saved=JSON.parse(localStorage.getItem('et-knowledge-metrics-settings-v1'))||{};}catch(_){}
    if(saved.citationSchema!==2){
      if(saved.citationFields==='Total(DOI)')saved.citationFields=ETKnowledgeMetrics.defaults.citationFields;
      if(saved.citationMap==='Total(DOI)=Crossref')saved.citationMap=ETKnowledgeMetrics.defaults.citationMap;
      if(saved.citationSortBy==='Total(DOI)')saved.citationSortBy=ETKnowledgeMetrics.defaults.citationSortBy;
      if(saved.citationColors==='#ffe2dd')saved.citationColors=ETKnowledgeMetrics.defaults.citationColors;
      saved.citationSchema=2;localStorage.setItem('et-knowledge-metrics-settings-v1',JSON.stringify(saved));
    }
    const settings={...ETKnowledgeMetrics.defaults,...saved,useZotero:false};
    settings.hasKey=!!String(settings.secretKey||'').trim();settings.keySource=settings.hasKey?'本插件':'';
    settings.hasSemanticKey=!!String(settings.semanticKey||'').trim();
    if(!privateValues){delete settings.secretKey;delete settings.semanticKey;}return settings;
  }
  saveMetricsSettings(value) {
    let saved={};try{saved=JSON.parse(localStorage.getItem('et-knowledge-metrics-settings-v1'))||{};}catch(_){}
    for(const field of ['fields','aliases','impactField','rankColors','map','defaultColor','textColor','sortBy','citationFields','citationMap','citationColors','citationTextColor','citationSortBy'])if(typeof value[field]==='string')saved[field]=value[field].slice(0,4000);
    for(const prefix of ['', 'citation'])for(const [name,min,max] of [['opacity',0.1,1],['margin',0,12],['padding',0,16]]){const key=prefix?prefix+name[0].toUpperCase()+name.slice(1):name;if(value[key]!==undefined&&Number.isFinite(Number(value[key])))saved[key]=Math.max(min,Math.min(max,Number(value[key])));}
    for(const field of ['automatic'])if(typeof value[field]==='boolean')saved[field]=value[field];
    if(typeof value.secretKey==='string'&&value.secretKey.trim())saved.secretKey=value.secretKey.trim().slice(0,256);
    if(value.clearKey)delete saved.secretKey;
    if(typeof value.semanticKey==='string'){
      const next=value.semanticKey.trim().slice(0,256);
      if(next!==String(saved.semanticKey||'')){this.metrics?.serviceFailures?.delete('api.semanticscholar.org');this.metrics?.serviceRateLimits?.delete('api.semanticscholar.org');for(const key of this.metrics?.failures?.keys()||[])if(key.startsWith('s2:'))this.metrics.failures.delete(key);}
      if(next)saved.semanticKey=next;else delete saved.semanticKey;
    }
    localStorage.setItem('et-knowledge-metrics-settings-v1',JSON.stringify(saved));return this.metricsSettings();
  }
  savePreferences(value) { try { localStorage.setItem('et-knowledge-library-ui:' + this.store.root, JSON.stringify(value)); } catch (_) { /* Library data is independently saved on disk. */ } }
  webService(store=this.store){const net=new ETAIWeb(reqnode);return new ETKnowledgeWeb(store,{Managed:ETKnowledgeManaged,Execution:ETAIExecution,fetch:(url,{signal,image}={})=>net.fetch(url,signal,0,{image}),extract:(html,url)=>ETWebExtractor.extract(html,url),activeSource:path=>{try{if(String(File.bundle?.filePath||'').toLowerCase()===path.toLowerCase())return File.editor.getMarkdown();}catch{}return null;}});}
  async switchRoot(root, remember = true) {
    const candidate = new ETKnowledgeStorage(root, reqnode);await candidate.open();
    const deletionWarning=await new ETKnowledgePurge(candidate,{Managed:ETKnowledgeManaged}).recover();
    const result=await candidate.read();
    if(deletionWarning)result.warning=[result.warning,deletionWarning].filter(Boolean).join('；');
    if (remember) localStorage.setItem(this.key, candidate.root);
    if(this.metrics)this.metrics.stopped=true;this.cnkiBrowser?.cancel();
    this.store = candidate; this.web=this.webService(candidate); this.metadata = new ETKnowledgeMetadata(candidate); this.metrics=new ETKnowledgeMetrics(candidate,{requireNode:reqnode,fetch:window.fetch.bind(window),lookupISBN:value=>this.lookupISBN(value),parseHTML:html=>new DOMParser().parseFromString(html,'text/html'),cnkiRequest:(url,options)=>{this.cnkiBrowser ||= new KnowledgeLibraryCNKIBrowser(this);return this.cnkiBrowser.request(url,options);},settings:()=>this.metricsSettings(true)});this.ui.load(result.data, this.preferences(), result.warning || ''); this.syncTheme();
    this.graphChanged();
    void this.web.prepareIndex(result.data.items).then(()=>this.ui?.webIndexed?.()).catch(()=>{});
    await this.ui.syncMetadata();
    if(this.isOpen&&!this.opening)this.ui.onLibraryOpen();
    void this.backupUI.prepare(candidate).catch(e=>this.notice('云端同步：'+e.message));
    return result;
  }
  async chooseRoot(expectedRoot) {
    if(this.backupUI?.busy)throw Error('请先完成或取消备份，再切换知识库。');
    if(this.ui?.importing())throw Error('正在导入文件，请完成后再切换知识库。');
    if (this.ui && !await this.ui.flush()) return false;
    if(typeof expectedRoot==='string'&&this.rootPath!==expectedRoot)throw Error('知识库已切换，请刷新后重试。');
    const picked = await JSBridge.invoke('dialog.showOpenDialog', { title: '选择知识库目录（切换目录，不搬动现有文库）', properties: ['openDirectory', 'createDirectory'] });
    if(!picked?.filePaths?.[0])return false;
    if(typeof expectedRoot==='string'&&this.rootPath!==expectedRoot)throw Error('知识库已切换，请刷新后重试。');
    await this.switchRoot(picked.filePaths[0]);return true;
  }
  theme() {
    const palette = this.toolbar.themePalette, s = palette?.draft || palette?.state;
    const catalog = palette?.catalog(s) || { default: { name: '原主题' } };
    const colors = palette?.colors(s);
    const style = getComputedStyle(document.body), html = getComputedStyle(document.documentElement);
    const bg = style.backgroundColor === 'rgba(0, 0, 0, 0)' ? html.backgroundColor : style.backgroundColor, text = style.color;
    return { colors, tokens: palette?.tokens(s), dark: palette?.mode(s) === 'dark', native: { bg, text }, id: palette?.selectedId(s) || 'default', catalog: Object.entries(catalog).filter(([id,p])=>!palette||palette.supports(p,palette.mode(s))).map(([id, p]) => ({ id, name: p.name })) };
  }
  syncTheme() { this.ui?.theme(); }
  setTheme(id) {
    const palette = this.toolbar.themePalette; if (!palette || !Object.hasOwn(palette.catalog(palette.state), id)) return;
    const next = palette.normalize(palette.selectionState(id));
    localStorage.setItem(palette.key, JSON.stringify(next)); palette.state = next; palette.apply(); this.syncTheme();
  }
  async chooseFiles() {
    const picked = await JSBridge.invoke('dialog.showOpenDialog', { title: '关联文献、书籍或 Markdown 章节', properties: ['openFile', 'multiSelections'], filters: [{ name: '阅读材料', extensions: ['md', 'markdown', 'mdown', 'txt', 'pdf', 'epub'] }, { name: '所有文件', extensions: ['*'] }] });
    const files = [];
    for (const file of picked?.filePaths || []) { if (!(await this.store.io.stat(file)).isFile()) continue; files.push(await new ETKnowledgeManaged(this.store).prepare(this.store.fileRef(file))); }
    return files;
  }
  async openDriveBackup(){
    await this.open();if(!this.store||!this.ui)throw Error('请先打开知识库');
    if(this.ui.importing())throw Error('请先完成文件导入');
    this.backupUI ||= new KnowledgeLibraryBackupUI(this);return this.backupUI.show();
  }
  flushBackupNotes(){
    if(this.notePane&&!this.notePane.flush())throw Error('笔记尚未保存，请先完成保存');
    for(const manager of [this.toolbar.documentNotes,this.toolbar.annotations,this.toolbar.manualMarks]){
      manager?._flushEditor?.();for(const ctx of manager?.contexts?.values?.()||[])if(ctx.dirty&&!manager._save(ctx))throw Error('笔记尚未保存，请先完成保存');
    }
  }
  async transferLibrary(exporting,file,onProgress){
    if(this.dropAbort)throw Error('已有文件操作正在进行');
    this.flushBackupNotes();
    const controller=this.dropAbort=new AbortController(),store=this.store;
    try{
      const service=new ETKnowledgeArchive(store,{Managed:ETKnowledgeManaged,Zip:ETKnowledgeZip});
      const result=await service[exporting?'export':'import'](file,{signal:controller.signal,onProgress});
      if(!exporting)this.graphChanged();return result;
    }finally{if(this.dropAbort===controller)this.dropAbort=null;}
  }
  async importBook(folder,collectionId,progress){
    if(this.dropAbort)throw Error('上一批文件还在导入中。');
    const controller=this.dropAbort=new AbortController(),store=this.store;
    try{
      const result=await this.bookService(store).importFolder(folder,{collectionId,signal:controller.signal,onProgress:progress});
      this.graphChanged();return result;
    }finally{if(this.dropAbort===controller)this.dropAbort=null;}
  }
  lookupISBN(isbn){
    this.isbn ||= new ETKnowledgeISBN({requireNode:reqnode,parseHTML:html=>new DOMParser().parseFromString(html,'text/html')});return this.isbn.lookup(isbn);
  }
  bookService(store=this.store){
    return new ETKnowledgeBook(store,{Managed:ETKnowledgeManaged,ISBN:ETKnowledgeISBN,Metadata:ETKnowledgeBookMetadata,lookupISBN:isbn=>this.lookupISBN(isbn)});
  }
  async currentFile() {
    const file = File.bundle?.filePath;
    if (!file || !this.store.path.isAbsolute(file)) throw new Error('请先保存当前 Markdown，再将它加入知识库。');
    if (!(await this.store.io.stat(file)).isFile()) throw new Error('当前文件不存在。');
    return this.store.fileRef(file);
  }
  droppedPaths(files) {
    const webUtils = reqnode('electron').webUtils, paths = [];
    for (const file of files) {
      const path = webUtils?.getPathForFile ? webUtils.getPathForFile(file) : file.path;
      if (!path) throw new Error('未能读取拖入文件的位置，请从 Windows 文件资源管理器拖入本地文件或文件夹。');
      paths.push(path);
    }
    return paths;
  }
  async scanDrop(paths, existing, progress) {
    if (this.dropAbort) throw new Error('上一批文件还在识别中，请稍后重试。');
    const controller = this.dropAbort = new AbortController(), store = this.store, managed = new ETKnowledgeManaged(store), prepared = [];
    try {
      const book=this.bookService(store),result = await new ETKnowledgeImport(store).scan(paths, existing, { signal: controller.signal, onProgress: progress, detectBook:(file,options)=>book.inspect(file,options) });
      const metadata = this.metadata;
      progress('正在读取文献元数据…');
      for (const entry of result.files) {
        if (controller.signal.aborted) { const error = new Error('已取消导入'); error.name = 'AbortError'; throw error; }
        if(entry.kind==='book'){
          if(!entry.existingId){
            const copy=await book.prepareFolder(entry.book.folder,{signal:controller.signal,detected:entry.book,onProgress:progress});
            entry.item=copy.item;entry.file=copy.ref;prepared.push(copy.ref);
            for(const warning of copy.warnings){result.warningCount++;if(result.warnings.length<6)result.warnings.push(entry.title+'：'+warning);}
          }
          continue;
        }
        if(!entry.existingId){progress('正在托管文档及配套资源：'+entry.file.name);entry.file=await managed.prepare(entry.file,{signal:controller.signal});prepared.push(entry.file);}
        try { entry.metadata = await metadata.readFile(entry.file); for (const warning of entry.metadata?.warnings || []) { result.warningCount++; if (result.warnings.length < 6) result.warnings.push(entry.file.name + '：' + warning); } }
        catch (error) { result.warningCount++; if (result.warnings.length < 6) result.warnings.push(entry.file.name + '：' + error.message); }
      }
      if (this.store !== store) throw new Error('知识库目录已切换，请在新文库重新拖入。');
      result.prepared=prepared;return result;
    } catch(error){await managed.rollback(prepared);throw error;} finally { if (this.dropAbort === controller) this.dropAbort = null; }
  }
  async relink(file) {
    const picked = await JSBridge.invoke('dialog.showOpenDialog', { title: '重新定位：' + file.name, properties: ['openFile'] });
    if (!picked?.filePaths?.[0]) return null;
    const ref = this.store.fileRef(picked.filePaths[0], file.kind); return { ...ref, id: file.id };
  }
  beginRead() {
    const overlay=this.overlay,visibility=overlay?.style.visibility;
    if(overlay)overlay.style.visibility='hidden';
    // Keep the surface yielded through native switching AND metadata persistence.
    // The caller closes it before release on success; errors/cancellation reveal it.
    return ()=>{if(overlay)overlay.style.visibility=visibility;};
  }
  async openFile(file) {
    if(file.linkType==='url'){await reqnode('electron').shell.openExternal(ETKnowledgeStorage.webURL(file.path));return true;}
    const target = this.store.resolveFile(file);
    if (!(await this.store.io.stat(target).catch(() => null))?.isFile()) throw new Error('找不到附件，请在“附件”分区点击“重新定位”：' + target);
    const extension = this.store.path.extname(target).toLowerCase();
    if (!['.md', '.markdown', '.mdown', '.txt', '.pdf', '.epub', '.png', '.jpg', '.jpeg'].includes(extension)) throw new Error('此文件类型请从系统文件管理器打开。');
    if (['.md', '.markdown', '.mdown', '.txt'].includes(extension)) {
      const same = () => this.store.path.resolve(File.bundle?.filePath || '.').toLowerCase() === target.toLowerCase();
      if (!same()) {
        await this.switchDocument(target,same);
      }
    } else { File.editor.tryOpenUrl(target); }
    return true;
  }
  nativeOpenBlock() {
    // Native guards are owned by Typora. Never clear them or bypass licensing.
    if(window._nos)return 'Typora 暂未允许打开文档。请在“帮助 → 我的许可证”检查激活状态；激活 Typora 后重试，若仍被拦截请重启 Typora。启用插件不等于激活 Typora。';
    if(File.isBroken)return 'Typora 编辑器尚未就绪，请重启 Typora 后重试。';
    if(File._onInitParse||File._onFileSwitching||File.editor.library._onSwitchDocumentTarget)return 'Typora 正在加载或切换文档，请稍后重试。';
    return '';
  }
  nativeSaveDialogVisible() {
    const dialog=document.querySelector('#common-dialog');
    return !!dialog&&!dialog.hidden&&getComputedStyle(dialog).display!=='none'&&getComputedStyle(dialog).visibility!=='hidden';
  }
  async switchDocument(target,same) {
    if(this.switchingDocument)throw Error('正在打开文档，请稍候。');
    const blocked=this.nativeOpenBlock();if(blocked)throw Error(blocked);
    this.switchingDocument=true;
    const overlay=this.overlay,visibility=overlay?.style.visibility;
    // Yield the entire surface, including its iframe, to native Save/Discard/Cancel.
    if(overlay)overlay.style.visibility='hidden';
    try{
      while(this.nativeSaveDialogVisible())await new Promise(r=>setTimeout(r,100));
      const blocked=this.nativeOpenBlock();if(blocked)throw Error(blocked);
      this.toolbar.readingPosition?.cancelRestore();
      File.editor.library.openFile(target);
      let idle=0,sawDialog=false;
      while(!same()){
        if(window._nos)throw Error(this.nativeOpenBlock());
        if(File.isBroken)throw Error(this.nativeOpenBlock());
        const dialog=this.nativeSaveDialogVisible();sawDialog ||=dialog;
        if(dialog)idle=0;
        else if(++idle>=100)throw Error(sawDialog?'文档未切换，操作可能已取消。可重试打开。':'Typora 未完成文档切换。请稍后重试，或重启 Typora。');
        await new Promise(r=>setTimeout(r,100));
      }
    }finally{
      if(overlay)overlay.style.visibility=visibility;
      this.switchingDocument=false;
    }
  }
  async noteList(item) {
    const result = [], warnings = [];
    for (const file of item.files) {
      if(file.linkType==='url')continue;
      const target = this.store.resolveFile(file); if (!/\.(md|markdown|mdown|txt)$/i.test(target)) continue;
      for (const [kind, manager] of [['笔记', this.toolbar.documentNotes], ['注释', this.toolbar.annotations], ['标注', this.toolbar.manualMarks]]) {
        try {
          let notes;
          if (manager?.contexts?.has(target)) { if(manager.ctx?.key===target)manager._flushEditor(); notes = manager.contexts.get(target).notes; }
          else {
            let raw = await this.store.readOptional(this.store.path.join(target + '.资料', kind, 'index.json'));
            if (raw === null) raw = await this.store.readOptional(this.store.path.join(target + '.' + kind, 'index.json'));
            if (raw === null) continue;
            const data = JSON.parse(raw.replace(/^\uFEFF/, '')); if (data.version !== 1 || !Array.isArray(data.notes)) throw new Error('索引格式不受支持'); notes = data.notes;
          }
          for (const n of notes) if (typeof n.id === 'string' && typeof n.markdown === 'string') result.push({ id: n.id, kind, fileId: file.id, title: n.title || n.anchor?.exact?.slice(0,60) || kind, text: n.markdown.slice(0, 240) });
        } catch (e) { warnings.push(file.name + ' / ' + kind + '：' + e.message); }
      }
    }
    return { notes: result, warnings };
  }
  async revealFile(file){
    const target=this.store.resolveFile(file);
    if(!(await this.store.io.stat(target).catch(()=>null))?.isFile())throw Error('找不到附件，请先重新定位文件');
    reqnode('electron').shell.showItemInFolder(target);return true;
  }
  async openNote(file, kind = '笔记', id, create = false) {
    if (file.linkType==='url'||!/\.(md|markdown|mdown|txt)$/i.test(file.path)) throw new Error('请先关联一个 Markdown 文件，用于保存文档笔记。');
    await this.openFile(file);
    const manager = kind === '注释' ? this.toolbar.annotations : kind === '标注' ? this.toolbar.manualMarks : this.toolbar.documentNotes;
    if (!manager) throw new Error('笔记模块尚未加载，请稍后再试。');
    manager._switchDocument();const wasVirgin=manager.ctx?.virgin;manager.open();
    if(create&&!wasVirgin)manager.newNote();
    if (id) { if (manager.selectNote) manager.selectNote(id); else { manager._select(id); manager._locate?.(); } }
    return true;
  }
  async deleteNote(file, kind, id) {
    if(kind!=='笔记'||typeof id!=='string'||!id||file.linkType==='url'||!/\.(md|markdown|mdown|txt)$/i.test(file.path))throw Error('无法删除此笔记');
    const manager=this.toolbar.documentNotes;
    if(!manager)throw Error('笔记模块尚未加载，请稍后再试');
    const path=this.store.resolveFile(file);
    const closePane=this.notePane?.manager===manager&&manager.ctx?.key?.toLowerCase()===path.toLowerCase()&&manager.ctx.selected===id;
    manager.deleteStoredNote(path,id);
    return {closePane};
  }
  async recovery(data) {
    const file = this.store.path.join(this.store.root, '未保存修改-' + Date.now() + '.json');
    await this.store.atomic(file, JSON.stringify(data, null, 2)); return file;
  }
}
