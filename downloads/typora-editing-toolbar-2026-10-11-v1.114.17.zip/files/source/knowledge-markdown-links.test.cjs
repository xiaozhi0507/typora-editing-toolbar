'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),path=require('node:path');
const Managed=require('./knowledge-library-managed.cjs');
test('TeX bracket products are not files, including inline, display and alternate delimiters',()=>{
  const formula=String.raw`[\rho_{700}](\frac{\rho_{700}}{\rho_{670}})`;
  for(const text of ['$'+formula+'$', '$$\n'+formula+'\n\n+1\n$$', '\\('+formula+'\\)', '\\[\n'+formula+'\n\\]']){
    assert.deepEqual(Managed.links('Before '+(text.startsWith('$$')?'\n\n':'')+text+'\n\n![actual](images/plot.png)'),['images/plot.png'],text);
  }
});
test('literal code, escaped syntax and incomplete link-like prose are ignored',()=>{
  assert.deepEqual(Managed.links('`[sample](C:/example.md)`\n\n~~~md\n[x](D:/example.md)\n~~~\n\n    [sample](C:/example.md)\n\nonly ](missing.md)\n\n\\[sample](missing.md)'),[]);
});
test('real resources survive math and include nested names, reference links, HTML media and dollar names',()=>{
  const text=String.raw`$[x](\frac{a}{b})$ [chapter](chapter(2).md) ![pic](<images/a b.png>) [ref][two]

[two]: chapters/二.md
[unused]: appendix.md

<img src="images/a.png?x=1&amp;y=2">

[dollar](assets/$price$.md)`;
  const links=Managed.links(text).map(x=>decodeURIComponent(x));
  for(const link of ['chapter(2).md','images/a b.png','chapters/二.md','appendix.md','images/a.png?x=1&y=2','assets/$price$.md'])assert(links.includes(link),link);
  assert.equal(links.length,6);
});
test('real absolute links remain blocked including percent encoded Windows paths',()=>{
  const managed=new Managed({path:path.win32,root:'C:\\library'});
  for(const text of ['[x](C:/notes/x.md)','![x](file:///C:/x.png)','[x](C%3A%2Fnotes%2Fx.md)','[x](%5Croot%5Cx.md)']){
    const links=Managed.links(text);assert.equal(links.length,1);assert.throws(()=>managed.localLink(links[0],'C:\\library'),/绝对本地链接/);
  }
});
