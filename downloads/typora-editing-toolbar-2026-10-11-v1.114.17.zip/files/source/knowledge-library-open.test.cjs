'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
function fixture(){
  const state={blocked:false,ticks:0,calls:0,dialog:false};
  const File={bundle:{filePath:'C:/old.md'},editor:{library:{openFile(target){state.calls++;assert.equal(host.overlay.style.visibility,'hidden');File.bundle.filePath=target;}}}};
  const window={};Object.defineProperty(window,'_nos',{get:()=>state.blocked});
  const sandbox={File,window,document:{querySelector:()=>state.dialog?{hidden:false}:null},getComputedStyle:()=>({display:'block',visibility:'visible'}),setTimeout:cb=>{state.ticks++;state.tick?.();queueMicrotask(cb);}};
  const Host=vm.runInNewContext(fs.readFileSync(require.resolve('./knowledge-library-host.js'),'utf8')+';EditingToolbarKnowledgeLibrary',sandbox);
  const host=Object.create(Host.prototype);Object.assign(host,{overlay:{style:{visibility:''}},toolbar:{readingPosition:{cancelRestore(){state.cancelledRestore=true;}}},store:{path:path.win32,resolveFile:f=>f.path,io:{stat:async()=>({isFile:()=>true})}}});
  return {state,File,host,file:{path:'C:\\paper.md'}};
}
test('native blocked state fails immediately and legitimate activation permits retry without patching guard',async()=>{
  const {state,host,file}=fixture();state.blocked=true;
  await assert.rejects(host.openFile(file),/我的许可证/);assert.equal(state.calls,0);assert.equal(state.ticks,0);assert.equal(state.blocked,true);assert.equal(host.overlay.style.visibility,'');
  state.blocked=false;assert.equal(await host.openFile(file),true);assert.equal(state.calls,1);assert.equal(host.overlay.style.visibility,'');
});
test('visible save dialog remains accessible past ten seconds; native save eventually switches',async()=>{
  const {state,File,host,file}=fixture();File.editor.library.openFile=()=>{state.dialog=true;state.calls++;};
  state.tick=()=>{assert.equal(host.overlay.style.visibility,'hidden');if(state.ticks===150){state.dialog=false;File.bundle.filePath=file.path;}};
  assert.equal(await host.openFile(file),true);assert.equal(state.ticks,150);assert.equal(host.overlay.style.visibility,'');
});
test('cancelled save and native no-op restore library with accurate failure, preserve original file',async()=>{
  for(const withDialog of [false,true]){
    const {state,File,host,file}=fixture();File.editor.library.openFile=()=>{state.dialog=withDialog;};state.tick=()=>{if(state.ticks===3)state.dialog=false;};
    await assert.rejects(host.openFile(file),withDialog?/可能已取消/:/未完成文档切换/);assert.equal(File.bundle.filePath,'C:/old.md');assert.equal(host.overlay.style.visibility,'');assert.equal(host.switchingDocument,false);
  }
});
test('native exception and activation guard arriving during switch restore library',async()=>{
  const f=fixture();f.File.editor.library.openFile=()=>{throw Error('native failure');};await assert.rejects(f.host.openFile(f.file),/native failure/);assert.equal(f.host.overlay.style.visibility,'');
  const g=fixture();g.File.editor.library.openFile=()=>{};g.state.tick=()=>{g.state.blocked=true;};await assert.rejects(g.host.openFile(g.file),/我的许可证/);assert.equal(g.host.overlay.style.visibility,'');assert.equal(g.state.blocked,true);
});
test('already-open file is accepted and busy editor is not given a concurrent open',async()=>{
  const {state,File,host,file}=fixture();File._onFileSwitching=true;await assert.rejects(host.openFile(file),/正在加载或切换/);assert.equal(state.calls,0);
  File.bundle.filePath=file.path;state.blocked=true;assert.equal(await host.openFile(file),true);assert.equal(state.calls,0);
});
test('pre-existing native prompt is handled before starting another document switch',async()=>{
  const {state,host,file}=fixture();state.dialog=true;state.tick=()=>{assert.equal(state.calls,0);if(state.ticks===3)state.dialog=false;};assert.equal(await host.openFile(file),true);assert.equal(state.calls,1);
});

test('read transaction never reveals library between file switch and slow metadata close',async()=>{
  const {host,file}=fixture(),release=host.beginRead();
  assert.equal(host.overlay.style.visibility,'hidden');
  await host.openFile(file);
  for(let frame=0;frame<4;frame++){await new Promise(r=>setImmediate(r));assert.equal(host.overlay.style.visibility,'hidden');}
  host.overlay.hidden=true;release();assert.equal(host.overlay.hidden,true);assert.equal(host.overlay.style.visibility,'');
});
test('failed read transaction restores the library after native cancellation',async()=>{
  const {host,file,File}=fixture(),release=host.beginRead();File.editor.library.openFile=()=>{};
  try{await assert.rejects(host.openFile(file),/未完成文档切换/);assert.equal(host.overlay.style.visibility,'hidden');}
  finally{release();}assert.equal(host.overlay.style.visibility,'');
});

test('reading UI releases its surface on success, open failure and metadata save failure',async()=>{
  const source=fs.readFileSync(__dirname+'/knowledge-library-ui.js','utf8');
  const script=source.slice(source.indexOf('    async function readItem('),source.indexOf('    const bookMode='))+';readItem';
  for(const outcome of ['success','open-failure','save-failure']){
    const item={id:'paper',status:'unread',files:[{id:'md',path:'C:/paper.md'}]},surface={visible:true,closed:false},calls=[];let flushes=0;
    const env={openingFile:false,byID:()=>item,state:{},clone:x=>({...x}),persist(){},showError:()=>calls.push('error'),
      flush:async()=>{if(++flushes===2){assert.equal(surface.visible,false);await new Promise(r=>setImmediate(r));assert.equal(surface.visible,false);return outcome!=='save-failure';}return true;},
      bridge:{beginRead(){surface.visible=false;return ()=>{calls.push('release');surface.visible=!surface.closed;};},
        openFile:async()=>{assert.equal(surface.visible,false);if(outcome==='open-failure')throw Error('cancelled');},
        close:async()=>{assert.equal(surface.visible,false);surface.closed=true;calls.push('close');}}};
    await vm.runInNewContext(script,env)('paper');assert.equal(env.openingFile,false);
    assert.equal(surface.visible,outcome!=='success');assert.equal(surface.closed,outcome==='success');
    assert.equal(calls.at(-1),'release');assert.equal(item.status,outcome==='open-failure'?'unread':'reading');
  }
});

test('failed open offers document retry and does not mark the literature read until it succeeds',async t=>{
  const {JSDOM}=require('jsdom'),dom=new JSDOM(fs.readFileSync(__dirname+'/knowledge-library.html','utf8'));t.after(()=>dom.window.close());
  const source=fs.readFileSync(__dirname+'/knowledge-library-ui.js','utf8'),item={id:'paper',status:'unread',files:[{id:'md',path:'C:/paper.md'}]},state={},calls=[];
  const env={q:s=>dom.window.document.querySelector(s),openingFile:false,byID:()=>item,state,clone:x=>({...x}),persist(){},flush:async()=>true,bridge:{openFile:async()=>{calls.push('open');throw Error('Typora 暂未允许打开文档');},close:async()=>calls.push('close')}};
  const api=vm.runInNewContext(source.slice(source.indexOf('    let retryOpen='),source.indexOf('    function run(action)'))+source.slice(source.indexOf('    async function readItem('),source.indexOf('    const bookMode='))+';({readItem,showError,clearError,retry:()=>retryOpen()})',env);
  await api.readItem('paper');assert.equal(item.status,'unread');assert.equal(item.last,undefined);assert.equal(env.q('[data-do="retry-save"]').hidden,true);assert.equal(env.q('[data-do="retry-open"]').hidden,false);assert.equal(env.q('[data-library-error] [data-do="close-library"]').hidden,false);
  env.bridge.openFile=async()=>calls.push('open');await api.retry();assert.equal(item.status,'reading');assert.ok(item.last);assert.deepEqual(calls,['open','open','close']);
  api.showError('write failed');assert.equal(env.q('[data-do="retry-save"]').hidden,false);assert.equal(env.q('[data-do="retry-open"]').hidden,true);
});
